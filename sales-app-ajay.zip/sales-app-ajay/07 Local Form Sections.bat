@echo off
title 07 Local Form Sections - Sales CRM
cd /d "%~dp0"
echo LOCAL ONLY: clears test-field privacy categories and splits the local lead form into 4 sections.
echo Make sure "02 Launch Local.bat" is running first.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts-local\07-local-form-sections.ps1"
pause

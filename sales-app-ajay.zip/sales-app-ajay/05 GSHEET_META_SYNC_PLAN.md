# 05 Google Sheet → CRM lead sync (Meta leads) — plan for owner approval

Status: PLAN ONLY — no code written. Needs owner approval of the decisions in section 6.
Architecture: unchanged. Built as a connector using existing parts (see section 4).

## 1. Why

Meta Lead Ads already write every new lead into a Google Sheet (file reviewed: `META_ADS__CRM_FINAL.xlsx`, 111 rows, 1 tab).
Pulling from that sheet needs no Meta app review and no change to marketing's setup.

## 2. Sheet as it is today (headers only, no personal data copied)

| Column | Filled | Notes |
| --- | --- | --- |
| id | 111/111, all unique | Format `l:<digits>` = Meta lead id → **unique key** |
| created_time | 111/111 | ISO with mixed time zones (+05:30, -05:00) → convert to UTC |
| ad_id, ad_name | 110/111 | 3 ads |
| adset_id, adset_name | 110/111 | 1 ad set |
| campaign_id, campaign_name | 110/111 | 1 campaign |
| form_id, form_name | 111/111 | 1 Meta form |
| is_organic | 111/111 | false 110, true 1 |
| platform | 110/111 | fb 90, ig 20 |
| what_is_your_company's_annual_revenue? | 111/111 | 4 bands, e.g. `less_than_5_million` |
| what_best_describes_your_role? | 111/111 | 6 options, e.g. `finance_manager_/_accountant` |
| full_name, work_email, whatsapp_number, company_name | 111/111 | Personal data |
| lead_status | 111/111 | `Good` 109, `CREATED` 2 |

Data quality found:
- 1 Meta **test lead** (values start `<test lead: dummy data ...>`) → must be skipped.
- 2 phone numbers without `+country code` → normalise with the org's default country (libphonenumber, already used).
- Answer values are Meta keys (`5_-_25_million`) → store as readable labels ("5–25 million").

## 3. Field mapping (proposed)

| Sheet column | CRM field | Rule |
| --- | --- | --- |
| id | Sync key (not shown) | Strip `l:`; a row with a known id is never imported again |
| full_name | Contact name | Required |
| company_name | Company | Required |
| work_email | Email | Required; lower-case |
| whatsapp_number | Phone | Normalise to E.164 |
| created_time | Lead created date | UTC |
| platform | Source | `fb` → "Meta Ads – Facebook", `ig` → "Meta Ads – Instagram" |
| campaign_name / adset_name / ad_name / form_name | Custom fields `meta_campaign`, `meta_adset`, `meta_ad`, `meta_form` | Same keys the Meta connector already uses |
| annual revenue answer | Custom field "Annual revenue" (select) | Readable label |
| role answer | Custom field "Role" (select) | Readable label |
| is_organic, *_id columns | Stored for reporting only | Not shown on the form |
| lead_status | — | See decision 4 |
| (none) | Stage | New |
| (none) | Owner | Existing routing rules |

## 4. How it works (all reused)

| Step | What | Reused |
| --- | --- | --- |
| 1 | Admin → Connect tools → **Google Sheets**: paste link, pick tab, test access | Connector card + credentials (`ConnectorRegistry`) |
| 2 | Sheet shared read-only with a CRM service-account email | Encrypted secret storage |
| 3 | Column → field mapping screen | LinkedIn / Meta mapping (`CaptureFieldMapping`) |
| 4 | Worker reads new rows every N minutes | Pattern of `LinkedInLeadSyncWorker` |
| 5 | Skip known ids and test leads | Synced-ids table like `meta_synced_leads` |
| 6 | Duplicate check (email / phone) → new lead, note on existing, or skip (org setting) | `CapturedLeadWriter`, `DuplicateMatchService` |
| 7 | Card shows last sync, imported, skipped, errors; rows logged | Integration counters, incoming log |
| 8 | First connect: one-time import of existing rows (111 today) | Same as Meta 90-day backfill |

## 5. Risks

| Risk | Handling |
| --- | --- |
| Column renamed or moved | Match by header name, not position; flag "mapping broken" on the card |
| Public "anyone with link" sheet exposes personal data | Not allowed: private sheet shared only with the service account |
| 5–15 min delay vs instant direct Meta connector | Accepted trade-off |
| Two routes for Meta leads | Needs owner OK (decision 1) |

## 6. Decisions for the owner

1. Approve a Google Sheets connector alongside the existing direct Meta connector?
2. Google Cloud project for the service account (Suntech company account).
3. Sync interval: 5 or 15 minutes?
4. `lead_status` column: ignore, import only `Good`, or map to a CRM field?
5. Priority from revenue band (e.g. 50 million+ = High)? Or all Medium?
6. Existing 111 rows: import all on first connect, or only new rows from go-live?
7. Duplicate mode for sheet leads: new lead / note on existing / skip?

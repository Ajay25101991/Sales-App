@echo off
setlocal EnableExtensions
title 02 Launch Local - Sales CRM
cd /d "%~dp0"

echo ============================================================
echo   Sales CRM - LOCAL LAUNCHER (our copy: sales-app-ajay)
echo   Test changes here before any deploy build.
echo ============================================================
echo.

REM ---------- 1. Prerequisites ----------
where docker >nul 2>&1 || (echo [X] Docker not found. Install Docker Desktop and start it. & goto :fail)
where dotnet >nul 2>&1 || (echo [X] .NET 8 SDK not found. Install from https://dotnet.microsoft.com & goto :fail)
where node   >nul 2>&1 || (echo [X] Node.js 20+ not found. Install from https://nodejs.org & goto :fail)
docker info >nul 2>&1 || (echo [X] Docker is installed but not running. Start Docker Desktop, then re-run. & goto :fail)
echo [OK] Docker, .NET and Node found.

REM ---------- 2. Choose what to run ----------
echo.
echo What do you want to run?
echo   1 = Desktop app (laptop UI)              [recommended]
echo   2 = Desktop + Phone web (Expo)
echo   3 = Desktop + Partner portal + Control panel
echo   4 = Everything
echo   5 = Backend only (DB + API)
set "CHOICE=1"
set /p "CHOICE=Enter 1-5 (default 1): "

REM ---------- 3. Env files and packages ----------
if not exist "apps\web\.env"    if exist ".env.example" copy /y ".env.example" "apps\web\.env"    >nul
if not exist "apps\mobile\.env" if exist ".env.example" copy /y ".env.example" "apps\mobile\.env" >nul

if not exist "node_modules\@sales" (
  echo.
  echo [..] First run: installing npm packages. This takes a few minutes...
  call npm install --no-audit --no-fund || (echo [X] npm install failed. & goto :fail)
)
echo [OK] npm packages ready.

REM ---------- 4. Database (Postgres in Docker, port 5433) ----------
echo.
echo [..] Starting Postgres (sales-postgres on port 5433)...
pushd api
docker compose up -d || (popd & echo [X] Could not start Postgres container. & goto :fail)
popd
set /a TRIES=0
:waitdb
docker exec sales-postgres pg_isready -U sales -d sales_dotnet >nul 2>&1 && goto :dbok
set /a TRIES+=1
if %TRIES% GEQ 30 (echo [X] Postgres did not become ready in 60s. & goto :fail)
timeout /t 2 /nobreak >nul
goto :waitdb
:dbok
echo [OK] Postgres is ready.

REM ---------- 5. API (.NET on http://localhost:5100) ----------
curl.exe -s http://localhost:5100/health >nul 2>&1 && (echo [OK] API already running on 5100. & goto :apiok)
echo [..] Starting API window (first start runs migrations - can take 1-2 min)...
start "SALES-API (5100)" cmd /k "cd /d "%~dp0api" && set ASPNETCORE_ENVIRONMENT=Development&& set ASPNETCORE_URLS=http://localhost:5100&& set Logging__LogLevel__Default=Warning&& dotnet run --no-launch-profile"
set /a TRIES=0
:waitapi
curl.exe -s http://localhost:5100/health >nul 2>&1 && goto :apiok
set /a TRIES+=1
if %TRIES% GEQ 90 (echo [X] API not healthy after 3 min. Check the SALES-API window for errors. & goto :fail)
timeout /t 2 /nobreak >nul
goto :waitapi
:apiok
echo [OK] API healthy: http://localhost:5100/health

REM ---------- 6. Front-ends ----------
if "%CHOICE%"=="5" goto :summary

start "SALES-DESKTOP (8110)" cmd /k "cd /d "%~dp0" && npm -w @sales/desktop run dev"

if "%CHOICE%"=="2" start "SALES-PHONE-WEB (8081)" cmd /k "cd /d "%~dp0" && npm -w @sales/web run web"
if "%CHOICE%"=="4" start "SALES-PHONE-WEB (8081)" cmd /k "cd /d "%~dp0" && npm -w @sales/web run web"

if "%CHOICE%"=="3" goto :portals
if "%CHOICE%"=="4" goto :portals
goto :open
:portals
start "SALES-PARTNER (8120)" cmd /k "cd /d "%~dp0" && npm -w @sales/partner run dev"
start "SALES-CONTROL (8130)" cmd /k "cd /d "%~dp0" && npm -w @sales/control run dev"

:open
echo [..] Waiting for the desktop dev server...
timeout /t 8 /nobreak >nul
start "" "http://localhost:8110/apps/desktop/"

:summary
echo.
echo ============================================================
echo   RUNNING LOCALLY
echo   API ........... http://localhost:5100   (health: /health, docs: /swagger)
if not "%CHOICE%"=="5" echo   Desktop ....... http://localhost:8110/apps/desktop/
if "%CHOICE%"=="2" echo   Phone web ..... http://localhost:8081
if "%CHOICE%"=="4" echo   Phone web ..... http://localhost:8081
if "%CHOICE%"=="3" echo   Partner ....... http://localhost:8120/apps/partner/
if "%CHOICE%"=="3" echo   Control ....... http://localhost:8130/
if "%CHOICE%"=="4" echo   Partner ....... http://localhost:8120/apps/partner/
if "%CHOICE%"=="4" echo   Control ....... http://localhost:8130/
echo.
echo   Login: maya@salesco.test / Password123!  (manager)
echo   Code edits in desktop/apps refresh the browser automatically.
echo   API (C#) edits: close SALES-API window and run this again.
echo   To stop everything: run "03 Clean Local.bat"
echo ============================================================
pause
exit /b 0

:fail
echo.
echo Launch stopped. Fix the issue above and run again.
pause
exit /b 1

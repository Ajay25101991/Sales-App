# 04 CHANGE LOG — our copy (sales-app-ajay)

Every change we make to this copy is recorded here, newest first.
The original `sales-app-main` is never edited. Architecture stays frozen (see `01 PROJECT_OVERVIEW.md`, section 0).

## How to log a change

| Field | What to write |
| --- | --- |
| No. | Running number (CL-001, CL-002 ...) |
| Date | DD-MMM-YYYY |
| Area | Launcher / Docs / Desktop UI / Phone UI / API / Database / Config |
| Files changed | Exact paths, relative to the repo root |
| What changed | One or two lines, plain words |
| Why | The business reason or request |
| How tested | Local launch, screen checked, login used |
| Status | Done / In progress / Reverted |

Rule: a code change is not finished until it has a row here. A database migration also needs a note on how to roll it back.

## Log

| No. | Date | Area | Files changed | What changed | Why | How tested | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CL-017 | 25-Nov-2026 | Desktop UI (app code) | `desktop/src/components/lead-form.tsx`, `.module.css` | Deal summary card like the mock: chips (status, priority, deal type, products), money rows (Estimated value + the form's Year 1 fees, Year 2 fees, Final value, Payment received found by label), "Year 1 + Year 2 fees" total box. Owner decision: which money fields the card shows/sums should become an org setting | Ajay: needs all summary rows | Syntax OK | In progress |
| CL-016 | 25-Nov-2026 | Local test data | `08 Local Partner Source.bat`, `scripts-local/08-local-partner-source.ps1` | Local Source list set to live order incl. Partner; form's Partner field shown + required only when Source = Partner, placed under Source. TEST partners not created: Maya's local role lacks "Manage channel partners" (403) | Match live Source → Partner behaviour | Ran: sources OK, form rule OK, partners 403 (re-runnable) | Done (partners pending) |
| CL-015 | 25-Nov-2026 | Desktop UI (app code) | `desktop/src/components/lead-form.tsx`, `.module.css` | Closer to the mock: red tint inside the control (not around the field), lighter placeholders, section icons (picked from the section title), open-section highlight and dark step badge, dark green deal-summary card, sticky bottom save bar with "x required fields left" and a glowing Save when ready | Ajay: "not like the artifact" | Syntax OK; test at localhost | In progress |
| CL-014 | 25-Nov-2026 | Local test data | `07 Local Form Sections.bat`, `scripts-local/07-local-form-sections.ps1`, `scripts-local/06-local-test-data.ps1` | Clears the privacy *category* wrongly set on the 16 test fields (category = data-access setting, not layout); splits each local lead form into Contact details / Pipeline / Industry and ERP / Commercials (backup JSON saved first). 06 script fixed to never set category | Local form must have real sections to match the mock | Ran OK 25-Nov 18:00: 16 categories cleared; form 'Default' now Contact 11 (incl. former Address) / Pipeline 9 / Industry 4 / Commercials 12; backup `scripts-local/backup-form-578d8316-….json` | Done (local only) |
| CL-013 | 25-Nov-2026 | Desktop UI (app code) | `desktop/src/components/lead-form.tsx`, `.module.css` | Right rail "form map": progress ring (required filled), sections as clickable steps (open + scroll), live summary (status, priority, value, products). Sticky | Mock: step rail + deal summary + ring | Syntax OK; test at localhost on a wide window | In progress |
| CL-012 | 25-Nov-2026 | Desktop UI (app code) | same | Status and Priority as segmented switches (CSS on shared ChipSelect); Source as a dropdown (existing SelectMenu); Products as a checkbox grid with "x selected" | Mock: one control per kind of choice | Syntax OK | In progress |
| CL-011 | 25-Nov-2026 | Desktop UI (app code) | same | Required fields tinted light red (danger surface) until filled, new lead only; money fields show thousand separators | Mock: mandatory cue + finance-style amounts | Syntax OK | In progress |
| CL-010 | 25-Nov-2026 | Desktop UI (app code) | `desktop/src/components/lead-form.tsx`, `desktop/src/components/lead-form.module.css`, `packages/core/src/lib/lead-form-state.ts` | Redesign phase 1: every configured form section is a collapsible card (step badge / ✓, "x of y filled · n required left", +/−), Expand all / Collapse all, Tags + Deal type + Closed value + Playbook grouped as "Deal setup". New lead opens section 1; Edit lead opens collapsed; a refused save opens all sections. Form-builder preview unchanged. New shared helper `leadFormSectionProgress` (core) for reuse by phone forms. No backend change | Approved mock: minimal + rich layout | Syntax check OK; to test at localhost (New + Edit lead). Note: copy is 1–2 changes behind live, re-apply on fresh clone if needed | In progress |
| CL-009 | 25-Nov-2026 | Launcher | `02 Launch Local.bat` | Local API now runs with log level Warning (hides per-request GET lines); errors and warnings still show | Cleaner local console | Restart launcher, check SALES-API window | Done (local only) |
| CL-008 | 25-Nov-2026 | API (app code) | `api/Program.cs` (BuildConnectionString) | `[db] pool …` line printed once per process instead of on every connection set-up; no behaviour change | Log flood locally and on live (CloudWatch noise/cost) | Restart API: line should appear once | Done locally – **needs owner approval to go live** |
| CL-007 | 25-Nov-2026 | Local test data | `06 Local Test Data.bat`, `scripts-local/06-local-test-data.ps1` | Local-only script: adds 16 live-style custom fields (Industry, ERP systems, Commercials), the 9 live Products & services, and 5 leads named TEST 01–05 via the local API. No app code changed; never pushed live | Make the local form match live before redesign | Final run OK: 16 fields, 9 products, TEST 01-05 created locally (fixes: category names, product keys, PowerShell 5.1 list quirk, TEST 05 value); undo = 03 Clean option 4 | Done |
| CL-006 | 25-Nov-2026 | Docs | `05 GSHEET_META_SYNC_PLAN.md` | Plan for Google Sheet → CRM sync of Meta leads: sheet review, field mapping, reuse map, risks, 7 owner decisions. No code | Meta already writes leads to a Google Sheet; pull from it | Sheet headers checked (111 rows, 1 test lead, 2 phones without country code) | Plan – awaiting owner |
| CL-005 | 25-Nov-2026 | Docs | `04 CHANGE_LOG.md` | Created this change log | Track every change we make, separately from the code | File opened and checked | Done |
| CL-004 | 24-Nov-2026 | Docs | `01 PROJECT_OVERVIEW.md` | Added section 4A, full tech stack checked against package.json, .csproj and Terraform; updated the Hosting row | Record exactly which technologies are used | Checked against the dependency files | Done |
| CL-003 | 24-Nov-2026 | Launcher | `02 Launch Local.bat`, `03 Clean Local.bat`, `01 PROJECT_OVERVIEW.md` (section 8) | One-click local launcher (DB + API + chosen front-ends) and cleaner (stop / clean caches / deep clean / reset DB); local URLs added to the overview | See changes locally before any deploy build | Launched locally: API healthy, desktop on http://localhost:8110/apps/desktop/ | Done |
| CL-002 | 24-Nov-2026 | Docs | `01 PROJECT_OVERVIEW.md` | Added section 0, working agreement: architecture frozen, 8 rules | Owner instruction: do not change the code architecture | Read through | Done |
| CL-001 | 24-Nov-2026 | Docs | `01 PROJECT_OVERVIEW.md` (first created as PROJECT_OVERVIEW.md, renamed by Ajay) | Project overview: purpose, folder map, data flow, layers, modules, run/deploy steps, traps, glossary | Understand the project before working on it | Read through | Done |

## Setup notes (not code changes)

| Date | Note |
| --- | --- |
| 24-Nov-2026 | Copied `sales-app-main` to `sales-app-ajay` with robocopy (4,479 files, 0 failed). The original has no `.git`, so no history or branch yet |
| 24-Nov-2026 | Installed Docker Desktop on the laptop (direct download; winget not available). .NET 8 and Node v24 were already installed |
| 24-Nov-2026 | The original folder still contains the first `PROJECT_OVERVIEW.md`; to be removed only if Ajay asks |

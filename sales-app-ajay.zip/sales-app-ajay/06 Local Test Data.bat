@echo off
title 06 Local Test Data - Sales CRM
cd /d "%~dp0"
echo LOCAL ONLY: adds live-style custom fields + 5 TEST leads to http://localhost:5100
echo Make sure "02 Launch Local.bat" is running first.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts-local\06-local-test-data.ps1"
pause

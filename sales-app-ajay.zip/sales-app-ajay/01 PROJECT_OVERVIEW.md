# Sales CRM (sales-app-main) — Project Overview

Generated 24 Nov 2026 from a read of the repo (README, CLAUDE.md, DEPLOYMENT.md, `.claude/plans`, `to-do/`, folder structure).

## 1. What this project is

A multi-platform **sales CRM** (Suntech, `sales.suntech-global.com`) for field and inside sales teams.
It covers the full journey: **lead → qualification → proposal/quote → won → invoice → collection → AMC renewal**, with partner, customer and admin portals, workflows and an AI layer on top.

| Item | Value |
| --- | --- |
| Repo type | npm workspaces monorepo (`sales-monorepo`) + separate .NET backend |
| Frontend | Expo SDK 57 / React Native 0.86 (phone), React + Vite + React Router v7 (desktop, portals) |
| Backend | ASP.NET Core 8 + EF Core, PostgreSQL 16, JWT auth |
| Server state | TanStack Query (React Query) — no Redux/Zustand |
| Languages | TypeScript (clients), C# (API) |
| Hosting | Docker → AWS ECS Fargate + RDS Postgres + ALB + S3 (Terraform in `infra/aws`); Render blueprint as alternative |
| Size (approx.) | 127 controllers, 166 EF models, ~244 migrations, ~630 test files |

## 0. Working agreement (our copy) — architecture is frozen

This folder (`sales-app-ajay`) is our working copy. The original `sales-app-main` is never edited.
**We will not change the architecture of the code.** All work fits inside the existing structure.

| Rule | What it means in practice |
| --- | --- |
| No new layers or projects | Keep Host → Experience → Process → System → Contracts exactly as they are |
| No stack changes | Stay on Expo SDK 57, React + Vite, ASP.NET Core 8, EF Core, PostgreSQL 16, React Query |
| No folder restructuring | Apps, packages, api projects and routes stay where they are; no renames or moves |
| Follow existing patterns | New domain = `XStore` → `XProcess` → `XExperience`, registered in `Program.cs`; UI = screen → hook → `api.ts` |
| Reuse before adding | Extend existing components, hooks, endpoints and helpers; no parallel versions |
| No new state libraries or frameworks | No Redux/Zustand, no new UI kit, no new ORM |
| Schema changes only by additive migration | Add columns/tables via EF migrations; never drop or rename live columns without sign-off |
| Log every change | Each change gets a row in `04 CHANGE_LOG.md` (files, what, why, how tested) before it counts as done |
| Escalate, don't decide | Anything that would need an architecture change is written up and taken to the owner first |

## 2. Repository map

| Path | What it holds |
| --- | --- |
| `apps/mobile` | Expo native app — iOS + Android |
| `apps/web` | Expo / React-Native-Web — phones and mobile browsers |
| `desktop/` | React + Vite desktop web app (laptops), served at `/apps/desktop`; Playwright e2e |
| `apps/partner` | Partner / customer portal (Vite), served at `/apps/partner` |
| `apps/control` | Platform control panel (orgs, plans, domains, studio access) — `suntech-admin` logins only |
| `packages/core` | Shared logic: hooks, API client, auth context, constants, demo data (no DOM) |
| `packages/ui` | Native UI primitives (Button, TextField, Card, Badge, ChipSelect...) |
| `packages/ui-web` | Web UI primitives (DOM + CSS modules) |
| `api/` | .NET backend (layered, see section 4) |
| `infra/aws` | Terraform: ECR, ECS Fargate, GitHub OIDC deploy role |
| `.github/workflows` | `ci.yml` (lint/typecheck/test) and `deploy-aws.yml` (build image → ECR → ECS) |
| `.design-sync` | Design-system previews, specs and live mock HTML screens |
| `docs/` | Aggregation for KPIs, teams plan, tenancy migration plan |
| `to-do/` | ~100 design docs, audits, scope decisions and handoffs |
| `scripts/` | Theme CSS generator, country list generator, web-font copy, Dirham glyph patch |
| `.claude/`, `.codex/` | AI agent definitions and delivery plans |

## 3. Request / data flow (how a click becomes data)

| Step | Layer | Where |
| --- | --- | --- |
| 1 | Screen renders, user acts | `apps/*` or `desktop/src/screens` |
| 2 | Screen calls a React Query hook | `packages/core/src/hooks/` (e.g. `use-leads.ts`) |
| 3 | Hook calls thin fetch client with JWT | `packages/core/src/lib/api.ts` |
| 4 | Controller routes, checks permission, picks status code | `api/Controllers/` |
| 5 | Experience layer shapes response per consumer | `api/SalesApi.ExperienceApi` |
| 6 | Process layer applies business rules | `api/SalesApi.ProcessApi` |
| 7 | System layer reads/writes DB via stores | `api/SalesApi.SystemApi` (Models, Data, Migrations, Services) |
| 8 | Mutation invalidates query keys → UI refetches | React Query cache (persisted 24h for offline) |

## 4. Backend architecture (API-led, 3 layers)

| Project | Holds | May reference |
| --- | --- | --- |
| `SalesApi` (host) | Controllers, `Program.cs`, `wwwroot` | all below |
| `SalesApi.ExperienceApi` | per-consumer shaping | Contracts, ProcessApi |
| `SalesApi.ProcessApi` | business rules, orchestration | Contracts, SystemApi |
| `SalesApi.SystemApi` | EF models, DbContext, migrations, stores, services, workers | Contracts |
| `SalesApi.Contracts` | DTOs / plain types | nothing |

Rules enforced by tests: `LayerBoundaryTests` (no System types leak upward), `LayerRegistrationTests` (every Store/Process/Experience registered in `Program.cs`).
New domain recipe: `XStore` → `XProcess` → `XExperience` → register in `Program.cs` → wire in `SalesApi.Tests/LoyaltyLayers.cs`.

## 4A. Full tech stack (verified from package.json and .csproj files)

### Frontend

| Area | Technology | Used in |
| --- | --- | --- |
| UI library | React 19.2 | all apps |
| Language | TypeScript 6.0 | all apps and packages |
| Phone app | Expo SDK 57, React Native 0.86, expo-router (file-based routing) | `apps/mobile`, `apps/web` |
| Phone web | react-native-web 0.21 | `apps/web` |
| Desktop / portals | Vite 7, React Router 7 | `desktop`, `apps/partner`, `apps/control` |
| Server state + offline | TanStack Query 5 + AsyncStorage persister, NetInfo | all apps |
| Charts | Apache ECharts 5 | `packages/ui-web` |
| Rich text editor | Tiptap 2 | desktop (proposals, templates) |
| Flow / workflow canvas | React Flow (`@xyflow/react` 12) | desktop workflow editor |
| Dates | date-fns 4 | all apps |
| Animation / gestures | Reanimated 4, Gesture Handler, Worklets | phone |
| Native features | expo-camera, image-picker, notifications (push), local-authentication (biometrics), print, sharing, file-system, quick-actions, expo-updates (OTA), Android widget, iOS targets | phone |
| OCR | Google ML Kit text recognition (on-device) | `apps/mobile` |
| Currency glyph | `dirham` package + patched fonts (AED sign) | core, ui |
| Fonts | Plus Jakarta Sans, JetBrains Mono (self-hosted) | all apps |
| Styling | Manual theme tokens (`theme.ts`), CSS modules on web; no Tailwind/NativeWind | ui, ui-web |

### Backend

| Area | Technology |
| --- | --- |
| Framework | ASP.NET Core 8 (C#, .NET 8) — 5 projects: Host, Experience, Process, System, Contracts |
| Database | PostgreSQL 16 via EF Core 8 + Npgsql, snake_case naming (EFCore.NamingConventions), jsonb columns |
| Auth | JWT bearer, BCrypt password hashes, SSO + OAuth controllers, API keys, DataProtection keys stored in DB |
| API docs | Swagger (Swashbuckle) at `/swagger` |
| AI | AWS Bedrock Runtime (Anthropic Claude models, e.g. Claude 3 Haiku) with skills, action policies, cost policy, execution log, evals |
| MCP | `ModelContextProtocol.AspNetCore` 2.4 — the CRM exposes its own MCP server (`api/Mcp`) |
| File storage | AWS S3 (attachments, documents) + SharePoint via Microsoft Graph |
| Email | AWS SES v2 (sending), Microsoft Graph mail (mailbox sync, shared mailbox) |
| PDF | PDFsharp-MigraDoc (invoices, proposals, documents) |
| Phone numbers | libphonenumber-csharp (validation, duplicate matching) |
| Security | HtmlSanitizer, rate limiting, security headers, data-access and reveal logs |
| Background jobs | .NET `BackgroundService` workers: reminders, campaign send, mailbox sync, LinkedIn lead sync, report schedules, WhatsApp template sync, SharePoint move, integration alerts, portal sign-up purge |
| Tests | xUnit + EF Core InMemory; live Postgres checks with `SALES_LIVE_DB=1` |

### Integrations

| Integration | Purpose |
| --- | --- |
| Microsoft 365 (Graph) | Mail, calendar, SharePoint document storage, SSO |
| WhatsApp Cloud API | Messaging, templates, inbound webhook |
| Meta Lead Ads, LinkedIn Lead Sync | Lead capture from ads |
| Stripe | Online payments, payment webhooks, public pay links |
| Accounting sync | Framework present; current connector is log-only (Tally/Zoho referenced, not live) |
| Expo Push | Mobile push notifications |

### DevOps and tooling

| Area | Technology |
| --- | --- |
| Containers | Docker (API image also carries web, desktop, partner, control builds) |
| Cloud | AWS: ECS Fargate, ECR, RDS Postgres, ALB + certificate, S3 (versioned, encrypted), VPC/NAT, CloudWatch logs |
| IaC | Terraform (`infra/aws`) |
| CI/CD | GitHub Actions: `ci.yml` (Node 20 lint/typecheck/test, .NET 8 tests with Postgres service), `deploy-aws.yml` (OIDC → ECR → ECS) |
| Mobile builds | EAS (Expo Application Services) |
| Quality | ESLint 9, typescript-eslint, `node --test` (core), Playwright e2e (desktop) |
| Package manager | npm workspaces (Node >= 20) |

## 5. Functional modules (grouped from controllers)

| Module | Key controllers / features |
| --- | --- |
| Leads & pipeline | Leads, LeadStageValues, LeadQualification, LeadBrief, LeadRecommendations, DealRisk, Playbooks, Workflows, SavedViews, Tags, CustomFields, Picklists |
| Accounts & contacts | Accounts, Contacts, Stakeholders, Organizations, Teams, Team, Roles |
| Lead capture | LeadForms, MetaLeadAds, LinkedInLeadSync, Campaigns (+ public), WhatsApp (+ webhook), SharedMailbox, MailboxConnect, EmailUnmatched |
| Proposals & quotes | Proposals, ProposalGeneration, Quotes, PricingModels, Packages, CatalogItems, DocumentTemplates, EngagementLetter |
| Money | Invoices, OnlinePayments, PaymentWebhook, PayPublic, Collections, CollectionTasks, AccountingSync, Amcs |
| After the win | AfterWin, DeliveryProject, IRL (info request lists), DocumentRequests, ClientDocuments, ChangeRequests |
| Partners & portals | ChannelPartners, PartnerPortal, PartnerApi, PartnerBulk, PartnerMou, PartnerStock, CustomerPortal, Portal, LoyaltyBenefits |
| Activities & reminders | Tasks, Reminders, Notifications, Digest, RecordEmails, MessageTemplates |
| Reports & dashboards | Dashboard, Reports, CustomReports, SavedReports, ReportSchedules, MonthlyReport, Targets |
| AI layer | AiSkills, AiActionPolicies, AiCostPolicy, AiExecutionLog, AiFeedback, Knowledge, FieldSuggestions, MCP server (`api/Mcp`) |
| Admin, security, compliance | Admin, Settings, Approvals, ApprovalChains, Sso, OAuth, ApiKeys, Privacy, RevealRequests, DataAccessLog, Screenings, Sandbox, Usage, Plans, Studio |
| Integrations | Integrations, IntegrationEvents, Webhooks, Microsoft365Settings, SharePointBrowse, McpConnections |

## 6. Key design rules (owner standing rules)

| Rule | Meaning |
| --- | --- |
| Reuse first | Extend existing helpers/components/endpoints; a parallel implementation is rejected |
| Decisions are the owner's | Agents stop and hand back open questions with options + recommendation |
| Agents run no builds/tests | Coordinator runs all suites in one batched pass after merge |
| Aggregate tables | Reports read DealStats, PipelineStats, ActivityStats, CohortStats, ForecastSnapshot; every write keeps them current |
| No destructive git | No stash/reset/rebase; nothing pushed/deployed without owner approval |
| Auth at HTTP layer | Owner/manager scoping in controllers; caller facts passed down as data |

## 7. Notable capabilities

| Capability | How |
| --- | --- |
| Offline mode | React Query cache persisted to AsyncStorage; NetInfo pauses/resumes mutations; optimistic lead updates |
| Demo mode | `EXPO_PUBLIC_DEMO=true` → in-memory mock API (`packages/core/src/lib/demoData.ts`), no login |
| Business-card OCR | ML Kit on-device (native dev build only) |
| Reminder delivery | `ReminderSweeper` background worker sends Expo push |
| Multi-currency incl. AED | Custom Dirham sign (U+20C3) glyph handling — see `FONTS.md` |
| Device routing | `api/wwwroot/apps/sales/index.html` loader picks phone vs desktop build |

## 8. How to run locally (steps)

| Step | Command |
| --- | --- |
| 1 | `cd api && docker compose up -d` (Postgres on host port 5433) |
| 2 | `dotnet run` (API on http://localhost:5100; migrates + seeds) |
| 3 | From repo root: `npm install` |
| 4 | Copy `.env.example` to `apps/web/.env` and `apps/mobile/.env` |
| 5 | `npm run start` (press i / a / w) — desktop: `cd desktop && npm run dev` |
| 6 | Gates: `npm run lint`, `npm run typecheck` (never bare root `tsc`), `npm test` |

Shortcut (our copy): double-click **`02 Launch Local.bat`** to start DB + API + chosen front-ends and open the browser; **`03 Clean Local.bat`** stops everything and clears caches (option 4 resets the local DB).

| Local URL | What |
| --- | --- |
| http://localhost:5100/swagger | API docs |
| http://localhost:8110/apps/desktop/ | Desktop app |
| http://localhost:8081 | Phone web (Expo) |
| http://localhost:8120/apps/partner/ | Partner portal |
| http://localhost:8130/ | Control panel |

Seeded logins (password `Password123!`): `maya@salesco.test` (manager), `liam@`, `sofia@`, `noah@`, `ava@salesco.test` (reps).

## 9. Deployment

| Step | What happens |
| --- | --- |
| 1 | Push to `main` touching api/web/partner/control/desktop/core paths |
| 2 | `deploy-aws.yml` builds web + desktop + portals into the API Docker image |
| 3 | Image pushed to ECR via GitHub OIDC role |
| 4 | ECS Fargate forced redeploy; EF migrations run on container start |
| Risk | No pre-migration DB snapshot (item A0 parked) — a bad migration crash-loops prod |

## 10. Known traps (from CLAUDE.md)

| Trap | Effect |
| --- | --- |
| EF InMemory evaluates LINQ in C# | Unit tests pass, Postgres fails to translate — run `SALES_LIVE_DB=1` live checks for GROUP BY / raw SQL |
| Reflection-based response tests | JSON key renames go unnoticed — verify against a real signed-in response |
| Date-dependent tests | Pin the instant; never use `DateTime.UtcNow` fixtures |
| Missing per-app `.env` | Metro cache keeps stale demo flag |
| Web fonts after `expo export` | Run `node scripts/copy-web-fonts.mjs apps/web/dist` |
| Worktrees | Run `npm install` inside the worktree or `@sales/*` resolves to main checkout |

## 11. Glossary (with India examples)

| Term | Definition | Example 1 (India) | Example 2 (India) |
| --- | --- | --- | --- |
| Lead | A potential customer being tracked through stages | A Pune manufacturer enquiring about e-invoicing software | A Chennai CA firm that filled a website form |
| Pipeline | Ordered stages a lead moves through (New → Won/Lost) | Tata dealer sales funnel for fleet orders | Bank loan desk: enquiry → documents → sanction |
| AMC | Annual Maintenance Contract, renewed yearly | Yearly AC servicing contract with Voltas | Tally software annual support renewal |
| Collections | Tracking and chasing unpaid invoices | Distributor following up 60-day dues from retailers in Surat | Telecom vendor chasing a PSU for pending payment |
| Channel partner | Third party that resells or refers your product | Airtel retailer selling SIMs | Regional reseller selling Zoho licences |
| Monorepo | One repository holding many apps and shared packages | Flipkart keeping app, web and seller tools together | Paytm sharing one payments library across apps |

## 12. Where to read next

| Need | File |
| --- | --- |
| Architecture rules | `CLAUDE.md` |
| Backend setup / endpoints | `api/README.md` |
| Cloud deploy | `DEPLOYMENT.md`, `infra/aws/README.md` |
| Roadmap & scope | `.claude/plans/crm-delivery-plan.md`, `.claude/plans/crm-scope-decisions.md` |
| Feature designs | `to-do/*-design.md` |
| Latest task status | `to-do/TASKS.md`, `to-do/HANDOFF*.md` |

---
**Summary:** A large, production-grade Suntech CRM — Expo phone app + React desktop + partner/control portals on a layered .NET 8 / Postgres API deployed to AWS.
Biggest risks: unattended production migrations with no snapshot, and EF InMemory tests hiding Postgres failures.

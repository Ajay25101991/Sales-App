@echo off
title 08 Local Partner Source - Sales CRM
cd /d "%~dp0"
echo LOCAL ONLY: adds Partner to Source, shows the Partner picker when Source = Partner, creates 3 TEST partners.
echo Make sure "02 Launch Local.bat" is running first.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts-local\08-local-partner-source.ps1"
pause

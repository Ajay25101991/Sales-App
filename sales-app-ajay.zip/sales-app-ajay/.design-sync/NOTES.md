# design-sync notes — Suntech Sales UI

This repo is an **Expo React Native app**, not a conventional web component library.
The sync is deliberately **off-script**: the `ui/` primitives are React Native
components, compiled to the web through **react-native-web** so claude.ai/design
can render them. Read this before any re-sync.

## Off-script build pipeline
- `.ds-sync/rnw-entry.tsx` — barrel that re-exports the 12 primitives.
- `.ds-sync/rnw-dist.mjs` (`cfg.buildCmd`) — esbuild bundles the barrel into a
  self-contained web dist at `.ds-sync/dist/index.mjs`, with:
  - `alias: { 'react-native': 'react-native-web' }` (the whole point)
  - `tsconfig: tsconfig.json` so `@/…` path aliases resolve
  - loaders: `.js`→`jsx` (for `@expo/vector-icons` JSX-in-.js), font/image → `dataurl`
  - a `node:` stub plugin (expo-font's SSR helper imports `node:async_hooks`)
  - `define`: `process.env.NODE_ENV="production"`, `__DEV__=false`, **`process.env.EXPO_OS="web"`**
    (without EXPO_OS the browser throws `process is not defined` and nothing mounts)
  - `external`: react / react-dom / jsx-runtime (the converter provides these from `_vendor/`)
- The converter is then pointed at that dist: `--entry .ds-sync/dist/index.mjs`.

## Config gotchas (already in config.json — don't relearn)
- `.ds-sync/package.json` MUST be nameless (`{"private":true}`). The converter walks
  up from the entry to the first package.json **with a name** to set `PKG_DIR`; a named
  `.ds-sync/package.json` makes `PKG_DIR=.ds-sync` and then `src/` isn't found (0 src-matched).
- Props DON'T auto-extract (the dist ships no `.d.ts`), so **`cfg.dtsPropsFor`** carries a
  hand-written props body for each component. Keep these in sync with the src interfaces.
- `DateField` is excluded: it pulls `@react-native-community/datetimepicker`, whose source is
  Flow-typed and unparseable by esbuild (and a native date picker isn't meaningful on web).
- CSS is `[CSS_RUNTIME]` (self-styling) — react-native-web injects atomic styles at runtime.
  This is expected; there is no static stylesheet to point `cfg.cssEntry` at.

## Preview authoring rule (important)
Authored previews in `.design-sync/previews/*.tsx` MUST import components from the
**package specifier** `'sales-mobile-app'` — e.g. `import { Button } from 'sales-mobile-app'`.
The preview compiler's shim only rewrites the package specifier to `window.SuntechUI`.
Importing via `@/components/...` instead makes the compiler bundle the component **from source**,
which pulls native `react-native/index.js` (Flow `typeof`) and the preview fails to compile
(drops to a floor card). Use plain `<div>` for layout glue in previews (never import
`react-native` there).

## Known render warns (triaged false positives — do NOT chase)
Confirmed again on the 2026-08-03 re-sync: 22 `bad`, 4 `thin`, 4 `variantsIdentical`
out of 38. The exact split is below; a warn on a component NOT in these lists is new.
- **`[RENDER] root empty` / `rootEmpty:true` on 14 components** (Badge, Button, Card,
  ChipSelect, EmptyState, Fab, ListRow, SectionHeader, Segmented, TextField, ThemedText,
  LeadTablePresentation, InvoiceTablePresentation, NavSidebarPresentation) — a react-native-web vs.
  render-harness measurement mismatch. Truth check: `.render-check.json` shows `blank:false`,
  real `maxHeight`, and 8–22KB PNGs, and `_screenshots/contact-sheet-1.png` shows every card
  fully rendered and styled. The harness counts one extra empty "root" per preview (an rnw DOM
  artifact). The cards render correctly in chromium (hence on the claude.ai/design platform).
- **Modal `thin`/`collapsed` (maxH:0)** — the modal renders as a position-absolute overlay
  (see the screenshot: the "Delete lead" dialog is there); the card box measures 0 height.
  Benign; `cfg.overrides.Modal.cardMode = "single"` is set for it.
- **`[RENDER_BLANK]` / `[RENDER_THIN]` / `[RENDER_ERRORS]` on the 8 unauthored components**
  (AccordionRail, DesktopFrame, TopBar, KpiRow, ProgressBar, StageBarRow, InvoiceRow,
  NavSidebar) — these have no `.design-sync/previews/<Name>.tsx`, so they render only from
  the `.d.ts` crash-prevention props: near-empty PNGs, and for the three data/context-driven
  ones a pageerror (`… .map` / `… .status` undefined; NavSidebar's `useAuth must be used
  within an AuthProvider`). Expected — the fix is authoring their previews, not config.
  9 components additionally show the deliberate typographic floor card. **`validate` therefore
  exits 1 on every run**; the gate for this repo is the contact sheets, not a green validate.

## Re-sync risks / watch-list
- **Fonts — RESOLVED.** `cfg.extraFonts` now points at `.design-sync/fonts.css`, and the
  7 per-weight ttfs (Plus Jakarta Sans 400/500/600/700/800, JetBrains Mono 400/500) ship in
  `fonts/`. No `[FONT_MISSING]`. If a new weight is used in src, add it there too.
- The render-check gate does NOT pass clean because of the rnw `rootEmpty` quirk above — the
  upload was made on the strength of the **visual** contact-sheet review, not a green validate.
  Re-runs will show the same warns; treat them as known unless the contact sheet regresses.
- **Bash cwd persists across tool calls.** A `cd ds-bundle` earlier in the session makes
  `finalize_plan`'s `localDir: "./ds-bundle"` resolve to `ds-bundle/ds-bundle` and fail with
  ENOENT. Pass the absolute path, or `cd` back to the repo root first.
- **The design project holds files this build does not produce** and must never be swept:
  `templates/` (the .dc.html composites + shared icons), `design_handoff_desktop_composites/`
  (the eight BATCH specs — the project is now the surviving copy; the local zip was deleted),
  `github.md`, plus the app-generated `_ds_manifest.json` / `_adherence.oxlintrc.json`.
  Always upload with `deletes: []` unless `.sync-diff.json` names real `deletePaths`.
- `dtsPropsFor` is hand-maintained — if a component's real props change in src, update it here.
- Bumping react-native-web may change the runtime style output; re-check the contact sheet.

## Custom build scripts (committed, must be restaged for re-sync)
The off-script bundler lives in `.design-sync/build/` (committed): `rnw-entry.tsx`
(the 12-component barrel) and `rnw-dist.mjs` (the react-native-web esbuild). `.ds-sync/`
is gitignored, so before a re-sync copy them back: `cp .design-sync/build/* .ds-sync/`
(and `cd .ds-sync && npm i esbuild ts-morph @types/react playwright@1.55.0` per the
staging step). `cfg.buildCmd` = `node .ds-sync/rnw-dist.mjs`.

## Expected components (previously missing from the published design system)
Per the componentisation handoff's "After all four batches" step, these were
**expected additions that were missing** from the published Suntech Sales UI
project and are now included in the widened sync — treat them as expected, never
as anomalies/removals on a re-sync:
- `src/components/desktop/*.web.tsx` → DesktopFrame, TopBar, LeadTable, SettingCard,
  AccordionRail (bundled from the `.web.tsx`; resolveExtensions picks `.web` first).
- `src/components/ui/date-field.tsx` → DateField (needs the datetimepicker stub in
  rnw-dist.mjs to bundle).
- `src/components/ui/multi-select-sheet.tsx` → MultiSelectSheet.
Barrel = `.ds-sync/rnw-entry.tsx` (33 components); componentSrcMap in config.json
pins each. If any of these are absent from a future build, it's a regression to fix,
not an expected drop.

## 2026-08-11 re-sync findings

- **`MultiSelectSheet` → `MultiSelectDropdown`.** Renamed in `cec2a73` (5 Aug), i.e. AFTER the
  2026-08-03 sync, so the design project was advertising a component the app no longer had —
  the design agent would have emitted imports that don't resolve. It surfaced as a hard build
  failure (`Could not resolve "@/components/ui/multi-select-sheet"`), not a warning.
  **Lesson: `.design-sync/pipeline/rnw-entry.tsx` is hand-maintained and does NOT track
  renames.** When a synced component is renamed or removed in src, update the entry,
  `cfg.componentSrcMap` and `cfg.dtsPropsFor` together, or the next sync won't build.
- **`guidelinesGlob` is now `[]`, deliberately.** The default glob includes `docs/*.md`, and a
  `docs/` folder was added to this repo on 10 Aug (backend aggregation + tenancy-migration
  docs). Those were being swept into `guidelines/` and shipped to the design agent, which
  reads them while building UI — irrelevant context that only crowds it out. If real *design*
  guidelines are ever written, point the glob at them specifically rather than reverting.
- **The off-script pipeline is now committed at `.design-sync/pipeline/`** (`rnw-entry.tsx`,
  `rnw-dist.mjs`, `require-shim.js`). `.ds-sync/` is gitignored staging, so before this those
  three files existed ONLY on one machine — a fresh clone could not have run the sync at all.
  **Fresh-clone setup: copy `.design-sync/pipeline/*` into `.ds-sync/` before the first build**
  (alongside the skill's own `cp -r` of the converter scripts). `cfg.buildCmd` still points at
  `.ds-sync/rnw-dist.mjs`; the pipeline copy is the durable source of truth for those files.
- Uncommitted `hitSlop` / `Spacing.three` edits to AccountRow and ChipSelect produced NO diff —
  neither changes rendered output, so render hashes were identical and the driver classified
  both `unchanged`. Deterministic output behaving correctly; not a missed change.

## 2026-08-11 re-sync #2 (Accordion in, StageBarRow out)

- **Added `Accordion` + `AccordionChevron`** (`src/components/ui/accordion.tsx`), the disclosure
  primitive extracted from `movement.tsx`'s `RepGroup` and `collections-view.tsx`'s `CustomerRow`.
  Barrel + `componentSrcMap` + `dtsPropsFor` + an authored preview all landed together, per the
  rename lesson above. `AccordionChevron` is exported deliberately even though it's a 16px icon:
  authoring an `Accordion` header requires it, since `header` is a render prop.
- **Removed `StageBarRow`.** The charts work replaced it with `StageChart` and nothing in `src/`
  imported it any more, so the design system was advertising a component the app no longer
  renders — the orphan counterpart of the MultiSelectSheet rename. Its 4 remote files were
  deleted via the diff's `deletePaths`; the 2 `_preview/StageBarRow.*` entries didn't exist
  remotely (floor-card component, no authored preview) and the not-found rejection is expected.
  NOTE: `design_handoff_desktop_composites/src/components/ui/stage-bar-row.tsx` still exists in
  the project — that's a handoff artifact in the never-sweep set, not a DS component. Leave it.
- **The palette re-step changed NOTHING in the design system.** All six stage hues in
  `constants/leads.ts` were replaced this day (CVD/contrast fix), yet 36 of 39 components came
  back `unchanged`. Reason: the DS components take colour as *props* (`Badge` takes `color`/`ink`,
  `ProgressBar` takes `color`); the palette lives in the app, not in the components. Useful
  property to know — app-wide colour work does not force a DS re-verification.
- **Only real `changed` was `LeadTablePresentation`**, because its `dtsPropsFor` gained
  `isOverdue`/`isIdle` (the stage-authority fix moved those predicates onto `useStages()`).
  Its preview now visibly exercises them — the sheet shows "4 days overdue" and "— · idle".
  A `.d.ts`-only edit still counts as `changed` and clears the grade; that's correct, the
  contract the design agent codes against moved.
- **Known render warns updated: 24 `bad`, 7 `thin`, 7 `variantsIdentical` out of 39** (was
  22/4/4 of 38). The deltas are all accounted for: `Accordion` joins the `rootEmpty` false
  positives (39KB PNG, maxHeight 166 — it renders correctly, see contact sheet 1), and
  `AccordionChevron` is legitimately `blank` at 4.7KB/16px because it IS a 16px chevron.
  `thin`/`variantsIdentical` picked up AccountRow, CollectionTaskCard, InvoiceRow and
  SwipeableLead — all unauthored floor-card components, not regressions.
- `validate` still exits 1 (the rnw `rootEmpty` quirk), so the driver skipped `capture` with
  `"skipped": "prior_failure"` and reported `pendingGrade: []` — **that empty list is not a
  green light on this repo**. Run `package-capture.mjs --components <changed+added>` by hand
  afterwards, or new components ship ungraded. Worth knowing before trusting a future verdict.

## 2026-08-12 re-sync (post monorepo-split repair)

- **The split broke the sync in three ways, not one.** `componentSrcMap` had 10 pre-split
  `src/components/**` paths; `.ds-sync/rnw-entry.tsx` imported everything through `@/…`, whose
  root `tsconfig.json` the split DELETED (hard build failure, not a silent partial); and
  `rnw-dist.mjs` named that same dead tsconfig. Entry now imports `@sales/ui` plus relative
  `../apps/web/src/components/…`; `tsconfig` points at `apps/web/tsconfig.json`. `@/` is now
  used nowhere in the repo, so the alias dependency is gone rather than repointed.
- **`NavSidebarPresentation` was genuinely broken, not a `rootEmpty` false positive.**
  `firstErr: "Cannot read properties of undefined (reading 'trim')"`, `maxHeight: 0`. The
  component declared `searchQuery: string` required and read `searchQuery.trim()` unguarded,
  while `dtsPropsFor` omitted the prop entirely — so the published contract told the design
  agent to write exactly the call that crashes. Fixed at the source: search is now an optional
  capability (`searchQuery = ''`, `onSearchChange?`, `onClose?`) and `dtsPropsFor` declares all
  three. After: `firstErr: null`, `maxHeight: 560`, rail renders fully in both variants.
  **Lesson: a `rootEmpty` warn is only a false positive when the card VISIBLY renders. Check
  `firstErr` and `maxHeight` before filing one under the known-warns list.**
- Known warns now **21 bad / 3 thin / 4 variantsIdentical of 39** (was 24/7/7) — the split
  repair improved the render check; the deltas are NavSidebarPresentation plus the components
  whose previews now mount cleanly.
- The re-sync ran WITHOUT the remote `sourceHashes` (the saved anchor was partial), so the
  driver reported full scope. `remote-diff.mjs` falls back to `deletePaths: []` in that case —
  safe, never destructive. The real changed-set was recovered by diffing local vs remote
  `renderHashes` by hand: 16 changed, 0 added, 0 removed.

## 2026-08-13 re-sync (bundle-only, plus the InvoiceTable blank card)

- **The driver does NOT run `cfg.buildCmd`.** It chains build → diff → validate → capture,
  where "build" is `package-build.mjs` — the rnw esbuild step is NOT part of it. Run
  `node .ds-sync/rnw-dist.mjs` FIRST or the converter bundles a stale
  `.ds-sync/dist/index.mjs` and you sync a design system that predates every commit since the
  last run. Caught this run only because the driver was started before the rebuild; nothing
  was uploaded from the stale dist. Sanity check after the rnw build: it prints
  `exports: 39` — that number must match the anchor's component count.
- **All 39 came back `unchanged`; the upload was bundle + styling only.** `upload.bundle` and
  `upload.styling` were true while `upload.components` was empty — a legitimate and cheap
  outcome. Do not read "0 changed components" as "nothing to upload": scope uploads by
  `upload.*`, never by the verification partition.
- **`InvoiceTable` was shipping a genuinely BLANK card — now fixed by authoring its preview.**
  It is the connected wrapper (`InvoiceTable({ invoices })`, resolves row-press via
  `useRouter()` itself); `InvoiceTablePresentation` is the sibling that takes `onPressRow`.
  With no authored preview the `.d.ts` crash-prevention props left `invoices` undefined and the
  component crashed mapping over it — `firstErr: "Cannot read properties of undefined (reading
  'map')"`, `maxHeight: 0`, an EMPTY card rather than the honest floor card.
  It was NOT in the Known render warns list, which is exactly the signal the
  NavSidebarPresentation lesson describes: check `firstErr` and `maxHeight` before filing a
  `bad` under the known quirk. Authored `.design-sync/previews/InvoiceTable.tsx` with the same
  four invoices as the Presentation preview (deliberately identical — the two cards sit next to
  each other in the pane and differing rows would imply a behavioural difference that does not
  exist). After: `firstErr: null`, `maxHeight: 292`, 36KB PNG, both cells graded good.
  **`useRouter()` does NOT throw outside a router context** — worth knowing before assuming a
  connected component can't be previewed.
- **Known render warns updated: 20 `bad`, 1 `thin`, 1 `variantsIdentical` of 39** (was
  21/3/4). `InvoiceTable` now belongs to the `rootEmpty` false-positive class (it renders
  visibly); the thin/identical drops are the same fix.
- The anchor fetched this run was COMPLETE (`sourceHashes` present), unlike 2026-08-12's
  partial one, so `deletePaths` was computed properly and came back `[]` — correct, nothing
  was removed.

## Design mock drift — the desktop nav rail (2026-08-13)

> **PARTLY SUPERSEDED (2026-08-16) for `desktop/` only** — see "The permanent
> sidebar is back, above 1280px" below. The ruling below still stands verbatim for
> `apps/web`, which is the build it was actually made about.

The mocks in the **`Sales` project** (`619b755c-…`, a PROJECT_TYPE_PROJECT, NOT the
design-system project) render a permanent 236px `AppSidebar` on every desktop screen.
**The app no longer works that way** — the rail is behind a hamburger. Confirmed with
the user: the app is correct and the mock is out of date. Do NOT "fix" the app to
restore a persistent rail, and do not file its absence as an implementation gap.

Also worth knowing for any future port from these mocks:

- The mocks live in the **`Sales` project**, not in `Suntech Sales UI`. `list_projects`
  only returns design-SYSTEM projects, so the mocks project is invisible to it — I
  concluded "there is no workflows mock" from that and was wrong. Go to
  `619b755c-7ddd-4f6d-9a27-3ad71544c1b0`.
- **`Web - Sales CRM.dc.html` (18 screens) is DEAD — do not port from it.** See the
  2026-08-14 correction below; it survives only inside
  `design_handoff_suntech_redesign/`, which is an archive.
- `Suntech Sales UI`'s own `templates/` are an OLDER, per-area split of the same
  material: 11 screens, missing the 4 Import and 3 Workflows screens. Treat them as
  stale; the `Sales` project is the live copy.
- Do NOT compare data VALUES between mock and app (lead counts, dates, names). The
  mock's figures are fixtures. Compare layout, hierarchy, spacing, states — not numbers.

## Rendering the mocks locally (reusable)

`.design-sync/.cache/render/` holds a working harness — `shoot.mjs` screenshots every
`[data-shot]` screen in the composite, `shoot-app.mjs` screenshots the running dev app
for side-by-side. Two things that make it work:

- `support.js` (the dc-runtime) needs `window.React`/`window.ReactDOM`; the design-sync
  bundle's `_vendor/react.js` supplies both, so copy it in rather than fetching React.
- The mock's `<ion-icon>` fetches ~56 SVGs from the project. Instead, define `ion-icon`
  in the page HEAD **before** the mock's own script (its first line bails if the element
  is already registered) and render the glyph from the repo's own
  `@expo/vector-icons` `Ionicons.ttf` + `Ionicons.json`. No per-icon fetches.
- Screenshot the app with `EXPO_PUBLIC_DEMO=true`: the auth gate loads DEMO_USER and
  never shows sign-in, so no credentials are needed. `expo start --web --port <n>` must
  be given an explicit free port — it cannot prompt in a non-interactive shell.

## templates/ refreshed to mirror the Sales project (2026-08-14)

The stale 11-screen per-area split is gone. `templates/` now holds the four
current mocks flat, mirroring the `Sales` project (`619b755c-…`) where they are
authored: `Web - Sales CRM.dc.html` (18 screens), `Mobile - Sales.dc.html`,
`Foundations.dc.html`, `AppSidebar.dc.html`, plus `support.js`. Deleted:
`web-sales/`, `web-admin/`, `web-payments/`, `app-sidebar/`, `foundations/`,
`mobile-sales/` (22 files, including their `.thumbnail`s — those regenerate).

**One deliberate deviation from a literal mirror.** The Sales project keeps its
icons beside each file at `assets/icons/`; this project keeps them at
`templates/_shared/icons/`. Rather than duplicate 79 SVGs into a second
location, the uploaded files have their icon BASE repointed to `_shared/icons/`
and the sidebar logo to `_shared/icon.png`. **If you re-upload these files from
the Sales project, redo that substitution** or every icon renders empty:

    'assets/icons/'      -> '_shared/icons/'
    '../_shared/icons/'  -> '_shared/icons/'
    src="assets/icon.png" -> src="_shared/icon.png"

Eleven icons the newer screens (Workflows, Import) need were missing here and
were copied across: add-circle-outline, attach-outline, checkmark-circle,
cloud-upload-outline, flag, git-network-outline, information-circle-outline,
remove-circle-outline, reorder-two-outline, save-outline, trash-outline.

`templates/` is still NOT managed by /design-sync — it stays in the never-sweep
set, and this refresh was a manual DesignSync write. The `Sales` project remains
the authoring home; this is a copy for browsing beside the components.

## The mock set moved — 32 frames across six files (2026-08-14)

**Read this before any design port.** The single `Web - Sales CRM.dc.html`
composite (18 screens) that earlier notes point at has been SPLIT. It now
survives only inside `design_handoff_suntech_redesign/`, which is an archive
folder — along with a README that documents an even older 12-screen set. A whole
design port was done from that stale composite before anyone noticed, and it
covered barely half the real set.

**Always start from `design_handoff_suntech_redesign/screenshots/capture.md`**,
which carries the authoritative file→frame table, and then cross-check it
against `list_files` — `Web - Work.dc.html` postdates even capture.md and is
absent from its table.

Live web composites and their frames:

| File | Frames |
| --- | --- |
| `Web - Sales.dc.html` | 01 sign-in · 02 dashboard · 03 leads table · 04 board · 05 lead detail · 06 new lead |
| `Web - Money.dc.html` | 07 payments · 08 collection tasks · 09 accounts · 19 quotes · 20 quote builder · 21 proposal modules · 22 AMCs |
| `Web - Import - Workflows.dc.html` | 12–15 CSV import · 16–18 workflows |
| `Web - Admin.dc.html` | 10 admin hub · 11 pipeline stages · 23 team |
| `Web - Admin Rules.dc.html` | 24 routing · 25 sources & custom fields · 26 reminder rules |
| `Web - Work.dc.html` | 27 reminders · 28 approvals · 29 activity feed · 30 scorecard · 31 sales targets · 32 movement report |

Every frame carries `data-shot="web-NN-slug"` and `data-screen-label`, so the
frame list of any file is one grep away — do that rather than trusting a note.

The `.dc.html` files are design REFERENCES, not code: static HTML, inline
styles, no state. Recreate in React Native + Expo Router against the existing
`packages/ui` primitives; never port the markup.

## The permanent sidebar is back, above 1280px (2026-08-16)

Scope: **`desktop/` only.** The 2026-08-13 ruling above — "the mock's permanent 236px
sidebar is stale, the app's 68px rail is correct" — was made about `apps/web`, a
react-native-web build that also has to lay out on a phone, where a permanent 236px
sidebar genuinely does not fit. It still holds there. `desktop/` is the purpose-built
laptop app with no phone to serve, and the user has since ruled that it should show
the mock's sidebar wherever there is room for it.

So `desktop/src/chrome/nav-sidebar.tsx` now has two states:

- **>= 1280px** — the permanent 236px sidebar, i.e. the `AppSidebar.md` frame as drawn.
- **< 1280px** — the existing 68px rail plus its 304px drawer, unchanged.

The four spec regions (brand -> search -> groups -> footer) are one component shared by
both, so this was a container change, not a rebuild.

**1280 is a product decision, not a derivation.** It is the smallest common laptop
width, which is the point: 1366, 1440 and the 14" MacBook Pro's 1512 all clear it, so
the sidebar appears on the machines people actually use. Above it the content region
is 1280 - 236 - 56 = 988px, more than the 932px this app already shipped to a 1024px
laptop.

**Do not confuse it with the board's floor, which is 1260 and is a different fact.**
Six default stage tracks at `lead-board.module.css`'s declared `min-width: 200px` with
12px gaps = 6x200 + 5x12 = 1260px, the width at which the default pipeline stops
scrolling horizontally. That number is worth keeping — anyone changing track widths or
the default stage set wants it — but the CHROME deliberately does not wait for it.
Making it do so meant a breakpoint of 236 + 28 + 1260 + 28 = **1552**, which was the
first cut and was rejected: 1552 is above every common laptop, so the sidebar would
have shown only on external monitors and the feature would have been close to dead.
Horizontal scroll on a kanban board is ordinary (Trello, Jira, Linear), and the
board's `overflow-x` was written as a release valve precisely so it could. At 1280 the
board gets 988px and scrolls ~272px; `desktop/e2e/layout.spec.ts` scrolls it to the end
and asserts the last stage track is fully reachable rather than clipped, because that
is the risk the decision accepted.

`layout.spec.ts` asserts the two numbers **separately** — 1280 as a literal in
"the nav breakpoint", 1260 measured off the rendered board in "the pipeline board
floor" — so neither drags the other when it moves.

# Foundations — desktop type scale, geometry, elevation

Distilled from `Foundations.dc.html` in the Sales design project
(`619b755c-7ddd-4f6d-9a27-3ad71544c1b0`), fetched 2026-08-15. Reference only —
never port the markup, and never copy the hex: every colour below already exists
as a token in `packages/core/src/constants/theme-tokens.ts` and reaches the DOM
as an `--app-*` custom property.

## ⚠️ This scale is NEW — apps/web is not the authority here

The mock says plainly: *"The desktop scale on the left is new, since the app has
no desktop shell today."*

That matters, because the desktop shell was built from `apps/web`'s `TopBar` /
`DesktopFrame` values while this file was unavailable. Those values were invented
before this scale existed. **Where they differ, this file wins** — unlike the nav
rail, where NOTES records a deliberate ruling that the app is right and the mock
is stale. There is no such ruling here.

### Known deviations to reconcile

| Element | Built as | Spec says |
|---|---|---|
| Top bar title | `22px` — **WRONG, revert to 18** | **`18px / 700 / 1.2 / -0.015em`** (`topBar`) |
| Top bar meta | `12px` | **`13px / 400 / 1.45`** (`small`), or `11px / 700 / .07em uppercase` if it reads as a label |

> **The 22px top bar came from THIS FILE.** An earlier snapshot had no `topBar`
> role, so the closest match (`title` 22) was used. Design has since added
> `topBar / 18·700`. Reverting also restores `height` in place of the
> `min-height` that the 22px title forced on `top-bar.module.css` — see its
> comment. Measured: 18px appears **49×** as a page title across the 8
> `Desktop - *` frames; 22px appears **3×**, on detail pages.

## Web · desktop shell type scale

| Role | Spec |
|---|---|
| `display` | 700 · 32px · lh 1.15 · `-0.02em` — page-level heading ("Team pipeline") |
| `title` | 700 · 22px · lh 1.25 · `-0.015em` — record/screen title ("Priya Shah"). Detail pages only, 3 uses. |
| `topBar` | 700 · 18px · lh 1.2 · `-0.015em` — **the page title in the top bar. 49 uses. This is the common one.** |
| `section` | 600 · 15px · lh 1.3 — section heading ("Pipeline by stage") |
| `body` | 400 · 14px · lh 1.5 — prose |
| `small` | 400 · 13px · lh 1.45 — secondary/meta ("Updated 2 hours ago · Liam Nguyen") |
| `micro` | **700** · 11px · lh 1.3 · `.07em` · UPPERCASE — label above a value ("Weighted forecast") |
| `numeric` | 500 · 20px · **monospace** · `font-variant-numeric: tabular-nums` |

**Numbers are monospace with tabular figures.** This is not decoration: it is what
makes a column of currency line up on the decimal. Any money or count in a table,
a stat tile or a KPI takes the numeric treatment. Use the `--font-*` variables,
not family names.

The native (`ThemedText`) scale is deliberately unchanged — title **44**·600/52,
subtitle 32·600/44, default 16·500/24, smallBold 14·700/20, small 14·500/20,
code 12·mono. Only the family changed there. Don't apply the desktop scale to
`packages/ui`.

## Geometry — radius

| Radius | Applies to |
|---|---|
| `7px` | **control** — button, text field, small icon button |
| `10px` | **card · web** — cards, tiles, panels on desktop |
| `16px` | **card · native** — `packages/ui` only, do NOT use on desktop |
| `999px` | chip / pill / badge / avatar |

The primitives section's `16px` for `button` / `text-field` / `card.tsx` is the
**native** set (`components/ui/` → `packages/ui`). It is not a contradiction:
desktop buttons measure **7px** in the `Desktop - *` frames. Use the geometry
scale above on desktop and keep `packages/ui`'s existing 16px
where it already ships — do not "fix" native to match.

## Elevation

Three levels only:

| Level | Shadow |
|---|---|
| flat | none, 1px border |
| card | `0 1px 2px rgb(23 26 22 / .04), 0 8px 24px -12px rgb(23 26 22 / .10)` |
| overlay | `0 2px 4px rgb(23 26 22 / .05), 0 18px 40px -16px rgb(23 26 22 / .24)` |

Dark mode uses the same geometry with black-based alpha
(`rgb(0 0 0 / .3)` / `rgb(0 0 0 / .5)` on the card level). Elevation has no token
today — if these get used in more than one place, add them as tokens rather than
repeating the literals.

## Spacing

`4 · 8 · 16 · 24 · 32` — explicitly **unchanged** from the existing `Spacing`
scale. Use it; don't invent intermediate values.

## Colour — all of it already tokenised

The palette section maps 1:1 onto `Colors.light` / `Colors.dark`, which is where
`theme-tokens.ts` already gets its values. Nothing to do; listed only so you can
recognise a literal in the mock:

background · surface · backgroundElement · backgroundSelected · border · text ·
textSecondary · **textTertiary** · primary · success · successLarge · warning · danger

**`textTertiary` is NEW** (added by design 2026-08-18): light `#8A9187`, dark
`#6E746A`, for "quiet icons, meta, disabled labels". It is the token for the
quiet dialog/panel close icon that previously had none — use it instead of a
literal. It needs adding to `theme-tokens.ts`; it is not there yet.

Two worth knowing: **`successLarge` is for numerals ≥19px only** (the smaller
`success` carries the 4.6:1 contrast for text), and stage/invoice colours each
ship a four-part set — `color` (dot), `ink` (label text), `tint` (fill), `line`
(border). Those live in `constants/leads.ts` and `constants/payments.ts` and are
the only other places raw hex is allowed.

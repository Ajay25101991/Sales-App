# Design specs — the source every desktop port works from

`live-mocks/` holds all six current `.dc.html` composites, fetched 2026-08-15/16 from
the **Sales** design project (`619b755c-7ddd-4f6d-9a27-3ad71544c1b0`). They are
committed deliberately: **subagents cannot fetch them.** `DesignSync` is not in a
subagent's tool set, so without these on disk every port either works blind or waits
on the coordinator to fetch. They lived untracked in one working tree until now,
which meant a single `git clean` would have destroyed the spec source for the whole
remaining migration.

## The 44 frames, by file

| File | Frames |
| --- | --- |
| `Web - Sales.dc.html` | `web-01-signin` `web-02-dashboard` `web-03-leads-list` `web-03b-leads-loading` `web-04-leads-board` `web-05-lead-detail` `web-06-new-lead` `web-36-lead-dates` `web-37-lead-dates-aging` |
| `Web - Money.dc.html` | `web-07-payments` `web-08-collection-tasks` `web-09-accounts` `web-19-quotes` `web-20-quote-builder` `web-21-proposal-modules` `web-22-amcs` |
| `Web - Work.dc.html` | `web-27-reminders` `web-28-approvals` `web-29-activity` `web-30-scorecard` `web-35-md-pack` `web-31-targets` `web-32-movement` `web-33-login-activity` `web-34-signup` |
| `Web - Admin.dc.html` | `web-10-admin-hub` `web-11-admin-stages` `web-23-team` |
| `Web - Admin Rules.dc.html` | `web-24-routing` `web-25-sources-fields` `web-26-reminders` |
| `Web - Dialogs.dc.html` | `web-38-confirm` `web-39-confirm-bulk` `web-40-reason` `web-41-choice` `web-42-status` `web-43-dialog-anatomy` |
| `Web - Import - Workflows.dc.html` | `web-12-import-upload` `web-13-import-mapping` `web-14-import-review` `web-15-import-result` `web-16-workflows-library` `web-17-workflow-builder` `web-18-workflow-publish` |

**Grep `data-shot=` rather than trusting this table.** It has been wrong before: the
project notes advertised 32 frames and omitted `web-03b`, `web-33` and `web-34`, and
called one frame `web-29-activity-feed` when the file says `web-29-activity`. The
file is the authority; this table is a convenience.

**44 frames for 67 routes.** Most routes have no design — `/invoice/:id`,
`/leaderboard`, `/needs-you-today`, `/profile` and nearly every config screen included.
A screen built without a frame should say so in its own doc comment, as
`desktop/src/screens/account-detail.tsx` does, so nobody later mistakes a derivation
for approved design.

## Two traps that have each cost real time

**1. The dead composite is still on disk and looks identical.**
`.design-sync/.cache/` holds a superseded 18-screen set — both `.dc.html` files and
*renders* of them under `render/`. The renders carry **the same `data-shot` ids as the
live mocks**, so a grep for `web-09-accounts` finds a convincing hit in a stale file
with nothing in the markup to say it is out of date. A whole design port was done from
that set before anyone noticed.

Discriminator: **the dead set has no frame numbered above 18.** Anything quarantined as
`DEAD-*`, `STALE-*`, or living under `.cache/render/` is poison. Use only `live-mocks/`.

**2. The mock draws its own device chrome.**
Every `18px` radius in these files, with its `0 24px 60px -24px` shadow, sits on a
`data-shot` wrapper — the fake browser window the mock paints around each screen. **Zero
are product UI.** Exclude `data-shot` elements before reading any geometry, or you ship
an 18px card and a 60px-blur shadow that exist nowhere in the product.

## How to use them

These are references: static HTML, inline styles, no state. **Never port the markup.**
Recreate in React against `@sales/ui-web`. Compare layout, hierarchy, spacing and
states — **never data values.** Every name, amount and date in them is a fixture.

Colours must resolve through the generated `--app-*` custom properties; raw hex is
allowed only in `packages/core/src/constants/{theme-tokens,leads,payments}.ts`.

`AppSidebar.md` and `Foundations.md` are distilled specs, not raw mocks — dimensions,
type scale, elevation and state treatments with every colour named as its token.
`Foundations.md` records where the foundations scale and the screen frames disagree,
and which wins.

## Refreshing

Only the main session can fetch (`DesignSync` → `get_file`). Large results persist to a
file rather than the transcript; extract `.content` from that JSON and write it here.
Re-fetch when the design project changes — and re-grep `data-shot` afterwards, because
the frame list is exactly the thing that drifts.

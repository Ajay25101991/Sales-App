# Nav sidebar — design spec

Distilled from `AppSidebar.dc.html` in the Sales design project
(`619b755c-7ddd-4f6d-9a27-3ad71544c1b0`), fetched 2026-08-15. The mock is a
static reference: **never port its markup, and never copy its hex.** Every colour
below is given as the token you must use; the hex is shown only so you can
recognise it in the mock.

## ⚠️ Known mock drift — read before you "fix" anything

`.design-sync/NOTES.md` § "Design mock drift — the desktop nav rail (2026-08-13)"
records that **this mock is out of date and the app is correct** in places. Where
this spec and the shipped app disagree on *which nav items exist*, the app wins —
the mock's item list below is illustrative of structure, not an authority on
content. Take **layout, spacing, hierarchy and states** from here; take the
**actual nav items and their routes** from the app's existing sidebar and the
permission model.

## Frame

Fixed left rail. `width: 236px`, full height, `flex: none`, column flex,
`border-right: 1px solid` in the border token. Background is the app background
token (mock: `#F9FAF8` light / `#191D17` dark).

Four stacked regions, top to bottom: **brand → search → nav groups (scrolls) →
user footer**.

## 1. Brand header

`padding: 20px 18px 16px`, row, `align-items: center`, `gap: 11px`.

- App icon: 34×34, `border-radius: 11px`, `object-fit: cover`, `flex: none`.
- Text column (`flex: 1; min-width: 0`, gap 1px):
  - Product name — 700, 15px, line-height 1.2, `letter-spacing: -.01em`, text token.
  - Org label — 500, 11px, line-height 1.2, dim token.
- Trailing `chevron-expand` icon, 15px, dim token.

`min-width: 0` on the text column is load-bearing — without it a long org name
refuses to truncate and pushes the chevron out of the rail.

## 2. Search affordance

`padding: 0 18px 14px`. Inner row: `padding: 8px 10px`, `border-radius: 10px`,
`1px` border in the border token, background = field token (`#FFFFFF` light /
`#262B24` dark), `gap: 8px`.

- `search` icon, 14px, dim.
- Label "Search", 400, 12.5px, dim, `flex: 1`.
- Keyboard hint chip: text `⌘K`, 500, 10px, **monospace**, `padding: 3px 5px`,
  `border-radius: 5px`, background = chip token, dim foreground.

In the mock this is a static div. In the app it should be a real control that
opens search. **Show the `⌘K` hint only if that shortcut is actually wired up** —
a hint for a shortcut that does nothing is a lie to the user. If you don't wire
the shortcut, omit the chip and say so.

## 3. Nav groups

Container: `flex: 1`, `overflow: hidden`, column, `gap: 16px` between groups,
`padding: 0 12px`.

**Group title:** `padding: 4px 10px 6px`, 800 weight, 11px, line-height 1.2,
`letter-spacing: .1em`, `text-transform: uppercase`, **text token** (note: full
strength, not dim — the titles are darker than the inactive items beneath them).

**Group items:** column, `gap: 2px`.

**Item row:** `display: flex; align-items: center; gap: 10px; padding: 8px 10px;
border-radius: 10px`.

- Leading icon, 17px, colour follows item state.
- Label, `flex: 1`, 13px, line-height 1.2 — **500 when inactive, 600 when
  active**.
- Optional trailing count badge (see below).

**Item states** — the whole row is tinted, not just the text:

| State | Background | Icon + label |
|---|---|---|
| inactive | transparent | dim token (`#5F6660` / `#A2A89F`) |
| active | active-fill (`#EDF2EB` / `#2A3A27`) | active-ink (`#3C5638` / `#9CC194`) |

If no active-fill token pair exists yet, add one to
`packages/core/src/constants/theme-tokens.ts` (the only place raw hex is allowed)
and let the CSS custom property be generated — do **not** inline the hex.

**Count badge:** `min-width: 18px`, centred, `padding: 2px 6px`,
`border-radius: 999px`, 700, 10px, line-height 1.4, **monospace**. Two tones:

| Tone | Background | Foreground |
|---|---|---|
| neutral | `#E3E7E1` / `#33382F` | `#666C64` / `#949A92` |
| danger | `#F7E9E6` / `#38241F` | `#A9483C` / `#E08A80` |

The danger tone marks counts that represent something owed or overdue. **Badge
counts must come from the backend.** If a nav item has no count endpoint, render
no badge — never a placeholder or a zero standing in for "unknown".

### Group structure in the mock (structure only — verify items against the app)

The mock varies groups by role, which is the important behaviour to reproduce:

- **collector**: `Collections` (Payments, My tasks ⚠, Accounts, AMCs) ·
  `Personal` (Reminders, Activity, Profile)
- **rep**: `Sell` (Dashboard, Leads, Accounts, Quotes) · `Money` (Payments ⚠,
  AMCs) · `Work` (Reminders, Approvals, Activity, Reports)
- **manager / admin**: as rep, plus `Manage` (Team, Admin), and Approvals gains a
  count.

Drive this from the **permission model** (`managerAccess` etc.), not from a role
string equality check — the app replaced `isManager` role tests with permission
checks deliberately.

## 4. User footer

`padding: 12px`, `border-top: 1px solid` border token.

Inner row: `padding: 8px 10px`, `border-radius: 12px`, `gap: 10px`.

- Avatar: 30×30, `border-radius: 999px`, `flex: none`, centred initials at 700,
  11px, **primary token background with white text**.
- Text column (`flex: 1; min-width: 0`, gap 1px):
  - Name — 600, 12.5px, line-height 1.2, text token.
  - Role — 500, 10.5px, line-height 1.2, `text-transform: capitalize`, dim token.
- Trailing `ellipsis-horizontal`, 15px, dim.

Name, initials and role come from the authenticated profile. The mock's people
(Maya Patel / Liam Nguyen / Raj Kumar) are **fixtures — never ship them.**

## Typography

The mock uses `Plus Jakarta Sans` for all UI text and `JetBrains Mono` for the
`⌘K` hint and the count badges. Use the app's existing font variables
(`--font-*`, declared in `packages/core/src/global.css`) rather than naming
families directly.

## Icons

Ionicons names, resolved through `@sales/ui-web`'s `Icon` (which is keyed by
Ionicons names): `chevron-expand`, `search`, `stats-chart-outline`,
`people-outline`, `business-outline`, `document-text-outline`, `card-outline`,
`shield-checkmark-outline`, `notifications-outline`, `checkmark-done-outline`,
`pulse-outline`, `bar-chart-outline`, `people-circle-outline`,
`settings-outline`, `checkbox-outline`, `person-circle-outline`,
`ellipsis-horizontal`. If one is missing from the `Icon` set, add it there.

# Suntech Sales UI — how to build with these components

These are the Suntech Sales CRM's own UI primitives. They are **React Native**
components rendered on the web via react-native-web, exposed on
`window.SuntechUI`. Compose designs from them; don't hand-write lookalikes.

## Styling idiom — props, not CSS classes
There is **no utility-class system and no stylesheet to import**. Components
carry the design language themselves and read the theme automatically (moss-green
palette, Plus Jakarta Sans type). You style **through props**, and use plain
`<div>` (with inline fl[ex]/gap styles) only for your own layout glue between
components.

- **Color comes from the component**, not from you: e.g. `Button` `variant`,
  `Badge` `color`+`ink`, `ThemedText` `themeColor`. Don't wrap components in
  colored divs to restyle them.
- Spacing/layout glue: a flex `<div style={{ display:'flex', flexDirection:'column', gap:12 }}>`
  is fine. Don't reach for a CSS framework.

## The components and their key props
- **Button** — `title`, `variant?: 'primary'|'secondary'|'ghost'|'danger'`, `loading?`, `disabled?`, `onPress`. `danger` is a solid red fill.
- **Badge** — a status/priority pill. `label`, `color` (dot+tint), `ink` (darker label text; always pass it for legible small text).
- **Card** — a bordered surface (`backgroundElement`, radius 16). Put `ThemedText` and rows inside.
- **ThemedText** — all text. `type?: 'title'|'subtitle'|'default'|'smallBold'|'small'|'link'|'code'`, `themeColor?` (e.g. `'textSecondary'`, `'primary'`, `'success'`, `'danger'`). Never use a raw `<p>`/`<span>` for DS text.
- **TextField** — `label`, `value`, `onChangeText`, `placeholder`, `error?`, `secureTextEntry?`.
- **ChipSelect** — single-select chips: `label?`, `options: {value,label}[]`, `value`, `onChange`.
- **Segmented** — segmented control: `options: {value,label}[]`, `value`, `onChange` (e.g. List/Board).
- **ListRow** — a settings/nav row: `icon` (Ionicons name), `title`, `subtitle?`, `onPress?`, `first?` (drop the top divider on the first row).
- **SectionHeader** — `title` + optional `actionLabel`/`onAction` ("See all").
- **EmptyState** — `icon`, `title`, `subtitle?`.
- **Fab** — floating action button: `icon?` (default plus), `onPress`, `accessibilityLabel`. Position it in a `position:relative` container.
- **Modal** — `visible`, `onClose`, `title?`, `children`, `dismissable?`.

Icons are **Ionicons** names (e.g. `'people-outline'`, `'card-outline'`, `'add'`).

## Idiomatic snippet
```jsx
const { Card, ThemedText, Badge, Button } = window.SuntechUI;
<div style={{ maxWidth: 360, display: 'flex', flexDirection: 'column', gap: 16 }}>
  <Card>
    <ThemedText type="smallBold">Acme Industries</ThemedText>
    <ThemedText type="small" themeColor="textSecondary">Maya Patel · Qualified</ThemedText>
    <Badge label="Qualified" color="#3E7F86" ink="#2B5C61" />
  </Card>
  <Button title="Create lead" variant="primary" onPress={() => {}} />
</div>
```

The per-component `.d.ts` and `.prompt.md` (with authored examples) are the
detailed reference; read them before composing a component you haven't used.

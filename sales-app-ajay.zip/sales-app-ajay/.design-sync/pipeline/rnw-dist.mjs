import * as esbuild from 'esbuild';
import { mkdirSync } from 'node:fs';
mkdirSync('.ds-sync/dist', { recursive: true });
const stubNode = {
  name: 'stub-node',
  setup(b) {
    b.onResolve({ filter: /^node:/ }, (a) => ({ path: a.path, namespace: 'stub-node' }));
    b.onLoad({ filter: /.*/, namespace: 'stub-node' }, () => ({
      contents: 'export class AsyncLocalStorage { getStore(){} run(_,f){return f();} enterWith(){} }; export default {};',
      loader: 'js',
    }));
  },
};
// @react-native-community/datetimepicker ships Flow-typed source esbuild can't
// parse (and a native date picker has no web rendering anyway). Stub it with a
// null component so DateField bundles; the field's button still renders.
const stubDatePicker = {
  name: 'stub-datetimepicker',
  setup(b) {
    b.onResolve({ filter: /^@react-native-community\/datetimepicker$/ }, (a) => ({
      path: a.path,
      namespace: 'stub-datepicker',
    }));
    b.onLoad({ filter: /.*/, namespace: 'stub-datepicker' }, () => ({
      contents: 'export default function DateTimePicker(){ return null; }',
      loader: 'js',
    }));
  },
};
try {
  const r = await esbuild.build({
    entryPoints: ['.ds-sync/rnw-entry.tsx'],
    bundle: true, format: 'esm', outfile: '.ds-sync/dist/index.mjs',
    external: ['react', 'react-dom', 'react/jsx-runtime', 'react/jsx-dev-runtime'],
    alias: { 'react-native': 'react-native-web' },
    // apps/web's tsconfig, not a root one: the monorepo split deleted the
    // root tsconfig.json this used to name, which broke the build outright.
    // Nothing in the entry uses path aliases any more, but esbuild still wants
    // a real file here.
    tsconfig: 'apps/web/tsconfig.json', jsx: 'automatic',
    resolveExtensions: ['.web.tsx', '.web.ts', '.web.js', '.tsx', '.ts', '.js', '.json'],
    loader: { '.js': 'jsx', '.ttf': 'dataurl', '.otf': 'dataurl', '.woff': 'dataurl', '.woff2': 'dataurl', '.png': 'dataurl', '.jpg': 'dataurl', '.gif': 'dataurl', '.svg': 'dataurl' },
    define: { 'process.env.NODE_ENV': '"production"', '__DEV__': 'false', 'process.env.EXPO_OS': '"web"', global: 'globalThis' },
    plugins: [stubNode, stubDatePicker], metafile: true,
  });
  const out = r.metafile.outputs['.ds-sync/dist/index.mjs'];
  console.log('rnw-dist OK — KB:', Math.round(out.bytes / 1024), 'exports:', out.exports.length);
} catch (e) {
  const msgs = (e.errors || []).map((x) => `${x.text}${x.location ? ` @ ${x.location.file}:${x.location.line}` : ''}`);
  console.error('BUILD FAILED:\n' + (msgs.join('\n') || e.message || String(e)));
  process.exit(1);
}

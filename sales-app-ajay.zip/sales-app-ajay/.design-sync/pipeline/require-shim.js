// Installs a global `require` so esbuild's __require helper (which prefers a
// real global `require` when one exists) can resolve the CJS `require("react")`
// / `require("react-dom")` calls inside react-native-web's internals. Without
// this, those throw "Dynamic require of react is not supported" at runtime.
// Must be imported FIRST in the barrel so it runs before any rnw module evals.
// The widened bundle pulls in expo-router, which reads several `process.env.*`
// keys at module eval (EXPO_BASE_URL, EXPO_ROUTER_IMPORT_MODE, APP_MANIFEST…).
// esbuild's `define` only replaces the specific keys we name; a global process
// shim makes every other lookup return undefined instead of throwing
// "process is not defined".
if (typeof globalThis.process === 'undefined') globalThis.process = { env: {} };

import * as React from 'react';
import * as ReactDOM from 'react-dom';

const map = {
  react: React,
  'react-dom': ReactDOM,
  'react-dom/client': ReactDOM,
  'react/jsx-runtime': React,
};
if (typeof globalThis.require === 'undefined') {
  globalThis.require = (m) => {
    if (m in map) return map[m];
    throw new Error('require() not supported for: ' + m);
  };
}

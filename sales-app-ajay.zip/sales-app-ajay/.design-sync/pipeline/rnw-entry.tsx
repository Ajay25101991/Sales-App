import './require-shim.js'; // must be first — see the file

// Barrel entry for the design-system bundle: the app's UI primitives, compiled
// for the web through react-native-web so claude.ai/design can render them.

// --- ui/ primitives (batch 0) ---
export { Button } from '@sales/ui';
export { Badge } from '@sales/ui';
export { Card } from '@sales/ui';
export { TextField } from '@sales/ui';
export { ChipSelect } from '@sales/ui';
export { Segmented } from '@sales/ui';
export { EmptyState } from '@sales/ui';
export { Fab } from '@sales/ui';
export { ListRow } from '@sales/ui';
export { Modal } from '@sales/ui';
export { SectionHeader } from '@sales/ui';
export { ThemedText } from '@sales/ui';

// --- ui/ primitives added by the componentisation refactor (batches 1–3) ---
export { ProgressBar } from '@sales/ui';
export { ProgressPanel } from '@sales/ui';
export { StatTile } from '@sales/ui';
export { AlertBanner } from '@sales/ui';
export { SwipeableLead } from '@sales/ui';
export { RowMenu } from '@sales/ui';
export { BulkActionBar } from '@sales/ui';
export { BoardColumn } from '@sales/ui';
export { AgingBar } from '@sales/ui';
export { KpiRow } from '@sales/ui';
export { InvoiceRow } from '@sales/ui';
export { CollectionTaskCard } from '@sales/ui';
export { AccountRow } from '@sales/ui';

// --- shared disclosure primitive (extracted 11 Aug from movement/collections) ---
export { Accordion, AccordionChevron } from '@sales/ui';

// StageBarRow was removed from this barrel on 11 Aug: the charts work replaced
// it with StageChart and nothing in src/ imports it any more. A design system
// that keeps publishing it invites the design agent to compose screens around a
// component the app no longer renders.

// --- ui/ primitives previously skipped (now widened in) ---
export { DateField } from '@sales/ui';
export { MultiSelectDropdown } from '@sales/ui';

// --- desktop/ shell components (web-only) ---
// After the monorepo split these are plain .tsx under apps/web (the split
// promoted each .web.tsx to .tsx and left the native app a null stub), so
// there is no resolveExtensions trick here any more.
export { DesktopFrame } from '../apps/web/src/components/desktop/desktop-frame';
export { TopBar } from '../apps/web/src/components/desktop/top-bar';
export { LeadTable, LeadTablePresentation } from '../apps/web/src/components/desktop/lead-table';
export { InvoiceTable, InvoiceTablePresentation } from '../apps/web/src/components/desktop/invoice-table';
export { SettingCard } from '../apps/web/src/components/desktop/setting-card';
export { AccordionRail } from '../apps/web/src/components/desktop/accordion-rail';

// --- the desktop left rail (one level above components/desktop/) ---
export { NavSidebar, NavSidebarPresentation } from '../apps/web/src/components/nav-sidebar';

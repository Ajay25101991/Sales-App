import { Fab } from '@sales/ui';
export function AddButton() {
  return (
    <div style={{ position: 'relative', width: 200, height: 140 }}>
      <Fab icon="add" accessibilityLabel="Add lead" onPress={() => {}} />
    </div>
  );
}

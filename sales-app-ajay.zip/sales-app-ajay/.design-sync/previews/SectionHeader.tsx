import { SectionHeader } from '@sales/ui';
export function WithAction() {
  return (
    <div style={{ maxWidth: 380 }}>
      <SectionHeader title="Sales leaderboard" actionLabel="See all" onAction={() => {}} />
    </div>
  );
}
export function Plain() {
  return <div style={{ maxWidth: 380 }}><SectionHeader title="Pipeline by stage" /></div>;
}

import { InvoiceTablePresentation } from '@sales/ui';

const DAY = 86_400_000;
// Offsets from "now": the row shows a due date and an overdue flag derived
// against the current date, so fixed ISO dates would age into nonsense.
const at = (days: number) => new Date(Date.now() + days * DAY).toISOString();

const INVOICES = [
  {
    id: '1', number: 'INV-1042', lead_name: 'Acme Industries', company: 'Acme Industries',
    status: 'partial', amount: 48000, balance: 18000, due_date: at(6), overdue: false,
  },
  {
    id: '2', number: 'INV-1038', lead_name: 'Brightside Logistics', company: 'Brightside Logistics',
    status: 'open', amount: 125000, balance: 125000, due_date: at(-12), overdue: true,
  },
  {
    id: '3', number: 'INV-1031', lead_name: 'Northwind Trading', company: 'Northwind Trading',
    status: 'paid', amount: 9500, balance: 0, due_date: at(-40), overdue: false,
  },
  {
    id: '4', number: 'INV-1029', lead_name: 'Cedar & Co', company: 'Cedar & Co',
    status: 'written_off', amount: 4200, balance: 0, due_date: at(-95), overdue: false,
  },
];

const noop = () => {};

export function Table() {
  return (
    <div style={{ minWidth: 900 }}>
      <InvoiceTablePresentation invoices={INVOICES as never} onPressRow={noop} />
    </div>
  );
}

export function Empty() {
  return (
    <div style={{ minWidth: 900 }}>
      <InvoiceTablePresentation invoices={[]} onPressRow={noop} />
    </div>
  );
}

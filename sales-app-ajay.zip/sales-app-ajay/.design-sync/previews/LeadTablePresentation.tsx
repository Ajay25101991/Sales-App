import { LeadTablePresentation } from '@sales/ui';

// The default open stages + Won/Lost, matching constants/leads.ts. Inlined
// rather than imported so the preview needs no app internals — this component
// exists precisely to render without the app's providers.
const STAGES: Record<string, { label: string; color: string; ink: string }> = {
  new: { label: 'New', color: '#5B7C85', ink: '#3F5A61' },
  contacted: { label: 'Contacted', color: '#7A6A93', ink: '#584A6D' },
  qualified: { label: 'Qualified', color: '#3E7F86', ink: '#2B5C61' },
  proposal: { label: 'Proposal', color: '#B0862F', ink: '#7C5D18' },
  won: { label: 'Won', color: '#5C7F58', ink: '#3D6130' },
  lost: { label: 'Lost', color: '#B3524A', ink: '#8C3B34' },
};
const stageMeta = (status: string) => STAGES[status] ?? STAGES.new;

const DAY = 86_400_000;
// Offsets from "now": the row's follow-up text is derived against the current
// date inside the component, so fixed ISO dates would drift into nonsense
// ("150 days overdue" on every row) as the card ages.
const at = (days: number) => new Date(Date.now() + days * DAY).toISOString();

const LEADS = [
  {
    id: '1', name: 'Maya Patel', company: 'Acme Industries', source: 'Referral',
    status: 'qualified', priority: 'high', estimated_value: 48000,
    owner_name: 'Liam Nguyen', next_follow_up_at: at(3), updated_at: at(-1),
  },
  {
    id: '2', name: 'Noah Johnson', company: 'Brightside Logistics', source: 'Website',
    status: 'proposal', priority: 'medium', estimated_value: 125000,
    owner_name: 'Sofia Rossi', next_follow_up_at: at(-4), updated_at: at(-2),
  },
  {
    id: '3', name: 'Amina Yusuf', company: 'Northwind Trading', source: 'Walk-in',
    status: 'new', priority: 'low', estimated_value: 9500,
    owner_name: 'Liam Nguyen', next_follow_up_at: null, updated_at: at(-30),
  },
  {
    id: '4', name: 'Tom Becker', company: 'Cedar & Co', source: 'Cold call',
    status: 'won', priority: 'medium', estimated_value: 76400,
    owner_name: 'Maya Patel', next_follow_up_at: at(9), updated_at: at(-3),
  },
];

const noop = () => {};

// The real table takes these from `useStages()`, so the open-stage test uses the
// org's configured pipeline. A preview has no query client, so it passes plain
// date predicates — enough to light up the overdue/idle badges in the card.
const isOverdue = (l: { next_follow_up_at: string | null }) =>
  !!l.next_follow_up_at && new Date(l.next_follow_up_at).getTime() < Date.now();
const isIdle = (l: { updated_at: string }, idleDays: number) =>
  new Date(l.updated_at).getTime() < Date.now() - idleDays * 86400000;

export function Table() {
  return (
    <div style={{ minWidth: 900 }}>
      <LeadTablePresentation
        leads={LEADS as never}
        selected={new Set(['2'])}
        onToggle={noop}
        onToggleAll={noop}
        onMore={noop}
        onPressRow={noop}
        idleDays={14}
        stageMeta={stageMeta as never}
        isOverdue={isOverdue as never}
        isIdle={isIdle as never}
      />
    </div>
  );
}

export function Empty() {
  return (
    <div style={{ minWidth: 900 }}>
      <LeadTablePresentation
        leads={[]}
        selected={new Set()}
        onToggle={noop}
        onToggleAll={noop}
        onMore={noop}
        onPressRow={noop}
        idleDays={14}
        stageMeta={stageMeta as never}
        isOverdue={isOverdue as never}
        isIdle={isIdle as never}
      />
    </div>
  );
}

import { EmptyState } from '@sales/ui';
export function NoLeads() {
  return (
    <div style={{ maxWidth: 360 }}>
      <EmptyState icon="people-outline" title="No leads yet" subtitle="Tap + to add your first lead" />
    </div>
  );
}

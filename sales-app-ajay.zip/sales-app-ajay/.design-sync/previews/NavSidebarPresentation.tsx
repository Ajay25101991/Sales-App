import { NavSidebarPresentation } from '@sales/ui';

// The rail's real role-derived groups, mirroring buildGroups() in
// nav-sidebar.web.tsx. Inlined rather than imported so the preview needs no app
// internals — this component exists precisely to render without providers.
const MANAGER_GROUPS = [
  {
    title: 'Sell',
    items: [
      { href: '/', label: 'Dashboard', icon: 'stats-chart-outline' },
      { href: '/leads', label: 'Leads', icon: 'people-outline' },
      { href: '/accounts', label: 'Accounts', icon: 'business-outline' },
      { href: '/proposals-overview', label: 'Quotes', icon: 'document-text-outline' },
    ],
  },
  {
    title: 'Money',
    items: [
      { href: '/collections', label: 'Payments', icon: 'card-outline' },
      { href: '/amcs', label: 'AMCs', icon: 'shield-checkmark-outline' },
    ],
  },
  {
    title: 'Work',
    items: [
      { href: '/reminders', label: 'Reminders', icon: 'notifications-outline', badge: 4, tone: 'danger' },
      { href: '/approvals', label: 'Approvals', icon: 'checkmark-done-outline', badge: 2, tone: 'danger' },
      { href: '/team-activity', label: 'Activity', icon: 'pulse-outline' },
    ],
  },
  {
    title: 'Manage',
    items: [
      { href: '/team', label: 'Team', icon: 'people-circle-outline' },
      { href: '/admin', label: 'Admin', icon: 'settings-outline' },
    ],
  },
];

const COLLECTOR_GROUPS = [
  {
    title: 'Collections',
    items: [
      { href: '/collections?tab=payments', label: 'Payments', icon: 'card-outline', tab: 'payments' },
      {
        href: '/collections?tab=tasks', label: 'My tasks', icon: 'checkbox-outline',
        tab: 'tasks', badge: 7, tone: 'danger',
      },
      { href: '/accounts', label: 'Accounts', icon: 'business-outline' },
      { href: '/amcs', label: 'AMCs', icon: 'shield-checkmark-outline' },
    ],
  },
  {
    title: 'Personal',
    items: [
      { href: '/reminders', label: 'Reminders', icon: 'notifications-outline', badge: 1, tone: 'danger' },
      { href: '/team-activity', label: 'Activity', icon: 'pulse-outline' },
      { href: '/profile', label: 'Profile', icon: 'person-circle-outline' },
    ],
  },
];

const noop = () => {};
// The rail is height:100% — give the card a fixed frame to fill.
const frame = { height: 560, display: 'flex' } as const;

export function Manager() {
  return (
    <div style={frame}>
      <NavSidebarPresentation
        groups={MANAGER_GROUPS as never}
        pathname="/leads"
        user={{ name: 'Maya Patel', role: 'manager', orgLabel: 'Suntech Global', initials: 'MP' }}
        onNavigate={noop}
        onSearch={noop}
        onProfile={noop}
      />
    </div>
  );
}

export function Collector() {
  return (
    <div style={frame}>
      <NavSidebarPresentation
        groups={COLLECTOR_GROUPS as never}
        pathname="/collections"
        currentTab="tasks"
        user={{ name: 'Raj Kumar', role: 'collector', orgLabel: 'Suntech Global', initials: 'RK' }}
        onNavigate={noop}
        onSearch={noop}
        onProfile={noop}
      />
    </div>
  );
}

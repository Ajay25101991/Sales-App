import { Card } from '@sales/ui';
import { ThemedText } from '@sales/ui';
export function LeadCard() {
  return (
    <div style={{ maxWidth: 320 }}>
      <Card>
        <ThemedText type="smallBold">Acme Industries</ThemedText>
        <ThemedText type="small" themeColor="textSecondary">Maya Patel · Qualified</ThemedText>
        <ThemedText type="default">$48,000 estimated value</ThemedText>
      </Card>
    </div>
  );
}

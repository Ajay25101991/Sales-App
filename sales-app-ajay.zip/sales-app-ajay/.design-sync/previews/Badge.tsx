import { Badge } from '@sales/ui';

// The status/priority pairs from constants/leads.ts, per scheme. Badge fills with
// `color + '22'` and labels with `ink`, so a pair is only legible on the ground it
// was chosen for — which is why the table carries a light and a dark pair. These
// cells render each set on the card colour it actually sits on in the app, so the
// contrast is verifiable side by side rather than asserted.
const STATUS = {
  light: [
    { label: 'New', color: '#5B7C85', ink: '#3F5A61' },
    { label: 'Contacted', color: '#7A6A93', ink: '#584A6D' },
    { label: 'Qualified', color: '#3E7F86', ink: '#2B5C61' },
    { label: 'Proposal', color: '#B0862F', ink: '#7C5D18' },
    { label: 'Won', color: '#5C7F58', ink: '#3D6130' },
    { label: 'Lost', color: '#B3524A', ink: '#8C3B34' },
  ],
  dark: [
    { label: 'New', color: '#8FAEB8', ink: '#8FAEB8' },
    { label: 'Contacted', color: '#A99BC2', ink: '#A99BC2' },
    { label: 'Qualified', color: '#7FBAC1', ink: '#7FBAC1' },
    { label: 'Proposal', color: '#D4AC5A', ink: '#D4AC5A' },
    { label: 'Won', color: '#9CC194', ink: '#9CC194' },
    { label: 'Lost', color: '#E08A80', ink: '#E08A80' },
  ],
};

const PRIORITY = {
  light: [
    { label: 'Low', color: '#666C64', ink: '#4E534D' },
    { label: 'Medium', color: '#B0862F', ink: '#7C5D18' },
    { label: 'High', color: '#B3524A', ink: '#8C3B34' },
  ],
  dark: [
    { label: 'Low', color: '#A2A89F', ink: '#A2A89F' },
    { label: 'Medium', color: '#D4AC5A', ink: '#D4AC5A' },
    { label: 'High', color: '#E08A80', ink: '#E08A80' },
  ],
};

// The card colours these badges actually sit on (theme.backgroundElement).
const LIGHT_CARD = '#EEF0EC';
const DARK_CARD = '#262B24';

const row = { display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' } as const;

function Set({ scheme, bg, fg }: { scheme: 'light' | 'dark'; bg: string; fg: string }) {
  const pane = {
    display: 'flex', flexDirection: 'column', gap: 10,
    padding: 14, borderRadius: 16, background: bg, minWidth: 420,
  } as const;
  const caption = {
    fontFamily: 'PlusJakartaSans_600SemiBold', fontSize: 11,
    letterSpacing: 0.7, textTransform: 'uppercase', color: fg,
  } as const;
  return (
    <div style={pane}>
      <div style={caption}>{scheme} — statuses</div>
      <div style={row}>
        {STATUS[scheme].map((s) => (
          <Badge key={s.label} label={s.label} color={s.color} ink={s.ink} />
        ))}
      </div>
      <div style={caption}>{scheme} — priorities</div>
      <div style={row}>
        {PRIORITY[scheme].map((p) => (
          <Badge key={p.label} label={p.label} color={p.color} ink={p.ink} />
        ))}
      </div>
    </div>
  );
}

export function LightScheme() {
  return <Set scheme="light" bg={LIGHT_CARD} fg="#5C625A" />;
}

export function DarkScheme() {
  return <Set scheme="dark" bg={DARK_CARD} fg="#A2A89F" />;
}

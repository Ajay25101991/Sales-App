import { TextField } from '@sales/ui';
const col = { display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 320 } as const;
export function Default() {
  return <div style={col}><TextField label="Company" value="Acme Industries" placeholder="Company name" onChangeText={() => {}} /></div>;
}
export function WithError() {
  return <div style={col}><TextField label="Email" value="not-an-email" error="Enter a valid email address" onChangeText={() => {}} /></div>;
}
export function Password() {
  return <div style={col}><TextField label="Password" value="hunter2" secureTextEntry onChangeText={() => {}} /></div>;
}

import { ChipSelect } from '@sales/ui';
export function Priority() {
  return (
    <div style={{ maxWidth: 340 }}>
      <ChipSelect
        label="Priority"
        value="high"
        onChange={() => {}}
        options={[{ value: 'low', label: 'Low' }, { value: 'medium', label: 'Medium' }, { value: 'high', label: 'High' }]}
      />
    </div>
  );
}

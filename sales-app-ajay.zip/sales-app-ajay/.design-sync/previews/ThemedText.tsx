import { ThemedText } from '@sales/ui';
export function TypeScale() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, maxWidth: 360 }}>
      <ThemedText type="title">Title</ThemedText>
      <ThemedText type="subtitle">Subtitle</ThemedText>
      <ThemedText type="default">Default body text for descriptions.</ThemedText>
      <ThemedText type="smallBold">Small bold label</ThemedText>
      <ThemedText type="small" themeColor="textSecondary">Small secondary caption</ThemedText>
    </div>
  );
}

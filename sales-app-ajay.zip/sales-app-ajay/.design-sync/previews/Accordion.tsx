import { Accordion, AccordionChevron, Card, ThemedText } from '@sales/ui';

// Compositions ported from the two real call sites: movement.tsx's per-rep
// disclosure and collections-view.tsx's per-customer one. Layout glue is plain
// <div> per the preview rule in NOTES.md — never import react-native here.

const row: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 8 };
const statRow: React.CSSProperties = { display: 'flex', gap: 16, paddingLeft: 20 };

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div style={row}>
      <ThemedText type="small" themeColor="textSecondary">{label}</ThemedText>
      <ThemedText type="smallBold">{value}</ThemedText>
    </div>
  );
}

/** The default state: a closed group whose header still carries its numbers. */
export function Collapsed() {
  return (
    <div style={{ maxWidth: 380 }}>
      <Card>
        <Accordion
          accessibilityLabel="Liam Nguyen, 4 changes, $191K open, $120K won, 4 leads"
          accessibilityHint={(expanded) => (expanded ? 'Collapses this rep’s changes' : 'Expands this rep’s changes')}
          header={(expanded) => (
            <>
              <div style={row}>
                <AccordionChevron expanded={expanded} />
                <ThemedText type="smallBold">Liam Nguyen</ThemedText>
                <div style={{ marginLeft: 'auto' }}>
                  <ThemedText type="small" themeColor="textSecondary">4 changes</ThemedText>
                </div>
              </div>
              <div style={statRow}>
                <Stat label="Open" value="$191K" />
                <Stat label="Won" value="$120K" />
                <Stat label="Leads" value="4" />
              </div>
            </>
          )}>
          <div />
        </Accordion>
      </Card>
    </div>
  );
}

/** Open, showing that the body only mounts while expanded. */
export function Expanded() {
  return (
    <div style={{ maxWidth: 380 }}>
      <Card>
        <Accordion
          defaultExpanded
          accessibilityLabel="Sofia Rossi, 3 changes, $47K open, $0 won, 3 leads"
          accessibilityHint={(expanded) => (expanded ? 'Collapses this rep’s changes' : 'Expands this rep’s changes')}
          header={(expanded) => (
            <>
              <div style={row}>
                <AccordionChevron expanded={expanded} />
                <ThemedText type="smallBold">Sofia Rossi</ThemedText>
                <div style={{ marginLeft: 'auto' }}>
                  <ThemedText type="small" themeColor="textSecondary">3 changes</ThemedText>
                </div>
              </div>
              <div style={statRow}>
                <Stat label="Open" value="$47K" />
                <Stat label="Won" value="$0" />
                <Stat label="Leads" value="3" />
              </div>
            </>
          )}>
          <div style={{ paddingLeft: 20, paddingTop: 8, display: 'grid', gap: 6 }}>
            <ThemedText type="small">Northwind Traders · moved to Proposal</ThemedText>
            <ThemedText type="small" themeColor="textSecondary">Contoso Ltd · quiet for 12 days</ThemedText>
            <ThemedText type="small" themeColor="textSecondary">Fabrikam Inc · entered Contacted</ThemedText>
          </div>
        </Accordion>
      </Card>
    </div>
  );
}

/** The single-line header form, as the Collections screen uses it. */
export function SingleLineHeader() {
  return (
    <div style={{ maxWidth: 380 }}>
      <Card>
        <Accordion
          accessibilityLabel="Adventure Works, $42,500 outstanding"
          accessibilityHint="Expands this customer’s invoices"
          header={(expanded) => (
            <div style={row}>
              <AccordionChevron expanded={expanded} />
              <ThemedText type="smallBold">Adventure Works</ThemedText>
              <div style={{ marginLeft: 'auto' }}>
                <ThemedText type="smallBold" themeColor="dangerStrong">$42,500</ThemedText>
              </div>
            </div>
          )}>
          <div />
        </Accordion>
      </Card>
    </div>
  );
}

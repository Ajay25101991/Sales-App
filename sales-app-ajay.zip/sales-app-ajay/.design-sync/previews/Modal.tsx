import { Modal } from '@sales/ui';
import { ThemedText } from '@sales/ui';
import { Button } from '@sales/ui';
export function Confirm() {
  return (
    <Modal visible title="Delete lead" onClose={() => {}}>
      <ThemedText type="small" themeColor="textSecondary">This can’t be undone.</ThemedText>
      <Button title="Delete" variant="danger" onPress={() => {}} />
    </Modal>
  );
}

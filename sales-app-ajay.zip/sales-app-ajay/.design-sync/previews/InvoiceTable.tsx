import { InvoiceTable } from '@sales/ui';

// The connected sibling of InvoiceTablePresentation: same rows, but it owns the
// row-press navigation itself (expo-router) instead of taking an onPressRow.
// Without an authored preview it rendered a BLANK card — the .d.ts
// crash-prevention props leave `invoices` undefined and the component maps over
// it — which is worse than the honest floor card, so it gets real rows here.
//
// Data mirrors InvoiceTablePresentation.tsx deliberately: the two cards sit next
// to each other in the pane, and differing rows would read as a behavioural
// difference when the only real difference is who owns the press handler.

const DAY = 86_400_000;
// Offsets from "now", not fixed ISO dates: the row derives an overdue flag
// against the current date, so hardcoded dates would age into nonsense.
const at = (days: number) => new Date(Date.now() + days * DAY).toISOString();

const INVOICES = [
  {
    id: '1', number: 'INV-1042', lead_name: 'Acme Industries', company: 'Acme Industries',
    status: 'partial', amount: 48000, balance: 18000, due_date: at(6), overdue: false,
  },
  {
    id: '2', number: 'INV-1038', lead_name: 'Brightside Logistics', company: 'Brightside Logistics',
    status: 'open', amount: 125000, balance: 125000, due_date: at(-12), overdue: true,
  },
  {
    id: '3', number: 'INV-1031', lead_name: 'Northwind Trading', company: 'Northwind Trading',
    status: 'paid', amount: 9500, balance: 0, due_date: at(-40), overdue: false,
  },
  {
    id: '4', number: 'INV-1029', lead_name: 'Cedar & Co', company: 'Cedar & Co',
    status: 'written_off', amount: 4200, balance: 0, due_date: at(-95), overdue: false,
  },
];

export const Table = () => <InvoiceTable invoices={INVOICES as never} />;

export const Empty = () => <InvoiceTable invoices={[] as never} />;

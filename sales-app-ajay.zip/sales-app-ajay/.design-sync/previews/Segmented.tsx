import { Segmented } from '@sales/ui';
export function ListBoard() {
  return (
    <div style={{ maxWidth: 260 }}>
      <Segmented value="list" onChange={() => {}} options={[{ value: 'list', label: 'List' }, { value: 'board', label: 'Board' }]} />
    </div>
  );
}
export function Ranges() {
  return (
    <div style={{ maxWidth: 320 }}>
      <Segmented value="month" onChange={() => {}} options={[{ value: 'week', label: 'Week' }, { value: 'month', label: 'Month' }, { value: 'quarter', label: 'Quarter' }]} />
    </div>
  );
}

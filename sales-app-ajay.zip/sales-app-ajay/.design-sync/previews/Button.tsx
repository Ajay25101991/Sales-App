import { Button } from '@sales/ui';
const col = { display: 'flex', flexDirection: 'column', gap: 12, maxWidth: 260 } as const;
export function Primary() { return <Button title="Create lead" onPress={() => {}} />; }
export function Variants() {
  return (
    <div style={col}>
      <Button title="Save lead" variant="primary" onPress={() => {}} />
      <Button title="Cancel" variant="secondary" onPress={() => {}} />
      <Button title="Skip for now" variant="ghost" onPress={() => {}} />
      <Button title="Delete deal" variant="danger" onPress={() => {}} />
    </div>
  );
}
export function Loading() { return <Button title="Saving…" loading onPress={() => {}} />; }
export function Disabled() { return <Button title="Unavailable" disabled onPress={() => {}} />; }

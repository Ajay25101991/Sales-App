import { ListRow } from '@sales/ui';
export function SettingsRows() {
  return (
    <div style={{ maxWidth: 380 }}>
      <ListRow icon="notifications-outline" title="Reminders" subtitle="Push, email & in-app" first onPress={() => {}} />
      <ListRow icon="people-outline" title="Team" subtitle="5 members" onPress={() => {}} />
      <ListRow icon="card-outline" title="Payments" onPress={() => {}} />
    </div>
  );
}

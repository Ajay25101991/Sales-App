---
category: desktop
---

# InvoiceTablePresentation

The desktop receivables table with **no data fetching and no router** — the
provider-free half of `InvoiceTable`. Rows arrive as `invoices`, and clicking one
calls `onPressRow`, so this renders anywhere.

Columns: Status (status badge, plus an `Overdue` badge when the invoice is
overdue), Customer (lead name + `company · number`), Amount, Balance (em-dash
when settled), Due (in `danger` when overdue). Amount/Balance/Due are
right-aligned mono with tabular-nums and fixed widths.

Its metrics are copied from `LeadTablePresentation` so the two tables — one click
apart in the product — share row height, gutters and header fill.

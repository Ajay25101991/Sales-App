---
category: desktop
---

# NavSidebarPresentation

The desktop left rail's markup with **no data fetching and no router** — the
provider-free half of `NavSidebar`. Role, counts, the active route and the
signed-in user all arrive as props, so this renders anywhere: a design template,
a preview card, a test.

Inside the app use `NavSidebar`, which reads the role from `useAuth()`, the
badge counts from `useReminders` / `useApprovals` / `useCollectionTasks`, and the
active row from `usePathname()` + `?tab=` — then passes a `renderLink` so rows
stay real expo-router `<Link>` anchors (middle-click, open in new tab). Without
`renderLink` the rows fall back to `onNavigate`.

236px wide, `theme.surface` fill. Group headings are full-strength `text`;
inactive rows are `textSecondary`; the active row takes the `#EDF2EB` fill
(`backgroundSelected` in dark) with `primaryStrong` label. Attention counts
(reminders, approvals, collector tasks) carry `tone: 'danger'`.

---
category: desktop
---

# InvoiceTable

App-facing receivables table: resolves navigation via `useRouter()` and delegates
to `InvoiceTablePresentation`. Use this inside the app; use the presentation
component in templates and previews, where there is no router.

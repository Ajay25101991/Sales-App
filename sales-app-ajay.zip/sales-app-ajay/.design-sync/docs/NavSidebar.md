---
category: desktop
---

# NavSidebar

The desktop web app's persistent 236px left rail — it replaces the bottom tab bar
at ≥900px. Role-derived nav groups (Sell / Money / Work / Manage for managers and
reps; Collections / Personal for collectors), a search box that opens the ⌘K
palette, real count badges on Reminders / Approvals / My tasks, and the signed-in
user pinned at the bottom.

Takes **no props**: it reads the role from `useAuth()`, its counts from
`useReminders` / `useApprovals` / `useCollectionTasks`, and the active row from
`usePathname()` + `?tab=`. It therefore needs the app's providers to render, which
is why its card here is the typographic floor rather than a live preview.

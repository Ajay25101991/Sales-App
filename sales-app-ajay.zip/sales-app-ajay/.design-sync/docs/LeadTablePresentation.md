---
category: desktop
---

# LeadTablePresentation

The desktop leads table with **no data fetching** — the provider-free half of
`LeadTable`. Stage display data arrives through the `stageMeta` prop instead of
`useStages()`, so this renders anywhere: a design template, a preview card, a
test. Inside the app use `LeadTable`, which resolves the org's stages from the
API and delegates here.

Columns follow spec §11: checkbox, Lead (name + source), Company, Stage badge,
Value (right-aligned, mono, tabular-nums), Follow-up (colour-coded overdue /
idle), Owner + priority pill, row menu.

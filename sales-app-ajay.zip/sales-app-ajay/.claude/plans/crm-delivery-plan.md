# Suntech Sales CRM — Delivery Plan

**Date:** 2026-08-08
**Source:** Sales manager feedback (12 ranked items) plus a reporting follow-up
**Audience:** One developer, executing one item at a time
**Status:** Proposed, pending user review

---

## Part 0: What I verified, and what changed my ranking

**Confirmed true** (beyond the five already checked before planning began): no stage-history table of any kind (`Lead.Status` is the only state; `StageService` is config-only); `Amc` has no `AccountId`; `AmcsController.Renew` mutates `RenewalDate` in place and creates nothing; `GET /invoices/billable-leads` filters `!invoiced.Contains(l.Id)` so a lead can **never** be invoiced twice; `Proposal` has no discount/VAT/validity/currency fields and `proposal-generator.tsx` only calls `Print.printAsync`/`Sharing.shareAsync` — nothing is POSTed; `Invoice` has a single `Amount`, no line items, no tax, no TRN, and `Number` has **no unique index** (`GenerateNumber()` is date + 4 random hex chars); no mail transport exists anywhere in `api/` (`NotificationService` is Expo push only, `ReminderSweeper` has no email branch); `AccountDto` carries no receivables; `ApprovalsController.Decide` writes only `Status`/`DecidedBy`/`DecidedAt`/`DecisionNote` for `discount`; `/reports/trends`, `/win-loss`, `/rep/{id}` take no date range and nothing exports; `targets.tsx` is hardcoded to `currentPeriod()`; "promise to pay" is just an activity-type chip in `src/constants/payments.ts` with no date or amount field.

### Four corrections to the reported list

**1. `/reports/leaderboard` already accepts `?period=`** (`ReportsController.cs:21`, supporting week/month/quarter/all). The all-time leaderboard is purely a client wiring bug at `reports-view.tsx:191`. That's a one-hour fix, not an analytics project — pulled out of item #8 and made a standalone quick win.

**2. The roles-tab bug is one line in one file.** The nav model correctly uses `Permissions.manageRoles`; it's `roles-config.tsx:31` that hardcodes `user?.role === 'admin' || user?.role === 'suntech-admin'` and then `<Redirect>`s. Small — pulled forward.

**3. Merge is worse than reported, and it is live data loss.** `LeadsController.Merge` reparents activities, attachments, reminders, approvals, invoices and proposals (lines 753–758) — but **not `Amcs`, `Contacts` or `CollectionTasks`**. `Amc.LeadId` is configured `OnDelete(DeleteBehavior.Cascade)` (`AppDbContext.cs:282`), so `_db.Leads.Remove(dup)` **silently destroys every AMC attached to the duplicate**, with no warning and no undo. For a business whose recurring revenue lives in AMCs, this is more urgent than the missing field-picker UX the manager described. This moves item #10 from polish to P0.

**4. The USD bug reaches the customer, not just internal staff.** `QuotesController.cs:38` renders `{quote.Total:C0}` with no culture on the public accept page served from `api.suntech-global.com`. A UAE customer clicking a quote link sees a dollar sign. That is worse than the internal template and makes the currency fix urgent independent of the whole document chain.

### Structural risk affecting every item below

`DbInitializer` calls `db.Database.MigrateAsync()` on container start, and `deploy-aws.yml` has no database backup or snapshot step. **The CI deploy is now armed and live**, so every migration in this plan auto-applies to production the moment a commit with an `api/` change lands on main — unreviewed, unattended and unrecoverable. Worse, because migration runs at container start, a *failed* migration takes the API down rather than merely failing the deploy. See item **A0**.

---

## Part 1: Work items

### Tier 0 — Live bugs and data-loss risk

---

#### A0. Pre-migration database snapshot in the deploy pipeline

**Outcome:** A bad migration is recoverable. Right now it isn't.

**Scope cut:** Add an RDS snapshot (or `pg_dump` to S3) step to `deploy-aws.yml`, gated before the ECS service update, tagged with the commit SHA. **Not doing:** migration review gates, blue/green deploys, automatic rollback, a staging environment.

**Touch points:** `.github/workflows/deploy-aws.yml` only. No app code.

**Migration risk:** None — this is what de-risks the other nine.

**Acceptance criteria:**
- A deploy that includes a migration produces a restorable snapshot named for its commit SHA.
- A documented restore command exists in `DEPLOYMENT.md`.
- The snapshot step fails the deploy if it errors, rather than being skipped.

**Dependencies:** None. **This is the first thing built.**

**Size:** Half a day.

---

#### A1. Stop the merge from destroying AMCs

**Outcome:** Merging a duplicate never loses a maintenance contract, a contact, or a collection task.

**Scope cut:** In `Merge`, reparent `Amcs`, `Contacts` and `CollectionTasks` to the primary alongside the existing six `ExecuteUpdateAsync` calls; then **soft-retire the duplicate instead of deleting it** — add `Lead.MergedIntoId` + `Lead.MergedAt`, exclude merged leads from all list queries, and keep the row. **Not doing:** field picker, merge preview, unmerge UI, or the `IsDuplicate` detection change (that's deferred, Tier 5).

**Touch points:** `api/Controllers/LeadsController.cs` (`Merge`, `Scoped`/list filters), `api/Models/Lead.cs`, `api/Data/AppDbContext.cs`. No client change needed beyond confirming merged leads vanish from `useLeads()`.

**Migration risk: YES.** Two nullable columns on `leads` — a low-risk additive migration, but deliberately the **first one to go out after A0**, to prove the snapshot pipeline works on something cheap before the dangerous migrations in Phase 3.

**Acceptance criteria:**
- Merging a lead that has an AMC leaves the AMC attached to the primary and visible in `/amcs`.
- The duplicate row still exists in the DB with `merged_into_id` set.
- The duplicate appears in no list, board, report, dashboard or search result.
- Contacts and collection tasks on the duplicate survive the merge.

**Dependencies:** A0.

**Size:** 1 day.

---

#### A2. Make payments and invoices durable offline — or stop promising they are

**Outcome:** The offline banner's promise is true. A payment recorded in a basement car park is not lost.

**Scope cut:** Register `mutationKeys` + `setMutationDefaults` for the payment-record, invoice-create and invoice-status mutations in `src/lib/mutation-defaults.ts`, matching the existing six. **Attachments stay excluded** — a file blob can't be JSON-serialised into the persisted mutation cache, and solving that is an outbox project, not this item. Instead, change `offline-banner.tsx` to count only mutations with a registered durable key, and give attachment upload an explicit offline state ("photos upload when you reconnect — don't close the app"). **Not doing:** a durable attachment outbox, background sync, conflict resolution.

**Touch points:** `src/lib/mutation-defaults.ts`, `src/hooks/use-invoices.ts`, `src/hooks/use-collections.ts`, `src/components/offline-banner.tsx`, `src/hooks/use-attachments.ts`. Backend untouched.

**Migration risk:** None.

**Acceptance criteria:**
- Record a payment in airplane mode, force-quit the app, reopen, restore connectivity → the payment appears server-side.
- The offline banner's count matches only what will actually survive a restart.
- Attempting an attachment upload offline shows a distinct message, not the generic queued banner.

**Dependencies:** None. Can run parallel to A1.

**Size:** 1–2 days. The manager called this out as "fix first if it's small" — it is small, and they were right.

---

#### A3. Currency correctness on every server-rendered document

**Outcome:** No customer or colleague ever sees a dollar sign. AED, formatted correctly, everywhere the server renders money.

**Scope cut:** Add an org currency setting read from `AppSetting` (the client already has `setCurrency` in `src/lib/format.ts` — mirror it server-side), and use it in `ProposalTemplate.Money` and `QuotesController.Page`. **Not doing:** multi-currency deals, FX conversion, per-deal currency override, or the rest of the document redesign.

**Touch points:** `api/Services/ProposalTemplate.cs:11`, `api/Controllers/QuotesController.cs:38` (`Page`), `api/Controllers/SettingsController.cs`.

**Migration risk:** None (settings are key/value rows in an existing table).

**Acceptance criteria:**
- The public accept page and the tracked proposal both render `AED 45,000` for a 45000 total.
- No `$` appears anywhere in either output.
- Changing the org currency setting changes both surfaces without a redeploy.

**Dependencies:** None.

**Size:** Half a day. The cheapest slice of the manager's #3, fixing the most embarrassing symptom.

---

#### A4. Quick wins batch (one PR — they share nothing but their size)

**Outcome:** Manager can filter the leaderboard by period; a custom role with `roles.manage` can actually open the Roles screen; the "Coming soon" alerts stop lying.

**Scope cut:**
- (a) Pass a period argument at `reports-view.tsx:191` and add a segmented control — the API already supports it.
- (b) Replace the literal role check at `roles-config.tsx:31` with the permission check the nav already uses.
- (c) Delete the `comingSoon` handler and its two menu entries in `leads-view.tsx:53` rather than shipping a stub.

**Not doing:** building campaigns or tags.

**Touch points:** `src/components/reports-view.tsx`, `src/hooks/use-reports.ts`, `src/app/roles-config.tsx`, `src/components/leads-view.tsx`.

**Migration risk:** None.

**Acceptance criteria:**
- Leaderboard totals change when switching week/month/quarter/all.
- A user with a custom role holding `roles.manage` reaches the Roles screen without redirect.
- No "Coming soon" alert exists anywhere in the app.

**Dependencies:** None.

**Size:** 1 day for all three.

---

### Tier 1 — Recording what isn't recorded

Two items here — stage history (the manager's #1) and the four missing timestamp columns (the reporting follow-up). **They are the same kind of work and belong in the same phase:** both are write-only plumbing that renders nothing on the day it ships and becomes more valuable every week it sits in production. Building them together means one migration wave, one deploy, one risk window.

---

#### B1. Record stage transitions

**Outcome:** Nothing visible. From the day this ships, every stage change is a durable, queryable row. This is the prerequisite for all pipeline analytics forever.

**Scope cut:** New `LeadStageEvent` entity: `Id, OrgId, LeadId, FromStatus, ToStatus, ChangedById, ChangedAt`. Written from the single place in `LeadsController` that already handles a status change (the same code path that writes the `LeadActivity` sentence today), plus `ApprovalsController` if it moves status. **Backfill exactly one synthetic row per existing lead** — `(null → current Status, at CreatedAt)` — so time-in-current-stage is computable for the existing book from day one. **Not doing:** reconstructing real history by parsing the English sentences in `lead_activities` (unreliable, and it would bake bad data into the analytics permanently); no UI; no read endpoint.

**Touch points:** new `api/Models/LeadStageEvent.cs`, `api/Data/AppDbContext.cs`, `api/Controllers/LeadsController.cs`, `api/Controllers/ApprovalsController.cs`.

**Migration risk: YES, and this is the second-highest-risk migration in the plan** — new table plus a backfill pass over every existing lead. Run the backfill as an idempotent step in `DbInitializer`, guarded so it no-ops if the table is non-empty. Take the A0 snapshot first.

**Acceptance criteria:**
- Moving a lead new→contacted→qualified produces three rows (one backfill, two transitions) with correct `from`/`to`/`by`/`at`.
- Re-deploying does not duplicate the backfill.
- Indexes exist on `(OrgId, LeadId, ChangedAt)` and `(OrgId, ChangedAt)`.

**Dependencies:** A0.

**Size:** 2–3 days.

---

#### B1b. The four missing date columns

**Outcome:** Four reports become possible that are impossible today, and one number that is currently wrong becomes right. Specifically: a commit/forecast view gains a time dimension; the collections chase list can be ordered by promised date; "lost this month" stops being corrupted by unrelated edits; and time-to-decision stops being biased toward fast yeses.

**Scope cut:** Four columns, one migration:

| Column | Table | Written when | Unlocks |
|---|---|---|---|
| `ExpectedCloseDate` (nullable date) | `leads` | Set by the rep on the lead form | Commit / time-bounded forecast |
| `LostAt` (nullable timestamp) | `leads` | Set when `Status` first becomes `lost` | Correct "lost this period" figures |
| `PromisedDate` + `PromisedAmount` (nullable) | `invoice_activities` | Set when activity type is `promise` | Collections chase list |
| `DeclinedAt` (nullable timestamp) | `proposals` | Set when `Status` becomes `declined` | Unbiased time-to-decision |

Ship the **write sites and one UI field** (expected close date on `lead-form.tsx`, promised date/amount on the invoice activity composer). **Not doing in this pass:** any of the four reports themselves, backfilling `ExpectedCloseDate` (there is no honest source for it — leave it null and let it fill in as reps edit), or making the field mandatory.

**One correctness fix rides along, and it is not optional:** `ReportsController.cs:43-46` measures **won** with `WonAt ?? UpdatedAt` but **lost** with bare `UpdatedAt`. The two halves of the same leaderboard row are on different clocks, and any edit to a lost lead silently drags it into the current period. Once `LostAt` exists, switch the lost branch to `LostAt ?? UpdatedAt` and backfill `LostAt = UpdatedAt` for existing lost leads (imperfect, but no worse than the status quo and it stops the drift from here forward). Do the same for `WinLoss` at `ReportsController.cs:172`, which today has no date basis at all.

**Touch points:** `api/Models/Lead.cs`, `api/Models/InvoiceActivity.cs`, `api/Models/Proposal.cs`, `api/Data/AppDbContext.cs`, `api/Controllers/LeadsController.cs` (status-change path, `Apply`, `ToDto`), `api/Controllers/InvoicesController.cs` (activity create), `api/Controllers/ReportsController.cs` (lost date basis), `api/Dtos/Dtos.cs`, `src/components/lead-form.tsx`, `src/app/invoice/[id]/index.tsx`, `src/types/models.ts`.

**Migration risk: YES.** Five nullable columns across three tables, plus a `LostAt` backfill from `UpdatedAt`. Individually trivial, but it touches `leads` and `proposals`, both of which have live rows — and it is the same wave as B1's new table, so treat the two as one risk window with one snapshot.

**Acceptance criteria:**
- A rep can set an expected close date on a lead; it round-trips through create and update and appears in the lead DTO.
- Marking a lead lost sets `LostAt` once; editing that lead afterwards does not change it.
- `/reports/leaderboard?period=month` counts a lead lost last month in *last* month, even after it's edited today.
- Logging a `promise` activity captures a date and amount; other activity types don't require them.
- Declining a proposal sets `DeclinedAt`.

**Dependencies:** A0. Build immediately adjacent to B1 — same migration wave.

**Size:** 2 days.

**My judgement on the manager's argument:** they claimed these columns block more reporting than the stage-history gap does, and **they are right**, with one qualification. Three of the four (`LostAt`, `DeclinedAt`, `PromisedDate`) are pure server-side plumbing with an obvious write site and zero behaviour change — they cost two days and start accruing value immediately. `ExpectedCloseDate` is different in kind: it is the only one of the four with a *data-entry cost*, because it needs reps to actually fill it in, and a forecast built on a field that half the pipeline leaves null is worse than no forecast. So it ships in the same migration but its dependent reporting is gated on adoption, not on code. Track fill rate before building anything on top of it.

---

#### B1c. Bound the weighted forecast, or label it honestly

**Outcome:** The dashboard stops implying that a probability-weighted sum of the entire open pipeline is comparable to a monthly goal sitting next to it.

**Scope cut:** `DashboardController.cs:51` sums *every* open lead × its stage probability with **no date bound whatsoever** — a deal that has sat in "qualified" for fourteen months contributes 50% of its value to a figure the manager reads as this month's expectation. Two options, in order of preference: (a) once `ExpectedCloseDate` fill rate is adequate, bound the forecast to deals closing in the period and show the unbounded remainder separately; (b) **until then**, relabel the panel to "Weighted open pipeline" and stop rendering it adjacent to the monthly target. **Do (b) now — it is a text and layout change, and the panel is misleading today.** Do (a) as a follow-on when the data supports it.

**Touch points:** `src/components/dashboard-view.tsx`, and later `api/Controllers/DashboardController.cs` + `api/Services/ForecastService.cs`.

**Migration risk:** None for (b).

**Acceptance criteria for (b):** The panel is no longer captioned as a forecast, and no longer sits in the same visual group as the monthly goal. For (a): the forecast figure changes when a deal's expected close date moves out of the period.

**Dependencies:** (b) none. (a) depends on B1b plus adoption.

**Size:** (b) half a day. (a) 1–2 days, later.

---

#### B2. Time-in-stage on the lead

**Outcome:** Manager can see, per deal, how long it has sat in its current stage — the highest-value output of B1 and the one that works on day one from the backfill.

**Scope cut:** Add `days_in_stage` to the lead DTO (computed from the latest stage event) and surface it on `lead-card.tsx` and the lead detail header. Add a "stalled > N days" filter to the leads list, reusing the existing `idle` filter pattern in `LeadsController`. **Not doing:** the full history timeline UI, per-stage averages, charts.

**Touch points:** `api/Controllers/LeadsController.cs` (`ToDto`, list filters), `api/Dtos/Dtos.cs`, `src/components/lead-card.tsx`, `src/app/lead/`, `src/hooks/use-leads.ts`.

**Migration risk:** None (reads B1's table).

**Acceptance criteria:**
- Every lead shows a days-in-stage figure.
- Filtering "stalled > 14 days" returns exactly the leads whose latest stage event is older than 14 days.

**Dependencies:** B1 shipped, plus enough elapsed time that the number is meaningful for recently-moved deals.

**Size:** 2 days.

---

#### B3. Week-over-week pipeline movement

**Outcome:** The Monday pipeline review works. Manager can answer "what moved last week, what didn't, and who moved it."

**Scope cut:** One new endpoint, `GET /reports/pipeline-movement?from=&to=`, returning entered/exited counts and value per stage for the window, plus a list of deals that moved. Rendered as a **table** in `trends.tsx`, not a chart. **Not doing:** cohort conversion rates, drag-to-compare periods, forecasting.

**Touch points:** `api/Controllers/ReportsController.cs`, `api/Services/StageService.cs` (stage ordering/labels), `src/components/trends.tsx`, `src/hooks/use-reports.ts`.

**Migration risk:** None.

**Acceptance criteria:**
- For a chosen week, each configured stage shows deals-in, deals-out and net value change.
- The numbers reconcile against `lead_stage_events` when checked by hand.

**Dependencies:** B1 + roughly 2–4 weeks of accumulated events.

**Size:** 2–3 days.

---

#### B4. Cohort stage-conversion funnel

**Outcome:** The funnel in `trends.tsx` becomes a real conversion rate — of leads created in period X, what share reached each stage — instead of today's snapshot.

**Scope cut:** Replace the existing funnel computation with a cohort query over `lead_stage_events`. **Not doing:** per-source or per-rep cohort splits.

**Touch points:** `api/Controllers/ReportsController.cs` (`Trends`), `src/components/trends.tsx`.

**Migration risk:** None.

**Acceptance criteria:**
- The funnel is labelled with its cohort window.
- Its top-of-funnel count equals leads created in that window, not total open leads.

**Dependencies:** B1 + at least one full sales cycle of data. **Realistically a quarter out — say so to the manager now**, rather than letting them expect it in the same release as B1.

**Size:** 2 days, but gated on data, not effort.

---

### Tier 2 — The document chain (the manager's #3; large, three slices)

---

#### C1. Persist the real quote server-side

**Outcome:** The good A4 document — AED, 5% VAT, discount, validity, signature block — becomes the tracked, shareable, accepted quote. Today it exists only as a PDF on someone's phone.

**Scope cut:** Extend `Proposal` with the fields `proposal.model.ts` already carries: `Subtotal`, `DiscountAmount`, `TaxRate`, `TaxAmount`, `Total`, `ValidUntil`, `Currency`, and a `LineItems` jsonb column. Have `proposal-generator.tsx` POST that structure on generate. Replace `ProposalTemplate.cs`'s plain-text builder and `QuotesController.Page`'s `<pre>{Content}</pre>` with a server-side render of the same document. **Not doing:** server-side PDF binary generation (keep client `expo-print` for the PDF); versioning/revisions; e-signature.

**Touch points:** `api/Models/Proposal.cs`, `api/Services/ProposalTemplate.cs`, `api/Controllers/ProposalsController.cs`, `api/Controllers/QuotesController.cs`, `src/components/proposal-generator.tsx` + `.web.tsx`, `src/lib/proposal/render-html.ts`, `src/lib/proposal/proposal.model.ts`, `src/hooks/use-proposals.ts`.

**Migration risk: YES.** Several columns on `proposals` with existing rows. Backfill: `Subtotal = Total`, zero discount/tax, `ValidUntil = CreatedAt + 30d`, `Currency` = org currency. Old quotes must keep rendering.

**Acceptance criteria:**
- Generating a quote in the app creates a proposal row whose stored totals match the PDF to the fils.
- Opening the public accept link shows the same figures with AED and 5% VAT itemised.
- A pre-migration quote still opens without error.

**Dependencies:** A0, A3.

**Size:** 4–5 days. The single largest item in the plan.

---

#### C2. Compliant invoices — line items, VAT, TRN, unique numbers

**Outcome:** An invoice the customer's accounts department will accept and the FTA won't query.

**Scope cut:** Add `InvoiceLineItem` (description, qty, unit price, line total), and `Subtotal`/`TaxRate`/`TaxAmount` on `Invoice`; org TRN + legal name/address in settings; make numbering **sequential per org and unique-indexed** (`INV-2026-0001`), allocated inside a transaction. `Amount` stays as the gross total so every existing payment, aging and collections calculation keeps working untouched. **Not doing:** credit notes, multi-VAT-rate lines, tax-exempt handling, e-invoicing integration.

**Touch points:** `api/Models/Invoice.cs`, new `api/Models/InvoiceLineItem.cs`, `api/Data/AppDbContext.cs`, `api/Controllers/InvoicesController.cs` (`Create`, `GenerateNumber`, `ToDto`), `api/Controllers/SettingsController.cs`, `src/app/invoice/`, `src/hooks/use-invoices.ts`.

**Migration risk: YES — the highest in the plan.** New table, new columns, **and a unique index on `Number` over live data that may already contain collisions** (the current generator is date + 4 random hex chars, so collisions are unlikely but not impossible, and manually-entered numbers are unconstrained). The migration must detect and resolve duplicates *before* adding the constraint, or the deploy will crash-loop on startup — and because `MigrateAsync` runs at container start, a failed migration takes the API down, not just the deploy. **Test the duplicate-resolution path against a restored production snapshot before merging.**

**Acceptance criteria:**
- A new invoice has itemised lines summing to subtotal, 5% VAT shown separately, and the org TRN on the document.
- Numbers are sequential per org; two invoices created concurrently never collide.
- Every pre-existing invoice still lists with a correct balance.

**Dependencies:** A0, A3, C1 (reuse the same money/tax rendering).

**Size:** 4–5 days.

---

#### C3. Non-editable invoice document

**Outcome:** What the customer receives is what the system recorded.

**Scope cut:** Replace the 37-line editable plain-text share in `src/lib/invoice-document.ts` with a rendered document using the same HTML pipeline as C1/C2, shared as a PDF. **Not doing:** emailing it (that's D2), branded templates, per-customer templates.

**Touch points:** `src/lib/invoice-document.ts`, `src/app/invoice/[id]/index.tsx`, reusing `src/lib/proposal/render-html.ts`.

**Migration risk:** None.

**Acceptance criteria:**
- Sharing an invoice produces a PDF matching the stored line items and VAT.
- There is no editable text field anywhere in the share path.

**Dependencies:** C2.

**Size:** 1–2 days.

---

### Tier 3 — AMC renewals (the manager's #2)

---

#### D1. Renewals create a billable term

**Outcome:** Renewing an AMC produces something you can invoice, and last year's term is still on record.

**Scope cut:** Add `Amc.AccountId` (denormalised from the lead, mirroring `Invoice.AccountId`) and an `AmcTerm` record (`AmcId, StartDate, EndDate, ContractValue, InvoiceId?`). `Renew` closes the current term and opens a new one instead of overwriting. Then **fix `billable-leads`**: change it from "won leads with no invoice" to a union of (won leads with no invoice) and (AMC terms with no invoice) — the `!invoiced.Contains(l.Id)` filter at `InvoicesController.cs:85` is the specific line that makes renewals unbillable. **Not doing:** auto-generating the renewal quote, auto-invoicing, price escalation rules, or the dashboard/forecast/digest visibility work (see the override note below).

**Touch points:** `api/Models/Amc.cs`, new `api/Models/AmcTerm.cs`, `api/Controllers/AmcsController.cs` (`Renew`, `Create`, `ToDto`), `api/Controllers/InvoicesController.cs:82` (`BillableLeads`), `api/Data/AppDbContext.cs`, `src/app/amcs.tsx`, `src/hooks/use-amcs.ts`, the raise-invoice picker in `src/app/invoice/`.

**Migration risk: YES.** New table plus a column on `amcs`. Backfill one term per existing AMC from its current `StartDate`/`RenewalDate`/`ContractValue`, and populate `AccountId` from `Lead.AccountId`. Note that some leads have a null `AccountId`, so `Amc.AccountId` must be nullable.

**Acceptance criteria:**
- Renewing an AMC leaves the prior term queryable with its original dates and value.
- The renewed term appears in the raise-invoice picker.
- Invoicing a renewal does not remove the underlying won lead's other billable items.

**Dependencies:** A0, **A1** (A1 must land first — otherwise every merge keeps destroying the AMCs this item is built on).

**Size:** 3–4 days.

---

#### D2. Real email transport

**Outcome:** The "email" channel chip does what it says. Renewal notices, collection chasers and quotes actually leave the building.

**Scope cut:** One `IEmailSender` (SES) behind a config flag, wired into `ReminderSweeper`'s channel loop for the `email` case. **Until it's wired, disable the email chip in the UI** — a channel that stores a preference and silently drops it is worse than one that isn't offered. Do the chip-disable as a same-day change even if the transport takes longer. **Not doing:** templating beyond the existing `AmcService.DefaultEmail()` strings, open/click tracking, bounce handling, inbound email.

**Touch points:** new `api/Services/EmailSender.cs`, `api/Services/ReminderSweeper.cs`, `api/Program.cs`, `api/Services/CollectionReminderService.cs`, `src/app/collection-reminders.tsx`, `src/app/amc-reminders-config.tsx`.

**Migration risk:** None. **Infra risk instead:** SES sandbox removal, domain verification and DKIM for `suntech-global.com` are a multi-day external dependency — **start the AWS request the day this item is scheduled, not the day it's built.**

**Acceptance criteria:**
- A due reminder with `email` in its channels produces a delivered message.
- Delivery failures are logged, not swallowed.
- The chip is either functional or absent — never present and inert.

**Dependencies:** None technically, but the SES verification lead time means requesting early.

**Size:** 2 days of code, up to a week of waiting.

---

### Tier 4 — Manager tooling and collections

---

#### E1. Team follow-up view

**Outcome:** When a rep is off sick, the manager can see and reassign their open tasks.

**Scope cut:** Relax `RemindersController.cs:25`'s hard self-scope to the same owner/manager pattern used by `LeadsController` and `AmcsController` (`User.IsManager()` sees the team, reps see themselves); add `?owner_id=` and `?status=` filters; add reassign (`PATCH` the `UserId`) and snooze (`PATCH` the `RemindAt`). **Not doing:** bulk actions, saved filters, or a separate team-tasks screen — surface it in the existing `tasks-view.tsx` with an owner filter.

**Touch points:** `api/Controllers/RemindersController.cs`, `src/hooks/use-reminders.ts`, `src/components/tasks-view.tsx`, `src/app/reminders.tsx`.

**Migration risk:** None.

**Acceptance criteria:**
- A manager sees a named rep's open reminders and can reassign one.
- The new owner sees it; the old owner doesn't.
- A rep still cannot see anyone else's reminders.
- Snoozing moves the date without completing the reminder.

**Dependencies:** None.

**Size:** 2 days.

---

#### E2. Collections by customer

**Outcome:** Manager can answer "how much does this customer owe us and how old is it" — impossible today.

**Scope cut:** Add receivables to `AccountDto` (outstanding, overdue, oldest invoice age) computed from `Invoice.AccountId`, which already exists and is already indexed. Add an account-level aging breakdown to the account detail screen and a by-customer aging table to the collections dashboard. **Fold in the `WonValue` correction** — `AccountsController.ToDto` currently sums lead *estimates* rather than billed money, which is a number a manager will quote in a meeting and it is wrong. **Not doing:** credit limits, customer statements, dunning sequences.

**Touch points:** `api/Controllers/AccountsController.cs` (`ToDto`), `api/Controllers/CollectionsController.cs` (`Dashboard`), `api/Dtos/Dtos.cs`, `src/components/collections-view.tsx`, `src/components/accounts-view.tsx`, `src/app/account/`, `src/hooks/use-accounts.ts`.

**Migration risk:** None — `Invoice.AccountId` and its index already exist.

**Acceptance criteria:**
- Each account shows outstanding and overdue AED that reconcile against the sum of its invoices.
- The collections screen can be sorted by customer exposure.
- Account "won value" reflects billed money, not lead estimates.

**Dependencies:** None, but sequence near C2 — both live in the invoice money model and share the aging logic.

**Size:** 2–3 days.

---

#### E3. Structured promise-to-pay (report layer)

**Outcome:** The collections chase list exists: promises past their date with a balance still outstanding, ordered by how overdue the promise is.

**Scope cut:** The **columns ship in B1b**; this item is only the read side — a "broken promises" filter and sort on the collections screen, plus surfacing promised date/amount on the invoice detail. **Not doing:** automatic reminders on broken promises, promise-keeping analytics per customer.

**Touch points:** `api/Controllers/CollectionTasksController.cs`, `api/Controllers/InvoicesController.cs`, `src/components/collections-view.tsx`, `src/app/invoice/[id]/index.tsx`.

**Migration risk:** None (B1b carried it).

**Acceptance criteria:**
- A filter lists promises past their date where the invoice still has a balance.
- Each row shows promised amount, promised date, and days overdue.

**Dependencies:** B1b, E2 (shares the collections surface).

**Size:** 1 day (down from 2, because B1b already did the schema).

---

### Tier 5 — Deferred, with reasons

| Item | Verdict |
|---|---|
| **#8 remaining analytics** (period controls on trends/win-loss/rep, CSV export) | **Defer past the tiers above.** The leaderboard fix in A4 removes most of the pain for a fraction of the cost. Note that `api/Services/CsvUtil.cs` already exists, so export is a day's work when you get to it — but it's a day better spent on C2 first. |
| **#9 discount approvals change nothing** | **Defer, but note the trap.** The right fix is for an approved discount to write into the *quote*, and the quote has no discount field until **C1**. Building it before C1 means building it twice. Do it as a small follow-on to C1: on approve, set the proposal's `DiscountAmount`. Half a day, once C1 exists. |
| **#10 duplicate detection** (`IsDuplicate` needing both email and phone) | **Defer the detection; A1 already fixed the dangerous half.** When you get to it, note that the current implementation loads every lead's email and phone into memory (`LeadsController.cs:859`) and compares in C# — an O(n) table scan per create. It needs normalised, indexed columns, not just a looser predicate. A real item, not a one-liner. |
| **#11 insecure onboarding** | **Defer the invite email until D2 exists** (no transport, no invite email). Do ship `Profile.MustChangePassword` + a forced change on first login as a small standalone item — that's the security-relevant half and it needs no email. In-app help: not now. |
| **#12 remainder** (no search on Payments/AMCs, notification preferences, accounts showing invoices/AMCs) | **Mostly cheap, mostly low value, batch them later.** One exception worth pulling forward opportunistically: **won reasons** — `use-stage-change.tsx:232` collects a close reason on *lost* but not on *won*, while the API and `close-reasons-config.tsx` fully support won reasons. It's a small edit to an existing dialog and it makes the win/loss report twice as useful. (The accounts "won value" fix has been folded into E2.) |

---

## Part 2: Sequence

**Ordering principle: anything currently destroying or losing data comes before anything currently merely missing.** A missing feature costs the manager a report. A destroyed AMC costs revenue and cannot be recovered later.

### Phase 1 — Stop the bleeding (~1 week)

1. **A0** — snapshot pipeline. Nothing with a migration ships before this.
2. **A1** — merge destroying AMCs. First migration out, deliberately small, proving A0.
3. **A2** — durable offline payments. The manager's own "fix this first if it's small" call.
4. **A3** — currency on server-rendered documents. Half a day, customer-visible.
5. **A4** — the three quick wins.
6. **B1c(b)** — relabel the weighted forecast panel. Half a day, and it stops a misleading number being read as a forecast every morning.

Phase 1 fixes two silent data-loss paths, one customer-visible embarrassment, one misleading dashboard number, and one of the manager's top complaints (the all-time leaderboard) in under a week. Ship as one release.

### Phase 2 — Start the clock (~1 week)

7. **B1** — stage events table + backfill.
8. **B1b** — the four date columns + the lost-date correctness fix.

Front-load both immediately after Phase 1 **even though they render almost nothing**, because their value is a function of elapsed time. Every week they're delayed is a week of history you can never recover. This is the strongest sequencing argument in the plan and worth explaining to the manager, who will otherwise see a sprint with no visible output. Build them as one migration wave under one snapshot.

The one visible payoff in this phase is B1b's lost-date fix, which corrects numbers the manager is already reading — worth demoing so the phase doesn't look empty.

### Phase 3 — The document chain (~2 weeks)

9. **C1** — persist the real quote.
10. **C2** — invoice line items, VAT, TRN, unique numbers.
11. **C3** — non-editable invoice document.
12. *(half day)* discount approval writes into the quote — the #9 fix, now possible.

C1→C2→C3 must be adjacent: they share the money model, the tax rendering and the HTML pipeline. Splitting them across other work means re-learning the same code three times. **C2 carries the riskiest migration in the plan** (the unique index over live data) — schedule it early in a week, not on a Thursday.

### Phase 4 — AMC renewals + email (~1.5 weeks)

13. **D2 chip-disable** — same day. And start the SES verification request *now*.
14. **D1** — renewal terms and billable renewals. Depends on A1; benefits from C2's invoice model being settled.
15. **D2 transport** — when SES clears.

### Phase 5 — Manager tooling (~1.5 weeks)

16. **B2** — time-in-stage. By now B1 has weeks of real data behind it.
17. **E1** — team follow-up view.
18. **E2** — collections by customer (includes the accounts won-value correction).
19. **E3** — broken-promises chase list.

### Phase 6 — When the data has matured

20. **B3** — week-over-week movement (needs ~1 month of events).
21. **B1c(a)** — bound the forecast by expected close date (needs adequate fill rate — check before building).
22. **B4** — cohort funnel (needs ~1 sales cycle).
23. Deferred tier as capacity allows.

### Shared foundations — build adjacently

- **B1 + B1b** — one migration wave, one risk window, same "record now, report later" logic. Never split them across phases.
- **B1 → B2 → B3 → B4** — one table, four consumers. Build in order but spread over calendar time; the later slices are gated on data accumulating, not developer hours.
- **A3 → C1 → C2 → C3** — one money-and-document model. Keep contiguous.
- **C2 ↔ E2 ↔ E3** — all three touch invoice money and the collections surface. Do E2/E3 while C2 is fresh.
- **B1b → E3** — E3 is only cheap because B1b already shipped its columns.
- **A1 → D1** — D1 builds AMC structure that A1 stops destroying. Reversing them ships a renewal system on top of a delete bug.

### Total

**Roughly 9–10 weeks for one developer**, with Phases 5–6 partly gated on elapsed time rather than effort. If the schedule compresses, cut in this order: E3, then Tier 5, then B4. **Do not cut A0.**

---

## Part 3: Where I overrode the sales manager

### Override 1 — AMC commercial visibility (their #2)

They framed this as "AMCs are invisible commercially" and asked for dashboard, forecast, report and digest coverage. **I'd build none of that yet.** Five new surfaces for AMCs is a week of work producing reporting on a renewal process that currently generates no billable output — you would be building dashboards over a broken pipe.

The genuinely urgent part is narrower, and they buried it mid-paragraph: **a second-year renewal cannot be billed at all**, because `billable-leads` excludes any lead that already has an invoice. That is lost revenue today, and it's one filter change plus a term record (D1). Build D1, then re-ask whether the dashboards are still the top ask — my expectation is that once renewals are billable and flowing through the existing invoice and collections screens, most of the "invisibility" complaint dissolves without a single new surface.

### Override 2 — Cohort funnel timing (part of their #1)

They want the stage-conversion funnel fixed as part of the stage-history work. It cannot be. The funnel needs completed cohorts, and the data starts accruing only when B1 ships. Building B4 in the same release as B1 produces a chart with one nearly-empty cohort in it, which is worse than the honest snapshot they have now because it *looks* rigorous.

**Told them plainly: B4 is a quarter out.** The manager should expect B1 to render nothing, B2 to be the first visible payoff, and B3/B4 to arrive on the calendar, not on the sprint board. Setting that expectation now is the difference between "the stage history work delivered" and "we spent three weeks and got one number on a card."

### Where I agreed with them against my own instinct

The four missing columns (B1b). My first read was that this was a grab-bag of small backend nits that could wait behind the document chain. It isn't: `LostAt` in particular is not a missing feature but a **live correctness bug** — every "lost this month" figure currently uses `UpdatedAt`, so simply editing an old lost deal drags it into the current month's numbers, and the won/lost halves of the same leaderboard row are measured on different clocks (`ReportsController.cs:43-46`). The manager's instinct that these are "individually trivial and collectively unlock more than any new screen" is correct, and B1b moved into Phase 2 on that basis.

---

## Appendix: Verified code references

| Claim | Location | Status |
|---|---|---|
| USD formatting in tracked quote | `api/Services/ProposalTemplate.cs:11` | Verified |
| USD on public accept page | `api/Controllers/QuotesController.cs:38` | Verified |
| Reminders hard-scoped to caller | `api/Controllers/RemindersController.cs:25` | Verified |
| `useLeaderboard()` called with no period | `src/components/reports-view.tsx:191` | Verified |
| Leaderboard API *does* support period | `api/Controllers/ReportsController.cs:21` | Verified |
| `IsDuplicate` needs email AND phone | `api/Controllers/LeadsController.cs:859` | Verified |
| Merge omits `Amcs`/`Contacts`/`CollectionTasks` | `api/Controllers/LeadsController.cs:753-758` | Verified |
| `Amc.Lead` cascade delete | `api/Data/AppDbContext.cs:282` | Verified |
| Only six durable mutations | `src/lib/mutation-defaults.ts` | Verified |
| Banner counts all mutations | `src/components/offline-banner.tsx` (`useIsMutating()`) | Verified |
| Auto-migrate on startup | `api/Data/DbInitializer.cs:11` | Verified |
| No snapshot step in deploy | `.github/workflows/deploy-aws.yml` | Verified |
| `billable-leads` excludes invoiced leads | `api/Controllers/InvoicesController.cs:85` | Verified |
| `Renew` overwrites the term | `api/Controllers/AmcsController.cs:139` | Verified |
| Invoice number not unique-indexed | `api/Data/AppDbContext.cs`, `InvoicesController.cs:376` | Verified |
| No mail transport anywhere | `api/` (grep: no SMTP/SES/MailKit/SendGrid) | Verified |
| Discount approval writes no field | `api/Controllers/ApprovalsController.cs` (`Decide`) | Verified |
| No expected close date | `api/Models/Lead.cs` | Verified |
| No `LostAt`; lost measured by `UpdatedAt` | `api/Models/Lead.cs`, `ReportsController.cs:46` | Verified |
| No `DeclinedAt` on proposal | `api/Models/Proposal.cs` | Verified |
| No promised date/amount | `api/Models/InvoiceActivity.cs` | Verified |
| Forecast has no time dimension | `api/Controllers/DashboardController.cs:51` | Verified |
| Roles screen checks literal role | `src/app/roles-config.tsx:31` | Verified |
| Proposal generator never POSTs | `src/components/proposal-generator.tsx` | Verified |

**Caveat:** all of the above was established by reading code, not by running the app. Acceptance criteria are derived rather than observed — smoke-test A1 and C2 in particular against a restored snapshot before trusting their migration steps.

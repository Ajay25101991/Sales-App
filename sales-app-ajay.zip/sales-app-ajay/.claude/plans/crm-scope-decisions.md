# Scope decisions — 2026-08-08

Decisions taken against `crm-delivery-plan.md` and the sales manager's report brief.
This file records **what was chosen**, not how to build it. The plan holds the
detail; this holds the answers.

## Parked (explicitly, by the user)

| Item | Consequence to remember |
|---|---|
| **A0** — pre-migration DB snapshot in the deploy pipeline | `DbInitializer` calls `MigrateAsync()` on container start and CI deploys on merge to `main`. Every migration below therefore applies to production unattended, with no snapshot and no review. A failed one crash-loops the API rather than failing the deploy. |
| **Email entirely** — SES transport (D2) *and* the same-day chip-disable | `/collection-reminders` and `/amc-reminders-config` keep offering an "email" channel that is stored and then silently dropped by the sweeper. The settings screens continue to imply customers are being emailed. Nothing is. |
| **Duplicate-detection loosening** | The `email AND phone` predicate stays as-is. Only the indexed-column performance fix was approved (see below). |

## Done

- **A1** — merge no longer destroys AMCs. `LeadsController` reparents `Amcs`
  (line 759) before `Leads.Remove(dup)` (line 777). Verified by reading the code.
  Audit confirmed only `LeadActivity`, `Invoice` and `Amc` carry real cascade FKs
  to `leads`, and `Amc` was the only one missing.

## In progress

- Merge preview + undo (undo needs an additive nullable migration).
- **Open question for the user:** the two other `Leads.Remove(...)` call sites
  (~lines 557, 790) still cascade, so deleting a lead outright destroys its AMCs
  and invoices. Deleting *less* than the code currently does is a product
  decision — awaiting the agent's finding and the user's call.

## Approved — build queue

### Tier 0 — live bugs, no migration
1. **A2** durable offline payments; banner counts only what survives; attachments get an explicit offline state.
2. **A3** currency on server-rendered documents (proposal template + public quote accept page).
3. **A4** quick wins: leaderboard period control, roles-config permission check, delete "Coming soon".

### Tier 1 — capture (migrations)
4. **B1** stage-transition capture **and** the movement report together (user chose both, not capture-first).
5. **B1b** four date columns — expected close date, promised-payment date, `lost_at`, `declined_at` — plus the lost-date correctness fix (`ReportsController.cs:44-46` measures won by `WonAt ?? UpdatedAt` and lost by bare `UpdatedAt`).
6. **B2** time-in-stage on the lead.
7. Won reasons collected on the Won path and rendered.
8. Remove the stage-conversion funnel from `trends.tsx`.

### Tier 2 — documents (build adjacently)
9. **C1** persist the real quote server-side, + discount approval writes into the quote.
10. **C2** compliant invoices: line items, VAT, TRN, unique numbers. **Riskiest migration in the plan** (unique index over live data) — with A0 parked, take a manual snapshot before this runs.
11. **C3** non-editable invoice document.

### Tier 3 / 4
12. **D1** AMC renewals create a billable term instead of overwriting it.
13. **E1** team follow-up view (managers see and reassign the team's reminders).
14. **E2** collections grouped by customer, incl. the account won-value correction.
15. **E3** structured promise-to-pay (date + amount) and the broken-promise list.

### Reports
16. Commit board (per rep: target / closed / commit / best case / gap) — gated on close-date fill rate.
17. **Leads added per salesperson, with date filter** — user's own request; buildable today from `Lead.created_at` + `owner_id`.
18. Quote conversion (biased optimistic until `declined_at` lands with B1b).
19. AMC renewal book — totals and 30/60/90 buckets.
20. Source and product mix. **Note:** `products` is a free-text array of module names, so renaming a module in `/proposal-modules` silently orphans historical leads. Fix that or the report rots.
21. Adoption (from `login_events`).
22. Rep self-scorecard — private, rep-facing.
23. MD monthly pack.
24. Export on report screens (`api/Services/CsvUtil.cs` already exists).
25. **"Needs you today" action list as its own tab** — user overrode the PM/manager proposal to replace the dashboard tiles. Tiles stay.

### Smaller items
26. Forced password change on first login (`Profile.MustChangePassword`).
27. Account 360 — invoices and AMCs on the account page.
28. Duplicate detection: **normalised indexed columns only**, replacing the in-memory O(n) scan at `LeadsController.cs:859`. Matching semantics unchanged.

## Later decisions (2026-08-08, after the first two deploys)

**Expected close date semantics.** `Lead.ExpectedCloseDate` is **forward-looking** —
the date a rep expects to close, set and revised while the deal is open. It is not
the actual close date; `WonAt` / `LostAt` already record that.

**The field stays optional and parked — never make it required.** Prior rows stay
null, no backfill. Reps are not forced to fill it on create or edit, and no flow
may block on it.

Consequence, which must be honoured wherever it is consumed: any forecast or commit
board built on it counts **only** the leads that happen to carry a date, and must
show what share of open pipeline value it is blind to. It must never present a
partial figure as the whole forecast. If coverage is very low, the honest output is
"not enough data", not a confident number.

**Renaming a proposal module offers a data update.** `Lead.Products` is a `text[]`
of module *names* and `Proposal.Modules` is a jsonb snapshot embedding names, so a
rename silently orphans historical rows. Renaming now computes the real impact
(how many leads and quotes reference the old name), shows it, and asks. Manager-and-
above only, enforced in the controller. Renaming **without** updating stays
available — some renames are corrections where old records should keep the old
label. Open question the implementing agent was asked to judge and justify: whether
a historical quote's jsonb snapshot should be rewritten at all, given a quote sent
to a customer arguably should not change retroactively.

## Parked for later (not started)

**Microsoft 365 SSO.** Provider confirmed as Entra ID. Scope document not
written yet, nothing implemented — build later. Groundwork already in place if
picked up: auth and authorization are already separate (`AuthController`
verifies a password then issues the app's own JWT; everything downstream reads
that JWT), and `Organization.Domain` + the `AllowedDomain` table already map an
email domain to a tenant, which is the fiddly part. Shape when built: OIDC
authorization code + PKCE, `expo-auth-session` on the client (`expo-web-browser`
and the `salesmobileapp` scheme already exist), and a `/auth/sso` endpoint that
validates the ID token against Microsoft's JWKS before issuing the app JWT.
Three constraints to carry forward: password sign-in must stay (collectors and
the demo depend on it), `Profile.MustChangePassword` must be skipped for SSO
users or they hit a change-password loop with no password, and the email must
never be trusted from the client.

## Explicitly skipped

- Rep activity & coverage report (manager-facing). The rep self-scorecard was kept instead.

## Migration count

Roughly seven migrations across the approved queue (B1, B1b, C2, D1, E3, dedupe
index, `MustChangePassword`). All auto-apply to production on merge while A0 is
parked. Keep every one additive and nullable; C2's unique index is the one that
genuinely needs a snapshot first.

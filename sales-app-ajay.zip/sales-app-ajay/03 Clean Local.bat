@echo off
setlocal EnableExtensions
title 03 Clean Local - Sales CRM
cd /d "%~dp0"

echo ============================================================
echo   Sales CRM - LOCAL CLEANER (our copy: sales-app-ajay)
echo ============================================================
echo.
echo   1 = Stop only      (close servers, stop DB - data kept)
echo   2 = Normal clean   (stop + delete build outputs and caches)   [recommended]
echo   3 = Deep clean     (normal + delete node_modules; next launch reinstalls)
echo   4 = Reset database (stop + ERASE local DB; fresh seed on next launch)
set "CHOICE=2"
set /p "CHOICE=Enter 1-4 (default 2): "

REM ---------- Stop servers ----------
echo.
echo [..] Closing launcher windows...
for %%T in ("SALES-API*" "SALES-DESKTOP*" "SALES-PHONE-WEB*" "SALES-PARTNER*" "SALES-CONTROL*") do (
  taskkill /fi "WINDOWTITLE eq %%~T" /t /f >nul 2>&1
)
echo [..] Freeing ports 5100, 8081, 8110, 8120, 8130...
powershell -NoProfile -Command "foreach($p in 5100,8081,8110,8120,8130){Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }}"
echo [OK] Servers stopped.

REM ---------- Database ----------
where docker >nul 2>&1 && docker info >nul 2>&1 && (
  pushd api
  if "%CHOICE%"=="4" (
    echo.
    echo  WARNING: this ERASES all local CRM data in Postgres. It cannot be undone.
    set "OK=N"
    set /p "OK=Type Y to confirm: "
    call :resetdb
  ) else (
    docker compose stop >nul 2>&1
    echo [OK] Postgres stopped ^(data kept^).
  )
  popd
)
if "%CHOICE%"=="1" goto :done
if "%CHOICE%"=="4" goto :done

REM ---------- Build outputs and caches ----------
echo.
echo [..] Deleting build outputs and caches...
for %%D in ("desktop\dist" "apps\web\dist" "apps\partner\dist" "apps\control\dist" "apps\web\.expo" "apps\mobile\.expo" ".expo" "node_modules\.cache" "desktop\node_modules\.vite" "desktop\test-results" "desktop\playwright-report") do (
  if exist "%%~D" rmdir /s /q "%%~D"
)
for /d /r "api" %%D in (bin obj) do (
  if exist "%%D" rmdir /s /q "%%D"
)
echo [OK] Caches cleared (dist, .expo, .vite, api bin/obj).

if not "%CHOICE%"=="3" goto :done
echo.
echo [..] Deep clean: deleting node_modules (can take a while on OneDrive)...
for /d /r %%D in (node_modules) do (
  if exist "%%D" rmdir /s /q "%%D"
)
echo [OK] node_modules removed. "02 Launch Local.bat" will reinstall.

:done
echo.
echo ============================================================
echo   Clean finished. Source code was NOT touched.
echo   Start again with "02 Launch Local.bat".
echo ============================================================
pause
exit /b 0

:resetdb
if /i "%OK%"=="Y" (
  docker compose down -v >nul 2>&1
  echo [OK] Local database erased. Next launch re-creates and seeds it.
) else (
  docker compose stop >nul 2>&1
  echo [--] Reset cancelled. Postgres stopped, data kept.
)
exit /b 0

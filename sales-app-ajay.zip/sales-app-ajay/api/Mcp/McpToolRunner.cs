using System.Security.Claims;
using ModelContextProtocol.Protocol;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Mcp;
using SalesApi.Services;

namespace SalesApi.McpServer;

/// <summary>
/// Runs one MCP tool call: resolves the caller through <see cref="McpAccess"/> (the one gate - plan feature, permission or API-key scope, rate limit),
/// runs the tool's Process call under that caller, and turns the answer into an MCP result. A refusal is an MCP ERROR result (<c>isError</c>) whose text is
/// a plain sentence the AI tool shows its user - never an exception and never a stack trace.
///
/// LOGGING: the tool name, whether a person or a key called, their id and org, the outcome and the time taken. NEVER the arguments or the result text:
/// a search query, a filter value or a drafted email can carry a person's name, phone or email, and the app's own request logging
/// (<c>Middleware.cs</c>) does not record query strings or bodies either.
/// </summary>
public sealed class McpToolRunner
{
    private readonly McpAccess _access;
    private readonly IHttpContextAccessor _http;
    private readonly ILogger<McpToolRunner> _log;
    private readonly McpConnectionsExperience _calls;

    public McpToolRunner(McpAccess access, IHttpContextAccessor http, ILogger<McpToolRunner> log, McpConnectionsExperience calls)
    {
        _access = access;
        _http = http;
        _log = log;
        _calls = calls;
    }

    /// <summary>
    /// Writes the call-log line shown on the "AI tool connections" screen (tool, person or key, outcome, refusal sentence, duration - never arguments or
    /// results). A failure here is swallowed: the log must never fail or change the answer to the tool call.
    /// </summary>
    private async Task RecordAsync(ClaimsPrincipal user, string tool, string outcome, string? reason, DateTime started)
    {
        try
        {
            var isKey = user.HasClaim(c => c.Type == "api_key_id");
            var actor = Guid.TryParse(user.FindFirst(isKey ? "api_key_id" : "id")?.Value, out var id) ? id : Guid.Empty;
            if (user.OrgId() is not Guid orgId || actor == Guid.Empty) return;     // no organization to file it under
            await _calls.RecordCallAsync(orgId, tool, isKey, actor, outcome, reason, (int)(DateTime.UtcNow - started).TotalMilliseconds);
        }
        catch (Exception e)
        {
            _log.LogWarning("mcp call log write failed type={ExceptionType}", e.GetType().Name);
        }
    }

    public const string UnexpectedError = "Something went wrong reading that. Try again; if it keeps happening, ask an administrator to check the server log.";

    public async Task<CallToolResult> RunAsync(string tool, Func<McpCaller, Task<McpToolResult>> body, CancellationToken ct)
    {
        var started = DateTime.UtcNow;
        var user = _http.HttpContext?.User ?? new ClaimsPrincipal();
        var resolution = await _access.ResolveAsync(user, tool, ct);
        if (resolution.Caller is not { } caller)
        {
            _log.LogInformation("mcp tool={Tool} outcome=refused reason=gate", tool);
            await RecordAsync(user, tool, McpCallOutcomes.Refused, resolution.Refusal, started);
            return Error(resolution.Refusal ?? "Not allowed.");
        }

        var kind = caller.IsApiKey ? "key" : "person";
        try
        {
            var result = await body(caller);
            _log.LogInformation("mcp tool={Tool} caller={Kind} id={ActorId} org={OrgId} outcome={Outcome} ms={Ms}",
                tool, kind, caller.ActorId, caller.OrgId, result.IsRefusal ? "refused" : "ok", (int)(DateTime.UtcNow - started).TotalMilliseconds);
            await RecordAsync(user, tool, result.IsRefusal ? McpCallOutcomes.Refused : McpCallOutcomes.Ok, result.IsRefusal ? result.Refusal : null, started);
            return result.Json is not null ? Ok(result.Json) : Error(result.Refusal ?? "Not allowed.");
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception e)
        {
            // The exception TYPE only: its message can carry a value from a query.
            _log.LogError("mcp tool={Tool} caller={Kind} id={ActorId} org={OrgId} outcome=error type={ExceptionType}", tool, kind, caller.ActorId, caller.OrgId, e.GetType().Name);
            await RecordAsync(user, tool, McpCallOutcomes.Error, $"Unexpected error ({e.GetType().Name})", started);
            return Error(UnexpectedError);
        }
    }

    private static CallToolResult Ok(string json) => new() { Content = [new TextContentBlock { Text = json }] };

    private static CallToolResult Error(string message) => new() { IsError = true, Content = [new TextContentBlock { Text = message }] };
}

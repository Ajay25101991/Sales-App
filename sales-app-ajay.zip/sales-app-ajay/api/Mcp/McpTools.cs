using System.ComponentModel;
using System.Text.Json;
using ModelContextProtocol.Protocol;
using ModelContextProtocol.Server;
using SalesApi.ExperienceLayer.Mcp;
using SalesApi.Services;

namespace SalesApi.McpServer;

/// <summary>
/// The CRM's MCP tools (owner decisions 2026-11-17, to-do/mcp-server-design.md), served at <c>/mcp</c>. This class holds ONLY what the MCP SDK needs: each
/// tool's name, its description for an AI reader, its input schema (from the parameters) and its annotations. Every body is one call into
/// <see cref="McpExperience"/> -> the Process call the app already makes, run by <see cref="McpToolRunner"/> under the caller <c>McpAccess</c> resolved
/// (plan feature, permission or API-key scope, rate limit, the person's or the key's masking). There is no read, filter or figure in this file.
///
/// EVERY tool is marked read-only (<c>readOnlyHint</c>) EXCEPT <c>suggest_field_value</c> (<see cref="McpToolCatalogue.WriteTools"/>), which saves a SUGGESTION a person
/// accepts or rejects in the app and changes no record. <c>draft_email</c> returns text and saves and sends nothing.
/// </summary>
[McpServerToolType]
public sealed class McpTools
{
    private readonly McpToolRunner _run;
    private readonly McpExperience _crm;

    public McpTools(McpToolRunner run, McpExperience crm)
    {
        _run = run;
        _crm = crm;
    }

    private const string RecordTypeHelp = "One of: deal, account, contact (see list_record_types).";

    // ---- find and read -------------------------------------------------------------------------------------------

    [McpServerTool(Name = McpToolCatalogue.Names.Search, Title = "Search the CRM", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("Full-text search across the deals, accounts, contacts, quotes and invoices you may see. Returns short matches with ids; use get_deal, get_account or get_contact for the full record.")]
    public Task<CallToolResult> Search(
        [Description("Search text, at least 2 characters.")] string query,
        [Description("Optional: limit to these result groups: lead (deals), account, contact, quote, invoice.")] string[]? types = null,
        CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.Search, c => _crm.SearchAsync(c, query, types, ct), ct);

    [McpServerTool(Name = McpToolCatalogue.Names.GetDeal, Title = "Get a deal", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("One deal (lead) by id, exactly as it shows for you: contact details and values you may not see come back hidden or masked.")]
    public Task<CallToolResult> GetDeal([Description("The deal id.")] Guid deal_id, CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.GetDeal, c => _crm.GetDealAsync(c, deal_id, ct), ct);

    [McpServerTool(Name = McpToolCatalogue.Names.GetAccount, Title = "Get an account", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("One account (company) by id with its contacts, deals, invoices and AMCs, masked for you as in the app.")]
    public Task<CallToolResult> GetAccount([Description("The account id.")] Guid account_id, CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.GetAccount, c => _crm.GetAccountAsync(c, account_id, ct), ct);

    [McpServerTool(Name = McpToolCatalogue.Names.GetContact, Title = "Get a contact", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("One contact (a person at an account) by id, masked for you as in the app.")]
    public Task<CallToolResult> GetContact([Description("The contact id.")] Guid contact_id, CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.GetContact, c => _crm.GetContactAsync(c, contact_id, ct), ct);

    // ---- text and summaries --------------------------------------------------------------------------------------

    [McpServerTool(Name = McpToolCatalogue.Names.DraftEmail, Title = "Draft an email", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("Draft an email subject and body for a deal from templates with merge fields such as {{lead.name}}, {{lead.company}}, {{lead.owner_name}}, {{lead.email}}, {{lead.phone}}, {{lead.next_follow_up_at}}. Returns the text only: nothing is saved or sent.")]
    public Task<CallToolResult> DraftEmail(
        [Description("The deal id.")] Guid deal_id,
        [Description("Subject template, e.g. \"Following up, {{lead.name}}\".")] string subject_template,
        [Description("Body template.")] string body_template,
        CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.DraftEmail, c => _crm.DraftEmailAsync(c, deal_id, subject_template, body_template, ct), ct);

    [McpServerTool(Name = McpToolCatalogue.Names.DealBrief, Title = "Deal brief", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("The CRM's AI brief of one deal: momentum, summary, reasons and a suggested next action, written from the deal's own timeline. May say there is not enough history yet.")]
    public Task<CallToolResult> DealBrief([Description("The deal id.")] Guid deal_id, CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.DealBrief, c => _crm.DealBriefAsync(c, deal_id, ct), ct);

    [McpServerTool(Name = McpToolCatalogue.Names.AccountSummary, Title = "Account summary", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("An account at a glance: the account, its contacts, deals, invoices and AMCs, and its ten newest activity items.")]
    public Task<CallToolResult> AccountSummary([Description("The account id.")] Guid account_id, CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.AccountSummary, c => _crm.AccountSummaryAsync(c, account_id, ct), ct);

    [McpServerTool(Name = McpToolCatalogue.Names.PipelineSummary, Title = "Pipeline summary", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("The dashboard figures for the people and teams you may see: pipeline by stage, wins, targets and the like, from the stored aggregates.")]
    public Task<CallToolResult> PipelineSummary(
        [Description("week, month (default), year or all.")] string? period = null,
        [Description("Optional: only this team's figures (a team id from list_teams).")] Guid? team_id = null,
        CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.PipelineSummary, c => _crm.PipelineSummaryAsync(c, period, team_id, ct), ct);

    // ---- describe and list ---------------------------------------------------------------------------------------

    [McpServerTool(Name = McpToolCatalogue.Names.ListRecordTypes, Title = "List record types", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("The kinds of records you can list and filter (deals, accounts, contacts). Start here, then describe_record_type.")]
    public Task<CallToolResult> ListRecordTypes(CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.ListRecordTypes, c => _crm.ListRecordTypesAsync(c), ct);

    [McpServerTool(Name = McpToolCatalogue.Names.DescribeRecordType, Title = "Describe a record type", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("The fields of a record type, including this organization's custom fields: type, operators you can filter with, choice lists, whether required, and which fields you cannot see. Use the field keys in list_records.")]
    public Task<CallToolResult> DescribeRecordType([Description(RecordTypeHelp)] string record_type, CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.DescribeRecordType, c => _crm.DescribeRecordTypeAsync(c, record_type, ct), ct);

    [McpServerTool(Name = McpToolCatalogue.Names.ListRecords, Title = "List records", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("List records with filters, sorting and paging, the same way the app's tables do. filters is an array of {field, conditions:[{join:'and'|'or', op, value, value2, values}]}; conditions on one field combine left to right (and before or), different fields combine with and. Use field keys and operators from describe_record_type. Returns items and next_cursor; pass it back as cursor for the next page.")]
    public Task<CallToolResult> ListRecords(
        [Description(RecordTypeHelp)] string record_type,
        [Description("Optional text in the search box.")] string? search = null,
        [Description("Optional filters, see the tool description.")] JsonElement? filters = null,
        [Description("Optional sorts: [{field, dir:'asc'|'desc'}], up to five.")] JsonElement? sorts = null,
        [Description("Page size, 1 to 100 (default 25).")] int? limit = null,
        [Description("The next_cursor of the previous page.")] string? cursor = null,
        CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.ListRecords,
            c => _crm.ListRecordsAsync(c, record_type, search, RawJson(filters), RawJson(sorts), limit, cursor, ct), ct);

    private static string? RawJson(JsonElement? e) =>
        e is { ValueKind: not (JsonValueKind.Null or JsonValueKind.Undefined) } v ? v.GetRawText() : null;

    // ---- links, history, workflow, people ------------------------------------------------------------------------

    [McpServerTool(Name = McpToolCatalogue.Names.ListLinkedRecords, Title = "List linked records", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("What a record is linked to: a deal's contacts with their roles (stakeholders), or an account's contacts and deals.")]
    public Task<CallToolResult> ListLinkedRecords(
        [Description("deal or account.")] string record_type, [Description("The record id.")] Guid id, CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.ListLinkedRecords, c => _crm.ListLinkedAsync(c, record_type, id, ct), ct);

    [McpServerTool(Name = McpToolCatalogue.Names.GetTimeline, Title = "Get a timeline", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("A deal's or account's activity timeline, newest first: stage changes, logged activities and emails, reminders, quotes, invoices, payments, field changes. Paged: pass next_cursor back as cursor.")]
    public Task<CallToolResult> GetTimeline(
        [Description("deal or account.")] string record_type,
        [Description("The record id.")] Guid id,
        [Description("Optional: comma-separated groups to include: activity, stage, money, changes.")] string? kinds = null,
        [Description("Page size, 1 to 100 (default 25).")] int? limit = null,
        [Description("The next_cursor of the previous page.")] string? cursor = null,
        [Description("Accounts only: 'all' (default, includes the account's deals) or 'account' (the account's own items).")] string? scope = null,
        CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.GetTimeline, c => _crm.GetTimelineAsync(c, record_type, id, cursor, limit, kinds, scope, ct), ct);

    [McpServerTool(Name = McpToolCatalogue.Names.ListWorkflows, Title = "List workflows", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("The workflows (playbooks) you can see and the stages of each, plus the default pipeline for deals with no workflow. A deal's stage is always one of its own workflow's stages.")]
    public Task<CallToolResult> ListWorkflows(CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.ListWorkflows, c => _crm.ListWorkflowsAsync(c, ct), ct);

    [McpServerTool(Name = McpToolCatalogue.Names.ListUsers, Title = "List users", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("The active people in the organization: name, role and teams only (no email or phone).")]
    public Task<CallToolResult> ListUsers(CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.ListUsers, c => _crm.ListUsersAsync(c, ct), ct);

    [McpServerTool(Name = McpToolCatalogue.Names.ListTeams, Title = "List teams", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("The teams in the organization with their member counts.")]
    public Task<CallToolResult> ListTeams(CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.ListTeams, c => _crm.ListTeamsAsync(c, ct), ct);

    // ---- enrichment ----------------------------------------------------------------------------------------------

    [McpServerTool(Name = McpToolCatalogue.Names.EnrichmentContext, Title = "Enrichment context", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("What the CRM already knows about a company (account) or contact, and which of the fields you can see are empty, so you can research the gaps. Does not change anything.")]
    public Task<CallToolResult> EnrichmentContext(
        [Description("account or contact.")] string record_type, [Description("The record id.")] Guid id, CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.EnrichmentContext, c => _crm.EnrichmentContextAsync(c, record_type, id, ct), ct);

    // ---- the one write: a suggestion -----------------------------------------------------------------------------

    [McpServerTool(Name = McpToolCatalogue.Names.SuggestFieldValue, Title = "Suggest a field value", ReadOnly = false, Destructive = false, Idempotent = false, OpenWorld = false)]
    [Description("Propose a value for one field of a deal, account or contact (for example a company's industry or website, or a deal's estimated_value or notes). This does NOT change the record: it saves a suggestion that a person in the CRM accepts or rejects. Use fields and custom.<key> names from describe_record_type; a field you cannot see is refused. A deal accepts its contact details, estimated_value (a non-negative number) and notes. Returns the suggestion's id, field and status, or the reason it was refused.")]
    public Task<CallToolResult> SuggestFieldValue(
        [Description(RecordTypeHelp)] string record_type,
        [Description("The record id.")] Guid id,
        [Description("The field key, e.g. industry, website, phone, estimated_value, notes, or custom.<key>.")] string field,
        [Description("The suggested value: text, or a number for estimated_value, or the type the custom field takes.")] JsonElement value,
        [Description("Optional: where the value came from, in a sentence (shown to the person deciding).")] string? note = null,
        [Description("Optional: the web address the value was found at.")] string? source_url = null,
        CancellationToken ct = default) =>
        _run.RunAsync(McpToolCatalogue.Names.SuggestFieldValue, c => _crm.SuggestFieldValueAsync(c, record_type, id, field, value, note, source_url, ct), ct);
}

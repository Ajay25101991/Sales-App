using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SalesApi.Data;
using SalesApi.Services;

using System.IO.Compression;
using Microsoft.AspNetCore.ResponseCompression;

var builder = WebApplication.CreateBuilder(args);

// Hosted platforms (Render, Railway, Fly, …) inject the listening port.
var port = Environment.GetEnvironmentVariable("PORT");
if (!string.IsNullOrEmpty(port))
    builder.WebHost.UseUrls($"http://+:{port}");

// Database (EF Core + Npgsql, snake_case naming to match Postgres conventions).
// Prefer DATABASE_URL (managed Postgres) if present, else the local conn string.
// Per-request tenant (org) resolved from the JWT; injected into AppDbContext for
// the multi-tenant query filter + insert stamping.
builder.Services.AddHttpContextAccessor();
// Scopes must be PRINTED or step 6 ships an id nobody can see. The default
// console provider drops them silently, so this replaces it with the same
// provider configured to include them — ClearProviders first, because adding a
// second console provider would double every line rather than change it.
builder.Logging.ClearProviders();
builder.Logging.AddSimpleConsole(o =>
{
    o.IncludeScopes = true;
    o.SingleLine = true;
});

// One id per request, injectable at any layer and stamped into every log line
// downstream by RequestIdMiddleware's logging scope (API-led migration step 6).
builder.Services.AddScoped<SalesApi.Services.CorrelationContext>();

// The signed-in caller's id, filled by ActorContextMiddleware right after
// UseAuthentication — E1 event backbone design §6. Null outside a request
// (background workers set their own scope's copy explicitly).
builder.Services.AddScoped<SalesApi.Services.ActorContext>();
// Loop prevention (E2.3, design doc §5) — same ambient, request/scope-lived
// shape as ActorContext above, but set programmatically by AutomationRunner
// rather than by a middleware (there is no HTTP request to read it from: a
// background dispatch pass and a signed-in request share this exact pattern).
builder.Services.AddScoped<SalesApi.Services.AutomationRunContext>();

// Layering round 2 (H3, owner decision 2026-09-30) — injectable twins of the
// static StageService/PlaybookPhases/PeopleScope/TeamService/LeadWorkStatusService
// helpers, scoped like AppDbContext so a Process class can depend on one of
// these instead of AppDbContext itself. See each class's own doc comment.
builder.Services.AddScoped<SalesApi.Services.PipelineStages>();
builder.Services.AddScoped<SalesApi.Services.PlaybookPhaseLoader>();
builder.Services.AddScoped<SalesApi.Services.PeopleScopeReader>();
builder.Services.AddScoped<SalesApi.Services.TeamMembershipService>();
builder.Services.AddScoped<SalesApi.Services.LeadWorkStatusReader>();
// Layering round 2 (owner decision 2026-09-30, to-do/epics-ai-native-crm.md "Layering
// plan change"): the static System helpers gain injectable, scoped wrappers so
// ProcessApi classes can depend on these instead of AppDbContext directly. Same
// scoped lifetime as AppDbContext so a Process class's resolve stays inside the same
// unit of work as its own save.
builder.Services.AddScoped<SalesApi.Services.ReportingCalendarService>();
builder.Services.AddScoped<SalesApi.Services.MoneyFormatService>();
builder.Services.AddScoped<SalesApi.Services.RecordAccessContextFactory>();
// Layering round 2 (helpers-events-settings, owner decision 2026-09-30):
// injectable fronts for the static DomainEvents/OrgSettings helpers, scoped
// like AppDbContext so a Raise/read inside a Process class's own SaveChanges
// stays in that same unit of work. See each class's doc comment.
builder.Services.AddScoped<SalesApi.Services.DomainEventWriter>();
// Stamps / settles a record's files when the record is deleted (DeletedRecordFiles.cs) - injected into the five delete sites.
builder.Services.AddScoped<SalesApi.Services.RecordFileRetention>();
builder.Services.AddScoped<SalesApi.Services.OrgSettingsReader>();
// Layering round 4 (owner decision 2026-09-30): injectable front for the
// static ReminderSweeper helper, same reasoning/lifetime as above.
builder.Services.AddScoped<SalesApi.Services.ReminderSweepRunner>();
builder.Services.AddScoped<SalesApi.Services.CanonicalStageReader>();
// Layering round 3 (owner decision 2026-09-30): injectable fronts for the
// remaining six static System helpers (MeasureRegistry, CycleTime,
// DealStatsService, ForecastService, QualificationService/QualificationAuditService,
// ExploreService), same scoped lifetime as AppDbContext. See each class's doc comment.
builder.Services.AddScoped<SalesApi.Services.MeasureCalculator>();
builder.Services.AddScoped<SalesApi.Services.CycleTimeReader>();
builder.Services.AddScoped<SalesApi.Services.DealStatsCalculator>();
builder.Services.AddScoped<SalesApi.Services.ForecastReader>();
builder.Services.AddScoped<SalesApi.Services.QualificationReader>();
builder.Services.AddScoped<SalesApi.Services.QualificationAuditReader>();
builder.Services.AddScoped<SalesApi.Services.ExploreReader>();
// Layering round 4 (G2, owner decision 2026-09-30): injectable fronts for the
// remaining static System helpers used by Amcs/Approvals/CollectionTasks/
// Collections/Invoices/Quotes/Loyalty/Plans/WhatsApp/AiPlatform's Process
// classes, same scoped lifetime as AppDbContext. See each class's doc comment.
builder.Services.AddScoped<SalesApi.Services.AmcServiceReader>();
builder.Services.AddScoped<SalesApi.Services.LoyaltyPolicyReader>();
builder.Services.AddScoped<SalesApi.Services.LoyaltyTierReader>();
builder.Services.AddScoped<SalesApi.Services.LoyaltyLedgerWriter>();
builder.Services.AddScoped<SalesApi.Services.StagePhasesLoader>();
builder.Services.AddScoped<SalesApi.Services.StageGateReader>();
builder.Services.AddScoped<SalesApi.Services.InvoiceOwnershipService>();
builder.Services.AddScoped<SalesApi.Services.ReopenSettingsReader>();
builder.Services.AddScoped<SalesApi.Services.PaymentWorkflowReader>();
builder.Services.AddScoped<SalesApi.Services.PlaybookPostWinReader>();
builder.Services.AddScoped<SalesApi.Services.DomainEventPayloadReader>();
builder.Services.AddScoped<SalesApi.Services.GateEscalationSettingsReader>();
builder.Services.AddScoped<SalesApi.Services.PaymentSettlementService>();
builder.Services.AddScoped<SalesApi.Services.CollectionReminderReader>();
builder.Services.AddScoped<SalesApi.Services.PlanUsageReader>();
builder.Services.AddScoped<SalesApi.Services.CollectionTaskCreator>();

// Step 8's parallel batch: four more domains migrated to System + Process.
// None of them grew an Experience class, and that is the finding rather than an
// omission — every one returns the shape its endpoint already returned, so
// there was nothing for an Experience layer to reshape. A layer added because
// the pattern says so is scaffolding.
// Settings — the 19 endpoints whose accessors live on OrgSettings. The other
// ~15 groups have their own dedicated services and are not migrated yet.
builder.Services.AddScoped<SalesApi.SystemLayer.Accounts.AccountStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Accounts.AccountProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Accounts.AccountsExperience>();

builder.Services.AddScoped<SalesApi.SystemLayer.People.PeopleStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.People.PeopleProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.People.PeopleExperience>();

builder.Services.AddScoped<SalesApi.SystemLayer.Settings.SettingsStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Settings.SettingsProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Settings.SettingsExperience>();

builder.Services.AddScoped<SalesApi.SystemLayer.Invoices.InvoiceStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Invoices.InvoiceProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Invoices.InvoicesExperience>();

builder.Services.AddScoped<SalesApi.SystemLayer.AccountingSync.AccountingSyncStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.AccountingSync.AccountingSyncProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.AccountingSync.AccountingSyncExperience>();

builder.Services.AddScoped<SalesApi.SystemLayer.Roles.RoleStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Roles.RoleProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Roles.RolesExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.LeadForms.LeadFormLibraryStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.LeadForms.LeadFormLibraryProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.LeadForms.LeadFormLibraryExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Attachments.AttachmentStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Attachments.AttachmentProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Attachments.AttachmentsExperience>();
// Client-document reading (to-do/proposal-deck-port-scope.md decisions 6/10/11): pending values from a client's licence / VAT certificate /
// signatory documents, confirmed by a person into the account's custom fields. The OCR runner is a singleton (one read at a time, server-wide)
// behind an interface; the worker that reads queued files is in the RUN_WORKERS block.
builder.Services.AddSingleton<SalesApi.Services.IExternalProcess, SalesApi.Services.OsExternalProcess>();
builder.Services.AddSingleton<SalesApi.Services.IDocumentTextExtractor, SalesApi.Services.OsDocumentTextExtractor>();
builder.Services.AddScoped<SalesApi.SystemLayer.ClientDocuments.ClientDocumentStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ClientDocuments.ClientDocumentProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ClientDocuments.ClientDocumentsExperience>();
// E15.1 document register.
builder.Services.AddScoped<SalesApi.SystemLayer.DocumentRegister.DocumentRegisterStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.DocumentRegister.DocumentRegisterProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.DocumentRegister.DocumentRegisterExperience>();
// E15.5 sanctions screening. The providers: "manual" first; an API provider adds its IScreeningProvider here.
builder.Services.AddSingleton<SalesApi.SystemLayer.Screening.IScreeningProvider, SalesApi.SystemLayer.Screening.ManualScreeningProvider>();
builder.Services.AddSingleton<SalesApi.SystemLayer.Screening.ScreeningProviders>();
builder.Services.AddScoped<SalesApi.SystemLayer.Screening.ScreeningStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Screening.ScreeningProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Screening.ScreeningExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Notifications.NotificationStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Notifications.NotificationProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Notifications.NotificationsExperience>();

// The tail: small CRUD, the integration/public surfaces, and auth.
builder.Services.AddScoped<SalesApi.SystemLayer.Contacts.ContactStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Contacts.ContactProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Contacts.ContactsExperience>();
// E16.1 - contact opt-out per channel + the consent log.
builder.Services.AddScoped<SalesApi.SystemLayer.Contacts.ContactConsentStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Contacts.ContactConsentProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Contacts.ContactConsentExperience>();
// E21 - email campaigns: store -> processes (screens, send queue, public feedback, admin settings) -> experiences, then the marketing sender and its public-door helpers.
// Marketing mail goes through SES only (MarketingEmailResolver); credentials are the default AWS chain (the ECS task role), never configuration.
builder.Services.AddScoped<SalesApi.SystemLayer.Campaigns.CampaignStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Campaigns.CampaignProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Campaigns.CampaignSendProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Campaigns.CampaignFeedbackProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Campaigns.CampaignSettingsProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Campaigns.CampaignsExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Campaigns.CampaignFeedbackExperience>();
builder.Services.AddScoped<SalesApi.Services.MarketingEmailResolver>();
builder.Services.AddSingleton<SalesApi.Services.ISesMailClient, SalesApi.Services.AwsSesMailClient>();
builder.Services.AddSingleton<SalesApi.Services.UnsubscribeTokenService>();
builder.Services.AddHttpClient(SalesApi.Services.HttpSnsGateway.HttpClientName);
builder.Services.AddSingleton<SalesApi.Services.ISnsGateway, SalesApi.Services.HttpSnsGateway>();
builder.Services.AddScoped<SalesApi.Services.SnsMessageVerifier>();
// E3.3 — deal stakeholders.
builder.Services.AddScoped<SalesApi.SystemLayer.Stakeholders.StakeholderStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Stakeholders.StakeholderProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Stakeholders.StakeholdersExperience>();
// Owner 2026-11-11 — a lead's recommended next actions for its current stage.
builder.Services.AddScoped<SalesApi.SystemLayer.Recommendations.LeadRecommendationStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Recommendations.LeadRecommendationProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Recommendations.LeadRecommendationsExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.StageValues.LeadStageValueStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.StageValues.LeadStageValueProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.StageValues.LeadStageValuesExperience>();
// E3.7 — a lead's methodology checklist.
builder.Services.AddScoped<SalesApi.SystemLayer.Qualification.LeadQualificationStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Qualification.LeadQualificationProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Qualification.LeadQualificationExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.UserProfile.ProfileStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.UserProfile.ProfileProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.UserProfile.ProfileExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.MessageTemplates.MessageTemplateStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.MessageTemplates.MessageTemplateProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.MessageTemplates.MessageTemplatesExperience>();
// E4.8 — per-org AI action risk policy.
builder.Services.AddScoped<SalesApi.SystemLayer.AiPlatform.AiActionPolicyStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.AiPlatform.AiActionPolicyProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.AiPlatform.AiActionPolicyExperience>();
// E4.4 — the prompt/skill registry. IAiSkillPublishGate is now the real
// evaluation harness (E4.9, slice 11): AiSkillEvaluator loads the embedded
// golden-set fixtures once per process (stateless, no DB — safe as a
// singleton); EvalPublishGate resolves per request since it needs a scoped
// AppDbContext to look up the skill's Key.
builder.Services.AddSingleton<SalesApi.Services.AiSkillEvaluator>();
builder.Services.AddScoped<SalesApi.Services.IAiSkillPublishGate, SalesApi.Services.EvalPublishGate>();
builder.Services.AddScoped<SalesApi.SystemLayer.AiPlatform.AiSkillStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.AiPlatform.AiSkillProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.AiPlatform.AiSkillExperience>();
// E4.5 — the context engine (design §5, §15 slice 7): a fan-out over
// LeadReadProcess's own governed reads, registered after it below.
builder.Services.AddScoped<SalesApi.Services.IAiContextEngine, SalesApi.ProcessLayer.AiPlatform.AiContextEngine>();
// E4.2 — execution log + opt-in text-capture toggle.
builder.Services.AddScoped<SalesApi.SystemLayer.AiPlatform.AiExecutionLogStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.AiPlatform.AiExecutionLogProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.AiPlatform.AiExecutionLogExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.DataAccessLog.DataAccessLogStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.DataAccessLog.DataAccessLogProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.DataAccessLog.DataAccessLogExperience>();
// E22.1 - personal-data export / erasure. PersonalDataService is a System service (like OrganizationOffboardingService), not a *Store.
builder.Services.AddScoped<PersonalDataService>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Privacy.PrivacyProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Privacy.PrivacyExperience>();
// E4.3 — cost policy (budget/cap/feature toggles/model prices).
builder.Services.AddScoped<SalesApi.SystemLayer.AiPlatform.AiCostPolicyStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.AiPlatform.AiCostPolicyProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.AiPlatform.AiCostPolicyExperience>();
// Phone storage (2026-09-30, owner) — Admin "Phone numbers to review" screen.
builder.Services.AddScoped<SalesApi.SystemLayer.PhoneReview.PhoneReviewStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.PhoneReview.PhoneReviewProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.PhoneReview.PhoneReviewExperience>();
// E7.6 — plans, features and usage limits.
builder.Services.AddScoped<SalesApi.SystemLayer.Plans.PlanStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Plans.PlanProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Plans.PlansExperience>();
// E5.1 — the deal/account brief (cached per lead+user) and E5's shared
// AI-feedback frame (design brief §3's "UserFeedback"; E5.0 design review
// decision 2's reject-reason policy).
builder.Services.AddScoped<SalesApi.SystemLayer.AiPlatform.LeadBriefStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.AiPlatform.LeadBriefProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.AiPlatform.LeadBriefExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.AiPlatform.AiFeedbackSettingsStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.AiPlatform.AiFeedbackProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.AiPlatform.AiFeedbackExperience>();
// E4.7 — the tool registry: IAiTool implementations (each a thin wrapper over
// one existing Process method — design §7.1, §15 slice 9), the invocation
// log, and AiToolExecutor's propose/execute split (design §7.2).
builder.Services.AddScoped<SalesApi.SystemLayer.AiPlatform.AiToolInvocationStore>();
builder.Services.AddScoped<SalesApi.Services.IAiTool, SalesApi.ProcessLayer.AiPlatform.Tools.SearchTool>();
builder.Services.AddScoped<SalesApi.Services.IAiTool, SalesApi.ProcessLayer.AiPlatform.Tools.GetLeadTool>();
builder.Services.AddScoped<SalesApi.Services.IAiTool, SalesApi.ProcessLayer.AiPlatform.Tools.GetAccountTool>();
builder.Services.AddScoped<SalesApi.Services.IAiTool, SalesApi.ProcessLayer.AiPlatform.Tools.GetContactTool>();
builder.Services.AddScoped<SalesApi.Services.IAiTool, SalesApi.ProcessLayer.AiPlatform.Tools.CreateTaskTool>();
builder.Services.AddScoped<SalesApi.Services.IAiTool, SalesApi.ProcessLayer.AiPlatform.Tools.CreateReminderTool>();
builder.Services.AddScoped<SalesApi.Services.IAiTool, SalesApi.ProcessLayer.AiPlatform.Tools.LogActivityTool>();
// Slice 10 — the remaining five tools (design §15 slice 10): draft_email
// (read-class), send_email, change_stage (through every existing gate),
// update_field, create_quote.
builder.Services.AddScoped<SalesApi.Services.IAiTool, SalesApi.ProcessLayer.AiPlatform.Tools.DraftEmailTool>();
builder.Services.AddScoped<SalesApi.Services.IAiTool, SalesApi.ProcessLayer.AiPlatform.Tools.SendEmailTool>();
builder.Services.AddScoped<SalesApi.Services.IAiTool, SalesApi.ProcessLayer.AiPlatform.Tools.ChangeStageTool>();
builder.Services.AddScoped<SalesApi.Services.IAiTool, SalesApi.ProcessLayer.AiPlatform.Tools.UpdateFieldTool>();
builder.Services.AddScoped<SalesApi.Services.IAiTool, SalesApi.ProcessLayer.AiPlatform.Tools.CreateQuoteTool>();
builder.Services.AddScoped<SalesApi.ProcessLayer.AiPlatform.AiToolExecutor>();
// E4.6 — knowledge collections (design §6, §15 slice 12).
builder.Services.AddScoped<SalesApi.SystemLayer.Knowledge.KnowledgeStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Knowledge.KnowledgeProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Knowledge.KnowledgeExperience>();
// Slice 10 — the SystemApi-declared seam AiToolApprovalResumeHandler resumes
// through, without SystemApi ever referencing ProcessApi (see
// IAiToolApprovalResumer's own class comment). Resolved to the SAME
// AiToolExecutor instance within a scope.
builder.Services.AddScoped<SalesApi.Services.IAiToolApprovalResumer>(
    sp => sp.GetRequiredService<SalesApi.ProcessLayer.AiPlatform.AiToolExecutor>());
// E5.6 — deal risk (to-do/epics-ai-native-crm.md E5.6): thresholds admin
// screen plus the per-lead read/compute. LeadRiskStore is also injected
// directly into LeadReadProcess/LeadListProcess (optional constructor params)
// so the lead read/list DTOs can carry risk_level — see those classes' own
// comments.
builder.Services.AddScoped<SalesApi.SystemLayer.AiPlatform.DealRiskSettingsStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.AiPlatform.DealRiskSettingsProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.AiPlatform.DealRiskSettingsExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.AiPlatform.LeadRiskStore>();
// DealRiskComputeService (System) does the actual recompute — see its own
// class doc for why it lives here rather than in ProcessApi. DealRiskProcess
// (Process) is only the permission-gated GET /leads/{id}/risk read.
builder.Services.AddScoped<SalesApi.Services.DealRiskComputeService>();
builder.Services.AddScoped<SalesApi.ProcessLayer.AiPlatform.DealRiskProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.AiPlatform.DealRiskExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.ApiKeys.ApiKeyStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ApiKeys.ApiKeyProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ApiKeys.ApiKeysExperience>();
// MCP server (owner decisions 2026-11-17, to-do/mcp-server-design.md): /mcp, Streamable HTTP, STATELESS (no session affinity - the API must not
// depend on running as one task). McpAccess is the one gate (plan feature "mcp", the ai_tools.connect permission or the key's scopes, the key's rate
// limit); the four Process classes are thin wrappers over reads the app already makes; McpTools (host) only declares names, schemas and annotations.
builder.Services.AddScoped<SalesApi.Services.McpAccess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mcp.McpReadProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mcp.McpSummaryProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mcp.McpDirectoryProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mcp.McpRecordsProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mcp.McpSuggestProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Mcp.McpExperience>();
// "AI tool connections" admin screen + the call log McpToolRunner writes (to-do/mcp-server-design.md item 10).
builder.Services.AddScoped<SalesApi.SystemLayer.Mcp.McpCallStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mcp.McpConnectionsProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Mcp.McpConnectionsExperience>();
builder.Services.AddScoped<SalesApi.McpServer.McpToolRunner>();
builder.Services
    .AddMcpServer()
    .WithHttpTransport(o => o.SessionMode = ModelContextProtocol.AspNetCore.HttpServerSessionMode.Stateless)
    .WithTools<SalesApi.McpServer.McpTools>();
// suggest_field_value (the one write: a suggestion) is a method on McpTools, so no second WithTools is needed.
builder.Services.AddScoped<SalesApi.SystemLayer.Integrations.IntegrationsStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Integrations.IntegrationsProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Integrations.IntegrationsExperience>();
// Integrations audit (to-do/integrations-audit.md): the incoming log (one shared writer for the public webhooks), the common "test
// connection", the needs-attention items, and the once-per-occurrence admin alert (IntegrationAlertService, run by IntegrationAlertWorker).
builder.Services.AddScoped<SalesApi.SystemLayer.Integrations.InboundWebhookEventStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Integrations.IntegrationAttentionStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Integrations.IntegrationEventsProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Integrations.IntegrationTestProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Integrations.IntegrationAttentionProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Integrations.IntegrationEventsExperience>();
builder.Services.AddScoped<SalesApi.Services.IntegrationAlertService>();
// E6.1/E6.2 mailbox sync (design doc to-do/e6-capture-design.md, slices 1-3).
// GraphDelegatedTokenCache and the GraphDelegatedToken HttpClient are
// registered below, beside GraphTokenCache, once IEmailSecretProtector exists.
builder.Services.AddScoped<SalesApi.SystemLayer.Mailbox.MailboxConnectionStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mailbox.MailboxOAuthProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Mailbox.MailboxExperience>();
// E6.1 story slice — settings (backfill/poll interval) and the sync engine.
// IGraphMailClient/its HttpClient and MailboxSyncWorker are registered below,
// beside the other Graph HttpClients / RUN_WORKERS-gated workers.
builder.Services.AddScoped<SalesApi.SystemLayer.Mailbox.MailboxSyncSettingsStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mailbox.MailboxSyncSettingsProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Mailbox.MailboxSyncSettingsExperience>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mailbox.MailboxSyncProcess>();
// Team mailboxes (owner decisions 2026-10-14, to-do/e6-capture-design.md §14): org-owned addresses read with the org's
// own app, the review list of unknown-sender email, and the sync that feeds both. IGraphSharedMailClient is registered
// below, beside IGraphMailClient.
builder.Services.AddScoped<SalesApi.SystemLayer.Mailbox.SharedMailboxStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Mailbox.EmailTriageStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Mailbox.MailLeadMatchStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mailbox.TeamMailboxIntakeProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mailbox.SharedMailboxSyncProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mailbox.SharedMailboxProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mailbox.EmailTriageProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Mailbox.SharedMailboxExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Mailbox.EmailTriageExperience>();
// E6.4 WhatsApp (design doc to-do/e6-connectors-design.md §3/§4/§11). The
// WhatsAppCloud HttpClient is registered below, beside the other named
// HttpClients.
builder.Services.AddScoped<SalesApi.SystemLayer.WhatsApp.WhatsAppSettingsStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.WhatsApp.WhatsAppConversationStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.WhatsApp.WhatsAppInboundStore>();
// E6.4 finish (design §3.4/§3.6 step 5/§3.7) — template cache, sent-message
// status, connection health.
builder.Services.AddScoped<SalesApi.SystemLayer.WhatsApp.WhatsAppTemplateStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.WhatsApp.WhatsAppOutboundMessageStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.WhatsApp.WhatsAppConnectionHealthStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.WhatsApp.WhatsAppSettingsProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.WhatsApp.WhatsAppTestConnectionProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.WhatsApp.WhatsAppSendProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.WhatsApp.WhatsAppInboundProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.WhatsApp.WhatsAppTriageProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.WhatsApp.WhatsAppTemplateSyncProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.WhatsApp.WhatsAppExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.WhatsApp.WhatsAppSettingsExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.WhatsApp.WhatsAppTriageExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.WhatsApp.WhatsAppTemplatesExperience>();
// E6.4 LinkedIn Lead Sync (design doc to-do/e6-connectors-design.md §6, §9
// slices 9-11). ILinkedInLeadSyncClient/its HttpClients and
// LinkedInLeadSyncWorker are registered below, beside the other named
// HttpClients / RUN_WORKERS-gated workers — same placement Mailbox uses.
builder.Services.AddScoped<SalesApi.SystemLayer.LinkedIn.LinkedInConnectionStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.LinkedIn.LinkedInFieldMappingStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.LinkedIn.LinkedInSyncSettingsStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.LinkedIn.LinkedInSyncedResponseStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.LinkedIn.LinkedInOAuthProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.LinkedIn.LinkedInFieldMappingProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.LinkedIn.LinkedInSyncSettingsProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.LinkedIn.LinkedInLeadSyncProcess>();
// E6 follow-up (design §12, owner answer 2026-09-29) — the form-picker
// endpoint's 5-minute cache is IMemoryCache, the first use of it in this
// API; scoped like every other LinkedIn Process class even though the
// underlying IMemoryCache registration is a singleton.
builder.Services.AddMemoryCache();
builder.Services.AddScoped<SalesApi.ProcessLayer.LinkedIn.LinkedInFormsProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.LinkedIn.LinkedInExperience>();

// Meta Lead Ads (Facebook / Instagram) - the LinkedIn connector's sibling (to-do/meta-lead-ads-design.md). The vendor-neutral half
// of intake is CapturedLeadWriter, shared with LinkedIn; MetaLeadAdsClient (named HttpClient) is registered with the other
// vendor clients below. No worker: leads arrive by signed webhook, and the backfill is an admin action.
builder.Services.AddScoped<SalesApi.SystemLayer.Meta.MetaConnectionStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Meta.MetaFormMappingStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Meta.MetaSyncedLeadStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Capture.CapturedLeadWriter>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Meta.MetaOAuthProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Meta.MetaLeadSyncProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Meta.MetaPagesProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Meta.MetaFormMappingProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Meta.MetaFormsProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Meta.MetaExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Organizations.OrganizationStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Organizations.OrganizationProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Organizations.OrganizationsExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Webhooks.WebhookStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Webhooks.WebhookProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Webhooks.WebhooksExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Public.PublicIntakeStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Public.PublicIntakeProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Public.PublicIntakeExperience>();
// One-time session-handoff codes (control panel to CRM) live in this process's memory: a SINGLETON, and a single-API-instance assumption (see HandoffCodeStore).
builder.Services.AddSingleton<SalesApi.Services.HandoffCodeStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Auth.AuthStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Auth.AuthProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Auth.AuthExperience>();
// MCP phase 2: OAuth so a person connects Claude / ChatGPT / Cursor with their own sign-in (to-do/mcp-server-design.md, item 12).
builder.Services.AddScoped<SalesApi.SystemLayer.OAuth.OAuthStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.OAuth.OAuthProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.OAuth.OAuthExperience>();
// E7.7 single sign-on with Microsoft (brief Part S). MicrosoftIdTokenValidator
// and the SsoToken/SsoJwks HttpClients are registered below, beside the
// other named HttpClients (same placement Mailbox/LinkedIn use).
builder.Services.AddScoped<SalesApi.SystemLayer.Sso.SsoStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Sso.MicrosoftIdTokenValidator>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Sso.SsoOAuthProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Sso.SsoSettingsProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Sso.SsoExperience>();

// Microsoft 365 umbrella — status + "Check access" (mirrors WhatsAppSettings*). The Entra
// credentials are the org-owned microsoft_365 connector (ConnectorConnectionService);
// MicrosoftAppReader is their only reader. The access checker's named HttpClient is
// registered beside the other Graph clients below.
builder.Services.AddScoped<SalesApi.Services.MicrosoftAppReader>();
builder.Services.AddScoped<SalesApi.SystemLayer.Microsoft365.Microsoft365SettingsStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Microsoft365.MicrosoftAccessChecker>();
builder.Services.AddScoped<SalesApi.SystemLayer.Microsoft365.SharePointAccessChecker>();
// "Move existing files to SharePoint": the job's state + queries (Store), the per-file move (System service), the
// start/stop/retry rules and the worker's pass (Process). The worker itself is registered in the RUN_WORKERS block.
builder.Services.AddScoped<SalesApi.SystemLayer.Microsoft365.SharePointMoveStore>();
builder.Services.AddScoped<SalesApi.Services.SharePointFileMover>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Microsoft365.SharePointMoveProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Microsoft365.Microsoft365SettingsProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Microsoft365.Microsoft365TestConnectionProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Microsoft365.Microsoft365SettingsExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.PartnerApi.PartnerApiStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.PartnerApi.PartnerApiProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.PartnerApi.PartnerApiExperience>();

builder.Services.AddScoped<SalesApi.SystemLayer.Dashboard.DashboardStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Dashboard.DashboardProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Dashboard.DashboardExperience>();

// Reports — first slice (movement). The rest of that controller is not
// migrated yet; see to-do/api-led-migration-plan.md.
// Layering tidy-up round 1 (2026-09-30, batch L2): these Process classes
// still take AppDbContext directly (aggregate-service statics like
// ReportingCalendar/StageService/MeasureRegistry/PeopleScope are not behind
// stores yet — the documented blanket AppDbContext exemption in
// LayerBoundaryTests), but their plain entity reads now go through a
// per-domain store.
builder.Services.AddScoped<SalesApi.SystemLayer.Reports.MovementStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Reports.ReportsStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Reports.TrendsStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Reports.LeaderboardStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Reports.MdPackStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Reports.ScorecardStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.Reports.NeedsYouTodayStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Reports.MovementProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Reports.ReportsProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Reports.TrendsProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Reports.LeaderboardProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Reports.MdPackProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Reports.ScorecardProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Reports.NeedsYouTodayProcess>();
// Layering tidy-up round 1 (L1, 2026-09-30) — Assign/Read/Merge/Quote no
// longer take AppDbContext directly; they take this store instead.
builder.Services.AddScoped<SalesApi.SystemLayer.Leads.LeadStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Leads.LeadMergeProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Leads.LeadQuoteProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Leads.LeadImportProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Leads.LeadReadProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Leads.LeadAssignProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Leads.LeadWriteProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Leads.LeadListProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Leads.LeadsExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Reports.ReportsExperience>();

// Custom reports, slice 1 (to-do/report-builder-design.md) — the breakdown
// engine, in its own vertical (new files, not ReportsController's) so it does
// not collide with the parallel GET /reports/estimated-vs-closed work in
// ReportsProcess/ReportsStore/ReportsController.
builder.Services.AddScoped<SalesApi.SystemLayer.CustomReports.CustomReportStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.CustomReports.ReportSourceRegistry>(); // E18.2: the non-lead report sources
builder.Services.AddScoped<SalesApi.ProcessLayer.CustomReports.CustomReportProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.CustomReports.CustomReportExperience>();

// Custom reports, slice 3 — saved/shared reports (table mode + saved-report
// CRUD), its own vertical beside the breakdown engine above.
builder.Services.AddScoped<SalesApi.SystemLayer.CustomReports.SavedReportStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.CustomReports.SavedReportProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.CustomReports.SavedReportsExperience>();

// Step 8's third parallel batch — AMCs, approvals, reminders, catalog items,
// proposals and proposal modules. Six domains, four agents, one worktree each.
builder.Services.AddScoped<SalesApi.SystemLayer.Amcs.AmcStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Amcs.AmcProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Amcs.AmcsExperience>();
// E13 After the win: the won-deal read. Reuses the invoice, AMC and engagement-letter stores; owns no table.
builder.Services.AddScoped<SalesApi.ProcessLayer.AfterWin.AfterWinProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.AfterWin.AfterWinExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Approvals.ApprovalStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Approvals.ApprovalProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Approvals.ApprovalsExperience>();
// E12.5 reveal requests: built on the approval chains above (store = ApprovalStore / ApprovalChainStore, no new store).
builder.Services.AddScoped<SalesApi.ProcessLayer.Approvals.RevealRequestProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Approvals.RevealRequestExperience>();
// E2.6 slice 9 — approval chains, layered above ApprovalRequest above.
builder.Services.AddScoped<SalesApi.SystemLayer.Approvals.ApprovalChainStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Approvals.ApprovalChainProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Approvals.ApprovalChainsExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Reminders.ReminderStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Reminders.ReminderProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Reminders.RemindersExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Tasks.TaskStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Tasks.TaskProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Tasks.TaskFileProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Tasks.TasksExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.CatalogItems.CatalogItemStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.CatalogItems.CatalogItemProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.CatalogItems.CatalogItemsExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.PricingModels.PricingModelStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.PricingModels.PricingModelProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.PricingModels.PricingModelsExperience>();
// E10.4 / E10.9 - deck and letter templates, and the renderer the proposal generator (E10.5) calls.
builder.Services.AddScoped<SalesApi.SystemLayer.DocumentTemplates.DocumentTemplateStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.DocumentTemplates.QuoteFilePublisher>();
builder.Services.AddScoped<SalesApi.Documents.ProposalFieldReader>();
builder.Services.AddScoped<SalesApi.ProcessLayer.DocumentTemplates.DocumentTemplateProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.DocumentTemplates.ProposalDocumentProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Proposals.ProposalGenerateProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Proposals.ProposalGenerationExperience>();
// E10.9 engagement letters: store, rep-side process (make / send / PDF / signed copy), the customer's accept link, and the experience over both.
builder.Services.AddScoped<SalesApi.SystemLayer.EngagementLetters.EngagementLetterStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.EngagementLetters.EngagementLetterProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.EngagementLetters.EngagementLetterAcceptProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.EngagementLetters.EngagementLetterExperience>();
// E-invoicing IRL: store, the rep's side (send / resend / revoke / reopen / read / upload a completed workbook), the client's public link, and the experience over both.
builder.Services.AddScoped<SalesApi.SystemLayer.Irl.IrlStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Irl.IrlRequestProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Irl.IrlPublicProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Irl.IrlExperience>();
// Delivery project from a workflow stage: the Suntech Delivery services list (connector reader, SSRF-guarded like every outbound webhook client), the deal's one
// project, and the webhook requests that reuse the org's lead.won subscription to the delivery tool. IMemoryCache (AddMemoryCache above) holds the services list.
builder.Services.AddHttpClient(SalesApi.Services.DeliveryConnectorClient.HttpClientName)
    .ConfigurePrimaryHttpMessageHandler(() =>
    {
        var handler = new SocketsHttpHandler();
        WebhookDestinationGuard.ConfigureHandler(handler);
        return handler;
    });
builder.Services.AddScoped<SalesApi.Services.DeliveryConnectorClient>();
builder.Services.AddScoped<SalesApi.SystemLayer.Delivery.DeliveryProjectStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Delivery.DeliveryProjectProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Delivery.DeliveryProjectExperience>();
// E15 document requests: an account-level ask for missing KYC documents on a secure link (replaces the IRL-based request-missing).
builder.Services.AddScoped<SalesApi.SystemLayer.DocumentRequests.DocumentRequestStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.DocumentRequests.DocumentRequestProcess>();
// E19.2 - record change requests (portal users' proposed edits to accounts and contacts, approved by staff). Not the E7.4 ChangeRequest* classes above.
builder.Services.AddScoped<SalesApi.SystemLayer.RecordChangeRequests.RecordChangeRequestStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.RecordChangeRequests.RecordChangeRequestProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.RecordChangeRequests.RecordChangeRequestsExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.FieldSuggestions.FieldSuggestionStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.FieldSuggestions.FieldSuggestionProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.FieldSuggestions.FieldSuggestionsExperience>();
// E19.5 - self sign-up and application (public start/verify, the applicant's submit, the staff review queue, the purge sweep).
builder.Services.AddScoped<SalesApi.SystemLayer.SignUp.SignUpStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.SignUp.SignUpProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.SignUp.SignUpExperience>();
builder.Services.AddScoped<SalesApi.ProcessLayer.DocumentRequests.DocumentRequestPublicProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.DocumentRequests.DocumentRequestExperience>();

// E17.5 online payment: the Pay now link per invoice, the gateway (Stripe Checkout) behind IPaymentGateway, its signed callback and the reconciliation list.
// PayLinkIssuer is also what the notification dispatcher uses to add the link to an invoice email, so it is registered before the dispatcher is built.
builder.Services.AddHttpClient(SalesApi.Services.PaymentGatewayProvider.HttpClientName);
builder.Services.AddScoped<SalesApi.Services.PaymentGatewayProvider>();
builder.Services.AddScoped<SalesApi.Services.PayLinkIssuer>();
builder.Services.AddScoped<SalesApi.SystemLayer.OnlinePayments.OnlinePaymentStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.OnlinePayments.OnlinePaymentProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.OnlinePayments.OnlinePaymentPublicProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.OnlinePayments.OnlinePaymentWebhookProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.OnlinePayments.OnlinePaymentExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.DocumentTemplates.DocumentTemplatesExperience>();
// E12.6 in-CRM email compose: the shared mailbox opener (also used by the engagement letter), the record store, the process and its experience.
builder.Services.AddScoped<SalesApi.ProcessLayer.Mailbox.MailboxSendOpener>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mailbox.DealEmailSender>(); // the thread-pick + send + email.sent log shared by the engagement letter and the IRL request
builder.Services.AddScoped<SalesApi.SystemLayer.CompanyDocuments.CompanyDocumentStore>();   // the company documents library (attachable to every send)
builder.Services.AddScoped<SalesApi.ProcessLayer.CompanyDocuments.CompanyDocumentProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.CompanyDocuments.CompanyDocumentsExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Mailbox.RecordEmailStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Mailbox.EmailRecipientResolver>();   // refs <-> addresses for the To/CC/BCC pickers, with the masking rule
builder.Services.AddScoped<SalesApi.ProcessLayer.Mailbox.RecordEmailProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Mailbox.RecordEmailExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Proposals.ProposalStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Proposals.ProposalProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Proposals.ProposalsExperience>();

// Step 8's second parallel batch — four domains, each built in its own git
// worktree so their builds could not race (the first batch shared one tree and
// two of four agents lost their verification to it).
builder.Services.AddScoped<SalesApi.SystemLayer.CollectionTasks.CollectionTaskStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.CollectionTasks.CollectionTaskProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.CollectionTasks.CollectionTasksExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Workflows.WorkflowStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Workflows.WorkflowProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Workflows.WorkflowsExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Teams.TeamStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Teams.TeamProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Teams.TeamsExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Playbooks.PlaybookStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Playbooks.PlaybookProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Playbooks.PlaybooksExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Playbooks.PlaybookAssignmentStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Playbooks.PlaybookAssignmentProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Playbooks.PlaybookAssignmentExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Automations.AutomationStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Automations.AutomationProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Automations.AutomationsExperience>();
// E2.3 slices 3-4 (to-do/e2-automation-design.md §12, §6): the concrete
// action executor — calls TaskProcess/LeadWriteProcess/LeadAssignProcess/
// ReminderProcess/NotificationDispatcher/WebhookStore, so it lives in
// ProcessApi, registered against the SystemApi-declared
// SalesApi.Services.IAutomationActionExecutor interface AutomationRunner
// (SystemApi) depends on. See that interface's own class comment for why the
// indirection exists. branch/wait_n_days are NOT here — AutomationRunner
// handles both directly (see that class's own comment).
builder.Services.AddScoped<SalesApi.Services.IAutomationActionExecutor, SalesApi.ProcessLayer.Automations.AutomationActionExecutor>();
builder.Services.AddScoped<SalesApi.Services.AutomationRunner>();

builder.Services.AddScoped<SalesApi.ExperienceLayer.Goals.GoalsExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Collections.CollectionsExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Quotes.QuotesExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Tags.TagsExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.CustomFields.CustomFieldsExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Tags.TagStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Tags.TagProcess>();
builder.Services.AddScoped<SalesApi.SystemLayer.CustomFields.CustomFieldStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.CustomFields.CustomFieldProcess>();
// E3.6 — managed picklists. CustomFieldProcess also takes PicklistStore (a
// "picklist"-type custom field validates against one), so this must be
// registered before it is resolved.
builder.Services.AddScoped<SalesApi.SystemLayer.Picklists.PicklistStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Picklists.PicklistProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Picklists.PicklistsExperience>();
// E7.1 — configuration packages (flat items: custom fields, picklists, safe
// OrgSettings keys). design doc to-do/e7-config-platform-design.md §2/§8.
builder.Services.AddScoped<SalesApi.SystemLayer.Packages.PackageStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Packages.PackageExportProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Packages.PackageImportProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Packages.PackagesExperience>();
// E7.2 — templates + clone-from-org. design doc to-do/e7-config-platform-design.md §3/§8 slice 8.
builder.Services.AddScoped<SalesApi.ProcessLayer.Packages.PackageTemplateProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Packages.PackageCloneProcess>();
// E7.3 — sandbox org (create/refresh/delete/diff/promote). design doc
// to-do/e7-config-platform-design.md §4/§8 slices 10-11.
builder.Services.AddScoped<SalesApi.SystemLayer.Sandbox.SandboxStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Sandbox.SandboxProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Sandbox.SandboxExperience>();
// E7.4 — Studio onboarding checklist + go-live readiness. design doc
// to-do/e7-config-platform-design.md §5.2/§8 slice 14.
builder.Services.AddScoped<SalesApi.SystemLayer.Studio.StudioChecklistStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Studio.StudioChecklistProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Studio.StudioChecklistExperience>();
// E7.4 — change requests + customer approval (story slices 16-17). design
// doc to-do/e7-config-platform-design.md §5.4/§5.5.
builder.Services.AddScoped<SalesApi.SystemLayer.ChangeRequests.ChangeRequestStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChangeRequests.ChangeRequestProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ChangeRequests.ChangeRequestsExperience>();
// E7.4 — implementation studio: access, assignments, org/sandbox switching.
// design doc to-do/e7-config-platform-design.md §5.1/§8 slice 13.
// StudioProcess depends on ProfileProcess (registered above) to build the
// ProfileDto a switch response carries.
builder.Services.AddScoped<SalesApi.SystemLayer.Studio.StudioStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Studio.StudioProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Studio.StudioExperience>();
// E3.8 — saved views and column chooser.
builder.Services.AddScoped<SalesApi.SystemLayer.SavedViews.SavedViewStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.SavedViews.SavedViewProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.SavedViews.SavedViewsExperience>();
// E3.10 — "Email me this": owner-configured recurring delivery of the MD
// pack/leaderboard/scorecard. ReportScheduleProcess depends on the three
// report Process classes registered above (LeaderboardProcess, MdPackProcess,
// ScorecardProcess), never re-deriving their figures.
builder.Services.AddScoped<SalesApi.SystemLayer.ReportSchedules.ReportScheduleStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Reports.ReportScheduleProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ReportSchedules.ReportSchedulesExperience>();
// E3.9 — global search palette (desktop Ctrl+K). Reuses the account/contact/
// quote/invoice/lead stores already registered above.
builder.Services.AddScoped<SalesApi.ProcessLayer.Search.SearchProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Search.SearchExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Collections.CollectionStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Collections.CollectionProcess>();
builder.Services.AddScoped<SalesApi.SystemLayer.Quotes.QuoteStore>();
// E6.3 — quote-view tracking's own store, alongside QuoteStore.
builder.Services.AddScoped<SalesApi.SystemLayer.Quotes.QuoteViewStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Quotes.QuoteProcess>();

// The goals vertical (API-led migration step 8, second domain). No Experience
// class yet: the targets endpoints hand back the same shape they always did, so
// there is nothing for one to reshape — it arrives when a consumer wants
// something different, not before.
builder.Services.AddScoped<SalesApi.SystemLayer.Goals.GoalStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Goals.GoalProcess>();

// The loyalty vertical's three layers (API-led migration step 5). Scoped, like
// every other per-request service here: each holds an AppDbContext-derived
// dependency or another layer that does.
builder.Services.AddScoped<SalesApi.SystemLayer.Admin.PlatformStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Admin.PlatformProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Admin.AdminExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.Loyalty.LoyaltyStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Loyalty.LoyaltyStatusProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Loyalty.AccountLoyaltyExperience>();
// E20.2 - rewards per loyalty tier: benefit catalogue, entitlements per tier, usage ledger.
builder.Services.AddScoped<SalesApi.SystemLayer.Loyalty.LoyaltyBenefitStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Loyalty.LoyaltyBenefitProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Loyalty.LoyaltyBenefitExperience>();

// Channel partners, Phase 1 (to-do/partner-management-design.md). Three stores (profiles+plans, ledger+statements+stats, payouts), four Process classes, three
// Experience classes. NOT the Partner API (API-key integrations). The accrual itself runs inside AppDbContext.SaveChangesAsync (PartnerCapture); the reconciliation
// sweep is PartnerReconcileWorker in the RUN_WORKERS block.
builder.Services.AddScoped<SalesApi.SystemLayer.ChannelPartners.ChannelPartnerStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.ChannelPartners.PartnerLedgerStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.ChannelPartners.PartnerPayoutStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.ChannelPartnerProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.PartnerPlanProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.PartnerLedgerProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.PartnerPayoutProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ChannelPartners.ChannelPartnersExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ChannelPartners.PartnerMoneyExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ChannelPartners.PartnerPayoutsExperience>();
// Phase 4: the read-only partner portal and the channel team's portal-users panel (store -> process -> experience), then client usage.
builder.Services.AddScoped<SalesApi.SystemLayer.ChannelPartners.PartnerPortalStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.PartnerPortalProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.PartnerPortalUsersProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ChannelPartners.PartnerPortalExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ChannelPartners.PartnerPortalUsersExperience>();
// E19.1: what every portal kind shares (GET /portal/me, the customer scope walk). Reuses PartnerPortalStore + AccountStore, so there is no new store.
builder.Services.AddScoped<SalesApi.ProcessLayer.Portal.PortalProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Portal.PortalExperience>();
// E19.3: the customer portal's views (invoices, receipts, Pay now, KYC, requests). No store of its own: it reads through the invoice, collection-task, register, document-request and IRL stores.
builder.Services.AddScoped<SalesApi.ProcessLayer.Portal.CustomerPortalProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Portal.CustomerPortalExperience>();
builder.Services.AddScoped<SalesApi.SystemLayer.ChannelPartners.PartnerWhiteLabelStore>();   // white-label documents: injected (optionally) into ProposalDocumentProcess
builder.Services.AddScoped<SalesApi.SystemLayer.Usage.UsageStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Usage.UsageImportProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.Usage.UsageViewProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.Usage.UsageExperience>();
// Phase 2 (owner decisions 2026-10-19): registrations / pipeline flag / claim conflicts, an SI's milestones (cost), an FSP's remittance (receivable).
builder.Services.AddScoped<SalesApi.SystemLayer.ChannelPartners.PartnerRegistrationStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.ChannelPartners.PartnerMilestoneStore>();
builder.Services.AddScoped<SalesApi.SystemLayer.ChannelPartners.PartnerRemittanceStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.PartnerRegistrationProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.PartnerMilestoneProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.PartnerRemittanceProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ChannelPartners.PartnerRegistrationExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ChannelPartners.PartnerMilestoneExperience>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ChannelPartners.PartnerRemittanceExperience>();
// Phase 3 (bulk stock, the two named figures, distributor tiers). The draw itself is PartnerCapture job 4 (inside AppDbContext.SaveChangesAsync); the expiry sweep is in PartnerReconcileWorker.
// PartnerRevenueView is THE resolver of "end-client price" and "our revenue": the one definition every consumer calls.
builder.Services.AddScoped<SalesApi.Services.PartnerRevenueView>();
builder.Services.AddScoped<SalesApi.SystemLayer.ChannelPartners.PartnerStockStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.PartnerStockProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ChannelPartners.PartnerStockExperience>();
// Bulk partner upload (the partners file, the client sheet) and retrospective terms ("Partners to complete", back-pay preview) - to-do/partner-management-design.md section 11.
builder.Services.AddScoped<SalesApi.SystemLayer.ChannelPartners.PartnerBulkStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.PartnerBulkImportProcess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.PartnerCompletionProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ChannelPartners.PartnerBulkExperience>();
// Partner MoU net-margin model (to-do/partner-mou-net-margin-design.md): consumption, monthly statement, approve / void, report.
builder.Services.AddScoped<SalesApi.SystemLayer.ChannelPartners.PartnerMouStore>();
builder.Services.AddScoped<SalesApi.ProcessLayer.ChannelPartners.PartnerMouProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.ChannelPartners.PartnerMouExperience>();

builder.Services.AddScoped<CallerContext>();
builder.Services.AddScoped<ITenantProvider, TenantProvider>();

// Email. The RESOLVER is registered, never a concrete IEmailSender — which provider
// sends is decided per message from the org's own configuration, so an admin
// switching provider takes effect on the next email rather than the next deploy.
//
// Data Protection persistence: with no store configured, ASP.NET Core writes the
// key ring to the container filesystem, which is wiped on every ECS Fargate
// redeploy — every secret protected with the old key (the SMTP password and the
// Graph client secret on EmailProviderSetting, via DataProtectionEmailSecretProtector
// below) becomes permanently undecryptable the moment the container recycles.
// PersistKeysToDbContext<AppDbContext> stores the ring in Postgres instead, which
// survives redeploys identically to the rest of the app's data (AppDbContext also
// implements IDataProtectionKeyContext — see its class comment for why the tenant
// filter and audit log don't touch that table). SetApplicationName is REQUIRED and
// must stay literal/stable: Data Protection folds the app name into its purpose
// chain, so leaving it to the default (derived from the content-root path, which
// differs across hosting environments/containers) or letting it drift between
// deploys would silently invalidate every previously-protected secret — the exact
// failure this fix exists to remove, from a different angle.
builder.Services.AddDataProtection()
    .PersistKeysToDbContext<AppDbContext>()
    .SetApplicationName("SalesApi");
builder.Services.AddScoped<IEmailSecretProtector, DataProtectionEmailSecretProtector>();

// Microsoft Graph app-only mail send (the "graph" provider). Two named clients:
// one for the sendMail call itself, one for the Entra token endpoint — kept
// separate so a base-address/timeout change to one never accidentally touches
// the other. GraphTokenCache is a singleton (see its own doc comment for why);
// EmailProviderResolver is scoped and rebuilt per request, so it takes the
// cache as a dependency rather than owning one.
builder.Services.AddHttpClient(GraphEmailSender.SendHttpClientName);
builder.Services.AddHttpClient(GraphEmailSender.TokenHttpClientName);
builder.Services.AddSingleton<GraphTokenCache>();

// E6.1/E6.2 — delegated (authorization-code + PKCE) Graph tokens, ONE PER
// REP, never shared across users (see GraphDelegatedTokenCache's own doc
// comment for why this is NOT GraphTokenCache and NOT a singleton — it
// caches on the MailboxConnection row via MailboxConnectionStore instead of
// an in-memory dictionary, so it is registered Scoped like that store).
builder.Services.AddHttpClient(GraphDelegatedTokenCache.TokenHttpClientName);
builder.Services.AddScoped<GraphDelegatedTokenCache>();

// E7.7 — the Microsoft sign-in token-exchange call and the tenant JWKS
// fetch, two named HttpClients for the same "one path never accidentally
// touches another" reasoning as GraphEmailSender's Send/Token clients above.
builder.Services.AddHttpClient(SalesApi.ProcessLayer.Sso.SsoOAuthProcess.TokenHttpClientName);
builder.Services.AddHttpClient(SalesApi.SystemLayer.Microsoft365.MicrosoftAccessChecker.HttpClientName);
builder.Services.AddHttpClient(SalesApi.SystemLayer.Sso.MicrosoftIdTokenValidator.JwksHttpClientName);

// E6.1 story slice 4 — the delta-query read client (Inbox + Sent Items),
// kept as its own named HttpClient for the same "one path never accidentally
// touches another" reasoning as the two clients above.
builder.Services.AddHttpClient(GraphMailClient.MailHttpClientName);
builder.Services.AddScoped<IGraphMailClient>(sp =>
    new GraphMailClient(sp.GetRequiredService<IHttpClientFactory>().CreateClient(GraphMailClient.MailHttpClientName)));
// Team mailboxes: the same class on the same named client, read through its app-only /users/{address} interface.
// E10.9: sending as the rep from their own mailbox, on the same client class and HttpClient.
builder.Services.AddScoped<IGraphMailSendClient>(sp =>
    new GraphMailClient(sp.GetRequiredService<IHttpClientFactory>().CreateClient(GraphMailClient.MailHttpClientName)));
// "Reply" on a logged email: a draft in the rep's own mailbox (same client class and HttpClient).
builder.Services.AddScoped<IGraphMailDraftClient>(sp =>
    new GraphMailClient(sp.GetRequiredService<IHttpClientFactory>().CreateClient(GraphMailClient.MailHttpClientName)));
builder.Services.AddScoped<IGraphSharedMailClient>(sp =>
    new GraphMailClient(sp.GetRequiredService<IHttpClientFactory>().CreateClient(GraphMailClient.MailHttpClientName)));

// SharePoint storage (to-do/microsoft-365-sharepoint-design.md §5) - the files client over the org's app-only
// token. Own named HttpClient (same reasoning as GraphMailClient above), with redirects OFF: a download answers
// 302 to a pre-authenticated URL that must be fetched without the bearer token, so the client follows it by hand.
builder.Services.AddHttpClient(GraphSharePointClient.HttpClientName)
    .ConfigurePrimaryHttpMessageHandler(() => new SocketsHttpHandler { AllowAutoRedirect = false });
builder.Services.AddScoped<IGraphSharePointClient>(sp =>
    new GraphSharePointClient(sp.GetRequiredService<IHttpClientFactory>().CreateClient(GraphSharePointClient.HttpClientName)));

// SharePoint browsing / linking (Phase 4) - the DELEGATED read client: the caller's own token, one person at a time. Own
// named HttpClient; redirects OFF so a bearer token can never follow a redirect anywhere.
builder.Services.AddHttpClient(GraphSharePointBrowseClient.HttpClientName)
    .ConfigurePrimaryHttpMessageHandler(() => new SocketsHttpHandler { AllowAutoRedirect = false });
builder.Services.AddScoped<IGraphSharePointBrowseClient>(sp =>
    new GraphSharePointBrowseClient(sp.GetRequiredService<IHttpClientFactory>().CreateClient(GraphSharePointBrowseClient.HttpClientName)));
builder.Services.AddScoped<SalesApi.SystemLayer.Microsoft365.SharePointBrowseAccess>();
builder.Services.AddScoped<SalesApi.ProcessLayer.SharePointBrowse.SharePointBrowseProcess>();
builder.Services.AddScoped<SalesApi.ExperienceLayer.SharePointBrowse.SharePointBrowseExperience>();

// E6.2 story slice 10 (design §6/§9) — the calendar delta-query read client,
// same "own named HttpClient" reasoning as GraphMailClient above.
builder.Services.AddHttpClient(GraphCalendarClient.CalendarHttpClientName);
builder.Services.AddScoped<IGraphCalendarClient>(sp =>
    new GraphCalendarClient(sp.GetRequiredService<IHttpClientFactory>().CreateClient(GraphCalendarClient.CalendarHttpClientName)));

// E6.4 — the WhatsApp Cloud API typed HttpClient (design §2 — "no SDK",
// same reasoning GraphEmailSender's HttpClients get).
builder.Services.AddHttpClient(WhatsAppCloudClient.HttpClientName);
builder.Services.AddScoped<IWhatsAppCloudClient>(sp =>
    new WhatsAppCloudClient(sp.GetRequiredService<IHttpClientFactory>().CreateClient(WhatsAppCloudClient.HttpClientName)));

builder.Services.AddScoped<EmailProviderResolver>();
builder.Services.AddScoped<ConnectorConnectionService>();
builder.Services.AddScoped<InvoicePdfAttacher>();   // E17.1: the invoice PDF an automatic invoice email carries
builder.Services.AddScoped<NotificationDispatcher>();

// E6.4 — LinkedIn OAuth token exchange and the Lead Sync poll client, two
// named HttpClients for the same "one path never accidentally touches
// another" reasoning as GraphEmailSender's Send/Token clients above.
builder.Services.AddHttpClient(SalesApi.ProcessLayer.LinkedIn.LinkedInOAuthProcess.HttpClientName);
builder.Services.AddHttpClient(SalesApi.Services.LinkedInLeadSyncClient.HttpClientName);
builder.Services.AddScoped<SalesApi.Services.ILinkedInLeadSyncClient, SalesApi.Services.LinkedInLeadSyncClient>();
// Meta Lead Ads - the Graph API client (one HttpClient; the API version is a single constant on the client).
builder.Services.AddHttpClient(SalesApi.Services.MetaLeadAdsClient.HttpClientName);
builder.Services.AddScoped<SalesApi.Services.IMetaLeadAdsClient, SalesApi.Services.MetaLeadAdsClient>();

// E4.1 AI gateway (slices 1-2, design doc to-do/e4-ai-platform-design.md §2).
// StubAiPlatform is stateless/deterministic (no fixtures depend on request
// state), so it is a singleton the scoped resolver takes as a dependency —
// same "singleton service, scoped resolver" shape as GraphTokenCache above.
builder.Services.AddSingleton<StubAiPlatform>();
builder.Services.AddScoped<AiProviderResolver>();
builder.Services.AddScoped<AiAvailability>();

builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseNpgsql(BuildConnectionString(builder.Configuration))
       .UseSnakeCaseNamingConvention());

// Attachment storage. Per-org now, not a single process-wide backend: an org
// picks its own current provider (Settings key "attachment_storage_provider",
// see AttachmentStorageService), and IAttachmentStorageResolver is the only
// thing application code asks for — it maps a provider id, or an attachment's
// own stamped Provider, to the right adapter. Both adapters are still built
// once each, the same lifetime the old singleton had; only the "which one"
// decision moved from startup to per-request/per-row.
//
// DefaultProvider mirrors exactly what the old singleton would have been:
// S3 when a bucket is configured (production), else a local folder (dev) —
// so a deployment where no org has ever changed its setting behaves exactly
// as it did before this feature existed.
var attachmentBucket = builder.Configuration["Storage:S3Bucket"];
builder.Services.AddSingleton<LocalAttachmentStorage>();
if (!string.IsNullOrWhiteSpace(attachmentBucket))
{
    builder.Services.AddSingleton<Amazon.S3.IAmazonS3>(_ => new Amazon.S3.AmazonS3Client());
    builder.Services.AddSingleton(sp =>
        new S3AttachmentStorage(sp.GetRequiredService<Amazon.S3.IAmazonS3>(), attachmentBucket));
}
builder.Services.AddSingleton<SharePointStorageFactory>();
builder.Services.AddSingleton<IAttachmentStorageResolver>(sp => new AttachmentStorageResolver(
    sp.GetRequiredService<LocalAttachmentStorage>(),
    !string.IsNullOrWhiteSpace(attachmentBucket) ? sp.GetRequiredService<S3AttachmentStorage>() : null,
    defaultProvider: !string.IsNullOrWhiteSpace(attachmentBucket)
        ? AttachmentStorageResolver.S3
        : AttachmentStorageResolver.Local,
    sharePoint: sp.GetRequiredService<SharePointStorageFactory>()));

builder.Services.AddSingleton<JwtService>();
// Whether pg_trgm typo-tolerant search is available — set once at startup in
// DbInitializer.EnableTrigramSearchAsync, read by LeadsController.
builder.Services.AddSingleton<SearchCapabilities>();
builder.Services.AddScoped<OrganizationOffboardingService>();
// Per-org permission snapshots, short TTL. Singleton so one cache is shared by every
// request; it opens its own DI scope per refresh rather than borrowing a request's.
builder.Services.AddSingleton<OrgAuthorizationCache>();
builder.Services.AddScoped<OrganizationRoleService>();
builder.Services.AddScoped<RefreshTokenService>(); // scoped: holds the request's DbContext
builder.Services.AddScoped<InviteTokenService>(); // scoped: holds the request's DbContext
builder.Services.AddScoped<WorkflowService>();
// Background workers. Gated by RUN_WORKERS so a deployment can scale the API to more
// than one task without every task independently sweeping reminders and sending the
// same digest N times.
//
// It defaults to TRUE, not false, deliberately: today's deployment runs one service
// with no such variable set, and an opt-IN flag would silently stop every reminder,
// escalation and digest the moment this shipped. Opt-out is the safe direction — set
// RUN_WORKERS=false on additional API tasks, and keep exactly one task where it is
// unset or true.
var runWorkers = builder.Configuration.GetValue("RUN_WORKERS", true);
if (runWorkers)
{
    builder.Services.AddHostedService<ReminderSweepWorker>();
    builder.Services.AddHostedService<CollectionReminderWorker>();
    builder.Services.AddHostedService<DigestWorker>();
    builder.Services.AddHostedService<MonthlyReportWorker>();
    // E3.10 — "Email me this" scheduled delivery.
    builder.Services.AddHostedService<SalesApi.Services.ReportScheduleWorker>();
    // E21 - the email campaign send queue (a tick a second, throttled by the org's campaign_sends_per_second). Exactly one task sends.
    builder.Services.AddHostedService<SalesApi.Services.CampaignSendWorker>();
    builder.Services.AddHostedService<AmcReminderWorker>();
    // E15.5 - the staff reminder when a sanctions re-screen falls due (off unless the org sets rescreen_days).
    builder.Services.AddHostedService<ScreeningRescreenWorker>();
    builder.Services.AddHostedService<IdleLeadWorker>();
    builder.Services.AddHostedService<DealStatsWorker>();
    // Runs the per-org aggregate rebuild AFTER the app is serving, instead of
    // blocking startup with it — see AggregateRebuildWorker for why that was a
    // crash-loop waiting to happen at scale.
    builder.Services.AddHostedService<AggregateRebuildWorker>();
    builder.Services.AddHostedService<ForecastSnapshotWorker>();
    builder.Services.AddHostedService<DeferredEmailWorker>();
    builder.Services.AddHostedService<RefreshTokenSweepWorker>();
    builder.Services.AddHostedService<WebhookDeliveryWorker>();
    builder.Services.AddHostedService<CardScanRetentionWorker>();
    builder.Services.AddHostedService<DeletedRecordFilesWorker>();
    // E22.1 - carries out the erasures an org retention hold kept back, once the hold ends.
    builder.Services.AddHostedService<PrivacyErasureWorker>();
    // Nightly per-org retention purge for domain_events and
    // field_change_audit — design doc to-do/e1-event-backbone-design.md §2/§6/§8.
    builder.Services.AddHostedService<EventRetentionWorker>();
    // E4.2 — auto-deletes opt-in captured prompt/completion text once its
    // capture window ends (owner §17.4). See AiCapturedTextPurgeWorker.
    builder.Services.AddHostedService<AiCapturedTextPurgeWorker>();
    // E4.6 slice 12 — picks up pending knowledge documents and runs them
    // through extract/chunk/embed. Same RUN_WORKERS gate as every other
    // background worker.
    builder.Services.AddHostedService<KnowledgeIngestionWorker>();
    // E5.6 — the daily deal-risk sweep (story brief item 4): recomputes every
    // open lead in every org, once a day, regardless of the org's
    // recalculation-timing setting. Same RUN_WORKERS gate as every other
    // background worker.
    builder.Services.AddHostedService<DealRiskSweepWorker>();
    // E20.1 - the daily loyalty standing sweep: re-derives the stored balance and tier for an org on a rolling loyalty window, as points leave it.
    builder.Services.AddHostedService<LoyaltyStandingWorker>();
    // E19.5 - the daily purge of unsubmitted sign-up applications (and what they auto-created) past each org's purge days.
    builder.Services.AddHostedService<PortalSignUpPurgeWorker>();
    // Channel partners (design 3.9) - the reconciliation sweep behind the in-transaction accrual hook. Same RUN_WORKERS gate.
    builder.Services.AddHostedService<PartnerReconcileWorker>();
    // E1 event backbone (to-do/e1-event-backbone-design.md §3/§8 step 3):
    // drains domain_events per tenant per handler, same RUN_WORKERS gate as
    // every other background worker.
    builder.Services.AddHostedService<DomainEventDispatchWorker>();
    // Design doc to-do/e2-automation-design.md §6/§12 slice 4: resumes
    // wait_n_days pauses whose ResumeAt has passed — a durable row, not a
    // Task.Delay, so this is the ONLY place it continues from after a restart.
    builder.Services.AddHostedService<SalesApi.Services.AutomationWaitWorker>();
    // Design doc to-do/e2-automation-design.md §4/§12 slice 6: scan-driven
    // triggers (no_activity_for/date_reached/schedule/field_changed) — these
    // are not domain events, so they need their own periodic production, same
    // RUN_WORKERS gate as every other scheduled scan in this file.
    builder.Services.AddHostedService<SalesApi.Services.AutomationScanWorker>();
    // E6.1 story slice 4 (design §3.4) — per-connection mail sync on an
    // org-configurable poll interval. Same RUN_WORKERS gate as every other
    // background worker.
    builder.Services.AddHostedService<SalesApi.Services.MailboxSyncWorker>();
    // E6.4 story slice 11 (design §6.4) — per-org LinkedIn Lead Sync poll on
    // an org-configurable interval. Same RUN_WORKERS gate as every other
    // background worker.
    builder.Services.AddHostedService<SalesApi.Services.LinkedInLeadSyncWorker>();
    // Integrations audit (owner decision 6) - tells org admins once, in-app, when a webhook auto-pauses, an API key nears expiry or a
    // connector's sign-in expires. Same RUN_WORKERS gate as every other background worker.
    builder.Services.AddHostedService<SalesApi.Services.IntegrationAlertWorker>();
    // E6.4 finish, slice 5 (design §3.4) — re-syncs the Meta template cache
    // on a fixed interval. Same RUN_WORKERS gate as every other background
    // worker.
    builder.Services.AddHostedService<SalesApi.Services.WhatsAppTemplateSyncWorker>();
    // SharePoint program, phase 5 — carries out "Move existing files to SharePoint" for every org whose job is
    // running (state lives on the org's settings row, so a restart resumes it). Same RUN_WORKERS gate as the others.
    builder.Services.AddHostedService<SalesApi.Services.SharePointMoveWorker>();
    // Client-document reading — reads the doctype files waiting in read_state "queued" (OCR on this server, one at a time). Same RUN_WORKERS gate.
    builder.Services.AddHostedService<SalesApi.Services.ClientDocumentReadWorker>();
}
// The event backbone's registered consumers — design §3: "handlers are
// registered in Program.cs, same place every *Store/*Process is registered".
// DomainEventHandlerRegistrationTests fails the build on one written but not
// listed here, mirroring LayerRegistrationTests for the layered classes.
builder.Services.AddScoped<IDomainEventHandler, WebhookDomainEventHandler>();
// E1 step 5 (to-do/e1-event-backbone-design.md §5/§8 step 5): wave-1
// notifications, migrated off the inline NotifyAsync calls they used to be.
builder.Services.AddScoped<IDomainEventHandler, NotificationDomainEventHandler>();
// E2.2/E2.3 (to-do/e2-automation-design.md §3, §12 slices 2-3): trigger-
// matching for "event" triggers, logging AutomationRun rows, and (slice 3)
// executing each matched run's action list (via IAutomationActionExecutor,
// registered above).
builder.Services.AddScoped<IDomainEventHandler, AutomationDomainEventHandler>();
// Design doc to-do/e2-automation-design.md §12 slice 10: resumes a
// request_approval pause on ApprovalDecided — the event-driven counterpart to
// AutomationWaitWorker's time-based wait_n_days sweep (registered above).
builder.Services.AddScoped<IDomainEventHandler, AutomationApprovalResumeHandler>();
// Design doc to-do/e4-ai-platform-design.md §7.2/§15 slice 10: the AI-tool
// counterpart to AutomationApprovalResumeHandler above — resumes an
// AiToolInvocation paused on an 'approval' autonomy policy once its
// ApprovalRequest is decided.
builder.Services.AddScoped<IDomainEventHandler, AiToolApprovalResumeHandler>();
// E5.6 — the "on_change" recalculation timing (story brief item 4): recomputes
// a lead's deal risk on ActivityLogged/LeadStageChanged/Stakeholder* events,
// and always deletes the risk row on LeadClosedWon/LeadClosedLost regardless
// of timing. See DealRiskDomainEventHandler's own class doc.
builder.Services.AddScoped<IDomainEventHandler, DealRiskDomainEventHandler>();
// SharePoint storage: renames / moves the org's SharePoint folders when an account, lead, quote, invoice or AMC is
// renamed or a lead changes account (to-do/microsoft-365-sharepoint-design.md §5). A no-op for an org with no folders.
builder.Services.AddScoped<IDomainEventHandler, SharePointFolderEventHandler>();
// (The E13 handover handler is retired: HandoverToStageTasksBackfill moved every handover item into the stage-task list below.)
// Item 6: the tasks a workflow stage creates when a deal enters or leaves it (create_task action, working-day due dates, origin stored for the re-entry rule).
builder.Services.AddScoped<IDomainEventHandler, StageTaskDomainEventHandler>();
// Owner 2026-11-11: using a recommended action's linked action on a lead ticks it off for the lead's current stage entry.
builder.Services.AddScoped<IDomainEventHandler, RecommendationDomainEventHandler>();
// Bug 2: an accepted proposal moves the deal on when its stage says so (set_field status through the gated move), or tells the owner why it could not.
builder.Services.AddScoped<IDomainEventHandler, ProposalAcceptedDomainEventHandler>();
// Finance fix: a stage-triggered payment milestone is released (due date set, reminder made) when its stage is reached.
builder.Services.AddScoped<IDomainEventHandler, MilestoneStageDomainEventHandler>();
// Q12: a quote accepted after its valid-until date gets a "confirm the price" task for the deal's owner (create_task action, idempotent per deal + title).
builder.Services.AddScoped<IDomainEventHandler, QuoteExpiryDomainEventHandler>();
// E17.3: invoice.raised / payment.received -> pending accounting_sync_logs rows (orgs with an accounting connection only); the worker pushes them via IAccountingConnector.
builder.Services.AddSingleton<IAccountingConnector, LogOnlyAccountingConnector>();
builder.Services.AddSingleton<AccountingConnectors>();
builder.Services.AddScoped<IDomainEventHandler, AccountingSyncDomainEventHandler>();
// WebhookDestinationGuard.ConfigureHandler is the SSRF guard for every
// outbound webhook (admin subscriptions AND an automation's call_webhook
// action — both drain through this exact named client; see that class's own
// doc comment): refuses to connect to a loopback/private/link-local/CGNAT/
// unique-local/unspecified/multicast address (including IPv4-mapped forms),
// resolving DNS itself and connecting to the vetted address directly rather
// than letting the HTTP stack re-resolve the hostname, and never follows a
// redirect.
builder.Services.AddHttpClient(WebhookDeliveryWorker.HttpClientName)
    .ConfigurePrimaryHttpMessageHandler(() =>
    {
        var handler = new SocketsHttpHandler();
        WebhookDestinationGuard.ConfigureHandler(handler);
        return handler;
    });
builder.Services.AddHostedService<ProposalBillingWorker>();
builder.Services.AddHostedService<CollectionEscalationWorker>();

// JSON: snake_case property names to keep the exact API contract the app expects.
builder.Services.AddControllers(o => { o.Filters.Add<SalesApi.Services.ApiKeyRateLimitFilter>(); o.Filters.Add<SalesApi.Controllers.DataExportLogFilter>(); o.Filters.Add<SalesApi.Controllers.XlsxExportFilter>(); o.Filters.Add<SalesApi.Controllers.RevealReadLogFilter>(); }).AddJsonOptions(o =>
{
    o.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower;
    o.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.Never;
});

// JWT auth (HS256), keeping custom claims verbatim (id/email/role).
var secret = builder.Configuration["Jwt:Secret"] ?? "dev-super-secret-change-me-in-production-min-32-bytes";
builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(o =>
    {
        o.MapInboundClaims = false;
        o.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = false,
            ValidateAudience = false,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret)),
            ValidateLifetime = true,
        };
        // MCP authorization (2025-06-18): a 401 on /mcp must say where the protected resource metadata is (RFC 9728), so an AI tool can find the sign-in.
        // Every other path keeps the default bare challenge. The SDK's own McpAuthenticationHandler is not used: it is a second scheme with its own
        // metadata endpoint, and the metadata here is served by OAuthController from the same PublicBaseUrl as the rest of the OAuth documents.
        o.Events = new JwtBearerEvents
        {
            OnChallenge = ctx =>
            {
                if (!SalesApi.Services.McpOAuthUrls.IsMcpPath(ctx.Request.Path)) return Task.CompletedTask;
                ctx.HandleResponse();
                ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
                ctx.Response.Headers.WWWAuthenticate = SalesApi.Services.McpOAuthUrls.Challenge(
                    ctx.HttpContext.RequestServices.GetService<IConfiguration>(), ctx.Request, invalidToken: ctx.AuthenticateFailure is not null);
                return Task.CompletedTask;
            },
        };
    })
    // EP-25 partner integration: a SECOND scheme, additive only. The default
    // scheme above (what every existing [Authorize] with no explicit scheme
    // resolves to) is untouched — only PartnerApiController names "ApiKey"
    // explicitly, so no existing endpoint's authentication changes at all.
    .AddScheme<AuthenticationSchemeOptions, ApiKeyAuthenticationHandler>(
        ApiKeyAuthenticationDefaults.Scheme, _ => { });
builder.Services.AddAuthorization();

builder.Services.AddCors(o => o.AddDefaultPolicy(p => p
    .AllowAnyOrigin()
    .AllowAnyHeader()
    .AllowAnyMethod()
    // X-App-Version must be exposed or a cross-origin browser client cannot read
    // it, and the "a new version is available" check silently never fires.
    // X-Unknown-Query-Params (item 3, 2026-09-26 — QueryParamValidation) is the
    // same story for GET /leads and GET /accounts: a browser client can only
    // read it, not just see it in dev tools, if it is exposed here too.
    .WithExposedHeaders(
        "X-Offboarding-Receipt", "Content-Disposition", AppVersion.Header,
        QueryParamValidation.ResponseHeaderName)));

// Rate limiting: 300 req/min per IP globally; a stricter 50 req/15min on /auth.
// The API runs behind an ALB, so Connection.RemoteIpAddress is the load
// balancer, not the caller. Without this every request lands in the SAME rate
// limit partition below — the per-IP limits were effectively one shared bucket
// for the whole internet, so a burst from one source could 429 everyone else.
//
// X-Forwarded-For is only honoured from inside the VPC (10.0.0.0/16, see
// infra/aws/variables.tf). That restriction is the security-critical half:
// trusting the header from anywhere would let a caller spoof it and sidestep
// every limit by rotating fake addresses.
builder.Services.Configure<ForwardedHeadersOptions>(o =>
{
    o.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    o.ForwardLimit = 2;
    o.KnownNetworks.Clear();
    o.KnownProxies.Clear();
    // Fully qualified: System.Net also defines IPNetwork in .NET 8.
    o.KnownNetworks.Add(new Microsoft.AspNetCore.HttpOverrides.IPNetwork(IPAddress.Parse("10.0.0.0"), 16));
});

builder.Services.AddRateLimiter(options =>
{
    options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(ctx =>
        RateLimitPartition.GetFixedWindowLimiter(
            ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions { PermitLimit = 300, Window = TimeSpan.FromMinutes(1) }));
    options.AddFixedWindowLimiter("auth", o =>
    {
        o.PermitLimit = 50;
        o.Window = TimeSpan.FromMinutes(15);
    });
    // /auth/refresh is deliberately NOT on the "auth" policy above, and this is a
    // correctness point rather than a tuning preference: `AddFixedWindowLimiter`
    // creates ONE unpartitioned bucket shared by every caller. 50 per 15 minutes
    // is a sane budget for password attempts across the whole app; it is nowhere
    // near enough for refresh, which every signed-in rep performs on a timer once
    // the access token is 30 minutes long. Left on that policy, the first handful
    // of reps each hour would consume the bucket and everybody else would be 429'd
    // out of their session — the refresh mechanism would take the app down.
    //
    // Partitioned by caller IP, like the global limiter, so one noisy client
    // cannot exhaust anyone else's budget. 60 per 5 minutes is ~10x the legitimate
    // rate for a single device (one refresh per access-token lifetime, plus the
    // single-flight replay) while still capping a stolen-token grinder. The global
    // 300/min per-IP limiter applies on top of this.
    options.AddPolicy("auth-refresh", ctx =>
        RateLimitPartition.GetFixedWindowLimiter(
            ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions { PermitLimit = 60, Window = TimeSpan.FromMinutes(5) }));
    // Public website intake (PublicController). Anonymous and internet-facing,
    // so it gets a tighter budget than the global default: a site posting from
    // its own backend uses one address and nowhere near this, while a leaked
    // key or a bot is capped well before it can flood the pipeline.
    // E-invoicing IRL public link (IrlPublicController). Anonymous and token-gated; partitioned by caller IP like the global limiter. Higher than
    // public-intake because the page AUTOSAVES as the client types, but far below the global 300/min so a bot guessing tokens is stopped early.
    options.AddPolicy("irl-public", ctx =>
        RateLimitPartition.GetFixedWindowLimiter(
            ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions { PermitLimit = 120, Window = TimeSpan.FromMinutes(1) }));
    // E19.5 self sign-up (PublicSignUpController). Anonymous and internet-facing with NO captcha (owner decision 2026-11-05), so the budget is the protection: partitioned by caller
    // IP (like the global limiter), far below it. A person signing up uses three calls (options, start, verify); a script trying to flood mailboxes or guess tokens is stopped early.
    options.AddPolicy("portal-signup", ctx =>
        RateLimitPartition.GetFixedWindowLimiter(
            ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions { PermitLimit = 20, Window = TimeSpan.FromMinutes(15) }));
    // Partitioned PER API KEY (SHA-256 of the X-Api-Key header, so the key itself is never held as a dictionary key or logged) so one noisy
    // website cannot use up another org's 60/min; a request with no key is partitioned by caller IP. Same budget as before (60/min); the
    // global per-IP limiter still caps a caller who rotates through invented keys. The per-key budget for the SCOPED partner API is a different,
    // org-configurable limit (ApiKeyRateLimitFilter).
    options.AddPolicy("public-intake", ctx =>
    {
        var provided = ctx.Request.Headers["X-Api-Key"].FirstOrDefault();
        var partition = string.IsNullOrEmpty(provided)
            ? "ip:" + (ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown")
            : "key:" + SalesApi.Services.ApiKeyHasher.Hash(provided);
        return RateLimitPartition.GetFixedWindowLimiter(
            partition, _ => new FixedWindowRateLimiterOptions { PermitLimit = 60, Window = TimeSpan.FromMinutes(1) });
    });
    // E6.4 WhatsApp webhook (design §3.7). NOT partitioned by caller IP —
    // Meta's own infrastructure calls from a shared, rotating address pool,
    // so per-IP partitioning would just as easily throttle Meta's own
    // legitimate traffic. Unpartitioned and higher than public-intake's
    // 60/min: a busy WABA can legitimately send far more than that across
    // many conversations (design §3.7's own reasoning). The signature check
    // (WhatsAppWebhookVerifier, checked before any of this fires downstream
    // logic) already rejects anything not genuinely from Meta — this is
    // defense-in-depth against a flood of garbage from someone who does NOT
    // have the app secret, not a limit on Meta's real traffic.
    // E17.5: the payment gateway's signed callback (POST /webhooks/payments/stripe/{connection_id}). Same budget and same reasoning as the WhatsApp one:
    // defense-in-depth against garbage from someone who does not hold the webhook secret, not a limit on the gateway's real traffic.
    options.AddFixedWindowLimiter("payment-webhook", o =>
    {
        o.PermitLimit = 600;
        o.Window = TimeSpan.FromMinutes(1);
    });
    options.AddFixedWindowLimiter("whatsapp-webhook", o =>
    {
        o.PermitLimit = 600;
        o.Window = TimeSpan.FromMinutes(1);
    });
    // Meta Lead Ads webhook (/webhooks/meta-lead-ads/{org_id}) - same budget and reasoning as the WhatsApp one: Meta's own rotating
    // address pool, the signature check is the real gate, this only bounds a flood of garbage.
    options.AddFixedWindowLimiter("meta-lead-webhook", o =>
    {
        o.PermitLimit = 600;
        o.Window = TimeSpan.FromMinutes(1);
    });
    // E21: the unsubscribe link and the SES feedback webhook (CampaignPublicController). Unpartitioned and generous, like the webhooks above: SNS calls from a shared
    // AWS address pool, and the unsubscribe token is an HMAC, so guessing one is hopeless; this only bounds a flood of garbage.
    options.AddFixedWindowLimiter("campaign-public", o =>
    {
        o.PermitLimit = 600;
        o.Window = TimeSpan.FromMinutes(1);
    });
    // /auth/accept-invite. Unauthenticated and token-gated, like /auth/refresh —
    // the token itself is 256 bits of CSPRNG output, so brute force is not a
    // realistic threat on its own, but this budget is the defense-in-depth
    // against a scripted guesser hammering the endpoint and against it being
    // used to grind through the "generic failure" responses looking for timing
    // or other side-channel tells. Partitioned by caller IP, same shape as
    // "auth-refresh"; a much smaller budget than that policy because a genuine
    // invitee redeems a link once, ever, not on a recurring timer.
    options.AddPolicy("invite-redeem", ctx =>
        RateLimitPartition.GetFixedWindowLimiter(
            ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions { PermitLimit = 20, Window = TimeSpan.FromMinutes(15) }));
    // E7.7 /auth/sso/start. Unauthenticated and internet-facing, like
    // /auth/signin's "auth" policy — same budget, own policy so a flood of
    // SSO-start probing (an enumeration attempt, even though the response
    // never leaks anything) cannot also exhaust password sign-in's own
    // bucket for the same caller IP.
    options.AddPolicy("sso-start", ctx =>
        RateLimitPartition.GetFixedWindowLimiter(
            ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions { PermitLimit = 50, Window = TimeSpan.FromMinutes(15) }));
    // /auth/sso/exchange. Same "auth-refresh" shape: the code itself is
    // single-use CSPRNG output (brute force is not the realistic threat), so
    // this is defense-in-depth against a scripted grinder, not the primary
    // protection.
    options.AddPolicy("sso-exchange", ctx =>
        RateLimitPartition.GetFixedWindowLimiter(
            ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions { PermitLimit = 60, Window = TimeSpan.FromMinutes(5) }));
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.OnRejected = async (context, token) =>
    {
        context.HttpContext.Response.StatusCode = StatusCodes.Status429TooManyRequests;
        await context.HttpContext.Response.WriteAsJsonAsync(new { error = "Too many requests" }, token);
    };
});

// Gzip/Brotli on API responses. The leads list is the motivating case: at
// roughly 910 bytes per lead a 100-row page is ~90KB on the wire uncompressed,
// and JSON of that shape compresses by an order of magnitude — a bigger win on
// a phone than any page-size tuning.
//
// EnableForHttps is deliberately left at its default (false). TLS terminates at
// the ALB and the container is reached over plain HTTP, so responses are
// compressed in practice; turning it on would only matter if the app ever
// served TLS directly, and it is off by default because compressing a secret
// alongside attacker-influenced text in one response is the BREACH oracle.
builder.Services.AddResponseCompression(options =>
{
    options.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(new[] { "application/json" });
});
builder.Services.Configure<BrotliCompressionProviderOptions>(o => o.Level = CompressionLevel.Fastest);
builder.Services.Configure<GzipCompressionProviderOptions>(o => o.Level = CompressionLevel.Fastest);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Apply migrations + seed on startup.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var searchCapabilities = scope.ServiceProvider.GetRequiredService<SearchCapabilities>();
    await DbInitializer.InitAsync(db, app.Configuration, searchCapabilities,
        scope.ServiceProvider.GetRequiredService<IEmailSecretProtector>(),
        scope.ServiceProvider.GetRequiredService<OrganizationRoleService>());
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Must run before anything that reads the client IP (rate limiting, logging):
// it rewrites Connection.RemoteIpAddress from the ALB's X-Forwarded-For.
app.UseForwardedHeaders();

// Security headers + request-id + logging run first, mirroring the Node stack.
app.UseResponseCompression();
app.UseMiddleware<SecurityHeadersMiddleware>();
app.UseMiddleware<RequestIdMiddleware>();
app.UseMiddleware<RequestLoggerMiddleware>();

// Serve the embedded browser apps baked into wwwroot/apps (see EmbeddedApps for
// which app owns which prefix, and why the order matters). Real assets are
// served by UseStaticFiles; any other path under those prefixes falls back to
// that app's index.html so client-side routing / deep links work.
// Cache policy per file — see StaticCachePolicy. Without it browsers cached
// index.html heuristically and kept users on the previous build after a deploy.
// The control panel host (ControlPanel:Host, see ControlPanelHost): wwwroot/apps/control served at the ROOT of its own host, same
// container and origin as the API. A request for a real file of that app ("/", "/assets/x.js") is mapped onto its folder BEFORE
// UseStaticFiles, so it gets the same cache policy; client routes fall back to its index.html via MapFallback at the end of the
// pipeline, so every controller / health route still wins on that host. On any other host this does nothing.
var controlHost = ControlPanelHost.Configured(app.Configuration);
var controlWebRoot = app.Environment.WebRootPath ?? Path.Combine(app.Environment.ContentRootPath, "wwwroot");
if (controlHost is not null)
{
    app.Use(async (ctx, next) =>
    {
        if (ControlPanelHost.Matches(controlHost, ctx.Request.Host)
            && (HttpMethods.IsGet(ctx.Request.Method) || HttpMethods.IsHead(ctx.Request.Method)))
        {
            var mapped = ControlPanelHost.Mapped(ctx.Request.Path);
            if (File.Exists(Path.Combine(controlWebRoot, mapped.Value!.TrimStart('/').Replace('/', Path.DirectorySeparatorChar))))
                ctx.Request.Path = mapped;
        }
        await next();
    });
}
app.UseStaticFiles(new StaticFileOptions
{
    OnPrepareResponse = sf =>
    {
        if (StaticCachePolicy.For(sf.Context.Request.Path.Value) is { } cacheControl)
            sf.Context.Response.Headers.CacheControl = cacheControl;
    },
});
var webRoot = app.Environment.WebRootPath ?? Path.Combine(app.Environment.ContentRootPath, "wwwroot");
app.Use(async (ctx, next) =>
{
    var name = EmbeddedApps.Owning(ctx.Request.Path.Value ?? "");
    if (name is not null)
    {
        var index = Path.Combine(webRoot, "apps", name, "index.html");
        if (File.Exists(index))
        {
            ctx.Response.ContentType = "text/html";
            // The SPA fallback serves the same entry page for every deep link, so it
            // needs the same revalidate-every-time rule as a direct index.html hit.
            ctx.Response.Headers.CacheControl = StaticCachePolicy.Revalidate;
            await ctx.Response.SendFileAsync(index);
            return;
        }
    }
    await next();
});

app.UseCors();
app.UseRateLimiter();
app.UseAuthentication();
// An AI-tool (OAuth) token works on /mcp only; refused everywhere else before any permission is read (MCP phase 2).
app.UseMiddleware<SalesApi.Services.McpTokenGuardMiddleware>();
// Fills the scoped ActorContext from the now-authenticated principal — must run
// after UseAuthentication (needs ctx.User populated) and before anything that
// might write (design §6: field-change audit / domain events read this).
app.UseMiddleware<SalesApi.Services.ActorContextMiddleware>();
app.UseMiddleware<OrganizationPermissionMiddleware>();
// E7.4 slice 19 (design doc §5.6) — refuses every mutating request while a
// Studio preview-as-role session is active. Must run after the permission
// middleware above (needs the hydrated/rejected principal) and before
// UseAuthorization()/routing (a refused write never reaches a controller).
app.UseMiddleware<SalesApi.Services.StudioPreviewMiddleware>();
app.UseAuthorization();

app.MapGet("/health", () => Results.Ok(new { status = "ok" })).WithMetadata(new AllowPartnerPortalAttribute(), new AllowCustomerPortalAttribute());
app.MapControllers();
// MCP endpoint: a person's normal JWT bearer OR an org API key (X-Api-Key) - each scheme only evaluates its own header, so a call carries one or the
// other (a call carrying both is refused by McpAccess). Phase 2 issues OAuth tokens that resolve to the same person principal.
app.MapMcp("/mcp").RequireAuthorization(new Microsoft.AspNetCore.Authorization.AuthorizeAttribute
{
    AuthenticationSchemes = $"{JwtBearerDefaults.AuthenticationScheme},{SalesApi.Services.ApiKeyAuthenticationDefaults.Scheme}",
});
if (controlHost is not null)
{
    // SPA fallback for the control host: only reached when no controller / health route matched (endpoint routing prefers them), so the
    // API stays reachable on this host. GET/HEAD only; any other method on an unknown path stays a 404.
    app.MapFallback(async ctx =>
    {
        var index = Path.Combine(controlWebRoot, "apps", ControlPanelHost.AppName, "index.html");
        if (!(HttpMethods.IsGet(ctx.Request.Method) || HttpMethods.IsHead(ctx.Request.Method)) || !File.Exists(index))
        {
            ctx.Response.StatusCode = StatusCodes.Status404NotFound;
            return;
        }
        ctx.Response.ContentType = "text/html";
        ctx.Response.Headers.CacheControl = StaticCachePolicy.Revalidate;
        await ctx.Response.SendFileAsync(index);
    }).RequireHost(controlHost);
}

app.Run();

// Converts a managed-Postgres DATABASE_URL (postgres://user:pass@host:port/db)
// to an Npgsql connection string; falls back to the local "Default" conn string.
static string BuildConnectionString(IConfiguration config)
{
    var url = Environment.GetEnvironmentVariable("DATABASE_URL");
    Npgsql.NpgsqlConnectionStringBuilder b;
    // The raw string as supplied, so ApplyPoolSizing can tell what was actually
    // set from what merely has a default. Empty for the DATABASE_URL path, which
    // is built from a URI and carries no pool keywords.
    var source = "";

    if (string.IsNullOrEmpty(url))
    {
        // Parsed rather than returned verbatim so the pool sizing below applies
        // to local runs too — dev and production diverging on connection
        // settings is how a limit gets tuned in one place and forgotten in the
        // other.
        source = config.GetConnectionString("Default")!;
        b = new Npgsql.NpgsqlConnectionStringBuilder(source);
    }
    else
    {
        var uri = new Uri(url);
        var userInfo = uri.UserInfo.Split(':', 2);
        b = new Npgsql.NpgsqlConnectionStringBuilder
        {
            Host = uri.Host,
            Port = uri.Port > 0 ? uri.Port : 5432,
            Username = Uri.UnescapeDataString(userInfo[0]),
            Password = userInfo.Length > 1 ? Uri.UnescapeDataString(userInfo[1]) : "",
            Database = uri.AbsolutePath.TrimStart('/'),
        };
        // SslMode.Require encrypts without validating the chain (fine for managed
        // Postgres like Render, whose certs are self-signed).
        if (Environment.GetEnvironmentVariable("DATABASE_SSL") == "true")
            b.SslMode = Npgsql.SslMode.Require;
    }

    ApplyPoolSizing(b, source);
    // Logged once per process: this runs for every connection set-up, so an unguarded
    // WriteLine repeated on nearly every request (CL-008).
    if (AppContext.GetData("SalesApi.DbPoolLogged") is null)
    {
        AppContext.SetData("SalesApi.DbPoolLogged", true);
        Console.WriteLine($"[db] pool {b.MinPoolSize}-{b.MaxPoolSize}, idle lifetime {b.ConnectionIdleLifetime}s");
    }
    return b.ConnectionString;
}

// Connection pool bounds, sized against the database rather than left at
// Npgsql's defaults.
//
// The default MaxPoolSize is 100 *per process*. A db.t4g.micro allows about 112
// connections (RDS computes LEAST(DBInstanceClassMemory/9531392, 5000)) with
// three reserved for superuser, so a single task could very nearly exhaust the
// server on its own — and ECS runs old and new tasks together during a rolling
// deploy, doubling it exactly when a release is going out. That fails as
// "remaining connection slots are reserved", which takes the API down wholesale
// rather than degrading.
//
// 20 is sized to what the app needs, not to what the server tolerates: an async
// .NET API saturates on a handful of connections per core, and the six
// BackgroundService workers share this same pool rather than opening their own.
// Extra slots buy no throughput, only new ways to exhaust the server. The rule
// to keep is `tasks x MaxPoolSize x 2 < max_connections` (the x2 covers a
// rolling deploy) — which caps this instance class at roughly two tasks. Past
// that the answer is a bigger instance or RDS Proxy, not a bigger pool.
//
// MinPoolSize is the half that actually removes handshake cost: Postgres
// connection setup (process fork, TLS, auth) is expensive, so keeping two warm
// means the first request after an idle spell doesn't pay for it. A large
// *maximum* does nothing for latency.
//
// Anything explicitly present in the source connection string wins, so an
// operator can still tune this per environment without a deploy.
//
// `provided` must be a plain DbConnectionStringBuilder over the raw string, NOT
// the Npgsql one: a strongly-typed builder reports ContainsKey == true for every
// keyword it knows about, supplied or not, so guarding on it silently never
// fires and every value below stays at the Npgsql default. That exact bug
// shipped here once already — it looked correct and logged "pool 0-100".
static void ApplyPoolSizing(Npgsql.NpgsqlConnectionStringBuilder b, string source)
{
    var provided = new System.Data.Common.DbConnectionStringBuilder { ConnectionString = source };
    // Npgsql accepts both the spaced and unspaced spellings; ContainsKey on the
    // base builder is case-insensitive but not alias-aware, so check both.
    bool Given(params string[] keys) => keys.Any(provided.ContainsKey);

    if (!Given("Maximum Pool Size", "MaxPoolSize")) b.MaxPoolSize = 20;
    if (!Given("Minimum Pool Size", "MinPoolSize")) b.MinPoolSize = 2;
    // Drop idle connections after 5 minutes so a traffic spike doesn't leave the
    // pool holding its high-water mark indefinitely.
    if (!Given("Connection Idle Lifetime", "ConnectionIdleLifetime")) b.ConnectionIdleLifetime = 300;
}

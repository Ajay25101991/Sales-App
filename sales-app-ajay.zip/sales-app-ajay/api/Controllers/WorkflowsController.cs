using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Workflows;
using SalesApi.ProcessLayer.Workflows;
using SalesApi.Services;

namespace SalesApi.Controllers;

// MIGRATED to the layered API (step 8). This controller keeps routing, auth
// and permission checks, model binding and status-code selection; the
// business rules — what counts as a legal workflow, what publishing does to
// leads on stages that are about to disappear, and the whole transactional
// remap — live in WorkflowProcess (via WorkflowsExperience) so a second
// caller (an importer, a migration script) gets the same guarantees an HTTP
// request does.
//
// Legacy path, preserved exactly: the desktop app has moved on to playbooks,
// but both phone clients still design pipelines through /workflows, so this
// migration changes nothing about what they see.
[ApiController]
[Authorize]
[Route("workflows")]
public class WorkflowsController : ControllerBase
{
    private readonly WorkflowsExperience _workflows;
    public WorkflowsController(WorkflowsExperience workflows) => _workflows = workflows;

    [HttpGet]
    public async Task<IActionResult> Get(CancellationToken ct) =>
        Ok(await _workflows.GetAllAsync(User.OrgId(), ct));

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] WorkflowInput input, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        if (User.OrgId() is not Guid orgId) return BadRequest(new { error = "Organization is required." });

        var (created, refusal) = await _workflows.CreateAsync(orgId, input, User.UserId(), ct);
        if (refusal is not null) return Refuse(refusal);
        return StatusCode(201, created);
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] WorkflowInput input, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        if (User.OrgId() is not Guid orgId) return BadRequest(new { error = "Organization is required." });

        var (updated, refusal) = await _workflows.UpdateAsync(orgId, id, input, ct);
        if (refusal is not null) return Refuse(refusal);
        return Ok(updated);
    }

    // What publishing this workflow would do to leads sitting on stages that
    // are about to disappear (and, for completeness, stages that are about to
    // appear). Every count/value comes straight from the leads table — the
    // designer must never estimate this client-side.
    [HttpGet("{id:guid}/publish-preview")]
    public async Task<IActionResult> PublishPreview(Guid id, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        if (User.OrgId() is not Guid orgId) return BadRequest(new { error = "Organization is required." });

        var showValue = User.HasPermission(OrganizationPermissions.ViewLeadValueTotals);
        var (preview, refusal) = await _workflows.PublishPreviewAsync(orgId, id, showValue, ct);
        if (refusal is not null) return Refuse(refusal);
        return Ok(preview);
    }

    [HttpPost("{id:guid}/publish")]
    public async Task<IActionResult> Publish(Guid id, [FromBody] PublishInput? input, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        if (User.OrgId() is not Guid orgId) return BadRequest(new { error = "Organization is required." });

        var showValue = User.HasPermission(OrganizationPermissions.ViewLeadValueTotals);
        var (published, refusal) = await _workflows.PublishAsync(orgId, id, input?.Remap, showValue, User.UserId(), ct);
        if (refusal is not null) return Refuse(refusal);
        return Ok(published);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        if (User.OrgId() is not Guid orgId) return BadRequest(new { error = "Organization is required." });

        var refusal = await _workflows.DeleteAsync(orgId, id, ct);
        if (refusal is not null) return Refuse(refusal);
        return NoContent();
    }

    private bool CanAuthor() => User.HasPermission(OrganizationPermissions.CreateWorkflows);
    private IActionResult Forbidden() => StatusCode(403, new { error = "Your role cannot create or publish workflows." });

    private IActionResult Refuse(WorkflowProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason })
        : refusal.Conflict ? Conflict(new { error = refusal.Reason })
        : BadRequest(new { error = refusal.Reason });
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Contacts;
using SalesApi.ProcessLayer.Contacts;
using SalesApi.Services;

namespace SalesApi.Controllers;

// MIGRATED to the layered API (api-led migration, step 8). The account-scoping
// rule that used to live inline here now lives in
// SalesApi.ProcessApi/Contacts/ContactProcess.cs, reached through
// SalesApi.ExperienceApi/Contacts/ContactsExperience.cs. What is left here,
// deliberately: routing, [Authorize]/[RequirePermission], resolving the
// caller's RecordAccessContext (a System-layer factory over the token + the
// database — the one place this controller still needs AppDbContext, same as
// AmcsController), model binding, and choosing the HTTP status for a Refusal.
[ApiController]
[Route("contacts")]
[Authorize]
[RequireSensitiveAccess(SensitiveCategories.ContactDetails)]
public class ContactsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly ContactsExperience _contacts;
    public ContactsController(CallerContext caller, ContactsExperience contacts)
    {
        _caller = caller;
        _contacts = contacts;
    }

    private Task<RecordAccessContext> AccessAsync() => _caller.ForAsync(User);

    private static IActionResult FromRefusal(ContactProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 403 }
        : refusal.Code == SensitiveWriteGuard.Code
            ? new BadRequestObjectResult(new { error = refusal.Reason, code = refusal.Code, fields = refusal.Fields })
        // The table's refusals (invalid_query, stale_cursor): the same body the accounts list answers with.
        : refusal.Code is not null
            ? new BadRequestObjectResult(new { error = refusal.Reason, code = refusal.Code, field = refusal.Field })
        : new BadRequestObjectResult(new { error = refusal.Reason });

    private static IActionResult FromTableRefusal(SalesApi.Services.TableQuery.TableQueryRefusedException e) =>
        new BadRequestObjectResult(new { error = e.Message, code = "invalid_query", field = e.Field });

    private bool CanViewContactDetails => User.HasPermission(OrganizationPermissions.ViewContactDetails);

    // GET /contacts - every contact the caller may see (its ACCOUNT's visibility), as a table. Same two calling conventions as
    // GET /accounts: `paged=true` + optional `cursor` -> keyset pages in a { items, next_cursor } envelope; otherwise a bare array
    // (offset/limit, everything when `limit` is omitted). `filters` / `sorts` are the one-table JSON (columns: GET /contacts/columns);
    // `search` is the box (name, company, title, account, and email when the caller reads it raw), typo-tolerant when pg_trgm is on.
    [HttpGet]
    public async Task<IActionResult> List(
        [FromQuery] string? search, [FromQuery] int? limit = null, [FromQuery] int? offset = null,
        [FromQuery] double? similarity = null, [FromQuery] bool paged = false, [FromQuery] string? cursor = null,
        [FromQuery] string? filters = null, [FromQuery] string? sorts = null)
    {
        var outcome = await _contacts.ListAsync(await AccessAsync(), CanViewContactDetails,
            new ContactProcess.ListParams(search, limit, offset, similarity, paged, cursor, filters, sorts), User.Role());
        if (outcome.Refusal is not null) return FromRefusal(outcome.Refusal);
        return Ok(paged ? new PagedResult<ContactListItemDto>(outcome.Items!, outcome.NextCursor) : outcome.Items);
    }

    // GET /contacts/count - total rows for the identical search and filters List uses, so a count can never disagree with the list.
    [HttpGet("count")]
    public async Task<IActionResult> Count(
        [FromQuery] string? search, [FromQuery] double? similarity = null, [FromQuery] string? filters = null)
    {
        try
        {
            var count = await _contacts.CountAsync(await AccessAsync(), CanViewContactDetails, search, similarity, filters, User.Role());
            return Ok(new { count });
        }
        catch (SalesApi.Services.TableQuery.TableQueryRefusedException e) { return FromTableRefusal(e); }
    }

    // GET /contacts/columns - the table's column catalogue for this caller (email / phone only with contact_details.view and, when
    // the role sees them masked, listed locked; custom fields only the ones their role may see).
    [HttpGet("columns")]
    public async Task<IActionResult> Columns() =>
        Ok(await _contacts.ColumnsAsync(await AccessAsync(), CanViewContactDetails, User.Role()));

    // GET /contacts/export - the filtered, sorted table as CSV (?format=xlsx for Excel via the global export filter). `ids` = "export
    // selected". Like GET /accounts/export it takes no search: the file is what `filters` / `sorts` show.
    [HttpGet("export")]
    [RequirePermission(OrganizationPermissions.CreateExports)]
    public async Task<IActionResult> Export([FromQuery] string? filters = null, [FromQuery] string? sorts = null, [FromQuery] string? ids = null)
    {
        try
        {
            List<Guid>? selected = string.IsNullOrWhiteSpace(ids) ? null
                : ids.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                    .Select(s => Guid.TryParse(s, out var g) ? (Guid?)g : null).Where(g => g is not null).Select(g => g!.Value).Distinct().ToList();
            var csv = await _contacts.ExportCsvAsync(await AccessAsync(), CanViewContactDetails, filters, sorts, User.Role(), selected);
            return Content(csv, "text/csv; charset=utf-8");
        }
        catch (SalesApi.Services.TableQuery.TableQueryRefusedException e) { return FromTableRefusal(e); }
    }

    // GET /contacts/{id} — E3.11d. Out-of-scope reads come back 404 (see
    // ContactProcess.GetAsync's own comment) — routed through FromRefusal
    // like every other action here, which already maps NotFound to 404.
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var outcome = await _contacts.GetAsync(await AccessAsync(), id, User.Role());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Detail);
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] ContactInput input)
    {
        var outcome = await _contacts.UpdateAsync(await AccessAsync(), id, input, User.Role());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Contact);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var outcome = await _contacts.DeleteAsync(await AccessAsync(), id);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : NoContent();
    }

    // GET /contacts/{id}/deals — E3.11's contact timeline: every deal for this
    // person, open and closed. Same lead_values.view masking every other
    // per-deal money figure in this API applies.
    [HttpGet("{id:guid}/deals")]
    public async Task<IActionResult> Deals(Guid id)
    {
        var outcome = await _contacts.DealsAsync(
            await AccessAsync(), id, User.HasPermission(OrganizationPermissions.ViewLeadValues));
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Deals);
    }

    // E16.1 - opt-out per channel. POST /contacts/{id}/opt-out and /opt-in (body {channel, reason}) return {opted_out: {channel: date}};
    // GET /contacts/{id}/consent-history is the append-only log. The experience is injected per action so the controller's
    // constructor (built by hand in many tests) is unchanged.
    [HttpPost("{id:guid}/opt-out")]
    public async Task<IActionResult> OptOut(Guid id, [FromBody] ContactOptOutInput input, [FromServices] ContactConsentExperience consent)
    {
        var outcome = await consent.OptOutAsync(await AccessAsync(), id, input);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.State);
    }

    [HttpPost("{id:guid}/opt-in")]
    public async Task<IActionResult> OptIn(Guid id, [FromBody] ContactOptOutInput input, [FromServices] ContactConsentExperience consent)
    {
        var outcome = await consent.OptInAsync(await AccessAsync(), id, input);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.State);
    }

    [HttpGet("{id:guid}/consent-history")]
    public async Task<IActionResult> ConsentHistory(Guid id, [FromServices] ContactConsentExperience consent)
    {
        var outcome = await consent.HistoryAsync(await AccessAsync(), id);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Entries);
    }

    // PUT /contacts/{id}/reports-to — E3.4. Null clears it.
    [HttpPut("{id:guid}/reports-to")]
    public async Task<IActionResult> SetReportsTo(Guid id, [FromBody] ContactReportsToInput input)
    {
        var outcome = await _contacts.SetReportsToAsync(await AccessAsync(), id, input.ReportsToContactId, User.Role());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Contact);
    }
}

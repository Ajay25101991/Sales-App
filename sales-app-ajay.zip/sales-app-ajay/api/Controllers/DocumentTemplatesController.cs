using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.ExperienceLayer.DocumentTemplates;
using SalesApi.ProcessLayer.DocumentTemplates;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E10.4 / E10.9 - uploaded proposal-deck (.pptx) and engagement-letter (.docx) templates: one per service plus the org wrapper
/// (no <c>catalog_item_id</c>). Every upload is a new immutable numbered version. Contract: to-do/proposal-generator-api.md.
/// All endpoints need <c>settings.manage</c>, like the catalogue and the pricing models. This controller routes, checks
/// permission and picks a status code; it touches no _db.
/// </summary>
[ApiController]
[Route("document-templates")]
[Authorize]
public class DocumentTemplatesController : ControllerBase
{
    private readonly DocumentTemplatesExperience _templates;
    public DocumentTemplatesController(DocumentTemplatesExperience templates) => _templates = templates;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);
    private ObjectResult Forbidden => StatusCode(403, new { error = "Your role cannot manage document templates." });

    private IActionResult Respond<T>(DocumentTemplateProcess.Result<T> r, int okStatus = 200) => r.Outcome switch
    {
        DocumentTemplateProcess.Outcome.NotFound => NotFound(new { error = r.Error }),
        DocumentTemplateProcess.Outcome.Invalid => BadRequest(new { error = r.Error }),
        DocumentTemplateProcess.Outcome.Unavailable => StatusCode(503, new { error = r.Error }),
        _ => StatusCode(okStatus, r.Value),
    };

    /// <summary>Every slot with its newest version: the wrapper deck and letter, then each service's deck and letter.</summary>
    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct) =>
        CanManage ? Ok(await _templates.ListAsync(ct)) : Forbidden;

    /// <summary>The fields (and formatters) a template of this slot may use. No <c>catalog_item_id</c> = the wrapper.</summary>
    [HttpGet("fields")]
    public async Task<IActionResult> Fields([FromQuery] string kind, [FromQuery(Name = "catalog_item_id")] Guid? catalogItemId, CancellationToken ct) =>
        CanManage ? Respond(await _templates.FieldsAsync(kind, catalogItemId, ct)) : Forbidden;

    /// <summary>The versions of one slot, newest first, each with its check. <c>variant</c> = the agreement's name when the letter slot is
    /// split into several (omitted = the unnamed slot).</summary>
    [HttpGet("versions")]
    public async Task<IActionResult> Versions(
        [FromQuery] string kind, [FromQuery(Name = "catalog_item_id")] Guid? catalogItemId, [FromQuery] string? variant, CancellationToken ct) =>
        CanManage ? Respond(await _templates.ListVersionsAsync(kind, catalogItemId, variant, ct)) : Forbidden;

    [HttpGet("versions/{id:guid}")]
    public async Task<IActionResult> Version(Guid id, CancellationToken ct) =>
        CanManage ? Respond(await _templates.GetVersionAsync(id, ct)) : Forbidden;

    [HttpGet("versions/{id:guid}/download")]
    public async Task<IActionResult> Download(Guid id, CancellationToken ct)
    {
        if (!CanManage) return Forbidden;
        var r = await _templates.DownloadAsync(id, ct);
        return r.Outcome == DocumentTemplateProcess.Outcome.Ok
            ? File(r.Value!.Bytes, r.Value.ContentType, r.Value.FileName)
            : Respond(r);
    }

    /// <summary>
    /// Multipart: <c>file</c>, <c>kind</c> ("deck" | "letter" | "irl"), optional <c>catalog_item_id</c> (required for "irl": the blank e-invoicing
    /// IRL workbook, .xlsx, belongs to a service), optional <c>variant</c> (the agreement's
    /// name; letters only - a letter slot can hold several named agreements, each versioned on its own). Saves a new version (201)
    /// with the check of its fields; <c>?dry_run=true</c> returns the check and stores nothing (200). For "irl" the version carries
    /// <c>irl: { doc_id, template_version, released, questions, tables, documents }</c> (what the workbook's _map and Lists sheets were read as)
    /// and a workbook without them is refused with a plain message.
    /// </summary>
    [HttpPost("upload")]
    [RequestSizeLimit(26 * 1024 * 1024)]
    public async Task<IActionResult> Upload(
        [FromForm] string? kind, [FromForm(Name = "catalog_item_id")] Guid? catalogItemId, IFormFile? file,
        CancellationToken ct, [FromForm] string? variant = null, [FromQuery(Name = "dry_run")] bool dryRun = false)
    {
        if (!CanManage) return Forbidden;
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required" });
        if (file.Length > DocumentTemplateProcess.MaxBytes) return BadRequest(new { error = "The file is too large." });

        await using var stream = file.OpenReadStream();
        using var ms = new MemoryStream();
        await stream.CopyToAsync(ms, ct);
        return Respond(await _templates.UploadAsync(kind ?? "", catalogItemId, file.FileName, ms.ToArray(), User.UserId(), dryRun, variant, ct), dryRun ? 200 : 201);
    }
}

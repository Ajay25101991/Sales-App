using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Auth;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// THE SECURITY SURFACE, now a thin HTTP shell over
/// <see cref="SalesApi.ExperienceLayer.Auth.AuthExperience"/> /
/// <see cref="SalesApi.ProcessLayer.Auth.AuthProcess"/> /
/// <see cref="SalesApi.SystemLayer.Auth.AuthStore"/>. Every rule that used to
/// live in this file — BCrypt hashing/verification, the free-email-domain
/// block list, the org-provisioning/designated-admin bootstrap gate, refresh
/// rotation with its reuse-burns-the-family behaviour, the "every failure
/// looks identical" responses on <c>refresh</c> and <c>accept-invite</c>, and
/// the JWT's <c>org_id</c> claim (via <c>Profile.OrgId</c>, read inside
/// <c>AuthStore.AccessToken</c> → <c>JwtService.CreateToken</c>, untouched) —
/// moved down UNCHANGED. This file now does only what a controller must:
/// route, rate-limit, read identity off an authenticated <c>User</c>, and
/// translate a <c>Refusal</c> into the right HTTP status.
/// </summary>
[ApiController]
[Route("auth")]
[EnableRateLimiting("auth")]
public class AuthController : ControllerBase
{
    private readonly AuthExperience _auth;
    public AuthController(AuthExperience auth) => _auth = auth;

    private IActionResult Refuse(SalesApi.ProcessLayer.Auth.AuthProcess.Refusal refusal) =>
        refusal.EmptyBody ? StatusCode(refusal.StatusCode) : StatusCode(refusal.StatusCode, new { error = refusal.Reason });

    [HttpPost("signup")]
    public async Task<IActionResult> Signup([FromBody] SignupRequest req)
    {
        var (refusal, response) = await _auth.SignupAsync(req);
        if (refusal is not null) return Refuse(refusal);
        return StatusCode(201, response);
    }

    [AllowPartnerPortal]   // anonymous, but a client that still holds a (valid) token must not be refused the sign-in itself
    [AllowCustomerPortal]
    [HttpPost("signin")]
    public async Task<IActionResult> Signin([FromBody] SigninRequest req)
    {
        var (refusal, response) = await _auth.SigninAsync(req);
        if (refusal is not null) return Refuse(refusal);
        return Ok(response);
    }

    /// <summary>
    /// Anonymous by necessity: the access token is expired by definition here,
    /// so the refresh token is the only credential the caller has. Not on the
    /// "auth" rate-limit policy the rest of this controller uses — see the note
    /// on <c>[EnableRateLimiting]</c> below.
    /// </summary>
    [AllowAnonymous]
    // Overrides the controller-level [EnableRateLimiting("auth")]: the action's
    // attribute is the later metadata and wins. Deliberately NOT paired with
    // [DisableRateLimiting] — that carries IDisableRateLimiterMetadata, which the
    // middleware checks FIRST and which would take this endpoint out of rate
    // limiting altogether rather than move it to another policy.
    [EnableRateLimiting("auth-refresh")]
    [AllowPartnerPortal]
    [AllowCustomerPortal]
    [HttpPost("refresh")]
    public async Task<IActionResult> Refresh([FromBody] RefreshRequest req)
    {
        var response = await _auth.RefreshAsync(req.RefreshToken);
        if (response is null) return Unauthorized(new { error = "Your session has expired. Please sign in again." });
        return Ok(response);
    }

    /// <summary>
    /// Control panel to CRM: parks an already-issued session behind a one-time,
    /// 60-second code so the CRM (another origin, so no shared browser storage) can
    /// open signed in. Only a platform admin may hand a session off; Process also
    /// checks the two tokens belong to the same user.
    /// </summary>
    [Authorize]
    [HttpPost("handoff")]
    public async Task<IActionResult> Handoff([FromBody] HandoffRequest req)
    {
        if (!User.IsSuntechAdmin())
            return StatusCode(403, new { error = "Only an app administrator can do this." });
        var (refusal, response) = await _auth.CreateHandoffAsync(req);
        if (refusal is not null) return Refuse(refusal);
        return Ok(response);
    }

    /// <summary>
    /// Anonymous by necessity (the CRM has no session yet); the code IS the
    /// authorization. One use, 60 seconds. Same "auth" rate limit as sign-in.
    /// The reason is deliberately never logged with the code.
    /// </summary>
    [AllowAnonymous]
    [AllowPartnerPortal]
    [AllowCustomerPortal]
    [HttpPost("handoff/redeem")]
    public async Task<IActionResult> RedeemHandoff([FromBody] HandoffRedeemRequest req)
    {
        var (refusal, response) = await _auth.RedeemHandoffAsync(req.Code);
        if (refusal is not null) return Refuse(refusal);
        return Ok(response);
    }

    /// <summary>
    /// Always 204, even for an unknown token, so this cannot be used to probe
    /// whether a token string exists.
    /// </summary>
    [Authorize]
    [AllowPartnerPortal]
    [AllowCustomerPortal]
    [HttpPost("signout")]
    public async Task<IActionResult> SignOut([FromBody] SignOutRequest? req)
    {
        await _auth.SignOutAsync(User.UserId(), req?.RefreshToken);
        return NoContent();
    }

    // Biometric authentication happens locally against a stored, valid session.
    // Once it succeeds, the client reports it here so it updates the same latest
    // activity timestamp and history used by password authentication.
    [Authorize]
    [AllowPartnerPortal]
    [AllowCustomerPortal]
    [HttpPost("activity")]
    public async Task<IActionResult> RecordActivity([FromBody] AuthActivityRequest req)
    {
        var refusal = await _auth.RecordActivityAsync(User.UserId(), req.Platform);
        if (refusal is not null) return Refuse(refusal);
        return NoContent();
    }

    // The signed-in user changes their own password (current -> new).
    [Authorize]
    [AllowPartnerPortal]
    [AllowCustomerPortal]
    [HttpPost("change-password")]
    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequest req)
    {
        var (refusal, response, noContent) = await _auth.ChangePasswordAsync(User.UserId(), req);
        if (refusal is not null) return Refuse(refusal);
        return noContent ? NoContent() : Ok(response);
    }

    /// <summary>
    /// Redeems a teammate-invite link. Unauthenticated by necessity — there is
    /// no session yet — and the token IS the whole authorization, so it is on
    /// its own rate-limit policy rather than "auth" (see the note on
    /// <c>[EnableRateLimiting]</c> on <see cref="Refresh"/>, same reasoning).
    /// The real failure reason is still logged server-side even though the
    /// caller never sees it — see AuthProcess.AcceptInviteAsync's doc comment.
    /// </summary>
    [AllowAnonymous]
    [EnableRateLimiting("invite-redeem")]
    [AllowPartnerPortal]
    [AllowCustomerPortal]
    [HttpPost("accept-invite")]
    public async Task<IActionResult> AcceptInvite([FromBody] AcceptInviteRequest req)
    {
        var (refusal, response, outcomeLabel) = await _auth.AcceptInviteAsync(req);
        if (refusal is not null)
        {
            Console.WriteLine($"[invite] redeem failed: {outcomeLabel}");
            return Refuse(refusal);
        }
        return Ok(response);
    }
}

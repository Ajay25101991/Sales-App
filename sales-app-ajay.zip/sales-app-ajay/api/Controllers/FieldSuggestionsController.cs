using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.FieldSuggestions;
using SalesApi.ProcessLayer.FieldSuggestions;
using SalesApi.ProcessLayer.Leads;
using SalesApi.Services;

namespace SalesApi.Controllers;

// Owner 2026-11-17 - enrichment suggestions: an AI tool's proposed value for one field of a deal, account or contact, held until a person accepts or rejects it. Business rules
// live in SalesApi.ProcessApi/FieldSuggestions/FieldSuggestionProcess.cs. What is left here: routing, building the caller as data (the same three facts the lead / account /
// contact edits take) and choosing the status code for a Refusal. Suggesting is NOT an endpoint: only the MCP tool makes suggestions (FieldSuggestionProcess.SuggestAsync).

/// <summary>
/// What a person does with suggestions in the app: see a record's, see the open queue, accept one (which edits the real field through the normal update) or reject one.
/// </summary>
[ApiController]
[Route("suggestions")]
[Authorize]
public class FieldSuggestionsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly FieldSuggestionsExperience _suggestions;
    public FieldSuggestionsController(CallerContext caller, FieldSuggestionsExperience suggestions)
    {
        _caller = caller;
        _suggestions = suggestions;
    }

    /// <summary>The caller as the update paths take them. The lead view is the same one GET /leads/{id} uses (CallerContext.LeadViewOf).</summary>
    private async Task<SuggestionCaller> CallerAsync()
    {
        var access = await _caller.ForAsync(User);
        var view = CallerContext.LeadViewOf(User);
        var actor = new LeadActor(
            User.UserId(), User.OrgId(), await _caller.DisplayNameAsync(User), User.IsManager(),
            await _caller.VisibilityAsync(User), User.HasPermission(OrganizationPermissions.TagCreate));
        return new SuggestionCaller(access, view, actor, User.Role());
    }

    private static IActionResult FromRefusal(FieldSuggestionProcess.Refusal r) =>
        r.NotFound ? new NotFoundObjectResult(new { error = r.Reason })
        : r.Forbidden ? new ObjectResult(new { error = r.Reason, code = r.Code, fields = r.Fields }) { StatusCode = 403 }
        : r.Conflict ? new ConflictObjectResult(new { error = r.Reason, code = r.Code })
        : new BadRequestObjectResult(new { error = r.Reason, code = r.Code, field = r.Field, fields = r.Fields });

    /// <summary>GET /suggestions?record_type=lead|account|contact&amp;record_id=&amp;include_decided=. A record's suggestions, newest first; open ones unless include_decided.</summary>
    [HttpGet]
    public async Task<IActionResult> ForRecord(
        [FromQuery(Name = "record_type")] string? recordType, [FromQuery(Name = "record_id")] Guid recordId,
        [FromQuery(Name = "include_decided")] bool includeDecided, CancellationToken ct)
    {
        var (refusal, items) = await _suggestions.ListForRecordAsync(await CallerAsync(), recordType, recordId, includeDecided, ct);
        return refusal is not null ? FromRefusal(refusal) : Ok(items);
    }

    /// <summary>GET /suggestions/open?limit=&amp;cursor= - the open queue over every record the caller may view, paged (<c>{ items, next_cursor }</c>).</summary>
    [HttpGet("open")]
    public async Task<IActionResult> Open([FromQuery] int? limit, [FromQuery] string? cursor, CancellationToken ct) =>
        Ok(await _suggestions.ListOpenAsync(await CallerAsync(), limit, cursor, ct));

    [HttpPost("{id:guid}/accept")]
    public async Task<IActionResult> Accept(Guid id, CancellationToken ct)
    {
        var (refusal, dto) = await _suggestions.AcceptAsync(await CallerAsync(), id, ct);
        return refusal is not null ? FromRefusal(refusal) : Ok(dto);
    }

    [HttpPost("{id:guid}/reject")]
    public async Task<IActionResult> Reject(Guid id, CancellationToken ct)
    {
        var (refusal, dto) = await _suggestions.RejectAsync(await CallerAsync(), id, ct);
        return refusal is not null ? FromRefusal(refusal) : Ok(dto);
    }
}

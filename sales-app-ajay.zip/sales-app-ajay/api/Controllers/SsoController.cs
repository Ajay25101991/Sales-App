using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ExperienceLayer.Sso;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E7.7 single sign-on with Microsoft (brief Part S). Routing, the
/// ManageSettings permission check on the admin endpoints, and status-code
/// selection only (API-led migration convention) — the OAuth state machine
/// lives in <see cref="ProcessLayer.Sso.SsoOAuthProcess"/>, same split
/// <see cref="MailboxConnectController"/> draws for its own flow.
///
/// <c>/auth/sso/start</c>, <c>/auth/sso/callback</c> and <c>/auth/sso/exchange</c>
/// are all <see cref="AllowAnonymous"/> by necessity: there is no session yet
/// — that is the entire point of a sign-in endpoint. The callback in
/// particular is hit by a full-page browser redirect from Entra, never by
/// this app's own fetch client (same reasoning as
/// <see cref="MailboxConnectController.ConnectCallback"/>'s own doc comment);
/// its signed, single-use `state` parameter IS the security boundary.
/// </summary>
[ApiController]
public class SsoController : ControllerBase
{
    private readonly SsoExperience _sso;
    public SsoController(SsoExperience sso) => _sso = sso;

    private bool CanManage() => User.HasPermission(OrganizationPermissions.ManageSettings);

    // The desktop app's sign-in page — same host as the API (the device
    // loader routes phone vs desktop), so a relative path is enough. Mirrors
    // MailboxConnectController.ProfileRedirectPath.
    private const string SigninRedirectPath = "/apps/desktop/sign-in";
    private const string SsoSettingsRedirectPath = "/apps/desktop/admin/sso";

    // The other two clients' sign-in screens. A FIXED server-side map keyed by
    // SsoStateClient — the client only ever picks a key at /auth/sso/start,
    // never supplies a URL, so there is no open redirect.
    //  - phone web: apps/web is exported with experiments.baseUrl
    //    "/apps/sales/m" (apps/web/app.json; deploy-aws.yml copies the build to
    //    api/wwwroot/apps/sales/m), and its sign-in is app/(auth)/sign-in.tsx;
    //    expo-router drops the (auth) group from the URL.
    //  - native: the "salesmobileapp" scheme in apps/mobile/app.json.
    private const string PhoneWebSigninRedirectPath = "/apps/sales/m/sign-in";
    private const string NativeSigninRedirectPath = "salesmobileapp://sign-in";

    /// <summary>Where the sign-in result goes for a given <see cref="SsoStateClient"/>
    /// (anything unrecognised is desktop).</summary>
    public static string SigninRedirectFor(string? client) => client switch
    {
        SsoStateClient.PhoneWeb => PhoneWebSigninRedirectPath,
        SsoStateClient.Native => NativeSigninRedirectPath,
        _ => SigninRedirectPath,
    };

    // POST /auth/sso/start { email } — anonymous. Always 200; Available
    // false covers every refusal reason identically (see SsoStartResult's
    // own doc comment) — never a 4xx that would itself leak "this email/org
    // does/doesn't have an account".
    [AllowAnonymous]
    [EnableRateLimiting("sso-start")]
    [HttpPost("auth/sso/start")]
    public async Task<IActionResult> Start([FromBody] SsoStartRequest req)
    {
        var result = await _sso.StartAsync(req.Email, req.Client);
        return Ok(new SsoStartResponse(result.Available, result.AuthorizeUrl));
    }

    // GET /auth/sso/callback?code=&state=&error= — hit by Entra's browser
    // redirect. REDIRECTS (302), never JSON — same reasoning as
    // MailboxConnectController.ConnectCallback. On success for an ordinary
    // sign-in, carries a SHORT-LIVED, SINGLE-USE exchange code — never a
    // bearer token — which the client trades at POST /auth/sso/exchange for
    // the real session. `?sso=error&reason=<short code>` on failure — NEVER
    // raw provider text in the URL.
    [AllowAnonymous]
    [HttpGet("auth/sso/callback")]
    public async Task<IActionResult> Callback([FromQuery] string? code, [FromQuery] string? state, [FromQuery] string? error)
    {
        if (!string.IsNullOrEmpty(error))
        {
            // Entra sends `state` with `error=`. A read-only lookup (never
            // consumes it) finds who started the attempt; no/unknown/used/
            // expired/Test state keeps the desktop redirect.
            var errorClient = await _sso.ClientForStateAsync(state);
            return Redirect($"{SigninRedirectFor(errorClient)}?sso=error&reason=denied");
        }
        if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(state))
            return Redirect($"{SigninRedirectPath}?sso=error&reason=missing_params");

        var result = await _sso.ExchangeCallbackAsync(code, state);

        if (result.Purpose == SalesApi.Models.SsoStatePurpose.Test)
        {
            return result.Success
                ? Redirect($"{SsoSettingsRedirectPath}?test=ok")
                : Redirect($"{SsoSettingsRedirectPath}?test=error&reason={result.ErrorReason}");
        }

        var signinPath = SigninRedirectFor(result.Client);
        if (!result.Success || result.ExchangeCode is null)
            return Redirect($"{signinPath}?sso=error&reason={result.ErrorReason}");
        return Redirect($"{signinPath}?sso=ok&code={Uri.EscapeDataString(result.ExchangeCode)}");
    }

    // POST /auth/sso/exchange { code, supports_refresh } — anonymous. Trades
    // the one-time code for the real session. The JWT/refresh-token pair
    // travels in THIS JSON body only, never in a URL.
    [AllowAnonymous]
    [EnableRateLimiting("sso-exchange")]
    [HttpPost("auth/sso/exchange")]
    public async Task<IActionResult> Exchange([FromBody] SsoExchangeRequest req)
    {
        var (refusal, response) = await _sso.ExchangeSessionAsync(req.Code, req.SupportsRefresh == true);
        if (refusal is not null) return Unauthorized(new { error = refusal.Message });
        return Ok(response);
    }

    // GET /admin/sso — org admin (ManageSettings) settings read.
    [Authorize]
    [HttpGet("admin/sso")]
    public async Task<IActionResult> GetSettings()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view single sign-on settings." });
        var orgId = User.OrgId();
        if (orgId is null) return StatusCode(403, new { error = "No organization on this account." });
        return Ok(await _sso.GetSettingsAsync(orgId.Value));
    }

    // PUT /admin/sso — org admin (ManageSettings) settings write.
    [Authorize]
    [HttpPut("admin/sso")]
    public async Task<IActionResult> SaveSettings([FromBody] SsoSettingsInput input)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot change single sign-on settings." });
        var orgId = User.OrgId();
        if (orgId is null) return StatusCode(403, new { error = "No organization on this account." });
        var (dto, refusal) = await _sso.SaveSettingsAsync(orgId.Value, input, User.UserId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // POST /admin/sso/test — org admin (ManageSettings) "Test sign-in": runs
    // the real flow for the ADMIN'S OWN account and reports the result via
    // the callback's redirect (above), without creating or changing
    // anything.
    [Authorize]
    [HttpPost("admin/sso/test")]
    public async Task<IActionResult> Test()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot test single sign-on." });
        var orgId = User.OrgId();
        if (orgId is null) return StatusCode(403, new { error = "No organization on this account." });
        var (refusal, url) = await _sso.BuildTestAuthorizeUrlAsync(orgId.Value, User.UserId());
        if (refusal is not null) return BadRequest(new { error = refusal.Message });
        return Ok(new SsoTestStartResponse(url!));
    }
}

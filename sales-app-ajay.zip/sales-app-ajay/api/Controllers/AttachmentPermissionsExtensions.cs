using System.Security.Claims;
using SalesApi.Dtos;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>The permissions a file operation needs from the caller's token, resolved at the HTTP layer and handed down as data. ONE place, used
/// by the Files controller and the task-files endpoints on the tasks controller.</summary>
public static class AttachmentPermissionsExtensions
{
    public static AttachmentPermissions FileAccess(this ClaimsPrincipal user) => new(
        user.HasPermission(OrganizationPermissions.ViewFinancials),
        user.HasPermission(OrganizationPermissions.ViewContactDetails),
        user.HasPermission(OrganizationPermissions.KycAccess));
}

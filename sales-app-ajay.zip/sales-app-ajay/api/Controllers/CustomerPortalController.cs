using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Portal;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.ProcessLayer.Portal;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// The customer portal's API (E19.3; owner decision 2026-11-04: customers use the SAME portal app as partners, with their own views): what a signed-in CUSTOMER user sees of its own account -
/// invoices, receipts (PDF), Pay now, its KYC documents and what we have asked of it. Marked for the customer kind ONLY: a partner portal user is refused by the one default-deny guard
/// (<c>PortalGuard</c>), and a staff user has no portal account and is told so.
///
/// This controller routes and builds the caller's <see cref="PortalScope"/> from the principal the permission middleware stamped from the profile row - never from the URL or a body - and
/// passes it DOWN as data. An id outside that scope (another customer's invoice, an account that is not the caller's or a child it may see) is a 404, never a 403. The rules are
/// <see cref="CustomerPortalProcess"/>'s.
/// </summary>
[ApiController]
[Route("portal/customer")]
[Authorize]
[AllowCustomerPortal]
public class CustomerPortalController : ControllerBase
{
    private readonly CustomerPortalExperience _customer;
    public CustomerPortalController(CustomerPortalExperience customer) => _customer = customer;

    private PortalScope? Scope() =>
        User.PortalKind() is { } kind && User.PortalAccountId() is Guid account
            ? new PortalScope(kind, account, User.PortalIncludeChildren(), User.UserId())
            : null;

    private ObjectResult NotAPortalUser() => StatusCode(403, new { error = "This is for portal users.", code = "not_a_portal_user" });

    /// <summary><c>GET ?status=open|paid|all</c> (default all): <c>[{ id, number, issued_at, due_date, currency, amount, amount_paid, balance, status, account_name }]</c>. 400 code bad_status.</summary>
    [HttpGet("invoices")]
    public async Task<IActionResult> Invoices([FromQuery] string? status, CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _customer.InvoicesAsync(s, status, ct)) : NotAPortalUser();

    /// <summary>The same tax-invoice PDF the staff endpoint renders, with the money in full.</summary>
    [HttpGet("invoices/{id:guid}/pdf")]
    public async Task<IActionResult> InvoicePdf(Guid id, CancellationToken ct)
    {
        if (Scope() is not { } s) return NotAPortalUser();
        var r = await _customer.InvoicePdfAsync(s, id, ct);
        return r.IsOk ? File(r.Value!.Bytes, "application/pdf", r.Value.FileName) : this.Respond(r);
    }

    /// <summary><c>[{ collection_task_id, receipt_number, collected_at, amount, currency }]</c> - the receipts of payments collected against the invoice.</summary>
    [HttpGet("invoices/{id:guid}/receipts")]
    public async Task<IActionResult> Receipts(Guid id, CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _customer.ReceiptsAsync(s, id, ct)) : NotAPortalUser();

    /// <summary>The same receipt PDF the staff endpoint renders.</summary>
    [HttpGet("receipts/{collectionTaskId:guid}/pdf")]
    public async Task<IActionResult> ReceiptPdf(Guid collectionTaskId, CancellationToken ct)
    {
        if (Scope() is not { } s) return NotAPortalUser();
        var r = await _customer.ReceiptPdfAsync(s, collectionTaskId, ct);
        return r.IsOk ? File(r.Value!.Bytes, "application/pdf", r.Value.FileName) : this.Respond(r);
    }

    /// <summary><c>{ url }</c> - the invoice's Pay now page. 404 not the caller's; 409 code not_payable (not open money); 503 payments_not_connected / no_public_url.</summary>
    [HttpPost("invoices/{id:guid}/pay")]
    public async Task<IActionResult> Pay(Guid id, CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _customer.PayAsync(s, id, ct)) : NotAPortalUser();

    /// <summary><c>[{ account_id, account_name, complete, missing_count, missing_mandatory_count, items: [{ document_type, label, mandatory, holder, state, expiry_date, awaiting_review, can_upload }] }]</c>.</summary>
    [HttpGet("kyc")]
    [AllowPartnerPortal] // E19.5: a partner applicant uses the same route (scope = its own account)
    public async Task<IActionResult> Kyc(CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _customer.KycAsync(s, ct)) : NotAPortalUser();

    /// <summary>POST (multipart <c>file</c> + <c>document_type</c>): 201 <c>{ document_type, file_name, uploaded_at, awaiting_review }</c>. PDF, JPG or PNG up to 10 MB (400 file_type_not_allowed / file_too_large),
    /// only a document on the account's checklist (400 not_on_checklist), personal IDs not yet (400 contact_document_unsupported). The row lands pending, for review.</summary>
    [HttpPost("kyc/{accountId:guid}/files")]
    [AllowPartnerPortal] // E19.5: see Kyc
    [RequestSizeLimit(UploadLimits.PublicRequestBytes)]
    public async Task<IActionResult> UploadKycFile(Guid accountId, [FromForm(Name = "document_type")] string? documentType, IFormFile? file, CancellationToken ct)
    {
        if (Scope() is not { } s) return NotAPortalUser();
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required", code = "file_required" });
        await using var stream = file.OpenReadStream();
        var r = await _customer.UploadKycFileAsync(s, accountId, documentType, file.FileName, file.ContentType, file.Length, stream, ct);
        return r.Code == "file_too_large" ? StatusCode(413, new { error = r.Error, code = r.Code }) : this.Respond(r, 201);
    }

    /// <summary><c>[{ kind: "document_request" | "irl", id, title, sent_at, expires_at, status, url }]</c> - what we have asked for and is still open; <c>url</c> is the existing secure link.</summary>
    [HttpGet("requests")]
    public async Task<IActionResult> Requests(CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _customer.RequestsAsync(s, ct)) : NotAPortalUser();
}

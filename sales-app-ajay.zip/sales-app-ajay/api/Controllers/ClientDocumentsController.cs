using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.ClientDocuments;
using SalesApi.ProcessLayer.ClientDocuments;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Client-document reading: the values read from a client's trade licence, VAT certificate, signatory ID / authority and MoA/AoA, waiting
/// for a person to confirm them (see <see cref="ClientDocumentProcess"/>). Routes, checks the permission the account's own endpoints sit
/// behind, and picks a status code - nothing else. The write permission is the account's own edit permission, judged by the account
/// update the confirm goes through.
/// </summary>
[ApiController]
[Route("client-documents")]
[Authorize]
[RequireSensitiveAccess(SensitiveCategories.ContactDetails)]
[RequirePermission(OrganizationPermissions.KycAccess)]   // E15.1: the OCR values and the document files are KYC data
public class ClientDocumentsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly ClientDocumentsExperience _documents;

    public ClientDocumentsController(CallerContext caller, ClientDocumentsExperience documents)
    {
        _caller = caller;
        _documents = documents;
    }

    private Task<RecordAccessContext> AccessAsync() => _caller.ForAsync(User);

    // Same mapping as AccountsController.FromRefusal (this is the account's data): 404 / 403 / 400, with the sensitive-write body carrying its fields.
    private static IActionResult FromRefusal(ClientDocumentProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 403 }
        : refusal.Code == SensitiveWriteGuard.Code
            ? new BadRequestObjectResult(new { error = refusal.Reason, code = refusal.Code, fields = refusal.Fields })
        : new BadRequestObjectResult(refusal.Code is null
            ? new { error = refusal.Reason }
            : new { error = refusal.Reason, code = refusal.Code, field = refusal.Field });

    // GET /client-documents/fields - the document types and the account fields reading each can fill (labels in plain words).
    // The types' own list (the org can add to it) is the "document_types" picklist, GET /picklists.
    [HttpGet("fields")]
    public IActionResult Fields() => Ok(_documents.Catalogue());

    // GET /client-documents?account_id= | lead_id= [&status=pending|confirmed|rejected|superseded|all]
    // The document files (with where reading each is) and the values read, pending first. Default: pending and confirmed.
    [HttpGet]
    public async Task<IActionResult> List(
        [FromQuery(Name = "account_id")] Guid? accountId, [FromQuery(Name = "lead_id")] Guid? leadId, [FromQuery] string? status)
    {
        var outcome = await _documents.ListAsync(await AccessAsync(), User.Role(), accountId, leadId, status, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Result);
    }

    // POST /client-documents/files/{attachmentId}/read - "Read again": 202; the file goes back in the reading queue.
    [HttpPost("files/{attachmentId:guid}/read")]
    public async Task<IActionResult> ReadAgain(Guid attachmentId)
    {
        var refusal = await _documents.ReadAgainAsync(await AccessAsync(), attachmentId, HttpContext.RequestAborted);
        return refusal is not null ? FromRefusal(refusal) : Accepted();
    }

    // POST /client-documents/values/{id}/confirm - the value as read is written to the account's field. 200 with the value.
    [HttpPost("values/{id:guid}/confirm")]
    public async Task<IActionResult> Confirm(Guid id)
    {
        var outcome = await _documents.ConfirmAsync(await AccessAsync(), User.Role(), id, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Value);
    }

    // POST /client-documents/values/{id}/confirm-edited { value, reason } - confirm a changed value; a reason is required (a note on the account).
    [HttpPost("values/{id:guid}/confirm-edited")]
    public async Task<IActionResult> ConfirmEdited(Guid id, [FromBody] ClientDocumentEditInput input)
    {
        var outcome = await _documents.ConfirmEditedAsync(await AccessAsync(), User.Role(), id, input, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Value);
    }

    // POST /client-documents/values/{id}/reject - the value is wrong; it is kept as rejected and never written.
    [HttpPost("values/{id:guid}/reject")]
    public async Task<IActionResult> Reject(Guid id)
    {
        var outcome = await _documents.RejectAsync(await AccessAsync(), User.Role(), id, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Value);
    }

    // POST /client-documents/values { account_id, field_key, value, reason, document_type? } - a value typed in with no file; a reason is required.
    [HttpPost("values")]
    public async Task<IActionResult> AddManual([FromBody] ClientDocumentManualInput input)
    {
        var outcome = await _documents.AddManualAsync(await AccessAsync(), User.Role(), input, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Value);
    }
}

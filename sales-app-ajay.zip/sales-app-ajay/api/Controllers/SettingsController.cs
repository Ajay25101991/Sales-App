using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Settings;
using SalesApi.Models;
using SalesApi.ProcessLayer.Settings;
using SalesApi.Services;

// The org-settings ACCESSORS these endpoints share moved to
// Services/OrgSettings.cs — step 1 of the API-led migration
// (to-do/api-led-migration-plan.md). They were static methods here only because
// this is where the endpoints are, and 14 services calling up into a controller
// was the cycle blocking any layer beneath. Imported statically so every
// endpoint below reads exactly as it did.
using static SalesApi.Services.OrgSettings;

namespace SalesApi.Controllers;

/// <summary>
/// Every org setting, under one route prefix.
///
/// MIGRATED to the layered API (step 8): this controller routes, checks
/// permission, and picks a status code from what <see cref="SettingsExperience"/>
/// decides. Everything else — validation, merge-over-stored rules, the raw-body
/// stage parser, the composed reads — lives in SettingsExperience
/// (SalesApi.ExperienceApi) and beneath it SettingsProcess (SalesApi.ProcessApi)
/// and SettingsStore (SalesApi.SystemApi).
///
/// ONE `_db` use remains, deliberately, in GetRoutingAudit: building the
/// caller's <c>RecordAccessContext</c> needs both the ClaimsPrincipal and the
/// database, and a System-layer service must not take a principal.
/// AccountsController and AttachmentsController keep the same residual for the
/// same reason.
///
/// Three things this domain forced out of hiding, all fixed rather than
/// duplicated: <c>ValidateCalendarInput</c>, which TeamsController called across
/// for (now <c>CalendarValidation.Validate</c> in Contracts);
/// <c>LeadsController.CsvColumns</c>, which the lead-taxonomy screen read across
/// for (now <c>LeadCsv</c> in the System layer); and both residents of
/// <c>SystemBoundContracts.cs</c>, whose System dependencies moved down into
/// Contracts so the file itself could go.
/// </summary>
[ApiController]
[Route("settings")]
[Authorize]
public class SettingsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly SettingsExperience _settings;
    public SettingsController(CallerContext caller, SettingsExperience settings)
    {
        _caller = caller;
        _settings = settings;
    }

    // Anyone signed in can read the settings (the app needs them to scope UI).
    [HttpGet]
    public async Task<IActionResult> Get() => Ok(await _settings.GetSettingsAsync());

    // Managers/admins change them.
    [HttpPut]
    public async Task<IActionResult> Update([FromBody] SettingsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change settings." });

        var (refusal, dto) = await _settings.UpdateSettingsAsync(input.LeadVisibility);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(dto);
    }

    // --- Org setup (design doc D6a/D8) ---
    // GET is open to any signed-in user, like GET /settings itself: a future
    // catch-all consumer (D8, out of scope here — see OrgSetupService's doc
    // comment) needs to read this on every lead create, not only from an
    // admin session. Reading it costs nothing to expose; only the WRITE is a
    // configuration change.
    [HttpGet("org-setup")]
    public async Task<IActionResult> GetOrgSetup() => Ok(await _settings.GetOrgSetupAsync());

    [HttpPut("org-setup")]
    public async Task<IActionResult> SetOrgSetup([FromBody] OrgSetupInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change organization setup." });

        var (refusal, dto) = await _settings.SetOrgSetupAsync(input.UnmatchedLeadPolicy, input.CatchAllPlaybookId);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- Gate escalation approver (design doc D9a #2 / D12) ---
    // GET open to any signed-in user, same reasoning as GET /settings and GET
    // /settings/org-setup: ApprovalsController needs this on every gate-
    // exception create/decide, not only from an admin session.
    [HttpGet("gate-escalation")]
    public async Task<IActionResult> GetGateEscalation() => Ok(await _settings.GetGateEscalationAsync());

    [HttpPut("gate-escalation")]
    public async Task<IActionResult> SetGateEscalation([FromBody] GateEscalationSettingsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change organization setup." });

        var (refusal, dto) = await _settings.SetGateEscalationAsync(input.ApproverPolicy, input.SelfDecision);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- Playbook picker policy (design doc D10a / D12) ---
    // GET open to any signed-in user, same reasoning as the settings above:
    // the lead create/edit forms need this to decide whether to even draw a
    // picker, not only an admin session.
    [HttpGet("playbook-policy")]
    public async Task<IActionResult> GetPlaybookPolicy() => Ok(await _settings.GetPlaybookPolicyAsync());

    [HttpPut("playbook-policy")]
    public async Task<IActionResult> SetPlaybookPolicy([FromBody] PlaybookPolicyInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change organization setup." });

        var (refusal, dto) = await _settings.SetPlaybookPolicyAsync(input.HumanChoicePolicy, input.PickerAccessPolicy);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- Loyalty policy (loyalty-module-backlog.md P0-1) ---
    // GET open to any signed-in user, same reasoning as the settings above: a
    // loyalty read anywhere in the app needs to know whether the module is on
    // before it can decide what "disabled" looks like, not only an admin session.
    [HttpGet("loyalty-policy")]
    public async Task<IActionResult> GetLoyaltyPolicy() => Ok(await _settings.GetLoyaltyPolicyAsync());

    [HttpPut("loyalty-policy")]
    public async Task<IActionResult> SetLoyaltyPolicy([FromBody] LoyaltyPolicyInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change organization setup." });

        var (refusal, dto) = await _settings.SetLoyaltyPolicyAsync(
            input.Enabled, input.EarnSource, input.PointsInvoicePayment, input.PointsAmcRenewal, input.Window, input.WindowMonths);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- Loyalty tiers (owner decision 5a.3) ---
    // GET open to any signed-in user, same reasoning as the loyalty policy
    // above: an account's tier is derived from these thresholds on every read,
    // so anything showing a tier needs them, not only an admin session.
    [HttpGet("loyalty-tiers")]
    public async Task<IActionResult> GetLoyaltyTiers() => Ok(await _settings.GetLoyaltyTiersAsync());

    [HttpPut("loyalty-tiers")]
    public async Task<IActionResult> SetLoyaltyTiers([FromBody] LoyaltyTierConfigDto input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change organization setup." });

        var (refusal, dto) = await _settings.SetLoyaltyTiersAsync(input);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- Lead form routing policy (design doc D2, 2026-08-25) ---
    // GET open to any signed-in user, same reasoning as the settings above:
    // LeadsController needs this on every lead create/edit, not only from an
    // admin session.
    [HttpGet("lead-form-policy")]
    public async Task<IActionResult> GetLeadFormPolicy() => Ok(await _settings.GetLeadFormPolicyAsync());

    [HttpPut("lead-form-policy")]
    public async Task<IActionResult> SetLeadFormPolicy([FromBody] LeadFormPolicyInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change organization setup." });

        var (refusal, dto) = await _settings.SetLeadFormPolicyAsync(
            input.Source, input.NoPlaybookPolicy, input.PinningPolicy);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- Board rendering default view (design doc D11/D11a) ---
    // GET open to any signed-in user, same reasoning as the settings above:
    // the board itself needs this to pick its initial view, not only an
    // admin session. D11a made the three views a toggle the viewer switches
    // freely, so this setting is advisory (a default), never enforced here —
    // there is nothing for the server to enforce, since every view reads the
    // same leads and the same per-playbook stage lists either way.
    [HttpGet("board-rendering-policy")]
    public async Task<IActionResult> GetBoardRenderingPolicy() =>
        Ok(await _settings.GetBoardRenderingPolicyAsync());

    [HttpPut("board-rendering-policy")]
    public async Task<IActionResult> SetBoardRenderingPolicy([FromBody] BoardRenderingPolicyInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change organization setup." });

        var (refusal, dto) = await _settings.SetBoardRenderingPolicyAsync(input.Policy);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- Inbound (website contact form) config: default lead owner ---
    // (The API key moved to named, hashed rows under /api-keys; /settings/inbound/rotate is gone.)
    // GET /settings/inbound — the default owner.
    [HttpGet("inbound")]
    public async Task<IActionResult> GetInbound()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot view this setting." });
        return Ok(await _settings.GetInboundAsync());
    }

    // PUT /settings/inbound — choose which rep new website leads are assigned to.
    [HttpPut("inbound")]
    public async Task<IActionResult> SetInboundOwner([FromBody] InboundOwnerInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, dto) = await _settings.SetInboundOwnerAsync(input.OwnerId, User.OrgId());
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(dto);
    }

    // --- Pipeline stages (open stages; won/lost are terminal) ---
    [HttpGet("stages")]
    public async Task<IActionResult> GetStages() => Ok(await _settings.GetStagesAsync());

    // Every stage, terminals and post-close included. A SEPARATE endpoint rather than
    // widening the one above: ~40 server callers and every already-installed app build
    // read /settings/stages as "the open pipeline", and an older phone that suddenly
    // received Won and Lost in that list would render them as board columns. New
    // clients and the Stages admin screen read this one.
    // Canonical mapping is resolved on the way out, never stored back — see
    // CanonicalStageService.ResolveMapping. Only this endpoint pays for it: it is the
    // one the stage editor and the client's stage hook read, and nothing else needs
    // the mapping yet.
    //
    // `playbookId` (design doc D11/D11a): optional, defaults to null — the
    // org-wide list, i.e. every call site written before the board's per-
    // playbook views existed keeps compiling and keeps behaving identically.
    // Given, it resolves the SAME stage list StageService.GetAllAsync already
    // gives LeadsController for a lead carrying that PlaybookId — the board's
    // columns are therefore guaranteed to match what the server will actually
    // accept a move into, never an approximation reconstructed client-side.
    [HttpGet("stages/all")]
    public async Task<IActionResult> GetAllStages([FromQuery] Guid? playbookId) =>
        Ok(await _settings.GetAllStagesAsync(playbookId));

    // GET /settings/stages/lead-counts — how many leads currently sit on each
    // stage key (open AND terminal — a Won/Lost stage can still be deleted or
    // renamed, and those leads are affected too), for the stages admin
    // screen's "N leads are on this stage" so a rename/delete shows its blast
    // radius BEFORE it happens. Deliberately a separate endpoint from
    // GetAllStages rather than a field bolted onto StageDefDto: that DTO is
    // shared with GET /settings/stages (~40 callers, called far more often
    // than the stage editor is open), and this is a GROUP BY over every lead
    // in the org that only the editor needs.
    //
    // NOT the same figure as GET /dashboard's byStatus: that one is
    // period-scoped (only leads touched in the dashboard's window) and value
    // is masked for viewers without lead_values.view. This is "how many
    // leads are on this stage right now, org-wide", full stop — the same
    // permission PUT /settings/stages itself requires, since this only has a
    // use next to that edit.
    [HttpGet("stages/lead-counts")]
    public async Task<IActionResult> GetStageLeadCounts()
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePipeline))
            return StatusCode(403, new { error = "Your role cannot manage pipeline stages." });

        return Ok(await _settings.StageLeadCountsAsync());
    }

    // --- Canonical stage axis ---
    // Readable by anyone signed in, like /settings/stages: it is reference data every
    // client will need once rank and "backward" move onto it, and gating the read
    // behind an admin permission would make that step break for reps. Editing it is
    // pipeline configuration and takes the pipeline permission — no new bit, because
    // OrganizationPermissions is index-addressed and append-only (PermissionCatalog).
    [HttpGet("canonical-stages")]
    public async Task<IActionResult> GetCanonicalStages() => Ok(await _settings.GetCanonicalStagesAsync());

    [HttpPut("canonical-stages")]
    public async Task<IActionResult> SetCanonicalStages([FromBody] CanonicalStagesInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePipeline))
            return StatusCode(403, new { error = "Your role cannot change pipeline stages." });

        var (refusal, saved) = await _settings.SaveCanonicalStagesAsync(input);
        if (refusal is not null)
            // The reorder refusal carries a flag rather than being told apart by its
            // message: the client turns it into a confirmation prompt and resubmits,
            // and matching on prose is how that breaks the next time it is reworded.
            return BadRequest(new { error = refusal.Reason, needs_reorder_confirmation = refusal.NeedsReorderConfirmation });
        return Ok(saved);
    }

    // The body is read RAW and handed down unparsed. The merge rules need to tell
    // "field omitted" apart from "field explicitly null", which model binding
    // collapses — so the parse belongs with those rules, in SettingsProcess, not
    // here. See SettingsProcess.ParseStagesInput.
    [HttpPut("stages")]
    public async Task<IActionResult> SetStages()
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePipeline))
            return StatusCode(403, new { error = "Your role cannot change pipeline stages." });

        string raw;
        using (var reader = new StreamReader(Request.Body)) raw = await reader.ReadToEndAsync();
        var (refusal, saved) = await _settings.SaveStagesAsync(raw);
        // Item 7 — same "flag, not prose-matching" contract SetCanonicalStages
        // already uses for needs_reorder_confirmation: the client turns this
        // into a confirm-and-resubmit (with confirm_drop) prompt.
        return refusal is not null
            ? BadRequest(new { error = refusal.Reason, needs_drop_confirmation = refusal.NeedsDropConfirmation })
            : Ok(saved);
    }

    // --- Inbound lead routing (fixed / round-robin / least-busy) ---
    [HttpGet("routing")]
    public async Task<IActionResult> GetRouting()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot view routing settings." });
        return Ok(await _settings.GetRoutingAsync());
    }

    [HttpPut("routing")]
    public async Task<IActionResult> SetRouting([FromBody] LeadRoutingInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change routing settings." });
        return Ok(await _settings.SaveRoutingAsync(
            input.Mode, input.Pool, input.SourceRules, input.UnassignedTeamId, input.ClearUnassignedTeam,
            input.SourcePlaybooks));
    }

    // GET /settings/routing/audit?days=30&limit=10 — what the rule actually did:
    // the most recent routings, and how many each person was given over the window.
    // Both halves come off one filtered query so the counts always describe the
    // same window the list is drawn from.
    [HttpGet("routing/audit")]
    public async Task<IActionResult> GetRoutingAudit([FromQuery] int? days, [FromQuery] int? limit)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot view routing settings." });

        // The one remaining _db use in this controller, and a deliberate one:
        // building the caller's RecordAccessContext needs both the ClaimsPrincipal
        // and the database, and a System-layer service must not take a principal.
        // AccountsController and AttachmentsController keep the same residual for
        // the same reason.
        var ctx = await _caller.ForAsync(User);
        return Ok(await _settings.RoutingAuditAsync(ctx, days, limit));
    }

    // --- Idle-lead SLA threshold (days without an update before a lead is "idle") ---
    [HttpGet("sla")]
    public async Task<IActionResult> GetSla() => Ok(new { idle_days = await _settings.GetSlaAsync() });

    [HttpPut("sla")]
    public async Task<IActionResult> SetSla([FromBody] SlaInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, days) = await _settings.SetSlaAsync(input.IdleDays);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(new { idle_days = days });
    }

    // --- Accounts rework (owner decisions 6, 8, 14): deal_requires_contact, account_duplicate_mode, ------------
    // --- views_no_contact_days, views_renewal_days. GET is open to any signed-in user (the screens read them); PUT is
    // --- manage-settings, a partial update, and refuses a bad value with a 400 (same shape as the SLA setting).
    [HttpGet("account-policy")]
    public async Task<IActionResult> GetAccountPolicy() => Ok(await _settings.GetAccountsReworkAsync());

    [HttpPut("account-policy")]
    public async Task<IActionResult> SetAccountPolicy([FromBody] AccountsReworkSettingsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, dto) = await _settings.SaveAccountsReworkAsync(input);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- E16.1: which marketing-kind purposes still reach an opted-out contact (default none). GET is open to any
    // --- signed-in user; PUT is manage-settings.
    [HttpGet("message-kinds")]
    public async Task<IActionResult> GetMessageKinds() => Ok(await _settings.GetMessageKindsAsync());

    [HttpPut("message-kinds")]
    public async Task<IActionResult> SetMessageKinds([FromBody] MessageKindSettingsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, dto) = await _settings.SaveMessageKindsAsync(input);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- E14.3: whether automations may move a deal to an earlier open stage (on by default). GET open to signed-in users (the
    // --- automation builder shows it); PUT is manage-settings.
    [HttpGet("automation-stage-moves")]
    public async Task<IActionResult> GetAutomationStageMoves() => Ok(await _settings.GetAutomationStageMovesAsync());

    [HttpPut("automation-stage-moves")]
    public async Task<IActionResult> SetAutomationStageMoves([FromBody] AutomationStageMovesInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, dto) = await _settings.SaveAutomationStageMovesAsync(input);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- Admin-chosen header tiles: which summary-strip tiles the lead and account pages show, in what order. GET is open to every
    // --- signed-in user (each page load reads it); PUT is manage-settings. It chooses and orders only - the client still drops tiles the caller may not see.
    [HttpGet("header-tiles")]
    public async Task<IActionResult> GetHeaderTiles() => Ok(await _settings.GetHeaderTilesAsync());

    [HttpPut("header-tiles")]
    public async Task<IActionResult> SetHeaderTiles([FromBody] HeaderTilesInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, dto) = await _settings.SaveHeaderTilesAsync(input);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- E14: account hierarchy - which account fields a child inherits, which child statuses count --------------
    [HttpGet("account-hierarchy")]
    public async Task<IActionResult> GetAccountHierarchy() => Ok(await _settings.GetAccountHierarchyAsync());

    [HttpPut("account-hierarchy")]
    public async Task<IActionResult> SetAccountHierarchy([FromBody] AccountHierarchySettingsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, dto) = await _settings.SaveAccountHierarchyAsync(input);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- E15.3: KYC checklist rules - which documents an account must hold (rules over account fields) ------------
    // GET is admin-only too: the rules are the org's compliance policy, not something every rep's screen needs.
    [HttpGet("kyc-checklist")]
    public async Task<IActionResult> GetKycChecklist()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot see this setting." });
        return Ok(await _settings.GetKycChecklistAsync());
    }

    [HttpPut("kyc-checklist")]
    public async Task<IActionResult> SetKycChecklist([FromBody] KycChecklistSettingsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, dto) = await _settings.SaveKycChecklistAsync(input);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- Contact promotion (when a lead's person becomes a contact) ---------------
    [HttpGet("contact-promotion")]
    public async Task<IActionResult> GetContactPromotion() =>
        Ok(new { mode = await _settings.GetContactPromotionAsync() });

    [HttpPut("contact-promotion")]
    public async Task<IActionResult> SetContactPromotion([FromBody] ContactPromotionInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, mode) = await _settings.SetContactPromotionAsync(input.Mode);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(new { mode });
    }

    // --- Sensitive data: where Full contact details apply (E12) ---------------------
    [HttpGet("sensitive-data")]
    public async Task<IActionResult> GetSensitiveData() => Ok(await _settings.GetSensitiveDataAsync());

    [HttpPut("sensitive-data")]
    public async Task<IActionResult> SetSensitiveData([FromBody] SensitiveDataSettingsInput input, [FromServices] OrgAuthorizationCache authCache)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, dto) = await _settings.SaveSensitiveDataAsync(input);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        authCache.Invalidate(User.OrgId()); // the scope rides on the cached authorization snapshot
        return Ok(dto);
    }

    [HttpGet("invite")]
    public async Task<IActionResult> GetInviteSettings() => Ok(new { token_days = await _settings.GetInviteSettingsAsync() });

    // Gated on ManageTeam, not ManageSettings like most of this controller: this
    // setting has exactly one effect — how long a link TeamController.Create /
    // ResendInvite mints stays usable — so whoever may send an invite is exactly
    // who should be able to tune how long it lasts. Tying it to the broader
    // settings permission would let someone who cannot invite anyone still set
    // this, and refuse someone who can.
    [HttpPut("invite")]
    public async Task<IActionResult> SetInviteSettings([FromBody] InviteSettingsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageTeam))
            return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, tokenDays) = await _settings.SetInviteSettingsAsync(input.TokenDays);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(new { token_days = tokenDays });
    }

    // --- Org calendar (item 1): the org's default timezone, week-start day and
    // non-sending days. Teams override it at PUT /teams/{id}/calendar; nothing
    // downstream should read OrgCalendar directly — see OrgCalendarService.
    [HttpGet("calendar")]
    public async Task<IActionResult> GetCalendar() => Ok(await _settings.GetCalendarAsync(User.OrgId()));

    [HttpPut("calendar")]
    public async Task<IActionResult> SetCalendar([FromBody] CalendarSettingsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });

        var (refusal, dto) = await _settings.SetCalendarAsync(
            User.OrgId(), input.TimeZoneId, input.WeekStartDay, input.NonSendingDays);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // --- Weekly activity quota (calls + meetings logged per rep per week) ---
    [HttpGet("activity-quota")]
    public async Task<IActionResult> GetActivityQuota() => Ok(new { quota = await _settings.GetActivityQuotaAsync() });

    [HttpPut("activity-quota")]
    public async Task<IActionResult> SetActivityQuota([FromBody] QuotaInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var quota = await _settings.SetActivityQuotaAsync(input.Quota);
        return Ok(new { quota });
    }

    // --- Customer payment-reminder email template ---
    // The key and the shipped default live with the other ~17 org settings, on
    // OrgSettings — see OrgSettings.InvoiceEmailKey / DefaultInvoiceEmail.
    [HttpGet("invoice-email")]
    public async Task<IActionResult> GetInvoiceEmail() => Ok(await _settings.GetInvoiceEmailAsync());

    [HttpPut("invoice-email")]
    public async Task<IActionResult> SetInvoiceEmail([FromBody] InvoiceEmailTemplateInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePostWin)) return StatusCode(403, new { error = "Your role cannot change the after-the-win settings." });
        return Ok(await _settings.SetInvoiceEmailAsync(input.Subject, input.Body));
    }

    // --- Lead sources (org-defined; the lead form + filters read these) ---
    [HttpGet("lead-sources")]
    public async Task<IActionResult> GetLeadSources() => Ok(await _settings.GetLeadSourcesAsync());

    [HttpPut("lead-sources")]
    public async Task<IActionResult> SetLeadSources([FromBody] LeadSourcesInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, sources) = await _settings.SetLeadSourcesAsync(input.Sources);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(sources);
    }

    // --- Deal types (E3.11 — org-configurable; the lead form + filters read these) ---
    [HttpGet("deal-types")]
    public async Task<IActionResult> GetDealTypes() => Ok(await _settings.GetDealTypesAsync());

    [HttpPut("deal-types")]
    public async Task<IActionResult> SetDealTypes([FromBody] DealTypesInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, types) = await _settings.SetDealTypesAsync(input.Types);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(types);
    }

    // --- Terminology (E3.5 — per-org display labels for Lead/Account/Contact/Deal/
    // Quote/Invoice/Playbook/Stage/Rep; the desktop's useTerm() reads these. API
    // keys, routes and enum values never change; this is display text only.) ---
    [HttpGet("terminology")]
    public async Task<IActionResult> GetTerminology() => Ok(await _settings.GetTerminologyAsync());

    [HttpPut("terminology")]
    public async Task<IActionResult> SetTerminology([FromBody] TerminologyInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, terms) = await _settings.SetTerminologyAsync(input.Terms);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(terms);
    }

    // --- Account relationship types (E3.4 — org-configurable; account detail + the
    // relationship editor read these) ---
    [HttpGet("account-relationship-types")]
    public async Task<IActionResult> GetAccountRelationshipTypes() => Ok(await _settings.GetAccountRelationshipTypesAsync());

    [HttpPut("account-relationship-types")]
    public async Task<IActionResult> SetAccountRelationshipTypes([FromBody] AccountRelationshipTypesInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, types) = await _settings.SetAccountRelationshipTypesAsync(input.Types);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(types);
    }

    // --- Buying roles (E3.3 — org-configurable; the stakeholder panel reads these) ---
    [HttpGet("buying-roles")]
    public async Task<IActionResult> GetBuyingRoles() => Ok(await _settings.GetBuyingRolesAsync());

    [HttpPut("buying-roles")]
    public async Task<IActionResult> SetBuyingRoles([FromBody] BuyingRolesInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, roles) = await _settings.SetBuyingRolesAsync(input.Roles);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(roles);
    }

    // --- Required stakeholder roles (E3.3 — the "requires role" gate + gap detection) ---
    [HttpGet("required-stakeholder-roles")]
    public async Task<IActionResult> GetRequiredStakeholderRoles() => Ok(await _settings.GetRequiredStakeholderRolesAsync());

    [HttpPut("required-stakeholder-roles")]
    public async Task<IActionResult> SetRequiredStakeholderRoles([FromBody] RequiredStakeholderRolesInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, roles) = await _settings.SetRequiredStakeholderRolesAsync(input.Roles);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(roles);
    }

    [HttpGet("lead-source-policy")]
    public async Task<IActionResult> GetLeadSourcePolicy() => Ok(await _settings.GetLeadSourcePolicyAsync());

    [HttpPut("lead-source-policy")]
    public async Task<IActionResult> SetLeadSourcePolicy([FromBody] LeadSourcePolicyInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change this setting." });

        var (refusal, dto) = await _settings.SetLeadSourcePolicyAsync(input.Mode, input.Default);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(dto);
    }

    /// <summary>
    /// GET /settings/lead-taxonomy-usage — per source and per custom field: how
    /// many leads carry it, everything that reads it, and what stops working if
    /// the admin removes it. Backs the "What depends on these" panel, and the
    /// per-source lead counts beside the list.
    ///
    /// Admin-only, matching the sibling reads on this controller — the counts are
    /// whole-org (an admin deciding whether a source is retired needs the org's
    /// number, not their own), so nothing narrower than ManageSettings can see it.
    ///
    /// The assembly itself is SettingsStore.LeadTaxonomyUsageAsync: every input
    /// but the counts is a System type, so the composition belongs in the layer
    /// that may name them.
    /// </summary>
    [HttpGet("lead-taxonomy-usage")]
    public async Task<IActionResult> GetLeadTaxonomyUsage()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot view this setting." });

        return Ok(await _settings.LeadTaxonomyUsageAsync());
    }

    // --- Win/loss reason taxonomy ---
    [HttpGet("close-reasons")]
    public async Task<IActionResult> GetCloseReasons() => Ok(await _settings.GetCloseReasonsAsync());

    [HttpPut("close-reasons")]
    public async Task<IActionResult> SetCloseReasons([FromBody] CloseReasonsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        return Ok(await _settings.SaveCloseReasonsAsync(input.Won, input.Lost));
    }

    // --- H6: org-level close-date policy for a reopened-then-rewon/relost deal.
    // The per-stage half (can this stage even be exited backward, and how) lives
    // on the stage itself — see /settings/stages' reopen_policy — because it is
    // a property of the STAGE. This one isn't; it's a property of the whole
    // pipeline's behaviour, so it gets the same small settings-row treatment as
    // close-reasons rather than being bolted onto every stage identically.
    [HttpGet("reopen-policy")]
    public async Task<IActionResult> GetReopenPolicy() => Ok(await _settings.GetReopenPolicyAsync());

    [HttpPut("reopen-policy")]
    public async Task<IActionResult> SetReopenPolicy([FromBody] ReopenSettingsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePipeline)) return StatusCode(403, new { error = "Your role cannot change pipeline stages." });
        return Ok(await _settings.SaveReopenPolicyAsync(input));
    }

    // Bug 2: which deal custom fields an accepted generated proposal's Year 1 / Year 2 totals are written to (null = not written).
    [HttpGet("proposal-fee-fields")]
    public async Task<IActionResult> GetProposalFeeFields() => Ok(await _settings.GetProposalFeeFieldsAsync());

    [HttpPut("proposal-fee-fields")]
    public async Task<IActionResult> SetProposalFeeFields([FromBody] ProposalFeeFieldsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (saved, error) = await _settings.SaveProposalFeeFieldsAsync(input);
        return error is not null ? BadRequest(new { error }) : Ok(saved);
    }

    [HttpGet("invoice-profile")]
    public async Task<IActionResult> GetInvoiceProfile() => Ok(await _settings.GetInvoiceProfileAsync());

    [HttpPut("invoice-profile")]
    public async Task<IActionResult> SetInvoiceProfile([FromBody] InvoiceProfileInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePostWin)) return StatusCode(403, new { error = "Your role cannot change the after-the-win settings." });
        var (refusal, profile) = await _settings.SetInvoiceProfileAsync(
            input.VatRate, input.Trn, input.LegalName, input.LegalAddress, input.TaxLabel, input.QuoteOverDiscountPolicy, input.QuoteDiscountLimits);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(profile);
    }

    // --- "Needs attention" risk weights (audit H16) -------------------------
    // The weighting behind RepRiskRow.Score on GET /reports/needs-you-today —
    // see ReportsController.NeedsYouToday, the only reader. Same
    // JSON-blob-in-Settings shape as InvoiceProfile above: one row, deserialize
    // with a fallback default rather than one Settings row per field.
    // The ceiling exists HERE because the clients clamp to it, and a bound that
    // only one side enforces is not a bound — it is two definitions of "legal"
    // that disagree, which is the failure the other-settings screen already
    // warns about for the SLA and quota ranges.
    //
    // 100, not a tighter number, and deliberately. Only the RATIOS between the
    // three weights affect the ordering, so the bound is not expressing a view
    // about what an org should want — it exists to refuse the values that make
    // the SUM meaningless (1e300 and friends are finite and non-negative, and
    // pass every other check here). A first attempt at 10 was rejected by an
    // existing test that writes 100 to prove the score reads stored settings:
    // a bound low enough to be tripped by a plausible configuration is a policy
    // decision wearing a validator's clothes, and policy here belongs to the org.
    // The number itself now lives on SettingsProcess.MaxRiskWeight, the layer
    // that actually enforces it.
    public const double MaxRiskWeight = SettingsProcess.MaxRiskWeight;

    // Open to anyone signed in — the leaderboard/dashboard risk view needs the
    // weights to render even for a rep, mirroring GetPaymentWorkflow below.
    [HttpGet("risk-weights")]
    public async Task<IActionResult> GetRiskWeights() => Ok(await _settings.GetRiskWeightsAsync());

    [HttpPut("risk-weights")]
    public async Task<IActionResult> SetRiskWeights([FromBody] RiskWeightsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, weights) = await _settings.SetRiskWeightsAsync(input.OverdueWeight, input.StalledWeight, input.RegressedWeight);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(weights);
    }

    // E2.0 decision 5 — the org-configurable task snooze quick list (default 1/3/7
    // days). Open to anyone signed in, same as risk-weights above: the task drawer
    // needs the options to render for a rep, not just an admin.
    [HttpGet("task-snooze-options")]
    public async Task<IActionResult> GetTaskSnoozeOptions() => Ok(await _settings.GetTaskSnoozeOptionsAsync());

    [HttpPut("task-snooze-options")]
    public async Task<IActionResult> SetTaskSnoozeOptions([FromBody] TaskSnoozeOptionsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, options) = await _settings.SetTaskSnoozeOptionsAsync(input.QuickDays);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(options);
    }

    // E2.2, design doc §6 / owner answer §14.2 — the org's automation limits
    // (max live automations, actions/minute, chain depth). Open to anyone
    // signed in, same as risk-weights/task-snooze-options above: the
    // automations library (admin-only itself) still needs these to render the
    // "N of 200 live" line without a second round trip through ManageSettings.
    [HttpGet("automation-limits")]
    public async Task<IActionResult> GetAutomationLimits() => Ok(await _settings.GetAutomationLimitsAsync());

    [HttpPut("automation-limits")]
    public async Task<IActionResult> SetAutomationLimits([FromBody] AutomationLimitsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, limits) = await _settings.SetAutomationLimitsAsync(
            input.MaxLiveAutomations, input.MaxActionsPerMinute, input.MaxChainDepth);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(limits);
    }

    // --- Payment workflow (won-deal -> draft invoice -> send reminder ->
    // collection task). GET is open to anyone signed in — reps need it to
    // render the close-deal flow (term picker); PUT is manager/admin only,
    // matching SetSla/SetActivityQuota.
    [HttpGet("payment-workflow")]
    public async Task<IActionResult> GetPaymentWorkflow() => Ok(await _settings.GetPaymentWorkflowAsync());

    [HttpPut("payment-workflow")]
    public async Task<IActionResult> SetPaymentWorkflow([FromBody] PaymentWorkflowConfigInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePostWin)) return StatusCode(403, new { error = "Your role cannot change the after-the-win settings." });
        if (_settings.PaymentWorkflowProblem(input) is { } problem) return BadRequest(new { error = problem });
        return Ok(await _settings.SavePaymentWorkflowAsync(input));
    }

    // --- Email provider (org-level) ---
    //
    // Secrets are WRITE-ONLY. The GET returns `smtp_password_set: true|false` and
    // never the value nor a masked version: a masked secret invites someone to paste
    // it back, and an echoed one leaks its length and shape. The PUT distinguishes
    // three cases through a sentinel rather than a plain null, because JSON cannot
    // tell an omitted field from an explicit null and collapsing them means an admin
    // who edits the from-address without retyping the password silently wipes it:
    //
    //   omitted   -> leave the stored secret alone
    //   "clear"   -> delete it (SettingsStore.SecretClearSentinel)
    //   any value -> replace it

    [HttpGet("email-provider")]
    public async Task<IActionResult> GetEmailProvider()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot view this setting." });

        return Ok(await _settings.GetEmailProviderAsync());
    }

    [HttpPut("email-provider")]
    public async Task<IActionResult> SetEmailProvider([FromBody] EmailProviderInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change this setting." });

        var (refusal, dto) = await _settings.SetEmailProviderAsync(input, User.OrgId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // POST /settings/email-provider/test — send one message to the caller's own
    // address. Deliberately only to the caller: a test button that can mail anyone is
    // an open relay with a nicer name.
    [HttpPost("email-provider/test")]
    public async Task<IActionResult> TestEmailProvider()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change this setting." });

        var result = await _settings.SendTestEmailAsync(User.UserId());
        if (result.Ok) return Ok(new { ok = true, sent_to = result.SentTo });
        // The status rides along only when the resolver refused before sending, so
        // the screen can tell "not configured" from "the provider said no".
        return result.Status is null
            ? BadRequest(new { error = result.Reason })
            : BadRequest(new { error = result.Reason, status = result.Status });
    }

    // AI provider (org-level, E4.1 slices 1-2). Same shape as the email-provider
    // trio above: GET never returns a secret (there is none on this row — see
    // AiProviderSetting's doc comment), a partial PUT merges onto what's stored,
    // and Bedrock's actual credentials round-trip through the existing generic
    // /integrations/ai.bedrock/credentials endpoints, not through this one.

    [HttpGet("ai-provider")]
    public async Task<IActionResult> GetAiProvider()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot view this setting." });

        return Ok(await _settings.GetAiProviderAsync());
    }

    [HttpPut("ai-provider")]
    public async Task<IActionResult> SetAiProvider([FromBody] AiProviderInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change this setting." });

        var (refusal, dto) = await _settings.SetAiProviderAsync(input, User.OrgId(), User.UserId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // POST /settings/ai-provider/test — reports the resolver's verdict; no live
    // Bedrock call in this build (E4 slice 3 adds one).
    [HttpPost("ai-provider/test")]
    public async Task<IActionResult> TestAiProviderConnection()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change this setting." });

        var result = await _settings.TestAiProviderConnectionAsync();
        return result.Ok
            ? Ok(new { ok = true, status = result.Status })
            : BadRequest(new { error = result.Reason, status = result.Status });
    }

    // --- Lead-card swipe actions, per team (phone only) ---
    //
    // GET is open to anyone signed in, like the stage and lead-form config: every
    // rep needs it to render their own list at all. The write endpoints are
    // manager/admin, and a team override additionally requires that the caller
    // could administer that team — the same rule TeamsController applies to a
    // rename, so a manager cannot reconfigure a team they are not in.

    [HttpGet("swipe-actions")]
    public async Task<IActionResult> GetMySwipeActions() =>
        Ok(await _settings.ResolveSwipeActionsAsync(User.UserId()));

    [HttpGet("swipe-actions/config")]
    public async Task<IActionResult> GetSwipeActionsConfig()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot view this setting." });

        return Ok(await _settings.SwipeActionsConfigAsync());
    }

    [HttpPut("swipe-actions")]
    public async Task<IActionResult> SetSwipeActions([FromBody] SwipeActionsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change this setting." });

        var result = await _settings.SaveSwipeActionsAsync(input.TeamId, input.Left, input.Right, CanConfigureTeam);
        if (result.NotFound) return NotFound(new { error = "Team not found" });
        if (result.Forbidden) return StatusCode(403, new { error = "You can only configure teams you belong to." });
        return Ok(result.Saved);
    }

    // Drops a team's override so it inherits the org default again. Distinct from
    // saving two empty sides, which is the equally valid "this team gets no swipe
    // actions at all" — one is inheritance, the other is a choice.
    [HttpDelete("swipe-actions/{teamId:guid}")]
    public async Task<IActionResult> ClearSwipeActions(Guid teamId)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change this setting." });
        if (!CanConfigureTeam(teamId))
            return StatusCode(403, new { error = "You can only configure teams you belong to." });

        await _settings.ClearSwipeActionsAsync(teamId);
        return Ok(new { ok = true });
    }

    // A fact about the CALLER, read off their claims — so it stays here, like
    // every other permission check on this controller, and travels down to the
    // write as a predicate rather than being re-derived below the HTTP layer.
    private bool CanConfigureTeam(Guid teamId) => User.IsOrgAdmin() || User.TeamScope().Covers(teamId);

    // --- Lead form layout (the admin-built form: fields, order, rules) ---
    // GET is open to anyone signed in — every rep needs it to render the form
    // at all, exactly like the stage config. PUT is manager/admin only.
    [HttpGet("lead-form")]
    public async Task<IActionResult> GetLeadForm() => Ok(await _settings.GetLeadFormAsync(User.Role()));

    // What the designer opens — the newest version, published or not, so an
    // unfinished draft is resumed rather than silently lost.
    [HttpGet("lead-form/draft")]
    public async Task<IActionResult> GetLeadFormDraft()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot edit the lead form." });
        return Ok(await _settings.GetLeadFormDraftAsync());
    }

    [HttpGet("lead-form/versions")]
    public async Task<IActionResult> GetLeadFormVersions()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot edit the lead form." });
        return Ok(await _settings.LeadFormVersionsAsync());
    }

    // Save without going live. Reps keep rendering the published version.
    [HttpPut("lead-form/draft")]
    public Task<IActionResult> SaveLeadFormDraft([FromBody] LeadFormSchemaModel input) =>
        WriteLeadFormAsync(input, publish: false);

    // Make it live. PUT /lead-form is the same thing under the plain path,
    // because "save the lead form" from the designer means publish it.
    [HttpPut("lead-form")]
    public Task<IActionResult> PublishLeadForm([FromBody] LeadFormSchemaModel input) =>
        WriteLeadFormAsync(input, publish: true);

    // The one way back to an earlier version: it loads into the DRAFT, and going live is the normal publish.
    [HttpPost("lead-form/versions/{version:int}/restore")]
    public async Task<IActionResult> RestoreLeadForm(int version)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change the lead form." });
        var restored = await _settings.RestoreLeadFormAsync(version, User.UserId());
        if (restored is null) return NotFound(new { error = $"There is no version {version} to restore." });
        return Ok(restored);
    }

    private async Task<IActionResult> WriteLeadFormAsync(LeadFormSchemaModel input, bool publish)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change the lead form." });

        var (refusal, saved) = await _settings.WriteLeadFormAsync(input, publish, User.UserId());
        if (refusal is null) return Ok(saved);
        // A schema that fails validation carries the code and the per-field
        // problems the designer highlights; "the form is empty" is a plain
        // message, and has never carried either.
        return refusal.SchemaInvalid
            ? BadRequest(new
            {
                error = string.Join(" ", refusal.Problems),
                code = "invalid_form_schema",
                problems = refusal.Problems,
            })
            : BadRequest(new { error = string.Join(" ", refusal.Problems) });
    }

    /// <summary>
    /// GET /settings/last-updated — when each setting was last changed, for the
    /// admin hub's cards. Manager/admin only, matching every PUT this reports on
    /// (a rep who cannot change a setting has no more use for its history than for
    /// its value, and several of the underlying GETs are already gated the same
    /// way — e.g. inbound, routing).
    ///
    /// One flat dictionary, keyed by the SAME setting key each service already
    /// uses rather than by admin-hub route: the backend owns those keys and
    /// nothing else, and a route-keyed shape would make this reach into
    /// packages/core's admin-sections list to know what a screen is called.
    /// Grouping several keys under one settings CARD (e.g. "Website leads" reads
    /// both inbound_api_key and inbound_lead_owner) is a client-side join against
    /// that same list, not a decision made here.
    ///
    /// What is read, and the trap in adding a table, is documented on
    /// SettingsStore.SettingsLastUpdatedAsync.
    /// </summary>
    [HttpGet("last-updated")]
    public async Task<IActionResult> GetLastUpdated()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot view settings history." });

        return Ok(await _settings.SettingsLastUpdatedAsync());
    }
}

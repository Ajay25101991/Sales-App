using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Tags;
using SalesApi.ProcessLayer.Tags;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Free-form lead labels — see <see cref="SalesApi.Models.Tag"/> for why these
/// are not folded into <see cref="SalesApi.Models.CustomFieldDef"/>.
///
/// <para><b>Two permissions, deliberately.</b> <c>tags.create</c> ships with the
/// everyday writes so anyone editing a lead can mint a label by typing it;
/// <c>tags.manage</c> is manager+ because rename, merge and delete act across
/// every lead (and account) carrying the tag at once. GET is open to any
/// signed-in user — you cannot filter or search by something you are not
/// allowed to read.</para>
///
/// <para><b>No pagination here, on purpose</b> — same reasoning as
/// GET /custom-fields. A tag list is a vocabulary, not a register: the client
/// renders it as a filter bar and a type-ahead, both of which need the whole
/// set to be useful. Normalization keeps the set small by construction; an org
/// with hundreds of tags is a curation problem, not a paging one.</para>
///
/// <para>MIGRATED to the layered API (step 8): this controller now only
/// routes, authenticates, authorises and chooses the HTTP status. Every rule —
/// normalization identity, the rename-collides-is-a-merge decision, colour
/// validation — lives in <see cref="TagsExperience"/>, which enforces it again
/// independently of this endpoint. Tenant scoping is still enforced below
/// both of them: every query in <see cref="SalesApi.SystemLayer.Tags.TagStore"/>
/// runs through <see cref="SalesApi.Data.AppDbContext"/>'s tenant query filter
/// (Tag/LeadTag both implement <c>ITenantEntity</c>), so a caller can never
/// read, rename, merge or delete another org's tag — proven by
/// <c>TagsControllerScopingTests</c>.</para>
/// </summary>
[ApiController]
[Authorize]
[Route("tags")]
public class TagsController : ControllerBase
{
    private readonly TagsExperience _tags;
    public TagsController(TagsExperience tags) => _tags = tags;

    // ---- GET /tags -------------------------------------------------------

    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] string? q) =>
        Ok(await _tags.SearchAsync(q, HttpContext.RequestAborted));

    // ---- POST /tags ------------------------------------------------------

    /// <summary>
    /// Create a tag, or return the existing one with the same normalized name.
    ///
    /// <para><b>Idempotent by design, and 200 rather than 409 on a repeat.</b>
    /// The lead form creates tags as a side effect of typing; making the caller
    /// distinguish "created" from "already existed" would push the dedupe
    /// decision into every client, and the whole point of normalization is that
    /// there is one answer to "is this the same tag".</para>
    /// </summary>
    [RequirePermission(OrganizationPermissions.TagCreate)]
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateTagInput input)
    {
        var (refusal, dto, created) = await _tags.CreateAsync(
            input.Name, input.Color, User.UserId(), HttpContext.RequestAborted);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return created ? CreatedAtAction(nameof(Get), new { }, dto) : Ok(dto);
    }

    // ---- PATCH /tags/{id} ------------------------------------------------

    /// <summary>
    /// Rename or recolour. A rename whose normalized form already belongs to
    /// ANOTHER tag performs a merge into that tag and returns it.
    ///
    /// <para>Refusing with a 409 would be the obvious alternative and is worse:
    /// the reason a manager renames "e-inv" to "e-invoicing" is almost always
    /// that both exist and they want one. Making that a two-step dance (rename
    /// fails -&gt; go find merge -&gt; pick the target again) invites them to
    /// delete one instead, which silently strips the label from every lead
    /// carrying it.</para>
    /// </summary>
    [RequirePermission(OrganizationPermissions.TagManage)]
    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateTagInput input)
    {
        var (refusal, dto) = await _tags.UpdateAsync(id, input.Name, input.Color, HttpContext.RequestAborted);
        if (refusal is not null)
            return refusal.NotFound
                ? NotFound(new { error = refusal.Reason })
                : BadRequest(new { error = refusal.Reason });
        return Ok(dto);
    }

    // ---- POST /tags/{id}/merge -------------------------------------------

    [RequirePermission(OrganizationPermissions.TagManage)]
    [HttpPost("{id:guid}/merge")]
    public async Task<IActionResult> Merge(Guid id, [FromBody] MergeTagInput input)
    {
        var (refusal, dto) = await _tags.MergeAsync(id, input.IntoTagId, HttpContext.RequestAborted);
        if (refusal is not null)
            return refusal.NotFound
                ? NotFound(new { error = refusal.Reason })
                : BadRequest(new { error = refusal.Reason });
        return Ok(dto);
    }

    // ---- DELETE /tags/{id} -----------------------------------------------

    /// <summary>
    /// Delete a tag and strip it from every lead.
    ///
    /// <para>Unlike, say, a custom field (which is archived, never hard-deleted,
    /// because historical values would otherwise lose their label) this succeeds
    /// even while in use: removing a label from the pipeline IS the operation,
    /// and a lead loses nothing else with it. GET's usage count is what makes it
    /// an informed decision — the client shows it in the confirmation, per the
    /// caller's requirement that a delete report usage first.</para>
    /// </summary>
    [RequirePermission(OrganizationPermissions.TagManage)]
    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var refusal = await _tags.DeleteAsync(id, HttpContext.RequestAborted);
        if (refusal is not null) return NotFound(new { error = refusal.Reason });
        return NoContent();
    }
}

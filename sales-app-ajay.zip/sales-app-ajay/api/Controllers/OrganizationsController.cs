using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Organizations;
using SalesApi.ProcessLayer.Organizations;
using SalesApi.Services;

namespace SalesApi.Controllers;

// A user's own organization (tenant). Orgs are created at signup; here a manager
// can view and rename their org. Scoped to the caller's org — no cross-tenant
// access.
//
// API-led migration (step 8): routing, permission checks and status selection
// stay here; the org read/write and the offboarding orchestration live in
// SalesApi.ExperienceLayer.Organizations.OrganizationsExperience / ProcessApi
// / SystemApi. The ISO-4217 currency allow-list USED to stay here for want of a
// shared home — AdminController read it across as
// OrganizationsController.Currencies. Migrating Admin ended that: it is now
// OrgCurrencies.Supported in SalesApi.Contracts, read by both controllers.
[ApiController]
[Authorize]
[Route("organizations")]
public class OrganizationsController : ControllerBase
{
    private readonly OrganizationsExperience _organizations;
    public OrganizationsController(OrganizationsExperience organizations)
    {
        _organizations = organizations;
    }

    // The supported currency set now lives in SalesApi.Contracts as
    // OrgCurrencies.Supported — see that file for why it could not stay here
    // once AdminController was migrated. This alias keeps the membership test
    // below reading the way it did.
    private static HashSet<string> Currencies => OrgCurrencies.Supported;

    // Returns the caller's own organization (a 0/1-item list for client simplicity).
    [HttpGet]
    public async Task<IActionResult> Get() => Ok(await _organizations.MineAsync(User.OrgId() ?? Guid.Empty));

    // Update the caller's own organization: name and/or currency (managers /
    // suntech-admins only).
    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] OrganizationInput input)
    {
        if (!(User.IsManager() || User.IsSuntechAdmin()) || id != User.OrgId())
            return StatusCode(403, new { error = "You can only manage your own organization." });

        string? name = null;
        if (input.Name != null)
        {
            name = input.Name.Trim();
            if (name.Length == 0) return BadRequest(new { error = "A name is required" });
        }
        string? currency = null;
        if (input.Currency != null)
        {
            currency = input.Currency.Trim().ToUpperInvariant();
            if (!Currencies.Contains(currency))
                return BadRequest(new { error = "Unsupported currency" });
        }

        var (org, refusal) = await _organizations.UpdateAsync(id, name, currency);
        if (refusal is not null)
            return refusal.NotFound
                ? NotFound(new { error = refusal.Reason })
                : BadRequest(new { error = refusal.Reason });
        return Ok(org);
    }

    // Creates a complete ZIP before issuing a signed, one-hour receipt. The
    // receipt is required by Offboard, so deletion cannot run after a failed or
    // incomplete backup. Org admins are confined to their own org; the platform
    // admin may target any org.
    [HttpGet("{id:guid}/offboarding-backup")]
    public async Task<IActionResult> DownloadOffboardingBackup(Guid id, CancellationToken ct)
    {
        var error = CheckOffboardingAccess(id);
        if (error is not null) return error;

        try
        {
            var artifact = await _organizations.CreateBackupAsync(id, User.UserId(), ct);
            if (artifact is null) return NotFound(new { error = "Organization not found" });
            Response.Headers["X-Offboarding-Receipt"] = artifact.Receipt;
            Response.OnCompleted(() =>
            {
                OrganizationOffboardingService.TryDeleteFile(artifact.Path);
                return Task.CompletedTask;
            });
            return PhysicalFile(artifact.Path, "application/zip", artifact.Filename, enableRangeProcessing: false);
        }
        catch (IncompleteOrganizationBackupException ex)
        {
            return Conflict(new { error = ex.Message });
        }
    }

    // Permanently removes the target tenant only after an exact domain phrase
    // and a valid receipt from a completed backup by the same actor.
    [HttpPost("{id:guid}/offboard")]
    public async Task<IActionResult> Offboard(
        Guid id,
        [FromBody] OrganizationOffboardInput input,
        CancellationToken ct)
    {
        var error = CheckOffboardingAccess(id);
        if (error is not null) return error;

        var (result, refusal) = await _organizations.OffboardAsync(id, input.Confirmation, input.BackupReceipt, User.UserId(), ct);
        if (refusal is not null)
        {
            if (refusal.NotFound) return NotFound(new { error = refusal.Reason });
            if (refusal.Conflict) return Conflict(new { error = refusal.Reason });
            return BadRequest(new { error = refusal.Reason });
        }

        return Ok(new
        {
            deleted = true,
            organization_id = result!.OrganizationId,
            organization_name = result.OrganizationName,
            backup_sha256 = result.BackupSha256,
            deleted_counts = result.Deleted,
            storage_objects_deleted = result.StorageObjectsDeleted,
            storage_cleanup_errors = result.StorageCleanupErrors.Count,
        });
    }

    private IActionResult? CheckOffboardingAccess(Guid id)
    {
        if (!User.CanOffboardOrganization())
            return StatusCode(403, new { error = "Only an organization admin or platform admin can offboard an organization." });
        if (!User.IsSuntechAdmin() && User.OrgId() != id)
            return StatusCode(403, new { error = "Organization admins can only offboard their own organization." });
        return null;
    }
}

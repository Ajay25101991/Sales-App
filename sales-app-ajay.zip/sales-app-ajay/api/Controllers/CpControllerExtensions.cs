using Microsoft.AspNetCore.Mvc;
using SalesApi.ProcessLayer.ChannelPartners;

namespace SalesApi.Controllers;

/// <summary>The one mapping of a channel-partner Process result onto a status, shared by every controller of the module (the partner screens, the portal, usage).</summary>
public static class CpControllerExtensions
{
    /// <summary>A 400 carries the plan's issues so the editor can show them in place; a 404 never says whether the id exists elsewhere.</summary>
    public static IActionResult Respond<T>(this ControllerBase c, CpResult<T> r, int okStatus = 200) => r.Outcome switch
    {
        CpOutcome.NotFound => c.NotFound(new { error = r.Error }),
        CpOutcome.Invalid when r.MissingKeys is not null => c.BadRequest(new { error = r.Error, code = r.Code, missing = r.MissingKeys }),
        CpOutcome.Invalid => c.BadRequest(new { error = r.Error, code = r.Code, issues = r.Issues }),
        CpOutcome.Conflict when r.Missing is not null => c.Conflict(new { error = r.Error, code = r.Code, missing = r.Missing }),
        CpOutcome.Conflict => c.Conflict(new { error = r.Error, code = r.Code }),
        CpOutcome.Forbidden => c.StatusCode(403, new { error = r.Error, code = r.Code }),
        CpOutcome.Unavailable => c.StatusCode(503, new { error = r.Error, code = r.Code }),
        _ => c.StatusCode(okStatus, r.Value),
    };
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.ExperienceLayer.Search;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>E3.9 — the global search palette (desktop ⌘K). Any signed-in
/// caller may search; every group is scoped to what THEY may see, and
/// contact email/phone drop out of the match entirely without
/// contact_details.view — see SearchProcess for the reasoning. This
/// controller routes, resolves the caller's RecordAccessContext and the one
/// permission the palette needs, and nothing else.</summary>
[ApiController]
[Route("search")]
[Authorize]
public class SearchController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly SearchExperience _search;
    public SearchController(CallerContext caller, SearchExperience search)
    {
        _caller = caller;
        _search = search;
    }

    // GET /search?q=&types=lead,account,contact,quote,invoice
    [HttpGet]
    public async Task<IActionResult> Search([FromQuery] string? q, [FromQuery] string? types)
    {
        var ctx = await _caller.ForAsync(User);
        var wantedTypes = string.IsNullOrWhiteSpace(types)
            ? null
            : types.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        var canSeeContactDetails = CallerContext.LeadViewOf(User).CanSeeContactDetails;
        var result = await _search.SearchAsync(ctx, q, wantedTypes, canSeeContactDetails);
        return Ok(result);
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.ChannelPartners;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// The partner portal's API (channel partners Phase 4; owner decisions 4.1 / 4.8): what a signed-in PARTNER sees of its own relationship with us. GET only - there is no write here and
/// no way to add one by accident, because a portal user is refused everywhere that is not marked <see cref="AllowPartnerPortalAttribute"/> (see <c>PortalGuard</c>), and this
/// class and the session actions of <c>AuthController</c> are the only ones that are.
///
/// This controller routes and builds the caller's <see cref="PartnerPortalScope"/> from the principal - the partner comes from the profile row the permission middleware stamped on it,
/// never from the URL or a query string - and passes it DOWN as data. A staff user who calls it has no partner and is told so. An id that belongs to another partner is a 404.
/// </summary>
[ApiController]
[Route("partner-portal")]
[Authorize]
[AllowPartnerPortal]
public class PartnerPortalController : ControllerBase
{
    private readonly PartnerPortalExperience _portal;
    public PartnerPortalController(PartnerPortalExperience portal) => _portal = portal;

    private PartnerPortalScope? Scope() => User.PartnerAccountId() is Guid partner ? new PartnerPortalScope(partner, User.UserId()) : null;

    private ObjectResult NotAPartner() => StatusCode(403, new { error = "This is for partner users.", code = "not_a_partner_user" });

    [HttpGet("me")]
    public async Task<IActionResult> Me(CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _portal.MeAsync(s, ct)) : NotAPartner();

    [HttpGet("overview")]
    public async Task<IActionResult> Overview(CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _portal.OverviewAsync(s, ct)) : NotAPartner();

    [HttpGet("deals")]
    public async Task<IActionResult> Deals(CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _portal.DealsAsync(s, ct)) : NotAPartner();

    [HttpGet("deals/{id:guid}")]
    public async Task<IActionResult> Deal(Guid id, CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _portal.DealAsync(s, id, ct)) : NotAPartner();

    /// <summary>The partner's own earnings and payments, newest first (earning kinds and the payout that settled them; never a receivable or a cost).</summary>
    [HttpGet("entries")]
    public async Task<IActionResult> Entries(CancellationToken ct, [FromQuery] int skip = 0, [FromQuery] int take = 50) =>
        Scope() is { } s ? this.Respond(await _portal.EntriesAsync(s, skip, take, ct)) : NotAPartner();

    [HttpGet("statements")]
    public async Task<IActionResult> Statements(CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _portal.StatementsAsync(s, ct)) : NotAPartner();

    [HttpGet("statements/{id:guid}")]
    public async Task<IActionResult> Statement(Guid id, CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _portal.StatementAsync(s, id, ct)) : NotAPartner();

    /// <summary>The same PDF the channel team emails.</summary>
    [HttpGet("statements/{id:guid}/pdf")]
    public async Task<IActionResult> StatementPdf(Guid id, CancellationToken ct)
    {
        if (Scope() is not { } s) return NotAPartner();
        var r = await _portal.StatementPdfAsync(s, id, ct);
        return r.IsOk ? File(r.Value.Pdf, "application/pdf", r.Value.FileName) : this.Respond(r);
    }

    /// <summary>Approved and paid payouts only.</summary>
    [HttpGet("payouts")]
    public async Task<IActionResult> Payouts(CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _portal.PayoutsAsync(s, ct)) : NotAPartner();

    [HttpGet("payouts/{id:guid}")]
    public async Task<IActionResult> Payout(Guid id, CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _portal.PayoutAsync(s, id, ct)) : NotAPartner();

    /// <summary>Counts reported through this partner by client and month (<c>from</c> / <c>to</c> are YYYY-MM-DD, any day in the month). No charge, no allowance.</summary>
    [HttpGet("usage")]
    public async Task<IActionResult> Usage(CancellationToken ct, [FromQuery] DateOnly? from = null, [FromQuery] DateOnly? to = null) =>
        Scope() is { } s ? this.Respond(await _portal.UsageAsync(s, from, to, ct)) : NotAPartner();
}

/// <summary>
/// The channel team's panel for a partner's portal users: invite a named person (from a contact on the partner's account, or by email), see who can sign in, resend an invite,
/// switch someone off or on. partners.manage; the partner account must be one the caller can see.
/// </summary>
[ApiController]
[Route("channel-partners/{accountId:guid}/portal-users")]   // kind: partner
[Route("accounts/{accountId:guid}/portal-users")]           // kind: customer (E19.1)
[Authorize]
public class PartnerPortalUsersController : ControllerBase
{
    private readonly PartnerPortalUsersExperience _users;
    private readonly CallerContext _caller;
    public PartnerPortalUsersController(PartnerPortalUsersExperience users, CallerContext caller)
    {
        _users = users;
        _caller = caller;
    }

    /// <summary>E19.1: the portal kind is decided by the route this controller was reached on - <c>/channel-partners/{id}/portal-users</c> is the partner portal, <c>/accounts/{id}/portal-users</c> the customer portal.</summary>
    private string Kind() => Request.Path.StartsWithSegments("/channel-partners") ? PortalKinds.Partner : PortalKinds.Customer;

    /// <summary>partners.manage for the partner kind. OPEN QUESTION (E19.1 hand-back): the customer kind uses the same permission until the owner names one - it is the restrictive choice (no rep gets it by default).</summary>
    private bool MayManage() => User.HasPermission(OrganizationPermissions.ManagePartners);

    private ObjectResult No() => StatusCode(403, new { error = Kind() == PortalKinds.Partner ? "Your role cannot manage a partner's portal users." : "Your role cannot manage an account's portal users." });

    /// <summary>The absolute accept-invite link for the portal app. Partners AND customers share ONE portal app, <c>/apps/partner</c> (owner decision 2026-11-04), which shows each kind its own views
    /// after sign-in - so the link is the same path for both kinds.</summary>
    private string BuildPortalInviteUrl(string token) =>
        this.AbsoluteUrl($"/apps/partner/accept-invite?token={Uri.EscapeDataString(token)}");

    [HttpGet("~/channel-partners/{accountId:guid}/usage")]
    public async Task<IActionResult> Usage(Guid accountId, CancellationToken ct, [FromQuery] DateOnly? from = null, [FromQuery] DateOnly? to = null)
    {
        // Any of the three partner permissions (the channel team), like the other partner reads.
        var channel = User.HasPermission(OrganizationPermissions.ManagePartners) || User.HasPermission(OrganizationPermissions.PreparePartnerPayouts)
                      || User.HasPermission(OrganizationPermissions.ApprovePartnerPayouts);
        return !channel ? StatusCode(403, new { error = "Your role cannot open channel partners." })
            : this.Respond(await _users.UsageAsync(await _caller.ForAsync(User), accountId, from, to, ct));
    }

    [HttpGet]
    public async Task<IActionResult> List(Guid accountId, CancellationToken ct) =>
        !MayManage() ? No() : this.Respond(await _users.ListAsync(await _caller.ForAsync(User), accountId, Kind(), ct));

    [HttpPost]
    public async Task<IActionResult> Invite(Guid accountId, [FromBody] PartnerPortalUserInviteInput input, CancellationToken ct) =>
        !MayManage() ? No()
            : this.Respond(await _users.InviteAsync(await _caller.ForAsync(User), accountId, input, User.UserId(), BuildPortalInviteUrl, Kind(), ct), 201);

    [HttpPost("{userId:guid}/resend-invite")]
    public async Task<IActionResult> Resend(Guid accountId, Guid userId, CancellationToken ct) =>
        !MayManage() ? No()
            : this.Respond(await _users.ResendInviteAsync(await _caller.ForAsync(User), accountId, userId, BuildPortalInviteUrl, Kind(), ct));

    [HttpPost("{userId:guid}/deactivate")]
    public async Task<IActionResult> Deactivate(Guid accountId, Guid userId, CancellationToken ct)
    {
        if (!MayManage()) return No();
        var r = await _users.SetActiveAsync(await _caller.ForAsync(User), accountId, userId, false, User.UserId(), Kind(), ct);
        return r.IsOk ? NoContent() : this.Respond(r);
    }

    [HttpPost("{userId:guid}/reactivate")]
    public async Task<IActionResult> Reactivate(Guid accountId, Guid userId, CancellationToken ct)
    {
        if (!MayManage()) return No();
        var r = await _users.SetActiveAsync(await _caller.ForAsync(User), accountId, userId, true, User.UserId(), Kind(), ct);
        return r.IsOk ? NoContent() : this.Respond(r);
    }
}

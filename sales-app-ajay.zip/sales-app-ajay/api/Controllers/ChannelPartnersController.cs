using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.ChannelPartners;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Channel partners, Phase 1 (to-do/partner-management-design.md; owner decisions 2026-10-19). NOT the Partner API: <c>PartnerApiController</c> is the API-key
/// integration surface - this is the channel programme (referrers, resellers, integrators): partner profiles, deal partners, commission plans, the partner ledger,
/// clawback decisions, statements, payouts and the stored aggregate.
///
/// This controller routes, checks permission and picks a status code; it touches no _db. Three permissions gate it:
///   partners.manage           profiles, deal partners, plans, overrides, settings, manual corrections, clawback decisions
///   partners.prepare_payouts  prepare / edit / submit / cancel / mark paid / export a payout
///   partners.approve_payouts  deciding a payout's approval (on /approval-chains/instances/{id}/decide - see ApprovalChainsController)
/// and, underneath them, the sensitive-data category <c>partner_commercials</c> (Process refuses a caller below a raw read for anything with a rate or an amount;
/// below Full for any write). Payout bank details are the ID &amp; bank category. Reading what partners are on a DEAL needs only the deal.
/// </summary>
[ApiController]
[Route("")]
[Authorize]
public class ChannelPartnersController : ControllerBase
{
    private readonly ChannelPartnersExperience _partners;
    private readonly PartnerMoneyExperience _money;
    private readonly PartnerPayoutsExperience _payouts;
    private readonly PartnerRegistrationExperience _registrations;
    private readonly PartnerMilestoneExperience _milestones;
    private readonly PartnerRemittanceExperience _remittances;
    private readonly CallerContext _caller;

    public ChannelPartnersController(
        ChannelPartnersExperience partners, PartnerMoneyExperience money, PartnerPayoutsExperience payouts,
        PartnerRegistrationExperience registrations, PartnerMilestoneExperience milestones, PartnerRemittanceExperience remittances, CallerContext caller)
    {
        _partners = partners;
        _money = money;
        _payouts = payouts;
        _registrations = registrations;
        _milestones = milestones;
        _remittances = remittances;
        _caller = caller;
    }

    // ---- gates --------------------------------------------------------------------------------

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManagePartners);
    /// <summary>Owner 2026-11-16: the deal-partner actions (add, end, repoint) need partners.attribute OR partners.manage (manage implies it).</summary>
    private bool CanAttribute => CanManage || User.HasPermission(OrganizationPermissions.AttributePartners);
    private bool CanPayouts => User.HasPermission(OrganizationPermissions.PreparePartnerPayouts);
    /// <summary>Any of the three: the channel team may open the partner screens.</summary>
    private bool InChannel => CanManage || CanPayouts || User.HasPermission(OrganizationPermissions.ApprovePartnerPayouts);

    private ObjectResult No(string what) => StatusCode(403, new { error = $"Your role cannot {what}." });

    /// <summary>Maps a Process result onto a status. A 400 carries the plan's issues so the editor can show them in place.</summary>
    private IActionResult Respond<T>(CpResult<T> r, int okStatus = 200) => CpControllerExtensions.Respond(this, r, okStatus);   // the module's one mapping

    // ---- settings --------------------------------------------------------------------------------

    /// <summary>The org's partner types / tiers, rep-credit mode and the signed-agreement default. Read by anyone in the channel team (the form needs the lists).</summary>
    [HttpGet("channel-partners/settings")]
    public async Task<IActionResult> Settings()
    {
        if (!InChannel) return No("open channel partners");
        return Ok(await _partners.SettingsAsync());
    }

    [HttpPut("channel-partners/settings")]
    public async Task<IActionResult> SaveSettings([FromBody] ChannelPartnerSettingsInput input)
    {
        if (!CanManage) return No("change channel-partner settings");
        return Respond(await _partners.SaveSettingsAsync(input));
    }

    // ---- profiles --------------------------------------------------------------------------------

    [HttpGet("channel-partners")]
    public async Task<IActionResult> List(CancellationToken ct, [FromQuery] string? status = null, [FromQuery] string? type = null)
    {
        if (!InChannel) return No("open channel partners");
        return Ok(await _partners.ListAsync(await _caller.ForAsync(User), status, type, ct));
    }

    /// <summary>
    /// The lead form's "Partner" picker: partner accounts the form could accept (a profile, status prospect or active), id and name only. Open to any signed-in staff user,
    /// exactly as POST /leads is (there is no separate lead-create permission); a partner-portal user is refused by the portal's default-deny guard like every unmarked route.
    /// </summary>
    [HttpGet("channel-partners/picker")]
    public async Task<IActionResult> Picker(CancellationToken ct) => Ok(await _partners.PickerAsync(ct));

    /// <summary>The partner profile. Also open to partners.attribute holders (the deal's partner card shows who the partner is); the rates, plan name and other commercials stay masked
    /// exactly as for any caller without the Partner commercials category (ToDtoAsync).</summary>
    [HttpGet("channel-partners/{accountId:guid}")]
    public async Task<IActionResult> Get(Guid accountId, CancellationToken ct)
    {
        if (!InChannel && !CanAttribute) return No("open channel partners");
        return Respond(await _partners.GetAsync(await _caller.ForAsync(User), accountId, ct));
    }

    /// <summary>The Partner tab in one call: profile, balances (aggregate-backed), open clawback decisions, deals, current assignment.</summary>
    [HttpGet("channel-partners/{accountId:guid}/overview")]
    public async Task<IActionResult> Overview(Guid accountId, CancellationToken ct)
    {
        if (!InChannel) return No("open channel partners");
        return Respond(await _partners.OverviewAsync(await _caller.ForAsync(User), accountId, ct));
    }

    /// <summary>Makes the account a channel partner. <c>payouts_need_signed_agreement</c> must be stated (Q17).</summary>
    [HttpPost("channel-partners/{accountId:guid}")]
    public async Task<IActionResult> Create(Guid accountId, [FromBody] PartnerProfileInput input, CancellationToken ct)
    {
        if (!CanManage) return No("manage channel partners");
        return Respond(await _partners.CreateAsync(await _caller.ForAsync(User), accountId, input, User.UserId(), ct), 201);
    }

    [HttpPut("channel-partners/{accountId:guid}")]
    public async Task<IActionResult> Update(Guid accountId, [FromBody] PartnerProfileInput input, CancellationToken ct)
    {
        if (!CanManage) return No("manage channel partners");
        return Respond(await _partners.UpdateAsync(await _caller.ForAsync(User), accountId, input, ct));
    }

    /// <summary>Partner terms (D3): how many in-progress reseller deals of this partner a terms change would reach. Drives the "also update N open deals?" prompt.</summary>
    [HttpGet("channel-partners/{accountId:guid}/terms/open-deals")]
    public async Task<IActionResult> TermsOpenDeals(Guid accountId, CancellationToken ct)
    {
        if (!InChannel) return No("open channel partners");
        return Respond(await _partners.TermsOpenDealsAsync(await _caller.ForAsync(User), accountId, ct));
    }

    /// <summary>Rewrites resale / wholesale on exactly those in-progress reseller deals from the partner's current terms. Won deals never change. Same permission as editing the partner.</summary>
    [HttpPost("channel-partners/{accountId:guid}/terms/apply-open-deals")]
    public async Task<IActionResult> ApplyTermsToOpenDeals(Guid accountId, CancellationToken ct)
    {
        if (!CanManage) return No("manage channel partners");
        return Respond(await _partners.ApplyTermsToOpenDealsAsync(await _caller.ForAsync(User), accountId, ct));
    }

    [HttpDelete("channel-partners/{accountId:guid}")]
    public async Task<IActionResult> Delete(Guid accountId, CancellationToken ct)
    {
        if (!CanManage) return No("manage channel partners");
        var r = await _partners.DeleteAsync(await _caller.ForAsync(User), accountId, ct);
        return r.IsOk ? NoContent() : Respond(r);
    }

    // ---- deal partners -----------------------------------------------------------------------------

    /// <summary>The partners on a deal, with role and registration. Anyone who can see the deal may read this; rates and amounts come back null below a raw Partner commercials read.</summary>
    [HttpGet("leads/{leadId:guid}/channel-partners")]
    public async Task<IActionResult> DealPartners(Guid leadId, CancellationToken ct, [FromQuery(Name = "include_ended")] bool includeEnded = false) =>
        Respond(await _partners.DealPartnersAsync(await _caller.ForAsync(User), leadId, includeEnded, ct));

    [HttpPost("leads/{leadId:guid}/channel-partners")]
    public async Task<IActionResult> Attribute(Guid leadId, [FromBody] DealPartnerInput input, CancellationToken ct)
    {
        if (!CanAttribute) return No("attribute partners to deals");
        return Respond(await _partners.AttributeAsync(await _caller.ForAsync(User), leadId, input, User.UserId(), ct), 201);
    }

    [HttpPost("channel-partners/deal-partners/{dealPartnerId:guid}/end")]
    public async Task<IActionResult> EndDealPartner(Guid dealPartnerId, [FromBody] DealPartnerEndInput input, CancellationToken ct)
    {
        if (!CanAttribute) return No("end a partner attribution");
        return Respond(await _partners.EndDealPartnerAsync(await _caller.ForAsync(User), dealPartnerId, input, User.UserId(), ct));
    }

    [HttpPost("channel-partners/deal-partners/{dealPartnerId:guid}/repoint")]
    public async Task<IActionResult> Repoint(Guid dealPartnerId, [FromBody] DealPartnerRepointInput input, CancellationToken ct)
    {
        if (!CanAttribute) return No("change a deal partner's terms");
        return Respond(await _partners.RepointAsync(await _caller.ForAsync(User), dealPartnerId, input, ct));
    }

    /// <summary>The deals one partner is on (the Partner tab's list). Each row follows its deal's visibility.</summary>
    [HttpGet("channel-partners/{accountId:guid}/deals")]
    public async Task<IActionResult> DealsOfPartner(Guid accountId, CancellationToken ct, [FromQuery(Name = "active_only")] bool activeOnly = true)
    {
        if (!InChannel) return No("open channel partners");
        return Respond(await _partners.DealsOfPartnerAsync(await _caller.ForAsync(User), accountId, activeOnly, ct));
    }

    // ---- plans (draft + immutable versions, like pricing models) -----------------------------------------

    [HttpGet("channel-partners/plans")]
    public async Task<IActionResult> Plans(CancellationToken ct, [FromQuery(Name = "include_archived")] bool includeArchived = false)
    {
        if (!CanManage) return No("manage commission plans");
        if (!Cp.CanReadCommercials(await _caller.ForAsync(User))) return Forbidden();
        return Ok(await _partners.PlansAsync(includeArchived, ct));
    }

    private ObjectResult Forbidden() => StatusCode(403, new { error = "Your role can't see partner commercials.", code = "partner_commercials_hidden" });

    /// <summary>
    /// Plans gate: partners.manage AND a raw (write: full) Partner commercials level. Owner 2026-11-06: when a <paramref name="planId"/> is given, a partners.manage
    /// caller WITHOUT the commercials level passes for a plan they created themselves (anyone who may add a partner may create and publish its plan).
    /// </summary>
    private async Task<IActionResult?> PlanGateAsync(bool write, Guid? planId = null)
    {
        if (!CanManage) return No("manage commission plans");
        var ctx = await _caller.ForAsync(User);
        if (write ? !Cp.CanWriteCommercials(ctx) : !Cp.CanReadCommercials(ctx))
        {
            if (planId is Guid own && await _partners.PlanCreatedByAsync(own, User.UserId())) return null;
            return write
                ? BadRequest(new { error = Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), code = SensitiveWriteGuard.Code, fields = new[] { "partner_plan" } })
                : Forbidden();
        }
        return null;
    }

    [HttpGet("channel-partners/plans/{planId:guid}")]
    public async Task<IActionResult> Plan(Guid planId, CancellationToken ct) =>
        await PlanGateAsync(false, planId) ?? Respond(await _partners.PlanAsync(planId, ct));

    [HttpPost("channel-partners/plans")]
    public async Task<IActionResult> CreatePlan([FromBody] PartnerPlanCreateInput input, CancellationToken ct) =>
        // Owner 2026-11-06: partners.manage alone may create a plan (the add-partner form); the commercials level is not needed to START one.
        !CanManage ? No("manage commission plans") : Respond(await _partners.CreatePlanAsync(input, User.UserId(), ct), 201);

    /// <summary>Saves the draft. Rule problems do not refuse the save; they come back in <c>validation</c>.</summary>
    [HttpPut("channel-partners/plans/{planId:guid}")]
    public async Task<IActionResult> SavePlanDraft(Guid planId, [FromBody] PartnerPlanDraftInput input, CancellationToken ct) =>
        await PlanGateAsync(true, planId) ?? Respond(await _partners.SavePlanDraftAsync(planId, input, User.UserId(), ct));

    [HttpPost("channel-partners/plans/{planId:guid}/validate")]
    public async Task<IActionResult> ValidatePlan(
        Guid planId, [FromBody] PartnerPlanContentDto? body, CancellationToken ct, [FromQuery(Name = "for_publish")] bool forPublish = false) =>
        await PlanGateAsync(false, planId) ?? Respond(await _partners.ValidatePlanAsync(planId, body, forPublish, ct));

    /// <summary>What the rule (the body, else the stored draft) would earn on <c>collected</c> ex-VAT money - the editor's live preview, on the real engine.</summary>
    [HttpPost("channel-partners/plans/{planId:guid}/preview")]
    public async Task<IActionResult> PreviewPlan(
        Guid planId, [FromBody] PartnerPlanContentDto? body, CancellationToken ct, [FromQuery] decimal collected = 0m, [FromQuery(Name = "deal_base")] decimal dealBase = 0m) =>
        await PlanGateAsync(false, planId) ?? Respond(await _partners.PreviewPlanAsync(planId, body, collected, dealBase, ct));

    [HttpPost("channel-partners/plans/{planId:guid}/publish")]
    public async Task<IActionResult> PublishPlan(Guid planId, CancellationToken ct) =>
        await PlanGateAsync(true, planId) ?? Respond(await _partners.PublishPlanAsync(planId, User.UserId(), ct), 201);

    [HttpGet("channel-partners/plans/{planId:guid}/versions")]
    public async Task<IActionResult> PlanVersions(Guid planId, CancellationToken ct) =>
        await PlanGateAsync(false, planId) ?? Respond(await _partners.PlanVersionsAsync(planId, ct));

    [HttpGet("channel-partners/plans/{planId:guid}/versions/{version:int}")]
    public async Task<IActionResult> PlanVersion(Guid planId, int version, CancellationToken ct) =>
        await PlanGateAsync(false, planId) ?? Respond(await _partners.PlanVersionAsync(planId, version, ct));

    [HttpPost("channel-partners/plans/{planId:guid}/versions/{version:int}/restore")]
    public async Task<IActionResult> RestorePlanVersion(Guid planId, int version, CancellationToken ct, [FromQuery(Name = "replace_draft")] bool replaceDraft = false) =>
        await PlanGateAsync(true) ?? Respond(await _partners.RestorePlanVersionAsync(planId, version, replaceDraft, User.UserId(), ct));

    [HttpPost("channel-partners/plans/{planId:guid}/archive")]
    public async Task<IActionResult> ArchivePlan(Guid planId, CancellationToken ct) =>
        await PlanGateAsync(true) ?? Respond(await _partners.SetPlanArchivedAsync(planId, true, ct));

    [HttpPost("channel-partners/plans/{planId:guid}/unarchive")]
    public async Task<IActionResult> UnarchivePlan(Guid planId, CancellationToken ct) =>
        await PlanGateAsync(true) ?? Respond(await _partners.SetPlanArchivedAsync(planId, false, ct));

    // ---- per-partner assignment (override with a reason) -------------------------------------------------

    [HttpGet("channel-partners/{accountId:guid}/assignments")]
    public async Task<IActionResult> Assignments(Guid accountId, CancellationToken ct) =>
        await PlanGateAsync(false) ?? Respond(await _partners.AssignmentsAsync(accountId, ct));

    [HttpPost("channel-partners/{accountId:guid}/assignments")]
    public async Task<IActionResult> Assign(Guid accountId, [FromBody] PartnerPlanAssignmentInput input, CancellationToken ct) =>
        await PlanGateAsync(true) ?? Respond(await _partners.AssignAsync(accountId, input, User.UserId(), ct), 201);

    // ---- ledger / decisions / statements / stats ------------------------------------------------------------

    /// <summary>A partner's ledger or one deal's (<c>partner_account_id</c>, <c>lead_id</c> or <c>deal_partner_id</c> is required). Newest first; the header totals cover the whole filtered set.</summary>
    [HttpGet("channel-partners/ledger")]
    public async Task<IActionResult> Ledger(
        CancellationToken ct,
        [FromQuery(Name = "partner_account_id")] Guid? partnerAccountId = null, [FromQuery(Name = "lead_id")] Guid? leadId = null,
        [FromQuery(Name = "deal_partner_id")] Guid? dealPartnerId = null, [FromQuery] string? kind = null,
        [FromQuery] DateTime? from = null, [FromQuery] DateTime? to = null, [FromQuery] bool? settled = null,
        [FromQuery] int skip = 0, [FromQuery] int take = 50, [FromQuery] string? direction = null)
    {
        if (!InChannel) return No("see the partner ledger");
        // direction = payable (default - exactly what Phase 1 returned) | cost | receivable. One at a time; header totals are for that direction only.
        return Respond(await _money.LedgerAsync(await _caller.ForAsync(User), partnerAccountId, leadId, dealPartnerId, kind, from, to, settled, skip, take, direction, ct));
    }

    /// <summary>A manual correction: a new signed entry with a reason (never an edit of an old one).</summary>
    [HttpPost("channel-partners/{accountId:guid}/ledger/adjustments")]
    public async Task<IActionResult> Adjust(Guid accountId, [FromBody] PartnerLedgerAdjustInput input, CancellationToken ct)
    {
        if (!CanManage) return No("correct the partner ledger");
        return Respond(await _money.AdjustAsync(await _caller.ForAsync(User), accountId, input, User.UserId(), ct), 201);
    }

    /// <summary>Clawbacks that fell outside the plan's window and wait for a manager (Q14).</summary>
    [HttpGet("channel-partners/clawback-decisions")]
    public async Task<IActionResult> Decisions(
        CancellationToken ct, [FromQuery(Name = "partner_account_id")] Guid? partnerAccountId = null, [FromQuery] string? status = null)
    {
        if (!InChannel) return No("see partner clawbacks");
        return Respond(await _money.DecisionsAsync(await _caller.ForAsync(User), partnerAccountId, status, ct));
    }

    [HttpPost("channel-partners/clawback-decisions/{decisionId:guid}/decide")]
    public async Task<IActionResult> Decide(Guid decisionId, [FromBody] PartnerClawbackDecideInput input, CancellationToken ct)
    {
        if (!CanManage) return No("decide a partner clawback");
        return Respond(await _money.DecideAsync(await _caller.ForAsync(User), decisionId, input, User.UserId(), ct));
    }

    [HttpGet("channel-partners/{accountId:guid}/statements")]
    public async Task<IActionResult> Statements(Guid accountId, CancellationToken ct, [FromQuery] string? direction = null)
    {
        if (!InChannel) return No("see partner statements");
        return Respond(await _money.StatementsAsync(await _caller.ForAsync(User), accountId, direction, ct));
    }

    /// <summary>The statement for a period, computed now and not stored (default: the previous calendar month).</summary>
    [HttpPost("channel-partners/{accountId:guid}/statements/preview")]
    public async Task<IActionResult> PreviewStatement(Guid accountId, [FromBody] PartnerStatementInput? input, CancellationToken ct)
    {
        if (!InChannel) return No("see partner statements");
        return Respond(await _money.PreviewStatementAsync(await _caller.ForAsync(User), accountId, input ?? new PartnerStatementInput(null, null), ct));
    }

    /// <summary>Freezes the period's statement under the next STM number.</summary>
    [HttpPost("channel-partners/{accountId:guid}/statements")]
    public async Task<IActionResult> IssueStatement(Guid accountId, [FromBody] PartnerStatementInput? input, CancellationToken ct)
    {
        if (!CanManage && !CanPayouts) return No("issue partner statements");
        return Respond(await _money.IssueStatementAsync(await _caller.ForAsync(User), accountId, input ?? new PartnerStatementInput(null, null), User.UserId(), ct), 201);
    }

    [HttpGet("channel-partners/statements/{statementId:guid}")]
    public async Task<IActionResult> Statement(Guid statementId, CancellationToken ct)
    {
        if (!InChannel) return No("see partner statements");
        return Respond(await _money.StatementAsync(await _caller.ForAsync(User), statementId, ct));
    }

    [HttpGet("channel-partners/statements/{statementId:guid}/pdf")]
    public async Task<IActionResult> StatementPdf(Guid statementId, CancellationToken ct)
    {
        if (!InChannel) return No("see partner statements");
        var r = await _money.StatementPdfAsync(await _caller.ForAsync(User), statementId, ct);
        return r.IsOk ? File(r.Value.Pdf, "application/pdf", r.Value.FileName) : Respond(r);
    }

    /// <summary>The stored aggregate (PartnerStats) per partner per month. Never reads the live ledger.</summary>
    [HttpGet("channel-partners/stats")]
    public async Task<IActionResult> Stats(
        CancellationToken ct, [FromQuery(Name = "partner_account_id")] Guid? partnerAccountId = null, [FromQuery] DateOnly? from = null, [FromQuery] DateOnly? to = null)
    {
        if (!InChannel) return No("see partner figures");
        return Respond(await _money.StatsAsync(await _caller.ForAsync(User), partnerAccountId, from, to, ct));
    }

    /// <summary>The deliberate resync of the stored figures (the drift check only reports; this repairs).</summary>
    [HttpPost("channel-partners/stats/resync")]
    public async Task<IActionResult> ResyncStats(CancellationToken ct, [FromQuery(Name = "partner_account_id")] Guid? partnerAccountId = null)
    {
        if (!CanManage) return No("resync partner figures");
        var r = await _money.ResyncStatsAsync(partnerAccountId, ct);
        return r.IsOk ? NoContent() : Respond(r);
    }

    // ---- payouts ---------------------------------------------------------------------------------------------------

    [HttpGet("channel-partners/payouts")]
    public async Task<IActionResult> Payouts(
        CancellationToken ct, [FromQuery(Name = "partner_account_id")] Guid? partnerAccountId = null, [FromQuery] string? status = null)
    {
        if (!InChannel) return No("see partner payouts");
        return Respond(await _payouts.ListAsync(await _caller.ForAsync(User), partnerAccountId, status, ct));
    }

    [HttpGet("channel-partners/payouts/{id:guid}")]
    public async Task<IActionResult> Payout(Guid id, CancellationToken ct)
    {
        if (!InChannel) return No("see partner payouts");
        return Respond(await _payouts.GetAsync(await _caller.ForAsync(User), id, ct));
    }

    /// <summary>Prepares a DRAFT payout from payable ledger entries (all of the partner's, or <c>entry_ids</c>).</summary>
    [HttpPost("channel-partners/payouts")]
    public async Task<IActionResult> PreparePayout([FromBody] PartnerPayoutPrepareInput input, CancellationToken ct)
    {
        if (!CanPayouts) return No("prepare partner payouts");
        return Respond(await _payouts.PrepareAsync(await _caller.ForAsync(User), input, User.UserId(), ct), 201);
    }

    [HttpPut("channel-partners/payouts/{id:guid}")]
    public async Task<IActionResult> UpdatePayout(Guid id, [FromBody] PartnerPayoutUpdateInput input, CancellationToken ct)
    {
        if (!CanPayouts) return No("prepare partner payouts");
        return Respond(await _payouts.UpdateAsync(await _caller.ForAsync(User), id, input, ct));
    }

    /// <summary>Submits for approval on the org's approval chains. The decision is made on <c>POST /approval-chains/instances/{id}/decide</c> by someone other than the preparer.</summary>
    [HttpPost("channel-partners/payouts/{id:guid}/submit")]
    public async Task<IActionResult> SubmitPayout(Guid id, CancellationToken ct)
    {
        if (!CanPayouts) return No("prepare partner payouts");
        return Respond(await _payouts.SubmitAsync(await _caller.ForAsync(User), id, User.UserId(), ct));
    }

    [HttpPost("channel-partners/payouts/{id:guid}/cancel")]
    public async Task<IActionResult> CancelPayout(Guid id, [FromBody] PartnerPayoutCancelInput input, CancellationToken ct)
    {
        if (!CanPayouts) return No("prepare partner payouts");
        return Respond(await _payouts.CancelAsync(await _caller.ForAsync(User), id, input, ct));
    }

    [HttpPost("channel-partners/payouts/{id:guid}/mark-paid")]
    public async Task<IActionResult> MarkPaid(Guid id, [FromBody] PartnerPayoutMarkPaidInput input, CancellationToken ct)
    {
        if (!CanPayouts) return No("mark partner payouts paid");
        return Respond(await _payouts.MarkPaidAsync(await _caller.ForAsync(User), id, input, User.UserId(), ct));
    }

    /// <summary>The bank CSV for APPROVED payouts (<c>?ids=a,b</c>, or every approved one). Needs a raw read of ID &amp; bank.</summary>
    [HttpGet("channel-partners/payouts/export.csv")]
    public async Task<IActionResult> ExportPayouts(CancellationToken ct, [FromQuery] string? ids = null)
    {
        if (!CanPayouts) return No("export partner payouts");
        List<Guid>? parsed = null;
        if (!string.IsNullOrWhiteSpace(ids))
        {
            parsed = [];
            foreach (var part in ids.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                if (!Guid.TryParse(part, out var id)) return BadRequest(new { error = "ids must be a comma-separated list of payout ids." });
                parsed.Add(id);
            }
        }
        var r = await _payouts.ExportAsync(await _caller.ForAsync(User), parsed, ct);
        return r.IsOk ? File(r.Value.Content, "text/csv; charset=utf-8", r.Value.FileName) : Respond(r);
    }

    // ================================================================================================================
    // PHASE 2 (owner decisions 2026-10-19). Registration is a RECORD; a referral for a client already in the pipeline is decided on the deal;
    // two partners claiming one client is a manager decision; an SI is a cost; an FSP owes us a fee. Same gates as above: partners.manage for
    // writes, the channel team for reads, and the sensitive-data level (Process) for every amount and note.
    // ================================================================================================================

    // ---- registration (a record), the pipeline flag, claim conflicts ---------------------------------------------

    /// <summary>The registrations queue: deal partners that carry a registration (<c>status</c> narrows), or with <c>pipeline_pending=true</c> the referrals flagged against the pipeline and undecided.</summary>
    [HttpGet("channel-partners/registrations")]
    public async Task<IActionResult> Registrations(CancellationToken ct, [FromQuery] string? status = null, [FromQuery(Name = "pipeline_pending")] bool pipelinePending = false)
    {
        if (!InChannel) return No("open partner registrations");
        return Respond(await _registrations.QueueAsync(await _caller.ForAsync(User), status, pipelinePending, ct));
    }

    /// <summary>Records (or changes) the registration: <c>status</c> registered | accepted | declined (none clears), <c>registered_on</c>, <c>notes</c>. No timer, block or accrual change follows.</summary>
    [HttpPut("channel-partners/deal-partners/{dealPartnerId:guid}/registration")]
    public async Task<IActionResult> RecordRegistration(Guid dealPartnerId, [FromBody] DealPartnerRegistrationInput input, CancellationToken ct)
    {
        if (!CanManage) return No("record a partner registration");
        return Respond(await _registrations.RecordAsync(await _caller.ForAsync(User), dealPartnerId, input, User.UserId(), ct));
    }

    /// <summary>Accept or decline a referral flagged against the pipeline. The deal owner or a partner manager; the Process layer enforces which.</summary>
    [HttpPost("channel-partners/deal-partners/{dealPartnerId:guid}/pipeline-decision")]
    public async Task<IActionResult> DecidePipeline(Guid dealPartnerId, [FromBody] PipelineDecisionInput input, CancellationToken ct) =>
        Respond(await _registrations.DecidePipelineAsync(await _caller.ForAsync(User), dealPartnerId, input, User.UserId(), CanManage, ct));

    [HttpGet("channel-partners/conflicts")]
    public async Task<IActionResult> Conflicts(
        CancellationToken ct, [FromQuery] string? status = null, [FromQuery(Name = "partner_account_id")] Guid? partnerAccountId = null, [FromQuery(Name = "lead_id")] Guid? leadId = null)
    {
        if (!InChannel) return No("see partner registration conflicts");
        return Respond(await _registrations.ConflictsAsync(await _caller.ForAsync(User), status, partnerAccountId, leadId, ct));
    }

    /// <summary>Two partners claim one client: always a manager decision. Records the decision and the reason; nothing else changes automatically.</summary>
    [HttpPost("channel-partners/conflicts/{conflictId:guid}/decide")]
    public async Task<IActionResult> DecideConflict(Guid conflictId, [FromBody] PartnerConflictDecideInput input, CancellationToken ct)
    {
        if (!CanManage) return No("decide a partner registration conflict");
        return Respond(await _registrations.DecideConflictAsync(await _caller.ForAsync(User), conflictId, input, User.UserId(), ct));
    }

    // ---- SI milestones (cost) -----------------------------------------------------------------------------------

    /// <summary>An integrator's milestones. Anyone who sees the deal may read them; amounts come back null below a raw Partner commercials read.</summary>
    [HttpGet("channel-partners/deal-partners/{dealPartnerId:guid}/milestones")]
    public async Task<IActionResult> Milestones(Guid dealPartnerId, CancellationToken ct) =>
        Respond(await _milestones.ListAsync(await _caller.ForAsync(User), dealPartnerId, ct));

    [HttpPost("channel-partners/deal-partners/{dealPartnerId:guid}/milestones")]
    public async Task<IActionResult> CreateMilestone(Guid dealPartnerId, [FromBody] DealPartnerMilestoneInput input, CancellationToken ct)
    {
        if (!CanManage) return No("add an integrator milestone");
        return Respond(await _milestones.CreateAsync(await _caller.ForAsync(User), dealPartnerId, input, User.UserId(), ct), 201);
    }

    [HttpPut("channel-partners/milestones/{milestoneId:guid}")]
    public async Task<IActionResult> UpdateMilestone(Guid milestoneId, [FromBody] DealPartnerMilestoneInput input, CancellationToken ct)
    {
        if (!CanManage) return No("change an integrator milestone");
        return Respond(await _milestones.UpdateAsync(await _caller.ForAsync(User), milestoneId, input, ct));
    }

    [HttpDelete("channel-partners/milestones/{milestoneId:guid}")]
    public async Task<IActionResult> DeleteMilestone(Guid milestoneId, CancellationToken ct)
    {
        if (!CanManage) return No("remove an integrator milestone");
        var r = await _milestones.DeleteAsync(await _caller.ForAsync(User), milestoneId, ct);
        return r.IsOk ? NoContent() : Respond(r);
    }

    // Accept / reject / reopen: the DEAL OWNER or a partner manager (owner decision 2.7) - the Process layer enforces which, so a rep who owns the deal can accept
    // without partners.manage. No Partner commercials level is needed: such a rep accepts without ever seeing the amount.
    [HttpPost("channel-partners/milestones/{milestoneId:guid}/accept")]
    public async Task<IActionResult> AcceptMilestone(Guid milestoneId, [FromBody] MilestoneDecisionInput? input, CancellationToken ct) =>
        Respond(await _milestones.AcceptAsync(await _caller.ForAsync(User), milestoneId, input ?? new MilestoneDecisionInput(null), User.UserId(), CanManage, ct));

    [HttpPost("channel-partners/milestones/{milestoneId:guid}/reject")]
    public async Task<IActionResult> RejectMilestone(Guid milestoneId, [FromBody] MilestoneDecisionInput? input, CancellationToken ct) =>
        Respond(await _milestones.RejectAsync(await _caller.ForAsync(User), milestoneId, input ?? new MilestoneDecisionInput(null), User.UserId(), CanManage, ct));

    [HttpPost("channel-partners/milestones/{milestoneId:guid}/reopen")]
    public async Task<IActionResult> ReopenMilestone(Guid milestoneId, [FromBody] MilestoneDecisionInput? input, CancellationToken ct) =>
        Respond(await _milestones.ReopenAsync(await _caller.ForAsync(User), milestoneId, input ?? new MilestoneDecisionInput(null), User.UserId(), CanManage, ct));

    /// <summary>"Partner costs": cost entries (accepted milestones) awaiting a payout, oldest first. Prepare the payout with <c>direction: "cost"</c>.</summary>
    [HttpGet("channel-partners/costs")]
    public async Task<IActionResult> Costs(CancellationToken ct)
    {
        if (!InChannel) return No("see partner costs");
        return Respond(await _milestones.CostsAsync(await _caller.ForAsync(User), ct));
    }

    // ---- FSP remittance (receivable) --------------------------------------------------------------------------

    [HttpGet("channel-partners/remittances")]
    public async Task<IActionResult> Remittances(
        CancellationToken ct, [FromQuery] string? status = null, [FromQuery(Name = "partner_account_id")] Guid? partnerAccountId = null,
        [FromQuery(Name = "deal_partner_id")] Guid? dealPartnerId = null)
    {
        if (!InChannel) return No("see partner remittances");
        return Respond(await _remittances.ListAsync(await _caller.ForAsync(User), partnerAccountId, dealPartnerId, status, ct));
    }

    /// <summary>One partner's payable, cost and receivable balances side by side (never netted) plus its remittances.</summary>
    [HttpGet("channel-partners/{accountId:guid}/receivable")]
    public async Task<IActionResult> Receivable(Guid accountId, CancellationToken ct)
    {
        if (!InChannel) return No("see partner remittances");
        return Respond(await _remittances.BalancesAsync(await _caller.ForAsync(User), accountId, ct));
    }

    /// <summary>Links the deal on the FSP's account that our platform-fee invoice is raised on (one per end-client deal) and creates the remittance.</summary>
    [HttpPost("channel-partners/deal-partners/{dealPartnerId:guid}/billing-deal")]
    public async Task<IActionResult> LinkBillingDeal(Guid dealPartnerId, [FromBody] DealPartnerBillingDealInput input, CancellationToken ct)
    {
        if (!CanManage) return No("link a partner billing deal");
        return Respond(await _remittances.LinkBillingDealAsync(await _caller.ForAsync(User), dealPartnerId, input, User.UserId(), ct), 201);
    }

    /// <summary>The end user's due date and the date the partner collected, as read from its statement. The remittance due is recomputed from the collection date.</summary>
    [HttpPut("channel-partners/remittances/{id:guid}")]
    public async Task<IActionResult> UpdateRemittance(Guid id, [FromBody] PartnerRemittanceUpdateInput input, CancellationToken ct)
    {
        if (!CanManage) return No("change a partner remittance");
        return Respond(await _remittances.UpdateAsync(await _caller.ForAsync(User), id, input, ct));
    }

    [HttpPost("channel-partners/remittances/{id:guid}/link-invoice")]
    public async Task<IActionResult> LinkRemittanceInvoice(Guid id, [FromBody] PartnerRemittanceLinkInvoiceInput input, CancellationToken ct)
    {
        if (!CanManage) return No("link an invoice to a partner remittance");
        return Respond(await _remittances.LinkInvoiceAsync(await _caller.ForAsync(User), id, input, ct));
    }

    [HttpPost("channel-partners/remittances/{id:guid}/waive")]
    public async Task<IActionResult> WaiveRemittance(Guid id, [FromBody] PartnerRemittanceWaiveInput input, CancellationToken ct)
    {
        if (!CanManage) return No("waive a partner remittance");
        return Respond(await _remittances.WaiveAsync(await _caller.ForAsync(User), id, input, User.UserId(), ct));
    }
}

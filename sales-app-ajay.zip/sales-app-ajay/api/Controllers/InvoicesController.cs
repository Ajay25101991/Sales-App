using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Invoices;
using SalesApi.ProcessLayer.Invoices;
using SalesApi.Services;

namespace SalesApi.Controllers;

// Payment collection: invoices raised against won deals and the payments logged
// against them. Scoping mirrors leads/reminders — a rep sees invoices they own
// (the deal owner), managers/admins see the whole team.
//
// MIGRATED to the layered API (api-led migration). Business rules that used to
// live inline here now live in SalesApi.ProcessApi/Invoices/InvoiceProcess.cs,
// reached through SalesApi.ExperienceApi/Invoices/InvoicesExperience.cs. What
// is left here, deliberately: routing, [Authorize]/[RequirePermission], model
// binding, resolving the caller's RecordAccessContext (a System-layer factory
// over the token + the database — the one place this controller still needs
// AppDbContext), and choosing the HTTP status for a Refusal.
[ApiController]
[Route("invoices")]
[Authorize]
[RequirePermission(OrganizationPermissions.ViewFinancials)]
public class InvoicesController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly InvoicesExperience _invoices;
    public InvoicesController(CallerContext caller, InvoicesExperience invoices)
    {
        _caller = caller;
        _invoices = invoices;
    }

    private Task<RecordAccessContext> AccessAsync() => _caller.ForAsync(User);

    // Money masking (invoice-money-masking, owner decision 2026-09-28): the
    // SAME permission AccountsController.CanSeeFullAccountFinancials already
    // gates account receivables on. Invoice ACCESS stays gated on
    // `financials.view` above (RequirePermission on the class); this narrows
    // which FIELDS on an already-readable invoice carry real money.
    private bool CanSeeInvoiceFinancials =>
        User.HasPermission(OrganizationPermissions.ViewAccountFinancials);

    private static IActionResult FromRefusal(InvoiceProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 403 }
        : new BadRequestObjectResult(new { error = refusal.Reason });

    // GET /invoices?status=&overdue=true&search=&account_id=&lead_id=&broken_promise=true
    // (account_id backs the collections-by-customer expand-to-invoices row, E2;
    // lead_id backs the lead-detail draft-invoice badge/raise action;
    // broken_promise backs the chase-list filter, E3).
    [HttpGet]
    public async Task<IActionResult> List(string? status, bool? overdue, string? search, Guid? account_id, Guid? lead_id, bool? broken_promise)
    {
        var rows = await _invoices.ListAsync(await AccessAsync(), status, overdue, search, account_id, lead_id, broken_promise, CanSeeInvoiceFinancials);
        return Ok(rows);
    }

    // GET /invoices/billing-flag?lead_id= — Task 10: the deal's billing flag for finance (null billing_flag = nothing to flag). Read by the
    // After-the-win card. Declared before {id:guid}.
    [HttpGet("billing-flag")]
    public async Task<IActionResult> BillingFlag(Guid lead_id)
    {
        var (refusal, flag) = await _invoices.BillingFlagAsync(await AccessAsync(), lead_id);
        return refusal is not null ? FromRefusal(refusal) : Ok(flag);
    }

    // GET /invoices/credits?account_id=&lead_id= — Q11's customer-credit register (balance, source payment/invoice, date). Declared
    // before {id:guid} so the literal segment matches first.
    [HttpGet("credits")]
    public async Task<IActionResult> Credits(Guid? account_id, Guid? lead_id) =>
        Ok(await _invoices.CreditsAsync(await AccessAsync(), account_id, lead_id, CanSeeInvoiceFinancials));

    // POST /invoices/credits/{id}/apply — apply held credit to one of the customer's open invoices (an ordinary payment tagged as credit).
    [HttpPost("credits/{id:guid}/apply")]
    public async Task<IActionResult> ApplyCredit(Guid id, [FromBody] ApplyCreditInput input)
    {
        var outcome = await _invoices.ApplyCreditAsync(await AccessAsync(), id, input, User.UserId(), CanSeeInvoiceFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(new { credit = outcome.Credit, invoice = outcome.Invoice });
    }

    // POST /invoices/credits/{id}/refund — record that held credit was refunded OUTSIDE the CRM, with a reason (managers).
    [HttpPost("credits/{id:guid}/refund")]
    public async Task<IActionResult> RefundCredit(Guid id, [FromBody] RefundCreditInput input)
    {
        var outcome = await _invoices.RefundCreditAsync(await AccessAsync(), id, input, User.UserId(), CanSeeInvoiceFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(new { credit = outcome.Credit });
    }

    // GET /invoices/discount-residuals — M9's historical exposure, surfaced for
    // review. NOTHING is settled here: the owner was explicit that a residual
    // matching the contracted discount is indistinguishable from a genuine short
    // payment, so this is a list a human confirms, not a rule. Declared before
    // {id:guid} so the literal segment matches first.
    [HttpGet("discount-residuals")]
    public async Task<IActionResult> DiscountResiduals() => Ok(await _invoices.DiscountResidualsAsync(await AccessAsync(), CanSeeInvoiceFinancials));

    // POST /invoices/discount-residuals/{id}/settle — settle a historical
    // residual using whatever owner decision #15 says (discount_taken |
    // write_off).
    [HttpPost("discount-residuals/{id:guid}/settle")]
    public async Task<IActionResult> SettleResidual(Guid id)
    {
        var outcome = await _invoices.SettleResidualAsync(await AccessAsync(), id, User.UserId(), CanSeeInvoiceFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Invoice);
    }

    // POST /invoices/discount-residuals/{id}/dismiss — owner decision #16's
    // `dismissible` triage: judged a genuine short payment, not settled, and
    // taken off the review list without touching the invoice's money at all.
    [HttpPost("discount-residuals/{id:guid}/dismiss")]
    public async Task<IActionResult> DismissResidual(Guid id)
    {
        var outcome = await _invoices.DismissResidualAsync(await AccessAsync(), id, User.UserId(), CanSeeInvoiceFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Invoice);
    }

    // GET /invoices/billable-leads — the raise-invoice pick list (D1: a union,
    // not just fresh deals). Declared before {id:guid} so the literal segment
    // matches first.
    [HttpGet("billable-leads")]
    public async Task<IActionResult> BillableLeads() => Ok(await _invoices.BillableLeadsAsync(await AccessAsync()));

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var outcome = await _invoices.GetAsync(await AccessAsync(), id, CanSeeInvoiceFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Detail);
    }

    // GET /invoices/{id}/pdf — E17.1: the tax invoice as a server-rendered PDF. Same record scoping and the same money masking
    // ("Hidden" without account_financials.view) as the JSON read above; the class-level financials.view gate applies too.
    [HttpGet("{id:guid}/pdf")]
    public async Task<IActionResult> Pdf(Guid id)
    {
        var outcome = await _invoices.PdfAsync(await AccessAsync(), id, CanSeeInvoiceFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : File(outcome.Bytes!, "application/pdf", outcome.FileName);
    }

    // POST /invoices — raise an invoice against a won deal, OR (D1) against an
    // AMC renewal term, the caller can manage.
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] InvoiceInput input)
    {
        var outcome = await _invoices.CreateAsync(await AccessAsync(), input, User.UserId(), CanSeeInvoiceFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Invoice);
    }

    // POST /invoices/{id}/raise — turn a DRAFT invoice into a real one.
    [HttpPost("{id:guid}/raise")]
    public async Task<IActionResult> Raise(Guid id)
    {
        var outcome = await _invoices.RaiseAsync(await AccessAsync(), id, User.UserId(), CanSeeInvoiceFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Invoice);
    }

    // POST /invoices/{id}/record-external — finance completes an expected (draft) invoice with the external system's invoice
    // (number, subtotal, VAT, issue date, due date). Invoicing is done externally; this row is the record of it.
    [HttpPost("{id:guid}/record-external")]
    public async Task<IActionResult> RecordExternal(Guid id, [FromBody] RecordExternalInvoiceInput input)
    {
        var outcome = await _invoices.RecordExternalAsync(await AccessAsync(), id, input, User.UserId(), CanSeeInvoiceFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Invoice);
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] InvoiceInput input)
    {
        var outcome = await _invoices.UpdateAsync(await AccessAsync(), id, input, User.UserId(), CanSeeInvoiceFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Invoice);
    }

    // POST /invoices/{id}/payments — record a payment; recomputes balance + status.
    //
    // Money masking (2026-09-28): a caller without ViewAccountFinancials CAN
    // still reach this action today — it is gated only by the class-level
    // `financials.view` (ViewFinancials), a DIFFERENT, broader permission — and
    // still can after this change. That is a pre-existing inconsistency this
    // story does not resolve (the brief: "don't change it unless it's open to
    // them" — it already is), reported to the coordinator rather than fixed
    // here: closing it would mean deciding whether recording a payment without
    // being able to see the resulting balance is itself disallowed, which is a
    // product decision, not a masking one. The RESPONSE'S money is masked like
    // any other invoice read.
    [HttpPost("{id:guid}/payments")]
    public async Task<IActionResult> RecordPayment(Guid id, [FromBody] PaymentInput input)
    {
        var outcome = await _invoices.RecordPaymentAsync(await AccessAsync(), id, input, User.UserId(), CanSeeInvoiceFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Invoice);
    }

    // POST /invoices/{id}/plan — split the invoice into `count` equal installments
    // every `interval_days` from `start_date`. Replaces any existing plan.
    [HttpPost("{id:guid}/plan")]
    public async Task<IActionResult> SetPlan(Guid id, [FromBody] PlanInput input)
    {
        var outcome = await _invoices.SetPlanAsync(await AccessAsync(), id, input, User.UserId(), CanSeeInvoiceFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Installments);
    }

    // DELETE /invoices/{id}/plan — clear the installment schedule.
    [HttpDelete("{id:guid}/plan")]
    public async Task<IActionResult> ClearPlan(Guid id)
    {
        var outcome = await _invoices.ClearPlanAsync(await AccessAsync(), id);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : NoContent();
    }

    // GET /invoices/{id}/activities
    [HttpGet("{id:guid}/activities")]
    public async Task<IActionResult> Activities(Guid id)
    {
        var (refusal, activities) = await _invoices.ActivitiesAsync(await AccessAsync(), id);
        return refusal is not null ? FromRefusal(refusal) : Ok(activities);
    }

    // POST /invoices/{id}/activities — log a collection touch (call/promise/dispute).
    // PromisedDate/PromisedAmount are only meaningful (and only stored) for type=promise.
    [HttpPost("{id:guid}/activities")]
    public async Task<IActionResult> AddActivity(Guid id, [FromBody] InvoiceActivityInput input)
    {
        var outcome = await _invoices.AddActivityAsync(await AccessAsync(), id, input, User.UserId());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Activity);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var outcome = await _invoices.DeleteAsync(await AccessAsync(), id);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : NoContent();
    }
}

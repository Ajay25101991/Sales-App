using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.SharePointBrowse;
using SalesApi.ProcessLayer.SharePointBrowse;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Browsing SharePoint with the CALLER's own Microsoft sign-in, to attach files that already live there (SharePoint
/// program, Phase 4). Routing, authorization and status-code selection only; the work is in
/// <see cref="SharePointBrowseProcess"/>. Open to every signed-in person: what they may SEE is decided by SharePoint, with
/// their own token - this server grants nothing. A caller who cannot browse right now (switch off, not connected, must sign in
/// again) gets 409 <c>{ error, state }</c> from every list.
/// </summary>
[ApiController]
[Route("sharepoint/browse")]
[Authorize]
public class SharePointBrowseController : ControllerBase
{
    private readonly SharePointBrowseExperience _browse;
    public SharePointBrowseController(SharePointBrowseExperience browse) => _browse = browse;

    private IActionResult FromResult(BrowseResult result)
    {
        if (result.Refusal is not { } r) return Ok(result.Page);
        var body = new { error = r.Message };
        return r.Kind switch
        {
            BrowseRefusalKind.NotReady => Conflict(new SharePointBrowseRefusedDto(r.Message, r.State ?? "unavailable")),
            BrowseRefusalKind.Forbidden => StatusCode(403, body),
            BrowseRefusalKind.NotFound => NotFound(body),
            BrowseRefusalKind.Upstream => StatusCode(502, body),
            _ => BadRequest(body),
        };
    }

    // GET /sharepoint/browse/status - the caller's own state; always 200.
    [HttpGet("status")]
    public async Task<IActionResult> Status() => Ok(await _browse.StatusAsync(User.UserId(), HttpContext.RequestAborted));

    // GET /sharepoint/browse/recent - documents changed in the last 30 days that the person can see.
    [HttpGet("recent")]
    public async Task<IActionResult> Recent([FromQuery] string? cursor = null) =>
        FromResult(await _browse.RecentAsync(User.UserId(), cursor, ct: HttpContext.RequestAborted));

    // GET /sharepoint/browse/sites?search= - sites the person follows, or the ones matching the search.
    [HttpGet("sites")]
    public async Task<IActionResult> Sites([FromQuery] string? search = null, [FromQuery] string? cursor = null) =>
        FromResult(await _browse.SitesAsync(User.UserId(), search, cursor, HttpContext.RequestAborted));

    // GET /sharepoint/browse/sites/{siteId}/libraries
    [HttpGet("sites/{siteId}/libraries")]
    public async Task<IActionResult> Libraries(string siteId, [FromQuery] string? cursor = null) =>
        FromResult(await _browse.LibrariesAsync(User.UserId(), siteId, cursor, HttpContext.RequestAborted));

    // GET /sharepoint/browse/folder?drive_id=&item_id= - children; item_id omitted = the library root.
    [HttpGet("folder")]
    public async Task<IActionResult> Folder(
        [FromQuery(Name = "drive_id")] string? driveId, [FromQuery(Name = "item_id")] string? itemId, [FromQuery] string? cursor = null) =>
        FromResult(await _browse.FolderAsync(User.UserId(), driveId, itemId, cursor, HttpContext.RequestAborted));

    // GET /sharepoint/browse/search?q= - documents matching the text, across what the person can see.
    [HttpGet("search")]
    public async Task<IActionResult> Search([FromQuery] string? q = null, [FromQuery] string? cursor = null) =>
        FromResult(await _browse.SearchAsync(User.UserId(), q, cursor, HttpContext.RequestAborted));
}

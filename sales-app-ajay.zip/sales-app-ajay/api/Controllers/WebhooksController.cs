using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Webhooks;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Outbound webhook subscriptions and their delivery log. Delivery itself is
/// `WebhookDispatchService`/`WebhookDeliveryWorker`; this controller is CRUD
/// plus reads.
///
/// API-led migration (step 8): routing, the `settings.manage` permission
/// check and status selection stay here; event validation, subscription
/// CRUD and the delivery log live in
/// SalesApi.ExperienceLayer.Webhooks.WebhooksExperience / ProcessApi /
/// SystemApi. <see cref="WebhookEvents"/>'s key vocabulary is untouched.
/// </summary>
[ApiController]
[Route("webhooks")]
[Authorize]
public class WebhooksController : ControllerBase
{
    private readonly WebhooksExperience _webhooks;
    public WebhooksController(WebhooksExperience webhooks)
    {
        _webhooks = webhooks;
    }

    private bool CanManage() => User.HasPermission(OrganizationPermissions.ManageSettings);

    /// <summary>The registered event catalogue, for the UI's "event" picker — never free text.</summary>
    [RequirePlanFeature(PlanCatalogue.Features.ApiWebhooks)]
    [HttpGet("events")]
    public IActionResult Events() => Ok(_webhooks.Events());

    /// <summary>E1 step 8 (to-do/e1-event-backbone-design.md §8 step 8): the FULL
    /// grouped catalogue (legacy + every domain-event type), each with its
    /// group, description and documented payload fields — the desktop
    /// developer screen's grouped event picker and "payload" disclosure.
    /// Admin-only, like the rest of this controller.</summary>
    [RequirePlanFeature(PlanCatalogue.Features.ApiWebhooks)]
    [HttpGet("catalog")]
    public IActionResult Catalog()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view the webhook catalogue." });
        return Ok(_webhooks.Catalog());
    }

    [HttpGet]
    public async Task<IActionResult> List()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view webhooks." });
        return Ok(await _webhooks.ListAsync());
    }

    // POST /webhooks — the signing secret is returned exactly once, here.
    [RequirePlanFeature(PlanCatalogue.Features.ApiWebhooks)]
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateWebhookSubscriptionInput input)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot create webhooks." });
        var (created, refusal) = await _webhooks.CreateAsync(input.Event, input.EndpointUrl, User.UserId());
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return StatusCode(201, created);
    }

    private IActionResult FromRefusal(SalesApi.ProcessLayer.Webhooks.WebhookProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason }) : BadRequest(new { error = refusal.Reason });

    // PATCH /webhooks/{id} { event?, endpoint_url? } - change the destination or the event; the URL is re-checked like on create.
    [RequirePlanFeature(PlanCatalogue.Features.ApiWebhooks)]
    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateWebhookSubscriptionInput input)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot edit webhooks." });
        var (subscription, refusal) = await _webhooks.UpdateAsync(id, input.Event, input.EndpointUrl);
        return refusal is not null ? FromRefusal(refusal) : Ok(subscription);
    }

    // POST /webhooks/{id}/rotate-secret - a new signing secret, returned exactly once (same shape as create).
    [RequirePlanFeature(PlanCatalogue.Features.ApiWebhooks)]
    [HttpPost("{id:guid}/rotate-secret")]
    public async Task<IActionResult> RotateSecret(Guid id)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot rotate webhook secrets." });
        var (created, refusal) = await _webhooks.RotateSecretAsync(id);
        return refusal is not null ? FromRefusal(refusal) : Ok(created);
    }

    // POST /webhooks/{id}/test - queue a signed "test" ping to this subscription; it shows in the delivery log within ~30 seconds.
    [RequirePlanFeature(PlanCatalogue.Features.ApiWebhooks)]
    [HttpPost("{id:guid}/test")]
    public async Task<IActionResult> Test(Guid id)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot test webhooks." });
        var (deliveryId, refusal) = await _webhooks.TestAsync(id);
        return refusal is not null ? FromRefusal(refusal) : Ok(new { ok = true, delivery_id = deliveryId });
    }

    // POST /webhooks/{id}/deliveries/{deliveryId}/redeliver - send a delivery that gave up or failed again, as a new delivery.
    [RequirePlanFeature(PlanCatalogue.Features.ApiWebhooks)]
    [HttpPost("{id:guid}/deliveries/{deliveryId:guid}/redeliver")]
    public async Task<IActionResult> Redeliver(Guid id, Guid deliveryId)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot redeliver webhooks." });
        var (newDeliveryId, refusal) = await _webhooks.RedeliverAsync(id, deliveryId);
        return refusal is not null ? FromRefusal(refusal) : Ok(new { ok = true, delivery_id = newDeliveryId });
    }

    // POST /webhooks/{id}/revoke
    [HttpPost("{id:guid}/revoke")]
    public async Task<IActionResult> Revoke(Guid id)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot revoke webhooks." });
        var refusal = await _webhooks.RevokeAsync(id);
        if (refusal is not null) return NotFound(new { error = refusal.Reason });
        return Ok(new { ok = true });
    }

    // POST /webhooks/{id}/resume — clears PausedAt and re-schedules whatever
    // deliveries gave up, so an admin who fixes the endpoint sees the backlog
    // retried rather than needing to re-fire the events by hand.
    [RequirePlanFeature(PlanCatalogue.Features.ApiWebhooks)]
    [HttpPost("{id:guid}/resume")]
    public async Task<IActionResult> Resume(Guid id)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage webhooks." });
        var (retrying, refusal) = await _webhooks.ResumeAsync(id);
        if (refusal is not null)
            return refusal.NotFound ? NotFound(new { error = refusal.Reason }) : BadRequest(new { error = refusal.Reason });
        return Ok(new { ok = true, retrying });
    }

    // GET /webhooks/{id}/deliveries — the delivery log panel, newest first.
    [HttpGet("{id:guid}/deliveries")]
    public async Task<IActionResult> Deliveries(Guid id, [FromQuery] int limit = 50)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view webhook deliveries." });
        var (deliveries, refusal) = await _webhooks.DeliveriesAsync(id, limit);
        if (refusal is not null) return NotFound(new { error = refusal.Reason });
        return Ok(deliveries);
    }
}

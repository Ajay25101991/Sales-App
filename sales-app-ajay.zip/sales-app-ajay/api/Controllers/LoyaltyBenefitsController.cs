using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Loyalty;
using SalesApi.ProcessLayer.Loyalty;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E20.2 rewards per loyalty tier. Routes, checks the permission, and picks a status code - nothing else (the rules are <see cref="LoyaltyBenefitProcess"/>'s).
///
/// Permissions (owner decision pending on who may RECORD a use - see the hand-back; this is the least-surprising default):
///  - catalogue and entitlement reads: loyalty.view_status OR settings.manage (the admin screen may be opened by someone who manages settings only);
///  - catalogue and entitlement writes: settings.manage;
///  - an account's remaining / usage reads and RECORDING a use: loyalty.view_status, plus the account's own view rule (Process);
///  - correcting a use: loyalty.view_status, and then whoever recorded it or a settings manager (Process, from the facts passed down).
/// </summary>
[ApiController]
[Authorize]
public class LoyaltyBenefitsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly LoyaltyBenefitExperience _benefits;

    public LoyaltyBenefitsController(CallerContext caller, LoyaltyBenefitExperience benefits)
    {
        _caller = caller;
        _benefits = benefits;
    }

    private Task<RecordAccessContext> AccessAsync() => _caller.ForAsync(User);

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);
    private bool CanRead => CanManage || User.HasPermission(OrganizationPermissions.ViewLoyaltyStatus);

    private ObjectResult Forbid403(string message) => StatusCode(403, new { error = message });

    private static IActionResult FromRefusal(LoyaltyBenefitProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 403 }
        : refusal.Conflict ? new ConflictObjectResult(new { error = refusal.Reason })
        : new BadRequestObjectResult(new { error = refusal.Reason });

    // --- Catalogue ---------------------------------------------------------------------------------------------------------------------

    // GET /loyalty/benefits[?active_only=true] - the org's benefits, by name.
    [HttpGet("loyalty/benefits")]
    public async Task<IActionResult> ListBenefits([FromQuery(Name = "active_only")] bool activeOnly = false)
    {
        if (!CanRead) return Forbid403("Your role cannot view loyalty benefits.");
        return Ok(await _benefits.ListBenefitsAsync(activeOnly, HttpContext.RequestAborted));
    }

    // POST /loyalty/benefits {name, description?, active?} -> 201. 409 when the name is taken.
    [HttpPost("loyalty/benefits")]
    public async Task<IActionResult> CreateBenefit([FromBody] LoyaltyBenefitInput input)
    {
        if (!CanManage) return Forbid403("Your role cannot change organization setup.");
        var (refusal, dto) = await _benefits.CreateBenefitAsync(input, HttpContext.RequestAborted);
        return refusal is not null ? FromRefusal(refusal) : StatusCode(201, dto);
    }

    // PUT /loyalty/benefits/{id} {name?, description?, active?} - an omitted field keeps its value. There is no DELETE: usage points at a benefit, so it is deactivated.
    [HttpPut("loyalty/benefits/{id:guid}")]
    public async Task<IActionResult> UpdateBenefit(Guid id, [FromBody] LoyaltyBenefitInput input)
    {
        if (!CanManage) return Forbid403("Your role cannot change organization setup.");
        var (refusal, dto) = await _benefits.UpdateBenefitAsync(id, input, HttpContext.RequestAborted);
        return refusal is not null ? FromRefusal(refusal) : Ok(dto);
    }

    // --- Entitlements ------------------------------------------------------------------------------------------------------------------

    // GET /loyalty/entitlements[?tier_key=gold] - every tier's entitlements, or one tier's.
    [HttpGet("loyalty/entitlements")]
    public async Task<IActionResult> ListEntitlements([FromQuery(Name = "tier_key")] string? tierKey)
    {
        if (!CanRead) return Forbid403("Your role cannot view loyalty benefits.");
        return Ok(await _benefits.ListEntitlementsAsync(tierKey, HttpContext.RequestAborted));
    }

    // PUT /loyalty/tiers/{tierKey}/entitlements {entitlements: [{benefit_id, unlimited? | allowance + period}]} - states the tier's WHOLE set. 404 for an unknown tier.
    [HttpPut("loyalty/tiers/{tierKey}/entitlements")]
    public async Task<IActionResult> SetTierEntitlements(string tierKey, [FromBody] LoyaltyEntitlementSetInput input)
    {
        if (!CanManage) return Forbid403("Your role cannot change organization setup.");
        var (refusal, dto) = await _benefits.SetTierEntitlementsAsync(tierKey, input, HttpContext.RequestAborted);
        return refusal is not null ? FromRefusal(refusal) : Ok(dto);
    }

    // --- An account's rewards ----------------------------------------------------------------------------------------------------------

    // GET /accounts/{accountId}/loyalty-benefits - the benefits of the account's CURRENT tier, with used and remaining for this period.
    [HttpGet("accounts/{accountId:guid}/loyalty-benefits")]
    [RequirePermission(OrganizationPermissions.ViewLoyaltyStatus)]
    public async Task<IActionResult> Remaining(Guid accountId)
    {
        var (refusal, dto) = await _benefits.RemainingAsync(await AccessAsync(), accountId, HttpContext.RequestAborted);
        return refusal is not null ? FromRefusal(refusal) : Ok(dto);
    }

    // GET /accounts/{accountId}/loyalty-benefit-uses[?benefit_id=][&include_superseded=true] - the usage ledger, newest use first.
    [HttpGet("accounts/{accountId:guid}/loyalty-benefit-uses")]
    [RequirePermission(OrganizationPermissions.ViewLoyaltyStatus)]
    public async Task<IActionResult> Uses(
        Guid accountId, [FromQuery(Name = "benefit_id")] Guid? benefitId, [FromQuery(Name = "include_superseded")] bool includeSuperseded = false)
    {
        var (refusal, dto) = await _benefits.UsesAsync(await AccessAsync(), accountId, benefitId, includeSuperseded, HttpContext.RequestAborted);
        return refusal is not null ? FromRefusal(refusal) : Ok(dto);
    }

    // POST /accounts/{accountId}/loyalty-benefit-uses {benefit_id, quantity, used_at?, contact_id?, note?} -> 201 with the row.
    [HttpPost("accounts/{accountId:guid}/loyalty-benefit-uses")]
    [RequirePermission(OrganizationPermissions.ViewLoyaltyStatus)]
    public async Task<IActionResult> RecordUse(Guid accountId, [FromBody] LoyaltyBenefitUseInput input)
    {
        var (refusal, dto) = await _benefits.RecordUseAsync(await AccessAsync(), accountId, User.UserId(), input, HttpContext.RequestAborted);
        return refusal is not null ? FromRefusal(refusal) : StatusCode(201, dto);
    }

    // POST /accounts/{accountId}/loyalty-benefit-uses/{useId}/correct {quantity?, used_at?, note?, contact_id?} -> 201 with the REPLACING row; the old row is
    // marked superseded. quantity 0 voids the use. 409 when that use was already corrected.
    [HttpPost("accounts/{accountId:guid}/loyalty-benefit-uses/{useId:guid}/correct")]
    [RequirePermission(OrganizationPermissions.ViewLoyaltyStatus)]
    public async Task<IActionResult> CorrectUse(Guid accountId, Guid useId, [FromBody] LoyaltyBenefitUseCorrectionInput input)
    {
        var (refusal, dto) = await _benefits.CorrectUseAsync(
            await AccessAsync(), accountId, useId, User.UserId(), CanManage, input, HttpContext.RequestAborted);
        return refusal is not null ? FromRefusal(refusal) : StatusCode(201, dto);
    }
}

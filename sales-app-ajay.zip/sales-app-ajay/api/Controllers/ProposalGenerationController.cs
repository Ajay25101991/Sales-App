using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Proposals;
using SalesApi.ProcessLayer.Proposals;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E10.5 / E10.6 - generate a priced, combined proposal version for a deal, keep its PDF, list the versions and say what
/// changed. Contract: to-do/proposal-generator-api.md ("E10.5 - E10.7"). Routes, checks the permission, picks a status code; the
/// plain quote routes (list, status, revise) stay on <c>LeadsController</c>.
///
/// Generating, and making a version's PDF, need <c>proposals.generate_priced</c> ("Generate priced proposals") or
/// <c>settings.manage</c>, as running a pricing model does. Reading versions and the diff needs only access to the deal.
/// </summary>
[ApiController]
[Route("leads/{leadId:guid}/proposals")]
[Authorize]
public class ProposalGenerationController : ControllerBase
{
    private readonly ProposalGenerationExperience _proposals;
    private readonly CallerContext _caller;

    public ProposalGenerationController(ProposalGenerationExperience proposals, CallerContext caller)
    {
        _proposals = proposals;
        _caller = caller;
    }

    private bool CanUse() =>
        User.HasPermission(OrganizationPermissions.GeneratePricedProposals) || User.HasPermission(OrganizationPermissions.ManageSettings);

    /// <summary>lead_values.view: without it every money figure in these reads is null (ProposalMasking).</summary>
    private bool CanSeeValues() => User.HasPermission(OrganizationPermissions.ViewLeadValues);

    private ObjectResult NoUse() => StatusCode(403, new { error = "Your role cannot generate priced proposals." });

    private IActionResult Respond<T>(ProposalGenerateProcess.Result<T> r, int okStatus = 200) => r.Outcome switch
    {
        ProposalGenerateProcess.Outcome.NotFound => NotFound(new { error = r.Error }),
        ProposalGenerateProcess.Outcome.Forbidden => StatusCode(403, new { error = r.Error }),
        ProposalGenerateProcess.Outcome.Conflict => Conflict(new { error = r.Error }),
        ProposalGenerateProcess.Outcome.Unavailable => StatusCode(503, new { error = r.Error }),
        ProposalGenerateProcess.Outcome.Invalid => BadRequest(new { error = r.Error, issues = r.Issues }),
        _ => StatusCode(okStatus, r.Value),
    };

    /// <summary>Makes a new version (or the first) of the deal's proposal. 201 + the quote, its version entry and anything left unfilled.</summary>
    [HttpPost("generate")]
    public async Task<IActionResult> Generate(Guid leadId, [FromBody] GenerateProposalVersionInput input, CancellationToken ct)
    {
        if (!CanUse()) return NoUse();
        return Respond(await _proposals.GenerateAsync(await _caller.ForAsync(User), User.UserId(), leadId, input ?? new(null), CanSeeValues(), ct), 201);
    }

    /// <summary>
    /// The custom-field and partner tokens (DEAL_FIELD_ / ACCOUNT_FIELD_ / PARTNER_FIELD_ / PARTNER_NAME ...) that the templates about to be
    /// generated from use and that are BLANK on this deal, so the generator can ask for them before it renders.
    /// Query: <c>service_ids</c> (repeat), <c>deck</c> (true = include the proposal deck templates), <c>variants</c> (repeat: agreement names;
    /// send <c>letter=true</c> for the unnamed engagement letter). Response: <c>{ fields: [{ token, object_type, field_key, label, type,
    /// options, picklist_key, has_fallback, used_by }] }</c>.
    /// </summary>
    [HttpGet("blank-fields")]
    public async Task<IActionResult> BlankFields(
        Guid leadId, [FromQuery(Name = "service_ids")] List<Guid>? serviceIds, [FromQuery] bool deck, [FromQuery] bool letter,
        [FromQuery] List<string>? variants, CancellationToken ct)
    {
        if (!CanUse()) return NoUse();
        var asked = new List<string?>();
        if (letter) asked.Add(null);
        asked.AddRange(variants ?? []);
        return Respond(await _proposals.BlankFieldsAsync(await _caller.ForAsync(User), leadId, serviceIds ?? [], deck, asked, ct));
    }

    /// <summary>The agreement names that have a live letter template, per service and for the wrapper:
    /// <c>{ agreements: [{ catalog_item_id|null, variant }] }</c>. Query <c>catalog_item_ids</c> (repeat; none = all services).
    /// Same permission as making an engagement letter.</summary>
    [HttpGet("agreements")]
    public async Task<IActionResult> Agreements(Guid leadId, [FromQuery(Name = "catalog_item_ids")] List<Guid>? catalogItemIds, CancellationToken ct)
    {
        if (!CanUse()) return NoUse();
        return Respond(await _proposals.AgreementsAsync(await _caller.ForAsync(User), leadId, catalogItemIds ?? [], ct));
    }

    /// <summary>Every version of the quote that {pid} belongs to, newest first, with who/when and the one-line change summary.</summary>
    [HttpGet("{pid:guid}/versions")]
    public async Task<IActionResult> Versions(Guid leadId, Guid pid, CancellationToken ct) =>
        Respond(await _proposals.VersionsAsync(await _caller.ForAsync(User), leadId, pid, CanSeeValues(), ct));

    /// <summary>What changed in {pid} against <c>against</c> (default: the version it supersedes).</summary>
    [HttpGet("{pid:guid}/diff")]
    public async Task<IActionResult> Diff(Guid leadId, Guid pid, [FromQuery] Guid? against, CancellationToken ct) =>
        Respond(await _proposals.DiffAsync(await _caller.ForAsync(User), leadId, pid, against, CanSeeValues(), ct));

    /// <summary>Converts the version's PowerPoint to PDF again after a failure.</summary>
    [HttpPost("{pid:guid}/pdf/retry")]
    public async Task<IActionResult> RetryPdf(Guid leadId, Guid pid, CancellationToken ct)
    {
        if (!CanUse()) return NoUse();
        return Respond(await _proposals.RetryPdfAsync(await _caller.ForAsync(User), User.UserId(), leadId, pid, CanSeeValues(), ct));
    }

    /// <summary>Adds a PDF the rep made themselves (multipart <c>file</c>) as this version's PDF.</summary>
    [HttpPost("{pid:guid}/pdf")]
    [RequestSizeLimit(26 * 1024 * 1024)]
    public async Task<IActionResult> UploadPdf(Guid leadId, Guid pid, IFormFile? file, CancellationToken ct)
    {
        if (!CanUse()) return NoUse();
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required" });
        await using var stream = file.OpenReadStream();
        using var ms = new MemoryStream();
        await stream.CopyToAsync(ms, ct);
        return Respond(await _proposals.UploadPdfAsync(await _caller.ForAsync(User), User.UserId(), leadId, pid, ms.ToArray(), CanSeeValues(), ct));
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Irl;
using SalesApi.ProcessLayer.Irl;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E-invoicing IRL on a deal (to-do/einvoicing-irl-design.md): the rep sends the client their Information Request List (a secure link plus the blank
/// workbook, from the rep's own mailbox), resends or withdraws it, reopens a locked one, reads the answers and the kept submissions, and uploads a
/// completed workbook the client sent back. Routes, checks the sign-in, picks a status code; the deal-access rule (read = view the deal, every
/// write = manage it) and everything else is <see cref="IrlRequestProcess"/>. The client's side is <see cref="IrlPublicController"/>.
/// </summary>
[ApiController]
[Route("leads/{leadId:guid}/irl")]
[Authorize]
public class IrlController : ControllerBase
{
    private readonly IrlExperience _irl;
    private readonly CallerContext _caller;

    public IrlController(IrlExperience irl, CallerContext caller)
    {
        _irl = irl;
        _caller = caller;
    }

    /// <summary>403/404/409/400/503 with <c>{error, code?}</c>; <c>code</c> is irl_no_template, irl_choose_service, irl_unreadable, irl_version_mismatch,
    /// mailbox_reconnect_required, mailbox_not_connected or thread_not_in_mailbox.</summary>
    private IActionResult Respond<T>(IrlRequestProcess.Result<T> r, int okStatus = 200) => r.Outcome switch
    {
        IrlRequestProcess.Outcome.NotFound => NotFound(new { error = r.Error }),
        IrlRequestProcess.Outcome.Forbidden => StatusCode(403, new { error = r.Error }),
        IrlRequestProcess.Outcome.Conflict => Conflict(new { error = r.Error, code = r.Code }),
        IrlRequestProcess.Outcome.Unavailable => StatusCode(503, new { error = r.Error, code = r.Code }),
        IrlRequestProcess.Outcome.Invalid => BadRequest(new { error = r.Error, code = r.Code }),
        _ => StatusCode(okStatus, r.Value),
    };

    /// <summary>The deal's IRL: <c>{ request, definition, answers, templates }</c>. <c>request</c> (and with it <c>definition</c> / <c>answers</c>) is null until one is sent
    /// or uploaded; <c>templates</c> are the blank workbooks that could be sent.</summary>
    [HttpGet]
    public async Task<IActionResult> Get(Guid leadId, CancellationToken ct) =>
        Respond(await _irl.GetAsync(await _caller.ForAsync(User), leadId, ct));

    /// <summary>The org's "IRL request email" template filled for this deal (editable before sending).</summary>
    [HttpGet("email")]
    public async Task<IActionResult> Email(Guid leadId, CancellationToken ct) =>
        Respond(await _irl.EmailAsync(await _caller.ForAsync(User), await _caller.DisplayNameAsync(User), leadId, ct));

    /// <summary>Emails the client the link and the blank workbook from the caller's own mailbox, and starts the link's clock. Retires any earlier request on the deal. 201.</summary>
    [HttpPost("send")]
    public async Task<IActionResult> Send(Guid leadId, [FromBody] SendIrlInput? input, CancellationToken ct) =>
        Respond(await _irl.SendAsync(await _caller.ForAsync(User), User.UserId(), await _caller.DisplayNameAsync(User), leadId, input ?? new SendIrlInput(), ct), 201);

    /// <summary>Emails the SAME link again (answers kept) and restarts its clock.</summary>
    [HttpPost("resend")]
    public async Task<IActionResult> Resend(Guid leadId, [FromBody] SendIrlInput? input, CancellationToken ct) =>
        Respond(await _irl.ResendAsync(await _caller.ForAsync(User), User.UserId(), await _caller.DisplayNameAsync(User), leadId, input ?? new SendIrlInput(), ct));

    /// <summary>Withdraws the link now; the answers and history stay.</summary>
    [HttpPost("revoke")]
    public async Task<IActionResult> Revoke(Guid leadId, CancellationToken ct) =>
        Respond(await _irl.RevokeAsync(await _caller.ForAsync(User), User.UserId(), leadId, ct));

    /// <summary>Clears the lock a sent proposal put on a submitted IRL so the client can edit and submit again.</summary>
    [HttpPost("reopen")]
    public async Task<IActionResult> Reopen(Guid leadId, CancellationToken ct) =>
        Respond(await _irl.ReopenAsync(await _caller.ForAsync(User), User.UserId(), leadId, ct));

    /// <summary>One kept submission with its answers.</summary>
    [HttpGet("submissions/{submissionId:guid}")]
    public async Task<IActionResult> Submission(Guid leadId, Guid submissionId, CancellationToken ct) =>
        Respond(await _irl.SubmissionAsync(await _caller.ForAsync(User), leadId, submissionId, ct));

    /// <summary>Reads a COMPLETED workbook (multipart <c>file</c>, optional <c>catalog_item_id</c> when the deal has no IRL yet and more than one service has a blank
    /// workbook) into the deal's IRL. When the IRL already has answers, form field <c>mode</c> ("merge" | "replace") is required - without it: 400 code
    /// irl_choose_upload_mode. 400 with code irl_unreadable / irl_version_mismatch when it is not the template version on the deal: nothing is stored, and
    /// the file can still be added to the deal through the ordinary attachments endpoint. 201.</summary>
    [HttpPost("upload")]
    [RequestSizeLimit(UploadLimits.StaffRequestBytes)]
    public async Task<IActionResult> Upload(Guid leadId, IFormFile? file, [FromForm(Name = "catalog_item_id")] Guid? serviceId, [FromForm] string? mode, CancellationToken ct)
    {
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required" });
        await using var stream = file.OpenReadStream();
        return Respond(await _irl.UploadWorkbookAsync(
            await _caller.ForAsync(User), User.UserId(), await _caller.DisplayNameAsync(User), leadId, serviceId,
            file.FileName, file.ContentType, file.Length, stream, mode, ct), 201);
    }
}

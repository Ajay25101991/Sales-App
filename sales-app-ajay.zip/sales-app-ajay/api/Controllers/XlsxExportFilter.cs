using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using SalesApi.Documents;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E18.4: every CSV export can be downloaded as Excel by adding <c>?format=xlsx</c> to the SAME request (same route, same query
/// filters, same permission and record scoping, same masking). One filter, not an option on each of the twelve export endpoints, for
/// the reason <see cref="DataExportLogFilter"/> is one filter: the response content type (<c>text/csv</c>) is the one thing every
/// export shares, so the conversion happens at that single choke point and an export added later gets Excel for free.
///
/// The endpoint still builds its CSV with its own row builder; this swaps the finished text for a workbook built by
/// <see cref="XlsxExport"/> from those same rows. It is registered AFTER <see cref="DataExportLogFilter"/>, which therefore still
/// sees the CSV result and writes its one data-access-log entry (with format "xlsx", see <see cref="WantsXlsx"/>) before the swap.
/// A refused or empty-bodied export (any non-200) is left alone.
/// </summary>
public sealed class XlsxExportFilter : IAsyncResultFilter
{
    /// <summary>True when the request asks for the Excel form: <c>?format=xlsx</c>.</summary>
    public static bool WantsXlsx(HttpRequest request) =>
        string.Equals(request.Query["format"].ToString(), "xlsx", StringComparison.OrdinalIgnoreCase);

    public async Task OnResultExecutionAsync(ResultExecutingContext context, ResultExecutionDelegate next)
    {
        if (!WantsXlsx(context.HttpContext.Request)) { await next(); return; }

        string csv;
        string? csvName = null;
        switch (context.Result)
        {
            case ContentResult { ContentType: { } type } content
                when type.StartsWith("text/csv", StringComparison.OrdinalIgnoreCase)
                     && (content.StatusCode ?? StatusCodes.Status200OK) == StatusCodes.Status200OK:
                csv = content.Content ?? "";
                break;
            case FileContentResult { ContentType: { } fileType } file
                when fileType.StartsWith("text/csv", StringComparison.OrdinalIgnoreCase):
                csv = Encoding.UTF8.GetString(file.FileContents);
                csvName = file.FileDownloadName;
                break;
            default:
                await next();
                return;
        }

        byte[] workbook;
        try { workbook = XlsxExport.FromCsv(csv, "Export"); }
        catch (OoxmlException e)
        {
            context.Result = new ObjectResult(new { error = e.Message }) { StatusCode = StatusCodes.Status413PayloadTooLarge };
            await next();
            return;
        }

        context.Result = new FileContentResult(workbook, XlsxExport.ContentType)
        {
            FileDownloadName = FileNameFor(csvName, context),
        };
        await next();
    }

    /// <summary>The CSV's own download name with .xlsx, or - for a CSV sent as plain content with no name - the route's words and
    /// today's date ("leads-export-2026-11-04.xlsx").</summary>
    internal static string FileNameFor(string? csvName, ResultExecutingContext context)
    {
        if (!string.IsNullOrWhiteSpace(csvName))
            return Path.ChangeExtension(DownloadFileName.Of(csvName), ".xlsx");

        var template = context.ActionDescriptor.AttributeRouteInfo?.Template ?? context.HttpContext.Request.Path.Value ?? "export";
        var words = template.Split('/', StringSplitOptions.RemoveEmptyEntries)
            .Where(s => !s.StartsWith('{'))
            .Select(s => s.Replace(".csv", "", StringComparison.OrdinalIgnoreCase));
        var stem = string.Join("-", words);
        if (stem.Length == 0) stem = "export";
        return DownloadFileName.Of($"{stem}-{DateTime.UtcNow:yyyy-MM-dd}.xlsx");
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Plans;
using SalesApi.ProcessLayer.Plans;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E7.6 plans (owner answer 2026-09-29): platform-admin CRUD over the global
/// plan catalogue plus "set an org's plan", all suntech-admin only — same
/// gating shape as <see cref="AdminController"/>'s allowed-domains endpoints
/// — and one org-admin endpoint, <c>GET /admin/plan</c>, for the caller's own
/// org's status (ManageSettings, same permission the AI cost policy and
/// mailbox/WhatsApp admin screens use).
/// </summary>
[ApiController]
[Authorize]
public class PlansController : ControllerBase
{
    private readonly PlansExperience _plans;
    public PlansController(PlansExperience plans) => _plans = plans;

    private IActionResult? RequireAdmin() =>
        User.IsSuntechAdmin() ? null : StatusCode(403, new { error = "Only an app administrator can do this." });

    private IActionResult Refused(PlanProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason }) : BadRequest(new { error = refusal.Reason });

    // GET /admin/plans — the full catalogue (platform admin only).
    [HttpGet("admin/plans")]
    public async Task<IActionResult> List([FromQuery] bool includeArchived = false)
    {
        if (RequireAdmin() is { } err) return err;
        return Ok(await _plans.ListAsync(includeArchived));
    }

    // POST /admin/plans — create a plan.
    [HttpPost("admin/plans")]
    public async Task<IActionResult> Create([FromBody] EntitlementPlanInput input)
    {
        if (RequireAdmin() is { } err) return err;
        var (dto, refusal) = await _plans.CreateAsync(input);
        return refusal is not null ? Refused(refusal) : StatusCode(201, dto);
    }

    // PATCH /admin/plans/{id} — edit a plan (name/key/features/limits) or archive it.
    [HttpPatch("admin/plans/{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] EntitlementPlanInput input)
    {
        if (RequireAdmin() is { } err) return err;
        var (dto, refusal) = await _plans.UpdateAsync(id, input);
        return refusal is not null ? Refused(refusal) : Ok(dto);
    }

    // PUT /admin/organizations/{orgId}/plan — assign a plan to an org (audited).
    [HttpPut("admin/organizations/{orgId:guid}/plan")]
    public async Task<IActionResult> SetOrgPlan(Guid orgId, [FromBody] SetOrgPlanInput input)
    {
        if (RequireAdmin() is { } err) return err;
        var (dto, refusal) = await _plans.SetOrgPlanAsync(orgId, input.PlanId, User.UserId());
        return refusal is not null ? Refused(refusal) : Ok(dto);
    }

    // GET /admin/plan — the caller's OWN org: plan name, each feature on/off,
    // each meter's raw usage/limit/mode and this period's reset date.
    [HttpGet("admin/plan")]
    public async Task<IActionResult> OrgStatus()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot view this setting." });
        return Ok(await _plans.OrgStatusAsync());
    }
}

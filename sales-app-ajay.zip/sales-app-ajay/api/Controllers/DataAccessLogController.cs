using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.DataAccessLog;
using SalesApi.Services;

namespace SalesApi.Controllers;

// E12.7 + E12.6. Routing, [Authorize], the permission checks, model binding and status codes - nothing else (the rules are in
// DataAccessLogProcess). Contract: to-do/sensitive-data-api.md section 7.
[ApiController]
[Authorize]
public class DataAccessLogController : ControllerBase
{
    private readonly DataAccessLogExperience _log;
    private readonly CallerContext _caller;

    public DataAccessLogController(DataAccessLogExperience log, CallerContext caller)
    {
        _log = log;
        _caller = caller;
    }

    // GET /admin/data-access-log - filter by person, action, record and date range; keyset-paginated, newest first.
    [HttpGet("admin/data-access-log")]
    public async Task<IActionResult> List(
        [FromQuery] Guid? userId, [FromQuery] string? action, [FromQuery] string? recordType, [FromQuery] Guid? recordId,
        [FromQuery] DateTime? from, [FromQuery] DateTime? to, [FromQuery] string? cursor, [FromQuery] int? limit)
    {
        if (!User.HasPermission(OrganizationPermissions.ViewDataAccessLog))
            return StatusCode(403, new { error = "Your role cannot view the data access log." });
        var (page, refusal) = await _log.ListAsync(userId, action, recordType, recordId, from, to, cursor, limit);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(page);
    }

    // POST /data-access/launch - the person tapped Call / "Open in WhatsApp" on their device; log it, and say whether they may.
    [HttpPost("data-access/launch")]
    public async Task<IActionResult> Launch([FromBody] DataAccessLaunchInput input)
    {
        var access = await _caller.ForAsync(User);
        var refusal = await _log.LaunchAsync(access, User.HasPermission(OrganizationPermissions.OpenWhatsAppExternal), input);
        if (refusal is null) return NoContent();
        if (refusal.NotFound) return NotFound(new { error = refusal.Reason });
        if (refusal.Forbidden) return StatusCode(403, new { error = refusal.Reason, code = refusal.Code });
        return BadRequest(new { error = refusal.Reason });
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// A storage provider the org chose (SharePoint) could not be used: answer with its plain message and a 502, not a
/// bare 500, so the person sees WHY the upload / download / delete failed. Nothing was stored elsewhere and no row
/// was written. Put on the controllers that touch file bytes; the controller still only picks a status code.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public sealed class StorageUnavailableFilterAttribute : ExceptionFilterAttribute
{
    public override void OnException(ExceptionContext context)
    {
        if (context.Exception is not StorageUnavailableException ex) return;
        context.Result = new ObjectResult(new { error = ex.Message }) { StatusCode = StatusCodes.Status502BadGateway };
        context.ExceptionHandled = true;
    }
}

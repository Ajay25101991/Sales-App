using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.ExperienceLayer.UserProfile;
using SalesApi.Services;

namespace SalesApi.Controllers;

public record ProfileUpdate(string? FullName, string? ExpoPushToken);

// MIGRATED to the layered API (api-led migration, step 8). Assembly of the
// profile payload (role resolution, team membership) now lives in
// SalesApi.ProcessApi/Profile/ProfileProcess.cs, reached through
// SalesApi.ExperienceApi/Profile/ProfileExperience.cs. What is left here,
// deliberately: routing, [Authorize], model binding, and resolving the
// caller's id from the TOKEN — User.UserId() — never from the request body,
// which is the one thing this endpoint must never allow a client to name.
[ApiController]
[Route("profile")]
[Authorize]
public class ProfileController : ControllerBase
{
    private readonly ProfileExperience _profile;
    public ProfileController(ProfileExperience profile) => _profile = profile;

    [HttpGet]
    [AllowPartnerPortal]   // a signed-in app validates its token with GET /profile on launch; reading your own profile is the portal's only other read
    [AllowCustomerPortal]
    public async Task<IActionResult> Get()
    {
        // E7.4 — the token's own acting-org/studio-kind claims (see
        // JwtService.CreateStudioToken), read here (a Controller may touch
        // the ClaimsPrincipal) and passed DOWN as data, never re-derived
        // inside ProfileProcess. ProfileProcess only treats this as a studio
        // session when it differs from the profile's own home org, so
        // passing the ordinary org_id claim on a normal session is a no-op.
        var dto = await _profile.GetAsync(
            User.UserId(), actingOrgId: User.OrgId(), studioKind: User.StudioKind(), previewRoleKey: User.PreviewRoleKey());
        return dto is null ? NotFound() : Ok(dto);
    }

    [HttpPatch]
    public async Task<IActionResult> Update([FromBody] ProfileUpdate input)
    {
        var dto = await _profile.UpdateAsync(User.UserId(), input.FullName, input.ExpoPushToken);
        return dto is null ? NotFound() : Ok(dto);
    }
}

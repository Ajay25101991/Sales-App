using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SalesApi.ExperienceLayer.OnlinePayments;
using SalesApi.ProcessLayer.OnlinePayments;

namespace SalesApi.Controllers;

/// <summary>
/// E17.5 online payment - the CUSTOMER's public "Pay now" link (no sign-in). The token in the path names one invoice's link, as the IRL and document
/// request links do. These are JSON endpoints for the desktop app's public page (the page itself, <c>/apps/sales/pay/{token}</c>, is a route of that
/// app, not served here; the gateway sends the customer back to it with <c>?result=success|cancel</c>). Rate limited with the IRL link's policy
/// ("irl-public"). Routes and picks status codes only; the rules are <see cref="OnlinePaymentPublicProcess"/>.
/// </summary>
[ApiController]
[Route("public/pay")]
[AllowAnonymous]
[EnableRateLimiting("irl-public")]
public class PayPublicController : ControllerBase
{
    private readonly OnlinePaymentExperience _payments;
    public PayPublicController(OnlinePaymentExperience payments) => _payments = payments;

    /// <summary>404 <c>{error}</c> unknown link; 409 <c>{error, status}</c> paid or not payable online; 410 <c>{error, status:"expired"}</c>;
    /// 503 <c>{error}</c> online payment is not available.</summary>
    private IActionResult Respond<T>(OnlinePaymentPublicProcess.Result<T> r) => r.Outcome switch
    {
        OnlinePaymentPublicProcess.Outcome.NotFound => NotFound(new { error = r.Error }),
        OnlinePaymentPublicProcess.Outcome.Conflict => Conflict(new { error = r.Error, status = r.Status }),
        OnlinePaymentPublicProcess.Outcome.Gone => StatusCode(410, new { error = r.Error, status = r.Status }),
        OnlinePaymentPublicProcess.Outcome.Unavailable => StatusCode(503, new { error = r.Error }),
        _ => Ok(r.Value),
    };

    /// <summary>GET: <c>{ company, invoice_number, issued_at, due_date, currency, amount_due, status }</c>, status open | paid | expired | unavailable.</summary>
    [HttpGet("{token}")]
    public async Task<IActionResult> View(string token, CancellationToken ct) => Respond(await _payments.ViewAsync(token, ct));

    /// <summary>POST: opens a gateway checkout for the invoice's CURRENT balance. <c>{ redirect_url }</c>.</summary>
    [HttpPost("{token}/checkout")]
    public async Task<IActionResult> Checkout(string token, CancellationToken ct) => Respond(await _payments.CheckoutAsync(token, ct));
}

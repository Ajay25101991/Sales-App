using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Mailbox;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Team mailboxes (owner decisions 2026-10-14, to-do/e6-capture-design.md §14) — the org's shared addresses the
/// Microsoft 365 app reads: list, add, edit, delete, and "Check access". Routing, the permission check and status-code
/// selection only. Gated by ManageSettings like the rest of the Microsoft 365 screen; creating one and checking one
/// also need the plan's mailbox-sync feature (an org whose plan lapses can still list, switch off and delete).
/// </summary>
[ApiController]
[Authorize]
[Route("admin/shared-mailboxes")]
public class SharedMailboxController : ControllerBase
{
    private readonly SharedMailboxExperience _mailboxes;
    public SharedMailboxController(SharedMailboxExperience mailboxes) => _mailboxes = mailboxes;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);

    [HttpGet]
    public async Task<IActionResult> List()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot view this setting." });
        return Ok(await _mailboxes.ListAsync());
    }

    [HttpPost]
    [RequirePlanFeature(PlanCatalogue.Features.MailboxSync)]
    public async Task<IActionResult> Create([FromBody] SharedMailboxInput input)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, dto) = await _mailboxes.CreateAsync(input);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] SharedMailboxInput input)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, dto) = await _mailboxes.UpdateAsync(id, input);
        return refusal switch
        {
            { NotFound: true } => NotFound(new { error = refusal.Reason }),
            not null => BadRequest(new { error = refusal.Reason }),
            _ => Ok(dto),
        };
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var refusal = await _mailboxes.DeleteAsync(id);
        return refusal switch
        {
            { NotFound: true } => NotFound(new { error = refusal.Reason }),
            not null => BadRequest(new { error = refusal.Reason }),
            _ => Ok(new { deleted = true }),
        };
    }

    // POST /admin/shared-mailboxes/{id}/check — reads one message id from the inbox with the org's app. ALWAYS 200 with
    // {ok, message}: "the app may not read this mailbox" is the answer to the question, not a failed request.
    [HttpPost("{id:guid}/check")]
    [RequirePlanFeature(PlanCatalogue.Features.MailboxSync)]
    public async Task<IActionResult> Check(Guid id)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (refusal, result) = await _mailboxes.CheckAsync(id);
        return refusal is { NotFound: true } ? NotFound(new { error = refusal.Reason }) : Ok(result);
    }
}

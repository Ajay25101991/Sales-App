using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Amcs;
using SalesApi.ProcessLayer.Amcs;
using SalesApi.Services;

namespace SalesApi.Controllers;

// Annual Maintenance Contracts. Owner/manager scoping mirrors invoices.
//
// MIGRATED to the layered API (api-led migration, step 8). Business rules that
// used to live inline here now live in SalesApi.ProcessApi/Amcs/AmcProcess.cs,
// reached through SalesApi.ExperienceApi/Amcs/AmcsExperience.cs. What is left
// here, deliberately: routing, [Authorize]/[RequirePermission], the manager-only
// checks on the reminder/email/policy/generate endpoints (request-shaped facts
// about the CALLER's role, not a rule about an AMC), model binding, resolving
// the caller's RecordAccessContext (a System-layer factory over the token +
// the database — the one place this controller still needs AppDbContext), and
// choosing the HTTP status for a Refusal.
[ApiController]
[Route("amcs")]
[Authorize]
[RequirePermission(OrganizationPermissions.ViewFinancials)]
public class AmcsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly AmcsExperience _amcs;
    public AmcsController(CallerContext caller, AmcsExperience amcs)
    {
        _caller = caller;
        _amcs = amcs;
    }

    private Task<RecordAccessContext> AccessAsync() => _caller.ForAsync(User);

    private static IActionResult FromRefusal(AmcProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 403 }
        : new BadRequestObjectResult(new { error = refusal.Reason });

    // GET /amcs?status=&lead_id=   (lead_id: E13 - the contracts of one deal)
    [HttpGet]
    public async Task<IActionResult> List(string? status, Guid? lead_id) =>
        Ok(await _amcs.ListAsync(await AccessAsync(), status, leadId: lead_id));

    // E13: the After-the-win settings read with financials.view (class gate) OR post_win.manage; edit needs post_win.manage.
    [HttpGet("reminder-config")]
    [AlsoAllowPermission(OrganizationPermissions.ManagePostWin)]
    [AlsoAllowPermission(OrganizationPermissions.CreateWorkflows)] // workflow authors read the org setting to start an override (they cannot change it)
    public async Task<IActionResult> GetReminderConfig()
    {
        return Ok(await _amcs.GetReminderConfigAsync());
    }

    [HttpPut("reminder-config")]
    public async Task<IActionResult> SetReminderConfig([FromBody] AmcReminderConfigInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePostWin)) return StatusCode(403, new { error = "Your role cannot change the after-the-win settings." });
        return Ok(await _amcs.SetReminderConfigAsync(input));
    }

    [HttpGet("email-template")]
    [AlsoAllowPermission(OrganizationPermissions.ManagePostWin)]
    public async Task<IActionResult> GetEmailTemplate() => Ok(await _amcs.GetEmailTemplateAsync());

    [HttpPut("email-template")]
    public async Task<IActionResult> SetEmailTemplate([FromBody] AmcEmailTemplateInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePostWin)) return StatusCode(403, new { error = "Your role cannot change the after-the-win settings." });
        return Ok(await _amcs.SetEmailTemplateAsync(input));
    }

    [HttpPost("generate-reminders")]
    public async Task<IActionResult> Generate()
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can trigger this." });
        return Ok(new { created = await _amcs.GenerateAsync() });
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var outcome = await _amcs.GetAsync(await AccessAsync(), id);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Amc);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] AmcInput input)
    {
        var outcome = await _amcs.CreateAsync(await AccessAsync(), input);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Amc);
    }

    // GET /amcs/{id}/terms — full contract history, current term first.
    [HttpGet("{id:guid}/terms")]
    public async Task<IActionResult> Terms(Guid id)
    {
        var outcome = await _amcs.TermsAsync(await AccessAsync(), id);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Terms);
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] AmcInput input)
    {
        var outcome = await _amcs.UpdateAsync(await AccessAsync(), id, input);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Amc);
    }

    // PATCH /amcs/{id}/terms/{termId} — per-term value editor (H15). Lets a
    // negotiated/escalating schedule be expressed directly on the term history,
    // separate from the "does a value change on the AMC reach this term" policy
    // above. A term whose invoice has already been RAISED can't be edited here —
    // that invoice is the billed record of what the term cost.
    [HttpPatch("{id:guid}/terms/{termId:guid}")]
    public async Task<IActionResult> UpdateTerm(Guid id, Guid termId, [FromBody] AmcTermInput input)
    {
        var outcome = await _amcs.UpdateTermAsync(await AccessAsync(), id, termId, input);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Term);
    }

    // GET/PUT /amcs/value-change-policy — the org setting deciding what a
    // ContractValue edit does to the currently-open term (H15). Manager-only,
    // same gating as reminder-config/email-template above.
    [HttpGet("value-change-policy")]
    [AlsoAllowPermission(OrganizationPermissions.ManagePostWin)]
    public async Task<IActionResult> GetValueChangePolicy() => Ok(await _amcs.GetValueChangePolicyAsync());

    [HttpPut("value-change-policy")]
    public async Task<IActionResult> SetValueChangePolicy([FromBody] AmcValueChangePolicyInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePostWin)) return StatusCode(403, new { error = "Your role cannot change the after-the-win settings." });
        return Ok(await _amcs.SetValueChangePolicyAsync(input));
    }

    // POST /amcs/{id}/renew — close the current term and open a new one (D1),
    // then advance Amc.StartDate/RenewalDate to match the new term (unchanged
    // behavior for every existing reader of those two fields).
    [HttpPost("{id:guid}/renew")]
    public async Task<IActionResult> Renew(Guid id, [FromBody] AmcRenewInput? input = null)
    {
        var outcome = await _amcs.RenewAsync(await AccessAsync(), id, default, input);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Amc);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var outcome = await _amcs.DeleteAsync(await AccessAsync(), id);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : NoContent();
    }
}

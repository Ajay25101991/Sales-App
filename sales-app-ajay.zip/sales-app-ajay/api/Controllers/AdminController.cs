using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Admin;
using SalesApi.ProcessLayer.Admin;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Platform administration for the app admin (suntech-admin): the domain
/// allowlist that gates which organizations may self-register, explicit tenant
/// provisioning, a read-only view of every registered org, and the
/// aggregate-health console. These operate across ALL tenants, so every action is
/// gated on <c>IsSuntechAdmin()</c>.
///
/// MIGRATED to the layered API (step 8): this controller now only routes, checks
/// permission and picks a status code from what <see cref="AdminExperience"/>
/// decides. It touches no `_db` at all — every read and write goes through
/// AdminExperience (SalesApi.ExperienceApi) and, beneath it, PlatformProcess
/// (SalesApi.ProcessApi) and PlatformStore (SalesApi.SystemApi). The domain
/// validation, the designated-admin trust model and the cross-tenant switching
/// moved with them, unchanged.
///
/// Two things this domain forced out of hiding, both fixed rather than
/// duplicated: the ISO-4217 currency allow-list, which was `internal static` on
/// `OrganizationsController` and read across from here (now
/// `OrgCurrencies.Supported` in Contracts), and `AggregateDriftReport`, which sat
/// in the System layer where the Experience layer cannot see it at all.
/// </summary>
[ApiController]
[Authorize]
[Route("admin")]
public class AdminController : ControllerBase
{
    private readonly AdminExperience _admin;
    public AdminController(AdminExperience admin) => _admin = admin;

    private IActionResult? RequireAdmin() =>
        User.IsSuntechAdmin() ? null : StatusCode(403, new { error = "Only an app administrator can do this." });

    /// <summary>The one place a refusal becomes a status code, so no endpoint
    /// below re-derives the reason from a message string.</summary>
    private IActionResult Refused(PlatformProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason })
        : refusal.Conflict ? Conflict(new { error = refusal.Reason })
        : BadRequest(new { error = refusal.Reason });

    // GET /admin/allowed-domains — the approved-domain allowlist.
    [HttpGet("allowed-domains")]
    public async Task<IActionResult> ListDomains()
    {
        if (RequireAdmin() is { } err) return err;
        return Ok(await _admin.AllowedDomainsAsync());
    }

    // POST /admin/allowed-domains — approve a domain for self-registration.
    [HttpPost("allowed-domains")]
    public async Task<IActionResult> AddDomain([FromBody] AllowedDomainInput input)
    {
        if (RequireAdmin() is { } err) return err;
        var (domain, refusal) = await _admin.AddAllowedDomainAsync(input, User.UserId());
        return refusal is not null ? Refused(refusal) : StatusCode(201, domain);
    }

    // DELETE /admin/allowed-domains/{id} — revoke approval. Existing orgs on that
    // domain keep working; this only blocks future first-time registrations.
    [HttpDelete("allowed-domains/{id:guid}")]
    public async Task<IActionResult> RemoveDomain(Guid id)
    {
        if (RequireAdmin() is { } err) return err;
        var refusal = await _admin.RemoveAllowedDomainAsync(id);
        return refusal is not null ? Refused(refusal) : NoContent();
    }

    // GET /admin/organizations — every registered org (cross-tenant, admin only).
    [HttpGet("organizations")]
    public async Task<IActionResult> ListOrgs()
    {
        if (RequireAdmin() is { } err) return err;
        return Ok(await _admin.OrganizationsAsync());
    }

    /// <summary>
    /// POST /admin/organizations — explicit tenant provisioning. A platform admin
    /// names the org, its domain and currency, and DESIGNATES its first org admin
    /// by email, before anyone has signed up. Orgs used to come into existence
    /// only via self-registration (AuthController.Signup's AllowedDomains path,
    /// which is untouched and still governs that flow); this is a second,
    /// independent way for one to exist, chosen up front rather than left to
    /// whoever registers first.
    ///
    /// The designated admin does not become an admin here — creating the row does
    /// not create their account. <see cref="AuthController.Signup"/> is what
    /// enforces the designation: while this org has no registered admin, only the
    /// designated email may register, and doing so is what makes them one. See
    /// the doc comment on that check for why it has to be scoped this narrowly.
    ///
    /// E7.2 (design doc to-do/e7-config-platform-design.md §3): <c>input.TemplateId</c>
    /// is the new-org wizard's "start from template" step — optional, and an
    /// org created without one behaves exactly as before this story.
    /// </summary>
    [HttpPost("organizations")]
    public async Task<IActionResult> CreateOrganization([FromBody] CreateOrganizationInput input)
    {
        if (RequireAdmin() is { } err) return err;
        var (org, refusal) = await _admin.CreateOrganizationAsync(input, User.UserId());
        return refusal is not null ? Refused(refusal) : StatusCode(201, org);
    }

    // DELETE /admin/organizations/{orgId}/leads — permanently delete every lead in
    // an organization (its activities, invoices, proposals and reminders cascade
    // away with it). suntech-admin only, irreversible. Returns the count removed.
    [HttpDelete("organizations/{orgId:guid}/leads")]
    public async Task<IActionResult> DeleteOrgLeads(Guid orgId)
    {
        if (RequireAdmin() is { } err) return err;
        var (deleted, refusal) = await _admin.DeleteOrgLeadsAsync(orgId);
        return refusal is not null ? Refused(refusal) : Ok(new { deleted });
    }

    /// <summary>GET /templates — the platform-shipped starter templates
    /// (design doc §3, §8 slice 8), for the new-org wizard's "start from
    /// template" picker. suntech-admin only, same as every other endpoint on
    /// this controller: today the only caller of this list is the explicit
    /// org-provisioning screen above, which is itself suntech-admin only.
    /// </summary>
    [HttpGet("~/templates")]
    public IActionResult Templates()
    {
        if (RequireAdmin() is { } err) return err;
        return Ok(_admin.Templates());
    }

    /// <summary>
    /// POST /admin/organizations/{targetOrgId}/clone-from/{sourceOrgId} —
    /// clone-from-org (design doc §3, §10 owner answer 2): exports
    /// <paramref name="sourceOrgId"/>'s whole configuration (custom fields,
    /// picklists, safe settings, playbooks, lead forms, automations — never
    /// records, users or secrets, structurally: see
    /// <c>PackageCloneProcess</c>'s own class comment) and applies it to
    /// <paramref name="targetOrgId"/> through the same import pipeline any
    /// package uses. suntech-admin only; audited via the ordinary
    /// PackageApplyRecord trail (<c>GET /admin/packages/applies</c>, read
    /// from the TARGET org's own scope).
    /// </summary>
    [HttpPost("organizations/{targetOrgId:guid}/clone-from/{sourceOrgId:guid}")]
    public async Task<IActionResult> CloneOrgConfig(Guid targetOrgId, Guid sourceOrgId, [FromBody] CloneOrgConfigInput? input)
    {
        if (RequireAdmin() is { } err) return err;
        var (result, refusal) = await _admin.CloneOrgConfigAsync(sourceOrgId, targetOrgId, input?.Name, User.UserId());
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    // GET /admin/aggregate-health — what last night's drift check found, per org,
    // plus how many buckets are sitting in the durable retry queue (audit C9).
    //
    // This is the human end of "detect and REPORT". The check itself never
    // corrects anything (see Services/AggregateDrift for why); this is where
    // someone reads what it found, and the resync below is where they act on it
    // once they understand the cause.
    //
    // Findings are read from the stored report rather than recomputed here: the
    // point is to show what the scheduled check saw. Pass ?live=true to run the
    // comparison now — for confirming a resync worked, or for an org whose
    // nightly run hasn't happened yet.
    //
    // A null `report` means the scheduled check has not run for that org yet —
    // which is NOT the same as "no drift", and must not be rendered as a clean
    // bill of health.
    [HttpGet("aggregate-health")]
    public async Task<IActionResult> AggregateHealth([FromQuery] bool live = false)
    {
        if (RequireAdmin() is { } err) return err;
        return Ok(await _admin.AggregateHealthAsync(live));
    }

    // POST /admin/organizations/{orgId}/aggregates/resync — the DELIBERATE
    // repair. Re-derives every aggregate for one org from `leads`, then re-checks
    // immediately and returns the result, so the caller sees whether the resync
    // actually settled the disagreement rather than assuming it.
    //
    // Deliberate is the whole design (C9): the nightly drift check reports a
    // disagreement and stops there, so a bug in the checker can never rewrite
    // good aggregates on its own. A person reads the finding, decides the
    // aggregates are the wrong side of it, and calls this.
    //
    // Distinct from the automatic retry queue, which needs no decision: a queued
    // bucket is one the database itself recorded as never having been recomputed.
    [HttpPost("organizations/{orgId:guid}/aggregates/resync")]
    public async Task<IActionResult> ResyncAggregates(Guid orgId)
    {
        if (RequireAdmin() is { } err) return err;
        var (report, refusal) = await _admin.ResyncAggregatesAsync(orgId);
        return refusal is not null ? Refused(refusal) : Ok(report);
    }
}

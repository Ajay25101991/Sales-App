using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.ExperienceLayer.AccountingSync;
using SalesApi.Services;

namespace SalesApi.Controllers;

// E17.3: the accounting sync log. Gated on the same permission the invoices
// screens use (financials.view). Routing, permission and status codes only —
// the rules are in AccountingSyncProcess.
[ApiController]
[Route("accounting-sync")]
[Authorize]
[RequirePermission(OrganizationPermissions.ViewFinancials)]
public class AccountingSyncController : ControllerBase
{
    private readonly AccountingSyncExperience _sync;
    public AccountingSyncController(AccountingSyncExperience sync) => _sync = sync;

    // GET /accounting-sync/failed?limit= — pushes that failed, newest first (both still retrying and gave up; see will_retry).
    [HttpGet("failed")]
    public async Task<IActionResult> Failed(int? limit) => Ok(await _sync.ListFailedAsync(limit));

    // POST /accounting-sync/{id}/retry — re-queues a failed push; the worker pushes it on its next pass.
    [HttpPost("{id:guid}/retry")]
    public async Task<IActionResult> Retry(Guid id)
    {
        var outcome = await _sync.RetryAsync(id, DateTime.UtcNow);
        if (outcome.Row is not null) return Ok(outcome.Row);
        return outcome.NotFound
            ? NotFound(new { error = outcome.Error })
            : BadRequest(new { error = outcome.Error });
    }
}

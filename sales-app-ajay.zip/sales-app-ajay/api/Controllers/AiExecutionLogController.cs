using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.AiPlatform;
using SalesApi.ProcessLayer.AiPlatform;
using SalesApi.Services;

namespace SalesApi.Controllers;

// The E4.2 execution log + opt-in text-capture toggle (design doc
// to-do/e4-ai-platform-design.md §3, §15 slice 4). Admin-only, same
// permission that gates the AI provider settings endpoints (slice 2,
// SettingsController's ai-provider trio) — OrganizationPermissions.ManageSettings,
// reused rather than a new bit per the story brief. What is left here,
// deliberately: routing, [Authorize], the inline permission check, model
// binding and status codes — same split AiActionPoliciesController's own
// header documents.
[ApiController]
[Authorize]
public class AiExecutionLogController : ControllerBase
{
    private readonly AiExecutionLogExperience _log;
    public AiExecutionLogController(AiExecutionLogExperience log) => _log = log;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);

    private static IActionResult FromRefusal(AiExecutionLogProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : new BadRequestObjectResult(new { error = refusal.Reason });

    // GET /admin/ai-log — filter by user, feature, outcome, date range;
    // keyset-paginated, newest first.
    [HttpGet("admin/ai-log")]
    public async Task<IActionResult> List(
        [FromQuery] Guid? userId, [FromQuery] string? feature, [FromQuery] string? outcome,
        [FromQuery] DateTime? from, [FromQuery] DateTime? to,
        [FromQuery] string? cursor, [FromQuery] int? limit)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot view AI activity." });
        return Ok(await _log.ListAsync(userId, feature, outcome, from, to, cursor, limit));
    }

    // GET /admin/ai-log/{id} — the full trace.
    [HttpGet("admin/ai-log/{id:guid}")]
    public async Task<IActionResult> Get(Guid id)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot view AI activity." });
        var (detail, refusal) = await _log.GetAsync(id);
        return refusal is not null ? FromRefusal(refusal) : Ok(detail);
    }

    // GET /admin/ai-text-capture — current status (on/off, until).
    [HttpGet("admin/ai-text-capture")]
    public async Task<IActionResult> GetCaptureStatus()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot view this setting." });
        return Ok(await _log.GetCaptureStatusAsync());
    }

    // PUT /admin/ai-text-capture — switch on for N days, or off now.
    [HttpPut("admin/ai-text-capture")]
    public async Task<IActionResult> SetCapture([FromBody] AiTextCaptureInput input)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (status, refusal) = await _log.SetCaptureAsync(input, User.UserId());
        return refusal is not null ? FromRefusal(refusal) : Ok(status);
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Roles;
using SalesApi.ProcessLayer.Roles;
using SalesApi.Services;

namespace SalesApi.Controllers;

[ApiController]
[Authorize]
[Route("roles")]
public class RolesController : ControllerBase
{
    private readonly RolesExperience _roles;
    public RolesController(RolesExperience roles) => _roles = roles;

    [HttpGet]
    public async Task<IActionResult> Get(CancellationToken ct)
    {
        // Projected rather than returned raw so `assignable` — which is about the
        // CALLER, not the role — never round-trips back into the stored definition
        // on PUT. It lets a picker leave out a role the caller can't hand out
        // instead of offering it and collecting a 403; the save path still decides
        // on every write.
        var roles = await _roles.ListAsync(User.OrgId(), User.Role(), User.IsOrgAdmin(), User.IsSuntechAdmin(), ct);
        return Ok(roles);
    }

    /// <summary>E12.1 - the fixed vocabulary the roles screen renders its Sensitive data section from.</summary>
    [HttpGet("data-access-catalog")]
    public IActionResult DataAccessCatalog() => Ok(new
    {
        levels = new object[]
        {
            new { key = SensitiveLevels.Full, label = "Full" },
            new { key = SensitiveLevels.ViewOnly, label = "View only" },
            new { key = SensitiveLevels.MaskedPartial, label = "Masked (partial)" },
            new { key = SensitiveLevels.MaskedFull, label = "Masked (full)" },
            new { key = SensitiveLevels.Hidden, label = "Hidden" },
        },
        categories = new object[]
        {
            Category(SensitiveCategories.ContactDetails, "Email, phone, address, city, state, postal code, country and nationality."),
            Category(SensitiveCategories.DealValues, "A deal's negotiation, closed and proposal value."),
            Category(SensitiveCategories.IdBank, "National ID and bank details, on custom fields tagged with this category."),
            Category(SensitiveCategories.CompanyFinancials, "Pricing models (fixed and variable costs, fee formulas) and catalogue prices."),
            Category(SensitiveCategories.IdentityChecks, "Date of birth and identity verification, on custom fields tagged with this category."),
            Category(SensitiveCategories.DealInsights, "Internal lead notes, lost reasons and activity notes."),
            Category(SensitiveCategories.PartnerCommercials, "Channel-partner commission rates, ledger amounts, statements and payouts. Roles with a partner permission default to Full; all others to Hidden."),
        },
    });

    private static object Category(string key, string description) =>
        new { key, label = SensitiveCategories.Label(key), description, levels = SensitiveLevels.All };

    /// <summary>
    /// Gated on the SAME permission the read is gated on client-side and the nav
    /// filters on — <c>roles.manage</c> — rather than on <c>role == "admin"</c>. The
    /// base-role test was the last leftover of the kind tasks #25/#30 removed, and it
    /// was the only place in the admin surface where the gate the UI applies and the
    /// gate the server applies disagreed: a custom role granted `roles.manage` could
    /// open the screen and then collect a 403 from Save.
    ///
    /// Two things had to move WITH that gate, because widening who may reach this
    /// endpoint widens who can reach everything it writes:
    ///
    ///   1. <c>is_predefined</c> is no longer taken from the request body. It gated the
    ///      "custom roles cannot inherit organization-admin authority" rule, so a body
    ///      claiming <c>is_predefined: true</c> on a brand-new key walked straight past
    ///      it — and the assignment loop below then writes <c>member.Role =
    ///      definition.BaseRole</c>, which would have handed the caller the `admin`
    ///      BASE ROLE and every rank check in UserAdminPolicy with it. Unreachable
    ///      while only admins could call this; reachable the moment a manager can. See
    ///      OrganizationRoleService.ValidateAndNormalize, where the flag is now derived
    ///      from the shipped key set.
    ///
    ///   2. A role's base role may not be introduced or raised above what the caller
    ///      may hand out (UserAdminPolicy.CanAssignRole) — the same ladder /team's
    ///      invite and re-role paths use. Editing roles must not become a side door
    ///      around the rank rule task #38 closed.
    /// </summary>
    [HttpPut]
    [RequirePermission(OrganizationPermissions.ManageRoles)]
    public async Task<IActionResult> Save([FromBody] RoleListInput input, CancellationToken ct)
    {
        if (User.OrgId() is not Guid orgId) return BadRequest(new { error = "Organization is required." });

        var (config, refusal) = await _roles.SaveAsync(
            orgId, input.Roles ?? [], User.Role(), User.IsOrgAdmin(), User.IsSuntechAdmin(), User.UserId(), ct);

        if (refusal is not null)
        {
            return refusal.Kind switch
            {
                RoleProcess.RefusalKind.Validation => BadRequest(new { error = refusal.Reason }),
                RoleProcess.RefusalKind.RolesInUse => Conflict(new { error = refusal.Reason }),
                _ => StatusCode(403, new { error = refusal.Reason }), // RankDenied, SelfGrant, SelfVisibility
            };
        }

        // Echo what the store now resolves to rather than what was submitted: if a
        // grant failed to persist, the roles screen must show that.
        return Ok(config!.Roles);
    }
}

/// <summary>The PUT /roles body. Binds straight to <c>RoleDraft</c> (the plain-value
/// contract, not <c>SalesApi.Services.OrganizationRoleDefinition</c>) so the model
/// binder itself never touches a System type.</summary>
public record RoleListInput(List<RoleDraft>? Roles);

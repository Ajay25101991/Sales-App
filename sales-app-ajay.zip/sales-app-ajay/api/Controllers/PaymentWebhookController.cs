using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SalesApi.ExperienceLayer.OnlinePayments;
using SalesApi.ProcessLayer.OnlinePayments;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E17.5 online payment - the payment gateway's SIGNED callback, one address per organization connection:
/// <c>POST /webhooks/payments/stripe/{connection_id}</c> (the id is shown on <c>GET /online-payments/setup</c>). Anonymous, because the gateway is not a
/// user; trust comes from the signature, which is checked against the connection's own webhook secret before anything is read or recorded. Mirrors
/// <see cref="WhatsAppWebhookController"/>: the raw body is read once (the signature covers the exact bytes), 400 on anything not genuine, and the
/// rules - signature, idempotency, recording the payment - are <see cref="OnlinePaymentWebhookProcess"/>.
///
/// 200 <c>{ received: true }</c> for a genuine event, whether it was acted on, was a replay or is one this build does not use. 400 <c>{ error }</c> for an
/// unknown connection, a missing / wrong / stale signature, or an event that names no checkout of ours - the gateway keeps retrying those, and nothing
/// is ever recorded for them. An error while recording is NOT swallowed (500), so the gateway retries and the payment is not lost.
/// </summary>
[ApiController]
[Route("webhooks/payments")]
[AllowAnonymous]
[EnableRateLimiting("payment-webhook")]
public class PaymentWebhookController : ControllerBase
{
    private readonly OnlinePaymentExperience _payments;
    public PaymentWebhookController(OnlinePaymentExperience payments) => _payments = payments;

    [HttpPost("stripe/{connectionId:guid}")]
    [RequestSizeLimit(1024 * 1024)]
    public async Task<IActionResult> Stripe(Guid connectionId, CancellationToken ct)
    {
        using var ms = new MemoryStream();
        await Request.Body.CopyToAsync(ms, ct);
        var signature = Request.Headers[StripeCheckoutGateway.SignatureHeader].FirstOrDefault();

        var result = await _payments.HandleWebhookAsync(connectionId, ms.ToArray(), signature, ct);
        return result.Outcome == OnlinePaymentWebhookProcess.Outcome.Rejected
            ? BadRequest(new { error = result.Error })
            : Ok(new { received = true });
    }
}

using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SalesApi.Dtos;
using SalesApi.ProcessLayer.WhatsApp;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E6.4 (design doc to-do/e6-connectors-design.md §2, §3.6, §4.3) - the public, unauthenticated Meta WhatsApp webhook.
///
/// ONE ADDRESS PER ORGANIZATION: <c>/webhooks/whatsapp/{org_id}</c>, shown on the WhatsApp settings screen (integrations audit,
/// owner decision 1). The org supplies its own Meta app, so its app secret and verify token are fields of its WhatsApp connection
/// (never deployment config - production never set them, which left inbound dead), and the org comes from the path. Mirrors
/// <c>MetaLeadAdsWebhookController</c>.
///
/// The old deployment-wide address <c>/webhooks/whatsapp</c> (no org) still answers ONLY when <c>WhatsApp:VerifyToken</c> /
/// <c>WhatsApp:AppSecret</c> deployment config is set, so anything already pointed at it keeps working; with neither set it is 404.
///
/// Does exactly three things: verify (signature on POST, token on the GET handshake), hand the payload to
/// <see cref="WhatsAppInboundProcess"/>, and return 200 fast - Meta retries aggressively on non-2xx/timeout, so an internal
/// processing failure is logged and swallowed here rather than surfaced as a webhook error (§3.6 step 6).
/// </summary>
[ApiController]
[Route("webhooks/whatsapp/{orgId:guid?}")]
[AllowAnonymous]
[EnableRateLimiting("whatsapp-webhook")]
public class WhatsAppWebhookController : ControllerBase
{
    private readonly WhatsAppInboundProcess _inbound;
    private readonly IConfiguration _config;
    private readonly SalesApi.ExperienceLayer.Integrations.IntegrationEventsExperience _incomingLog;

    public WhatsAppWebhookController(
        WhatsAppInboundProcess inbound, IConfiguration config, SalesApi.ExperienceLayer.Integrations.IntegrationEventsExperience incomingLog)
    {
        _inbound = inbound;
        _config = config;
        _incomingLog = incomingLog;
    }

    // Integrations audit - the incoming log. The org comes from the address's {orgId} route value; on the legacy org-less address
    // there is no org to file the line under and nothing is written. Never throws, never carries a body or a secret.
    private Task LogIncomingAsync(string outcome, string detail) =>
        _incomingLog.RecordInboundAsync(
            Request.RouteValues.TryGetValue("orgId", out var v) && Guid.TryParse(v?.ToString(), out var org) ? org : null,
            ConnectorRegistry.Keys.WhatsAppBusiness, outcome, detail, null, HttpContext.RequestAborted);

    // GET - the one-time verification handshake (design §4.3 point 1), run when the URL is registered in the Meta App dashboard.
    [HttpGet]
    public async Task<IActionResult> Verify(
        Guid? orgId,
        [FromQuery(Name = "hub.mode")] string? mode,
        [FromQuery(Name = "hub.verify_token")] string? verifyToken,
        [FromQuery(Name = "hub.challenge")] string? challenge,
        CancellationToken ct)
    {
        if (orgId is Guid org)
        {
            if (!await _inbound.VerifyHandshakeAsync(org, mode, verifyToken, ct))
            {
                await LogIncomingAsync(InboundEventOutcomes.RejectedVerify, "Meta's verify token did not match the one saved here.");
                return StatusCode(403);
            }
            await LogIncomingAsync(InboundEventOutcomes.Accepted, "Meta verified the webhook address.");
            return Content(challenge ?? "", "text/plain");
        }

        // Legacy deployment-wide address: only when the deployment config is set.
        var expected = _config["WhatsApp:VerifyToken"];
        if (string.IsNullOrEmpty(expected)) return NotFound();
        if (!WhatsAppWebhookVerifier.VerifyHandshake(mode, verifyToken, expected)) return StatusCode(403);
        return Content(challenge ?? "", "text/plain");
    }

    // POST - every real delivery (design §3.6, §4.3 point 2). A missing/invalid signature is rejected BEFORE any parsing, 401, and
    // logged WITHOUT the message body (§4.4).
    [HttpPost]
    public async Task<IActionResult> Receive(Guid? orgId, CancellationToken ct)
    {
        var legacySecret = _config["WhatsApp:AppSecret"];
        if (orgId is null && string.IsNullOrEmpty(legacySecret)) return NotFound();

        Request.EnableBuffering();
        using var ms = new MemoryStream();
        await Request.Body.CopyToAsync(ms, ct);
        var rawBody = ms.ToArray();

        var signatureHeader = Request.Headers[WhatsAppWebhookVerifier.SignatureHeader].FirstOrDefault();
        var verified = orgId is Guid org
            ? await _inbound.VerifySignatureAsync(org, rawBody, signatureHeader, ct)
            : WhatsAppWebhookVerifier.VerifySignature(rawBody, signatureHeader, legacySecret!);
        if (!verified)
        {
            // Never the message body - only that the signature failed.
            Console.WriteLine("[whatsapp-webhook] signature verification failed - payload rejected before processing");
            await LogIncomingAsync(InboundEventOutcomes.RejectedSignature, "The signature was missing or did not match the saved app secret.");
            return Unauthorized();
        }

        try
        {
            using var doc = JsonDocument.Parse(rawBody);
            await _inbound.HandleWebhookAsync(doc.RootElement, ct, orgId);
            await LogIncomingAsync(InboundEventOutcomes.Accepted, "Delivery handled.");
        }
        catch (Exception e)
        {
            await LogIncomingAsync(InboundEventOutcomes.FailedProcessing, $"Handling the delivery failed ({e.GetType().Name}).");
            // Design §3.6 step 6 - a malformed or unmatched payload still gets 200 (a legitimate transient error retried by Meta is
            // fine; a permanently-unmatchable payload retried forever is not). Logged without the body.
            Console.WriteLine($"[whatsapp-webhook] processing error: {e.Message}");
        }

        return Ok();
    }
}

using SalesApi.ExperienceLayer.Quotes;
using SalesApi.Dtos;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.ProcessLayer.Quotes;
using SalesApi.Services;

// The HTML helpers below take a CustomerQuoteDto, not the Proposal entity.
// That is the change that makes the layering real for this domain: the customer
// page renders a CONTRACT, so a column rename on the entity is no longer a
// breaking change for the page — which is the coupling the whole exercise
// exists to remove. QuotesExperience does the mapping, because Process is the last
// layer that may legally see an entity.
namespace SalesApi.Controllers;

// Public (no-auth) accept flow for a quote, reached via the shareable link in the
// Email/WhatsApp message. Only ever exposes a single quote by its opaque token.
//
// MIGRATED to the layered API (step 8): this controller now only routes,
// selects a status code/HTML shape from what QuotesExperience decides, and renders
// the markup. It touches no _db at all — every read and write goes through
// QuotesExperience (SalesApi.ProcessApi) and, beneath it, QuoteStore
// (SalesApi.SystemApi). The business rules that used to live inline here —
// which statuses may be viewed/accepted, what a refusal should say, the accept
// write and its notification — moved with them.
// [AllowAnonymous] moved from the class down to the two public accept-flow
// actions (Page, Accept) — E6.3 added an AUTHENTICATED action (Views) to this
// same controller, and AllowAnonymous is all-or-nothing per endpoint metadata:
// ASP.NET Core skips authorization for an action if EITHER the action OR its
// controller carries the attribute, so leaving it at class level would have
// made Views anonymous too, silently.
[ApiController]
[Route("quotes")]
public class QuotesController : ControllerBase
{
    private readonly QuotesExperience _quotes;
    private readonly CallerContext _caller;
    public QuotesController(QuotesExperience quotes, CallerContext caller)
    {
        _quotes = quotes;
        _caller = caller;
    }

    internal static string Esc(string? s) => System.Net.WebUtility.HtmlEncode(s ?? "");

    // GET /quotes/accept/{token} — a minimal self-contained accept page.
    [HttpGet("accept/{token}")]
    [Produces("text/html")]
    [AllowAnonymous]
    public async Task<IActionResult> Page(string token)
    {
        // E6.3 — facts about the caller travel DOWN as data (the layering
        // rule): QuoteProcess must not read HttpContext/Request itself, so the
        // IP and UA are read here and handed down as plain strings. Behind the
        // ALB, Connection.RemoteIpAddress is already the real client IP — see
        // Program.cs's ForwardedHeaders configuration, the same source the
        // rate limiter's partition key uses.
        var ip = HttpContext?.Connection?.RemoteIpAddress?.ToString();
        var userAgent = HttpContext?.Request?.Headers.UserAgent.ToString();
        var view = await _quotes.ViewAsync(token, ip, userAgent);
        if (view.Outcome == QuoteProcess.QuoteViewOutcome.NotFound)
            return Content(Html("Quote not found", "<p>This link is no longer valid.</p>"), "text/html");

        var quote = view.Quote!;
        string body = view.Outcome switch
        {
            QuoteProcess.QuoteViewOutcome.Accepted => AcceptedBody(quote),
            // Layer one: never render a form for a quote the POST would refuse,
            // so a customer is not invited to accept something that cannot be
            // accepted. Layer two is the guard QuoteProcess.AcceptAsync makes.
            QuoteProcess.QuoteViewOutcome.Refused => RefusalBody(quote, view.Refusal!),
            _ =>
                // The number the customer will quote back at us. Absent on a
                // quote reached before it was ever sent — which is possible, the
                // accept link is handed out with the draft — so it is rendered
                // only when there is one, never invented.
                (quote.Number is null ? "" : $"<p class='num'>Quote {Esc(quote.Number)}</p>") +
                $"<div class='total'>{ProposalTemplate.Money(quote.Total, view.Currency!)}</div>" +
                ItemizedTable(quote, view.Currency!, view.TaxLabel!) +
                $"<form method='post' action='/quotes/accept/{Esc(token)}'>" +
                "<input name='name' placeholder='Your full name' required />" +
                "<button type='submit'>Accept quote</button></form>",
        };
        return Content(Html(quote.Title, body), "text/html");
    }

    // The customer's thank-you, for both a fresh acceptance and a repeat visit
    // to an already-accepted quote.
    private static string AcceptedBody(CustomerQuoteDto quote) =>
        $"<div class='ok'>✓ Accepted</div><p>Thanks{(quote.AcceptedBy is null ? "" : ", " + Esc(quote.AcceptedBy))} — this quote was accepted on {quote.AcceptedAt:MMM d, yyyy}.</p>";

    // The refusal a customer meets when their link points at a quote that is not
    // open to acceptance. Shared by GET (which shows it instead of the form) and
    // POST (which refuses with it), so the two can never disagree. The DECISION
    // behind each case — which kind of refusal, and whether a successor exists
    // to point at — is QuoteProcess.RefusalInfo; this is only the wording.
    //
    // Worded for the actual status rather than one generic message: a replaced
    // quote can point at its successor and should, while a declined one must not
    // pretend to be replaced — telling a customer their quote was "replaced" when
    // the rep wrote the deal off is a different and misleading claim. None of
    // these show prices: the figures on a closed quote are not on offer, and
    // leaving them beside a dead button invites exactly the confusion this
    // prevents.
    private static string RefusalBody(CustomerQuoteDto quote, QuoteProcess.RefusalInfo refusal) => refusal.Kind switch
    {
        "superseded" => SupersededBody(quote, refusal),
        "declined" =>
            "<div class='replaced'>This quote is no longer open</div>" +
            $"<p>{Esc(quote.Number ?? quote.Title)} was closed and can't be accepted.</p>" +
            "<p class='valid'>If you'd like it reissued, please get in touch — we'll send a fresh quote.</p>",
        // Draft: never sent, so from the customer's side it does not exist yet.
        // Deliberately says nothing about its contents or that a draft exists —
        // this link was not meant to be in anyone's hands.
        _ =>
            "<div class='replaced'>This quote isn't available</div>" +
            "<p>This link isn't active. Please contact us for a current quote.</p>",
    };

    // The "this has been replaced" page, shared by GET (which shows it) and POST
    // (which refuses with it).
    //
    // Links on to the replacement when QuotesExperience found one worth offering. If
    // there is no usable link the page still says the quote was replaced and
    // tells the customer to ask for the current version — it never invents a
    // number or a URL, and never falls back to letting them accept this one.
    private static string SupersededBody(CustomerQuoteDto quote, QuoteProcess.RefusalInfo refusal)
    {
        var sb = new StringBuilder();
        sb.Append("<div class='replaced'>This quote has been replaced</div>");
        sb.Append($"<p>{Esc(quote.Number ?? quote.Title)} is no longer current and can't be accepted.</p>");

        if (refusal.SuccessorToken is not null)
        {
            var label = string.IsNullOrEmpty(refusal.SuccessorNumber) ? "the current version" : Esc(refusal.SuccessorNumber);
            sb.Append($"<p><a class='cta' href='/quotes/accept/{Esc(refusal.SuccessorToken)}'>View {label}</a></p>");
        }
        else
        {
            sb.Append("<p class='valid'>Please contact us for the current version.</p>");
        }
        return sb.ToString();
    }

    // Itemised AED/org-currency breakdown with VAT and validity (C1) — used for
    // every quote, old and new. Pre-C1 rows have an empty LineItems array
    // (nothing was ever tracked per-line before this migration), so they fall
    // back to a single "Amount" row built from the already-migrated Subtotal.
    private static string ItemizedTable(CustomerQuoteDto quote, string currency, string taxLabel = "VAT")
    {
        var sb = new StringBuilder();
        sb.Append("<table class='items'>");
        var items = ParseLineItems(quote.LineItems);
        if (items.Count == 0) items.Add(("Amount", 1m, quote.Subtotal));
        foreach (var (desc, qty, unitPrice) in items)
        {
            // Qty × unit price is spelled out only when the quantity is not 1.
            // Printing "1 × AED 5,000" on a line that was never priced per unit
            // — every pre-#83 line included — would assert a pricing model the
            // quote does not have.
            var label = qty == 1m ? Esc(desc) : $"{Esc(desc)}<span class='qty'>{qty:0.##} × {ProposalTemplate.Money(unitPrice, currency)}</span>";
            var lineTotal = QuoteNumbering.LineTotal(qty, unitPrice);
            sb.Append($"<tr><td>{label}</td><td class='amt'>{ProposalTemplate.Money(lineTotal, currency)}</td></tr>");
        }
        if (quote.DiscountAmount > 0)
            sb.Append($"<tr><td>Less: negotiated discount</td><td class='amt'>-{ProposalTemplate.Money(quote.DiscountAmount, currency)}</td></tr>");
        sb.Append($"<tr class='sub'><td>Subtotal</td><td class='amt'>{ProposalTemplate.Money(quote.Subtotal, currency)}</td></tr>");
        if (quote.TaxRate > 0)
            sb.Append($"<tr><td>{Esc(taxLabel)} @ {quote.TaxRate:0.##}%</td><td class='amt'>{ProposalTemplate.Money(quote.TaxAmount, currency)}</td></tr>");
        sb.Append($"<tr class='sub'><td>Total due</td><td class='amt'>{ProposalTemplate.Money(quote.Total, currency)}</td></tr>");
        sb.Append("</table>");
        if (quote.ValidUntil is DateTime vu)
            sb.Append($"<p class='valid'>Valid until {vu:MMM d, yyyy}</p>");
        return sb.ToString();
    }

    // Shared by every reader of the quote's jsonb line snapshot. Since #83 a line
    // is {description, quantity, unit_price}; `amount` is still accepted as a
    // quantity-1 unit price so a row written by an older deployment (or an
    // in-flight request straddling the migration) still renders its real total
    // rather than zero.
    /// <summary>
    /// Forwards to <see cref="Services.QuoteLineItems.Parse"/>, which is now the
    /// only implementation. Kept as a public static here because
    /// `QuoteNumberingTests` calls it by this name; the parsing itself is no
    /// longer this controller's business.
    /// </summary>
    public static List<(string Description, decimal Quantity, decimal UnitPrice)> ParseLineItems(string json) =>
        Services.QuoteLineItems.Parse(json);

    // POST /quotes/accept/{token} — records acceptance (HTML form or JSON {name}).
    [HttpPost("accept/{token}")]
    [Consumes("application/x-www-form-urlencoded", "application/json")]
    [AllowAnonymous]
    public async Task<IActionResult> Accept(string token, [FromForm] string? name)
    {
        var result = await _quotes.AcceptAsync(token, name);
        return result.Outcome switch
        {
            QuoteProcess.AcceptOutcome.NotFound =>
                Content(Html("Quote not found", "<p>This link is no longer valid.</p>"), "text/html"),
            // THE refusal, on the WRITE — not only on the page that renders the
            // form. A POST can arrive from an old email, a bookmarked URL or a
            // replayed request without the form ever being rendered, so guarding
            // the page alone would guard nothing. QuoteProcess.AcceptAsync makes
            // this check again independently of what the GET already showed.
            QuoteProcess.AcceptOutcome.Refused =>
                Content(Html("Quote unavailable", RefusalBody(result.Quote!, result.Refusal!)), "text/html"),
            // Accepted or AlreadyAccepted (a double-submit/refresh/repeat click
            // on the same emailed link): the customer sees the same thank-you
            // either way.
            _ =>
                Content(Html("Accepted", $"<div class='ok'>✓ Accepted</div><p>Thank you, {Esc(result.Quote!.AcceptedBy)}! Your acceptance has been recorded.</p>"), "text/html"),
        };
    }

    // GET /quotes/{id}/views (E6.3) — authenticated; same permission as
    // reading the quote itself (QuoteProcess.ViewsAsync mirrors
    // LeadQuoteProcess.LoadAsync's manage:false check). This is the one action
    // on this controller that needs the caller's identity, so it alone carries
    // [Authorize] rather than inheriting the class-level [AllowAnonymous] the
    // other two actions now declare individually.
    [HttpGet("{id:guid}/views")]
    [Authorize]
    public async Task<IActionResult> Views(Guid id)
    {
        var vis = await _caller.ForAsync(User);
        var (refusal, dto) = await _quotes.ViewsAsync(vis, id);
        if (refusal is not null)
            return refusal.NotFound ? NotFound(new { error = refusal.Reason }) : StatusCode(403, new { error = refusal.Reason });
        return Ok(dto);
    }

    // internal: the engagement-letter accept page (E10.9) reuses this shell so the two public pages look the same.
    internal static string Html(string title, string body)
    {
        var sb = new StringBuilder();
        sb.Append("<!doctype html><html><head><meta charset='utf-8'>");
        sb.Append("<meta name='viewport' content='width=device-width, initial-scale=1'>");
        sb.Append($"<title>{Esc(title)}</title><style>");
        sb.Append("body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:640px;margin:0 auto;padding:24px;color:#0f172a;background:#f8fafc}");
        sb.Append("h1{font-size:20px}.total{font-size:32px;font-weight:700;color:#2563eb;margin:8px 0}");
        sb.Append("pre{white-space:pre-wrap;background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:16px;font-family:inherit;font-size:14px}");
        sb.Append("table.items{width:100%;border-collapse:collapse;background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;margin-bottom:16px}");
        sb.Append("table.items td{padding:10px 14px;border-bottom:1px solid #e2e8f0;font-size:14px}");
        sb.Append("table.items td.amt{text-align:right;font-variant-numeric:tabular-nums}");
        sb.Append("table.items tr.sub td{font-weight:700;background:#f1f5f9}");
        sb.Append("p.valid{color:#64748b;font-size:13px;margin:0 0 16px}");
        sb.Append("p.num{color:#64748b;font-size:13px;letter-spacing:.04em;margin:0;font-weight:600}");
        sb.Append("span.qty{display:block;color:#64748b;font-size:12px;margin-top:2px}");
        sb.Append("input{width:100%;padding:12px;border:1px solid #cbd5e1;border-radius:10px;margin:8px 0;font-size:16px;box-sizing:border-box}");
        sb.Append("button{width:100%;padding:14px;border:0;border-radius:10px;background:#2563eb;color:#fff;font-size:16px;font-weight:600}");
        sb.Append(".ok{font-size:22px;font-weight:700;color:#16a34a}");
        sb.Append(".replaced{font-size:22px;font-weight:700;color:#b45309}");
        sb.Append("a.cta{display:inline-block;padding:12px 18px;border-radius:10px;background:#2563eb;color:#fff;font-weight:600;text-decoration:none}");
        sb.Append($"</style></head><body><h1>{Esc(title)}</h1>{body}</body></html>");
        return sb.ToString();
    }
}

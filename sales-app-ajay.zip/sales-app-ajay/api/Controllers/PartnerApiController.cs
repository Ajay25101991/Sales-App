using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.PartnerApi;
using SalesApi.ProcessLayer.PartnerApi;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// The EP-25 partner integration surface — read/update endpoints for an
/// EXTERNAL system authenticating with a scoped API key (project-management,
/// initially), never a signed-in user. Distinct from every other controller
/// two ways:
///
/// <list type="bullet">
/// <item><c>[Authorize(AuthenticationSchemes = ApiKeyAuthenticationDefaults.Scheme)]</c>
/// — the new "ApiKey" scheme (<see cref="ApiKeyAuthenticationHandler"/>), not
/// the JWT bearer scheme every other controller uses. A JWT here is simply
/// not evaluated; a request with no <c>X-Api-Key</c> header gets an ordinary
/// 401, never a 500.</item>
/// <item><c>[RequireApiKeyScope]</c> per action instead of
/// <c>[RequirePermission]</c> — a scope on the KEY, not a permission on a
/// user's role. See <see cref="ApiKeyScopes"/>.</item>
/// </list>
///
/// Org scoping needs no code here at all: <see cref="ApiKeyAuthenticationHandler"/>
/// stamps the same <c>org_id</c> claim a JWT carries, so the ordinary tenant
/// query filter (<see cref="Services.TenantProvider"/>) already scopes every
/// read/write below to the key's own org — a lead id from another org 404s
/// the same way it would for a signed-in user in the wrong org, because the
/// row is invisible to the query, not because of an extra check.
/// </summary>
[ApiController]
[Route("partner/v1")]
[Authorize(AuthenticationSchemes = ApiKeyAuthenticationDefaults.Scheme)]
[RequirePlanFeature(PlanCatalogue.Features.ApiWebhooks)]
public class PartnerApiController : ControllerBase
{
    private readonly PartnerApiExperience _partner;
    public PartnerApiController(PartnerApiExperience partner) => _partner = partner;

    private static IActionResult FromRefusal(PartnerApiProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : new BadRequestObjectResult(new { error = refusal.Reason });

    // GET /partner/v1/accounts?updated_since=&cursor=&limit=
    [HttpGet("accounts")]
    [RequireApiKeyScope(ApiKeyScopes.Keys.AccountsRead)]
    public async Task<IActionResult> Accounts(
        [FromQuery] DateTime? updated_since, [FromQuery] string? cursor, [FromQuery] int? limit) =>
        Ok(await _partner.AccountsAsync(updated_since, cursor, limit));

    // GET /partner/v1/accounts/{id}
    [HttpGet("accounts/{id:guid}")]
    [RequireApiKeyScope(ApiKeyScopes.Keys.AccountsRead)]
    public async Task<IActionResult> Account(Guid id)
    {
        var (account, refusal) = await _partner.AccountAsync(id);
        return refusal is not null ? FromRefusal(refusal) : Ok(account);
    }

    // GET /partner/v1/contacts?account_id=&updated_since=&cursor=&limit=
    [HttpGet("contacts")]
    [RequireApiKeyScope(ApiKeyScopes.Keys.ContactsRead)]
    public async Task<IActionResult> Contacts(
        [FromQuery] Guid? account_id, [FromQuery] DateTime? updated_since, [FromQuery] string? cursor, [FromQuery] int? limit)
    {
        var (page, refusal) = await _partner.ContactsAsync(account_id, updated_since, cursor, limit);
        return refusal is not null ? FromRefusal(refusal) : Ok(page);
    }

    // GET /partner/v1/leads/{id}
    [HttpGet("leads/{id:guid}")]
    [RequireApiKeyScope(ApiKeyScopes.Keys.LeadsRead)]
    public async Task<IActionResult> Lead(Guid id)
    {
        var (lead, refusal) = await _partner.LeadAsync(id);
        return refusal is not null ? FromRefusal(refusal) : Ok(lead);
    }

    // PATCH /partner/v1/leads/{id}/delivery — the entire allow-list is the
    // shape of PartnerLeadDeliveryInput; there is nothing else to reject here.
    [HttpPatch("leads/{id:guid}/delivery")]
    [RequireApiKeyScope(ApiKeyScopes.Keys.LeadsUpdate)]
    public async Task<IActionResult> UpdateLeadDelivery(Guid id, [FromBody] PartnerLeadDeliveryInput input)
    {
        var (lead, refusal) = await _partner.UpdateDeliveryAsync(id, input);
        return refusal is not null ? FromRefusal(refusal) : Ok(lead);
    }
}

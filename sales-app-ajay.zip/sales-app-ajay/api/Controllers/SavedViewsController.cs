using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.SavedViews;
using SalesApi.ProcessLayer.SavedViews;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>E3.8 — saved views (filters/sort/columns for leads/accounts/
/// quotes/invoices, or a saved Explore query spec). Read: anyone signed in.
/// Write: anyone manages their own; a shared view's owner or an org admin
/// (settings.manage) may edit/rename/delete/re-share it; only an org admin
/// may set the org default. This controller routes, checks permission and
/// picks a status code — everything else lives in SavedViewProcess.</summary>
[ApiController]
[Route("saved-views")]
[Authorize]
public class SavedViewsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly SavedViewsExperience _views;
    public SavedViewsController(CallerContext caller, SavedViewsExperience views)
    {
        _caller = caller;
        _views = views;
    }

    private async Task<SavedViewProcess.Caller> CallerAsync() => new(
        User.UserId(),
        User.HasPermission(OrganizationPermissions.ManageSettings),
        await _caller.LiveTeamIdsAsync(User),
        // Accounts rework (decision 14): the grants the gated built-in views need - the Unassigned queue (the same record gate
        // the lead list and the dashboard use) and the account money the Overdue view filters on.
        CanSeeUnassignedQueue: SalesApi.Services.AggregateOwner.VisibleTo(await _caller.ForAsync(User)),
        CanViewAccountFinancials: User.HasPermission(OrganizationPermissions.ViewAccountFinancials));

    private static IActionResult FromRefusal(SavedViewProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        // code is set for the built-in refusal (accounts rework) so the client can say "copy it" instead of "not allowed".
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason, code = refusal.Code }) { StatusCode = 403 }
        : new BadRequestObjectResult(new { error = refusal.Reason, code = refusal.Code });

    // GET /saved-views?list=leads — mine + shared with a team I'm on + org-wide.
    [HttpGet]
    public async Task<IActionResult> ListForMe([FromQuery] string? list) =>
        Ok(await _views.ListForMeAsync(await CallerAsync(), list));

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var (dto, refusal) = await _views.GetAsync(await CallerAsync(), id);
        return refusal is not null ? FromRefusal(refusal) : Ok(dto);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] SavedViewInput input)
    {
        var (created, refusal) = await _views.CreateAsync(await CallerAsync(), input);
        return refusal is not null ? FromRefusal(refusal) : StatusCode(201, created);
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] SavedViewInput input)
    {
        var (updated, refusal) = await _views.UpdateAsync(await CallerAsync(), id, input);
        return refusal is not null ? FromRefusal(refusal) : Ok(updated);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var refusal = await _views.DeleteAsync(await CallerAsync(), id);
        return refusal is not null ? FromRefusal(refusal) : NoContent();
    }

    // POST /saved-views/{id}/org-default { orgDefault: true|false } — org
    // admin only, and only on a view shared org-wide (SavedViewProcess).
    [HttpPost("{id:guid}/org-default")]
    public async Task<IActionResult> SetOrgDefault(Guid id, [FromBody] SetOrgDefaultInput input)
    {
        var refusal = await _views.SetOrgDefaultAsync(await CallerAsync(), id, input.OrgDefault);
        return refusal is not null ? FromRefusal(refusal) : NoContent();
    }

    // POST /saved-views/{id}/my-default { myDefault: true|false } — anyone,
    // for any view they may currently see.
    [HttpPost("{id:guid}/my-default")]
    public async Task<IActionResult> SetMyDefault(Guid id, [FromBody] SetMyDefaultInput input)
    {
        var refusal = await _views.SetMyDefaultAsync(await CallerAsync(), id, input.MyDefault);
        return refusal is not null ? FromRefusal(refusal) : NoContent();
    }
}

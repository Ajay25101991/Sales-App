using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Knowledge;
using SalesApi.ProcessLayer.Knowledge;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E4.6 knowledge collections (design doc to-do/e4-ai-platform-design.md §6,
/// §15 slice 12). Admin-only — same permission as the AI provider/cost-policy
/// admin endpoints (<see cref="AiCostPolicyController"/>'s own comment),
/// <c>OrganizationPermissions.ManageSettings</c>.
/// </summary>
[ApiController]
[Route("knowledge")]
[Authorize]
[StorageUnavailableFilter]
public class KnowledgeController : ControllerBase
{
    private readonly KnowledgeExperience _knowledge;
    public KnowledgeController(KnowledgeExperience knowledge) => _knowledge = knowledge;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);
    private static IActionResult Forbidden => new ObjectResult(new { error = "Your role cannot manage knowledge collections." }) { StatusCode = 403 };

    // --- collections --------------------------------------------------------

    // GET /knowledge/collections
    [HttpGet("collections")]
    public async Task<IActionResult> ListCollections()
    {
        if (!CanManage) return Forbidden;
        return Ok(await _knowledge.ListCollectionsAsync(HttpContext.RequestAborted));
    }

    // POST /knowledge/collections
    [HttpPost("collections")]
    public async Task<IActionResult> CreateCollection([FromBody] KnowledgeCollectionInput input)
    {
        if (!CanManage) return Forbidden;
        var (dto, refusal) = await _knowledge.CreateCollectionAsync(User.OrgId(), User.UserId(), input, HttpContext.RequestAborted);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : StatusCode(201, dto);
    }

    // PUT /knowledge/collections/{id}
    [HttpPut("collections/{id:guid}")]
    public async Task<IActionResult> UpdateCollection(Guid id, [FromBody] KnowledgeCollectionInput input)
    {
        if (!CanManage) return Forbidden;
        var result = await _knowledge.UpdateCollectionAsync(id, input, HttpContext.RequestAborted);
        return result.Outcome switch
        {
            KnowledgeProcess.UpdateOutcome.NotFound => NotFound(new { error = "Collection not found" }),
            KnowledgeProcess.UpdateOutcome.Invalid => BadRequest(new { error = result.Reason }),
            _ => Ok(result.Dto),
        };
    }

    // DELETE /knowledge/collections/{id}
    [HttpDelete("collections/{id:guid}")]
    public async Task<IActionResult> DeleteCollection(Guid id)
    {
        if (!CanManage) return Forbidden;
        var deleted = await _knowledge.DeleteCollectionAsync(id, HttpContext.RequestAborted);
        return deleted ? NoContent() : NotFound(new { error = "Collection not found" });
    }

    // --- documents -----------------------------------------------------------

    // GET /knowledge/collections/{id}/documents
    [HttpGet("collections/{collectionId:guid}/documents")]
    public async Task<IActionResult> ListDocuments(Guid collectionId)
    {
        if (!CanManage) return Forbidden;
        var result = await _knowledge.ListDocumentsAsync(collectionId, HttpContext.RequestAborted);
        return result.Outcome == KnowledgeProcess.ListDocsOutcome.CollectionNotFound
            ? NotFound(new { error = "Collection not found" })
            : Ok(result.Docs);
    }

    // POST /knowledge/collections/{id}/documents  (multipart: field "file")
    [HttpPost("collections/{collectionId:guid}/documents")]
    [RequestSizeLimit(UploadLimits.StaffRequestBytes)]
    public async Task<IActionResult> UploadDocument(Guid collectionId, IFormFile? file)
    {
        if (!CanManage) return Forbidden;
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required" });

        await using var stream = file.OpenReadStream();
        var result = await _knowledge.UploadDocumentAsync(
            collectionId, User.OrgId(), User.UserId(), file.FileName, file.ContentType, file.Length, stream,
            HttpContext.RequestAborted);

        return result.Outcome switch
        {
            KnowledgeProcess.UploadOutcome.CollectionNotFound => NotFound(new { error = "Collection not found" }),
            KnowledgeProcess.UploadOutcome.UnsupportedType => BadRequest(new
            {
                error = $"Unsupported file type — supported types are: {string.Join(", ", KnowledgeSupportedTypes.Extensions)}",
            }),
            _ => StatusCode(201, result.Dto),
        };
    }

    // POST /knowledge/documents/{id}/retry
    [HttpPost("documents/{documentId:guid}/retry")]
    public async Task<IActionResult> RetryDocument(Guid documentId)
    {
        if (!CanManage) return Forbidden;
        var result = await _knowledge.RetryDocumentAsync(documentId, HttpContext.RequestAborted);
        return result.Outcome == KnowledgeProcess.DocOutcome.NotFound
            ? NotFound(new { error = "Document not found" })
            : Ok(result.Dto);
    }

    // DELETE /knowledge/documents/{id}
    [HttpDelete("documents/{documentId:guid}")]
    public async Task<IActionResult> DeleteDocument(Guid documentId)
    {
        if (!CanManage) return Forbidden;
        var deleted = await _knowledge.DeleteDocumentAsync(documentId, HttpContext.RequestAborted);
        return deleted ? NoContent() : NotFound(new { error = "Document not found" });
    }
}

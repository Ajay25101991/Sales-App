using Microsoft.AspNetCore.Mvc.Filters;
using SalesApi.ExperienceLayer.Approvals;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E12.5: writes the once-per-grant <c>value_revealed</c> log entry.
///
/// WHY A FILTER, same reason as <see cref="DataExportLogFilter"/>: the real value can leave through many endpoints (a lead, an account
/// or a contact; detail or list; history) and what they share is that a mapper asked <see cref="SensitiveAccess.ForRecord"/> for the
/// record, which marks the caller's <see cref="RevealGrant"/> as used. This runs after the action has built its response and BEFORE
/// the result is written, so a failure to log stops the value leaving. Only the first response that used a grant logs; later ones find
/// it already claimed (see <c>RevealRequestProcess.LogFirstReadsAsync</c>). Does nothing for the (nearly everyone) caller with no grants.
/// </summary>
public sealed class RevealReadLogFilter : IAsyncResultFilter
{
    private readonly RevealRequestExperience _reveals;
    public RevealReadLogFilter(RevealRequestExperience reveals) => _reveals = reveals;

    public async Task OnResultExecutionAsync(ResultExecutingContext context, ResultExecutionDelegate next)
    {
        var user = context.HttpContext.User;
        if (user.Identity?.IsAuthenticated == true
            && CompactPermissionIdentity.Find(user) is { RevealGrants.Count: > 0 } identity)
        {
            var used = identity.RevealGrants.Where(g => g.Used).ToList();
            if (used.Count > 0)
                await _reveals.LogFirstReadsAsync(user.UserId(), used, context.HttpContext.RequestAborted);
        }
        await next();
    }
}

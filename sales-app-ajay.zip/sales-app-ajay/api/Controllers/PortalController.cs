using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Portal;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Endpoints every portal kind shares (E19.1). Marked for BOTH kinds, so a partner and a customer user may call it; staff get a plain 403 (they have no portal). Anything specific to one
/// kind stays on that kind's own controller (<see cref="PartnerPortalController"/> for partners) and carries only that kind's attribute.
///
/// The controller routes and builds the caller's <see cref="PortalScope"/> from the principal the permission middleware stamped from the profile row - never from the URL - and passes it DOWN as data.
/// </summary>
[ApiController]
[Route("portal")]
[Authorize]
[AllowPartnerPortal]
[AllowCustomerPortal]
public class PortalController : ControllerBase
{
    private readonly PortalExperience _portal;
    public PortalController(PortalExperience portal) => _portal = portal;

    private PortalScope? Scope() =>
        User.PortalKind() is { } kind && User.PortalAccountId() is Guid account
            ? new PortalScope(kind, account, User.PortalIncludeChildren(), User.UserId())
            : null;

    /// <summary>Who is signed in and which account they speak for: <c>{kind, account_id, account_name, include_children, name, email}</c>.</summary>
    [HttpGet("me")]
    public async Task<IActionResult> Me(CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _portal.MeAsync(s, ct)) : StatusCode(403, new { error = "This is for portal users.", code = "not_a_portal_user" });
}

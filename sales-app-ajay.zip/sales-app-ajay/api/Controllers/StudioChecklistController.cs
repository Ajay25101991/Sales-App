using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Studio;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E7.4 Studio — onboarding checklist + go-live readiness (design doc
/// to-do/e7-config-platform-design.md §5.2, slice 14).
///
/// ACCESS GATE (round-2 follow-up, §11 build notes' own "still gate on
/// suntech-admin OR that org's admin — switch to the StudioAssignment check"
/// item): now <c>suntech-admin</c> (today's platform-wide cross-org role,
/// §1.3) OR the target org's OWN admin reading their own org OR an
/// implementation user currently SWITCHED into exactly this org via an
/// active <c>StudioAssignment</c>. That third case needs no
/// extra database read here: a switched implementation-user session is a
/// <c>studio_kind=impl</c> token whose <c>org_id</c> IS the acting org, and
/// <c>OrganizationPermissionMiddleware.ResolveActingOrgAsync</c> has ALREADY
/// re-verified the underlying grant fresh against the database for every
/// such request before it ever reaches a controller (never cached — see that
/// method's own comment) — so <c>User.OrgId() == orgId</c> on an <c>impl</c>
/// session already IS "an active grant for exactly this org", the same way a
/// non-studio request's <c>User.OrgId()</c> already implies "this profile's
/// current org" without a second lookup here.
///
/// NOT a fourth case: a <c>studio_kind=sandbox</c> session (a production
/// admin switched into their OWN sandbox). <see cref="JwtService.CreateStudioToken"/>
/// stamps <c>role=admin</c> cosmetically on EVERY studio-scoped token
/// regardless of kind, so <c>User.IsOrgAdmin()</c> alone cannot tell a real
/// org admin's own unscoped session apart from a sandbox session acting in a
/// different org — <c>User.StudioKind() is null</c> is what actually narrows
/// the "org admin" branch to a genuine, un-switched session; sandbox access
/// to a customer's checklist was never one of the three cases the brief
/// names, so it stays refused.
/// </summary>
[ApiController]
[Route("studio")]
[Authorize]
public class StudioChecklistController : ControllerBase
{
    private readonly StudioChecklistExperience _checklist;
    public StudioChecklistController(StudioChecklistExperience checklist) => _checklist = checklist;

    private bool MayAccess(Guid orgId) =>
        User.IsSuntechAdmin()
        || (User.StudioKind() is null && User.IsOrgAdmin() && User.OrgId() == orgId)
        || (User.StudioKind() == StudioSessionKind.ImplementationUser && User.OrgId() == orgId);

    [HttpGet("orgs/{orgId:guid}/checklist")]
    public async Task<IActionResult> GetChecklist(Guid orgId, CancellationToken ct)
    {
        if (!MayAccess(orgId))
            return StatusCode(403, new { error = "You do not have access to this organization's checklist." });

        return Ok(await _checklist.GetChecklistAsync(orgId, ct));
    }

    [HttpPost("orgs/{orgId:guid}/checklist")]
    public async Task<IActionResult> CreateItem(Guid orgId, [FromBody] StudioChecklistItemInputDto input, CancellationToken ct)
    {
        if (!MayAccess(orgId))
            return StatusCode(403, new { error = "You do not have access to this organization's checklist." });

        var created = await _checklist.CreateItemAsync(orgId, User.UserId(), input, ct);
        if (created is null) return BadRequest(new { error = "A checklist item needs a title." });
        return Ok(created);
    }

    [HttpPost("orgs/{orgId:guid}/checklist/{itemId:guid}/check")]
    public async Task<IActionResult> Check(Guid orgId, Guid itemId, CancellationToken ct)
    {
        if (!MayAccess(orgId))
            return StatusCode(403, new { error = "You do not have access to this organization's checklist." });

        var ok = await _checklist.SetCheckedAsync(orgId, itemId, true, User.UserId(), ct);
        return ok ? NoContent() : NotFound();
    }

    [HttpPost("orgs/{orgId:guid}/checklist/{itemId:guid}/uncheck")]
    public async Task<IActionResult> Uncheck(Guid orgId, Guid itemId, CancellationToken ct)
    {
        if (!MayAccess(orgId))
            return StatusCode(403, new { error = "You do not have access to this organization's checklist." });

        var ok = await _checklist.SetCheckedAsync(orgId, itemId, false, User.UserId(), ct);
        return ok ? NoContent() : NotFound();
    }

    [HttpDelete("orgs/{orgId:guid}/checklist/{itemId:guid}")]
    public async Task<IActionResult> DeleteItem(Guid orgId, Guid itemId, CancellationToken ct)
    {
        if (!MayAccess(orgId))
            return StatusCode(403, new { error = "You do not have access to this organization's checklist." });

        var ok = await _checklist.DeleteItemAsync(orgId, itemId, ct);
        return ok ? NoContent() : NotFound();
    }
}

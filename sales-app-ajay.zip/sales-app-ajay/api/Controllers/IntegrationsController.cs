using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Integrations;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// The integrations directory (`Desktop - Integrations.dc.html`, frame 1) —
/// the nine connectors in <see cref="ConnectorRegistry"/>, each rendered from
/// its declared credential fields, never a bespoke per-vendor screen.
///
/// HONESTY ABOUT WHAT THIS DOES: no connector has outbound behaviour in this
/// slice (numbers-audit-decisions.md §36/§37) — no sync worker reads a saved
/// credential and does anything with a vendor. Saving credentials here only
/// proves they round-trip through <see cref="ConnectorConnectionService"/>.
/// So a connector's status is NEVER "Connected" — only "Not configured" or
/// "Configured" (`ConnectorConnectionService.Status`), and every DTO below
/// carries a fixed, honest caption for the UI to show next to that state
/// rather than letting the client invent one. A green "Connected" badge for a
/// connector nothing runs would be the exact false-assurance shape §36 warns
/// about — a form that stores a secret no code path reads is worse than no
/// form, because it looks configured.
///
/// API-led migration (step 8): this controller now does routing, the
/// `settings.manage` permission check, model binding and status selection
/// only. The directory reads, the credential round-trip and the DTO shaping
/// live in <see cref="IntegrationsExperience"/> / ProcessApi / SystemApi.
/// </summary>
[ApiController]
[Route("integrations")]
[Authorize]
public class IntegrationsController : ControllerBase
{
    private readonly IntegrationsExperience _integrations;

    public IntegrationsController(IntegrationsExperience integrations)
    {
        _integrations = integrations;
    }

    private bool CanManage() => User.HasPermission(OrganizationPermissions.ManageSettings);

    // GET /integrations — the directory list, all nine, in registry order.
    [HttpGet]
    public async Task<IActionResult> List()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view integrations." });
        return Ok(await _integrations.ListAsync());
    }

    // GET /integrations/{key} — one connector's form: field defs + which are currently filled.
    [HttpGet("{key}")]
    public async Task<IActionResult> Detail(string key)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view integrations." });
        var detail = await _integrations.DetailAsync(key);
        if (detail is null) return NotFound(new { error = "Unknown connector." });
        return Ok(detail);
    }

    // PUT /integrations/{key}/credentials — save (merge onto whatever is already stored).
    [HttpPut("{key}/credentials")]
    public async Task<IActionResult> SaveCredentials(string key, [FromBody] SaveConnectorCredentialsInput input)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot configure integrations." });
        if (!ConnectorRegistry.IsKnown(key)) return NotFound(new { error = "Unknown connector." });
        try
        {
            var detail = await _integrations.SaveCredentialsAsync(key, User.UserId(), input.Values ?? new Dictionary<string, string>());
            return Ok(detail);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    // POST /integrations/{key}/disconnect — clears stored credentials.
    [HttpPost("{key}/disconnect")]
    public async Task<IActionResult> Disconnect(string key)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot configure integrations." });
        if (!ConnectorRegistry.IsKnown(key)) return NotFound(new { error = "Unknown connector." });
        try
        {
            var detail = await _integrations.DisconnectAsync(key);
            return Ok(detail);
        }
        catch (ArgumentException ex)
        {
            // Same refusal shape as a rejected save (Microsoft 365 while a feature is on).
            return BadRequest(new { error = ex.Message });
        }
    }
}

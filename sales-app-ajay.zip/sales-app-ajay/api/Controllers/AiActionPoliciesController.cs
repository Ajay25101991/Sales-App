using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.AiPlatform;
using SalesApi.ProcessLayer.AiPlatform;
using SalesApi.Services;

namespace SalesApi.Controllers;

// The E4.8 action-risk-policy table (design doc to-do/e4-ai-platform-design.md
// §8, slice 8). Admin-only both ways: unlike automation-limits/task-snooze-options
// (GET open to any signed-in user because a rep-facing screen needs them),
// this table backs ONLY the "Admin, AI actions" screen
// (epics-ai-native-crm.md:272) — no rep-facing surface reads it in this slice,
// so there is no reason to expose an org's AI autonomy configuration beyond
// whoever can already change it.
//
// What is left here, deliberately: routing, [Authorize], the inline
// ManageSettings check, model binding, and choosing the HTTP status for a
// Refusal — same split MessageTemplatesController's header documents.
[ApiController]
[Route("ai-action-policies")]
[Authorize]
public class AiActionPoliciesController : ControllerBase
{
    private readonly AiActionPolicyExperience _policies;
    public AiActionPoliciesController(AiActionPolicyExperience policies) => _policies = policies;

    private static IActionResult FromRefusal(AiActionPolicyProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : new BadRequestObjectResult(new { error = refusal.Reason });

    [HttpGet]
    public async Task<IActionResult> List()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot view AI action settings." });
        return Ok(await _policies.ListAsync());
    }

    [HttpPut("{actionType}")]
    public async Task<IActionResult> SetAutonomy(string actionType, [FromBody] AiActionPolicyInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot change AI action settings." });
        var outcome = await _policies.SetAutonomyAsync(actionType, input, User.UserId());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Policy);
    }
}

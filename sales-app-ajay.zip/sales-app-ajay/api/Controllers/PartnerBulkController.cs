using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.ChannelPartners;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Channel partners - the bulk partner upload and retrospective terms (to-do/partner-management-design.md section 11; owner decisions 2026-10-20). A third controller beside
/// <see cref="ChannelPartnersController"/> on the same <c>channel-partners/*</c> routes, so this work never edits the Phase 1 file.
///
/// Routes, checks permission, picks a status code; it touches no _db. Every route needs partners.manage. Each import is a preview then a commit with the SAME body (the lead import's
/// shape: the CSV and the column mapping travel with both). Underneath, the sensitive category <c>partner_commercials</c> decides the back-pay figures: a preview needs a raw read,
/// attaching a plan needs Full (Process says so; this controller never masks).
/// </summary>
[ApiController]
[Route("")]
[Authorize]
public class PartnerBulkController : ControllerBase
{
    private readonly PartnerBulkExperience _bulk;
    private readonly CallerContext _caller;

    public PartnerBulkController(PartnerBulkExperience bulk, CallerContext caller)
    {
        _bulk = bulk;
        _caller = caller;
    }

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManagePartners);
    private ObjectResult No(string what) => StatusCode(403, new { error = $"Your role cannot {what}." });
    private IActionResult Respond<T>(CpResult<T> r, int okStatus = 200) => CpControllerExtensions.Respond(this, r, okStatus);

    private async Task<PartnerImportActor> ActorAsync() => new(
        User.UserId(), User.OrgId(), await _caller.DisplayNameAsync(User), User.IsManager(), await _caller.VisibilityAsync(User), User.Role(),
        User.HasPermission(OrganizationPermissions.TagCreate), User.Sensitive());

    // ---- the partners file (Partner, POC(s), Assigned Manager) ----

    [HttpPost("channel-partners/import/partners/preview")]
    public async Task<IActionResult> PartnersPreview([FromBody] PartnerFileInput input, CancellationToken ct)
    {
        if (!CanManage) return No("import partners");
        return Respond(await _bulk.PartnersPreviewAsync(await _caller.ForAsync(User), await ActorAsync(), input, ct));
    }

    [HttpPost("channel-partners/import/partners/commit")]
    public async Task<IActionResult> PartnersCommit([FromBody] PartnerFileInput input, CancellationToken ct)
    {
        if (!CanManage) return No("import partners");
        return Respond(await _bulk.PartnersCommitAsync(await _caller.ForAsync(User), await ActorAsync(), input, ct));
    }

    // ---- the client sheet (the partner is its Lead Channel) ----

    [HttpPost("channel-partners/import/clients/preview")]
    public async Task<IActionResult> ClientsPreview([FromBody] ClientSheetInput input, CancellationToken ct)
    {
        if (!CanManage) return No("link partners to clients");
        return Respond(await _bulk.ClientsPreviewAsync(await _caller.ForAsync(User), await ActorAsync(), input, ct));
    }

    [HttpPost("channel-partners/import/clients/commit")]
    public async Task<IActionResult> ClientsCommit([FromBody] ClientSheetInput input, CancellationToken ct)
    {
        if (!CanManage) return No("link partners to clients");
        return Respond(await _bulk.ClientsCommitAsync(await _caller.ForAsync(User), await ActorAsync(), input, ct));
    }

    // ---- partners to complete, and attaching a plan later ----

    /// <summary>Profiles with type "To be set", no plan or no agreement, and the deal partners that have no plan.</summary>
    [HttpGet("channel-partners/to-complete")]
    public async Task<IActionResult> ToComplete(CancellationToken ct)
    {
        if (!CanManage) return No("see the partners to complete");
        return Ok(await _bulk.ToCompleteAsync(await _caller.ForAsync(User), ct));
    }

    /// <summary>The back-pay preview for ONE deal partner: what the plan would pay on everything collected so far. Writes nothing.</summary>
    [HttpPost("channel-partners/deal-partners/{dealPartnerId:guid}/attach-plan/preview")]
    public async Task<IActionResult> PreviewOne(Guid dealPartnerId, [FromBody] AttachPlanInput input, CancellationToken ct)
    {
        if (!CanManage) return No("attach a plan");
        return Respond(await _bulk.BackPayPreviewAsync(await _caller.ForAsync(User), null, input with { DealPartnerIds = [dealPartnerId] }, ct));
    }

    /// <summary>Confirm: attach the plan to ONE deal partner and accrue what it has earned so far.</summary>
    [HttpPost("channel-partners/deal-partners/{dealPartnerId:guid}/attach-plan")]
    public async Task<IActionResult> AttachOne(Guid dealPartnerId, [FromBody] AttachPlanInput input, CancellationToken ct)
    {
        if (!CanManage) return No("attach a plan");
        return Respond(await _bulk.AttachPlanAsync(await _caller.ForAsync(User), null, input with { DealPartnerIds = [dealPartnerId] }, ct));
    }

    /// <summary>The back-pay preview for ALL of a partner's planless deal partners (or just the ids sent).</summary>
    [HttpPost("channel-partners/{accountId:guid}/attach-plan/preview")]
    public async Task<IActionResult> PreviewAll(Guid accountId, [FromBody] AttachPlanInput input, CancellationToken ct)
    {
        if (!CanManage) return No("attach a plan");
        return Respond(await _bulk.BackPayPreviewAsync(await _caller.ForAsync(User), accountId, input, ct));
    }

    [HttpPost("channel-partners/{accountId:guid}/attach-plan")]
    public async Task<IActionResult> AttachAll(Guid accountId, [FromBody] AttachPlanInput input, CancellationToken ct)
    {
        if (!CanManage) return No("attach a plan");
        return Respond(await _bulk.AttachPlanAsync(await _caller.ForAsync(User), accountId, input, ct));
    }
}

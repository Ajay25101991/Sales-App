using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.ExperienceLayer.Accounts;
using SalesApi.ExperienceLayer.Loyalty;
using SalesApi.ProcessLayer.Accounts;

namespace SalesApi.Controllers;

// MIGRATED (API-led migration, step 8) — except the loyalty slice, migrated
// separately (step 5) and untouched here. Business rules now live in
// SalesApi.ProcessApi/Accounts/AccountProcess.cs, reached through
// SalesApi.ExperienceApi/Accounts/AccountsExperience.cs. What is left here,
// deliberately: routing, [Authorize]/[RequirePermission], model binding,
// resolving the caller's RecordAccessContext and CanSeeFullAccountFinancials
// (both request-shaped facts about the CALLER, not a rule about an account),
// and choosing the HTTP status for a Refusal.
[ApiController]
[Route("accounts")]
[Authorize]
[RequireSensitiveAccess(SensitiveCategories.ContactDetails)]
public class AccountsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly AccountsExperience _accounts;
    // The loyalty vertical is MIGRATED (API-led step 5) separately: these three
    // endpoints go through their own Experience layer and never touch _db for
    // loyalty. AccountsExperience/AccountProcess above is the REST of this
    // controller's migration (step 8) — a controller taking two Experience
    // classes, one per already-carved-out sub-vertical, is what a strangler
    // looks like mid-run, and it is deliberate.
    private readonly AccountLoyaltyExperience _loyalty;
    // Optional, defaulted: see LeadsController's identical field for why —
    // DI always supplies a real one, the ~8 test files that build this
    // controller by hand never do and shouldn't have to.
    private readonly ILogger<AccountsController>? _logger;
    public AccountsController(
        CallerContext caller, AccountsExperience accounts, AccountLoyaltyExperience loyalty,
        ILogger<AccountsController>? logger = null)
    {
        _caller = caller;
        _accounts = accounts;
        _loyalty = loyalty;
        _logger = logger;
    }

    // Team scoping. Same predicate as leads (Services/TeamScoping.cs) — an account
    // carries an owner and a team, which is all that predicate ever reads. A
    // manager's reach is their teams', not the org's; an org admin's is everything.
    // Memoized per request (a controller instance is per-request): the context reads
    // the org's lead_visibility row, and several endpoints below need it more than
    // once. Without this, scoping a list would quietly triple that endpoint's reads.
    private RecordAccessContext? _access;
    private async Task<RecordAccessContext> AccessAsync() =>
        _access ??= await _caller.ForAsync(User);
    // Still used by the (unmigrated) loyalty endpoints below — CanManage's
    // callers all moved into AccountProcess with the rest of the controller.
    private static bool CanView(Account a, in RecordAccessContext ctx) =>
        RecordAccess.CanView(ctx, a.OwnerId, a.TeamId);

    /// <summary>
    /// Whether this caller may see an account's FULL receivables position —
    /// every invoice raised against it, including ones they could not open in
    /// /invoices or /collections.
    ///
    /// Without <c>account_financials.view</c>, AccountProcess applies the same
    /// <c>WhereViewable</c> predicate every other invoice read in the API uses
    /// (CollectionsController.ComputeAsync, InvoicesController.ScopedAsync),
    /// so the account's billed/outstanding/overdue tiles agree with the
    /// collections page for that account instead of quietly exceeding it.
    ///
    /// A request-shaped fact about the CALLER (their permission claim), so it
    /// stays here and is threaded through every Process/Experience call that
    /// needs it — the failure mode of computing it twice, or differently, is
    /// two figures for one account.
    /// </summary>
    private bool CanSeeFullAccountFinancials =>
        User.HasPermission(OrganizationPermissions.ViewAccountFinancials);

    /// <summary>
    /// Whether this caller may see OPEN-DEAL money at all on an account —
    /// open value, an account's deal rows' estimated values, sort/filter by
    /// open value (account-money-masking, owner decision 2026-09-27). The
    /// SAME permission LeadsController already gates Lead.EstimatedValue on;
    /// an account tile summing lead estimates must not show a figure the
    /// underlying leads already hide one screen over.
    /// </summary>
    private bool CanSeeAccountLeadValues =>
        User.HasPermission(OrganizationPermissions.ViewLeadValues);

    /// <summary>
    /// The key two company names are considered the same by. Kept here as a
    /// thin static forward — LeadsController (unmigrated) calls
    /// <c>AccountsController.CompanyKey</c> directly rather than through DI,
    /// same as before this migration. The rule itself lives in
    /// <see cref="AccountProcess.CompanyKey"/>, which forwards to
    /// <c>AccountLinkService.CompanyKey</c>.
    /// </summary>
    public static string CompanyKey(string? name) => AccountProcess.CompanyKey(name);

    private static IActionResult FromRefusal(AccountProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 403 }
        // Accounts rework: a 409 - the new owner is outside the account's team (carries both team sets so the client can offer
        // a retry), or a delete blocked by issued invoices (carries the blocking deals).
        : refusal.Conflict ? new ConflictObjectResult(ConflictBody(refusal))
        : refusal.Code == SensitiveWriteGuard.Code
            ? new BadRequestObjectResult(new { error = refusal.Reason, code = refusal.Code, fields = refusal.Fields })
        : new BadRequestObjectResult(refusal.Code is null
            ? new { error = refusal.Reason }
            : new { error = refusal.Reason, code = refusal.Code, field = refusal.Field });

    // The 409 bodies: owner outside the account's team (both team sets, so the client can offer a retry) or a delete blocked by
    // issued invoices (the blocking deals).
    private static Dictionary<string, object?> ConflictBody(AccountProcess.Refusal refusal)
    {
        var body = new Dictionary<string, object?> { ["error"] = refusal.Reason, ["code"] = refusal.Code };
        if (refusal.TeamId is not null) body["account_team_id"] = refusal.TeamId;
        if (refusal.OwnerTeamIds is not null) body["owner_team_ids"] = refusal.OwnerTeamIds;
        if (refusal.BlockedDeals is not null) body["blocked_deals"] = refusal.BlockedDeals;
        return body;
    }

    private static IActionResult FromTableRefusal(SalesApi.Services.TableQuery.TableQueryRefusedException e) =>
        new BadRequestObjectResult(new { error = e.Message, code = "invalid_query", field = e.Field });

    // Same two calling conventions as LeadsController.List (see its comment):
    // `paged=true` + optional `cursor` -> keyset pagination, { items,
    // next_cursor } envelope. Everything else -> the original Skip/Take, bare
    // array, full set when `limit` is omitted — unchanged for callers that
    // haven't moved to `paged` (e.g. the lead form's account autocomplete).
    //
    // `sort`: name (default) | open_value | won_value — see AccountKeyset's
    // doc comment for how the latter two are computed and paged. Combined
    // with `search`: exactly like LeadsController.List, a fuzzy search keeps
    // its two-tier relevance ordering (exact matches, then fuzzy matches by
    // similarity) and `sort` is applied as a TIEBREAK within each tier —
    // never overridden by relevance, but never allowed to outrank an exact
    // match either. That fuzzy branch also still pages by offset, not
    // keyset, same limitation (and same reason) as before this change:
    // relevance isn't a stored column.
    // Same convention as LeadsController.ListQueryParams — the union of every
    // param `useAccounts`/`useAccountsInfinite`
    // (packages/core/src/hooks/use-accounts.ts) send.
    private static readonly string[] ListQueryParams =
    [
        "search", "limit", "offset", "similarity", "owner", "industry",
        "hasOpenValue", "sort", "paged", "cursor", "filters", "sorts",
    ];

    [HttpGet]
    public async Task<IActionResult> List(
        [FromQuery] string? search, [FromQuery] int? limit = null, [FromQuery] int? offset = null,
        [FromQuery] double? similarity = null,
        [FromQuery] string? owner = null, [FromQuery] string? industry = null,
        [FromQuery] bool? hasOpenValue = null, [FromQuery] string? sort = null,
        [FromQuery] bool paged = false, [FromQuery] string? cursor = null,
        [FromQuery] string? filters = null, [FromQuery] string? sorts = null)
    {
        // Reported, never refused — see QueryParamValidation's class doc.
        QueryParamValidation.ReportUnknownKeys(
            HttpContext, _logger, "GET /accounts", QueryParamValidation.UnknownKeys(Request, ListQueryParams));

        var outcome = await _accounts.ListAsync(await AccessAsync(), CanSeeFullAccountFinancials, CanSeeAccountLeadValues,
            new AccountProcess.ListParams(search, limit, offset, similarity, owner, industry, hasOpenValue, sort, paged, cursor, filters, sorts),
            User.Role());
        if (outcome.Refusal is not null) return FromRefusal(outcome.Refusal);
        return Ok(paged ? new PagedResult<AccountDto>(outcome.Items!, outcome.NextCursor) : outcome.Items);
    }

    // GET /accounts/count — total rows for the identical filter set List
    // uses, so a count can never disagree with the list it describes.
    [HttpGet("count")]
    public async Task<IActionResult> Count(
        [FromQuery] string? search, [FromQuery] double? similarity = null,
        [FromQuery] string? owner = null, [FromQuery] string? industry = null,
        [FromQuery] bool? hasOpenValue = null, [FromQuery] string? filters = null)
    {
        try
        {
            var count = await _accounts.CountAsync(await AccessAsync(), search, similarity, owner, industry, hasOpenValue,
                CanSeeAccountLeadValues, default, filters, CanSeeFullAccountFinancials, User.Role());
            return Ok(new { count });
        }
        catch (SalesApi.Services.TableQuery.TableQueryRefusedException e) { return FromTableRefusal(e); }
    }

    // GET /accounts/columns — the table's column catalogue for this caller (open value and won value only for
    // callers who may see them; custom fields only the ones their role may see).
    [HttpGet("columns")]
    public async Task<IActionResult> Columns() =>
        Ok(await _accounts.ColumnsAsync(await AccessAsync(), CanSeeFullAccountFinancials, CanSeeAccountLeadValues, User.Role()));

    // GET /accounts/facets — how many accounts each filter option would match.
    [HttpGet("facets")]
    public async Task<IActionResult> Facets(
        [FromQuery] string? search, [FromQuery] double? similarity = null,
        [FromQuery] string? owner = null, [FromQuery] string? industry = null,
        [FromQuery] bool? hasOpenValue = null, [FromQuery] string? filters = null)
    {
        try
        {
            return Ok(await _accounts.FacetsAsync(await AccessAsync(), search, similarity, owner, industry, hasOpenValue,
                CanSeeAccountLeadValues, default, filters, CanSeeFullAccountFinancials, User.Role()));
        }
        catch (SalesApi.Services.TableQuery.TableQueryRefusedException e) { return FromTableRefusal(e); }
    }

    // GET /accounts/export — the caller's visible accounts as CSV. Mirrors
    // GET /leads/export exactly: same streaming approach, same owner/manager
    // scoping, and — like leads export — takes no filter query params: this
    // is every account the CALLER can see, not the currently-filtered/sorted
    // view.
    [HttpGet("export")]
    [RequirePermission(OrganizationPermissions.CreateExports)]
    public async Task<IActionResult> Export([FromQuery] string? filters = null, [FromQuery] string? sorts = null, [FromQuery] string? ids = null)
    {
        try
        {
            // Accounts rework (decision 13): "Export selected" - a comma-separated list of account ids narrows the file to those rows.
            List<Guid>? selected = string.IsNullOrWhiteSpace(ids) ? null
                : ids.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                    .Select(s => Guid.TryParse(s, out var g) ? (Guid?)g : null).Where(g => g is not null).Select(g => g!.Value).Distinct().ToList();
            var csv = await _accounts.ExportCsvAsync(await AccessAsync(), CanSeeFullAccountFinancials, CanSeeAccountLeadValues,
                default, filters, sorts, User.Role(), selected);
            return Content(csv, "text/csv; charset=utf-8");
        }
        catch (SalesApi.Services.TableQuery.TableQueryRefusedException e) { return FromTableRefusal(e); }
    }

    // GET /accounts/match?company=&email= — suggest existing accounts that look
    // like the same company (name similarity) or share the email domain. Scoped
    // rep=own / manager=all.
    [HttpGet("match")]
    public async Task<IActionResult> Match([FromQuery] string? company, [FromQuery] string? email) =>
        Ok(await _accounts.MatchAsync(await AccessAsync(), CanSeeFullAccountFinancials, company, email, CanSeeAccountLeadValues));

    // POST /accounts/match-bulk — for the CSV import review step.
    //
    // Answers "of these 40 company names, which already exist?" in one call, so the
    // import screen can state the consequence — 12 will link, 28 would be created —
    // BEFORE anything is written. Read-only.
    [HttpPost("match-bulk")]
    public async Task<IActionResult> MatchBulk([FromBody] List<string>? companies) =>
        Ok(await _accounts.MatchBulkAsync(await AccessAsync(), companies));

    // S9c — the one-off "link my existing unlinked leads to accounts" admin
    // tool. `manage-settings`, not the class-level `view-contact-details`: this
    // writes AccountId on leads org-wide, which is an admin action, not a rep
    // one. GET previews (writes nothing); POST applies the SAME matching.
    [HttpGet("link-unlinked-leads/preview")]
    [RequirePermission(OrganizationPermissions.ManageSettings)]
    public async Task<IActionResult> PreviewLinkUnlinkedLeads() =>
        Ok(await _accounts.PreviewLinkUnlinkedLeadsAsync(await AccessAsync()));

    [HttpPost("link-unlinked-leads")]
    [RequirePermission(OrganizationPermissions.ManageSettings)]
    public async Task<IActionResult> LinkUnlinkedLeads() =>
        Ok(await _accounts.LinkUnlinkedLeadsAsync(await AccessAsync()));

    // GET /accounts/{id} — account + contacts + linked leads (+ invoices, AMCs,
    // derived tags — the account-360 composite).
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var outcome = await _accounts.GetAsync(await AccessAsync(), CanSeeFullAccountFinancials, id, User.Role(), CanSeeAccountLeadValues);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Detail);
    }

    // GET /accounts/{id}/history — field-change audit (design doc
    // to-do/e1-event-backbone-design.md §6/§8), newest first, cursor-paged.
    // Record access IS the account's own: a caller who cannot see the account
    // gets the SAME 404 as an account that does not exist, never a 403 that
    // would confirm the id is real.
    [HttpGet("{id:guid}/history")]
    public async Task<IActionResult> History(Guid id, [FromQuery] string? cursor, [FromQuery] int? limit)
    {
        // canSeeContactDetails is always true here: every endpoint on this
        // controller already requires ViewContactDetails (see the class-level
        // [RequirePermission] above), so a caller who reaches this line holds it.
        var (refusal, page) = await _accounts.HistoryAsync(
            await AccessAsync(), User.HasPermission(OrganizationPermissions.ViewLeadValues), canSeeContactDetails: true, id, cursor, limit);
        return refusal is not null ? NotFound(new { error = "Account not found" }) : Ok(page);
    }

    // GET /accounts/{id}/timeline — the unified record timeline (design doc
    // to-do/e1-event-backbone-design.md §7/§8/§9), newest first, cursor-paged.
    // `scope` is "all" (default — rolls up every child lead's items, owner
    // decision 2026-09-26) or "account" (this account row's own items only).
    // Same 404-not-403 record access as GET /accounts/{id}/history.
    [HttpGet("{id:guid}/timeline")]
    public async Task<IActionResult> Timeline(
        Guid id, [FromQuery] string? cursor, [FromQuery] int? limit, [FromQuery] string? kinds, [FromQuery] string? scope)
    {
        var (refusal, page) = await _accounts.TimelineAsync(
            await AccessAsync(), User.HasPermission(OrganizationPermissions.ViewLeadValues), canSeeContactDetails: true,
            User.HasPermission(OrganizationPermissions.ViewFinancials), id, cursor, limit, kinds, scope);
        return refusal is not null ? NotFound(new { error = "Account not found" }) : Ok(page);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] AccountInput input)
    {
        var outcome = await _accounts.CreateAsync(User.UserId(), User.OrgId(), input, User.Role(), CanSeeAccountLeadValues, CanSeeFullAccountFinancials,
            canCreateTags: User.HasPermission(OrganizationPermissions.TagCreate), sensitive: User.Sensitive(), access: await AccessAsync());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Account);
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] AccountInput input)
    {
        var outcome = await _accounts.UpdateAsync(await AccessAsync(), id, input, User.Role(), CanSeeAccountLeadValues, CanSeeFullAccountFinancials,
            canCreateTags: User.HasPermission(OrganizationPermissions.TagCreate));
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Account);
    }

    // DELETE /accounts/{id}[?delete_deals=true] - contacts go, leads and invoices are unlinked (today's effect). With
    // delete_deals each deal also goes through the existing lead delete; if any deal has issued invoices the WHOLE delete is
    // refused (409 invoices_issued, listing the blocking deals). 204 normally; 200 { deals_deleted, deal_skips } with delete_deals.
    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id, [FromQuery(Name = "delete_deals")] bool deleteDeals = false)
    {
        var outcome = await _accounts.DeleteAsync(await AccessAsync(), id, deleteDeals);
        if (outcome.Refusal is not null) return FromRefusal(outcome.Refusal);
        return deleteDeals ? Ok(new { deals_deleted = outcome.DealsDeleted, deal_skips = outcome.DealSkips ?? [] }) : NoContent();
    }

    // GET /accounts/{id}/delete-preview - what the delete confirm states: contacts deleted, leads and invoices unlinked, and the
    // deals split into deletable / blocked (issued invoices). Same permission as the delete.
    [HttpGet("{id:guid}/delete-preview")]
    public async Task<IActionResult> DeletePreview(Guid id)
    {
        var (refusal, preview) = await _accounts.DeletePreviewAsync(await AccessAsync(), id);
        return refusal is not null ? FromRefusal(refusal) : Ok(preview);
    }

    // GET/POST /accounts/{id}/activities - the account's history list and the composer's write (decision 1). The write mirrors
    // POST /leads/{id}/activities; lead_id optionally files it under one of the account's deals.
    [HttpGet("{id:guid}/activities")]
    public async Task<IActionResult> Activities(Guid id)
    {
        var (refusal, dto) = await _accounts.ActivitiesAsync(await AccessAsync(), id);
        return refusal is not null ? FromRefusal(refusal) : Ok(dto);
    }

    [HttpPost("{id:guid}/activities")]
    public async Task<IActionResult> AddActivity(Guid id, [FromBody] AccountActivityInput input)
    {
        var (refusal, dto) = await _accounts.AddActivityAsync(await AccessAsync(), User.UserId(), id, input);
        return refusal is not null ? FromRefusal(refusal) : StatusCode(201, dto);
    }

    private async Task<SalesApi.ProcessLayer.Accounts.AccountProcess.AccountActor> ActorAsync() => new(
        User.UserId(), User.OrgId(), await _caller.DisplayNameAsync(User), User.IsManager(), await _caller.VisibilityAsync(User),
        User.HasPermission(OrganizationPermissions.TagCreate), User.Role());

    // POST /accounts/{id}/assign - change the owner (decision 5), copying POST /leads/{id}/assign: managers/admins only, the
    // caller must manage the account, the new owner must be in the account's team (409 owner_outside_team). move_open_leads
    // also moves each open deal through the lead assign path.
    [HttpPost("{id:guid}/assign")]
    public async Task<IActionResult> Assign(Guid id, [FromBody] AccountAssignInput input)
    {
        var outcome = await _accounts.AssignAsync(await AccessAsync(), await ActorAsync(), id, input, CanSeeAccountLeadValues, CanSeeFullAccountFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Result);
    }

    // POST /accounts/bulk - assign | tag_add | tag_remove | set_status | delete over ticked rows (decision 13), mirroring POST /leads/bulk:
    // each account is checked on its own and a skipped one is reported with its reason.
    [HttpPost("bulk")]
    public async Task<IActionResult> Bulk([FromBody] AccountBulkInput input)
    {
        try
        {
            var (refusal, result) = await _accounts.BulkAsync(await AccessAsync(), await ActorAsync(), input, default,
                CanSeeAccountLeadValues, CanSeeFullAccountFinancials);
            return refusal is not null ? FromRefusal(refusal) : Ok(result);
        }
        catch (SalesApi.Services.TableQuery.TableQueryRefusedException e) { return FromTableRefusal(e); }
        catch (SalesApi.Services.BulkMatchTooLargeException e)
        {
            return BadRequest(new { error = e.Message, code = "match_too_large", count = e.Count, limit = e.Limit });
        }
    }

    // POST /accounts/bulk/ids - what "select all N matching" resolves to (same scoping, same bulk_match_limit as POST /accounts/bulk with
    // `match`), so the client can run a big action in small batches with progress. Nothing is changed.
    [HttpPost("bulk/ids")]
    public async Task<IActionResult> BulkIds([FromBody] AccountMatchInput match)
    {
        try
        {
            return Ok(new BulkIdsResult(await _accounts.MatchingIdsAsync(await AccessAsync(), match, CanSeeAccountLeadValues, CanSeeFullAccountFinancials, User.Role())));
        }
        catch (SalesApi.Services.TableQuery.TableQueryRefusedException e) { return FromTableRefusal(e); }
        catch (SalesApi.Services.BulkMatchTooLargeException e)
        {
            return BadRequest(new { error = e.Message, code = "match_too_large", count = e.Count, limit = e.Limit });
        }
    }

    // --- contacts ---

    [HttpGet("{id:guid}/contacts")]
    public async Task<IActionResult> Contacts(Guid id)
    {
        var outcome = await _accounts.ContactsAsync(await AccessAsync(), id, User.Role());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Contacts);
    }

    // GET /accounts/{id}/loyalty — the P0-2 balance + history read, the only UI
    // this backlog item needs to be "usable... provable at the API/data layer
    // alone" (loyalty-module-backlog.md P0-2's own proof bar). Gated on
    // loyalty.view_status (owner decision 5a.6: visibility is an ORG ROLE
    // PERMISSION, not a setting) IN ADDITION to the class-level
    // ViewContactDetails every account read already requires — every role that
    // ships loyalty.view_status also ships ViewContactDetails (see
    // OrganizationRoleService.Defaults), so this never narrows who could already
    // see the account.
    [HttpGet("{id:guid}/loyalty")]
    [RequirePermission(OrganizationPermissions.ViewLoyaltyStatus)]
    public async Task<IActionResult> Loyalty(Guid id)
    {
        if (await _accounts.CheckViewAsync(await AccessAsync(), id) is { } denied) return FromRefusal(denied);

        // Everything below the permission check is the Experience layer's now.
        // This endpoint's remaining job is exactly what an endpoint should do:
        // authenticate, authorise, and hand off.
        return Ok(await _loyalty.PanelAsync(id));
    }

    // GET/PUT /accounts/{id}/loyalty-rule — this account's earn OVERRIDE (owner
    // decision 5a.2: "configurable per org, overridable per account").
    //
    // Reading is gated on loyalty.view_status like the balance beside it;
    // WRITING additionally needs settings.manage, because an override is
    // business configuration and the org-wide rule it overrides is already
    // behind that permission. Anything narrower would let someone who may not
    // change the org's rule change it for one customer, which is the same
    // decision with a smaller blast radius rather than a different one.
    [HttpGet("{id:guid}/loyalty-rule")]
    [RequirePermission(OrganizationPermissions.ViewLoyaltyStatus)]
    public async Task<IActionResult> GetLoyaltyRule(Guid id)
    {
        if (await _accounts.CheckViewAsync(await AccessAsync(), id) is { } denied) return FromRefusal(denied);

        return Ok(await _loyalty.RuleAsync(id));
    }

    [HttpPut("{id:guid}/loyalty-rule")]
    [RequirePermission(OrganizationPermissions.ViewLoyaltyStatus)]
    public async Task<IActionResult> SetLoyaltyRule(Guid id, [FromBody] LoyaltyAccountRuleInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change organization setup." });

        if (await _accounts.CheckViewAsync(await AccessAsync(), id) is { } denied) return FromRefusal(denied);

        // A null means "follow the org's rule for this source" and is always
        // legal; a present value must be in range. Same bound as the org rule —
        // one definition of a legal point value, not two.
        if (input.PointsInvoicePayment is int pi && !LoyaltyPolicyService.IsValidPoints(pi))
            return BadRequest(new { error = $"points must be between 0 and {LoyaltyPolicyService.MaxPointsPerEvent}" });
        if (input.PointsAmcRenewal is int pa && !LoyaltyPolicyService.IsValidPoints(pa))
            return BadRequest(new { error = $"points must be between 0 and {LoyaltyPolicyService.MaxPointsPerEvent}" });

        // The write itself, and the "an override that says nothing is not an
        // override" rule, both live below now. What stays here is the HTTP
        // contract: the 400s, and the permission that gates the write.
        return Ok(await _loyalty.SaveRuleAsync(
            id, input.PointsInvoicePayment, input.PointsAmcRenewal, input.Reason, User.UserId()));
    }

    [HttpPost("{id:guid}/contacts")]
    public async Task<IActionResult> AddContact(Guid id, [FromBody] ContactInput input)
    {
        var outcome = await _accounts.AddContactAsync(await AccessAsync(), id, input, User.Role());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Contact);
    }

    // --- E3.4: parent/subsidiary, related companies, external ids ---

    // PUT /accounts/{id}/parent — set or clear (null) the parent account.
    [HttpPut("{id:guid}/parent")]
    public async Task<IActionResult> SetParent(Guid id, [FromBody] AccountParentInput input)
    {
        var outcome = await _accounts.SetParentAsync(await AccessAsync(), id, input.ParentAccountId, User.UserId(), User.Role(), CanSeeAccountLeadValues, CanSeeFullAccountFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Account);
    }

    // POST /accounts/{id}/follow-parent - E14.1: take the parent's stored value again for the named inheriting fields (omit `fields` = every
    // field this account overrides). Same permission as editing the account. 400 no_parent / not_inherited.
    [HttpPost("{id:guid}/follow-parent")]
    public async Task<IActionResult> FollowParent(Guid id, [FromBody] AccountFollowParentInput? input)
    {
        var outcome = await _accounts.FollowParentAsync(await AccessAsync(), id, input?.Fields, User.Role(), CanSeeAccountLeadValues, CanSeeFullAccountFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Account);
    }

    // GET /accounts/{id}/tree — this account's own bounded-depth subtree.
    [HttpGet("{id:guid}/tree")]
    public async Task<IActionResult> Tree(Guid id)
    {
        var (refusal, tree) = await _accounts.ChildrenTreeAsync(await AccessAsync(), id);
        return refusal is not null ? FromRefusal(refusal) : Ok(tree);
    }

    [HttpGet("{id:guid}/relationships")]
    public async Task<IActionResult> Relationships(Guid id)
    {
        var (refusal, relationships) = await _accounts.RelationshipsAsync(await AccessAsync(), id);
        return refusal is not null ? FromRefusal(refusal) : Ok(relationships);
    }

    [HttpPost("{id:guid}/relationships")]
    public async Task<IActionResult> AddRelationship(Guid id, [FromBody] AccountRelationshipInput input)
    {
        var (refusal, relationship) = await _accounts.AddRelationshipAsync(await AccessAsync(), id, input, User.UserId());
        return refusal is not null ? FromRefusal(refusal) : StatusCode(201, relationship);
    }

    [HttpDelete("{id:guid}/relationships/{relationshipId:guid}")]
    public async Task<IActionResult> RemoveRelationship(Guid id, Guid relationshipId)
    {
        var refusal = await _accounts.RemoveRelationshipAsync(await AccessAsync(), id, relationshipId, User.UserId());
        return refusal is not null ? FromRefusal(refusal) : NoContent();
    }

    [HttpGet("{id:guid}/external-ids")]
    public async Task<IActionResult> ExternalIds(Guid id)
    {
        var (refusal, ids) = await _accounts.ExternalIdsAsync(await AccessAsync(), id);
        return refusal is not null ? FromRefusal(refusal) : Ok(ids);
    }

    [HttpPost("{id:guid}/external-ids")]
    public async Task<IActionResult> AddExternalId(Guid id, [FromBody] AccountExternalIdInput input)
    {
        var (refusal, externalId) = await _accounts.AddExternalIdAsync(await AccessAsync(), id, input);
        return refusal is not null ? FromRefusal(refusal) : StatusCode(201, externalId);
    }

    [HttpDelete("{id:guid}/external-ids/{externalIdId:guid}")]
    public async Task<IActionResult> RemoveExternalId(Guid id, Guid externalIdId)
    {
        var refusal = await _accounts.RemoveExternalIdAsync(await AccessAsync(), id, externalIdId);
        return refusal is not null ? FromRefusal(refusal) : NoContent();
    }
}

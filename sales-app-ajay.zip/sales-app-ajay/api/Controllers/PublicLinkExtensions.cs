using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>Absolute links built in a controller (invite and sign-up links): the one rule is <see cref="PublicBaseUrl.Absolute"/> - the
/// configured public address, falling back to the request's own scheme and host only when none is configured. Replaces the three
/// copies of <c>$"{Request.Scheme}://{Request.Host}..."</c>, which behind a proxy produced an internal host.</summary>
public static class PublicLinkExtensions
{
    public static string AbsoluteUrl(this Microsoft.AspNetCore.Mvc.ControllerBase controller, string path)
    {
        var request = controller.Request;
        var config = (IConfiguration?)request.HttpContext.RequestServices?.GetService(typeof(IConfiguration));
        return PublicBaseUrl.Absolute(config, $"{request.Scheme}://{request.Host}", path);
    }
}

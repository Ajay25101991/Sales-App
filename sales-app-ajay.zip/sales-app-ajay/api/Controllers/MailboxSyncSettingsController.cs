using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Mailbox;
using SalesApi.Services;

namespace SalesApi.Controllers;

// E6.1/E6.2 mailbox-sync org settings (design doc to-do/e6-capture-design.md
// §11.2/§11.3, brief item 1). Admin-only, same permission as the deal-risk
// thresholds — OrganizationPermissions.ManageSettings.
[ApiController]
[Authorize]
public class MailboxSyncSettingsController : ControllerBase
{
    private readonly MailboxSyncSettingsExperience _settings;
    public MailboxSyncSettingsController(MailboxSyncSettingsExperience settings) => _settings = settings;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);

    [HttpGet("admin/mailbox-settings")]
    public async Task<IActionResult> Get()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot view this setting." });
        return Ok(await _settings.GetAsync());
    }

    [HttpPut("admin/mailbox-settings")]
    public async Task<IActionResult> Save([FromBody] MailboxSyncSettingsInput input)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (dto, refusal) = await _settings.SaveAsync(input, User.UserId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }
}

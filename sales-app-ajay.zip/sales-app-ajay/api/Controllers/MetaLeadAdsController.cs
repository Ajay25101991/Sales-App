using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Meta;
using SalesApi.ProcessLayer.Meta;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Meta Lead Ads (Facebook / Instagram) - the admin surface: Facebook connect, Page selection, the one-time backfill, the form list
/// and the per-form mapping. The sibling of <c>LinkedInLeadSyncController</c>; routing, the `settings.manage` permission check and
/// status-code selection only - the rules live in ProcessApi.
///
/// The callback is [AllowAnonymous] for the same reason LinkedIn's is: it is a full-page browser redirect from Facebook with no
/// Authorization header, so the signed `state` parameter IS the identity check.
/// </summary>
[ApiController]
[Route("integrations/meta")]
[Authorize]
[RequirePlanFeature(PlanCatalogue.Features.MetaLeadAds)]
public class MetaLeadAdsController : ControllerBase
{
    private readonly MetaExperience _meta;
    public MetaLeadAdsController(MetaExperience meta) => _meta = meta;

    private bool CanManage() => User.HasPermission(OrganizationPermissions.ManageSettings);

    private const string IntegrationsRedirectPath = "/apps/desktop/integrations";

    // GET /integrations/meta/connect -> { authorize_url }
    [HttpGet("connect")]
    public async Task<IActionResult> Connect()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        var orgId = User.OrgId();
        if (orgId is null) return StatusCode(403, new { error = "No organization on this account." });

        var adminIdentity = User.FindFirstValue("email") ?? "An admin";
        var (refusal, result) = await _meta.BuildAuthorizeUrlAsync(orgId.Value, User.UserId(), adminIdentity);
        if (refusal is not null) return BadRequest(new { error = refusal.Message });
        return Ok(result);
    }

    // GET /integrations/meta/connect/callback?code=&state= - Facebook's redirect, no JWT. Redirects to the desktop integrations
    // page: ?meta=connected, or ?meta=error&reason=<code> (never raw Meta error text in a URL).
    [HttpGet("connect/callback")]
    [AllowAnonymous]
    public async Task<IActionResult> Callback([FromQuery] string? code, [FromQuery] string? state, [FromQuery] string? error)
    {
        if (!string.IsNullOrEmpty(error))
            return Redirect($"{IntegrationsRedirectPath}?meta=error&reason=denied");
        if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(state))
            return Redirect($"{IntegrationsRedirectPath}?meta=error&reason=missing_params");

        var (refusal, _) = await _meta.ExchangeCallbackAsync(code, state);
        if (refusal is not null)
            return Redirect($"{IntegrationsRedirectPath}?meta=error&reason={refusal.ReasonCode}");
        return Redirect($"{IntegrationsRedirectPath}?meta=connected");
    }

    // GET /integrations/meta/connection -> MetaConnectionDetailDto
    [HttpGet("connection")]
    public async Task<IActionResult> Connection()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view integrations." });
        var orgId = User.OrgId();
        if (orgId is null) return StatusCode(403, new { error = "No organization on this account." });
        return Ok(await _meta.GetConnectionDetailAsync(orgId.Value));
    }

    // DELETE /integrations/meta/connection - unsubscribe the Pages and drop the stored tokens; the saved app credentials and
    // the form mappings stay.
    [HttpDelete("connection")]
    public async Task<IActionResult> Disconnect()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        await _meta.DisconnectAsync();
        return Ok(new { disconnected = true });
    }

    // PUT /integrations/meta/pages { page_ids: [...] } -> { pages, backfill }
    [HttpPut("pages")]
    public async Task<IActionResult> SelectPages([FromBody] MetaSelectPagesInput input)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        var (result, refusal) = await _meta.SelectPagesAsync(input.PageIds ?? []);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(result);
    }

    // POST /integrations/meta/backfill { page_id? } -> MetaBackfillResultDto - the one-time import of what Meta still holds.
    [HttpPost("backfill")]
    public async Task<IActionResult> Backfill([FromBody] MetaBackfillInput? input)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        return Ok(await _meta.BackfillAsync(input?.PageId));
    }

    // GET /integrations/meta/forms -> MetaFormsResultDto (Meta's forms joined with the saved mapping; needs_mapping flag).
    [HttpGet("forms")]
    public async Task<IActionResult> Forms()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view integrations." });
        var orgId = User.OrgId();
        if (orgId is null) return StatusCode(403, new { error = "No organization on this account." });
        return Ok(await _meta.GetFormsAsync(orgId.Value));
    }

    [HttpGet("mapping")]
    public async Task<IActionResult> ListMappings()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        return Ok(await _meta.ListMappingsAsync());
    }

    [HttpGet("mapping/{formId}")]
    public async Task<IActionResult> GetMapping(string formId)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        var dto = await _meta.GetMappingAsync(formId);
        if (dto is null) return NotFound(new { error = "No mapping saved for that form yet." });
        return Ok(dto);
    }

    // PUT /integrations/meta/mapping - save (create or overwrite); saving takes the form off the "needs mapping" list.
    [HttpPut("mapping")]
    public async Task<IActionResult> SaveMapping([FromBody] MetaFormMappingInput input)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        var (dto, refusal) = await _meta.SaveMappingAsync(input, User.UserId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    [HttpDelete("mapping/{formId}")]
    public async Task<IActionResult> DeleteMapping(string formId)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        var ok = await _meta.DeleteMappingAsync(formId);
        if (!ok) return NotFound(new { error = "No mapping saved for that form." });
        return Ok(new { deleted = true });
    }
}

/// <summary>
/// The public Meta Lead Ads webhook, ONE ADDRESS PER ORGANIZATION (<c>/webhooks/meta-lead-ads/{org_id}</c>, shown on the connector
/// card): the Meta app - and so its app secret and verify token - is the org's own, so the org comes from the path and the secrets
/// from that org's saved credentials. Anonymous; trust is the verify token (GET) and X-Hub-Signature-256 (POST), checked with the
/// SAME verifier the WhatsApp webhook uses. Mirrors <see cref="WhatsAppWebhookController"/>.
///
/// POST answers 401 for a bad signature (nothing parsed), 200 for a delivery handled (including ones with nothing for us), and 500
/// only for a transient failure fetching/saving a lead - Meta then redelivers, and every lead is idempotent on its leadgen id.
/// </summary>
[ApiController]
[Route("webhooks/meta-lead-ads/{orgId:guid}")]
[AllowAnonymous]
[EnableRateLimiting("meta-lead-webhook")]
public class MetaLeadAdsWebhookController : ControllerBase
{
    private readonly MetaExperience _meta;
    public MetaLeadAdsWebhookController(MetaExperience meta) => _meta = meta;

    [HttpGet]
    public async Task<IActionResult> Verify(
        Guid orgId,
        [FromQuery(Name = "hub.mode")] string? mode,
        [FromQuery(Name = "hub.verify_token")] string? verifyToken,
        [FromQuery(Name = "hub.challenge")] string? challenge,
        CancellationToken ct)
    {
        if (!await _meta.VerifyHandshakeAsync(orgId, mode, verifyToken, ct)) return StatusCode(403);
        return Content(challenge ?? "", "text/plain");
    }

    [HttpPost]
    [RequestSizeLimit(1024 * 1024)]
    public async Task<IActionResult> Receive(Guid orgId, CancellationToken ct)
    {
        using var ms = new MemoryStream();
        await Request.Body.CopyToAsync(ms, ct);
        var signature = Request.Headers[WhatsAppWebhookVerifier.SignatureHeader].FirstOrDefault();

        var outcome = await _meta.HandleWebhookAsync(orgId, ms.ToArray(), signature, ct);
        return outcome switch
        {
            MetaWebhookOutcome.Rejected => Unauthorized(),
            MetaWebhookOutcome.Retry => StatusCode(500, new { error = "temporarily unable to process" }),
            _ => Ok(),
        };
    }
}

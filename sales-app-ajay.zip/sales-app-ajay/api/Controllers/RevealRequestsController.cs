using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Approvals;
using SalesApi.ProcessLayer.Approvals;
using SalesApi.Services;

namespace SalesApi.Controllers;

// E12.5 (owner decision 10) - reveal requests. Routing, [Authorize], model binding and status codes only; the rules are in
// RevealRequestProcess. No permission beyond sign-in: the whole point is that the caller does NOT hold the level that reads the
// value, and the org's reveal switch (a setting, not a permission) decides whether asking is allowed at all.
//
// Approve / refuse are NOT here: a reveal request is started on an approval chain like any other, so it is decided through the
// existing POST /approval-chains/instances/{id}/decide (the dto carries chain_instance_id). Contract:
// to-do/sensitive-data-api.md section 8.
[ApiController]
[Route("reveal-requests")]
[Authorize]
public class RevealRequestsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly RevealRequestExperience _reveals;

    public RevealRequestsController(CallerContext caller, RevealRequestExperience reveals)
    {
        _caller = caller;
        _reveals = reveals;
    }

    private IActionResult FromRefusal(ApprovalProcess.Refusal refusal) => refusal.Kind switch
    {
        ApprovalProcess.RefusalKind.NotFound => NotFound(refusal.Body),
        ApprovalProcess.RefusalKind.Conflict => Conflict(refusal.Body),
        ApprovalProcess.RefusalKind.Forbidden => StatusCode(403, refusal.Body),
        _ => BadRequest(refusal.Body),
    };

    // POST /reveal-requests - ask to see a masked value on one record.
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] RevealRequestInput input, CancellationToken ct)
    {
        var ctx = await _caller.ForAsync(User);
        var outcome = await _reveals.CreateAsync(ctx, input, ct);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Request);
    }

    // GET /reveal-requests?status= - my requests, and the pending ones I am the current approver of.
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] string? status, CancellationToken ct)
    {
        var ctx = await _caller.ForAsync(User);
        var (refusal, page) = await _reveals.ListAsync(ctx, status, ct);
        return refusal is not null ? FromRefusal(refusal) : Ok(page);
    }
}

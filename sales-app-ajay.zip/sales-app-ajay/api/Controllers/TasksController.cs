using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Tasks;
using SalesApi.ProcessLayer.Tasks;
using SalesApi.Services;

namespace SalesApi.Controllers;

// E2.1 (to-do/epics-ai-native-crm.md) — tasks as a first-class object. This
// controller keeps routing, [Authorize] and status selection; every business
// rule (list scoping/team switcher, create/update rules, the bulk-reassign
// cross-team refusal) lives in TaskProcess, reached through TasksExperience —
// same split as RemindersController.
[ApiController]
[Route("tasks")]
[Authorize]
public class TasksController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly TasksExperience _tasks;
    public TasksController(CallerContext caller, TasksExperience tasks)
    {
        _caller = caller;
        _tasks = tasks;
    }

    // GET /tasks?scope=mine|team|overdue|role&team_id=&status=   (role = E13 "For my role": unclaimed queue tasks of the caller's role)
    [HttpGet]
    // One-table: `filters` and `sorts` (JSON, URL-encoded) — see GET /tasks/columns for what may be used.
    public async Task<IActionResult> List(
        string? scope, [FromQuery] Guid? team_id, [FromQuery] string? status,
        [FromQuery] string? filters = null, [FromQuery] string? sorts = null)
    {
        var ctx = await _caller.ForAsync(User);
        var (dtos, refusal) = await _tasks.ListAsync(ctx, scope, team_id, status, default, filters, sorts);
        if (refusal is not null) return Refuse(refusal);
        return Ok(dtos);
    }

    // GET /tasks/columns — the table's column catalogue (same access as GET /tasks).
    [HttpGet("columns")]
    public async Task<IActionResult> Columns() => Ok(await _tasks.ColumnsAsync(await _caller.ForAsync(User)));

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var ctx = await _caller.ForAsync(User);
        var (dto, refusal) = await _tasks.GetAsync(ctx, id);
        if (refusal is not null) return Refuse(refusal);
        return Ok(dto);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] TaskInput input)
    {
        // Files named at creation on an account task sit behind the same permission as the account's own Files list (as POST /tasks/{id}/files/links).
        if (input.AttachmentIds is { Count: > 0 } && input.LinkedRecordType == SalesApi.Models.TaskLinkedRecordTypes.Account && !User.FileAccess().ViewContactDetails)
            return NotFound(new { error = "Record not found" });
        var ctx = await _caller.ForAsync(User);
        var (dto, refusal) = await _tasks.CreateAsync(ctx, User.OrgId(), input);
        if (refusal is not null) return Refuse(refusal);
        return StatusCode(201, dto);
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] TaskInput input)
    {
        var ctx = await _caller.ForAsync(User);
        var (dto, refusal) = await _tasks.UpdateAsync(ctx, User.OrgId(), id, input);
        if (refusal is not null) return Refuse(refusal);
        return Ok(dto);
    }

    [HttpPost("{id:guid}/complete")]
    public async Task<IActionResult> Complete(Guid id)
    {
        var ctx = await _caller.ForAsync(User);
        var (dto, refusal) = await _tasks.CompleteAsync(ctx, id);
        if (refusal is not null) return Refuse(refusal);
        return Ok(dto);
    }

    // E13: claim a role-queue task (409 when somebody already has it).
    [HttpPost("{id:guid}/claim")]
    public async Task<IActionResult> Claim(Guid id)
    {
        var ctx = await _caller.ForAsync(User);
        var (dto, refusal) = await _tasks.ClaimAsync(ctx, id);
        if (refusal is not null) return Refuse(refusal);
        return Ok(dto);
    }

    [HttpPost("{id:guid}/cancel")]
    public async Task<IActionResult> Cancel(Guid id)
    {
        var ctx = await _caller.ForAsync(User);
        var (dto, refusal) = await _tasks.CancelAsync(ctx, id);
        if (refusal is not null) return Refuse(refusal);
        return Ok(dto);
    }

    [HttpPost("{id:guid}/snooze")]
    public async Task<IActionResult> Snooze(Guid id, [FromBody] TaskSnoozeInput input)
    {
        var ctx = await _caller.ForAsync(User);
        var (dto, refusal) = await _tasks.SnoozeAsync(ctx, id, input);
        if (refusal is not null) return Refuse(refusal);
        return Ok(dto);
    }

    [HttpPost("bulk-complete")]
    public async Task<IActionResult> BulkComplete([FromBody] TaskBulkCompleteInput input)
    {
        var ctx = await _caller.ForAsync(User);
        var result = await _tasks.BulkCompleteAsync(ctx, input.Ids ?? []);
        return Ok(result);
    }

    [HttpPost("bulk-reassign")]
    public async Task<IActionResult> BulkReassign([FromBody] TaskBulkReassignInput input)
    {
        if (input.AssigneeId is not Guid assigneeId) return BadRequest(new { error = "assignee_id is required" });
        var ctx = await _caller.ForAsync(User);
        var result = await _tasks.BulkReassignAsync(ctx, User.OrgId(), input.Ids ?? [], assigneeId);
        return Ok(result);
    }

    // --- files on a task (to-do/task-files-design.md) -------------------------------------------------------------------
    // The task's files are links to its deal's / account's own files; every rule lives in TaskFileProcess (and the attachment rules it reuses).

    // GET /tasks/{id}/files - the task's linked files. 404 when the caller cannot see the task.
    [HttpGet("{id:guid}/files")]
    public async Task<IActionResult> Files(Guid id)
    {
        var (files, refusal) = await _tasks.FilesAsync(await _caller.ForAsync(User), User.FileAccess(), id, HttpContext.RequestAborted);
        return refusal is not null ? Refuse(refusal) : Ok(files);
    }

    // POST /tasks/{id}/files/links { attachment_ids } - link files of the task's record; answers the task's files after.
    [HttpPost("{id:guid}/files/links")]
    public async Task<IActionResult> LinkFiles(Guid id, [FromBody] TaskFileLinksInput input)
    {
        var (files, refusal) = await _tasks.LinkFilesAsync(
            await _caller.ForAsync(User), User.FileAccess(), id, input, User.UserId(), HttpContext.RequestAborted);
        return refusal is not null ? Refuse(refusal) : Ok(files);
    }

    // DELETE /tasks/{id}/files/{attachmentId} - unlink only; the file stays on its record.
    [HttpDelete("{id:guid}/files/{attachmentId:guid}")]
    public async Task<IActionResult> UnlinkFile(Guid id, Guid attachmentId)
    {
        var refusal = await _tasks.UnlinkFileAsync(await _caller.ForAsync(User), id, attachmentId, HttpContext.RequestAborted);
        return refusal is not null ? Refuse(refusal) : NoContent();
    }

    // POST /tasks/{id}/files (multipart field "file") - upload from the task; lands on the task's deal/account. 400 for an unlinked task.
    [HttpPost("{id:guid}/files")]
    [RequestSizeLimit(UploadLimits.StaffRequestBytes)]
    [StorageUnavailableFilter]
    public async Task<IActionResult> UploadFile(Guid id, IFormFile? file)
    {
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required" });
        await using var stream = file.OpenReadStream();
        var (saved, refusal) = await _tasks.UploadFileAsync(
            await _caller.ForAsync(User), User.FileAccess(), id, User.UserId(), User.OrgId(),
            file.FileName, file.ContentType, file.Length, stream, HttpContext.RequestAborted);
        return refusal is not null ? Refuse(refusal) : StatusCode(201, saved);
    }

    // GET /leads/{id}/tasks and /accounts/{id}/tasks are exposed here (not on
    // LeadsController/AccountsController) to keep the tasks vertical's own
    // scoping rule (RecordAccess.CanView on the linked record) in one place —
    // matching how GET /leads/{id}/timeline stays with the record it reads FROM.
    [HttpGet("~/leads/{leadId:guid}/tasks")]
    public async Task<IActionResult> ForLead(Guid leadId)
    {
        var ctx = await _caller.ForAsync(User);
        return Ok(await _tasks.ForLeadAsync(ctx, leadId));
    }

    [HttpGet("~/accounts/{accountId:guid}/tasks")]
    public async Task<IActionResult> ForAccount(Guid accountId)
    {
        var ctx = await _caller.ForAsync(User);
        return Ok(await _tasks.ForAccountAsync(ctx, accountId));
    }

    private IActionResult Refuse(TaskProcess.Refusal refusal) => refusal.Kind switch
    {
        TaskProcess.RefusalKind.NotFound => NotFound(new { error = refusal.Reason }),
        TaskProcess.RefusalKind.Forbidden => StatusCode(403, new { error = refusal.Reason }),
        TaskProcess.RefusalKind.Conflict => Conflict(new { error = refusal.Reason }),
        _ when refusal.Code is not null => BadRequest(new { error = refusal.Reason, code = refusal.Code, field = refusal.Field }),
        _ => BadRequest(new { error = refusal.Reason }),
    };
}

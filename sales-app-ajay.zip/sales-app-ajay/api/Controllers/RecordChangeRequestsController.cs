using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.RecordChangeRequests;
using SalesApi.ProcessLayer.RecordChangeRequests;
using SalesApi.Services;

namespace SalesApi.Controllers;

// E19.2 - record change requests: edits to an Account or a Contact made by PORTAL users, held for staff to approve (old against new against current). NOT the E7.4 Studio
// change requests (ChangeRequestsController, "change-requests"). Business rules live in SalesApi.ProcessApi/RecordChangeRequests/RecordChangeRequestProcess.cs. What is left
// here: routing, the portal guard attributes, building the caller as data (the portal scope, or the staff RecordAccessContext) and choosing the status code for a Refusal.

/// <summary>
/// What a portal user does with their own proposed edits: submit one, list theirs, withdraw a pending one. Reachable by portal users (and ONLY by them: a staff caller has no
/// portal account and is told so). The portal account comes from the principal, never from the body; a target outside it (and its child accounts) is a 404.
/// </summary>
[ApiController]
[Route("portal/change-requests")]
[Authorize]
[AllowCustomerPortal]
[AllowPartnerPortal]
public class PortalChangeRequestsController : ControllerBase
{
    private readonly RecordChangeRequestsExperience _requests;
    public PortalChangeRequestsController(RecordChangeRequestsExperience requests) => _requests = requests;

    // The ONE place the portal user's account is read. Today it is the partner claim; when the general portal-user claim (portal-users, E19.1) lands on this base, this is the
    // single line to point at it - the request logic is scope-in, never principal-in.
    // The general portal claims (E19.1): a customer sees its own account, plus its children only when its invite allows it; a partner, its own account.
    private RecordChangePortalScope? Scope() => User.PortalAccountId() is Guid account
        ? new RecordChangePortalScope(User.UserId(), account, User.PortalKind() == PortalKinds.Customer && User.PortalIncludeChildren())
        : null;

    private ObjectResult NotAPortalUser() => StatusCode(403, new { error = "This is for portal users.", code = "not_a_portal_user" });

    internal static IActionResult FromRefusal(RecordChangeRequestProcess.Refusal r) =>
        r.NotFound ? new NotFoundObjectResult(new { error = r.Reason })
        : r.Forbidden ? new ObjectResult(new { error = r.Reason }) { StatusCode = 403 }
        : r.Conflict ? new ConflictObjectResult(new { error = r.Reason, code = r.Code })
        : new BadRequestObjectResult(new { error = r.Reason, code = r.Code, field = r.Field, fields = r.Fields });

    [HttpPost]
    public async Task<IActionResult> Submit([FromBody] RecordChangeSubmitInput input, CancellationToken ct)
    {
        if (Scope() is not { } scope) return NotAPortalUser();
        var (refusal, dto) = await _requests.SubmitAsync(scope, input, ct);
        return refusal is not null ? FromRefusal(refusal) : Ok(dto);
    }

    [HttpGet]
    public async Task<IActionResult> Mine(CancellationToken ct) =>
        Scope() is { } scope ? Ok(await _requests.MineAsync(scope, ct)) : NotAPortalUser();

    [HttpPost("{id:guid}/withdraw")]
    public async Task<IActionResult> Withdraw(Guid id, CancellationToken ct)
    {
        if (Scope() is not { } scope) return NotAPortalUser();
        var (refusal, dto) = await _requests.WithdrawAsync(scope, id, ct);
        return refusal is not null ? FromRefusal(refusal) : Ok(dto);
    }
}

/// <summary>
/// The staff queue. Staff only (no portal attribute, so the portal guard denies a portal user here). A request is listed and decidable only when the caller may MANAGE its
/// account; approving applies the values through the normal account / contact update with the caller as the actor.
/// </summary>
[ApiController]
[Route("record-change-requests")]
[Authorize]
[RequireSensitiveAccess(SensitiveCategories.ContactDetails)]
public class RecordChangeRequestsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly RecordChangeRequestsExperience _requests;
    public RecordChangeRequestsController(CallerContext caller, RecordChangeRequestsExperience requests)
    {
        _caller = caller;
        _requests = requests;
    }

    /// <summary>GET /record-change-requests?status=pending|approved|rejected|withdrawn|all&amp;account_id=. Default pending.</summary>
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] string? status, [FromQuery(Name = "account_id")] Guid? accountId, CancellationToken ct)
    {
        var (refusal, items) = await _requests.ListAsync(await _caller.ForAsync(User), User.Role(), status, accountId, ct);
        return refusal is not null ? PortalChangeRequestsController.FromRefusal(refusal) : Ok(items);
    }

    [HttpPost("{id:guid}/approve")]
    public async Task<IActionResult> Approve(Guid id, CancellationToken ct)
    {
        var (refusal, dto) = await _requests.ApproveAsync(await _caller.ForAsync(User), User.Role(), id, ct);
        return refusal is not null ? PortalChangeRequestsController.FromRefusal(refusal) : Ok(dto);
    }

    [HttpPost("{id:guid}/reject")]
    public async Task<IActionResult> Reject(Guid id, [FromBody] RecordChangeRejectInput input, CancellationToken ct)
    {
        var (refusal, dto) = await _requests.RejectAsync(await _caller.ForAsync(User), User.Role(), id, input.Reason, ct);
        return refusal is not null ? PortalChangeRequestsController.FromRefusal(refusal) : Ok(dto);
    }
}

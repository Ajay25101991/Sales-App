using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Integrations;
using SalesApi.ProcessLayer.Integrations;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// The integrations admin page's extras (integrations audit, to-do/integrations-audit.md): the incoming log, one "test connection" for
/// every connector that has one, and the integration items for the Admin "needs attention" strip. A separate controller from
/// <see cref="IntegrationsController"/> (the directory + credentials) only so that class's constructor - hand-wired by many tests - does not
/// change; the routes share the <c>/integrations</c> prefix, and ASP.NET prefers a literal segment (<c>attention</c>,
/// <c>inbound-events</c>) over the directory's <c>{key}</c>.
///
/// Routing, the <c>settings.manage</c> check and status codes only; the rules are <see cref="IntegrationEventsExperience"/> and below.
/// </summary>
[ApiController]
[Route("integrations")]
[Authorize]
public class IntegrationEventsController : ControllerBase
{
    private readonly IntegrationEventsExperience _events;
    public IntegrationEventsController(IntegrationEventsExperience events) => _events = events;

    private bool CanManage() => User.HasPermission(OrganizationPermissions.ManageSettings);

    // GET /integrations/inbound-events?connector=&outcome=&page=&page_size= -> InboundEventPageDto, newest first (50 a page, at most 200).
    // Plan-gated: the incoming log is part of the "API & webhooks" plan feature (integrations audit, owner decision 8).
    [RequirePlanFeature(PlanCatalogue.Features.ApiWebhooks)]
    [HttpGet("inbound-events")]
    public async Task<IActionResult> InboundEvents(
        [FromQuery] string? connector, [FromQuery] string? outcome, [FromQuery] int page = 1,
        [FromQuery(Name = "page_size")] int pageSize = 50)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view integrations." });
        return Ok(await _events.ListEventsAsync(connector, outcome, page, pageSize));
    }

    // GET /integrations/attention -> { items: [{ kind, ref_id, label, since }] } - paused webhooks, expired / expiring API keys, signed-out connectors.
    [HttpGet("attention")]
    public async Task<IActionResult> Attention()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view integrations." });
        return Ok(await _events.AttentionAsync());
    }

    // POST /integrations/{key}/test -> { ok, message }. 200 when the connection works, 400 with the same body when it does not (the WhatsApp
    // test's contract, which this generalises; /settings/whatsapp/test and /settings/microsoft-365/test keep working).
    [HttpPost("{key}/test")]
    public async Task<IActionResult> Test(string key)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot configure integrations." });
        if (!ConnectorRegistry.IsKnown(key)) return NotFound(new { error = "Unknown connector." });
        if (!IntegrationTestProcess.Supports(key))
            return BadRequest(new ConnectionTestResultDto(false, "This connector has no connection test."));
        var result = await _events.TestAsync(key, User.OrgId(), User.UserId());
        if (result is null) return BadRequest(new ConnectionTestResultDto(false, "This connector has no connection test."));
        return result.Ok ? Ok(result) : BadRequest(result);
    }
}

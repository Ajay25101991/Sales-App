using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.SignUp;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.Services;

namespace SalesApi.Controllers;

// E19.5 - self sign-up and application for the partner and customer portals. Business rules live in SalesApi.ProcessApi/SignUp/SignUpProcess.cs. What is left here: routing, the
// permission checks, the portal guard attributes, building the caller as data (the portal scope, or the staff RecordAccessContext) and choosing the status code.

/// <summary>
/// The org's sign-up policy: per portal kind a switch (off by default) and the staff owner of new sign-up accounts, the days an unsubmitted application is kept, and the declaration
/// text. <c>manage_settings</c>. Switching a kind on without an active staff owner is a 400 (<c>owner_required</c> / <c>owner_not_staff</c>).
/// </summary>
[ApiController]
[Route("settings/sign-up")]
[Authorize]
[RequirePermission(OrganizationPermissions.ManageSettings)]
public class SignUpSettingsController : ControllerBase
{
    private readonly SignUpExperience _signUp;
    public SignUpSettingsController(SignUpExperience signUp) => _signUp = signUp;

    /// <summary><c>{ partner: { enabled, owner_profile_id, owner_name }, customer: {...}, purge_days, declaration_text, declaration_version }</c></summary>
    [HttpGet]
    public async Task<IActionResult> Get(CancellationToken ct) => Ok(await _signUp.GetSettingsAsync(ct));

    [HttpPut]
    public async Task<IActionResult> Put([FromBody] SignUpSettingsInput input, CancellationToken ct) => this.Respond(await _signUp.UpdateSettingsAsync(input, ct));
}

/// <summary>
/// The PUBLIC steps. No sign-in, no captcha (owner decision 2026-11-05): protected by the verified email and the <c>portal-signup</c> rate limit. The organisation is named by its domain
/// (or id); an unknown organisation, a closed kind and a kind with no active owner all answer the same 404, and <c>start</c> answers the same 200 whether or not the email is known.
/// </summary>
[ApiController]
[Route("public/sign-up")]
[AllowAnonymous]
[EnableRateLimiting("portal-signup")]
public class PublicSignUpController : ControllerBase
{
    private readonly SignUpExperience _signUp;
    public PublicSignUpController(SignUpExperience signUp) => _signUp = signUp;

    private string Absolute(string path) => this.AbsoluteUrl(path);

    /// <summary><c>GET ?org=&amp;kind=</c> -> <c>{ org_name, kind }</c>, or 404 when sign-up is not open.</summary>
    [HttpGet("options")]
    public async Task<IActionResult> Options([FromQuery] string? org, [FromQuery] string? kind, CancellationToken ct) => this.Respond(await _signUp.OptionsAsync(org, kind, ct));

    /// <summary><c>{ org, kind, full_name, company_name, email }</c> -> <c>{ ok: true }</c>. The same answer whether or not the email is known.</summary>
    [HttpPost("start")]
    public async Task<IActionResult> Start([FromBody] SignUpStartInput input, CancellationToken ct)
    {
        var r = await _signUp.StartAsync(input, Absolute, ct);
        return r.IsOk ? Ok(new { ok = true }) : this.Respond(r);
    }

    /// <summary><c>{ token, password }</c> -> <c>{ result: "created" | "under_review", email }</c>. The applicant then signs in with <c>POST /auth/signin</c>.</summary>
    [HttpPost("verify")]
    public async Task<IActionResult> Verify([FromBody] SignUpVerifyInput input, CancellationToken ct) => this.Respond(await _signUp.VerifyAsync(input, ct));
}

/// <summary>
/// The applicant's own application, for a signed-in portal user of either kind. A staff caller has no portal account and is told so. While the application is a draft the applicant edits
/// their account and contacts through <c>POST /portal/change-requests</c>, which saves them directly (status <c>applied</c>); after Submit the same call files a change request.
/// </summary>
[ApiController]
[Route("portal/sign-up")]
[Authorize]
[AllowPartnerPortal]
[AllowCustomerPortal]
public class PortalSignUpController : ControllerBase
{
    private readonly SignUpExperience _signUp;
    public PortalSignUpController(SignUpExperience signUp) => _signUp = signUp;

    private PortalScope? Scope() =>
        User.PortalKind() is { } kind && User.PortalAccountId() is Guid account
            ? new PortalScope(kind, account, User.PortalIncludeChildren(), User.UserId())
            : null;

    private ObjectResult NotAPortalUser() => StatusCode(403, new { error = "This is for portal users.", code = "not_a_portal_user" });

    /// <summary><c>{ application: {...}, checklist: { complete, items: [...] } | null }</c>; 404 when the user has no application.</summary>
    [HttpGet("application")]
    public async Task<IActionResult> Mine(CancellationToken ct) => Scope() is { } s ? this.Respond(await _signUp.MineAsync(s, ct)) : NotAPortalUser();

    /// <summary><c>{ editable, account: { id, fields: { name, industry, website, phone, address, city, state, postal_code, country, country_code } }, contacts: [{ id, name, fields: { name, title, email, phone, phone_country_code, preferred_language } }] }</c> - current values (null when empty). 404 when the user has no application.</summary>
    [HttpGet("details")]
    public async Task<IActionResult> Details(CancellationToken ct) => Scope() is { } s ? this.Respond(await _signUp.DetailsAsync(s, ct)) : NotAPortalUser();

    /// <summary><c>{ accept_declaration: true }</c> -> the application, now <c>submitted</c>. 409 <c>kyc_incomplete</c> with <c>missing: [...]</c> while mandatory documents are missing.</summary>
    [HttpPost("submit")]
    public async Task<IActionResult> Submit([FromBody] SignUpSubmitInput input, CancellationToken ct) =>
        Scope() is { } s ? this.Respond(await _signUp.SubmitAsync(s, input, ct)) : NotAPortalUser();
}

/// <summary>
/// The staff review queue. <c>partners.manage</c> for both kinds - the same permission that gates inviting a customer's portal users today (E19.1). Approve moves a partner to
/// active (a customer's account status stays as it is); reject needs a reason; both email the applicant.
/// </summary>
[ApiController]
[Route("sign-up-applications")]
[Authorize]
public class SignUpApplicationsController : ControllerBase
{
    private readonly SignUpExperience _signUp;
    private readonly CallerContext _caller;
    public SignUpApplicationsController(SignUpExperience signUp, CallerContext caller)
    {
        _signUp = signUp;
        _caller = caller;
    }

    private bool MayReview() => User.HasPermission(OrganizationPermissions.ManagePartners);
    private ObjectResult No() => StatusCode(403, new { error = "Your role cannot review sign-up applications." });
    private string Absolute(string path) => this.AbsoluteUrl(path);

    private async Task<PartnerImportActor> ActorAsync() => new(
        User.UserId(), User.OrgId(), await _caller.DisplayNameAsync(User), User.IsManager(), await _caller.VisibilityAsync(User), User.Role(),
        User.HasPermission(OrganizationPermissions.TagCreate), User.Sensitive());

    /// <summary><c>GET ?status=draft|submitted|approved|rejected|purged|all&amp;kind=partner|customer</c> (default submitted) -> <c>[application]</c>.</summary>
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] string? status, [FromQuery] string? kind, CancellationToken ct) =>
        !MayReview() ? No() : this.Respond(await _signUp.ListAsync(await _caller.ForAsync(User), status, kind, ct));

    /// <summary><c>{ submitted, flagged }</c> - the menu badge. <c>flagged</c> = held possible duplicates awaiting a decision; <c>submitted</c> = the rest of the waiting queue (no overlap).</summary>
    [HttpGet("count")]
    public async Task<IActionResult> Count(CancellationToken ct) =>
        !MayReview() ? No() : this.Respond(await _signUp.CountAsync(await _caller.ForAsync(User), ct));

    /// <summary>The application with the account's KYC checklist: <c>{ application, checklist }</c>.</summary>
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct) =>
        !MayReview() ? No() : this.Respond(await _signUp.GetAsync(await _caller.ForAsync(User), id, ct));

    /// <summary><c>{ owner_id? }</c> (reassigns the account's owner first). 409 <c>duplicate_unresolved</c> for a duplicate-flagged application.</summary>
    [HttpPost("{id:guid}/approve")]
    public async Task<IActionResult> Approve(Guid id, [FromBody] SignUpApproveInput? input, CancellationToken ct) =>
        !MayReview() ? No() : this.Respond(await _signUp.ApproveAsync(await _caller.ForAsync(User), await ActorAsync(), id, input ?? new SignUpApproveInput(null), Absolute, ct));

    /// <summary>
    /// A held possible duplicate only. <c>{ account_id? }</c> (default: the matched account): invites the applicant as a portal user on it and approves the application.
    /// 409 <c>not_flagged</c>, 409 <c>email_in_use</c>.
    /// </summary>
    [HttpPost("{id:guid}/link")]
    public async Task<IActionResult> Link(Guid id, [FromBody] SignUpLinkInput? input, CancellationToken ct) =>
        !MayReview() ? No() : this.Respond(await _signUp.LinkAsync(await _caller.ForAsync(User), await ActorAsync(), id, input ?? new SignUpLinkInput(null), Absolute, ct));

    /// <summary>A held possible duplicate only; body <c>{}</c>. Creates the account, partner and portal user as verify does, sends the set-password invite, and leaves the application a draft. 409 <c>not_flagged</c>, <c>email_in_use</c>, <c>duplicate_account</c>.</summary>
    [HttpPost("{id:guid}/create-anyway")]
    public async Task<IActionResult> CreateAnyway(Guid id, CancellationToken ct) =>
        !MayReview() ? No() : this.Respond(await _signUp.CreateAnywayAsync(await ActorAsync(), id, Absolute, ct));

    /// <summary><c>{ reason }</c> - required, emailed to the applicant.</summary>
    [HttpPost("{id:guid}/reject")]
    public async Task<IActionResult> Reject(Guid id, [FromBody] SignUpRejectInput input, CancellationToken ct) =>
        !MayReview() ? No() : this.Respond(await _signUp.RejectAsync(await _caller.ForAsync(User), await ActorAsync(), id, input, ct));
}

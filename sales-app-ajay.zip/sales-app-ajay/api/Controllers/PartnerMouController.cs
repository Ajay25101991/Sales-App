using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.ChannelPartners;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Channel partners - the MoU net-margin model (to-do/partner-mou-net-margin-design.md; owner decisions 2026-11-12). A fourth controller beside <see cref="ChannelPartnersController"/> on the same
/// <c>channel-partners/*</c> routes. Routes, checks permission, picks a status code; touches no _db. Permissions follow the payout chain: whoever manages partners or prepares payouts enters
/// consumption and runs a month; only partners.approve_payouts approves or voids a statement. Underneath, Process applies the partner_commercials category (a raw read to see, Full to write).
/// </summary>
[ApiController]
[Route("")]
[Authorize]
public class PartnerMouController : ControllerBase
{
    private readonly PartnerMouExperience _mou;
    private readonly CallerContext _caller;

    public PartnerMouController(PartnerMouExperience mou, CallerContext caller)
    {
        _mou = mou;
        _caller = caller;
    }

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManagePartners);
    private bool CanPrepare => CanManage || User.HasPermission(OrganizationPermissions.PreparePartnerPayouts);
    private bool CanApprove => User.HasPermission(OrganizationPermissions.ApprovePartnerPayouts);
    private bool InChannel => CanPrepare || CanApprove;
    private ObjectResult No(string what) => StatusCode(403, new { error = $"Your role cannot {what}." });
    private IActionResult Respond<T>(CpResult<T> r, int okStatus = 200) => CpControllerExtensions.Respond(this, r, okStatus);

    // ---- consumption ----

    /// <summary>One partner's clients' consumption for a month (<c>month=YYYY-MM</c>).</summary>
    [HttpGet("channel-partners/{accountId:guid}/consumption")]
    public async Task<IActionResult> Consumption(Guid accountId, [FromQuery] string? month, CancellationToken ct)
    {
        if (!InChannel) return No("see partner consumption");
        return Respond(await _mou.ConsumptionAsync(await _caller.ForAsync(User), accountId, month, ct));
    }

    /// <summary>Enter one client and month by hand; the same client and month again replaces the row.</summary>
    [HttpPut("channel-partners/{accountId:guid}/consumption")]
    public async Task<IActionResult> SaveConsumption(Guid accountId, [FromBody] PartnerConsumptionInput input, CancellationToken ct)
    {
        if (!CanPrepare) return No("enter partner consumption");
        return Respond(await _mou.SaveConsumptionAsync(await _caller.ForAsync(User), accountId, input, User.UserId(), ct));
    }

    /// <summary>Upload consumption as CSV text. Idempotent per client and month; bad rows are skipped and listed. <c>dry_run</c> saves nothing.</summary>
    [HttpPost("channel-partners/{accountId:guid}/consumption/upload")]
    public async Task<IActionResult> UploadConsumption(Guid accountId, [FromBody] PartnerConsumptionUploadInput input, CancellationToken ct)
    {
        if (!CanPrepare) return No("upload partner consumption");
        return Respond(await _mou.UploadConsumptionAsync(await _caller.ForAsync(User), accountId, input, User.UserId(), ct));
    }

    // ---- statements ----

    [HttpGet("channel-partners/{accountId:guid}/mou-statements")]
    public async Task<IActionResult> Statements(Guid accountId, CancellationToken ct)
    {
        if (!InChannel) return No("see MoU statements");
        return Respond(await _mou.StatementsAsync(await _caller.ForAsync(User), accountId, ct));
    }

    /// <summary>"Run month": computes the month into a draft statement (replaces a draft; refuses an approved one).</summary>
    [HttpPost("channel-partners/{accountId:guid}/mou-statements")]
    public async Task<IActionResult> Run(Guid accountId, [FromBody] PartnerMouRunInput input, CancellationToken ct)
    {
        if (!CanPrepare) return No("run a partner's month");
        return Respond(await _mou.RunAsync(await _caller.ForAsync(User), accountId, input, User.UserId(), ct), 201);
    }

    /// <summary>
    /// One statement. No channel gate here on purpose: the partner account's owner may be a rep outside the channel team. Process lets through a channel caller or the account's owner
    /// (an owner without a commercials read sees figures only while the statement awaits their choice).
    /// </summary>
    [HttpGet("channel-partners/mou-statements/{statementId:guid}")]
    public async Task<IActionResult> Statement(Guid statementId, CancellationToken ct) =>
        Respond(await _mou.StatementAsync(await _caller.ForAsync(User), statementId, User.UserId(), InChannel, ct));

    /// <summary>The draft negative statements waiting for the CALLER's shortfall choice. Any signed-in user; an empty list when none.</summary>
    [HttpGet("channel-partners/mou-statements/awaiting-my-choice")]
    public async Task<IActionResult> AwaitingMyChoice(CancellationToken ct) =>
        Respond(await _mou.AwaitingMyChoiceAsync(await _caller.ForAsync(User), User.UserId(), CanManage, ct));

    [HttpPost("channel-partners/mou-statements/{statementId:guid}/approve")]
    public async Task<IActionResult> Approve(Guid statementId, [FromBody] PartnerMouApproveInput? input, CancellationToken ct)
    {
        if (!CanApprove) return No("approve a MoU statement");
        return Respond(await _mou.ApproveAsync(await _caller.ForAsync(User), statementId, input ?? new PartnerMouApproveInput(null), User.UserId(), ct));
    }

    [HttpPost("channel-partners/mou-statements/{statementId:guid}/void")]
    public async Task<IActionResult> Void(Guid statementId, [FromBody] PartnerMouVoidInput input, CancellationToken ct)
    {
        if (!CanApprove) return No("void a MoU statement");
        return Respond(await _mou.VoidAsync(await _caller.ForAsync(User), statementId, input, User.UserId(), ct));
    }

    /// <summary>
    /// The partner account's owner chooses what to do with a NEGATIVE statement (carry_forward | settle_zero | post_reverse). Process allows only the account owner,
    /// or a partners.manage holder while the owner is inactive.
    /// </summary>
    [HttpPost("channel-partners/mou-statements/{statementId:guid}/shortfall-choice")]
    public async Task<IActionResult> ChooseShortfall(Guid statementId, [FromBody] PartnerMouShortfallInput input, CancellationToken ct)
    {
        // No permission gate on purpose: the partner account's owner may be a rep outside the channel team. Process requires the owner (or, if inactive, partners.manage) and a Full commercials write.
        return Respond(await _mou.ChooseShortfallAsync(await _caller.ForAsync(User), statementId, input, User.UserId(), CanManage, ct));
    }

    /// <summary>"Mark received": a payment (date, amount, reference) against an approved receivable statement. Partial allowed; overpayment refused.</summary>
    [HttpPost("channel-partners/mou-statements/{statementId:guid}/receipts")]
    public async Task<IActionResult> RecordReceipt(Guid statementId, [FromBody] PartnerMouReceiptInput input, CancellationToken ct)
    {
        if (!CanApprove) return No("record money received on a MoU statement");
        return Respond(await _mou.RecordReceiptAsync(await _caller.ForAsync(User), statementId, input, User.UserId(), ct), 201);
    }

    // ---- report ----

    /// <summary>Per partner per month (<c>from</c> / <c>to</c> = YYYY-MM; default the last 12 months): net base, FP and SP amounts, direction, statement status.</summary>
    [HttpGet("channel-partners/mou-report")]
    public async Task<IActionResult> Report(CancellationToken ct, [FromQuery] string? from = null, [FromQuery] string? to = null)
    {
        if (!InChannel) return No("see the MoU report");
        return Respond(await _mou.ReportAsync(await _caller.ForAsync(User), from, to, ct));
    }
}

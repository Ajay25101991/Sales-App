using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Stakeholders;
using SalesApi.ProcessLayer.Stakeholders;
using SalesApi.Services;

namespace SalesApi.Controllers;

// E3.3 — deal stakeholders, nested under the lead they belong to (same
// /leads/{id}/... shape as activities/proposals/timeline on LeadsController;
// a separate controller because the vertical is its own domain, the same
// reasoning ContactsController is separate from AccountsController).
[ApiController]
[Route("leads/{leadId:guid}/stakeholders")]
[Authorize]
public class StakeholdersController : ControllerBase
{
    // The one remaining _db use — resolving WHO is calling needs both the
    // ClaimsPrincipal and the database, same residual every migrated
    // controller keeps (see LeadsController's own comment).
    private readonly CallerContext _caller;
    private readonly StakeholdersExperience _stakeholders;

    public StakeholdersController(CallerContext caller, StakeholdersExperience stakeholders)
    {
        _caller = caller;
        _stakeholders = stakeholders;
    }

    private Task<RecordAccessContext> AccessAsync() => _caller.ForAsync(User);
    private bool CanSeeContactDetails => User.HasPermission(OrganizationPermissions.ViewContactDetails);

    private static IActionResult FromRefusal(StakeholderProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 403 }
        : new BadRequestObjectResult(new { error = refusal.Reason });

    [HttpGet]
    public async Task<IActionResult> List(Guid leadId)
    {
        var outcome = await _stakeholders.ListAsync(await AccessAsync(), leadId, CanSeeContactDetails, User.Role());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Dto);
    }

    [HttpPost]
    public async Task<IActionResult> Add(Guid leadId, [FromBody] StakeholderInput input)
    {
        var outcome = await _stakeholders.AddAsync(
            await AccessAsync(), leadId, User.UserId(), User.Role(), CanSeeContactDetails, input);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Stakeholder);
    }

    [HttpPatch("{stakeholderId:guid}")]
    public async Task<IActionResult> Update(Guid leadId, Guid stakeholderId, [FromBody] StakeholderInput input)
    {
        var outcome = await _stakeholders.UpdateAsync(
            await AccessAsync(), leadId, stakeholderId, User.UserId(), User.Role(), CanSeeContactDetails, input);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Stakeholder);
    }

    [HttpDelete("{stakeholderId:guid}")]
    public async Task<IActionResult> Remove(Guid leadId, Guid stakeholderId)
    {
        var outcome = await _stakeholders.RemoveAsync(await AccessAsync(), leadId, stakeholderId, User.UserId());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : NoContent();
    }
}

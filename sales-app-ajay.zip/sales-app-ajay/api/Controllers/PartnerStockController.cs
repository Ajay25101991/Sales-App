using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.ChannelPartners;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Channel partners, Phase 3 (to-do/partner-management-design.md 9.2; owner decisions section 10): reseller bulk packs, the two named figures of a deal, distributor tiers.
/// A second controller beside <see cref="ChannelPartnersController"/> on the same <c>channel-partners/*</c> routes, so Phase 2 and Phase 3 never edit one file.
///
/// Routes, checks permission, picks a status code; it touches no _db. Reading a pack or the stock page needs any partners.* permission (the channel team); every write needs
/// partners.manage; and, underneath, the sensitive category <c>partner_commercials</c> (Process masks every count, price and credit below a raw read and refuses a write below
/// Full). The deal-level reads (a deal partner's stock facts, a deal's two figures) need only the deal: a rep sees "available / low / out" and the end-client price.
/// A WIN IS NEVER BLOCKED BY STOCK - there is no refusal or override-to-win endpoint by design (owner 3.5).
/// </summary>
[ApiController]
[Route("")]
[Authorize]
public class PartnerStockController : ControllerBase
{
    private readonly PartnerStockExperience _stock;
    private readonly CallerContext _caller;

    public PartnerStockController(PartnerStockExperience stock, CallerContext caller)
    {
        _stock = stock;
        _caller = caller;
    }

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManagePartners);
    private bool InChannel => CanManage || User.HasPermission(OrganizationPermissions.PreparePartnerPayouts) || User.HasPermission(OrganizationPermissions.ApprovePartnerPayouts);

    private ObjectResult No(string what) => StatusCode(403, new { error = $"Your role cannot {what}." });

    private IActionResult Respond<T>(CpResult<T> r, int okStatus = 200) => r.Outcome switch
    {
        CpOutcome.NotFound => NotFound(new { error = r.Error }),
        CpOutcome.Invalid => BadRequest(new { error = r.Error, code = r.Code, issues = r.Issues }),
        CpOutcome.Conflict => Conflict(new { error = r.Error, code = r.Code }),
        CpOutcome.Forbidden => StatusCode(403, new { error = r.Error, code = r.Code }),
        _ => StatusCode(okStatus, r.Value),
    };

    // ---- a partner's stock -----------------------------------------------------------------------

    /// <summary>The Stock tab: the partner's lots with balances, and the totals. Below a raw Partner commercials read only the availability comes back.</summary>
    [HttpGet("channel-partners/{accountId:guid}/stock")]
    public async Task<IActionResult> Summary(Guid accountId, CancellationToken ct)
    {
        if (!InChannel) return No("see partner stock");
        return Respond(await _stock.SummaryAsync(await _caller.ForAsync(User), accountId, ct));
    }

    [HttpGet("channel-partners/{accountId:guid}/stock/movements")]
    public async Task<IActionResult> Movements(
        Guid accountId, CancellationToken ct, [FromQuery(Name = "lot_id")] Guid? lotId = null, [FromQuery] string? kind = null, [FromQuery] int skip = 0, [FromQuery] int take = 50)
    {
        if (!InChannel) return No("see partner stock");
        return Respond(await _stock.MovementsAsync(await _caller.ForAsync(User), accountId, lotId, kind, skip, take, ct));
    }

    /// <summary>Record a pack the partner bought (the purchase is an ordinary deal on the partner's account).</summary>
    [HttpPost("channel-partners/{accountId:guid}/stock/lots")]
    public async Task<IActionResult> RecordLot(Guid accountId, [FromBody] PartnerStockLotInput input, CancellationToken ct)
    {
        if (!CanManage) return No("record a partner's stock");
        return Respond(await _stock.RecordLotAsync(await _caller.ForAsync(User), accountId, input, User.UserId(), ct), 201);
    }

    /// <summary>Extend ONE pack's expiry or change its policy, with a reason (a zero-delta override movement).</summary>
    [HttpPost("channel-partners/stock/lots/{lotId:guid}/override")]
    public async Task<IActionResult> OverrideLot(Guid lotId, [FromBody] PartnerStockOverrideInput input, CancellationToken ct)
    {
        if (!CanManage) return No("override a partner's stock");
        return Respond(await _stock.OverrideLotAsync(await _caller.ForAsync(User), lotId, input, User.UserId(), ct));
    }

    /// <summary>Correct the units on a pack (positive or negative), with a reason. A transfer between partners is a pair of these.</summary>
    [HttpPost("channel-partners/stock/lots/{lotId:guid}/adjust")]
    public async Task<IActionResult> AdjustLot(Guid lotId, [FromBody] PartnerStockAdjustInput input, CancellationToken ct)
    {
        if (!CanManage) return No("adjust a partner's stock");
        return Respond(await _stock.AdjustLotAsync(await _caller.ForAsync(User), lotId, input, User.UserId(), ct));
    }

    /// <summary>Record that (part of) a partner's stock credit was spent on a new pack.</summary>
    [HttpPost("channel-partners/stock/credits/apply")]
    public async Task<IActionResult> ApplyCredit([FromBody] PartnerStockCreditApplyInput input, CancellationToken ct)
    {
        if (!CanManage) return No("apply a partner's stock credit");
        return Respond(await _stock.ApplyCreditAsync(await _caller.ForAsync(User), input, User.UserId(), ct));
    }

    /// <summary>The channel stock page: one row per partner holding stock (balance, expiring within N days, low, negative).</summary>
    [HttpGet("channel-partners/stock")]
    public async Task<IActionResult> Overview(CancellationToken ct, [FromQuery(Name = "expiring_days")] int expiringDays = 30)
    {
        if (!InChannel) return No("see partner stock");
        return Respond(await _stock.OverviewAsync(await _caller.ForAsync(User), expiringDays, ct));
    }

    // ---- a deal's stock facts and its two named figures --------------------------------------------

    /// <summary>The stock facts of a reseller on a deal: typed and suggested units, drawn, availability. Numbers are masked below a raw Partner commercials read. Anyone who can see the deal.</summary>
    [HttpGet("leads/{leadId:guid}/channel-partners/{dealPartnerId:guid}/stock")]
    public async Task<IActionResult> DealPartnerStock(Guid leadId, Guid dealPartnerId, CancellationToken ct) =>
        Respond(await _stock.DealPartnerStockAsync(await _caller.ForAsync(User), leadId, dealPartnerId, ct));

    /// <summary>Set the units (editable until the deal is won), the partner's resale price and the wholesale amount of a reseller on a deal.</summary>
    [HttpPut("leads/{leadId:guid}/channel-partners/{dealPartnerId:guid}/stock")]
    public async Task<IActionResult> SetDealPartnerStock(Guid leadId, Guid dealPartnerId, [FromBody] DealPartnerStockInput input, CancellationToken ct)
    {
        if (!CanManage) return No("change a deal partner's stock");
        return Respond(await _stock.SetDealPartnerStockAsync(await _caller.ForAsync(User), leadId, dealPartnerId, input, ct));
    }

    /// <summary>"End-client price" and "Our revenue (wholesale)" of a deal, from the one resolver. Our revenue is null below a raw Partner commercials read.</summary>
    [HttpGet("leads/{leadId:guid}/channel-partners/revenue")]
    public async Task<IActionResult> DealRevenue(Guid leadId, CancellationToken ct) =>
        Respond(await _stock.DealRevenueAsync(await _caller.ForAsync(User), leadId, ct));

    // ---- distributors ----------------------------------------------------------------------------------

    /// <summary>The distributor and its sub-resellers to the org's depth, with units drawn, wholesale value and the override earned.</summary>
    [HttpGet("channel-partners/{accountId:guid}/tree")]
    public async Task<IActionResult> Tree(Guid accountId, CancellationToken ct)
    {
        if (!InChannel) return No("see a distributor's tree");
        return Respond(await _stock.TreeAsync(await _caller.ForAsync(User), accountId, ct));
    }

    /// <summary>Add a sub-reseller under a distributor (the account relationship distributor_for), within the org's channel depth.</summary>
    [HttpPost("channel-partners/{accountId:guid}/sub-resellers")]
    public async Task<IActionResult> AddSubReseller(Guid accountId, [FromBody] SubResellerInput input, CancellationToken ct)
    {
        if (!CanManage) return No("add a sub-reseller");
        return Respond(await _stock.AddSubResellerAsync(await _caller.ForAsync(User), accountId, input, User.UserId(), ct), 201);
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SalesApi.ExperienceLayer.DocumentRequests;
using SalesApi.ProcessLayer.DocumentRequests;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E15 document requests - the CLIENT's public link (no sign-in). The token in the path names one request, as the IRL link does; a stale link is refused on
/// the read AND again on every write: 404 for an unknown token, 410 for a revoked or expired one, 409 once the client has submitted. These are JSON endpoints
/// for the desktop app's public page (the page itself, <c>/apps/sales/document-request/{token}</c>, is a route of that app, not served here). Rate limited with
/// the IRL link's policy ("irl-public"). Routes and picks status codes only; the rules are <see cref="DocumentRequestPublicProcess"/>.
/// </summary>
[ApiController]
[Route("public/document-requests")]
[AllowAnonymous]
[EnableRateLimiting("irl-public")]
public class DocumentRequestPublicController : ControllerBase
{
    private readonly DocumentRequestExperience _requests;
    public DocumentRequestPublicController(DocumentRequestExperience requests) => _requests = requests;

    /// <summary>404 <c>{error}</c>; 410 <c>{error, status}</c> (revoked/expired); 409 <c>{error, status:"completed"}</c>; 400 <c>{error, code?}</c>; 413 <c>{error}</c>.</summary>
    private IActionResult Respond<T>(DocumentRequestPublicProcess.Result<T> r) => r.Outcome switch
    {
        DocumentRequestPublicProcess.Outcome.NotFound => NotFound(new { error = r.Error }),
        DocumentRequestPublicProcess.Outcome.Gone => r.Status == "completed" ? Conflict(new { error = r.Error, status = r.Status }) : StatusCode(410, new { error = r.Error, status = r.Status }),
        DocumentRequestPublicProcess.Outcome.Invalid => BadRequest(new { error = r.Error, code = r.Code }),
        DocumentRequestPublicProcess.Outcome.TooLarge => StatusCode(413, new { error = r.Error }),
        _ => Ok(r.Value),
    };

    /// <summary>GET: <c>{ company, requested_by, expires_at, status, language, items: [{ document_type, label, uploaded: [{ file_name, uploaded_at }] }] }</c>.</summary>
    [HttpGet("{token}")]
    public async Task<IActionResult> View(string token, CancellationToken ct) =>
        Respond(await _requests.ViewAsync(token, ct));

    /// <summary>POST (multipart <c>file</c> + <c>document_type</c>): adds a file for one of the documents asked for. 201 <c>{ document_type, file_name, uploaded_at }</c>.
    /// PDF, JPG or PNG only (400 code file_type_not_allowed).</summary>
    [HttpPost("{token}/files")]
    [RequestSizeLimit(UploadLimits.PublicRequestBytes)]
    public async Task<IActionResult> Upload(string token, [FromForm(Name = "document_type")] string? documentType, IFormFile? file, CancellationToken ct)
    {
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required" });
        await using var stream = file.OpenReadStream();
        var result = await _requests.UploadAsync(token, documentType, file.FileName, file.ContentType, file.Length, stream, ct);
        return result.Outcome == DocumentRequestPublicProcess.Outcome.Ok ? StatusCode(201, result.Value) : Respond(result);
    }

    /// <summary>POST: closes the request and tells the rep. <c>{ status: "completed" }</c>.</summary>
    [HttpPost("{token}/submit")]
    public async Task<IActionResult> Submit(string token, CancellationToken ct) =>
        Respond(await _requests.SubmitAsync(token, ct));
}

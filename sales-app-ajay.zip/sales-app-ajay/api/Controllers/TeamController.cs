using System.Globalization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.People;
using SalesApi.ProcessLayer.People;
using SalesApi.Services;

namespace SalesApi.Controllers;

[ApiController]
[Route("team")]
[Authorize]
public class TeamController : ControllerBase
{
    private readonly PeopleExperience _people;

    public TeamController(PeopleExperience people)
    {
        _people = people;
    }

    // List everyone on the team. Managers/admins, or a suntech-admin (user admin).
    // A suntech-admin may pass ?orgId= to view another organization's roster;
    // everyone else is scoped to their own org.
    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] Guid? orgId)
    {
        if (!User.HasPermission(OrganizationPermissions.ViewTeam) && !User.HasPermission(OrganizationPermissions.ManageTeam))
            return StatusCode(403, new { error = "Your role cannot view the team." });
        var targetOrg = User.IsSuntechAdmin() && orgId is not null ? orgId.Value : User.OrgId();
        if (targetOrg is not Guid org) return Ok(new List<ProfileDto>());

        var roster = await _people.GetRosterAsync(org);

        // Whether the caller may administer each person. This stays here, not in
        // PeopleProcess: "may THIS caller touch THIS person" is a fact about the
        // caller (UserAdminContext), and UserAdminContext/UserAdminPolicy live in
        // the System assembly — a Process surface that named either would trip
        // LayerBoundaryTests. PeopleProcess hands back the raw reach-team ids
        // (RosterRow.ReachTeamIds); the policy call itself happens here, exactly
        // where every other migrated domain has kept permission checks.
        var actor = UserAdminContext.For(User);
        return Ok(roster.Select(r => r.Profile with
        {
            CanManage = UserAdminPolicy.CanModifyUser(actor, r.Profile.Role, r.ReachTeamIds),
        }).ToList());
    }

    // GET /team/export — the same rows as GET /team, as CSV. Calls that action
    // directly and reuses its result rather than duplicating the query, so the
    // export can never see more than the screen it mirrors (its own
    // ViewTeam/ManageTeam check and org scoping still run) — same precedent
    // as GET /leads/export and GET /reports/leaderboard/export.
    [HttpGet("export")]
    [RequirePermission(OrganizationPermissions.CreateExports)]
    public async Task<IActionResult> Export([FromQuery] Guid? orgId)
    {
        var result = await Get(orgId);
        if (result is not OkObjectResult ok) return result;
        var rows = (List<ProfileDto>)ok.Value!;

        var csvRows = new List<IEnumerable<string?>>
        {
            new[] { "full_name", "email", "role", "is_active", "created_at" },
        };
        csvRows.AddRange(rows.Select(r => new string?[]
        {
            r.FullName, r.Email, r.Role, r.IsActive.ToString(),
            r.CreatedAt.ToUniversalTime().ToString("o"),
        }));
        return Content(CsvUtil.ToCsv(csvRows), "text/csv; charset=utf-8");
    }

    /// <summary>
    /// The shared gate on every write that targets an existing person: rank first
    /// (an admin is not a manager's to touch), then reach. Returns null when allowed.
    ///
    /// <paramref name="forceOwnOrg"/> — set by <see cref="UnlinkSso"/> only: unlike
    /// Update/Delete/ResetPassword, a suntech-admin's platform-wide reach does not
    /// extend to unbinding someone's Microsoft account. That is squarely the
    /// affected org's own call, so a suntech-admin here is treated as an ordinary
    /// caller scoped to their own org, never cross-org.
    /// </summary>
    private async Task<(ObjectResult? Denied, PeopleProcess.PersonGate? Gate)> GateAsync(Guid id, bool forceOwnOrg = false)
    {
        var gate = await _people.GetGateAsync(id, crossOrg: !forceOwnOrg && User.IsSuntechAdmin(), callerOrg: User.OrgId());
        if (gate is null) return (NotFound(new { error = "User not found" }), null);

        var actor = UserAdminContext.For(User);
        var reason = UserAdminPolicy.ExplainModifyDenial(actor, gate.Role, gate.TeamIds);
        return reason is null ? (null, gate) : (StatusCode(403, new { error = reason }), null);
    }

    // Rolling window "logins this period" is measured over — see
    // LoginActivityDto.LoginCountPeriod. A fixed 30 days (not user-selectable):
    // this table answers "who's gone quiet," a manager's occasional
    // rollout/hiring check, not a report anyone slices by week/month, so the
    // adoption-summary card on the same screen already assumes this window.
    public const int LoginActivityPeriodDays = 30;

    // GET /team/login-activity — per-teammate sign-in summary (rep, time since
    // last login, logins this period) for managers/admins; suntech-admin may
    // target another org. This is deliberately a table, not a chart: the
    // decision it drives is "who do I ping today," so it's ordered
    // longest-idle-first (never-signed-in leads, then oldest last-login) —
    // the names that need action, not a number.
    [HttpGet("login-activity")]
    public async Task<IActionResult> LoginActivity([FromQuery] Guid? orgId)
    {
        if (!User.HasPermission(OrganizationPermissions.ViewTeam) && !User.HasPermission(OrganizationPermissions.ManageTeam))
            return StatusCode(403, new { error = "Your role cannot view login activity." });
        var targetOrg = User.IsSuntechAdmin() && orgId is not null ? orgId.Value : User.OrgId();
        if (targetOrg is not Guid org) return Ok(new List<LoginActivityDto>());

        var rows = await _people.GetLoginActivityAsync(org, LoginActivityPeriodDays);
        return Ok(rows);
    }

    // GET /team/login-activity/export — the same rows as GET /team/login-activity,
    // as CSV. Same reuse pattern as GET /team/export above.
    [HttpGet("login-activity/export")]
    [RequirePermission(OrganizationPermissions.CreateExports)]
    public async Task<IActionResult> LoginActivityExport([FromQuery] Guid? orgId)
    {
        var result = await LoginActivity(orgId);
        if (result is not OkObjectResult ok) return result;
        var rows = (List<LoginActivityDto>)ok.Value!;

        var csvRows = new List<IEnumerable<string?>>
        {
            new[] { "full_name", "email", "role", "is_active", "last_login_at", "login_count", "login_count_period" },
        };
        csvRows.AddRange(rows.Select(r => new string?[]
        {
            r.FullName, r.Email, r.Role, r.IsActive.ToString(),
            r.LastLoginAt?.ToUniversalTime().ToString("o"),
            r.LoginCount.ToString(CultureInfo.InvariantCulture),
            r.LoginCountPeriod.ToString(CultureInfo.InvariantCulture),
        }));
        return Content(CsvUtil.ToCsv(csvRows), "text/csv; charset=utf-8");
    }

    // Create (invite) a teammate. Managers/admins only. If no password is given,
    // a temporary one is generated and returned once so the manager can share it.
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateUserInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageTeam))
            return StatusCode(403, new { error = "Your role cannot add teammates." });

        var prep = await _people.PrepareCreateAsync(input, User.IsSuntechAdmin(), User.UserId());
        if (prep.Refusal is { } refusal)
            return refusal.Conflict ? Conflict(new { error = refusal.Reason }) : BadRequest(new { error = refusal.Reason });

        // Rank. team.manage says you may run a roster; it has never said how high
        // you may appoint into it. Without this a manager passing role: "admin"
        // creates someone above themselves — and then that account can do anything.
        var actor = UserAdminContext.For(User);
        if (!UserAdminPolicy.CanAssignRole(actor, prep.BaseRole))
            return StatusCode(403, new { error = UserAdminPolicy.AssignRoleDenied });

        // Reach. TeamsController.SetMembers has always refused a roster edit on a
        // team you don't belong to; creating a person straight INTO that team is
        // the same write by another door.
        if (prep.ChosenTeam is Guid chosenTeam && !UserAdminPolicy.CanReachTeam(actor, chosenTeam))
            return StatusCode(403, new { error = UserAdminPolicy.CreateTeamDenied });

        var (dto, newId) = await _people.CommitCreateAsync(prep);

        // The self-serve invite link. Only for the auto-provisioned path (no
        // explicit input.Password) — see CreateUserResult's own doc comment.
        bool? inviteSent = null;
        string? inviteError = null;
        if (prep.TempPassword is not null)
            (inviteSent, inviteError) = await _people.SendInviteEmailAsync(newId, BuildInviteUrl);

        return StatusCode(201, new CreateUserResult(dto, prep.TempPassword, inviteSent, inviteError));
    }

    /// <summary>
    /// Builds an absolute link to the accept-invite screen. This API serves the
    /// app's static build itself (see Program.cs / wwwroot/apps) rather than
    /// through a separate host, so the request's own scheme+host IS the app's
    /// origin — the same assumption the device loader
    /// (wwwroot/apps/sales/index.html) and the desktop/web split make already.
    /// `/apps/sales/...` is the loader prefix that picks mobile vs. desktop by
    /// viewport and forwards the query string (the token) unchanged.
    /// </summary>
    private string BuildInviteUrl(string token) =>
        this.AbsoluteUrl($"/apps/sales/accept-invite?token={Uri.EscapeDataString(token)}");

    // Re-sends the invite link, invalidating any still-outstanding one (requirement
    // #7 — a re-invite must never leave a second working link in circulation;
    // InviteTokenService.IssueAsync already does that revoke-then-issue as one
    // step). Managers/admins only, and bounded by the same rank/reach rule as
    // every other write that touches someone else's account.
    [HttpPost("{id:guid}/resend-invite")]
    public async Task<IActionResult> ResendInvite(Guid id)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageTeam))
            return StatusCode(403, new { error = "Your role cannot manage the team." });

        var (denied, gate) = await GateAsync(id);
        if (denied is not null) return denied;

        // Resending only makes sense before the person has ever signed in — once
        // they have a password of their own, "set your password" is no longer
        // the right message (that is what Reset password / self-serve change is
        // for). MustChangePassword is exactly that flag: it is cleared the
        // moment either path lands them a password they chose.
        if (!gate!.MustChangePassword)
            return BadRequest(new { error = "This person has already signed in and set their own password." });

        var (sent, error) = await _people.SendInviteEmailAsync(id, BuildInviteUrl);
        if (!sent)
            return StatusCode(502, new { error = error ?? "The invite email could not be sent." });
        return NoContent();
    }

    // Update a teammate's role or active status. Managers/admins only.
    // PUT /team/{id}/primary-team - which of this person's teams their work
    // counts toward. Null clears it.
    //
    // Its own endpoint rather than a field on PATCH: a nullable Guid there cannot
    // tell "clear it" from "not supplied", and clearing is a real answer -
    // someone on a single team needs no primary, because resolution answers them
    // from that one membership.
    //
    // Same ManageTeam permission and the same GateAsync authority check the role
    // and deactivate paths use, so a manager cannot reach past their own
    // authority through a new door. No self-guard, unlike role/IsActive: setting
    // your own primary team cannot lock you out of anything.
    [HttpPut("{id:guid}/primary-team")]
    public async Task<IActionResult> SetPrimaryTeam(Guid id, [FromBody] PrimaryTeamInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageTeam))
            return StatusCode(403, new { error = "Your role cannot manage the team." });

        var (denied, _) = await GateAsync(id);
        if (denied is not null) return denied;

        var (refusal, dto) = await _people.SetPrimaryTeamAsync(id, input.TeamId, HttpContext.RequestAborted);
        if (refusal is null) return Ok(dto);
        return refusal.NotFound
            ? NotFound(new { error = refusal.Reason })
            : BadRequest(new { error = refusal.Reason });
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateTeamMemberInput input)
    {
        // Managers (and suntech-admins, which are a superset) manage the whole
        // team. Only suntech-admin can additionally delete users (see below).
        if (!User.HasPermission(OrganizationPermissions.ManageTeam))
            return StatusCode(403, new { error = "Your role cannot manage the team." });

        // Guard against locking yourself out (self role change / self-deactivation).
        if (id == User.UserId() && (input.Role != null || input.IsActive == false))
            return BadRequest(new { error = "You can't change your own role or deactivate yourself." });

        // Whom may I touch? Bounded to the org AND the caller's authority — without
        // this a manager can promote any stranger in the org to admin, or demote
        // and deactivate a sitting admin.
        var (denied, gate) = await GateAsync(id);
        if (denied is not null) return denied;

        string? newBaseRole = null;
        if (input.Role != null)
        {
            var resolution = await _people.ResolveRoleAsync(gate!.OrgId, input.Role, User.IsSuntechAdmin());
            if (!resolution.Valid)
                return BadRequest(new { error = "Select a role defined for this organization." });

            // How high may I appoint? Same ceiling as on create — otherwise the
            // invite is guarded and the promotion right after it is not.
            var actor = UserAdminContext.For(User);
            if (!UserAdminPolicy.CanAssignRole(actor, resolution.BaseRole))
                return StatusCode(403, new { error = UserAdminPolicy.AssignRoleDenied });
            newBaseRole = resolution.BaseRole;
        }

        if (await _people.ReactivationRefusalAsync(id, input.IsActive) is { } full)
            return StatusCode(403, new { error = full, code = "usage_limit_reached", meter = "active_users" });

        var updated = await _people.ApplyUpdateAsync(id, input.Role, newBaseRole, input.IsActive, User.UserId());
        if (updated is null) return NotFound(new { error = "User not found" });
        return Ok(updated);
    }

    // Permanently delete a user while KEEPING their data. Their leads, accounts,
    // invoices, AMCs and reminders are reassigned to the acting admin first, so the
    // Profile foreign keys (OnDelete.Cascade) don't take that data with the user.
    // suntech-admin only. To just disable a login, use the deactivate action above.
    // DELETE /team/{id}?reassign=single&to={guid} — hand the departing rep's book
    // to one named person.
    // DELETE /team/{id}?reassign=routing — spread it across the configured lead
    // routing pool (round-robin or least-busy, per Settings > routing).
    //
    // Omitting `reassign` keeps the original behaviour (everything to the acting
    // admin, or a fallback owner for a cross-org delete) so existing callers and
    // scripts don't change meaning.
    [HttpDelete("{id:guid}")]
    // `teamId` answers the one question this can ask: when the person inheriting
    // the leads is in several teams with no primary, there is no way to know
    // which of them the leads now belong to. The first call is refused with the
    // candidates (code `owner_team_choice_required`) and re-sent with an answer.
    public async Task<IActionResult> Delete(
        Guid id, [FromQuery] string? reassign = null, [FromQuery] Guid? to = null,
        [FromQuery] Guid? teamId = null)
    {
        if (!User.IsSuntechAdmin())
            return StatusCode(403, new { error = "Only a suntech-admin can delete users." });

        if (id == User.UserId())
            return BadRequest(new { error = "You can't delete your own account." });

        var (refusal, done) = await _people.DeleteAsync(id, User.UserId(), User.OrgId(), reassign, to, teamId);
        if (refusal is not null)
        {
            if (refusal.NotFound) return NotFound(new { error = refusal.Reason });
            // The answerable refusal carries its options, so the client can ask
            // rather than just report a wall.
            return refusal.Code is null
                ? BadRequest(new { error = refusal.Reason })
                : BadRequest(new { error = refusal.Reason, code = refusal.Code, owner_teams = refusal.OwnerTeams });
        }

        return done ? NoContent() : StatusCode(500);
    }

    // Reset a teammate's password to a value explicitly supplied by an admin.
    [HttpPost("{id:guid}/reset-password")]
    public async Task<IActionResult> ResetPassword(Guid id, [FromBody] ResetPasswordInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageTeam))
            return StatusCode(403, new { error = "Only a manager or suntech-admin can reset passwords." });

        // Setting someone's password is taking their account. It is therefore the
        // same boundary as re-roling them, not a lesser one: a manager who could
        // reset an admin's password would simply sign in as that admin, and the
        // rank rule above would be decoration.
        var (denied, _) = await GateAsync(id);
        if (denied is not null) return denied;

        var refusal = await _people.ResetPasswordAsync(id, input.Password);
        if (refusal is not null)
            return refusal.NotFound ? NotFound(new { error = refusal.Reason }) : BadRequest(new { error = refusal.Reason });

        return NoContent();
    }

    // Follow-up (2026-09-30, owner) — unlink a teammate's bound Microsoft
    // account. Their NEXT Microsoft sign-in binds whichever account they use
    // then, exactly like a first-time link (SsoOAuthProcess.HandleCallbackAsync
    // / SsoStore.BindSubjectAsync). Managers/admins only, and — unlike every
    // other write below — never cross-org even for a suntech-admin: see
    // GateAsync's own comment on forceOwnOrg.
    [HttpDelete("{id:guid}/sso-link")]
    public async Task<IActionResult> UnlinkSso(Guid id)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageTeam))
            return StatusCode(403, new { error = "Your role cannot manage the team." });

        var (denied, _) = await GateAsync(id, forceOwnOrg: true);
        if (denied is not null) return denied;

        var updated = await _people.UnlinkSsoAsync(id, User.UserId());
        if (updated is null) return NotFound(new { error = "User not found" });
        return Ok(updated);
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Privacy;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E22.1 - personal-data requests for ONE person (UAE PDPL / GDPR): the map of where a person's data lives, an export ZIP, an erasure that
/// anonymises in place, the org's retention holds, and the erasure log. Routes, checks the permission, and picks a status code - nothing
/// else (the rules are in PrivacyProcess).
///
/// ADMIN ONLY by default. Gated on privacy.manage ("Personal data requests"), which only the admin base role and the Executive / Owner
/// ready-made role hold until an org grants it: erasure is irreversible and an export hands over everything about a person.
/// </summary>
[ApiController]
[Route("privacy")]
[Authorize]
[RequirePermission(OrganizationPermissions.PrivacyManage)]
[StorageUnavailableFilter]
public class PrivacyController : ControllerBase
{
    private readonly PrivacyExperience _privacy;
    public PrivacyController(PrivacyExperience privacy) => _privacy = privacy;

    // GET /privacy/map - which tables hold a person's data, how a row is tied to the person, what an erasure does, and what is NOT covered.
    [HttpGet("map")]
    public IActionResult Map() => Ok(_privacy.Map());

    // GET /privacy/retention-holds and PUT: the org's holds, per document type or record kind. Empty by default.
    [HttpGet("retention-holds")]
    public async Task<IActionResult> GetHolds() => Ok(await _privacy.GetHoldsAsync());

    [HttpPut("retention-holds")]
    public async Task<IActionResult> PutHolds([FromBody] PrivacyHoldsDto input)
    {
        var (holds, refusal) = await _privacy.SaveHoldsAsync(input);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(holds);
    }

    // GET /privacy/erasures - who erased which subject and when (ids and numbers only), newest first, with the ones still held.
    [HttpGet("erasures")]
    public async Task<IActionResult> Erasures(CancellationToken ct) => Ok(await _privacy.ListLogAsync(ct));

    [HttpPost("contacts/{id:guid}/export")]
    public Task<IActionResult> ExportContact(Guid id, CancellationToken ct) => ExportAsync(PrivacySubjectKinds.Contact, id, ct);

    [HttpPost("leads/{id:guid}/export")]
    public Task<IActionResult> ExportLead(Guid id, CancellationToken ct) => ExportAsync(PrivacySubjectKinds.Lead, id, ct);

    [HttpPost("contacts/{id:guid}/erase")]
    public Task<IActionResult> EraseContact(Guid id, [FromBody] PrivacyEraseInput input, CancellationToken ct) =>
        EraseAsync(PrivacySubjectKinds.Contact, id, input, ct);

    [HttpPost("leads/{id:guid}/erase")]
    public Task<IActionResult> EraseLead(Guid id, [FromBody] PrivacyEraseInput input, CancellationToken ct) =>
        EraseAsync(PrivacySubjectKinds.Lead, id, input, ct);

    private async Task<IActionResult> ExportAsync(string kind, Guid id, CancellationToken ct)
    {
        var (file, refusal) = await _privacy.ExportAsync(kind, id, User.UserId(), ct);
        if (refusal is not null)
            return refusal.NotFound ? NotFound(new { error = refusal.Reason }) : BadRequest(new { error = refusal.Reason });

        Response.Headers["X-Export-Rows"] = file!.RowCount.ToString();
        Response.Headers["X-Export-Files"] = file.FileCount.ToString();
        Response.OnCompleted(() =>
        {
            OrganizationOffboardingService.TryDeleteFile(file.Path);
            return Task.CompletedTask;
        });
        return PhysicalFile(file.Path, "application/zip", file.Filename, enableRangeProcessing: false);
    }

    private async Task<IActionResult> EraseAsync(string kind, Guid id, PrivacyEraseInput? input, CancellationToken ct)
    {
        var (result, refusal) = await _privacy.EraseAsync(kind, id, input?.Confirm, User.UserId(), ct);
        if (refusal is not null)
            return refusal.NotFound ? NotFound(new { error = refusal.Reason }) : BadRequest(new { error = refusal.Reason });
        return Ok(result);
    }
}

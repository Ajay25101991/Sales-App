using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Services;

namespace SalesApi.Controllers;

[ApiController]
[Route("dashboard")]
[Authorize]
public class DashboardController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly CallerContext _caller;
    // The dashboard builders moved to ProcessLayer.Dashboard.DashboardProcess.
    // `_db` stays for the two forecast-config endpoints and for resolving the
    // caller's own scope — both authorization work, not domain queries.
    private readonly SalesApi.ExperienceLayer.Dashboard.DashboardExperience _dashboard;
    public DashboardController(AppDbContext db, CallerContext caller, SalesApi.ExperienceLayer.Dashboard.DashboardExperience dashboard)
    {
        _db = db;
        _caller = caller;
        _dashboard = dashboard;
    }

    // Pipeline stats for the current rep, or the whole team for managers/admins.
    // `tagIds` (comma-separated) re-scopes every figure that CAN honestly be
    // re-scoped by tag to leads carrying any of the given tags — see
    // `TagFilteredAsync` below for exactly which figures that is and, just as
    // important, which one it deliberately leaves alone.
    //
    // `teamId` (org-admin/manager team filter, 2026-08-27) narrows every figure
    // further, to ONE team's records — an AND on top of the existing people
    // scope below, never a widening of it (see the refusal check right after
    // `access` is resolved). Accepts the real team-less sentinel
    // (`AggregateOwner.Unassigned`, i.e. `Guid.Empty`) as a selectable value —
    // "No team" — because those records are already inside whatever the
    // caller's people scope admits (RecordAccess: an owned-but-team-less
    // record is visible only to its owner and org admins), so surfacing them
    // as their own bucket cannot expose anything the caller could not already
    // see; leaving it out would make them invisible under every real team
    // filter while still counting in the org total, which is the reporting
    // gap the task called out.
    [HttpGet]
    public async Task<IActionResult> Get(
        [FromQuery] string period = "month", [FromQuery] string? tagIds = null, [FromQuery] Guid? teamId = null)
    {
        var now = DateTime.UtcNow;
        // Which calendar MONTH "this month" is (the target tile and the monthly
        // grain) is the org's, not UTC's — on the 1st at 02:00 local a UTC month
        // is still the previous one. `now` itself stays the absolute instant:
        // the idle/overdue cutoffs below are elapsed time, not a boundary.
        var cal = await ReportingCalendar.ForAsync(_db);
        // Four ranges now. "week"/"month" (unrecognized values fall back to
        // month, same as before this DTO widening — see AggregatedAsync/
        // TagFilteredAsync) are ROLLING windows ending today (Type A —
        // DealStatsService's own header comment). "year" is a WINDOW too, but a
        // calendar one — the org-local current year, closed months of which
        // never change again, so it reads the monthly grain rather than the
        // rolling one (see AggregatedAsync). "all" has no floor at all —
        // owner decision, mirroring desktop/src/screens/leaderboard.tsx's
        // existing `{ value: 'all', label: 'All time' }` vocabulary, the
        // closest precedent in the app for a fourth range on this exact
        // Week/Month control.
        var idleDays = await OrgSettings.GetIdleDaysAsync(_db);
        var valuesVisible = User.HasPermission(OrganizationPermissions.ViewLeadValues);

        // Team scoping: every table/query read here is keyed by owner, so the
        // scope is a set of PEOPLE (Services/TeamScoping.cs). null means no
        // restriction — the org admin, who still sums the whole org. Applied
        // identically on both paths below, so a tag filter can never widen what
        // someone can see.
        // E18.1: the scope resolution below (the team refusal, `people`, `statsPeople`) moved verbatim into ScopeAsync so the raw-aggregate reads
        // share it; its comments travelled with it.
        var (refusal, people, statsPeople) = await ScopeAsync(teamId);
        if (refusal is not null) return refusal;
        var tagIdList = (tagIds ?? "")
            .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(s => Guid.TryParse(s, out var g) ? (Guid?)g : null)
            .Where(g => g != null).Select(g => g!.Value).ToList();

        var dto = tagIdList.Count > 0
            ? await _dashboard.TagFilteredAsync(people, statsPeople, tagIdList, period, cal, now, idleDays, valuesVisible, teamId)
            : await _dashboard.AggregatedAsync(people, statsPeople, period, cal, now, idleDays, valuesVisible, teamId);

        return Ok(dto);
    }

    // The caller's scope for every dashboard read: the people whose records they may see (`people`, null = unrestricted), the same list widened with
    // the unassigned bucket where their record scope admits it (`statsPeople`), or a 403 refusal for a team outside their reach.
    private async Task<(IActionResult? Refusal, List<Guid>? People, List<Guid>? StatsPeople)> ScopeAsync(Guid? teamId)
    {
        var access = await _caller.ForAsync(User);

        // SECURITY: a real team must be inside the caller's own scope. Mirrors
        // TeamsController.CanAdminister / SettingsController.CanConfigureTeam
        // (both `user.IsOrgAdmin() || user.TeamScope().Covers(teamId)`) — the
        // existing, already-audited answer to "which teams may this caller
        // reach", reused rather than a second scoping mechanism invented for
        // this endpoint. `Covers` alone already returns true for an org admin
        // (their hydrated scope is AllTeams — see OrganizationRoleService's
        // middleware), so `IsOrgAdmin` here is belt-and-braces, matching the
        // cited precedent exactly rather than trusting that invariant silently.
        // The team-less sentinel is exempt (see the class-adjacent comment) —
        // it names no team roster to be outside of.
        if (AggregateOwner.TeamOutsideScope(access, teamId))
            return (StatusCode(403, new { error = "You do not have access to that team's figures." }), null, null);

        var people = await PeopleScope.VisibleIdsAsync(_db, access);
        // Owner-less leads waiting in the routing queue are IN, for any caller
        // whose record scope already admits them (C6/M5 — see
        // AggregateOwner.VisibleTo). This is the ONE place the decision is made:
        // both paths below read `statsPeople`, so a tag filter can no longer
        // change WHICH leads are counted, only which of them carry the tag.
        //
        // It also settles a split that already existed: the tag path's owner
        // predicate was `people == null || (l.OwnerId != null && ...)`, so an org
        // admin (people == null) counted unassigned leads and a team-scoped
        // manager did not — one tile reading differently by viewer.
        //
        // `people` itself is left alone for MonthlyTargetAsync: a target is a row
        // in `targets` keyed by a real user, and the sentinel would just be an id
        // that matches nothing.
        var statsPeople = AggregateOwner.WidenScope(people, access);
        return (null, people, statsPeople);
    }

    // E18.1 - the raw stored rows of the pipeline snapshot, split by the org's chosen account field (Dimension "" = off: the rows are then the plain
    // snapshot). Same scope and team refusal as GET /dashboard; lead values are masked at the edge for a caller without ViewLeadValues.
    [HttpGet("pipeline-by-account-field")]
    public async Task<IActionResult> PipelineByAccountField([FromQuery] Guid? teamId = null)
    {
        var (refusal, _, statsPeople) = await ScopeAsync(teamId);
        if (refusal is not null) return refusal;
        return Ok(await _dashboard.PipelineByAccountFieldAsync(statsPeople, teamId, User.HasPermission(OrganizationPermissions.ViewLeadValues)));
    }

    // E18.1 - the raw stored stage-entry rows (deals entering each stage per org-local month) for the months covering from..to (yyyy-MM-dd, the org's
    // local days; default: the last 12 months to today). Same scope and team refusal as GET /dashboard.
    [HttpGet("stage-entries")]
    public async Task<IActionResult> StageEntries(
        [FromQuery(Name = "from")] DateOnly? fromQuery = null, [FromQuery(Name = "to")] DateOnly? toQuery = null, [FromQuery] Guid? teamId = null)
    {
        var today = ReportingCalendar.Today(await ReportingCalendar.ForAsync(_db));
        var toDay = toQuery ?? today;
        var fromDay = fromQuery ?? new DateOnly(toDay.Year, toDay.Month, 1).AddMonths(-11);
        if (fromDay > toDay) return BadRequest(new { error = "from must not be after to." });
        if ((toDay.Year * 12 + toDay.Month) - (fromDay.Year * 12 + fromDay.Month) >= MaxStageEntryMonths)
            return BadRequest(new { error = $"Ask for at most {MaxStageEntryMonths} months at a time." });
        var (refusal, _, statsPeople) = await ScopeAsync(teamId);
        if (refusal is not null) return refusal;
        return Ok(await _dashboard.StageEntriesAsync(fromDay, toDay, statsPeople, teamId));
    }

    private const int MaxStageEntryMonths = 120;

    // E18.1 part 3 - the raw stored AMC-renewal rows (terms due vs renewed per month, by contract owner / playbook / team) for the months covering
    // from..to (default: the last 12 months to today; pass `to` to see upcoming months). Same scope and team refusal as stage-entries; the two
    // values are masked at the edge for a caller without ViewLeadValues (the dashboard's money permission). Months after the current one are `partial`.
    [HttpGet("amc-renewals")]
    public async Task<IActionResult> AmcRenewals(
        [FromQuery(Name = "from")] DateOnly? fromQuery = null, [FromQuery(Name = "to")] DateOnly? toQuery = null, [FromQuery] Guid? teamId = null)
    {
        var today = ReportingCalendar.Today(await ReportingCalendar.ForAsync(_db));
        var toDay = toQuery ?? today;
        var fromDay = fromQuery ?? new DateOnly(toDay.Year, toDay.Month, 1).AddMonths(-11);
        if (fromDay > toDay) return BadRequest(new { error = "from must not be after to." });
        if ((toDay.Year * 12 + toDay.Month) - (fromDay.Year * 12 + fromDay.Month) >= MaxStageEntryMonths)
            return BadRequest(new { error = $"Ask for at most {MaxStageEntryMonths} months at a time." });
        var (refusal, _, statsPeople) = await ScopeAsync(teamId);
        if (refusal is not null) return refusal;
        return Ok(await _dashboard.AmcRenewalsAsync(
            fromDay, toDay, today, statsPeople, teamId, User.HasPermission(OrganizationPermissions.ViewLeadValues)));
    }

    // The default, fast path: every figure comes from the pre-aggregated tables
    // — this endpoint does not load leads at all when no tag filter is asked
    // for. It used to materialize every lead in the org and loop in memory,
    // which is what made the dashboard scale with pipeline size rather than
    // with the number of stages; this keeps that property for the common case.
    [HttpGet("forecast-config")]
    public async Task<IActionResult> GetForecastConfig()
    {
        var (values, defaulted) = await ForecastService.GetWithDefaultedAsync(_db);
        return Ok(new ForecastConfigDto(values, defaulted));
    }

    [HttpPut("forecast-config")]
    public async Task<IActionResult> SetForecastConfig([FromBody] ForecastConfigInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePipeline))
            return StatusCode(403, new { error = "Your role cannot manage forecast configuration." });
        await ForecastService.SaveAsync(_db, input.Probabilities ?? new());
        var (values, defaulted) = await ForecastService.GetWithDefaultedAsync(_db);
        return Ok(new ForecastConfigDto(values, defaulted));
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.WhatsApp;
using SalesApi.ProcessLayer.WhatsApp;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E6.4 (design doc to-do/e6-connectors-design.md §2/§3, §7.2) — the
/// authenticated WhatsApp surface on a lead: the composer's window state and
/// the send action. Routes, checks permission, picks a status code — nothing
/// else, per CLAUDE.md.
///
/// ONE <c>_db</c> use via <see cref="CallerContext"/>, the same documented
/// exemption <see cref="SettingsController"/>/<see cref="AccountsController"/>
/// already carry: building the caller's <c>RecordAccessContext</c> needs both
/// the <c>ClaimsPrincipal</c> and the database.
/// </summary>
[ApiController]
[Authorize]
public class WhatsAppController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly WhatsAppExperience _whatsapp;
    private readonly WhatsAppTemplatesExperience _templates;

    public WhatsAppController(CallerContext caller, WhatsAppExperience whatsapp, WhatsAppTemplatesExperience templates)
    {
        _caller = caller;
        _whatsapp = whatsapp;
        _templates = templates;
    }

    // GET /leads/{id}/whatsapp — the composer's window state (design §7.2).
    // Any caller who may VIEW the lead sees this — no separate permission
    // needed just to know whether messaging is currently allowed.
    [HttpGet("leads/{id:guid}/whatsapp")]
    public async Task<IActionResult> GetWindow(Guid id)
    {
        var ctx = await _caller.ForAsync(User);
        var (refusal, dto) = await _whatsapp.GetWindowAsync(ctx, id);
        return refusal switch
        {
            { NotFound: true } => NotFound(new { error = refusal.Reason }),
            { Forbidden: true } => StatusCode(403, new { error = refusal.Reason }),
            not null => BadRequest(new { error = refusal.Reason }),
            _ => Ok(dto),
        };
    }

    // POST /leads/{id}/whatsapp — send a session message OR a template
    // message (design §3.3/§3.4, E6.4 finish slice 5; owner answer 4: the
    // NEW "Send WhatsApp" permission, checked here before the lead-access
    // check WhatsAppSendProcess itself makes).
    // E7.6 — WhatsApp sending is gated on the org's plan (feature) and, if the
    // plan sets one, a monthly message cap (meter) — both checked here, the
    // single choke point every send passes through.
    [HttpPost("leads/{id:guid}/whatsapp")]
    [RequirePlanFeature(PlanCatalogue.Features.WhatsApp, PlanCatalogue.Meters.WhatsAppMessagesPerMonth)]
    public async Task<IActionResult> Send(Guid id, [FromBody] WhatsAppSendInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.SendWhatsApp))
            return StatusCode(403, new { error = "Your role does not have the 'Send WhatsApp' permission." });

        var ctx = await _caller.ForAsync(User);
        var (refusal, dto) = !string.IsNullOrWhiteSpace(input.TemplateName)
            ? await _whatsapp.SendTemplateAsync(ctx, User.UserId(), id, input.TemplateName, input.TemplateLanguage, input.TemplateParams)
            : await _whatsapp.SendAsync(ctx, User.UserId(), id, input.Body);
        return refusal switch
        {
            { NotFound: true } => NotFound(new { error = refusal.Reason }),
            { Forbidden: true } => StatusCode(403, new { error = refusal.Reason }),
            not null => BadRequest(new { error = refusal.Reason }),
            _ => Ok(dto),
        };
    }

    // GET /whatsapp/templates — the composer's template picker (design §3.4/
    // §7.2), E6.4 finish slice 5. Same "anyone who may view a lead may see
    // what templates exist" posture GetWindow already takes — the send
    // permission gate is on the SEND action, not on reading the catalog.
    [HttpGet("whatsapp/templates")]
    public async Task<IActionResult> ListTemplates() => Ok(await _templates.ListApprovedAsync());

    // POST /whatsapp/templates/sync — the manual "Sync templates now" button
    // (design §3.4), same manager-only posture POST /reminders/sweep uses for
    // its own manual trigger.
    [HttpPost("whatsapp/templates/sync")]
    public async Task<IActionResult> SyncTemplates()
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Managers only." });
        var result = await _templates.SyncNowAsync();
        return result.Ok ? Ok(result) : BadRequest(result);
    }
}

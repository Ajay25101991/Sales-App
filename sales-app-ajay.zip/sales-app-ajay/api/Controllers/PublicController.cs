using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Public;
using SalesApi.ProcessLayer.Public;

namespace SalesApi.Controllers;

// Public (no-auth) inbound endpoint for website contact forms. Protected by an
// API key (X-Api-Key header) managed under Settings → inbound.
//
// API-led migration (step 8): routing, [AllowAnonymous], rate limiting and
// status selection stay here. Everything else — the API-key check (both the
// new hashed-key table and the legacy plaintext fallback), tenant scoping,
// de-dupe, source resolution and owner routing — lives in
// SalesApi.ExperienceLayer.Public.PublicIntakeExperience / ProcessApi /
// SystemApi, moved verbatim rather than rewritten: this is the one endpoint a
// stranger can reach, so nothing here widens what is accepted, changes how
// the key is checked, or lets the caller name an owner (the owner is always
// resolved server-side by LeadRoutingService.PickOwnerAsync).
[ApiController]
[Route("public")]
[EnableRateLimiting("public-intake")]
[AllowAnonymous]
public class PublicController : ControllerBase
{
    private readonly PublicIntakeExperience _intake;
    public PublicController(PublicIntakeExperience intake) => _intake = intake;

    // POST /public/leads  { name, email, phone, company, message, phone_country_code }  + X-Api-Key.
    // phone_country_code (ISO 3166-1 alpha-2, e.g. "AE") is optional — see
    // PublicIntakeProcess.CreateLeadAsync for validation and how it's used.
    [HttpPost("leads")]
    public async Task<IActionResult> CreateLead([FromBody] PublicLeadInput input, CancellationToken ct)
    {
        var provided = Request.Headers["X-Api-Key"].FirstOrDefault();
        var result = await _intake.CreateLeadAsync(provided, input, ct);
        return result.Outcome switch
        {
            PublicIntakeProcess.Outcome.Unauthorized => Unauthorized(new { error = result.Error }),
            PublicIntakeProcess.Outcome.BadRequest => BadRequest(new { error = result.Error }),
            PublicIntakeProcess.Outcome.ServerError => StatusCode(500, new { error = result.Error }),
            PublicIntakeProcess.Outcome.Duplicate => Ok(new { ok = true, duplicate = true }),
            _ => StatusCode(201, new { ok = true, id = result.LeadId }),
        };
    }
}

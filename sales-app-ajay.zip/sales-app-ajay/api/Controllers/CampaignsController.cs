using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Campaigns;
using SalesApi.ProcessLayer.Campaigns;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E21 - email campaigns: create a campaign (a saved contacts view, an optional buying role, a template per language, a marketing from-address and reply-to),
/// see who it would reach, preview a message, test-send it to yourself, schedule and cancel it, and read the results. Routes, checks the permission and picks a
/// status code - nothing else (the rules are in CampaignProcess).
///
/// EVERY endpoint needs campaigns.send (the admin base role has it; the roles matrix grants it to others). Sending itself runs under the record access of the
/// person who scheduled the campaign, rebuilt at send time. The from-address and send-rate settings are managed on <see cref="CampaignSettingsController"/>
/// (settings.manage); the list of from-addresses is readable here because the composer needs it.
/// </summary>
[ApiController]
[Route("campaigns")]
[Authorize]
[RequirePermission(OrganizationPermissions.SendCampaigns)]
public class CampaignsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly CampaignsExperience _campaigns;

    public CampaignsController(CallerContext caller, CampaignsExperience campaigns)
    {
        _caller = caller;
        _campaigns = campaigns;
    }

    private Task<RecordAccessContext> AccessAsync() => _caller.ForAsync(User);

    internal static IActionResult FromRefusal(CampaignProcess.Refusal r) =>
        r.NotFound ? new NotFoundObjectResult(new { error = r.Reason })
        : r.Forbidden ? new ObjectResult(new { error = r.Reason }) { StatusCode = 403 }
        : r.Conflict ? new ConflictObjectResult(new { error = r.Reason, code = r.Code })
        : new BadRequestObjectResult(new { error = r.Reason, code = r.Code });

    private IActionResult Respond<T>(CampaignProcess.Result<T> result, int okStatus = 200) =>
        result.Refusal is not null ? FromRefusal(result.Refusal) : StatusCode(okStatus, result.Value);

    // GET /campaigns?status= - newest first, each with its totals.
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] string? status) => Ok(await _campaigns.ListAsync(status, HttpContext.RequestAborted));

    // GET /campaigns/from-addresses - the org's marketing from-addresses (the composer's picker).
    [HttpGet("from-addresses")]
    public async Task<IActionResult> FromAddresses() => Ok(await _campaigns.FromAddressesAsync(HttpContext.RequestAborted));

    // POST /campaigns - a draft. 201.
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CampaignInput input) =>
        Respond(await _campaigns.CreateAsync(await AccessAsync(), input, HttpContext.RequestAborted), 201);

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id) => Respond(await _campaigns.GetAsync(id, HttpContext.RequestAborted));

    // PUT /campaigns/{id} - a draft only (409 otherwise).
    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] CampaignInput input) =>
        Respond(await _campaigns.UpdateAsync(await AccessAsync(), id, input, HttpContext.RequestAborted));

    // DELETE /campaigns/{id} - a draft only (409 otherwise). 204.
    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var refusal = await _campaigns.DeleteAsync(id, HttpContext.RequestAborted);
        return refusal is not null ? FromRefusal(refusal) : NoContent();
    }

    // GET /campaigns/{id}/recipients-preview - counts (will_send, opted_out, undeliverable, no_email, duplicate) and a sample, with the CALLER's record access.
    [HttpGet("{id:guid}/recipients-preview")]
    public async Task<IActionResult> PreviewRecipients(Guid id) =>
        Respond(await _campaigns.PreviewAudienceAsync(
            await AccessAsync(), User.HasPermission(OrganizationPermissions.ViewContactDetails), User.Role(), id, HttpContext.RequestAborted));

    // GET /campaigns/{id}/preview?contact_id= - the rendered message one contact would get.
    [HttpGet("{id:guid}/preview")]
    public async Task<IActionResult> PreviewMessage(Guid id, [FromQuery(Name = "contact_id")] Guid? contactId)
    {
        if (contactId is not Guid contact) return BadRequest(new { error = "contact_id is required" });
        return Respond(await _campaigns.PreviewMessageAsync(await AccessAsync(), id, contact, HttpContext.RequestAborted));
    }

    // POST /campaigns/{id}/test-send - to the CALLER's own address only.
    [HttpPost("{id:guid}/test-send")]
    public async Task<IActionResult> TestSend(Guid id, [FromBody(EmptyBodyBehavior = Microsoft.AspNetCore.Mvc.ModelBinding.EmptyBodyBehavior.Allow)] CampaignTestSendInput? input) =>
        Respond(await _campaigns.TestSendAsync(await AccessAsync(), id, input ?? new CampaignTestSendInput(null, null), HttpContext.RequestAborted));

    // POST /campaigns/{id}/schedule - { now: true } or { scheduled_at }. 409 while marketing mail cannot be sent (code marketing_email_unavailable).
    [HttpPost("{id:guid}/schedule")]
    public async Task<IActionResult> Schedule(Guid id, [FromBody] CampaignScheduleInput input) =>
        Respond(await _campaigns.ScheduleAsync(await AccessAsync(), id, input, HttpContext.RequestAborted));

    [HttpPost("{id:guid}/cancel")]
    public async Task<IActionResult> Cancel(Guid id) => Respond(await _campaigns.CancelAsync(id, HttpContext.RequestAborted));

    // GET /campaigns/{id}/recipients?status=&limit=&offset= - the send queue and its outcomes.
    [HttpGet("{id:guid}/recipients")]
    public async Task<IActionResult> Recipients(Guid id, [FromQuery] string? status, [FromQuery] int? limit, [FromQuery] int? offset) =>
        Respond(await _campaigns.RecipientsAsync(id, status, limit, offset, HttpContext.RequestAborted));
}

/// <summary>
/// E21 - the admin side of campaigns: the marketing from-addresses and the send-rate / SES settings. Gated on settings.manage (the owner's "Manage settings"),
/// separate from campaigns.send on purpose: who may configure what the org sends from is not who may send.
/// </summary>
[ApiController]
[Route("campaign-settings")]
[Authorize]
[RequirePermission(OrganizationPermissions.ManageSettings)]
public class CampaignSettingsController : ControllerBase
{
    private readonly CampaignsExperience _campaigns;
    public CampaignSettingsController(CampaignsExperience campaigns) => _campaigns = campaigns;

    private IActionResult Respond<T>(CampaignProcess.Result<T> result, int okStatus = 200) =>
        result.Refusal is not null ? CampaignsController.FromRefusal(result.Refusal) : StatusCode(okStatus, result.Value);

    // GET /campaign-settings - { sends_per_second, ses_region, ses_configuration_set, ses_configured, ses_problem }.
    [HttpGet]
    public async Task<IActionResult> Get() => Ok(await _campaigns.GetSettingsAsync(HttpContext.RequestAborted));

    [HttpPut]
    public async Task<IActionResult> Save([FromBody] CampaignSettingsInput input) => Respond(await _campaigns.SaveSettingsAsync(input, HttpContext.RequestAborted));

    [HttpGet("from-addresses")]
    public async Task<IActionResult> FromAddresses() => Ok(await _campaigns.FromAddressesAsync(HttpContext.RequestAborted));

    [HttpPost("from-addresses")]
    public async Task<IActionResult> CreateFromAddress([FromBody] MarketingFromAddressInput input) =>
        Respond(await _campaigns.CreateFromAddressAsync(input, HttpContext.RequestAborted), 201);

    [HttpPut("from-addresses/{id:guid}")]
    public async Task<IActionResult> UpdateFromAddress(Guid id, [FromBody] MarketingFromAddressInput input) =>
        Respond(await _campaigns.UpdateFromAddressAsync(id, input, HttpContext.RequestAborted));

    // 409 while a campaign uses it.
    [HttpDelete("from-addresses/{id:guid}")]
    public async Task<IActionResult> DeleteFromAddress(Guid id)
    {
        var refusal = await _campaigns.DeleteFromAddressAsync(id, HttpContext.RequestAborted);
        return refusal is not null ? CampaignsController.FromRefusal(refusal) : NoContent();
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Attachments;
using SalesApi.ProcessLayer.Attachments;
using SalesApi.Services;

namespace SalesApi.Controllers;

[ApiController]
[Route("attachments")]
[Authorize]
[StorageUnavailableFilter]
public class AttachmentsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly ITenantProvider _tenant;
    private readonly AttachmentsExperience _attachments;

    public AttachmentsController(CallerContext caller, ITenantProvider tenant, AttachmentsExperience attachments)
    {
        _caller = caller;
        _tenant = tenant;
        _attachments = attachments;
    }

    private Task<RecordAccessContext> AccessContextAsync() => _caller.ForAsync(User);

    // The permission the record's OWN endpoints sit behind (accounts: contact_details.view; invoices and AMCs:
    // financials.view). Resolved here, handed down as data - the Process class never reads the principal.
    private AttachmentPermissions Permissions() => User.FileAccess();

    /// <summary>The one place a refusal becomes a status code (404 not found / 403 not allowed / 400 otherwise).</summary>
    private static IActionResult FromRefusal(AttachmentProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : refusal.Upstream ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 502 }
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 403 }
        : new BadRequestObjectResult(new { error = refusal.Reason });

    // GET /attachments?record_type=lead|account|quote|invoice|amc&record_id=...
    // GET /attachments?leadId=...  (the phone apps' form - means record_type=lead)
    // GET /attachments?leadId=...&include_quotes=true  (E13: a lead's files PLUS the files on its quotes - the gate-link picker's list)
    [HttpGet]
    public async Task<IActionResult> List(
        [FromQuery] Guid leadId,
        [FromQuery(Name = "record_type")] string? recordType = null,
        [FromQuery(Name = "record_id")] Guid? recordId = null,
        [FromQuery(Name = "include_quotes")] bool includeQuotes = false)
    {
        var (type, id, bad) = AttachmentsExperience.Target(leadId, recordType, recordId);
        if (bad is not null) return FromRefusal(bad);
        var (refusal, files) = await _attachments.ListAsync(await AccessContextAsync(), Permissions(), type, id, default, includeQuotes);
        return refusal is not null ? FromRefusal(refusal) : Ok(files);
    }

    // POST /attachments  (multipart: field "file", body "record_type" + "record_id", or the legacy "leadId")
    [HttpPost]
    [RequestSizeLimit(UploadLimits.StaffRequestBytes)]
    public async Task<IActionResult> Upload(
        [FromForm] Guid leadId, [FromForm] string? tag, IFormFile? file,
        [FromForm(Name = "record_type")] string? recordType = null,
        [FromForm(Name = "record_id")] Guid? recordId = null)
    {
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required" });
        var (type, id, bad) = AttachmentsExperience.Target(leadId, recordType, recordId);
        if (bad is not null) return FromRefusal(bad);

        await using var stream = file.OpenReadStream();
        var result = await _attachments.UploadAsync(
            await AccessContextAsync(), Permissions(), type, id, User.UserId(), User.OrgId(),
            file.FileName, file.ContentType, file.Length, stream, tag, HttpContext.RequestAborted);

        return result.Outcome switch
        {
            AttachmentProcess.UploadOutcome.Refused => FromRefusal(result.Refusal!),
            // Business-card discard policy: the client asked to save a photo the
            // org has configured NOT to keep - not an error, the upload simply
            // has no bytes to persist.
            AttachmentProcess.UploadOutcome.DiscardedByPolicy => Ok(new { discarded = true }),
            _ => StatusCode(201, result.Attachment),
        };
    }

    // POST /attachments/links { record_type, record_id, items: [ { drive_id, item_id } ] } - link files that already live in
    // SharePoint (Phase 4). Same record access as an upload; each item is re-read with the CALLER's own Microsoft token.
    // 409 { error, state } when the caller cannot browse SharePoint right now (same body as /sharepoint/browse/*).
    [HttpPost("links")]
    public async Task<IActionResult> Link([FromBody] AttachmentLinkInput input)
    {
        var result = await _attachments.LinkAsync(await AccessContextAsync(), Permissions(), input, User.UserId(), HttpContext.RequestAborted);
        if (result.NotReadyState is { } state)
            return Conflict(new SharePointBrowseRefusedDto(result.NotReadyMessage ?? "You cannot browse SharePoint right now.", state));
        return result.Refusal is not null ? FromRefusal(result.Refusal) : StatusCode(201, result.Files);
    }

    // GET /attachments/{id}/file
    [HttpGet("{id:guid}/file")]
    public async Task<IActionResult> Download(Guid id)
    {
        var result = await _attachments.DownloadAsync(await AccessContextAsync(), Permissions(), id, HttpContext.RequestAborted);
        if (result.Refusal is not null) return FromRefusal(result.Refusal);
        // A SharePoint link has no bytes here: the client opens its web_url instead.
        if (result.IsSharePointLink) return Conflict(new { error = AttachmentRules.LinkHasNoFile });
        if (result.FileMissing) return NotFound(new { error = "File missing" });
        // The saved name is the Files list's name (DownloadFileName.Of leaves it as stored); filename* carries non-ASCII names.
        Response.Headers.ContentDisposition = DownloadFileName.ContentDisposition(result.Filename);
        return File(result.Stream!, result.MimeType ?? "application/octet-stream");
    }

    // DELETE /attachments/{id}  (uploader, or whoever may manage the record)
    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var refusal = await _attachments.DeleteAsync(await AccessContextAsync(), Permissions(), id, User.UserId(), HttpContext.RequestAborted);
        return refusal is not null ? FromRefusal(refusal) : NoContent();
    }

    // POST /attachments/{id}/gate-links { stage, requirement_key } - let a file already on a deal meet one of its stage's file gates
    // (linked, not relabelled or copied). 200 with the file; 404 not visible; 400 not a deal's file / no such gate.
    [HttpPost("{id:guid}/gate-links")]
    public async Task<IActionResult> LinkGate(Guid id, [FromBody] AttachmentGateLinkInput input)
    {
        var (refusal, file) = await _attachments.LinkGateAsync(
            await AccessContextAsync(), Permissions(), id, input, User.UserId(), HttpContext.RequestAborted);
        return refusal is not null ? FromRefusal(refusal) : Ok(file);
    }

    // DELETE /attachments/{id}/gate-links?stage=&requirement_key= - 204; the file stays.
    [HttpDelete("{id:guid}/gate-links")]
    public async Task<IActionResult> UnlinkGate(Guid id, [FromQuery] string? stage, [FromQuery(Name = "requirement_key")] string? requirementKey)
    {
        var refusal = await _attachments.UnlinkGateAsync(
            await AccessContextAsync(), Permissions(), id, stage, requirementKey, HttpContext.RequestAborted);
        return refusal is not null ? FromRefusal(refusal) : NoContent();
    }

    // GET/PUT /attachments/storage-provider — which backend (S3 or a local
    // disk folder) an org's NEW attachment uploads write to. Same
    // GET-effective-value / manager-only-PUT shape as AmcsController's
    // value-change-policy and card-scan-retention below. Switching stamps
    // every existing row of this org that is still unset with the OUTGOING
    // provider before flipping the config, so an object already written
    // under the old provider keeps resolving there — only new uploads move.
    // See AttachmentStorageService.SetProviderAsync.
    [HttpGet("storage-provider")]
    public async Task<IActionResult> GetStorageProvider() =>
        Ok(await _attachments.CurrentStorageProviderAsync(_tenant.OrgId, HttpContext.RequestAborted));

    [HttpPut("storage-provider")]
    public async Task<IActionResult> SetStorageProvider([FromBody] AttachmentStorageProviderInput input)
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can change this." });

        var result = await _attachments.SetStorageProviderAsync(_tenant.OrgId, input.Provider, HttpContext.RequestAborted);
        if (!result.Valid)
            return BadRequest(new { error = $"provider must be one of: {string.Join(", ", _attachments.AvailableStorageProviders)}" });
        return Ok(result.Dto);
    }

    // GET/PUT /attachments/card-scan-retention — owner decision §45: whether a
    // scanned business card's PHOTO is kept, and for how long, is an org
    // setting. Same GET-effective-value / manager-only-PUT shape as
    // AmcsController's value-change-policy.
    [HttpGet("card-scan-retention")]
    public async Task<IActionResult> GetCardScanRetention() =>
        Ok(await _attachments.GetCardScanRetentionAsync(HttpContext.RequestAborted));

    [HttpPut("card-scan-retention")]
    public async Task<IActionResult> SetCardScanRetention([FromBody] CardScanRetentionInput input)
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can change this." });
        return Ok(await _attachments.SetCardScanRetentionAsync(input.Mode, input.RetentionDays, HttpContext.RequestAborted));
    }

    // GET/PUT /attachments/deleted-record-retention - what happens to a record's files when the record (lead,
    // account, quote, invoice, AMC) is deleted: delete_now | keep_for_days | keep_forever. Same
    // GET-effective-value / manager-only-PUT shape as card-scan-retention above.
    [HttpGet("deleted-record-retention")]
    public async Task<IActionResult> GetDeletedRecordRetention() =>
        Ok(await _attachments.GetDeletedRecordRetentionAsync(HttpContext.RequestAborted));

    [HttpPut("deleted-record-retention")]
    public async Task<IActionResult> SetDeletedRecordRetention([FromBody] DeletedRecordRetentionInput input)
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can change this." });
        return Ok(await _attachments.SetDeletedRecordRetentionAsync(input.Mode, input.RetentionDays, HttpContext.RequestAborted));
    }
}

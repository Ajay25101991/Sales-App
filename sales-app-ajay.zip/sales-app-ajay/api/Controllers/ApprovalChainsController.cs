using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Approvals;
using SalesApi.ProcessLayer.Approvals;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Approval chains (E2.6 slice 9, to-do/e2-automation-design.md §8) — an
/// org-configurable layer above the fixed <see cref="Models.ApprovalTypes"/>
/// request types. Two surfaces:
///
/// 1. ADMIN CRUD (list/get/create/update/delete/reorder) — gated by
///    <see cref="OrganizationPermissions.ManageSettings"/>, the SAME
///    permission the "Approvals" settings group already uses for the
///    gate-escalation approver/self-decision policies
///    (<c>SettingsController.SetGateEscalation</c>) — mirrored here rather
///    than the automation builder's stricter <c>User.IsOrgAdmin()</c> base-role
///    gate, per the story brief's own instruction to mirror "the approvals
///    settings", not the automation builder.
/// 2. THE PER-STEP DECIDE ENDPOINT — [Authorize] only at the HTTP layer,
///    because who may decide a step is a fact only <see
///    cref="ApprovalChainProcess.DecideStepAsync"/> can resolve (the step's
///    own approver-kind, team scope, self-decision policy) — the same
///    dispatch-inside-Process shape <c>ApprovalProcess.DecideAsync</c> already
///    uses for GateException's org-configured approver policy.
///
/// UNLIKE <see cref="ApprovalsController"/>, this controller holds NO
/// <c>AppDbContext</c> of its own (<c>ControllerDependencyTests</c>' "this
/// list must only shrink" ratchet on <c>MayHoldDbContext</c>) — the caller's
/// scope comes from <see cref="CallerContext"/> (which holds its own db
/// internally, the sanctioned way), and the self-decision policy read that
/// would otherwise need one lives inside <see
/// cref="ApprovalChainProcess.DecideStepAsync"/> instead, which already holds
/// a db for <c>PeopleScope.VisibleIdsAsync</c> (the same documented Process
/// exemption <c>ApprovalProcess</c> itself uses).
/// </summary>
[ApiController]
[Route("approval-chains")]
[Authorize]
public class ApprovalChainsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly ApprovalChainsExperience _chains;
    private readonly ApprovalsExperience _approvals;

    public ApprovalChainsController(CallerContext caller, ApprovalChainsExperience chains, ApprovalsExperience approvals)
    {
        _caller = caller;
        _chains = chains;
        _approvals = approvals;
    }

    private IActionResult Forbidden() => StatusCode(403, new { error = "Your role cannot manage approval chains." });

    private static object Body(ApprovalChainProcess.Refusal refusal) =>
        refusal.Code is string code ? new { error = refusal.Reason, code } : new { error = refusal.Reason };

    private IActionResult Refuse(ApprovalChainProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(Body(refusal))
        : refusal.Conflict ? Conflict(Body(refusal))
        : refusal.Forbidden ? StatusCode(403, Body(refusal))
        : BadRequest(Body(refusal));

    // ---- Admin CRUD ---------------------------------------------------------

    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return Forbidden();
        return Ok(await _chains.ListAsync(ct));
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return Forbidden();
        var chain = await _chains.GetAsync(id, ct);
        return chain is null ? NotFound(new { error = "Approval chain not found." }) : Ok(chain);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] ApprovalChainInput input, CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return Forbidden();
        var (created, refusal) = await _chains.CreateAsync(input, User.UserId(), ct);
        return refusal is not null ? Refuse(refusal) : StatusCode(201, created);
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] ApprovalChainInput input, CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return Forbidden();
        var (updated, refusal) = await _chains.UpdateAsync(id, input, ct);
        return refusal is not null ? Refuse(refusal) : Ok(updated);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return Forbidden();
        var refusal = await _chains.DeleteAsync(id, ct);
        return refusal is not null ? Refuse(refusal) : NoContent();
    }

    /// <summary>Reorder chains in one call — mirrors <c>CustomFieldsController.Reorder</c>'s
    /// "the designer drags, then saves the whole order" shape. Priority order
    /// IS the overlap-resolution mechanism (design §14 item 5), so this is the
    /// one screen action that changes which chain wins an overlap.</summary>
    [HttpPost("reorder")]
    public async Task<IActionResult> Reorder([FromBody] ApprovalChainReorderInput input, CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return Forbidden();
        var (reordered, refusal) = await _chains.ReorderAsync(input.Ids, ct);
        return refusal is not null ? Refuse(refusal) : Ok(reordered);
    }

    // ---- Runtime: instance progress + per-step decide ------------------------

    /// <summary>The chain instance governing one request, if any — null (200
    /// with an empty body) when the request matched no chain. Scoped exactly
    /// like the request itself is visible today (coordinator review,
    /// 2026-09-27): [Authorize] only at the HTTP layer (no ManageSettings
    /// gate — a requester tracking their own request, or an approver deciding
    /// a step, both need this without admin rights), but 404 when the request
    /// doesn't exist OR isn't visible to this caller — same "don't let an id
    /// distinguish the two" rule <c>ApprovalsController.Decide</c>'s team-scope
    /// check already follows.</summary>
    [HttpGet("for-request/{requestId:guid}")]
    public async Task<IActionResult> ForRequest(Guid requestId, CancellationToken ct)
    {
        var ctx = await _caller.ForAsync(User);
        var (visible, instance) = await _chains.GetInstanceForRequestAsync(requestId, ctx, ct);
        return visible ? Ok(instance) : NotFound(new { error = "Request not found" });
    }

    // POST /approval-chains/instances/{instanceId}/decide — the step's
    // resolved approver decides. E0.1's two governance gates (team scope,
    // self-decision) and the step's own approver-kind check all live inside
    // ApprovalChainProcess.DecideStepAsync — see that method's own comment.
    [HttpPost("instances/{instanceId:guid}/decide")]
    public async Task<IActionResult> DecideStep(Guid instanceId, [FromBody] ApprovalChainStepDecisionInput input, CancellationToken ct)
    {
        var ctx = await _caller.ForAsync(User);
        var outcome = await _chains.DecideStepAsync(instanceId, input, User.UserId(), ctx, ct,
            holdsApprovePartnerPayouts: User.HasPermission(OrganizationPermissions.ApprovePartnerPayouts));
        if (outcome.Refusal is not null) return Refuse(outcome.Refusal);

        // The chain reached a final outcome this call — apply it to the
        // underlying ApprovalRequest via the SAME mutation code the direct
        // decide path uses (ApprovalProcess.ApplyChainOutcomeAsync), with no
        // further permission re-check (see that method's own comment for why).
        if (outcome.FinalApproved is bool finalApproved && outcome.Instance is not null)
        {
            var hasViewLeadValues = User.HasPermission(OrganizationPermissions.ViewLeadValues);
            var applied = await _approvals.ApplyChainOutcomeAsync(
                outcome.Instance.ApprovalRequestId, finalApproved, outcome.DeciderId, outcome.Note, hasViewLeadValues, ct);
            if (applied.Refusal is not null)
                return applied.Refusal.Kind switch
                {
                    ApprovalProcess.RefusalKind.NotFound => NotFound(applied.Refusal.Body),
                    ApprovalProcess.RefusalKind.Conflict => Conflict(applied.Refusal.Body),
                    ApprovalProcess.RefusalKind.Forbidden => StatusCode(403, applied.Refusal.Body),
                    _ => BadRequest(applied.Refusal.Body),
                };
        }

        return Ok(outcome.Instance);
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Delivery;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Delivery project from a workflow stage (to-do/delivery-project-from-workflow-design.md): when a deal enters a stage with "Create delivery project on entry"
/// the screen lists Suntech Delivery's services (<c>GET /delivery/services</c>), the rep ticks some, and <c>POST /leads/{id}/delivery-project</c> asks the delivery
/// tool for a draft project (first call) or adds services to it (later calls). Routes, checks the sign-in, picks a status code; the deal-access rule (read = view the
/// deal, request = manage it) and everything else is <c>DeliveryProjectProcess</c>.
///
/// Refusals are <c>{error, code?}</c>: 404 lead not found, 403 not allowed, 400 <c>delivery_choose_service</c>, 409 <c>delivery_not_configured</c> (the connector is not
/// set up), 503 <c>delivery_unreachable</c> (the services list) or <c>delivery_webhook_missing</c> (no lead.won webhook to the delivery tool to reuse).
/// </summary>
[ApiController]
[Route("")]
[Authorize]
public class DeliveryProjectController : ControllerBase
{
    private readonly DeliveryProjectExperience _delivery;
    private readonly CallerContext _caller;

    public DeliveryProjectController(DeliveryProjectExperience delivery, CallerContext caller)
    {
        _delivery = delivery;
        _caller = caller;
    }

    /// <summary>The delivery tool's service catalogue: <c>[{id, code, name, category, description}]</c>, cached for a few minutes.</summary>
    [HttpGet("delivery/services")]
    public async Task<IActionResult> Services(CancellationToken ct) => this.Respond(await _delivery.ServicesAsync(ct));

    /// <summary>The deal's delivery project, or 204 when none was requested.</summary>
    [HttpGet("leads/{leadId:guid}/delivery-project")]
    public async Task<IActionResult> Get(Guid leadId, CancellationToken ct) =>
        this.Respond(await _delivery.GetAsync(await _caller.ForAsync(User), leadId, ct));

    /// <summary>The rep's answer to the ask: <c>{service_ids: [...]}</c>. 201 with the project when this call made it, 200 when it already existed (services added, or nothing new).</summary>
    [HttpPost("leads/{leadId:guid}/delivery-project")]
    public async Task<IActionResult> Request(Guid leadId, [FromBody] DeliveryProjectInput? input, CancellationToken ct)
    {
        var r = await _delivery.RequestAsync(await _caller.ForAsync(User), User.UserId(), leadId, input ?? new DeliveryProjectInput(null), ct);
        return r.IsOk ? StatusCode(r.Value!.Created ? 201 : 200, r.Value.Project) : this.Respond(r);
    }
}

/// <summary>
/// The delivery tool reporting its project back: <c>PUT /partner/v1/leads/{id}/delivery-project</c>, authenticated by a scoped API key (<c>delivery:write</c>) like the
/// rest of the Partner API (<see cref="PartnerApiController"/>: the "ApiKey" scheme, <see cref="RequireApiKeyScopeAttribute"/>, the key's org stamped as the tenant, so a
/// deal of another org is a 404). Idempotent; a deal with no requested project is a 404.
/// </summary>
[ApiController]
[Route("partner/v1/leads/{leadId:guid}/delivery-project")]
[Authorize(AuthenticationSchemes = ApiKeyAuthenticationDefaults.Scheme)]
[RequirePlanFeature(PlanCatalogue.Features.ApiWebhooks)]
public class PartnerDeliveryApiController : ControllerBase
{
    private readonly DeliveryProjectExperience _delivery;
    public PartnerDeliveryApiController(DeliveryProjectExperience delivery) => _delivery = delivery;

    [HttpPut]
    [RequireApiKeyScope(ApiKeyScopes.Keys.DeliveryWrite)]
    public async Task<IActionResult> PutDeliveryProject(Guid leadId, [FromBody] PartnerDeliveryProjectInput? input, CancellationToken ct) =>
        this.Respond(await _delivery.ReportAsync(leadId, input ?? new PartnerDeliveryProjectInput(null, null, null, null), ct));
}

using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.LinkedIn;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E6.4 — LinkedIn Lead Sync connect flow, field mapping, and the manual
/// sync trigger (design doc to-do/e6-connectors-design.md §6, §9 slices
/// 9-11). Routing, the `settings.manage` permission check and status-code
/// selection only (API-led migration convention); the OAuth state machine,
/// mapping validation and sync orchestration live in ProcessApi.
///
/// The callback is [AllowAnonymous] deliberately — same reasoning
/// <c>MailboxConnectController</c>'s own doc comment gives verbatim: it is
/// hit by a full-page browser redirect from LinkedIn, never by this app's
/// own fetch client, so there is no Authorization header to check; the
/// signed `state` parameter IS the identity/authorization check.
/// </summary>
[ApiController]
[Route("integrations/linkedin")]
[Authorize]
public class LinkedInLeadSyncController : ControllerBase
{
    private readonly LinkedInExperience _linkedIn;
    public LinkedInLeadSyncController(LinkedInExperience linkedIn) => _linkedIn = linkedIn;

    private bool CanManage() => User.HasPermission(OrganizationPermissions.ManageSettings);

    // Same relative-path reasoning as MailboxConnectController's own
    // ProfileRedirectPath: the device loader routes phone vs desktop off one
    // host, so a relative path is enough.
    private const string IntegrationsRedirectPath = "/apps/desktop/integrations";

    // GET /integrations/linkedin/connect — builds the LinkedIn authorize URL.
    [HttpGet("connect")]
    public async Task<IActionResult> Connect()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        var orgId = User.OrgId();
        if (orgId is null) return StatusCode(403, new { error = "No organization on this account." });

        // No display-name claim on the JWT (JwtService.CreateToken carries
        // id/email/role only) — email is the best identity this endpoint has
        // for "who connected" (design §6.2 point 4's "confirms which admin
        // authorized", adapted: no Graph-style /me call here to resolve a
        // real display name, since r_liteprofile is requested but never
        // fetched in this slice).
        var adminIdentity = User.FindFirstValue("email") ?? "An admin";
        var (refusal, result) = await _linkedIn.BuildAuthorizeUrlAsync(orgId.Value, User.UserId(), adminIdentity);
        if (refusal is not null) return BadRequest(new { error = refusal.Message });
        return Ok(result);
    }

    // GET /integrations/linkedin/connect/callback?code=&state= — hit by
    // LinkedIn's own redirect, no JWT. REDIRECTS to the desktop integrations
    // page: `?linkedin=connected` on success, `?linkedin=error&reason=<code>`
    // on failure — never raw LinkedIn error text in the URL, same discipline
    // MailboxConnectController's own callback follows.
    [HttpGet("connect/callback")]
    [AllowAnonymous]
    public async Task<IActionResult> Callback([FromQuery] string? code, [FromQuery] string? state, [FromQuery] string? error)
    {
        if (!string.IsNullOrEmpty(error))
            return Redirect($"{IntegrationsRedirectPath}?linkedin=error&reason=denied");
        if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(state))
            return Redirect($"{IntegrationsRedirectPath}?linkedin=error&reason=missing_params");

        var (refusal, result) = await _linkedIn.ExchangeCallbackAsync(code, state);
        if (refusal is not null)
            return Redirect($"{IntegrationsRedirectPath}?linkedin=error&reason={refusal.ReasonCode}");
        return Redirect($"{IntegrationsRedirectPath}?linkedin=connected");
    }

    // GET /integrations/linkedin/mapping — every mapped form.
    [HttpGet("mapping")]
    public async Task<IActionResult> ListMappings()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        return Ok(await _linkedIn.ListMappingsAsync());
    }

    // GET /integrations/linkedin/mapping/{formId}
    [HttpGet("mapping/{formId}")]
    public async Task<IActionResult> GetMapping(string formId)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        var dto = await _linkedIn.GetMappingAsync(formId);
        if (dto is null) return NotFound(new { error = "No mapping saved for that form yet." });
        return Ok(dto);
    }

    // PUT /integrations/linkedin/mapping — save (create or overwrite).
    [HttpPut("mapping")]
    public async Task<IActionResult> SaveMapping([FromBody] LinkedInFieldMappingInput input)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        var (dto, refusal) = await _linkedIn.SaveMappingAsync(input, User.UserId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // DELETE /integrations/linkedin/mapping/{formId}
    [HttpDelete("mapping/{formId}")]
    public async Task<IActionResult> DeleteMapping(string formId)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        var ok = await _linkedIn.DeleteMappingAsync(formId);
        if (!ok) return NotFound(new { error = "No mapping saved for that form." });
        return Ok(new { deleted = true });
    }

    // POST /integrations/linkedin/sync-now — org-scoped manual trigger, same
    // shape as POST /reminders/sweep (design §1's ReminderSweeper precedent).
    // E7.6 — gated on the org's plan.
    [HttpPost("sync-now")]
    [RequirePlanFeature(PlanCatalogue.Features.LinkedIn)]
    public async Task<IActionResult> SyncNow()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage integrations." });
        return Ok(await _linkedIn.SyncNowAsync());
    }

    // GET /integrations/linkedin/connection — lifetime totals + last error
    // for the connector card (E6 follow-up owner answer 2026-09-29),
    // mirroring MailboxConnectController's own "status" endpoint.
    [HttpGet("connection")]
    public async Task<IActionResult> Connection()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view integrations." });
        return Ok(await _linkedIn.GetConnectionDetailAsync());
    }

    // GET /integrations/linkedin/forms — the mapping screen's form picker
    // (E6 follow-up owner answer 2026-09-29). Never a 500 for "not
    // connected yet" — see LinkedInFormsProcess.
    [HttpGet("forms")]
    public async Task<IActionResult> Forms()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view integrations." });
        var orgId = User.OrgId();
        if (orgId is null) return StatusCode(403, new { error = "No organization on this account." });
        return Ok(await _linkedIn.GetFormsAsync(orgId.Value));
    }
}

/// <summary>E6.4 LinkedIn sync org settings (design §11 answers 6/7) —
/// admin-only, same permission as every other org-settings surface.</summary>
[ApiController]
[Authorize]
public class LinkedInSyncSettingsController : ControllerBase
{
    private readonly LinkedInExperience _linkedIn;
    public LinkedInSyncSettingsController(LinkedInExperience linkedIn) => _linkedIn = linkedIn;

    private bool CanManage() => User.HasPermission(OrganizationPermissions.ManageSettings);

    [HttpGet("admin/linkedin-settings")]
    public async Task<IActionResult> Get()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view this setting." });
        return Ok(await _linkedIn.GetSettingsAsync());
    }

    [HttpPut("admin/linkedin-settings")]
    public async Task<IActionResult> Save([FromBody] LinkedInSyncSettingsInput input)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (dto, refusal) = await _linkedIn.SaveSettingsAsync(input, User.UserId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }
}

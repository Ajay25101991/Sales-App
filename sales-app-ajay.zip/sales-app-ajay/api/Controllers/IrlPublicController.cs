using SalesApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Irl;
using SalesApi.ProcessLayer.Irl;

namespace SalesApi.Controllers;

/// <summary>
/// E-invoicing IRL - the CLIENT's public link (no sign-in). The token in the path names one request, as the engagement letter's accept link does;
/// a stale link is refused on the read AND again on every write: 404 for an unknown token, 410 for a revoked or expired one, 409 once a proposal has
/// locked a submitted IRL. These are JSON endpoints for the browser apps' public IRL page (the page itself is a route of those apps, not served
/// here). Anyone at the client who has the link can use it; nothing here exposes anything of the deal beyond its name. Rate limited
/// ("irl-public"). Routes and picks status codes only; the rules are <see cref="IrlPublicProcess"/>.
/// </summary>
[ApiController]
[Route("irl")]
[AllowAnonymous]
[EnableRateLimiting("irl-public")]
public class IrlPublicController : ControllerBase
{
    private readonly IrlExperience _irl;
    public IrlPublicController(IrlExperience irl) => _irl = irl;

    /// <summary>404 <c>{error}</c>; 410 <c>{error, status}</c> (revoked/expired); 409 <c>{error, status:"locked"}</c>; 400 <c>{error, fields:[{id,message}]}</c>; 413 <c>{error}</c>.</summary>
    private IActionResult Respond<T>(IrlPublicProcess.Result<T> r) => r.Outcome switch
    {
        IrlPublicProcess.Outcome.NotFound => NotFound(new { error = r.Error }),
        IrlPublicProcess.Outcome.Gone => r.Status == "locked" ? Conflict(new { error = r.Error, status = r.Status }) : StatusCode(410, new { error = r.Error, status = r.Status }),
        IrlPublicProcess.Outcome.Invalid => BadRequest(new { error = r.Error, fields = r.Errors ?? [] }),
        IrlPublicProcess.Outcome.TooLarge => StatusCode(413, new { error = r.Error }),
        _ => Ok(r.Value),
    };

    /// <summary>The form (its definition), the answers so far and whether they can still be changed. A locked request still reads (<c>can_edit</c> false).</summary>
    [HttpGet("{token}")]
    public async Task<IActionResult> View(string token, CancellationToken ct)
    {
        // The IP and user agent are read here and handed down as plain strings (the layering rule), as the quote page does.
        var ip = HttpContext?.Connection?.RemoteIpAddress?.ToString();
        var userAgent = HttpContext?.Request?.Headers.UserAgent.ToString();
        return Respond(await _irl.ViewAsync(token, ip, userAgent, ct));
    }

    /// <summary>Autosave. Body <c>{ "answers": { "&lt;canonical id&gt;": value, ... } }</c>: only the keys sent change; a table's value is the whole list of its rows.</summary>
    [HttpPut("{token}")]
    public async Task<IActionResult> Save(string token, [FromBody] SaveIrlAnswersInput input, CancellationToken ct) =>
        Respond(await _irl.SaveAsync(token, input.Answers, ct));

    /// <summary>Submit: keeps a snapshot, tells the rep. Optional body <c>{ "answers": {...} }</c> is saved first.</summary>
    [HttpPost("{token}/submit")]
    public async Task<IActionResult> Submit(string token, [FromBody] SubmitIrlInput? input, CancellationToken ct) =>
        Respond(await _irl.SubmitAsync(token, input?.Answers, ct));

    /// <summary>Uploads a file (multipart <c>file</c>) for one Section D item to the deal.</summary>
    [HttpPost("{token}/documents/{itemId}")]
    [RequestSizeLimit(UploadLimits.PublicRequestBytes)]
    public async Task<IActionResult> UploadDocument(string token, string itemId, IFormFile? file, CancellationToken ct)
    {
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required", fields = Array.Empty<IrlFieldErrorDto>() });
        await using var stream = file.OpenReadStream();
        var result = await _irl.UploadDocumentAsync(token, itemId, file.FileName, file.ContentType, file.Length, stream, ct);
        return result.Outcome == IrlPublicProcess.Outcome.Ok ? StatusCode(201, result.Value) : Respond(result);
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.DocumentRegister;
using SalesApi.ProcessLayer.DocumentRegister;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E15.1 document register: one row per KYC / company document, with a version chain (see <see cref="DocumentRegisterProcess"/>). Routes,
/// checks the permission, and picks a status code - nothing else. The whole controller sits behind kyc.access; the account's own view and
/// edit rules are judged by the Process class.
/// </summary>
[ApiController]
[Route("document-register")]
[Authorize]
[RequirePermission(OrganizationPermissions.KycAccess)]
[RequireSensitiveAccess(SensitiveCategories.ContactDetails)]
[StorageUnavailableFilter]
public class DocumentRegisterController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly DocumentRegisterExperience _register;

    public DocumentRegisterController(CallerContext caller, DocumentRegisterExperience register)
    {
        _caller = caller;
        _register = register;
    }

    private Task<RecordAccessContext> AccessAsync() => _caller.ForAsync(User);

    // 404 / 403 / 400, like ClientDocumentsController (this is the account's data).
    private static IActionResult FromRefusal(DocumentRegisterProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 403 }
        : refusal.Code == SensitiveWriteGuard.Code
            ? new BadRequestObjectResult(new { error = refusal.Reason, code = refusal.Code, fields = refusal.Fields })
        : new BadRequestObjectResult(refusal.Code is null
            ? new { error = refusal.Reason }
            : new { error = refusal.Reason, code = refusal.Code, field = refusal.Field });

    // GET /document-register?account_id= | contact_id= [&include_history=true] [&include_inherited=true]
    // The account's documents (company ones, and its contacts' personal ones), or one person's. include_history adds the replaced versions;
    // include_inherited adds the personal documents held on the account's ancestors, read-only (inherited: true).
    [HttpGet]
    public async Task<IActionResult> List(
        [FromQuery(Name = "account_id")] Guid? accountId, [FromQuery(Name = "contact_id")] Guid? contactId,
        [FromQuery(Name = "include_history")] bool includeHistory = false, [FromQuery(Name = "include_inherited")] bool includeInherited = false)
    {
        var outcome = await _register.ListAsync(await AccessAsync(), User.Role(), accountId, contactId, includeHistory, includeInherited, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Entries);
    }

    // GET /accounts/{account_id}/kyc-checklist (E15.3) - what the org's rules ask of this account and where each document stands:
    // present / missing / expired, with a complete flag. Behind kyc.access like the rest of this controller.
    [HttpGet("~/accounts/{accountId:guid}/kyc-checklist")]
    public async Task<IActionResult> Checklist(Guid accountId)
    {
        var outcome = await _register.ChecklistAsync(await AccessAsync(), accountId, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Checklist);
    }

    // POST /document-register (multipart: optional "file" - PDF, JPG or PNG - and account_id | contact_id, document_type, number?, issue_date?,
    // expiry_date?, replaces_id?). 201 with the row. The file is stored as an ordinary account attachment tagged doctype:{type}.
    [HttpPost]
    [RequestSizeLimit(UploadLimits.StaffRequestBytes)]
    public async Task<IActionResult> Add(
        [FromForm(Name = "account_id")] Guid? accountId, [FromForm(Name = "contact_id")] Guid? contactId,
        [FromForm(Name = "document_type")] string? documentType, [FromForm] string? number,
        [FromForm(Name = "issue_date")] DateOnly? issueDate, [FromForm(Name = "expiry_date")] DateOnly? expiryDate,
        [FromForm(Name = "replaces_id")] Guid? replacesId, IFormFile? file)
    {
        var input = new DocumentRegisterAddInput(accountId, contactId, documentType, number, issueDate, expiryDate, replacesId);
        var perms = new AttachmentPermissions(
            User.HasPermission(OrganizationPermissions.ViewFinancials), User.HasPermission(OrganizationPermissions.ViewContactDetails),
            User.HasPermission(OrganizationPermissions.KycAccess));
        await using var stream = file?.OpenReadStream();
        var outcome = await _register.AddAsync(
            await AccessAsync(), User.Role(), perms, User.UserId(), User.OrgId(), input,
            file?.FileName, file?.ContentType, file?.Length ?? 0, stream, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Entry);
    }

    // PUT /document-register/{id} { number, issue_date, expiry_date } - the values as they should now be (null clears). Current version only.
    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] DocumentRegisterEditInput input)
    {
        var outcome = await _register.UpdateAsync(await AccessAsync(), User.Role(), id, input, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Entry);
    }

    // POST /document-register/{id}/verify - a person has checked the document: status verified, verified_by / verified_at stamped.
    [HttpPost("{id:guid}/verify")]
    public async Task<IActionResult> Verify(Guid id)
    {
        var outcome = await _register.SetVerifiedAsync(await AccessAsync(), User.Role(), id, true, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Entry);
    }

    // POST /document-register/{id}/unverify - back to pending; verified_by / verified_at cleared.
    [HttpPost("{id:guid}/unverify")]
    public async Task<IActionResult> Unverify(Guid id)
    {
        var outcome = await _register.SetVerifiedAsync(await AccessAsync(), User.Role(), id, false, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Entry);
    }
}

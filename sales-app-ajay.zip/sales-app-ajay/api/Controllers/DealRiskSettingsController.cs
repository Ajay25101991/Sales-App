using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.AiPlatform;
using SalesApi.Services;

namespace SalesApi.Controllers;

// The E5.6 deal-risk thresholds (to-do/epics-ai-native-crm.md E5.6, story
// brief item 1). Admin-only, same permission as the AI provider/cost-policy
// settings — OrganizationPermissions.ManageSettings.
[ApiController]
[Authorize]
public class DealRiskSettingsController : ControllerBase
{
    private readonly DealRiskSettingsExperience _settings;
    public DealRiskSettingsController(DealRiskSettingsExperience settings) => _settings = settings;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);

    [HttpGet("admin/deal-risk-settings")]
    public async Task<IActionResult> Get()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot view this setting." });
        return Ok(await _settings.GetAsync());
    }

    [HttpPut("admin/deal-risk-settings")]
    public async Task<IActionResult> Save([FromBody] DealRiskSettingsInput input)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (dto, refusal) = await _settings.SaveAsync(input, User.UserId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }
}

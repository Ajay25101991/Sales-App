using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.ChangeRequests;
using SalesApi.ProcessLayer.ChangeRequests;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E7.4 change requests + customer approval (design doc
/// to-do/e7-config-platform-design.md §5.4/§5.5, story brief slices 16-17).
///
/// AUTHORIZATION SEAM: every authenticated action below is gated on
/// <see cref="OrganizationPermissions.ManageSettings"/> — the same
/// config-admin permission <c>PackagesController</c>/<c>SandboxController</c>
/// already use — NOT yet on a <c>StudioAssignment</c> (§5.1's implementation-
/// user grant, story slice 13, a SIBLING slice that may not be merged into
/// this base). This is a deliberate, explicit seam, not an oversight: until
/// slice 13 lands, nobody outside a customer org's own admins can reach these
/// endpoints at all (there is no cross-org token yet), so ManageSettings is
/// already the correct — if not yet complete — gate. Once slice 13 merges,
/// each check here should ALSO require an active StudioAssignment for
/// <c>ChangeRequest.StudioAssignmentId</c> when the caller is not a member of
/// the request's own org (an implementation user acting cross-org), the same
/// "org-admin-equivalent, never platform powers" shape that slice describes.
///
/// Public approve/reject page mirrors <c>QuotesController</c> exactly —
/// [AllowAnonymous] on the two token actions only, everything else stays
/// [Authorize] at the class level.
/// </summary>
[ApiController]
[Route("change-requests")]
[Authorize]
public class ChangeRequestsController : ControllerBase
{
    private readonly ChangeRequestsExperience _changeRequests;
    public ChangeRequestsController(ChangeRequestsExperience changeRequests) => _changeRequests = changeRequests;

    private IActionResult? RequireManageSettings() =>
        User.HasPermission(OrganizationPermissions.ManageSettings)
            ? null
            : StatusCode(403, new { error = "Your role cannot manage change requests." });

    private IActionResult Refused(ChangeRequestProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(refusal.ToDto())
        : refusal.Conflict ? Conflict(refusal.ToDto())
        : BadRequest(refusal.ToDto());

    [HttpGet]
    public async Task<IActionResult> List()
    {
        if (RequireManageSettings() is { } err) return err;
        return Ok(await _changeRequests.ListAsync());
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Detail(Guid id)
    {
        if (RequireManageSettings() is { } err) return err;
        var (refusal, dto) = await _changeRequests.DetailAsync(id);
        return refusal is not null ? Refused(refusal) : Ok(dto);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] ChangeRequestCreateDto input)
    {
        if (RequireManageSettings() is { } err) return err;
        if (string.IsNullOrWhiteSpace(input.Title))
            return BadRequest(new { error = "Title is required." });

        var dto = await _changeRequests.CreateAsync(User.OrgId()!.Value, User.UserId(), input.Title, input.Description);
        return StatusCode(201, dto);
    }

    [HttpPost("{id:guid}/comments")]
    public async Task<IActionResult> Comment(Guid id, [FromBody] ChangeRequestCommentCreateDto input)
    {
        if (RequireManageSettings() is { } err) return err;
        var (refusal, dto) = await _changeRequests.CommentAsync(id, User.UserId(), input.Body);
        return refusal is not null ? Refused(refusal) : StatusCode(201, dto);
    }

    /// <summary>Requested/BuiltInSandbox → BuiltInSandbox — links the sandbox
    /// diff items this request covers and (re)mints the customer approval
    /// link. Returns the raw token ONCE, in <c>approval_token</c>, so the
    /// caller can build the shareable link — it is never retrievable again
    /// (only its hash is stored, same as an invite token).</summary>
    [HttpPost("{id:guid}/link-items")]
    public async Task<IActionResult> LinkItems(Guid id, [FromBody] ChangeRequestLinkItemsDto input)
    {
        if (RequireManageSettings() is { } err) return err;
        var (refusal, dto, rawToken) = await _changeRequests.LinkItemsAsync(id, input.Items ?? new(), input.Removals ?? new());
        if (refusal is not null) return Refused(refusal);
        return Ok(new { change_request = dto, approval_token = rawToken });
    }

    /// <summary>The authenticated path for "an authenticated customer org
    /// admin can approve/reject in the app" (story brief). <paramref name="approve"/>
    /// true approves — allowed only from BuiltInSandbox, same as the public
    /// token path. false rejects — owner answer 2026-09-29: allowed from ANY
    /// state before Promoted, including CustomerApproved (withdrawing an
    /// approval before it ships) — see <c>ChangeRequestProcess.ApplyDecision</c>
    /// for the full state table.</summary>
    [HttpPost("{id:guid}/decide")]
    public async Task<IActionResult> Decide(Guid id, [FromBody] ChangeRequestDecideDto input)
    {
        if (RequireManageSettings() is { } err) return err;
        var (refusal, dto) = await _changeRequests.DecideAsync(id, User.UserId(), input.Approve);
        return refusal is not null ? Refused(refusal) : Ok(dto);
    }

    /// <summary>CustomerApproved → Promoted — promotes exactly this request's
    /// linked sandbox items through the existing sandbox promote path
    /// (§10 owner answer 4). Refused with 409 if another still-open request
    /// already covers one of the same items.</summary>
    [HttpPost("{id:guid}/promote")]
    public async Task<IActionResult> Promote(Guid id)
    {
        if (RequireManageSettings() is { } err) return err;
        var (refusal, result) = await _changeRequests.PromoteAsync(User.OrgId()!.Value, User.UserId(), id);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    // --- Public approve/reject page (§5.5, mirrors QuotesController) -----------

    private static string Esc(string? s) => System.Net.WebUtility.HtmlEncode(s ?? "");

    /// <summary>GET /change-requests/approve/{token} — a minimal
    /// self-contained approve/reject page, same shape as
    /// <c>QuotesController.Page</c>. An invalid, expired or already-consumed
    /// token renders the SAME "not found" page a bad quote link would — no
    /// wording differs between those three cases (no information leak).</summary>
    [HttpGet("approve/{token}")]
    [Produces("text/html")]
    [AllowAnonymous]
    public async Task<IActionResult> Page(string token)
    {
        var view = await _changeRequests.ViewByTokenAsync(token);
        if (view.Outcome == ChangeRequestProcess.PublicViewOutcome.NotFound)
            return Content(Html("Not found", "<p>This link is no longer valid.</p>"), "text/html");

        var cr = view.ChangeRequest!;
        var body = $"<p class='status'>{Esc(cr.Status)}</p>" +
            $"<h2>{Esc(cr.Title)}</h2>" +
            $"<p>{Esc(cr.Description)}</p>" +
            ItemsList(cr) +
            $"<form method='post' action='/change-requests/approve/{Esc(token)}'>" +
            "<button class='approve' type='submit' name='decision' value='approve'>Approve</button>" +
            "<button class='reject' type='submit' name='decision' value='reject'>Reject</button></form>";
        return Content(Html("Review change request", body), "text/html");
    }

    private static string ItemsList(PublicChangeRequestDto cr)
    {
        var sb = new StringBuilder("<ul class='items'>");
        foreach (var item in cr.LinkedItems)
            sb.Append($"<li>{Esc(item.Kind)}: {Esc(item.StableKey)}</li>");
        foreach (var removal in cr.LinkedRemovals)
            sb.Append($"<li class='removed'>Remove — {Esc(removal.Kind)}: {Esc(removal.StableKey)}</li>");
        sb.Append("</ul>");
        return sb.ToString();
    }

    /// <summary>POST /change-requests/approve/{token} — records the
    /// customer's decision. The refusal on a wrong-state request (already
    /// decided, since re-checked) is worded, but an invalid/expired/consumed
    /// token still renders the identical "not found" page as the GET above.</summary>
    [HttpPost("approve/{token}")]
    [Consumes("application/x-www-form-urlencoded", "application/json")]
    [AllowAnonymous]
    public async Task<IActionResult> Decide(string token, [FromForm] string? decision)
    {
        var approve = string.Equals(decision, "approve", StringComparison.OrdinalIgnoreCase);
        var result = await _changeRequests.DecideByTokenAsync(token, approve);
        return result.Outcome switch
        {
            ChangeRequestProcess.PublicDecisionOutcome.NotFound =>
                Content(Html("Not found", "<p>This link is no longer valid.</p>"), "text/html"),
            ChangeRequestProcess.PublicDecisionOutcome.Refused =>
                Content(Html("Unavailable", $"<p>{Esc(result.RefusalReason)}</p>"), "text/html"),
            _ => Content(Html(approve ? "Approved" : "Rejected",
                $"<div class='ok'>{(approve ? "✓ Approved" : "Rejected")}</div><p>Thank you — your decision has been recorded.</p>"), "text/html"),
        };
    }

    private static string Html(string title, string body)
    {
        var sb = new StringBuilder();
        sb.Append("<!doctype html><html><head><meta charset='utf-8'>");
        sb.Append("<meta name='viewport' content='width=device-width, initial-scale=1'>");
        sb.Append($"<title>{Esc(title)}</title><style>");
        sb.Append("body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:640px;margin:0 auto;padding:24px;color:#0f172a;background:#f8fafc}");
        sb.Append("h1{font-size:20px}h2{font-size:18px;margin:0 0 8px}");
        sb.Append("p.status{text-transform:uppercase;letter-spacing:.04em;font-size:12px;color:#64748b;margin:0 0 4px}");
        sb.Append("ul.items{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:12px 16px;margin:12px 0;list-style:none}");
        sb.Append("ul.items li{padding:6px 0;border-bottom:1px solid #f1f5f9;font-size:14px}");
        sb.Append("ul.items li:last-child{border-bottom:0}li.removed{color:#b45309}");
        sb.Append("button{padding:14px;border:0;border-radius:10px;color:#fff;font-size:16px;font-weight:600;margin-right:8px}");
        sb.Append("button.approve{background:#16a34a}button.reject{background:#b91c1c}");
        sb.Append(".ok{font-size:22px;font-weight:700;color:#16a34a}");
        sb.Append($"</style></head><body><h1>{Esc(title)}</h1>{body}</body></html>");
        return sb.ToString();
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Qualification;
using SalesApi.ProcessLayer.Qualification;
using SalesApi.Services;

namespace SalesApi.Controllers;

// E3.7 — a lead's methodology checklist, nested under the lead it belongs to
// (same /leads/{id}/... shape as stakeholders/activities/proposals on
// LeadsController; its own controller for the same reasoning
// StakeholdersController is separate — its own domain).
[ApiController]
[Route("leads/{leadId:guid}/qualification")]
[Authorize]
public class LeadQualificationController : ControllerBase
{
    // The one remaining _db use — resolving WHO is calling needs both the
    // ClaimsPrincipal and the database, same residual every migrated
    // controller keeps (see LeadsController's own comment).
    private readonly CallerContext _caller;
    private readonly LeadQualificationExperience _qualification;

    public LeadQualificationController(CallerContext caller, LeadQualificationExperience qualification)
    {
        _caller = caller;
        _qualification = qualification;
    }

    private Task<RecordAccessContext> AccessAsync() => _caller.ForAsync(User);

    private static IActionResult FromRefusal(LeadQualificationProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 403 }
        : new BadRequestObjectResult(new { error = refusal.Reason });

    [HttpGet]
    public async Task<IActionResult> Get(Guid leadId)
    {
        var outcome = await _qualification.GetAsync(await AccessAsync(), leadId);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Dto);
    }

    [HttpPost("{itemKey}/complete")]
    public async Task<IActionResult> Complete(Guid leadId, string itemKey, [FromBody] CompleteQualificationItemInput? input)
    {
        var outcome = await _qualification.CompleteAsync(await AccessAsync(), leadId, itemKey, User.UserId(), input?.Note);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Dto);
    }

    [HttpDelete("{itemKey}/complete")]
    public async Task<IActionResult> Uncomplete(Guid leadId, string itemKey)
    {
        var outcome = await _qualification.UncompleteAsync(await AccessAsync(), leadId, itemKey, User.UserId());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Dto);
    }
}

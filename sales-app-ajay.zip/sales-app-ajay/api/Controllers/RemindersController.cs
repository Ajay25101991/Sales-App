using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Reminders;
using SalesApi.ProcessLayer.Reminders;
using SalesApi.Services;

namespace SalesApi.Controllers;

// MIGRATED to the layered API (step 8): this controller keeps routing,
// [Authorize], the manager-only checks on reassignment and the sweep, and
// status selection. Every business rule — list scoping, reassignment
// eligibility, the create/update/delete rules and the sweep trigger — lives
// in ReminderProcess, reached through RemindersExperience.
[ApiController]
[Route("reminders")]
[Authorize]
public class RemindersController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly RemindersExperience _reminders;
    public RemindersController(CallerContext caller, RemindersExperience reminders)
    {
        _caller = caller;
        _reminders = reminders;
    }

    // GET /reminders?pending=&owner_id=&status= — a rep always sees only their
    // own (hard-scoped, same as before E1). A manager sees the whole team's
    // reminders (the org tenant filter already limits this to their org) and can
    // narrow to one teammate with owner_id. status is a free filter (e.g.
    // "pending") in addition to/instead of the pending=true shorthand.
    [HttpGet]
    // owner_id accepts a comma-separated list so a manager can filter to several
    // teammates at once, matching how /leads takes its multi-value filters.
    // A single id still works unchanged.
    public async Task<IActionResult> List(bool? pending, [FromQuery] string? owner_id, [FromQuery] string? status)
    {
        var ctx = await _caller.ForAsync(User);
        return Ok(await _reminders.ListAsync(ctx, owner_id, pending, status));
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] ReminderInput input)
    {
        var (dto, refusal) = await _reminders.CreateAsync(User.UserId(), input);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return StatusCode(201, dto);
    }

    // A rep may only PATCH their own reminder (unchanged). A manager may PATCH
    // any reminder in their org — including reassigning it (owner_id) to another
    // teammate, or snoozing it (remind_at) on the team's behalf. Snooze needed no
    // new endpoint: RemindAt was already PATCH-able, it just moves the date
    // without touching Status, so it never marks the reminder done.
    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] ReminderInput input)
    {
        var ctx = await _caller.ForAsync(User);
        var (dto, refusal) = await _reminders.UpdateAsync(ctx, User.OrgId(), id, input);
        if (refusal is not null) return Refuse(refusal);
        return Ok(dto);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var refusal = await _reminders.DeleteAsync(User.UserId(), id);
        if (refusal is not null) return Refuse(refusal);
        return NoContent();
    }

    // Manually trigger the due-reminder sweep (managers/admins).
    //
    // Scoped to the caller's own organisation. The sweep MARKS ROWS SENT and
    // DISPATCHES PUSH, so running it unscoped meant a manager in one org
    // delivering another org's notifications to that org's users and being told
    // how many — `processed` now counts only what this caller actually caused.
    // The background worker still sweeps every tenant; that is its job.
    [HttpPost("sweep")]
    public async Task<IActionResult> Sweep()
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can trigger the sweep" });
        // Refused rather than defaulted: `orgId: null` means "every tenant" to the
        // sweeper, so a token without an org claim must not fall through to it.
        if (User.OrgId() is not Guid org) return StatusCode(403, new { error = "No organization on this token" });
        // Through the dispatcher, exactly like the background worker — see
        // ReminderProcess.SweepAsync, which calls the same ReminderSweeper the
        // background worker uses rather than duplicating its logic. Quiet
        // hours are the ONE deliberate difference from the background sweep: a
        // manager pressing "sweep now" is asking for delivery now. Every other
        // preference still applies — an opt-out is still an opt-out.
        var processed = await _reminders.SweepAsync(org);
        return Ok(new { processed });
    }

    private IActionResult Refuse(ReminderProcess.Refusal refusal) => refusal.Kind switch
    {
        ReminderProcess.RefusalKind.NotFound => NotFound(new { error = refusal.Reason }),
        ReminderProcess.RefusalKind.Forbidden => StatusCode(403, new { error = refusal.Reason }),
        _ => BadRequest(new { error = refusal.Reason }),
    };
}

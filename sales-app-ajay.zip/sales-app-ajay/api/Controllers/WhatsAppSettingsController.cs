using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.WhatsApp;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E6.4 (design doc to-do/e6-connectors-design.md §11 owner answers 2/3/8) —
/// the WhatsApp org settings and "Test connection". Admin-only
/// (ManageSettings), same permission every settings screen in this app uses
/// — the story brief's "nearest settings precedent".
/// </summary>
[ApiController]
[Authorize]
public class WhatsAppSettingsController : ControllerBase
{
    private readonly WhatsAppSettingsExperience _settings;
    public WhatsAppSettingsController(WhatsAppSettingsExperience settings) => _settings = settings;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);

    [HttpGet("settings/whatsapp")]
    public async Task<IActionResult> Get()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot view this setting." });
        return Ok(await _settings.GetAsync(User.OrgId()));
    }

    [HttpPut("settings/whatsapp")]
    public async Task<IActionResult> Save([FromBody] WhatsAppSettingsInput input)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (dto, refusal) = await _settings.SaveAsync(input, User.UserId(), User.OrgId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // POST /settings/whatsapp/test — owner answer 8: build now. Sends
    // nothing; the lightest real read Meta's API offers (GET the phone
    // number's own display info), so a bad access token or wrong
    // phone-number-id is caught here rather than on a rep's first real send.
    [HttpPost("settings/whatsapp/test")]
    public async Task<IActionResult> TestConnection()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var result = await _settings.TestConnectionAsync();
        return result.Ok ? Ok(result) : BadRequest(result);
    }
}

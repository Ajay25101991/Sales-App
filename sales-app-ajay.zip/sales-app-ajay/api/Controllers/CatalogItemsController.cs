using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.CatalogItems;
using SalesApi.ProcessLayer.CatalogItems;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// THE Products and services list (E10.1) — products and services alike
/// (Kind distinguishes them), with an optional quote Price. It replaced the old
/// /proposal-modules price list, which no longer exists; see the class comment
/// on <see cref="Models.CatalogItem"/>. Deals, the quote builder and account
/// ownership all read it.
///
/// Gated the same shape as CustomFieldsController: any signed-in user may
/// read it (the deal form's picker, a proposal, an AMC form all need it),
/// writes require settings.manage — an inline check rather than a class-level
/// [RequirePermission], because read and write have different gates here.
/// The PRICE is a financial figure: it is withheld from a reader without
/// financials.view, and setting or clearing one needs financials.view as well.
///
/// MIGRATED to the layered API (step 8): this controller now only routes,
/// checks permission and picks a status code from what CatalogItemsExperience
/// decides. It touches no _db at all — every read and write goes through
/// CatalogItemsExperience (SalesApi.ExperienceApi) and, beneath it,
/// CatalogItemProcess (SalesApi.ProcessApi) and CatalogItemStore
/// (SalesApi.SystemApi). The Kind vocabulary, key derivation, and the
/// uniqueness/archive rules moved with them, unchanged.
/// </summary>
[ApiController]
[Route("catalog-items")]
[Authorize]
public class CatalogItemsController : ControllerBase
{
    private readonly CatalogItemsExperience _catalog;
    private readonly CallerContext? _caller;
    // _caller is only needed by /proposable (the caller's team scope + deal visibility); the CRUD paths never read it.
    public CatalogItemsController(CatalogItemsExperience catalog, CallerContext? caller = null)
    {
        _catalog = catalog;
        _caller = caller;
    }

    // E12.2: a catalogue price is company financials. It is shown only to a caller who holds financials.view AND reads
    // that category raw (full or view only); a masked or hidden level gets the same withheld (null) price the permission
    // gives today. Writes additionally need full.
    private bool CanSeeFinancials =>
        User.HasPermission(OrganizationPermissions.ViewFinancials)
        && SensitiveLevels.CanReadRaw(User.Sensitive().RoleLevel(SensitiveCategories.CompanyFinancials));

    // Setting or clearing a price is a financial write. Everything else on the item
    // needs only settings.manage, so an admin without financials.view can still
    // maintain names and kinds.
    private IActionResult? PriceWriteRefusal(CatalogItemInput input)
    {
        if (input.Price is null && input.ClearPrice != true) return null;
        if (!CanSeeFinancials) return StatusCode(403, new { error = "Your role cannot set prices." });
        if (!SensitiveLevels.CanWrite(User.Sensitive().RoleLevel(SensitiveCategories.CompanyFinancials)))
            return BadRequest(new
            {
                error = "You can view Company financials but not change it.",
                code = SensitiveWriteGuard.Code, fields = new[] { "price" },
            });
        return null;
    }

    /// <summary>
    /// Anyone signed in can read the catalogue — a rep building a proposal, an
    /// account's white-space panel and the AMC form all need it. Archived items
    /// are excluded by default: they stay in the table only so anything that
    /// already references one (a future ownership record) keeps a resolvable
    /// Id/Key, not so they show up as pickable again.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> List(bool includeArchived = false)
    {
        var rows = await _catalog.ListAsync(includeArchived, CanSeeFinancials);
        return Ok(rows);
    }

    /// <summary>
    /// E10.2 - "services I can propose for this deal": the active services whose team scope admits the
    /// caller (knowledge-collection rule; empty scope = whole org). <c>deal_id</c> is optional; a deal the
    /// caller cannot see answers 404 exactly like a missing one. Any signed-in user, like the catalogue itself.
    /// </summary>
    [HttpGet("proposable")]
    public async Task<IActionResult> Proposable([FromQuery(Name = "deal_id")] Guid? dealId, CancellationToken ct)
    {
        var caller = await _caller!.ForAsync(User);
        var (items, notFound) = await _catalog.ListProposableAsync(caller, dealId, CanSeeFinancials, ct);
        return notFound is not null ? NotFound(new { error = notFound }) : Ok(items);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CatalogItemInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot define catalogue items." });
        if (PriceWriteRefusal(input) is { } priceRefusal) return priceRefusal;

        var result = await _catalog.CreateAsync(input, CanSeeFinancials);
        return result.Outcome switch
        {
            CatalogItemProcess.Outcome.Invalid => BadRequest(new { error = result.Error }),
            CatalogItemProcess.Outcome.Conflict => Conflict(new { error = result.Error }),
            _ => StatusCode(201, result.Item),
        };
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] CatalogItemInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot edit catalogue items." });
        if (PriceWriteRefusal(input) is { } priceRefusal) return priceRefusal;

        var result = await _catalog.UpdateAsync(id, input, CanSeeFinancials);
        return result.Outcome switch
        {
            CatalogItemProcess.Outcome.NotFound => NotFound(new { error = result.Error }),
            CatalogItemProcess.Outcome.Invalid => BadRequest(new { error = result.Error }),
            CatalogItemProcess.Outcome.Conflict => Conflict(new { error = result.Error }),
            _ => Ok(result.Item),
        };
    }

    /// <summary>Reorder items in one call — same shape as CustomFieldsController.Reorder.</summary>
    [HttpPost("reorder")]
    public async Task<IActionResult> Reorder([FromBody] CatalogItemReorderInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot edit catalogue items." });

        var ids = input.Ids ?? new();
        if (ids.Count == 0) return BadRequest(new { error = "ids is required" });

        var rows = await _catalog.ReorderAsync(ids, CanSeeFinancials);
        return Ok(rows);
    }

    /// <summary>
    /// Archive rather than delete — see the ArchivedAt comment on CatalogItem.
    /// Once an account can own a catalogue item, hard-deleting the item would
    /// orphan that ownership record; that reference does not exist yet, but the
    /// catalogue is the wrong layer to bet against it arriving.
    /// </summary>
    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot delete catalogue items." });

        var outcome = await _catalog.DeleteAsync(id);
        return outcome == CatalogItemProcess.DeleteOutcome.NotFound
            ? NotFound(new { error = "Item not found" })
            : NoContent();
    }

    /// <summary>
    /// Undo an archive. Refused if another active item has since taken the same
    /// key (the filtered unique index only frees a key up once its holder is
    /// archived — restoring both at once would collide).
    /// </summary>
    [HttpPost("{id:guid}/restore")]
    public async Task<IActionResult> Restore(Guid id)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot edit catalogue items." });

        var result = await _catalog.RestoreAsync(id, CanSeeFinancials);
        return result.Outcome switch
        {
            CatalogItemProcess.Outcome.NotFound => NotFound(new { error = result.Error }),
            CatalogItemProcess.Outcome.Conflict => Conflict(new { error = result.Error }),
            _ => Ok(result.Item),
        };
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.ApiKeys;
using SalesApi.ProcessLayer.ApiKeys;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Named, scoped, hashed-at-rest, revocable API keys - the ONLY inbound key mechanism (the legacy single plaintext website-form key at
/// `Settings["inbound_api_key"]` was migrated into one of these per org and its endpoints removed).
///
/// Generation, hashing, scope validation, expiry, rotation, audit events and the plan gate live in
/// SalesApi.ProcessApi/ApiKeys/ApiKeyProcess.cs, reached through SalesApi.ExperienceApi/ApiKeys/ApiKeysExperience.cs. What is left here,
/// deliberately: routing, [Authorize], the ManageSettings checks (a request-shaped fact about the caller, not a rule about a key), model
/// binding, and choosing the HTTP status for a Refusal.
///
/// PLAN GATE (`api_webhooks`): deliberately NOT a class-level [RequirePlanFeature]. A website lead key (only scope `leads:create`) must work on
/// every plan, and an attribute cannot read the scopes in the request body; ApiKeyProcess makes the check and a refusal comes back as the same
/// 403 `feature_not_in_plan` body the attribute produces. List and revoke are never gated (a downgraded org can still see and kill its keys).
/// </summary>
[ApiController]
[Route("api-keys")]
[Authorize]
public class ApiKeysController : ControllerBase
{
    private readonly ApiKeysExperience _keys;
    public ApiKeysController(ApiKeysExperience keys) => _keys = keys;

    private bool CanManage() => User.HasPermission(OrganizationPermissions.ManageSettings);

    private static IActionResult FromRefusal(ApiKeyProcess.Refusal refusal) =>
        refusal.PlanBlocked
            ? new ObjectResult(new { error = refusal.Reason, code = "feature_not_in_plan", feature = PlanCatalogue.Features.ApiWebhooks })
            { StatusCode = StatusCodes.Status403Forbidden }
        : refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : new BadRequestObjectResult(new { error = refusal.Reason });

    /// <summary>The registered scope catalogue, for the UI to render checkboxes against — never free text.</summary>
    [HttpGet("scopes")]
    public IActionResult Scopes() => Ok(_keys.Scopes());

    [HttpGet]
    public async Task<IActionResult> List()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view API keys." });
        return Ok(await _keys.ListAsync());
    }

    // GET /api-keys/settings - { default_expiry_days, rate_limit_per_minute, expiry_choices, min_/max_rate_limit_per_minute }.
    [HttpGet("settings")]
    public async Task<IActionResult> GetSettings()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view API key settings." });
        return Ok(await _keys.GetSettingsAsync());
    }

    // PUT /api-keys/settings { default_expiry_days: 30|90|365|null, rate_limit_per_minute?: int } - the org's defaults for every key.
    [HttpPut("settings")]
    public async Task<IActionResult> SetSettings([FromBody] ApiKeySettingsInput input)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot change API key settings." });
        var outcome = await _keys.SetSettingsAsync(input.DefaultExpiryDays, input.RateLimitPerMinute);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Settings);
    }

    // POST /api-keys — the full key is returned exactly once, here, and never again.
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateApiKeyInput input)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot create API keys." });
        var outcome = await _keys.CreateAsync(input.Name, input.Scopes, input.ExpiresAt, input.ExpiresInDays, User.UserId());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Created);
    }

    // PATCH /api-keys/{id} { name?, scopes? } — rename and/or change scopes of a live key.
    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateApiKeyInput input)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot edit API keys." });
        var outcome = await _keys.UpdateAsync(id, input.Name, input.Scopes, User.UserId());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Key);
    }

    // POST /api-keys/{id}/rotate — a new key (same name, scopes and lifetime) replaces this one, which is revoked. The new plaintext is
    // returned exactly once, in the same shape as create.
    [HttpPost("{id:guid}/rotate")]
    public async Task<IActionResult> Rotate(Guid id)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot rotate API keys." });
        var outcome = await _keys.RotateAsync(id, User.UserId());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Created);
    }

    // POST /api-keys/{id}/revoke — no DELETE: a revoked key stays in the list
    // (greyed out, `revoked_at` set) so "did we already kill this" is answerable
    // without digging through an audit log, matching how the design shows a
    // per-row menu action rather than a disappearing row.
    [HttpPost("{id:guid}/revoke")]
    public async Task<IActionResult> Revoke(Guid id)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot revoke API keys." });
        var outcome = await _keys.RevokeAsync(id, User.UserId());
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Key);
    }
}

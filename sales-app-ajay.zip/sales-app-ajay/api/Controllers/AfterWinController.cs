using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.AfterWin;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E13 - GET /leads/{id}/after-win: the won deal's money, contract, letter and next step in one read (to-do/e13-after-the-win-design.md).
/// Same access as reading the lead. Routes, resolves who is asking (money and settings permissions are facts about the caller, passed
/// down as data) and picks a status code; the figures are AfterWinProcess's.
/// </summary>
[ApiController]
[Route("leads/{id:guid}/after-win")]
[Authorize]
public class AfterWinController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly AfterWinExperience _afterWin;
    public AfterWinController(CallerContext caller, AfterWinExperience afterWin)
    {
        _caller = caller;
        _afterWin = afterWin;
    }

    [HttpGet]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct)
    {
        // Same view of the lead as GET /leads/{id} (CallerContext.LeadViewOf).
        var view = CallerContext.LeadViewOf(User);
        // Invoice money: invoice access (financials.view) and the field-level masking permission the rollups use.
        var canViewMoney = User.HasPermission(OrganizationPermissions.ViewFinancials) && User.HasPermission(OrganizationPermissions.ViewAccountFinancials);
        var outcome = await _afterWin.GetAsync(
            await _caller.ForAsync(User), view, id, canViewMoney, User.HasPermission(OrganizationPermissions.ManagePostWin), DateTime.UtcNow, ct);
        if (outcome.Refusal is { } r)
            return r.NotFound ? NotFound(new { error = r.Reason })
                : r.Forbidden ? StatusCode(403, new { error = r.Reason })
                : BadRequest(new { error = r.Reason });
        return Ok(outcome.Dto);
    }

    // POST /leads/{id}/after-win/dismiss-offer - "Not needed" on the recurring-contract offer. Same permission as creating the contract
    // (POST /amcs: financials.view, and the caller must manage the deal - checked in the process).
    [HttpPost("dismiss-offer")]
    [RequirePermission(OrganizationPermissions.ViewFinancials)]
    public async Task<IActionResult> DismissOffer(Guid id, CancellationToken ct)
    {
        var refusal = await _afterWin.DismissRecurringOfferAsync(await _caller.ForAsync(User), id, User.UserId(), DateTime.UtcNow, ct);
        if (refusal is { } r)
            return r.NotFound ? NotFound(new { error = r.Reason })
                : r.Forbidden ? StatusCode(403, new { error = r.Reason })
                : BadRequest(new { error = r.Reason });
        return NoContent();
    }
}

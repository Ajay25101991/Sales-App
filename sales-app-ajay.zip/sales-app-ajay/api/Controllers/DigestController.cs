using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Services;

namespace SalesApi.Controllers;

// Weekly team digest: an in-app summary + push delivery (no mail server).
[ApiController]
[Route("digest")]
[Authorize]
public class DigestController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly CallerContext _caller;
    public DigestController(AppDbContext db, CallerContext caller) => _db = db;

    // GET /digest — the summary (managers: team; reps: their own).
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var scope = await PeopleScope.VisibleIdsAsync(_db, await _caller.ForAsync(User));
        return Ok(await DigestService.ComputeAsync(_db, scope));
    }

    // POST /digest/send — push the digest to the caller's devices now.
    [HttpPost("send")]
    public async Task<IActionResult> Send()
    {
        var scope = await PeopleScope.VisibleIdsAsync(_db, await _caller.ForAsync(User));
        var dto = await DigestService.ComputeAsync(_db, scope);
        await DigestService.SendToAsync(_db, User.UserId(), dto);
        return Ok(new { sent = true });
    }

    [HttpGet("config")]
    public async Task<IActionResult> GetConfig()
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can view this." });
        return Ok(await DigestService.GetConfigAsync(_db));
    }

    [HttpPut("config")]
    public async Task<IActionResult> SetConfig([FromBody] DigestConfigInput input)
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can change this." });
        var current = await DigestService.GetConfigAsync(_db);
        var saved = await DigestService.SaveConfigAsync(_db,
            new DigestConfigDto(input.Enabled ?? current.Enabled, input.DayOfWeek ?? current.DayOfWeek, input.Hour ?? current.Hour));
        return Ok(saved);
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Mcp;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// The "AI tool connections" admin screen (to-do/mcp-server-design.md item 10). Not the MCP endpoint itself (<c>/mcp</c>, mapped in Program.cs);
/// the routes below share its prefix and are plain REST. Routing, the permission checks and status codes only; the rules are
/// <see cref="McpConnectionsExperience"/> and below.
/// </summary>
[ApiController]
[Route("mcp")]
[Authorize]
public class McpConnectionsController : ControllerBase
{
    private readonly McpConnectionsExperience _mcp;
    public McpConnectionsController(McpConnectionsExperience mcp) => _mcp = mcp;

    // GET /mcp/status -> McpStatusDto. Any signed-in user (it tells a person whether they can connect). The role list is filled only for
    // callers who manage roles or settings. Not plan-gated: the screen must be able to say "your plan does not include this".
    [HttpGet("status")]
    public async Task<IActionResult> Status(CancellationToken ct) =>
        Ok(await _mcp.StatusAsync(
            User.OrgId(), this.AbsoluteUrl("/mcp"),
            canConnect: User.HasPermission(OrganizationPermissions.AiToolsConnect),
            mayReadRoles: User.HasPermission(OrganizationPermissions.ManageRoles) || User.HasPermission(OrganizationPermissions.ManageSettings), ct, User.UserId()));

    // GET /mcp/access -> McpAccessDto: every active member with their role's answer, the admin's override and the effective answer. settings.manage.
    [HttpGet("access")]
    public async Task<IActionResult> GetAccess(CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot manage AI tool access." });
        return Ok(await _mcp.GetAccessAsync(User.OrgId()!.Value, ct));
    }

    // PUT /mcp/access { user_ids, override: "allow" | "block" | null } -> McpAccessDto. Applies to every listed person. settings.manage.
    [HttpPut("access")]
    public async Task<IActionResult> SetAccess([FromBody] McpAccessInput input, CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot manage AI tool access." });
        var (refusal, dto) = await _mcp.SetAccessAsync(User.OrgId()!.Value, User.UserId(), input, ct);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // GET /mcp/calls?limit=&cursor= -> McpCallPageDto, newest first (25 a page, at most 100). settings.manage.
    [HttpGet("calls")]
    public async Task<IActionResult> Calls([FromQuery] int limit = 25, [FromQuery] string? cursor = null, CancellationToken ct = default)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot view AI tool calls." });
        return Ok(await _mcp.ListCallsAsync(limit, cursor, ct));
    }
}

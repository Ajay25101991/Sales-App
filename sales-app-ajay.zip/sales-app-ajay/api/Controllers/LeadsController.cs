using System.Globalization;
using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using JsonOptions = Microsoft.AspNetCore.Mvc.JsonOptions;
using Microsoft.EntityFrameworkCore;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.Services.Paging;

namespace SalesApi.Controllers;

[ApiController]
[Route("leads")]
[Authorize]
public class LeadsController : ControllerBase
{
    // The only remaining _db use, and a deliberate one: resolving WHO is calling
    // needs both the ClaimsPrincipal and the database — their display name for
    // notification bodies, and their role's lead visibility. A System-layer
    // service must not take a principal, so this stays here, the same residual
    // Accounts, Attachments, Settings and Reports each keep.
    private readonly CallerContext _caller;
    private readonly SalesApi.ExperienceLayer.Leads.LeadsExperience _leads;
    // Optional, defaulted: DI always supplies a real ILogger<T> at runtime (no
    // registration needed — it's built in), but the ~30 test files that build
    // this controller by hand (see LoyaltyLayers.Leads's own comment on that
    // count) never pass one, and shouldn't have to just to exercise List.
    private readonly ILogger<LeadsController>? _logger;

    public LeadsController(
        CallerContext caller, SalesApi.ExperienceLayer.Leads.LeadsExperience leads,
        ILogger<LeadsController>? logger = null)
    {
        _caller = caller;
        _leads = leads;
        _logger = logger;
    }

    private string? _actorName;
    /// <summary>The caller's display name for notification bodies. Cached per request —
    /// a bulk action would otherwise re-read the same row once per lead.</summary>
    private async Task<string> ActorNameAsync()
    {
        if (_actorName is not null) return _actorName;
        return _actorName = await _caller.DisplayNameAsync(User);
    }

    // Search constants/thresholds (MinFuzzyQueryLength, DefaultSimilarityThreshold,
    // ShortTermMaxLength, WordSimilarityThreshold, MaxLevenshteinDistance) live in
    // Services.FuzzySearch — shared with AccountsController rather than
    // duplicated. See that class for the full measured reasoning behind each
    // number (worked out here first, then extracted).

    private LeadView? _leadView;

    // Per-role, falling back to the org-wide setting, falling back to a compile-time
    // default: "own" | "view" (see all) | "manage" (act on all). See RoleLeadVisibility.
    private Task<string> VisibilityAsync() => _caller.VisibilityAsync(User);

    // Everything the access decision depends on, gathered once per request-ish so the
    // decision itself stays a pure function (Services/TeamScoping.cs) that
    // SingleTeamEquivalenceTests can enumerate exhaustively. Note this reads
    // User.TeamScope(), NOT User.IsManager(): manager_access is now team-wide, and
    // adopting that at a call site is a deliberate, visible change rather than a
    // silent redefinition of IsManager() under ~82 unchanged call sites.
    private async Task<RecordAccessContext> AccessAsync() =>
        RecordAccessContexts.For(User, await VisibilityAsync());


    /// <summary>
    /// The team filter's permission check, for the four list-family endpoints.
    /// Returns a 403 result when the caller may not read that team, else null.
    ///
    /// SECURITY: mirrors DashboardController's identical guard exactly —
    /// `IsOrgAdmin || Scope.Covers(teamId)`, the already-audited answer to
    /// "which teams may this caller reach", reused rather than a second scoping
    /// mechanism invented here. WhereViewable would already reduce a foreign
    /// team to zero rows, so this is not the only thing standing between a
    /// caller and another team's leads; it is what turns a silently empty list
    /// into an honest refusal, and keeps /leads and /dashboard answering the
    /// same question the same way.
    ///
    /// The all-zeros sentinel ("No team") is exempt: it names no roster to be
    /// outside of.
    /// </summary>
    private IActionResult? TeamFilterRefusal(RecordAccessContext access, Guid? teamId) =>
        teamId is { } tid && tid != AggregateOwner.Unassigned && !access.IsOrgAdmin && !access.Scope.Covers(tid)
            ? StatusCode(403, new { error = "You do not have access to that team's leads." })
            : null;

    // The exact query-string names this action binds, i.e. the union of every
    // param `useLeads`/`useLeadsInfinite` (packages/core/src/hooks/use-leads.ts)
    // send — an unrecognized key (a typo, or a rename like the old `owner_id`)
    // is reported, not refused. See QueryParamValidation.
    private static readonly string[] ListQueryParams =
    [
        "status", "search", "sort", "owner", "source", "product",
        "overdue", "idle", "mine", "limit", "offset", "similarity",
        "custom", "paged", "cursor", "quietSince", "quietWindowDays", "tagIds", "teamId", "dealType",
        "filters", "sorts",
    ];

    // A filter or sort the server will not run (unknown column, an operator the type does not
    // allow, a column the caller may not see, more than five sorts) is a plain 400 with
    // `{ error, field? }` — never a 500 and never silently ignored.
    private async Task<IActionResult> RefusingBadQuery(Func<Task<IActionResult>> run)
    {
        try { return await run(); }
        catch (SalesApi.Services.TableQuery.TableQueryRefusedException e)
        {
            return BadRequest(new { error = e.Message, field = e.Field });
        }
    }

    // GET /leads/columns — the one-table column catalogue: every column this caller may sort or
    // filter, its type and operators, and the options of a pick column. Same access as GET /leads.
    [HttpGet("columns")]
    public async Task<IActionResult> Columns() =>
        Ok(await _leads.ColumnsAsync(await AccessAsync(), LeadViewOf()));

    [HttpGet]
    public async Task<IActionResult> List(
        string? status, string? search, string? sort,
        string? owner = null, string? source = null, string? product = null,
        bool overdue = false, bool idle = false, bool mine = false,
        int? limit = null, int? offset = null, double? similarity = null,
        string? custom = null, bool paged = false, string? cursor = null,
        DateTime? quietSince = null, int? quietWindowDays = null, string? tagIds = null,
        Guid? teamId = null, string? dealType = null, string? filters = null, string? sorts = null)
    {
        // Reported, never refused (reverted from a 400 on 2026-09-26 — see
        // QueryParamValidation's class doc): a param a fielded phone build
        // still sends that today's client no longer does must not break it.
        QueryParamValidation.ReportUnknownKeys(
            HttpContext, _logger, "GET /leads", QueryParamValidation.UnknownKeys(Request, ListQueryParams));

        var access = await AccessAsync();
        if (TeamFilterRefusal(access, teamId) is { } denied) return denied;
        var (refusal, dto) = await _leads.ListAsync(
            access, LeadViewOf(), User.UserId(),
            status, search, sort, owner, source, product, overdue, idle, mine,
            limit, offset, similarity, custom, paged, cursor, quietSince, quietWindowDays, tagIds, teamId, dealType,
            filters, sorts);
        // A stale cursor is refused rather than served: the page it points at is a
        // page of something else. The client reloads from the start. A bad filter/sort
        // arrives the same way, with the offending column in `field`.
        return refusal is not null
            ? BadRequest(new { error = refusal.Reason, code = refusal.Code, field = refusal.Field })
            : Ok(dto);
    }

    [HttpGet("count")]
    public async Task<IActionResult> Count(
        string? status, string? search,
        string? owner = null, string? source = null, string? product = null,
        bool overdue = false, bool idle = false, bool mine = false, double? similarity = null,
        string? custom = null, DateTime? quietSince = null, int? quietWindowDays = null, string? tagIds = null,
        Guid? teamId = null, string? dealType = null, string? filters = null)
    {
        var access = await AccessAsync();
        if (TeamFilterRefusal(access, teamId) is { } denied) return denied;
        return await RefusingBadQuery(async () =>
        {
            var view = LeadViewOf();
            var count = await _leads.CountAsync(
                access, User.UserId(),
                status, search, owner, source, product, overdue, idle, mine, similarity,
                custom, quietSince, quietWindowDays, tagIds, teamId, dealType,
                view.CanSeeContactDetails, filters, view);
            return Ok(new { count });
        });
    }

    // GET /leads/value-total - the same filter set as List/Count, summed.
    //
    // Gated on lead_values.aggregate, NOT lead_values.view: the two are
    // deliberately different grants ("may see totals" vs "may see per-deal
    // amounts"). It carried no check at all once, while the list DTO nulls
    // EstimatedValue without lead_values.view - so a rep saw blank values on
    // every row and an exact org-wide total in the header, and because this
    // re-runs on every filter change, individual values were recoverable by
    // difference. GET /leads/count beside it stays ungated: a count is not a
    // value.
    [HttpGet("value-total")]
    [RequirePermission(OrganizationPermissions.ViewLeadValueTotals)]
    public async Task<IActionResult> ValueTotal(
        string? status, string? search,
        string? owner = null, string? source = null, string? product = null,
        bool overdue = false, bool idle = false, bool mine = false, double? similarity = null,
        string? custom = null, string? tagIds = null, Guid? teamId = null, string? dealType = null, string? filters = null)
    {
        var access = await AccessAsync();
        if (TeamFilterRefusal(access, teamId) is { } denied) return denied;
        return await RefusingBadQuery(async () =>
        {
            var view = LeadViewOf();
            var total = await _leads.ValueTotalAsync(
                access, User.UserId(),
                status, search, owner, source, product, overdue, idle, mine, similarity, custom, tagIds, teamId, dealType,
                view.CanSeeContactDetails, filters, view);
            return Ok(new { total_value = total });
        });
    }

    // GET /leads/facets - how many leads each filter option would match, so the
    // filter sheet can show "Qualified (12)" and grey out what would return
    // nothing. Each dimension is counted with its OWN filter lifted; see
    // LeadListProcess for why.
    [HttpGet("facets")]
    public async Task<IActionResult> Facets(
        string? status, string? search,
        string? owner = null, string? source = null, string? product = null,
        bool overdue = false, bool idle = false, bool mine = false, double? similarity = null,
        Guid? teamId = null, string? filters = null)
    {
        var access = await AccessAsync();
        if (TeamFilterRefusal(access, teamId) is { } denied) return denied;
        return await RefusingBadQuery(async () =>
        {
            var view = LeadViewOf();
            var facets = await _leads.FacetsAsync(
                access, User.UserId(),
                status, search, owner, source, product, overdue, idle, mine, similarity, teamId,
                view.CanSeeContactDetails, filters, view);
            return Ok(facets);
        });
    }

    // GET /leads/export - the caller's visible leads as CSV. Declared before the
    // {id:guid} routes; the guid constraint keeps "export" from matching them.
    // Gated on exports.create, so the field gates are re-applied inside - see
    // LeadListProcess.
    [HttpGet("export")]
    [RequirePermission(OrganizationPermissions.CreateExports)]
    public async Task<IActionResult> Export(string? filters = null, string? sorts = null, string? ids = null) =>
        await RefusingBadQuery(async () =>
            Content(await _leads.ExportCsvAsync(await AccessAsync(), LeadViewOf(), filters, sorts, ParseIds(ids)), "text/csv; charset=utf-8"));

    // Accounts rework (decision 13): "Export selected" - a comma-separated list of lead ids narrows the export to those
    // rows (still inside the caller's visible set and the column rules). Unparseable entries are ignored.
    private static List<Guid>? ParseIds(string? ids)
    {
        if (string.IsNullOrWhiteSpace(ids)) return null;
        return ids.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(s => Guid.TryParse(s, out var g) ? (Guid?)g : null).Where(g => g is not null).Select(g => g!.Value).Distinct().ToList();
    }

    [HttpPost("import")]
    public async Task<IActionResult> Import(
        [FromBody] CsvImportInput input, bool preview = false, bool create_reminders = false)
    {
        // team_id is read here rather than below the HTTP layer: it is a query
        // parameter, and a Process class that reads a Request is not reusable by
        // anything that is not an HTTP call.
        Guid? teamId = Guid.TryParse(Request.Query["team_id"].ToString(), out var tt) ? tt : null;

        // account_mode now lives in the body (CsvImportInput.AccountMode) — the
        // review step makes this choice, so a documented request shape should
        // carry it. The query parameter is kept as a fallback for any caller
        // that has not moved yet; the body wins when both are present.
        var accountModeRaw = !string.IsNullOrWhiteSpace(input.AccountMode)
            ? input.AccountMode
            : Request.Query["account_mode"].ToString();

        var (refusal, dto) = await _leads.ImportAsync(
            User.UserId(), User.OrgId(),
            canAssign: User.IsManager() || User.IsSuntechAdmin(),
            LeadViewOf(), input,
            accountModeRaw, teamId,
            preview, create_reminders);
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // GET /leads/import/mapping?headers= — the mapping this org last saved for a
    // CSV with this header signature. 204 when there is none, so the client can
    // tell "no match" from "server returned nothing" the same way the rest of
    // this API does for a missing singleton.
    [HttpGet("import/mapping")]
    public async Task<IActionResult> GetImportMapping([FromQuery] string? headers)
    {
        var (refusal, dto) = await _leads.SavedImportMappingAsync(headers);
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return dto is null ? NoContent() : Ok(dto);
    }

    // GET /leads/import/defaults — what an unmapped field becomes for the caller
    // right now.
    [HttpGet("import/defaults")]
    public async Task<IActionResult> GetImportDefaults() =>
        Ok(await _leads.ImportDefaultsAsync(User.UserId()));

    // GET /leads/companies?q= — the company typeahead: names already on a
    // viewable lead, unioned with the org's account names.
    [HttpGet("companies")]
    public async Task<IActionResult> Companies(string? q) =>
        Ok(await _leads.CompaniesAsync(await AccessAsync(), q));

    /// <summary>The one place a lead read/activity refusal becomes a status code.</summary>
    private IActionResult LeadRefused(SalesApi.ProcessLayer.Leads.LeadReadProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason })
        : refusal.Forbidden ? StatusCode(403, new { error = refusal.Reason })
        : BadRequest(new { error = refusal.Reason });

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var (refusal, dto) = await _leads.GetAsync(await AccessAsync(), LeadViewOf(), id);
        return refusal is not null ? LeadRefused(refusal) : Ok(dto);
    }

    // GET /leads/{id}/stage-history — a lead's full recorded stage-transition
    // history, oldest first, for the lead-detail "progression through prior
    // stages" view. Same view-authorization as GET /leads/{id}. Returns an empty
    // list (not an error) for a lead that predates stage-event capture and was
    // never backfilled — the client renders that as "no history recorded", not
    // as zero elapsed time.
    [HttpGet("{id:guid}/stage-history")]
    public async Task<IActionResult> StageHistory(Guid id)
    {
        var (refusal, dto) = await _leads.StageHistoryAsync(await AccessAsync(), id);
        return refusal is not null ? LeadRefused(refusal) : Ok(dto);
    }

    // GET /leads/{id}/history — field-change audit (design doc
    // to-do/e1-event-backbone-design.md §6/§8), newest first, cursor-paged.
    // Record access IS the record's own: a caller who cannot see the lead gets
    // the SAME 404 as a lead that does not exist, never a 403 that would
    // confirm the id is real.
    [HttpGet("{id:guid}/history")]
    public async Task<IActionResult> History(Guid id, [FromQuery] string? cursor, [FromQuery] int? limit)
    {
        var (refusal, page) = await _leads.HistoryAsync(await AccessAsync(), LeadViewOf(), id, cursor, limit);
        return refusal is not null ? NotFound(new { error = "Lead not found" }) : Ok(page);
    }

    // GET /leads/{id}/timeline — the unified record timeline (design doc
    // to-do/e1-event-backbone-design.md §7/§8), newest first, cursor-paged,
    // optionally filtered by `kinds` (comma-separated: activity, stage, money,
    // change). Same 404-not-403 record access as GET /leads/{id}/history.
    [HttpGet("{id:guid}/timeline")]
    public async Task<IActionResult> Timeline(Guid id, [FromQuery] string? cursor, [FromQuery] int? limit, [FromQuery] string? kinds)
    {
        var (refusal, page) = await _leads.TimelineAsync(
            await AccessAsync(), LeadViewOf(), User.HasPermission(OrganizationPermissions.ViewFinancials), id, cursor, limit, kinds);
        return refusal is not null ? NotFound(new { error = "Lead not found" }) : Ok(page);
    }

    /// <summary>The one place a write refusal becomes a status code. Each
    /// structured shape is rebuilt exactly as these routes have always returned
    /// it — clients branch on the code and use the payload.</summary>
    private IActionResult WriteRefused(SalesApi.ProcessLayer.Leads.LeadWriteProcess.Refusal r)
    {
        if (r.Code == "form_requirements")
            return BadRequest(new { error = r.Reason, code = r.Code, missing = r.Missing });
        if (r.Code == "stage_requirements")
            return BadRequest(new { error = r.Reason, code = r.Code, stage = r.Stage, missing = r.Missing });
        if (r.Code == "reopen_requires_approval")
            return Conflict(new
            {
                error = r.Reason, code = r.Code,
                from_status = r.FromStatus, target_status = r.TargetStatus,
            });
        if (r.Code == "account_link_confirmation" && r.LinkPrompt is { } prompt)
            return BadRequest(new
            {
                error = prompt.Question,
                code = r.Code,
                prompt.Kind,
                prompt.Company,
                prompt.CurrentAccount,
                prompt.Candidates,
                prompt.Choices,
            });
        if (r.Code == "open_deal_exists")
            return Conflict(new { error = r.Reason, code = r.Code, open_deals = r.OpenDeals, possible_duplicate_hidden = r.PossibleDuplicateHidden ? true : (bool?)null, registered_by_partner = r.RegisteredByPartner ? true : (bool?)null });
        if (r.Code == SensitiveWriteGuard.Code)
            return BadRequest(new { error = r.Reason, code = r.Code, fields = r.Fields });
        if (r.Code is not null && r.Conflict) return Conflict(new { error = r.Reason, code = r.Code });
        if (r.Code is not null) return BadRequest(new { error = r.Reason, code = r.Code });
        if (r.NotFound) return NotFound(new { error = r.Reason });
        if (r.Forbidden) return StatusCode(403, new { error = r.Reason });
        if (r.Conflict) return Conflict(new { error = r.Reason });
        return BadRequest(new { error = r.Reason });
    }

    /// <summary>Everything about the caller these writes need, resolved once.</summary>
    private async Task<SalesApi.ProcessLayer.Leads.LeadActor> ActorAsync() => new(
        User.UserId(), User.OrgId(), await ActorNameAsync(), User.IsManager(),
        await VisibilityAsync(), User.HasPermission(OrganizationPermissions.TagCreate));

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] LeadInput input)
    {
        var (refusal, dto) = await _leads.CreateAsync(
            await AccessAsync(), LeadViewOf(), await ActorAsync(), input);
        return refusal is not null ? WriteRefused(refusal) : StatusCode(201, dto);
    }

    // POST /leads/with-files - multipart: field "lead" = the exact JSON body POST /leads takes, plus zero or more files named
    // "gate:{requirement_key}" (one each) for the target stage's file gates. Same validation, response and refusal codes as
    // POST /leads; the files are stored on the new lead (tag workflow:{stage}:{key}) and count toward the stage gate. All or
    // nothing - see LeadWriteProcess.CreateAsync.
    private const long MaxGateFileBytes = UploadLimits.StaffFileBytes; // the same per-file cap POST /attachments has
    private const string GateFilePrefix = "gate:";

    [HttpPost("with-files")]
    [RequestSizeLimit(UploadLimits.StaffMultiFileRequestBytes)]
    [StorageUnavailableFilter]
    public async Task<IActionResult> CreateWithFiles()
    {
        if (!Request.HasFormContentType) return BadRequest(new { error = "Send multipart/form-data with a 'lead' field." });
        var form = await Request.ReadFormAsync(HttpContext.RequestAborted);
        var json = form["lead"].ToString();
        if (string.IsNullOrWhiteSpace(json)) return BadRequest(new { error = "The 'lead' field is required." });

        var options = HttpContext.RequestServices
            .GetRequiredService<Microsoft.Extensions.Options.IOptions<JsonOptions>>().Value.JsonSerializerOptions;
        LeadInput? input;
        try { input = JsonSerializer.Deserialize<LeadInput>(json, options); }
        catch (JsonException) { return BadRequest(new { error = "The 'lead' field is not valid JSON for a lead." }); }
        if (input is null) return BadRequest(new { error = "The 'lead' field is required." });

        foreach (var file in form.Files)
        {
            if (!file.Name.StartsWith(GateFilePrefix, StringComparison.Ordinal) || file.Name.Length == GateFilePrefix.Length)
                return BadRequest(new { error = $"Unexpected file field '{file.Name}'. Name each file gate:<requirement_key>." });
            if (file.Length == 0) return BadRequest(new { error = $"The file for '{file.Name[GateFilePrefix.Length..]}' is empty." });
            if (file.Length > MaxGateFileBytes) return BadRequest(new { error = $"The file for '{file.Name[GateFilePrefix.Length..]}' is too large ({UploadLimits.Describe(MaxGateFileBytes)} at most)." });
        }

        var streams = new List<Stream>();
        try
        {
            var gateFiles = form.Files.Select(file =>
            {
                var stream = file.OpenReadStream();
                streams.Add(stream);
                return new SalesApi.ProcessLayer.Leads.LeadWriteProcess.GateFile(
                    file.Name[GateFilePrefix.Length..], file.FileName, file.ContentType, file.Length, stream);
            }).ToList();

            var (refusal, dto) = await _leads.CreateAsync(
                await AccessAsync(), LeadViewOf(), await ActorAsync(), input, gateFiles);
            return refusal is not null ? WriteRefused(refusal) : StatusCode(201, dto);
        }
        finally
        {
            foreach (var stream in streams) await stream.DisposeAsync();
        }
    }

    // Read-only: which playbook a lead with these values would land on if
    // created now. The new-lead form offers that playbook's stages, because the
    // create below checks the stage against exactly this playbook — offering the
    // org-wide list let a rep pick a stage the create then refused as unknown.
    [HttpPost("playbook-preview")]
    public async Task<IActionResult> PlaybookPreview([FromBody] LeadInput input) =>
        Ok(await _leads.PreviewPlaybookAsync(await ActorAsync(), input));

    // E3.12 — "the form shown is the form checked". Read-only: the exact form
    // a lead created right now would be captured on and validated against —
    // same resolver Create itself calls (LeadFormRoutingService.
    // ResolveForCreateAsync via LeadWriteProcess.PreviewCreateFormAsync), same
    // inputs a client can supply ahead of the submit. GET /settings/lead-form
    // keeps working unconditionally against the org's Default form for old
    // client builds that never call this.
    [HttpPost("form-preview")]
    public async Task<IActionResult> FormPreview([FromBody] LeadFormForCreateInput input) =>
        Ok(await _leads.PreviewCreateFormAsync(await ActorAsync(), User.Role(), input));

    // E3.12's edit twin — the form THIS lead resolves to right now
    // (LeadFormRoutingService.ResolveForLeadAsync), same 404-not-403 record
    // access as GET /leads/{id}/history.
    [HttpGet("{id:guid}/form")]
    public async Task<IActionResult> LeadForm(Guid id)
    {
        var dto = await _leads.PreviewLeadFormAsync(await AccessAsync(), id, User.Role());
        return dto is null ? NotFound(new { error = "Lead not found" }) : Ok(dto);
    }

    // Item 6 — the stage-move dialog's question before a move: the "rep picks" tasks the move creates (the current stage's leave tasks, the target's
    // enter tasks) and the caller's teams with their members. Empty lists when nothing needs a pick. Same 404/403 rules as editing the lead.
    [HttpGet("{id:guid}/stage-tasks")]
    public async Task<IActionResult> StageTaskPicks(Guid id, [FromQuery] string to)
    {
        if (string.IsNullOrWhiteSpace(to)) return BadRequest(new { error = "to is required" });
        var (refusal, dto) = await _leads.StageTaskPicksAsync(await AccessAsync(), await ActorAsync(), id, to.Trim());
        return refusal is not null ? WriteRefused(refusal) : Ok(dto);
    }

    // Parked item 7 - the stage-move dialog's question for a move to the Won stage: the deal values / payment term the win asks (applies=false when none).
    // Same 404/403 rules as editing the lead. Answers go back as win_values on PATCH /leads/{id}.
    [HttpGet("{id:guid}/win-ask")]
    public async Task<IActionResult> WinAsk(Guid id, [FromQuery] string to)
    {
        if (string.IsNullOrWhiteSpace(to)) return BadRequest(new { error = "to is required" });
        var (refusal, dto) = await _leads.WinAskAsync(await AccessAsync(), LeadViewOf(), User.UserId(), id, to.Trim());
        return refusal is not null ? WriteRefused(refusal) : Ok(dto);
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] LeadInput input)
    {
        var (refusal, dto) = await _leads.UpdateAsync(
            await AccessAsync(), LeadViewOf(), await ActorAsync(), id, input);
        return refusal is not null ? WriteRefused(refusal) : Ok(dto);
    }

    private static ContactDto ContactToDto(Contact c) =>
        new(c.Id, c.AccountId, c.Name, c.Title, c.Email, c.Phone, c.Notes, c.CreatedAt, c.PhoneCountryCode);

    // POST /leads/{id}/promote-contact — "make sure this lead's person exists
    // as a contact on its account, and point the lead at them". Manual, one
    // click, on lead detail — never automatic on link or on win. See
    // LeadAssignProcess for why this takes TWO permission checks, not one.
    [HttpPost("{id:guid}/promote-contact")]
    public async Task<IActionResult> PromoteContact(Guid id)
    {
        var (refusal, dto) = await _leads.PromoteContactAsync(await AccessAsync(), id);
        return refusal is not null ? AssignRefused(refusal) : Ok(dto);
    }

    // POST /leads/backfill-team - give a team to leads that have none, derived
    // from the owner. A repair for leads created while their owner was in no
    // team (see LeadWriteProcess.BackfillTeamsAsync); NOT a way to set a lead's
    // team by hand, which deliberately does not exist - a lead belongs to an
    // owner and its team follows.
    //
    // Org admin, not manager: it can rewrite every teamless lead in the org in
    // one call. `preview=true` reports what it WOULD do and writes nothing,
    // which is the sensible first call on a pipeline of any size.
    //
    // `limit` caps how many leads ONE call repairs, and exists because the
    // uncapped version could not answer inside the gateway timeout: repairing
    // 3,126 leads returned a 504 while the task committed anyway, which is a
    // coin flip dressed as a success. Call it until `updated` and
    // `cleared_from_archived_team` are both 0 - the operation is idempotent, so
    // a lead already holding the right team is simply not selected again.
    //
    // `remaining_teamless` is for reading, NOT for looping on: a lead nobody can
    // resolve stays stale by definition, so that number has a floor above zero
    // on an org with ambiguous owners. Loop on progress instead.
    [HttpPost("backfill-team")]
    public async Task<IActionResult> BackfillTeam(
        [FromQuery] bool preview = false, [FromQuery] int? limit = null)
    {
        if (!User.IsOrgAdmin())
            return StatusCode(403, new { error = "Only an organization admin can backfill lead teams." });
        return Ok(await _leads.BackfillTeamsAsync(preview, limit, HttpContext.RequestAborted));
    }

    // POST /leads/bulk — apply an action to many leads at once. Each lead is
    // checked individually; un-manageable or invalid ones are skipped rather
    // than failing the batch. Backward stage moves are skipped (they need the
    // single-lead flow with a manager reason). See LeadWriteProcess for why the
    // target stage is validated against the ORG's list rather than per-playbook.
    [HttpPost("bulk")]
    public async Task<IActionResult> Bulk([FromBody] BulkInput input)
    {
        var access = await AccessAsync();
        // "Select all N matching": the same team gate GET /leads and /leads/count apply to a teamId filter.
        if (input?.Match is { } m && TeamFilterRefusal(access, m.TeamId) is { } denied) return denied;
        try
        {
            return await RefusingBadQuery(async () =>
        {
            var (refusal, dto) = await _leads.BulkAsync(access, LeadViewOf(), await ActorAsync(), input!);
            return refusal is not null ? WriteRefused(refusal) : Ok(dto);
        });
        }
        catch (SalesApi.Services.BulkMatchTooLargeException e)
        {
            return BadRequest(new { error = e.Message, code = "match_too_large", count = e.Count, limit = e.Limit });
        }
    }

    // POST /leads/bulk/ids - what "select all N matching" resolves to (same team gate, scoping and bulk_match_limit as POST /leads/bulk
    // with `match`), so the client can run a big action in small batches with progress. Nothing is changed.
    [HttpPost("bulk/ids")]
    public async Task<IActionResult> BulkIds([FromBody] LeadMatchInput match)
    {
        var access = await AccessAsync();
        if (TeamFilterRefusal(access, match.TeamId) is { } denied) return denied;
        try
        {
            return await RefusingBadQuery(async () =>
                Ok(new BulkIdsResult(await _leads.MatchingIdsAsync(access, LeadViewOf(), User.UserId(), match))));
        }
        catch (SalesApi.Services.BulkMatchTooLargeException e)
        {
            return BadRequest(new { error = e.Message, code = "match_too_large", count = e.Count, limit = e.Limit });
        }
    }

    /// <summary>The one place an assign/promote refusal becomes a status code.
    /// The owner-outside-team case is a 409 carrying the two team sets, so the
    /// client can offer a retry rather than just reporting a wall.</summary>
    private IActionResult AssignRefused(SalesApi.ProcessLayer.Leads.LeadAssignProcess.Refusal refusal) =>
        refusal.OwnerOutsideTeam
            ? Conflict(new
            {
                error = refusal.Reason,
                code = "owner_outside_team",
                lead_team_id = refusal.LeadTeamId,
                owner_team_ids = refusal.OwnerTeamIds,
            })
        : refusal.NotFound ? NotFound(new { error = refusal.Reason })
        : refusal.Forbidden ? StatusCode(403, new { error = refusal.Reason })
        : BadRequest(new { error = refusal.Reason });

    // POST /leads/{id}/assign — reassign a lead's owner (managers/admins only).
    // team_id deliberately does not follow the owner; see LeadAssignProcess.
    [HttpPost("{id:guid}/assign")]
    public async Task<IActionResult> Assign(Guid id, [FromBody] AssignInput input)
    {
        var (refusal, dto) = await _leads.AssignAsync(
            await AccessAsync(), LeadViewOf(), User.UserId(), await ActorNameAsync(), User.OrgId(),
            User.IsManager(), await VisibilityAsync(), id, input);
        return refusal is not null ? AssignRefused(refusal) : Ok(dto);
    }

    [HttpGet("{id:guid}/activities")]
    public async Task<IActionResult> Activities(Guid id)
    {
        var (refusal, dto) = await _leads.ActivitiesAsync(await AccessAsync(), id);
        return refusal is not null ? LeadRefused(refusal) : Ok(dto);
    }

    // POST /leads/{id}/activities — logs what a person deliberately did. The
    // owner is told unless they are the one who did it, and status_change rows
    // are never announced; both rules live with the write, in LeadReadProcess.
    [HttpPost("{id:guid}/activities")]
    public async Task<IActionResult> AddActivity(Guid id, [FromBody] ActivityInput input)
    {
        var (refusal, dto) = await _leads.AddActivityAsync(
            await AccessAsync(), User.UserId(), await ActorNameAsync(), id, input);
        return refusal is not null ? LeadRefused(refusal) : StatusCode(201, dto);
    }

    /// <summary>The one place a quote refusal becomes a status code.</summary>
    private IActionResult QuoteRefused(SalesApi.ProcessLayer.Leads.LeadQuoteProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason })
        : refusal.Forbidden ? StatusCode(403, new { error = refusal.Reason })
        : BadRequest(new { error = refusal.Reason });

    /// <summary>E10.5: the generator's additions to a quote (snapshot, change summary) quote figures, so they follow lead_values.view.</summary>
    private bool QuoteValuesVisible() => User.HasPermission(OrganizationPermissions.ViewLeadValues);

    // GET /leads/{id}/proposals
    [HttpGet("{id:guid}/proposals")]
    public async Task<IActionResult> Proposals(Guid id)
    {
        var (refusal, dto) = await _leads.QuotesAsync(await AccessAsync(), id);
        return refusal is not null ? QuoteRefused(refusal) : Ok(ProposalMasking.Mask(dto!, QuoteValuesVisible()));
    }

    // POST /leads/{id}/proposal — generate from the lead + selected modules (the
    // "tracked" quote flow).
    [HttpPost("{id:guid}/proposal")]
    public async Task<IActionResult> GenerateProposal(Guid id, [FromBody] GenerateProposalInput input)
    {
        var (refusal, dto) = await _leads.GenerateQuoteAsync(await AccessAsync(), User.UserId(), id, input);
        return refusal is not null ? QuoteRefused(refusal) : StatusCode(201, ProposalMasking.Mask(dto!, QuoteValuesVisible()));
    }

    [HttpPost("{id:guid}/proposals/document")]
    public async Task<IActionResult> GenerateQuoteDocument(Guid id, [FromBody] GenerateQuoteDocumentInput input)
    {
        var (refusal, dto) = await _leads.GenerateQuoteDocumentAsync(await AccessAsync(), User.UserId(), id, input);
        return refusal is not null ? QuoteRefused(refusal) : StatusCode(201, ProposalMasking.Mask(dto!, QuoteValuesVisible()));
    }

    // Accepting an already-superseded quote is legal but gated on
    // quotes.override_status, and it writes an OVERRIDE note naming who did it.
    // Both the permission and the actor's display name are facts about the
    // CALLER, so they are resolved here and passed down.
    [HttpPatch("{id:guid}/proposals/{pid:guid}")]
    public async Task<IActionResult> UpdateProposal(Guid id, Guid pid, [FromBody] ProposalStatusInput input)
    {
        // The document text prints the figures, so a caller who cannot see them reads it back as null (ProposalMasking).
        // Saving over it would replace the real text with whatever the client holds, so refuse the edit outright.
        if (input.Content != null && !QuoteValuesVisible())
            return StatusCode(403, new { error = "You can't edit this quote's text without permission to see its values." });
        var (refusal, dto) = await _leads.UpdateQuoteAsync(
            await AccessAsync(), User.UserId(), await ActorNameAsync(),
            User.HasPermission(OrganizationPermissions.OverrideQuoteStatus), id, pid, input);
        return refusal is not null ? QuoteRefused(refusal) : Ok(ProposalMasking.Mask(dto!, QuoteValuesVisible()));
    }

    // POST /leads/{id}/proposals/{pid}/share-link — { token }: the accept link's token, minted if the quote has none, status untouched
    // (D3). Same manage-the-deal rule as the PATCH; the public page refuses the quote until it is sent.
    [HttpPost("{id:guid}/proposals/{pid:guid}/share-link")]
    public async Task<IActionResult> ProposalShareLink(Guid id, Guid pid)
    {
        var (refusal, token) = await _leads.QuoteShareLinkAsync(await AccessAsync(), id, pid);
        return refusal is not null ? QuoteRefused(refusal) : Ok(new { token });
    }

    [HttpPost("{id:guid}/proposals/{pid:guid}/revise")]
    public async Task<IActionResult> ReviseProposal(Guid id, Guid pid)
    {
        var (refusal, dto) = await _leads.ReviseQuoteAsync(await AccessAsync(), User.UserId(), id, pid);
        return refusal is not null ? QuoteRefused(refusal) : StatusCode(201, ProposalMasking.Mask(dto!, QuoteValuesVisible()));
    }

    /// <summary>The caller's render permissions, resolved once per request. See
    /// ProcessLayer.Leads.LeadView for why the mapper takes these as data.</summary>
    private LeadView LeadViewOf() => _leadView ??= CallerContext.LeadViewOf(User);

    /// <summary>The one place a merge/delete refusal becomes a status code.</summary>
    private IActionResult MergeRefused(SalesApi.ProcessLayer.Leads.LeadMergeProcess.Refusal refusal) =>
        refusal.Conflict ? Conflict(new { error = refusal.Reason, code = refusal.Code, issued_invoices = refusal.IssuedInvoices })
        : refusal.NotFound ? NotFound(new { error = refusal.Reason })
        : refusal.Forbidden ? StatusCode(403, new { error = refusal.Reason })
        : BadRequest(new { error = refusal.Reason });

    // GET /leads/merge-preview — read-only: shows what a merge of duplicate_id
    // into primary_id would do, before anything is written. Field-level outcome
    // (which value survives, and whether the duplicate's value would be
    // silently discarded) plus counts of related records that would move.
    [HttpGet("merge-preview")]
    public async Task<IActionResult> MergePreview(
        [FromQuery(Name = "primary_id")] Guid? primaryId, [FromQuery(Name = "duplicate_id")] Guid? duplicateId)
    {
        var (refusal, dto) = await _leads.MergePreviewAsync(
            await AccessAsync(), LeadViewOf(), primaryId, duplicateId);
        return refusal is not null ? MergeRefused(refusal) : Ok(dto);
    }

    // POST /leads/merge — folds duplicate_id into primary_id. Reversible for
    // MergeUndoWindow; see LeadMergeProcess for why the log row is written in
    // the same unit of work as the merge itself.
    [HttpPost("merge")]
    public async Task<IActionResult> Merge([FromBody] MergeInput input)
    {
        var (refusal, dto) = await _leads.MergeAsync(
            await AccessAsync(), LeadViewOf(), User.UserId(), input);
        return refusal is not null ? MergeRefused(refusal) : Ok(dto);
    }

    [HttpPost("merges/{id:guid}/undo")]
    public async Task<IActionResult> UndoMerge(Guid id)
    {
        var (refusal, dto) = await _leads.UndoMergeAsync(
            await AccessAsync(), LeadViewOf(), User.UserId(), User.OrgId(), id);
        return refusal is not null ? MergeRefused(refusal) : Ok(dto);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var refusal = await _leads.DeleteAsync(await AccessAsync(), id);
        return refusal is not null ? MergeRefused(refusal) : NoContent();
    }
}

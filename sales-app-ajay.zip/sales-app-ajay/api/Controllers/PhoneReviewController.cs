using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Contracts;
using SalesApi.ExperienceLayer.PhoneReview;
using SalesApi.ProcessLayer.PhoneReview;
using SalesApi.Services;

namespace SalesApi.Controllers;

// Admin → "Phone numbers to review" (owner 2026-09-30, to-do/epics-ai-native-crm.md
// "Phone storage" row). ManageSettings, own org only (the ambient tenant query
// filter, not anything checked here). What is left here, deliberately: routing,
// [Authorize], the inline permission check, model binding and status codes —
// same split AiExecutionLogController's own header documents.
[ApiController]
[Authorize]
public class PhoneReviewController : ControllerBase
{
    private readonly PhoneReviewExperience _review;
    public PhoneReviewController(PhoneReviewExperience review) => _review = review;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);

    private static IActionResult FromRefusal(PhoneReviewProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : new BadRequestObjectResult(new { error = refusal.Reason });

    // GET /admin/phone-review?kind=lead|contact&cursor=&limit= — rows needing a
    // country, keyset-paginated.
    [HttpGet("admin/phone-review")]
    public async Task<IActionResult> List([FromQuery] string? kind, [FromQuery] string? cursor, [FromQuery] int? limit)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot review phone numbers." });
        var (list, refusal) = await _review.ListAsync(kind, cursor, limit);
        return refusal is not null ? FromRefusal(refusal) : Ok(list);
    }

    // GET /admin/phone-review/count — for the Admin hub card.
    [HttpGet("admin/phone-review/count")]
    public async Task<IActionResult> Count()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot review phone numbers." });
        return Ok(await _review.CountAsync());
    }

    // POST /admin/phone-review/apply — converts every confirmed row.
    [HttpPost("admin/phone-review/apply")]
    public async Task<IActionResult> Apply([FromBody] PhoneReviewApplyInput input)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot review phone numbers." });
        var (response, refusal) = await _review.ApplyAsync(input, User.UserId());
        return refusal is not null ? FromRefusal(refusal) : Ok(response);
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Notifications;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// One person's own notification settings, plus their in-app inbox. Everything here
/// is scoped to the caller — there is no path for one user to read or change
/// another's, deliberately: these are personal preferences, not org configuration,
/// and an admin editing them would make every switch on the screen untrustworthy.
/// </summary>
[ApiController]
[Route("notifications")]
[Authorize]
public class NotificationsController : ControllerBase
{
    private readonly NotificationsExperience _notifications;
    public NotificationsController(NotificationsExperience notifications) => _notifications = notifications;

    // GET /notifications/settings — the whole preferences screen in one call.
    [HttpGet("settings")]
    public async Task<IActionResult> GetSettings() =>
        Ok(await _notifications.SettingsAsync(User.UserId(), User.OrgId()));

    // Bound as a raw JsonElement, not the typed NotificationSettingsInput,
    // specifically so `quiet_from`/`quiet_to` PRESENCE survives — see JsonBody's
    // doc comment. An explicit `"quiet_from": null` now clears the field exactly
    // like `""` already did; omitting the key still leaves it untouched.
    [HttpPatch("settings")]
    public async Task<IActionResult> UpdateSettings([FromBody] System.Text.Json.JsonElement body)
    {
        var input = new NotificationSettingsInput(
            JsonBody.Bool(body, "push_enabled"), JsonBody.Bool(body, "in_app_enabled"), JsonBody.Bool(body, "email_enabled"),
            JsonBody.String(body, "preset"), JsonBody.String(body, "quiet_from"), JsonBody.String(body, "quiet_to"),
            JsonBody.Int(body, "utc_offset_minutes"));
        var result = await _notifications.UpdateSettingsAsync(
            User.UserId(), User.OrgId(), input,
            JsonBody.HasProperty(body, "quiet_from"), JsonBody.HasProperty(body, "quiet_to"));
        if (result is null) return BadRequest(new { error = "Unknown preset." });
        return Ok(result);
    }

    [HttpPut("settings/events")]
    public async Task<IActionResult> SetEventPreference([FromBody] NotificationPreferenceInput input)
    {
        var result = await _notifications.SetEventPreferenceAsync(User.UserId(), User.OrgId(), input);
        if (result is null) return BadRequest(new { error = "Unknown event type." });
        return Ok(result);
    }

    [HttpPut("settings/teams")]
    public async Task<IActionResult> SetTeamPreference([FromBody] TeamNotificationPreferenceInput input)
    {
        if (input.TeamId is not Guid || !TeamNotificationScope.IsValid(input.Scope))
            return BadRequest(new { error = "A team and a valid scope are required." });

        var result = await _notifications.SetTeamPreferenceAsync(User.UserId(), User.OrgId(), input);
        if (result is null) return NotFound(new { error = "Team not found" });
        return Ok(result);
    }

    // --- the in-app inbox ----------------------------------------------------

    [HttpGet]
    public async Task<IActionResult> Inbox([FromQuery] bool unreadOnly = false) =>
        Ok(await _notifications.InboxAsync(User.UserId(), unreadOnly));

    [HttpGet("unread-count")]
    public async Task<IActionResult> UnreadCount() =>
        Ok(new { count = await _notifications.UnreadCountAsync(User.UserId()) });

    [HttpPost("read")]
    public async Task<IActionResult> MarkRead([FromBody] List<Guid>? ids) =>
        Ok(new { updated = await _notifications.MarkReadAsync(User.UserId(), ids) });
}

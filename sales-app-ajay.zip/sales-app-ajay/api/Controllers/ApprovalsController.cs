using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Approvals;
using SalesApi.Models;
using SalesApi.ProcessLayer.Approvals;
using SalesApi.Services;

namespace SalesApi.Controllers;

// Manager sign-off workflow. Reps raise requests (reassign a lead to themselves,
// approve a discount, reopen a closed deal, or — D9/D9a — request an exception
// to a blocked stage gate); an approver decides. Approving a reassignment
// performs it, and so does approving a reopen or a gate exception.
//
// D9a #1 — ViewFinancials USED to gate this whole controller. That fits
// Reassign/Discount (money and ownership) and, for no stated reason, Reopen —
// preserved rather than loosened (narrowing in scope, widening not). It does
// NOT fit GateException: a rep blocked by "Country is required" would have
// needed financial access merely to ask for an exception. So the permission
// moved off the class and onto each endpoint, per-type — see
// ApprovalTypes.RequireViewFinancials and every check below that reads it.
//
// MIGRATED to the layered API (api-led migration, step 8). Business rules that
// used to live inline here now live in SalesApi.ProcessApi/Approvals/
// ApprovalProcess.cs, reached through SalesApi.ExperienceApi/Approvals/
// ApprovalsExperience.cs. What is left here: routing, [Authorize], every
// permission check (D9a #1/#2 — ViewFinancials/DecideApprovals and the
// gate-exception approver-policy check), model binding, and choosing the HTTP
// status for a Refusal.
//
// `_db` stays on this controller for exactly two System-service factory calls
// that resolve the CALLER's own scope/authority — RecordAccessContexts.ForAsync
// (team/visibility scope, same as CollectionsController) and
// GateEscalationSettingsService's approver-policy read (D9a #2 — an ORG
// SETTING, not a hardcoded role; read GateEscalationSettingsService itself
// rather than this comment for what it resolves). Both are authorization
// inputs, resolved from the caller before Process is ever called — never a
// domain query, and never handed to Process as a raw ClaimsPrincipal or
// AppDbContext lookup Process would have to repeat.
[ApiController]
[Route("approvals")]
[Authorize]
public class ApprovalsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly CallerContext _caller;
    private readonly ApprovalsExperience _approvals;
    public ApprovalsController(AppDbContext db, CallerContext caller, ApprovalsExperience approvals)
    {
        _db = db;
        _caller = caller;
        _approvals = approvals;
    }

    private IActionResult FromRefusal(ApprovalProcess.Refusal refusal) => refusal.Kind switch
    {
        ApprovalProcess.RefusalKind.NotFound => NotFound(refusal.Body),
        ApprovalProcess.RefusalKind.Conflict => Conflict(refusal.Body),
        ApprovalProcess.RefusalKind.Forbidden => StatusCode(403, refusal.Body),
        _ => BadRequest(refusal.Body),
    };

    // GET /approvals?status=pending — managers see the team; reps see their own.
    [HttpGet]
    public async Task<IActionResult> List(string? status)
    {
        var ctx = await _caller.ForAsync(User);
        var hasViewFinancials = User.HasPermission(OrganizationPermissions.ViewFinancials);
        var hasViewLeadValues = User.HasPermission(OrganizationPermissions.ViewLeadValues);
        return Ok(await _approvals.ListAsync(ctx, status, hasViewFinancials, hasViewLeadValues));
    }

    // GET /approvals/pending-count — badge for managers.
    [HttpGet("pending-count")]
    public async Task<IActionResult> PendingCount()
    {
        if (!User.IsManager()) return Ok(new { count = 0 });
        var ctx = await _caller.ForAsync(User);
        var hasFinancials = User.HasPermission(OrganizationPermissions.ViewFinancials);
        // D9a #2 — the org's configured approver policy for gate-exception
        // requests, resolved through GateEscalationSettingsService rather than a
        // hardcoded role.
        var approverPolicy = await GateEscalationSettingsService.GetApproverPolicyAsync(_db);
        var canDecideGateExceptions = GateEscalationSettingsService.CanApprove(approverPolicy, User);
        // E0.1 — a caller's own pending requests don't count as "waiting on
        // you" when self-decision is blocked (the default).
        var selfDecisionPolicy = await GateEscalationSettingsService.GetSelfDecisionPolicyAsync(_db);
        var count = await _approvals.PendingCountAsync(ctx, hasFinancials, canDecideGateExceptions, selfDecisionPolicy);
        return Ok(new { count });
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] ApprovalInput input)
    {
        // D9a #1 — the pre-existing three types keep exactly today's gate.
        // GateException is new and was never behind ViewFinancials — that is the
        // whole point (D9): a rep blocked by "Country is required" must not need
        // financial access merely to ask for an exception. `Contains` on an
        // invalid/null type is simply false, so this never blocks a request
        // Process is about to refuse anyway with "type must be...".
        if (ApprovalTypes.RequireViewFinancials.Contains(input.Type)
            && !User.HasPermission(OrganizationPermissions.ViewFinancials))
            return StatusCode(403, new { error = "Your role does not have the 'financials.view' permission." });

        var hasViewLeadValues = User.HasPermission(OrganizationPermissions.ViewLeadValues);
        var outcome = await _approvals.CreateAsync(input, User.UserId(), hasViewLeadValues);
        if (outcome.Refusal is not null) return FromRefusal(outcome.Refusal);
        return StatusCode(201, outcome.Approval);
    }

    // POST /approvals/{id}/decide — managers approve/reject.
    //
    // E0.1 — two gates ADDED on top of the type-specific permission checks
    // below, in this order: (1) TEAM SCOPE — a decider may decide a request
    // only if its requester is within the decider's visible people, computed
    // exactly as List/PendingCount already do; a request outside that scope
    // 404s, same body as a missing id, so ids cannot be probed for existence.
    // (2) SELF-DECISION — an org setting (default: blocked) refusing a decider
    // who IS the requester with 403. Both apply to all four approval types and
    // sit in ApprovalProcess.DecideAsync, after the existing permission checks
    // and before any mutation — see the ordering note there.
    [HttpPost("{id:guid}/decide")]
    public async Task<IActionResult> Decide(Guid id, [FromBody] ApprovalDecisionInput input)
    {
        // D9a #1/#2 — who may decide depends on the type, which only the request
        // itself carries — so the three permission FACTS travel into Process and
        // the dispatch on req.Type happens there. Every fact here is resolved
        // from the caller alone, no request row involved: GateException follows
        // the org-configured approver policy (D9a #2: managers, the default and
        // today's population, or org admins only); every other type keeps
        // EXACTLY today's dual gate — DecideApprovals, same as always, AND
        // ViewFinancials, preserved rather than loosened (D9a #1: "narrowing is
        // in scope, widening is not").
        var hasDecideApprovals = User.HasPermission(OrganizationPermissions.DecideApprovals);
        var hasViewFinancials = User.HasPermission(OrganizationPermissions.ViewFinancials);
        var approverPolicy = await GateEscalationSettingsService.GetApproverPolicyAsync(_db);
        var canDecideGateExceptions = GateEscalationSettingsService.CanApprove(approverPolicy, User);

        // E0.1 — same RecordAccessContext List/PendingCount build (the one
        // documented `_db` residual on this controller), and the org's
        // self-decision policy, resolved from the caller before Process runs.
        var ctx = await _caller.ForAsync(User);
        var selfDecisionPolicy = await GateEscalationSettingsService.GetSelfDecisionPolicyAsync(_db);
        var hasViewLeadValues = User.HasPermission(OrganizationPermissions.ViewLeadValues);

        var outcome = await _approvals.DecideAsync(
            id, input, User.UserId(), hasDecideApprovals, hasViewFinancials, canDecideGateExceptions,
            ctx, selfDecisionPolicy, hasViewLeadValues);
        if (outcome.Refusal is not null) return FromRefusal(outcome.Refusal);
        return Ok(outcome.Approval);
    }
}

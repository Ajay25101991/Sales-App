using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.EngagementLetters;
using SalesApi.ProcessLayer.EngagementLetters;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E10.9 - the engagement letter of an accepted generated proposal: make it, review it, send it from the rep's own mailbox, keep its
/// PDF, add a signed copy. Contract: to-do/proposal-generator-api.md ("E10.9 - engagement letters"). Routes, checks the permission,
/// picks a status code. Reading the letter needs only access to the deal; every write needs <c>proposals.generate_priced</c> or
/// <c>settings.manage</c> (as generating the proposal does) and the right to manage the deal.
/// </summary>
[ApiController]
[Route("leads/{leadId:guid}/proposals/{pid:guid}/engagement-letter")]
[Authorize]
public class EngagementLetterController : ControllerBase
{
    private readonly EngagementLetterExperience _letters;
    private readonly CallerContext _caller;

    public EngagementLetterController(EngagementLetterExperience letters, CallerContext caller)
    {
        _letters = letters;
        _caller = caller;
    }

    private bool CanUse() =>
        User.HasPermission(OrganizationPermissions.GeneratePricedProposals) || User.HasPermission(OrganizationPermissions.ManageSettings);

    private ObjectResult NoUse() => StatusCode(403, new { error = "Your role cannot generate priced proposals." });

    /// <summary>403/404/409/400/503 with <c>{error, code?}</c>; <c>code</c> is mailbox_reconnect_required, mailbox_not_connected or thread_not_in_mailbox.</summary>
    private IActionResult Respond<T>(EngagementLetterProcess.Result<T> r, int okStatus = 200) => r.Outcome switch
    {
        EngagementLetterProcess.Outcome.NotFound => NotFound(new { error = r.Error }),
        EngagementLetterProcess.Outcome.Forbidden => StatusCode(403, new { error = r.Error }),
        EngagementLetterProcess.Outcome.Conflict => Conflict(new { error = r.Error, code = r.Code }),
        EngagementLetterProcess.Outcome.Unavailable => StatusCode(503, new { error = r.Error, code = r.Code }),
        EngagementLetterProcess.Outcome.Invalid => BadRequest(new { error = r.Error, code = r.Code }),
        _ => StatusCode(okStatus, r.Value),
    };

    /// <summary>The letters made from this accepted proposal, newest first (an empty list when there is none yet).</summary>
    [HttpGet]
    public async Task<IActionResult> List(Guid leadId, Guid pid, CancellationToken ct) =>
        Respond(await _letters.ListAsync(await _caller.ForAsync(User), leadId, pid, ct));

    /// <summary>Makes the next letter version (a draft) from the accepted proposal. 201. Optional body <c>{ "variants": ["Mutual NDA", ...] }</c>
    /// makes one letter per named agreement, all of the same version (see <c>GET /document-templates</c> for the names); no body or
    /// no variants = the single unnamed letter as before.</summary>
    [HttpPost]
    public async Task<IActionResult> Generate(Guid leadId, Guid pid, [FromBody] GenerateEngagementLettersInput? input, CancellationToken ct)
    {
        if (!CanUse()) return NoUse();
        return Respond(await _letters.GenerateAsync(await _caller.ForAsync(User), User.UserId(), leadId, pid, input?.Variants, ct), 201);
    }

    /// <summary>Converts a letter's Word file to PDF again after a failure: the one named by <c>letter_id</c>, else the newest still
    /// without a PDF.</summary>
    [HttpPost("pdf/retry")]
    public async Task<IActionResult> RetryPdf(Guid leadId, Guid pid, [FromQuery(Name = "letter_id")] Guid? letterId, CancellationToken ct)
    {
        if (!CanUse()) return NoUse();
        return Respond(await _letters.RetryPdfAsync(await _caller.ForAsync(User), User.UserId(), leadId, pid, letterId, ct));
    }

    /// <summary>Adds a PDF the rep made themselves (multipart <c>file</c>) as a letter's PDF: <c>letter_id</c>, else the newest still without one.</summary>
    [HttpPost("pdf")]
    [RequestSizeLimit(26 * 1024 * 1024)]
    public async Task<IActionResult> UploadPdf(Guid leadId, Guid pid, IFormFile? file, [FromQuery(Name = "letter_id")] Guid? letterId, CancellationToken ct)
    {
        if (!CanUse()) return NoUse();
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required" });
        await using var stream = file.OpenReadStream();
        using var ms = new MemoryStream();
        await stream.CopyToAsync(ms, ct);
        return Respond(await _letters.UploadPdfAsync(await _caller.ForAsync(User), User.UserId(), leadId, pid, ms.ToArray(), letterId, ct));
    }

    /// <summary>Emails of this deal that are in the caller's own mailbox, to choose a thread to reply on (the default is the first).</summary>
    [HttpGet("threads")]
    public async Task<IActionResult> Threads(Guid leadId, Guid pid, CancellationToken ct)
    {
        if (!CanUse()) return NoUse();
        return Respond(await _letters.ThreadsAsync(await _caller.ForAsync(User), User.UserId(), leadId, pid, ct));
    }

    /// <summary>The email as the org's "Engagement letter email" template fills it for this letter (editable before sending).</summary>
    [HttpGet("email")]
    public async Task<IActionResult> Email(Guid leadId, Guid pid, [FromQuery(Name = "letter_ids")] List<Guid>? letterIds, CancellationToken ct)
    {
        if (!CanUse()) return NoUse();
        return Respond(await _letters.EmailAsync(await _caller.ForAsync(User), await _caller.DisplayNameAsync(User), leadId, pid, letterIds, ct));
    }

    /// <summary>Sends the reviewed letter from the caller's own Microsoft 365 mailbox (a reply on a thread, or a new email) with its PDF and the accept link.</summary>
    [HttpPost("send")]
    public async Task<IActionResult> Send(Guid leadId, Guid pid, [FromBody] SendEngagementLetterInput? input, CancellationToken ct)
    {
        if (!CanUse()) return NoUse();
        return Respond(await _letters.SendAsync(
            await _caller.ForAsync(User), User.UserId(), await _caller.DisplayNameAsync(User), leadId, pid, input ?? new SendEngagementLetterInput(), ct));
    }

    /// <summary>Adds a signed copy (multipart <c>file</c>) to the deal as a signed_proposal file and remembers it on a letter: the one named by
    /// <c>letter_id</c> (query or form field), else the newest. Signed PER AGREEMENT.</summary>
    [HttpPost("signed")]
    [RequestSizeLimit(UploadLimits.StaffRequestBytes)]
    public async Task<IActionResult> UploadSigned(
        Guid leadId, Guid pid, IFormFile? file, [FromQuery(Name = "letter_id")] Guid? letterIdQuery, [FromForm(Name = "letter_id")] Guid? letterIdForm, CancellationToken ct)
    {
        if (!CanUse()) return NoUse();
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required" });
        var perms = new AttachmentPermissions(
            User.HasPermission(OrganizationPermissions.ViewFinancials), User.HasPermission(OrganizationPermissions.ViewContactDetails));
        await using var stream = file.OpenReadStream();
        return Respond(await _letters.UploadSignedAsync(
            await _caller.ForAsync(User), perms, User.UserId(), await _caller.DisplayNameAsync(User), User.OrgId(), leadId, pid,
            file.FileName, file.ContentType, file.Length, stream, letterIdQuery ?? letterIdForm, ct), 201);
    }
}

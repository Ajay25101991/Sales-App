using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Mailbox;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// The "Unmatched emails" review list (owner decisions 2026-10-14): email to a team address from a sender that matched
/// no lead, contact or account. Mirrors <see cref="WhatsAppUnmatchedController"/>: list, link to a lead, create a lead,
/// dismiss. Unlike WhatsApp's (manageSettings only), this one is worked by the address's named team too, so the caller's
/// ACCESS is computed here from the token — manageSettings means every mailbox, otherwise the live teams they belong to
/// (the same <c>User.TeamScope()</c> the record-access checks read) — and handed down as data. A row in a mailbox the
/// caller may not work is not listed, and acting on it answers 404 like a resolved one.
/// </summary>
[ApiController]
[Authorize]
[Route("email/unmatched")]
public class EmailUnmatchedController : ControllerBase
{
    private readonly EmailTriageExperience _triage;
    public EmailUnmatchedController(EmailTriageExperience triage) => _triage = triage;

    private EmailTriageScope Scope() =>
        User.HasPermission(OrganizationPermissions.ManageSettings)
            ? new EmailTriageScope(true, [])
            : new EmailTriageScope(false, User.TeamScope().TeamIds ?? []);

    [HttpGet]
    public async Task<IActionResult> List([FromQuery(Name = "mailbox_id")] Guid? mailboxId)
    {
        var scope = Scope();
        if (scope.IsEmpty) return StatusCode(403, new { error = "Your role cannot view this." });
        return Ok(await _triage.ListAsync(scope, mailboxId));
    }

    // GET /email/unmatched/summary — for the client to decide whether the menu item shows. Never 403: "you can work
    // nothing" is the answer, {can_work: false, pending_count: 0}.
    [HttpGet("summary")]
    public async Task<IActionResult> Summary() => Ok(await _triage.SummaryAsync(Scope()));

    [HttpPost("{id:guid}/link")]
    public async Task<IActionResult> Link(Guid id, [FromBody] EmailLinkUnmatchedInput input)
    {
        var scope = Scope();
        if (scope.IsEmpty) return StatusCode(403, new { error = "Your role cannot change this." });
        var (refusal, dto) = await _triage.LinkAsync(id, input.LeadId, User.UserId(), scope);
        return refusal switch
        {
            { NotFound: true } => NotFound(new { error = refusal.Reason }),
            not null => BadRequest(new { error = refusal.Reason }),
            _ => Ok(dto),
        };
    }

    [HttpPost("{id:guid}/create-lead")]
    public async Task<IActionResult> CreateLead(
        Guid id, [FromBody(EmptyBodyBehavior = EmptyBodyBehavior.Allow)] EmailCreateLeadInput? input = null)
    {
        var scope = Scope();
        if (scope.IsEmpty) return StatusCode(403, new { error = "Your role cannot change this." });
        var (refusal, leadId) = await _triage.CreateLeadAsync(id, User.UserId(), scope, input);
        return refusal switch
        {
            { NotFound: true } => NotFound(new { error = refusal.Reason }),
            not null => BadRequest(new { error = refusal.Reason }),
            _ => Ok(new { lead_id = leadId }),
        };
    }

    [HttpPost("{id:guid}/dismiss")]
    public async Task<IActionResult> Dismiss(Guid id)
    {
        var scope = Scope();
        if (scope.IsEmpty) return StatusCode(403, new { error = "Your role cannot change this." });
        var (refusal, dto) = await _triage.DismissAsync(id, User.UserId(), scope);
        return refusal switch
        {
            { NotFound: true } => NotFound(new { error = refusal.Reason }),
            not null => BadRequest(new { error = refusal.Reason }),
            _ => Ok(dto),
        };
    }
}

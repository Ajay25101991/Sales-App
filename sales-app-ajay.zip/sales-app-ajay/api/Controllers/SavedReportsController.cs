using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.CustomReports;
using SalesApi.ProcessLayer.CustomReports;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Custom reports, slice 3 (to-do/report-builder-design.md) — saved reports.
/// Same gate as <c>CustomReportsController</c> (reports.view: "who may RUN/OPEN
/// a report" is not a new policy question) plus one extra: creating, editing,
/// sharing or deleting a report is manager/admin only (design doc owner answer
/// 4), enforced in <c>SavedReportProcess</c> — not here — since it depends on
/// per-row ownership the controller does not have.
/// </summary>
[ApiController]
[Route("reports/custom/saved")]
[Authorize]
[RequirePermission(OrganizationPermissions.ViewReports)]
public class SavedReportsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly SavedReportsExperience _reports;

    public SavedReportsController(CallerContext caller, SavedReportsExperience reports)
    {
        _caller = caller;
        _reports = reports;
    }

    private RecordAccessContext? _access;
    private async Task<RecordAccessContext> AccessAsync() => _access ??= await _caller.ForAsync(User);
    private bool ShowValues => User.HasPermission(OrganizationPermissions.ViewLeadValues);

    // E18.2: what the VIEWER may do with money and contact data, passed down as data for a report over a non-lead source.
    private ReportViewer Viewer => new(
        User.HasPermission(OrganizationPermissions.ViewFinancials),
        User.HasPermission(OrganizationPermissions.ViewAccountFinancials),
        User.HasPermission(OrganizationPermissions.ViewContactDetails));

    private async Task<SavedReportProcess.Caller> CallerAsync() => new(
        User.UserId(), User.IsManager(), User.IsOrgAdmin(), await _caller.LiveTeamIdsAsync(User), User.Sensitive());

    private static IActionResult FromRefusal(SavedReportProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 403 }
        : new BadRequestObjectResult(new { error = refusal.Reason });

    // GET /reports/custom/saved — mine + shared with my team + org-wide.
    [HttpGet]
    public async Task<IActionResult> ListForMe() => Ok(await _reports.ListForMeAsync(await CallerAsync()));

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var (dto, refusal) = await _reports.GetAsync(await CallerAsync(), id);
        return refusal is not null ? FromRefusal(refusal) : Ok(dto);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] SavedReportInput input)
    {
        var (created, refusal) = await _reports.CreateAsync(await CallerAsync(), User.OrgId(), User.Role(), input);
        return refusal is not null ? FromRefusal(refusal) : StatusCode(201, created);
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] SavedReportInput input)
    {
        var (updated, refusal) = await _reports.UpdateAsync(await CallerAsync(), User.OrgId(), User.Role(), id, input);
        return refusal is not null ? FromRefusal(refusal) : Ok(updated);
    }

    // Archives rather than hard-deletes (design doc: "DELETE /{id} (archive)").
    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var refusal = await _reports.DeleteAsync(await CallerAsync(), id);
        return refusal is not null ? FromRefusal(refusal) : NoContent();
    }

    // POST /reports/custom/saved/{id}/run — always as the signed-in viewer,
    // never as whoever created or shared it (SavedReportProcess's own remarks).
    [HttpPost("{id:guid}/run")]
    public async Task<IActionResult> Run(Guid id)
    {
        var (dto, refusal) = await _reports.RunAsync(
            await CallerAsync(), await AccessAsync(), ShowValues, User.OrgId(), User.Role(), id, viewer: Viewer);
        return refusal is not null ? FromRefusal(refusal) : Ok(dto);
    }

    [HttpPost("{id:guid}/export")]
    [RequirePermission(OrganizationPermissions.CreateExports)]
    public async Task<IActionResult> Export(Guid id)
    {
        var (csv, refusal) = await _reports.ExportCsvAsync(
            await CallerAsync(), await AccessAsync(), ShowValues, User.OrgId(), User.Role(), id, viewer: Viewer);
        return refusal is not null ? FromRefusal(refusal) : Content(csv!, "text/csv; charset=utf-8");
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.ExperienceLayer.Proposals;
using SalesApi.Services;

namespace SalesApi.Controllers;

// Team-wide quotes view (per-lead proposal CRUD lives on LeadsController). Feeds
// the admin "Quotes overview": every quote across the org with lead + owner
// names so a manager can track pipeline value and win rate at a glance.
//
// MIGRATED to the layered API (step 8): this controller now only routes,
// builds the caller's RecordAccessContext (the same helper CollectionsController
// uses — RecordAccessContexts lives in the System layer and needs the
// ClaimsPrincipal + AppDbContext to resolve it, so this is the one place _db
// stays), and hands off. All the query, scoping and KPI logic that used to live
// here moved to ProposalProcess (SalesApi.ProcessApi) and, beneath it,
// ProposalStore (SalesApi.SystemApi), reached through ProposalsExperience.
[ApiController]
[Route("proposals")]
[Authorize]
[RequirePermission(OrganizationPermissions.ViewFinancials)]
public class ProposalsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly CallerContext _caller;
    private readonly ProposalsExperience _proposals;
    public ProposalsController(AppDbContext db, CallerContext caller, ProposalsExperience proposals)
    {
        _db = db;
        _caller = caller;
        _proposals = proposals;
    }

    // GET /proposals — the newest ListCap quotes this caller may see. Paged by
    // truncation, not by cursor: the KPIs that used to be derived from this
    // array now come from GET /proposals/summary, which computes over the whole
    // set, so the list no longer has to BE the whole set to be honest about it.
    // The client shows "newest 500 of N" from the summary's Total.
    //
    // One-table: `filters` and `sorts` (JSON, URL-encoded), exactly as GET /leads takes them; the cap applies
    // after both. See GET /proposals/columns for what may be used.
    [HttpGet]
    public async Task<IActionResult> All([FromQuery] string? filters = null, [FromQuery] string? sorts = null)
    {
        var ctx = await _caller.ForAsync(User);
        try
        {
            return Ok(await _proposals.ListAsync(ctx, default, filters, sorts));
        }
        catch (SalesApi.Services.TableQuery.TableQueryRefusedException e)
        {
            return BadRequest(new { error = e.Message, code = "invalid_query", field = e.Field });
        }
    }

    // GET /proposals/columns — the Quotes table's column catalogue (same access as GET /proposals).
    [HttpGet("columns")]
    public async Task<IActionResult> Columns() => Ok(await _proposals.ColumnsAsync(await _caller.ForAsync(User)));

    // GET /proposals/summary — the quotes-overview KPIs, over EVERY quote the
    // caller may see (audit H9). See ProposalProcess.SummaryAsync for why.
    [HttpGet("summary")]
    public async Task<IActionResult> Summary()
    {
        var ctx = await _caller.ForAsync(User);
        var summary = await _proposals.SummaryAsync(ctx);
        return Ok(summary);
    }
}

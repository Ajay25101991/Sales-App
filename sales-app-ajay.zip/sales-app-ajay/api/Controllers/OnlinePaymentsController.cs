using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.ExperienceLayer.OnlinePayments;
using SalesApi.ProcessLayer.OnlinePayments;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E17.5 online payment, staff side. Gated on the permission the invoice screens use (financials.view); the reconciliation list is money-only, so it
/// also needs account_financials.view, and the setup facts need settings.manage. Routing, permission and status codes only - the rules are
/// <see cref="OnlinePaymentProcess"/>.
/// </summary>
[ApiController]
[Authorize]
[RequirePermission(OrganizationPermissions.ViewFinancials)]
public class OnlinePaymentsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly OnlinePaymentExperience _payments;

    public OnlinePaymentsController(CallerContext caller, OnlinePaymentExperience payments)
    {
        _caller = caller;
        _payments = payments;
    }

    private IActionResult Fail(OnlinePaymentProcess.Outcome outcome, string? error)
    {
        var body = new { error };
        return outcome switch
        {
            OnlinePaymentProcess.Outcome.NotFound => NotFound(body),
            OnlinePaymentProcess.Outcome.Forbidden => StatusCode(403, body),
            OnlinePaymentProcess.Outcome.Unavailable => StatusCode(503, body),
            _ => BadRequest(body),
        };
    }

    /// <summary>POST /invoices/{id}/pay-link: <c>{ url, expires_at }</c> - the customer's "Pay now" address for an open invoice (a live one is reused).
    /// 404 unknown invoice; 403 not yours to manage; 400 not open money; 503 no gateway connected or no public address.</summary>
    [HttpPost("invoices/{id:guid}/pay-link")]
    public async Task<IActionResult> CreatePayLink(Guid id)
    {
        var result = await _payments.CreatePayLinkAsync(await _caller.ForAsync(User), id, User.UserId());
        return result.Outcome == OnlinePaymentProcess.Outcome.Ok ? Ok(result.Value) : Fail(result.Outcome, result.Error);
    }

    /// <summary>GET /online-payments?from=&amp;to=&amp;status=&amp;limit= (dates YYYY-MM-DD, inclusive, default the last 30 days): the gateway checkouts for
    /// matching against the gateway's payout report, newest first. Without <c>status</c>, abandoned (created) checkouts are left out.</summary>
    [HttpGet("online-payments")]
    [RequirePermission(OrganizationPermissions.ViewAccountFinancials)]
    public async Task<IActionResult> List([FromQuery(Name = "from")] DateOnly? fromDate, [FromQuery(Name = "to")] DateOnly? toDate, string? status, int? limit)
    {
        var result = await _payments.ListAsync(fromDate, toDate, status, limit);
        return result.Outcome == OnlinePaymentProcess.Outcome.Ok ? Ok(result.Value) : Fail(result.Outcome, result.Error);
    }

    /// <summary>GET /online-payments/setup: <c>{ connected, provider, webhook_url, publishable_key, pay_link_days }</c> - the address to register at the gateway.</summary>
    [HttpGet("online-payments/setup")]
    [RequirePermission(OrganizationPermissions.ManageSettings)]
    public async Task<IActionResult> Setup() => Ok(await _payments.SetupAsync());
}

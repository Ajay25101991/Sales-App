using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Screening;
using SalesApi.ProcessLayer.Screening;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E15.5 sanctions screening: an append-only record of each check of a company or a person at it, the reviewer's decisions, and evidence files (see
/// <see cref="ScreeningProcess"/>). Routes, checks the permission, and picks a status code - nothing else. The whole controller sits behind kyc.access; the
/// account's own view / manage rules are judged by the Process class. Changing the policy additionally needs settings.manage.
/// </summary>
[ApiController]
[Route("screenings")]
[Authorize]
[RequirePermission(OrganizationPermissions.KycAccess)]
[RequireSensitiveAccess(SensitiveCategories.ContactDetails)]
[StorageUnavailableFilter]
public class ScreeningsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly ScreeningExperience _screening;

    public ScreeningsController(CallerContext caller, ScreeningExperience screening)
    {
        _caller = caller;
        _screening = screening;
    }

    private Task<RecordAccessContext> AccessAsync() => _caller.ForAsync(User);

    // 404 / 403 / 400, like DocumentRegisterController (this is the account's data).
    private static IActionResult FromRefusal(ScreeningProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : refusal.Forbidden ? new ObjectResult(new { error = refusal.Reason }) { StatusCode = 403 }
        : new BadRequestObjectResult(refusal.Code is null
            ? new { error = refusal.Reason }
            : new { error = refusal.Reason, code = refusal.Code, field = refusal.Field });

    // GET /screenings?account_id= | contact_id= - an account's screenings (the company's and its contacts'), or one person's, newest first. Each carries its
    // status, the decision in force, the decision history and its evidence files.
    [HttpGet]
    public async Task<IActionResult> List([FromQuery(Name = "account_id")] Guid? accountId, [FromQuery(Name = "contact_id")] Guid? contactId)
    {
        var outcome = await _screening.ListAsync(await AccessAsync(), accountId, contactId, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Screenings);
    }

    // GET /screenings/subjects?account_id= - who the org's scope screens on the account, where each stands, and whether all are clear.
    [HttpGet("subjects")]
    public async Task<IActionResult> Subjects([FromQuery(Name = "account_id")] Guid? accountId)
    {
        var outcome = await _screening.SubjectsAsync(await AccessAsync(), accountId, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Subjects);
    }

    // GET /screenings/queue - the review queue: each subject's newest screening that is an open possible / true match or an escalation, oldest first, on
    // the accounts the caller may view.
    [HttpGet("queue")]
    public async Task<IActionResult> Queue()
    {
        var outcome = await _screening.QueueAsync(await AccessAsync(), HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Screenings);
    }

    // POST /screenings { account_id | contact_id, provider?, screened_at?, result, matches?, provider_reference?, notes? } - 201 with the screening.
    [HttpPost]
    public async Task<IActionResult> Record([FromBody] ScreeningRecordInput input)
    {
        var outcome = await _screening.RecordAsync(await AccessAsync(), User.UserId(), input, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Screening);
    }

    // POST /screenings/{id}/decision { decision: clear | true_match | escalate, reason } - 201 with the screening. A new decision; earlier ones stay as history.
    [HttpPost("{id:guid}/decision")]
    public async Task<IActionResult> Decide(Guid id, [FromBody] ScreeningDecisionInput input)
    {
        var outcome = await _screening.DecideAsync(await AccessAsync(), User.UserId(), id, input, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Screening);
    }

    // POST /screenings/{id}/evidence (multipart "file" - PDF, JPG or PNG) - 201 with the screening. Stored as an account attachment tagged screening:{id}.
    [HttpPost("{id:guid}/evidence")]
    [RequestSizeLimit(UploadLimits.StaffRequestBytes)]
    public async Task<IActionResult> AddEvidence(Guid id, IFormFile? file)
    {
        var perms = new AttachmentPermissions(
            User.HasPermission(OrganizationPermissions.ViewFinancials), User.HasPermission(OrganizationPermissions.ViewContactDetails),
            User.HasPermission(OrganizationPermissions.KycAccess));
        await using var stream = file?.OpenReadStream();
        var outcome = await _screening.AddEvidenceAsync(
            await AccessAsync(), perms, User.UserId(), User.OrgId(), id,
            file?.FileName, file?.ContentType, file?.Length ?? 0, stream, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Screening);
    }

    // GET /screenings/settings - who is screened and how often.
    [HttpGet("settings")]
    public async Task<IActionResult> GetSettings() => Ok(await _screening.GetSettingsAsync(HttpContext.RequestAborted));

    // PUT /screenings/settings { include_account?, contact_scope?, contact_field_key?, contact_field_values?, rescreen_days?, reminder_lead_days? }
    [HttpPut("settings")]
    public async Task<IActionResult> SaveSettings([FromBody] ScreeningSettingsInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot change screening settings." });
        var outcome = await _screening.SaveSettingsAsync(input, HttpContext.RequestAborted);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Settings);
    }
}

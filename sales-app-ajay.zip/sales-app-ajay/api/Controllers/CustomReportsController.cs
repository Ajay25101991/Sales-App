using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Custom reports, slice 1 (to-do/report-builder-design.md): the breakdown
/// engine + CSV export + the field catalogue that drives the group-by/filter
/// pickers. Saved/shared reports are slice 3 — not here.
///
/// NEW controller, NEW layers behind it (CustomReportStore -> CustomReportProcess
/// -> CustomReportExperience) — a separate agent is adding
/// GET /reports/estimated-vs-closed to the EXISTING ReportsController/
/// ReportsProcess in the same window (dev brief roster); keeping this apart
/// avoids colliding with that work.
///
/// Gated on the same `reports.view` permission every other report on
/// ReportsController requires — "who may RUN" a custom report is not a new
/// policy question, so it does not get a new permission. Who may SAVE/SHARE
/// one is a slice-3 question.
/// </summary>
[ApiController]
[Route("reports/custom")]
[Authorize]
[RequirePermission(OrganizationPermissions.ViewReports)]
public class CustomReportsController : ControllerBase
{
    // The one remaining _db use (via CallerContext) to build the caller's
    // RecordAccessContext — same documented exception ReportsController,
    // AccountsController, AttachmentsController and SettingsController keep.
    private readonly CallerContext _caller;
    private readonly SalesApi.ExperienceLayer.CustomReports.CustomReportExperience _reports;

    public CustomReportsController(
        CallerContext caller, SalesApi.ExperienceLayer.CustomReports.CustomReportExperience reports)
    {
        _caller = caller;
        _reports = reports;
    }

    private RecordAccessContext? _access;
    private async Task<RecordAccessContext> AccessAsync() => _access ??= await _caller.ForAsync(User);

    /// <summary>Same rule as ReportsController.ShowValues — read once, passed
    /// down as data so the computation never re-asks the principal.</summary>
    private bool ShowValues => User.HasPermission(OrganizationPermissions.ViewLeadValues);

    // E18.2: what this caller may do with money and contact data, read once here and passed DOWN as data (financials.view opens the
    // invoice / payment / AMC sources, account_financials.view their money columns, contact_details.view a contact's email and phone).
    private ReportViewer Viewer => new(
        User.HasPermission(OrganizationPermissions.ViewFinancials),
        User.HasPermission(OrganizationPermissions.ViewAccountFinancials),
        User.HasPermission(OrganizationPermissions.ViewContactDetails));

    private IActionResult Refused(SalesApi.ProcessLayer.CustomReports.CustomReportProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason }) : BadRequest(new { error = refusal.Reason });

    // POST /reports/custom/run
    [HttpPost("run")]
    public async Task<IActionResult> Run([FromBody] CustomReportRequestDto request, CancellationToken ct)
    {
        var (refusal, dto) = await _reports.RunAsync(
            await AccessAsync(), ShowValues, User.OrgId(), User.Role(), request, ct, Viewer);
        return refusal is not null ? Refused(refusal) : Ok(dto);
    }

    // POST /reports/custom/export — same body as /run, as CSV. Gated on
    // exports.create too, matching every other report export on
    // ReportsController (GET /reports/leaderboard/export,
    // /reports/rep/{id}/export, etc.) — a second, narrower permission on top
    // of reports.view, not instead of it.
    [HttpPost("export")]
    [RequirePermission(OrganizationPermissions.CreateExports)]
    public async Task<IActionResult> Export([FromBody] CustomReportRequestDto request, CancellationToken ct)
    {
        var (refusal, csv) = await _reports.ExportCsvAsync(
            await AccessAsync(), ShowValues, User.OrgId(), User.Role(), request, ct, Viewer);
        return refusal is not null ? Refused(refusal) : Content(csv!, "text/csv; charset=utf-8");
    }

    // GET /reports/custom/sources — E18.2: every source this caller may report over (leads first, then accounts, contacts, invoices,
    // payments, AMC renewal terms), each with its fields: key, label, type, filterable / sortable / groupable / summable, options.
    // `metrics` says what a breakdown over it shows: "lead_metrics" (the five lead groups) or "count_sum" (a count plus the sum of a
    // chosen field, `sum_field` on the request). A source the caller may not use (invoices without financials.view) is absent.
    [HttpGet("sources")]
    public async Task<IActionResult> Sources(CancellationToken ct) =>
        Ok(await _reports.SourcesAsync(User.OrgId(), User.Role(), Viewer, ct, User.Sensitive()));

    // GET /reports/custom/sources/{key}/table-columns — a non-lead source's results-table columns as a /columns catalogue (the lead
    // source's own is GET /reports/custom/table-columns). 404 for an unknown source or one this caller may not use.
    [HttpGet("sources/{key}/table-columns")]
    public async Task<IActionResult> SourceTableColumns(string key, CancellationToken ct)
    {
        var columns = await _reports.SourceTableColumnsAsync(key, User.OrgId(), User.Role(), Viewer, ct, User.Sensitive());
        return columns is null ? NotFound(new { error = $"No report source '{key}'." }) : Ok(columns);
    }

    // GET /reports/custom/fields — the group-by and filter options available
    // to THIS caller: built-ins plus every non-archived dropdown/picklist/
    // multi-select lead custom field they may see.
    [HttpGet("fields")]
    public async Task<IActionResult> Fields(CancellationToken ct) =>
        Ok(await _reports.FieldsAsync(User.OrgId(), User.Role(), ct, User.Sensitive()));

    // GET /reports/custom/table-columns — the results table's columns as a /columns catalogue
    // ({ columns: [{ key, label, type, sortable, filterable, ops, options, ... }], max_sorts }), so the table's
    // headings can sort and filter the report. `key` is the field name a `column_filters` / `sorts` entry uses.
    // A column this caller may not see (the money columns without lead_values.view) is absent.
    [HttpGet("table-columns")]
    public async Task<IActionResult> TableColumns(CancellationToken ct) =>
        Ok(await _reports.TableColumnsAsync(await AccessAsync(), ShowValues, User.OrgId(), User.Role(), ct));
}

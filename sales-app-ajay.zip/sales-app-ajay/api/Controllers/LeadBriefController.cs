using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.AiPlatform;
using SalesApi.ProcessLayer.AiPlatform;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E5.1 — the deal/account brief panel above the lead detail screen
/// (to-do/epics-ai-native-crm.md E5.1 row). <c>GET</c> serves the cached
/// brief (or generates one on a context-hash miss); <c>POST .../refresh</c>
/// always regenerates. Route is under <c>/leads</c> deliberately — same
/// resource family <c>LeadsController</c>'s own timeline/history endpoints
/// live under, since a brief is a read ABOUT one lead, not an independent
/// resource.
/// </summary>
[ApiController]
[Authorize]
[Route("leads/{id:guid}/brief")]
public class LeadBriefController : ControllerBase
{
    // The one remaining _db use every lead-scoped controller keeps — see
    // LeadsController's own comment on CallerContext for why.
    private readonly CallerContext _caller;
    private readonly LeadBriefExperience _brief;

    public LeadBriefController(CallerContext caller, LeadBriefExperience brief)
    {
        _caller = caller;
        _brief = brief;
    }

    private Task<RecordAccessContext> AccessAsync() =>
        _caller.ForAsync(User);

    private LeadView LeadViewOf() => new(
        User.HasPermission(OrganizationPermissions.ViewContactDetails),
        User.HasPermission(OrganizationPermissions.ViewLeadValues),
        User.Role(), User.Sensitive());

    private IActionResult Refused(LeadBriefProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason })
        : refusal.Forbidden ? StatusCode(403, new { error = refusal.Reason })
        : BadRequest(new { error = refusal.Reason });

    [HttpGet]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct)
    {
        var (dto, refusal) = await _brief.GetAsync(
            await AccessAsync(), LeadViewOf(), User.HasPermission(OrganizationPermissions.ViewFinancials),
            User.OrgId()!.Value, User.UserId(), id, ct);
        return refusal is not null ? Refused(refusal) : Ok(dto);
    }

    [HttpPost("refresh")]
    public async Task<IActionResult> Refresh(Guid id, CancellationToken ct)
    {
        var (dto, refusal) = await _brief.RefreshAsync(
            await AccessAsync(), LeadViewOf(), User.HasPermission(OrganizationPermissions.ViewFinancials),
            User.OrgId()!.Value, User.UserId(), id, ct);
        return refusal is not null ? Refused(refusal) : Ok(dto);
    }
}

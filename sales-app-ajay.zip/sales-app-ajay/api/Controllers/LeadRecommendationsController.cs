using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Recommendations;
using SalesApi.ProcessLayer.Recommendations;
using SalesApi.Services;

namespace SalesApi.Controllers;

// Owner 2026-11-11 - a lead's "Recommended next" list for its current stage, nested under the lead like stakeholders / qualification.
// Read = may view the lead; done / dismiss / undo = may edit the lead (the process applies RecordAccess.CanView / CanManage).
[ApiController]
[Route("leads/{leadId:guid}/recommendations")]
[Authorize]
public class LeadRecommendationsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly LeadRecommendationsExperience _recommendations;

    public LeadRecommendationsController(CallerContext caller, LeadRecommendationsExperience recommendations)
    {
        _caller = caller;
        _recommendations = recommendations;
    }

    private Task<RecordAccessContext> AccessAsync() => _caller.ForAsync(User);

    private IActionResult Respond(LeadRecommendationProcess.Outcome outcome) =>
        outcome.Refusal is not { } r ? Ok(outcome.Dto)
        : r.NotFound ? NotFound(new { error = r.Reason })
        : r.Forbidden ? StatusCode(403, new { error = r.Reason })
        : BadRequest(new { error = r.Reason });

    [HttpGet]
    public async Task<IActionResult> Get(Guid leadId) =>
        Respond(await _recommendations.GetAsync(await AccessAsync(), leadId));

    [HttpPost("{recommendationId}/done")]
    public Task<IActionResult> Done(Guid leadId, string recommendationId) => ChangeAsync(leadId, recommendationId, LeadRecommendationProcess.Change.Done);

    [HttpPost("{recommendationId}/dismiss")]
    public Task<IActionResult> Dismiss(Guid leadId, string recommendationId) => ChangeAsync(leadId, recommendationId, LeadRecommendationProcess.Change.Dismiss);

    [HttpPost("{recommendationId}/undo")]
    public Task<IActionResult> Undo(Guid leadId, string recommendationId) => ChangeAsync(leadId, recommendationId, LeadRecommendationProcess.Change.Undo);

    private async Task<IActionResult> ChangeAsync(Guid leadId, string recommendationId, LeadRecommendationProcess.Change change) =>
        Respond(await _recommendations.ChangeAsync(await AccessAsync(), User.UserId(), leadId, recommendationId, change));
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Sandbox;
using SalesApi.ExperienceLayer.Studio;
using SalesApi.ProcessLayer.Studio;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E7.3 sandbox org (design doc to-do/e7-config-platform-design.md §4, §10
/// owner answer 3): "customers can export/import too, within their own org
/// only... on a customer-visible Admin screen as well as in Studio." Every
/// endpoint here operates on the CALLER'S OWN org (<c>User.OrgId()</c>) and
/// its own sandbox — never a second org id in the route, unlike
/// <c>AdminController</c>'s suntech-admin-only clone-from-org. Gated on
/// <see cref="OrganizationPermissions.ManageSettings"/>, the same gate
/// <c>PackagesController</c> already uses for ordinary import/export — a
/// sandbox is config, and this is the config-admin permission.
/// </summary>
[ApiController]
[Route("admin/sandbox")]
[Authorize]
public class SandboxController : ControllerBase
{
    private readonly SandboxExperience _sandbox;
    private readonly StudioExperience _studio;
    public SandboxController(SandboxExperience sandbox, StudioExperience studio)
    {
        _sandbox = sandbox;
        _studio = studio;
    }

    private IActionResult? RequireManageSettings() =>
        User.HasPermission(OrganizationPermissions.ManageSettings)
            ? null
            : StatusCode(403, new { error = "Your role cannot manage this organization's sandbox." });

    private IActionResult Refused(SandboxRefusalDto refusal) =>
        refusal.NotFound ? NotFound(refusal) : BadRequest(refusal);

    /// <summary>GET /admin/sandbox — E7.4 (§11 build-notes gap): "no GET
    /// /admin/sandbox status endpoint, so the screen can't show created /
    /// last-refreshed dates after a reload." Never a refusal — no sandbox is
    /// a valid status, not an error.</summary>
    [HttpGet]
    public async Task<IActionResult> Status()
    {
        if (RequireManageSettings() is { } err) return err;
        return Ok(await _sandbox.StatusAsync(User.OrgId()!.Value));
    }

    /// <summary>POST /admin/sandbox — creates this org's sandbox by cloning
    /// its CONFIGURATION (never records/users/secrets) through the package
    /// pipeline. Refused if one already exists (§4.3) — use refresh instead.</summary>
    // E7.6 — gated on the org's plan.
    [HttpPost]
    [RequirePlanFeature(PlanCatalogue.Features.Studio)]
    public async Task<IActionResult> Create()
    {
        if (RequireManageSettings() is { } err) return err;
        var (result, refusal) = await _sandbox.CreateAsync(User.OrgId()!.Value, User.UserId());
        return refusal is not null ? Refused(refusal.ToDto()) : StatusCode(201, result);
    }

    /// <summary>DELETE /admin/sandbox — permanently removes this org's
    /// sandbox (config only; nothing else was ever in it). Production's own
    /// promote history is unaffected and kept forever (§10 owner answer 6).</summary>
    [HttpDelete]
    public async Task<IActionResult> Delete()
    {
        if (RequireManageSettings() is { } err) return err;
        var (deleted, refusal) = await _sandbox.DeleteAsync(User.OrgId()!.Value);
        return refusal is not null ? Refused(refusal.ToDto()) : Ok(new { deleted });
    }

    /// <summary>GET /admin/sandbox/refresh/preview — §4.5: what has changed
    /// in production since the sandbox was created/last refreshed, through
    /// the same diff shape any import preview uses.</summary>
    [HttpGet("refresh/preview")]
    public async Task<IActionResult> RefreshPreview()
    {
        if (RequireManageSettings() is { } err) return err;
        var (preview, refusal) = await _sandbox.RefreshPreviewAsync(User.OrgId()!.Value);
        return refusal is not null ? Refused(refusal.ToDto()) : Ok(preview);
    }

    /// <summary>POST /admin/sandbox/refresh/apply — pulls a fresh export of
    /// production into the sandbox with the caller's conflict resolutions
    /// (§4.5). The package body itself is never taken from the client —
    /// only the resolutions are, so a stale/tampered manifest can't be
    /// applied.</summary>
    [HttpPost("refresh/apply")]
    public async Task<IActionResult> RefreshApply([FromBody] List<PackageItemResolutionDto>? resolutions)
    {
        if (RequireManageSettings() is { } err) return err;
        var (result, refusal) = await _sandbox.RefreshApplyAsync(User.OrgId()!.Value, User.UserId(), resolutions ?? new());
        return refusal is not null ? Refused(refusal.ToDto()) : Ok(result);
    }

    /// <summary>GET /admin/sandbox/diff — §4.4: the sandbox's own items
    /// classified against a fresh export of CURRENT production (not the
    /// creation-time snapshot), plus anything removed in the sandbox since —
    /// the same diff shape an ordinary import preview uses.</summary>
    [HttpGet("diff")]
    public async Task<IActionResult> Diff()
    {
        if (RequireManageSettings() is { } err) return err;
        var (diff, refusal) = await _sandbox.DiffAsync(User.OrgId()!.Value);
        return refusal is not null ? Refused(refusal.ToDto()) : Ok(diff);
    }

    /// <summary>POST /admin/sandbox/promote — applies an EXPLICIT selection
    /// of sandbox items to production (§5.4/§10 owner answer 4: promote is
    /// per change request — this endpoint takes that selection directly;
    /// slice 16's ChangeRequest wraps it with a linked
    /// PackageApplyRecord/approval state, not built here). Removals need an
    /// explicit acknowledgement per item or the whole call is refused.</summary>
    [HttpPost("promote")]
    public async Task<IActionResult> Promote([FromBody] SandboxPromoteRequestDto input)
    {
        if (RequireManageSettings() is { } err) return err;
        var (result, refusal) = await _sandbox.PromoteAsync(User.OrgId()!.Value, User.UserId(), input);
        return refusal is not null ? Refused(refusal.ToDto()) : Ok(result);
    }

    // --- E7.4 (design doc §5.1 req 4, §8 slice 13): sandbox switching for --
    // --- customers — the SAME scoped-session mechanism §5.1 built for -----
    // --- implementation users, reused here for "my own org's admin, into --
    // --- my own org's sandbox".---------------------------------------------

    private IActionResult RefusedStudio(StudioProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(refusal.ToDto()) : BadRequest(refusal.ToDto());

    /// <summary>POST /admin/sandbox/switch — issues a scoped session for
    /// THIS org's own sandbox. Refused unless the caller holds ManageSettings
    /// on their own (home) org and that org actually has a sandbox — both
    /// re-checked from the database here, and again on every later request
    /// by OrganizationPermissionMiddleware.</summary>
    [HttpPost("switch")]
    public async Task<IActionResult> SwitchToSandbox()
    {
        var (result, refusal) = await _studio.SwitchToOwnSandboxAsync(User.UserId());
        return refusal is not null ? RefusedStudio(refusal) : Ok(result);
    }

    /// <summary>POST /admin/sandbox/switch/home — returns to an ordinary
    /// session for the caller's own (production) org.</summary>
    [HttpPost("switch/home")]
    public async Task<IActionResult> SwitchToProduction()
    {
        var (result, refusal) = await _studio.SwitchHomeAsync(User.UserId());
        return refusal is not null ? RefusedStudio(refusal) : Ok(result);
    }
}

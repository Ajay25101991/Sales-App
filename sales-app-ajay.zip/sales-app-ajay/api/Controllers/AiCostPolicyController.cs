using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.AiPlatform;
using SalesApi.Services;

namespace SalesApi.Controllers;

// The E4.3 cost policy (design doc to-do/e4-ai-platform-design.md §13, §15
// slice 5). Admin-only, same permission as the AI provider settings and
// execution-log endpoints — OrganizationPermissions.ManageSettings.
[ApiController]
[Authorize]
public class AiCostPolicyController : ControllerBase
{
    private readonly AiCostPolicyExperience _policy;
    public AiCostPolicyController(AiCostPolicyExperience policy) => _policy = policy;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);

    [HttpGet("admin/ai-cost-policy")]
    public async Task<IActionResult> Get()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot view this setting." });
        return Ok(await _policy.GetAsync());
    }

    [HttpPut("admin/ai-cost-policy")]
    public async Task<IActionResult> Save([FromBody] AiCostPolicyInput input)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (dto, refusal) = await _policy.SaveAsync(input, User.UserId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }
}

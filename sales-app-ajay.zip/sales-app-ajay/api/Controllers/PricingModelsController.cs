using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.PricingModels;
using SalesApi.ProcessLayer.PricingModels;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E10.3 — the pricing model of a service (a catalogue item of kind "service"): inputs, results written
/// as safe formulas, a draft, and immutable published versions. Contract: to-do/pricing-models-api.md.
///
/// Gated like the catalogue itself: authoring (draft, validate, preview, publish, restore, version list)
/// needs <c>settings.manage</c>. Reading a PUBLISHED version and evaluating it needs <c>proposals.generate_priced</c>
/// ("Generate priced proposals", a role permission), or <c>settings.manage</c> for the authors,
/// because the proposal generator (a rep's action) calls them and the formulas ARE the price list.
/// This controller routes, checks permission and picks a status code; it touches no _db.
/// </summary>
[ApiController]
[Route("catalog-items/{catalogItemId:guid}/pricing-model")]
[Authorize]
public class PricingModelsController : ControllerBase
{
    private readonly PricingModelsExperience _models;
    private readonly CallerContext _caller;
    public PricingModelsController(PricingModelsExperience models, CallerContext caller)
    {
        _models = models;
        _caller = caller;
    }

    /// <summary>The caller's record-access scope, resolved only when a deal is actually named (it costs queries).</summary>
    private async Task<RecordAccessContext?> AccessForAsync(Guid? dealId) =>
        dealId is null ? null : await _caller.ForAsync(User);

    // E12.2: a pricing model's costs and fee formulas are company financials. Reading the editor needs settings.manage AND
    // a raw read (full / view only) of that category; changing a model needs full. A masked or hidden level cannot open the
    // editor, and the generator's published-version reads below come back WITHOUT the formulas.
    private string FinancialsLevel => User.Sensitive().RoleLevel(SensitiveCategories.CompanyFinancials);
    private bool CanAuthor() => User.HasPermission(OrganizationPermissions.ManageSettings) && SensitiveLevels.CanReadRaw(FinancialsLevel);
    private bool CanAuthorWrite() => User.HasPermission(OrganizationPermissions.ManageSettings) && SensitiveLevels.CanWrite(FinancialsLevel);
    private bool CanUse() => User.HasPermission(OrganizationPermissions.GeneratePricedProposals);

    /// <summary>The refusal for an editor WRITE: 400 sensitive_read_only for someone who may read the model but not change it, else the usual 403.</summary>
    private IActionResult NoAuthoringWrite() =>
        CanAuthor()
            ? BadRequest(new
            {
                error = "You can view Company financials but not change it.",
                code = SensitiveWriteGuard.Code, fields = new[] { "pricing_model" },
            })
            : NoAuthoring();

    /// <summary>A published version for the generator: the formulas are withheld unless the caller reads Company financials raw.</summary>
    private IActionResult RespondVersion(PricingModelProcess.Result<PricingModelVersionDto> r)
    {
        if (r.Value is { } v && !SensitiveLevels.CanReadRaw(FinancialsLevel))
        {
            var withheld = JsonSerializer.SerializeToElement((object?)null);
            r = r with
            {
                Value = v with { Content = v.Content with { Results = v.Content.Results.Select(x => x with { Expr = withheld }).ToList() } },
            };
        }
        return Respond(r);
    }

    private ObjectResult NoAuthoring() => StatusCode(403, new { error = "Your role cannot edit pricing models." });
    private ObjectResult NoUse() => StatusCode(403, new { error = "Your role cannot use pricing models." });

    /// <summary>Maps a Process result onto a status. 400 carries the model's issues so the editor can show them in place.</summary>
    private IActionResult Respond<T>(PricingModelProcess.Result<T> r, int okStatus = 200) => r.Outcome switch
    {
        PricingModelProcess.Outcome.NotFound => NotFound(new { error = r.Error }),
        PricingModelProcess.Outcome.Invalid => BadRequest(new { error = r.Error, issues = r.Issues }),
        PricingModelProcess.Outcome.Conflict => Conflict(new { error = r.Error }),
        _ => StatusCode(okStatus, r.Value),
    };

    /// <summary>
    /// The result keys (with labels) a payment-term milestone can take its share of: every active service's live pricing model. For the
    /// payment-terms editor's basis picker, so it needs the permission that edits payment terms. Keys and labels only - never a formula.
    /// An absolute route, so it sits beside the payment-workflow settings although it is served from here.
    /// </summary>
    [HttpGet("/settings/payment-workflow/basis-keys")]
    public async Task<IActionResult> BasisKeys(CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePostWin)) return StatusCode(403, new { error = "Your role cannot change the after-the-win settings." });
        return Ok(await _models.ResultKeysAsync(ct));
    }

    /// <summary>The draft plus a pointer at the published version. A service with no model yet returns an empty draft.</summary>
    [HttpGet]
    public async Task<IActionResult> Get(Guid catalogItemId, CancellationToken ct)
    {
        if (!CanAuthor()) return NoAuthoring();
        return Respond(await _models.GetAsync(catalogItemId, ct));
    }

    /// <summary>Saves the draft. Formula problems do not refuse the save; they come back in <c>validation</c>.</summary>
    [HttpPut]
    public async Task<IActionResult> SaveDraft(Guid catalogItemId, [FromBody] PricingModelDraftInput input, CancellationToken ct)
    {
        if (!CanAuthorWrite()) return NoAuthoringWrite();
        return Respond(await _models.SaveDraftAsync(catalogItemId, input, User.UserId(), ct));
    }

    /// <summary>Checks the body, or the stored draft when there is none. <c>?for_publish=true</c> adds the publish-only rules.</summary>
    [HttpPost("validate")]
    public async Task<IActionResult> Validate(
        Guid catalogItemId, [FromBody] PricingModelDraftInput? input, CancellationToken ct, [FromQuery(Name = "for_publish")] bool forPublish = false)
    {
        if (!CanAuthor()) return NoAuthoring();
        return Respond(await _models.ValidateAsync(catalogItemId, input, forPublish, ct));
    }

    /// <summary>Evaluates the body's content, else <c>version</c>, else the stored draft, with the given inputs.</summary>
    [HttpPost("preview")]
    public async Task<IActionResult> Preview(Guid catalogItemId, [FromBody] PricingPreviewInput input, CancellationToken ct)
    {
        if (!CanAuthor()) return NoAuthoring();
        return Respond(await _models.PreviewAsync(catalogItemId, input, await AccessForAsync(input.DealId), ct));
    }

    /// <summary>
    /// Everything a result's expression may pick: this model's inputs, results defined earlier than
    /// <c>?before=&lt;result key&gt;</c> (all when omitted), and the deal's and account's number/money fields.
    /// </summary>
    [HttpGet("fields")]
    public async Task<IActionResult> Fields(Guid catalogItemId, CancellationToken ct, [FromQuery] string? before = null)
    {
        // Authors see the draft's names; readers who may run a model ("Generate priced proposals") see the published ones.
        if (CanAuthor()) return Respond(await _models.FieldsAsync(catalogItemId, before, false, ct));
        if (!CanUse()) return NoAuthoring();
        return Respond(await _models.FieldsAsync(catalogItemId, before, true, ct));
    }

    /// <summary>The newest published version (inputs, results with their labels, the marked deal value / Year 1 / Year 2): what the generator prices against.</summary>
    [HttpGet("versions/latest")]
    public async Task<IActionResult> GetLatestVersion(Guid catalogItemId, CancellationToken ct)
    {
        if (!CanAuthor() && !CanUse()) return NoUse();
        return RespondVersion(await _models.GetLatestVersionAsync(catalogItemId, ct));
    }

    [HttpPost("publish")]
    public async Task<IActionResult> Publish(Guid catalogItemId, CancellationToken ct)
    {
        if (!CanAuthorWrite()) return NoAuthoringWrite();
        return Respond(await _models.PublishAsync(catalogItemId, User.UserId(), ct), okStatus: 201);
    }

    [HttpGet("versions")]
    public async Task<IActionResult> ListVersions(Guid catalogItemId, CancellationToken ct)
    {
        if (!CanAuthor()) return NoAuthoring();
        return Respond(await _models.ListVersionsAsync(catalogItemId, ct));
    }

    [HttpGet("versions/{version:int}")]
    public async Task<IActionResult> GetVersion(Guid catalogItemId, int version, CancellationToken ct)
    {
        if (!CanAuthor() && !CanUse()) return NoUse();
        return RespondVersion(await _models.GetVersionAsync(catalogItemId, version, ct));
    }

    /// <summary>Copies a published version into the draft. 409 when that would discard unpublished draft work, unless <c>replace_draft</c> is true.</summary>
    [HttpPost("versions/{version:int}/restore")]
    public async Task<IActionResult> RestoreVersion(
        Guid catalogItemId, int version, [FromBody] PricingRestoreInput? input, CancellationToken ct)
    {
        if (!CanAuthorWrite()) return NoAuthoringWrite();
        return Respond(await _models.RestoreVersionAsync(catalogItemId, version, input?.ReplaceDraft ?? false, User.UserId(), ct));
    }

    /// <summary>Runs one published version for the proposal generator. The numbers come only from that frozen version.</summary>
    [HttpPost("versions/{version:int}/evaluate")]
    public async Task<IActionResult> Evaluate(
        Guid catalogItemId, int version, [FromBody] PricingEvaluateInput? input, CancellationToken ct)
    {
        if (!CanAuthor() && !CanUse()) return NoUse();
        input ??= new PricingEvaluateInput(null);
        return Respond(await _models.EvaluateVersionAsync(catalogItemId, version, input, await AccessForAsync(input.DealId), ct));
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Packages;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E7.1 package export/import — design doc to-do/e7-config-platform-design.md
/// §2, §10 owner answer 3: customers can export/import within their OWN org
/// (their production ↔ their own sandbox, or a backup), gated on
/// <see cref="OrganizationPermissions.ManageSettings"/> exactly like every
/// other admin-config endpoint (CustomFieldsController's own gate) — NOT
/// Studio-only, and never cross-org (Studio's cross-org access is a later
/// slice, its own store, its own role).
///
/// Flat items only this slice (custom fields, picklists, safe OrgSettings
/// keys). Versioned items, sandbox, templates and Studio are later slices.
/// </summary>
[ApiController]
[Route("admin/packages")]
[Authorize]
public class PackagesController : ControllerBase
{
    private readonly PackagesExperience _packages;
    public PackagesController(PackagesExperience packages) => _packages = packages;

    [HttpPost("export")]
    public async Task<IActionResult> Export([FromBody] PackageExportRequestDto input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot export configuration packages." });

        var result = await _packages.ExportAsync(User.OrgId(), input.Name, input.Items ?? new());
        return Ok(result);
    }

    [HttpPost("import/preview")]
    public async Task<IActionResult> Preview([FromBody] PackageImportPreviewRequestDto input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot import configuration packages." });

        var (preview, refusal) = await _packages.PreviewAsync(input.Package);
        if (refusal is not null) return BadRequest(refusal.ToDto());
        return Ok(preview);
    }

    [HttpPost("import/apply")]
    public async Task<IActionResult> Apply([FromBody] PackageApplyRequestDto input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot import configuration packages." });

        var (result, refusal) = await _packages.ApplyAsync(User.OrgId(), User.UserId(), input);
        if (refusal is not null) return BadRequest(refusal.ToDto());
        return Ok(result);
    }

    /// <summary>§2.6: "who, when, counts, rolled back?" — every apply and
    /// rollback for this org, newest first.</summary>
    [HttpGet("applies")]
    public async Task<IActionResult> Applies()
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot view configuration package history." });

        return Ok(await _packages.ApplyHistoryAsync());
    }

    /// <summary>§2.5/§2.6/§10 owner answer 6: restores every item a prior
    /// apply created or changed back to what it was immediately before —
    /// forever, never a retention-limited window. Refused if a later apply
    /// already touched one of the same items, unless <c>force</c> is set.</summary>
    [HttpPost("applies/{id:guid}/rollback")]
    public async Task<IActionResult> Rollback(Guid id, [FromBody] PackageRollbackRequestDto? input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot roll back configuration packages." });

        var (result, refusal) = await _packages.RollbackAsync(User.OrgId(), User.UserId(), id, input?.Force ?? false);
        if (refusal is not null) return BadRequest(refusal.ToDto());
        return Ok(result);
    }
}

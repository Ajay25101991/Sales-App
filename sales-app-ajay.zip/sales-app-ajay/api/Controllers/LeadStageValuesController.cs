using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.StageValues;
using SalesApi.ProcessLayer.StageValues;
using SalesApi.Services;

namespace SalesApi.Controllers;

// Owner 2026-11-12 - a deal's Proposal / Negotiation / Closed value sets (to-do/deal-values-per-stage-design.md), nested under the lead like recommendations.
// Read = may view the lead (numbers masked without deal-value access); correct = may edit the lead (the process applies RecordAccess.CanView / CanManage and the
// sensitive write rule). The sets themselves are captured by the stage move, not here.
[ApiController]
[Route("leads/{leadId:guid}/stage-values")]
[Authorize]
public class LeadStageValuesController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly LeadStageValuesExperience _values;

    public LeadStageValuesController(CallerContext caller, LeadStageValuesExperience values)
    {
        _caller = caller;
        _values = values;
    }

    private Task<RecordAccessContext> AccessAsync() => _caller.ForAsync(User);

    // The same view of the lead as GET /leads/{id}.
    private LeadView LeadViewOf() => CallerContext.LeadViewOf(User);

    private IActionResult Respond(LeadStageValueProcess.Outcome outcome) =>
        outcome.Refusal is not { } r ? Ok(outcome.Dto)
        : r.NotFound ? NotFound(new { error = r.Reason })
        : r.Forbidden ? StatusCode(403, new { error = r.Reason, code = r.Code })
        : BadRequest(new { error = r.Reason });

    // GET /leads/{id}/stage-values -> { fields: [{key,label,type}], sets: { proposal, negotiation, closed }, masked }
    [HttpGet]
    public async Task<IActionResult> Get(Guid leadId, CancellationToken ct) =>
        Respond(await _values.GetAsync(await AccessAsync(), LeadViewOf(), leadId, ct));

    // PUT /leads/{id}/stage-values/{kind} - correct one set; kind = proposal | negotiation | closed.
    [HttpPut("{kind}")]
    public async Task<IActionResult> Put(Guid leadId, string kind, [FromBody] StageValueSetInput input, CancellationToken ct) =>
        Respond(await _values.PutAsync(await AccessAsync(), LeadViewOf(), User.UserId(), leadId, kind, input, DateTime.UtcNow, ct));
}

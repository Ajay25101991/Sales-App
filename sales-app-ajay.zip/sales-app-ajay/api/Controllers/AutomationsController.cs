using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.ExperienceLayer.Automations;
using SalesApi.ProcessLayer.Automations;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Automations (E2.2 slice 1) — draft CRUD, publish/disable/restore, typed-
/// confirmation hard delete. No runtime yet: no run log, no execution.
///
/// EVERY ENDPOINT IS ORG-ADMIN ONLY (design doc §9: "Builder access (E2.4):
/// admins only" — epics-ai-native-crm.md:172's own wording, not the
/// team-scoped "manager can view, admin can author" split playbooks have).
/// This is a base-role check (<see cref="ClaimsPrincipalExtensions.IsOrgAdmin"/>),
/// the same bare <c>if (!User.IsOrgAdmin())</c> gate
/// <see cref="PlaybooksController.UnmatchedLeads"/> already uses for an
/// admin-only surface — NOT one of the configurable
/// <see cref="OrganizationPermissions"/> keys, because those ship to whatever
/// roles an org assigns them to (a manager can hold <c>ManageSettings</c>
/// today); "admins only" here means the base role, full stop, so no org
/// configuration can hand a manager automation-authoring rights by accident.
/// No new permission key was added for this reason — see the story report.
/// </summary>
[ApiController]
[Authorize]
[Route("automations")]
public class AutomationsController : ControllerBase
{
    private readonly AutomationsExperience _automations;
    public AutomationsController(AutomationsExperience automations) => _automations = automations;

    private IActionResult Forbidden() => StatusCode(403, new { error = "Only org admins can manage automations." });

    private IActionResult Refused(AutomationProcess.Refusal refusal) =>
        refusal.NotFound
            ? NotFound(new { error = refusal.Reason })
            : refusal.Conflict
                ? Conflict(new { error = refusal.Reason })
                : BadRequest(new { error = refusal.Reason });

    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct, bool includeArchived = false)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        return Ok(await _automations.ListAsync(includeArchived, ct));
    }

    // The builder's `{{field}}` picker one source (design doc §12 slice 4
    // follow-up, 2026-09-27) — admin-only like every other endpoint here.
    // Ahead of GET {id:guid} in file order for readability only; the
    // {id:guid} route constraint means "merge-fields" never matches it.
    [HttpGet("merge-fields")]
    public async Task<IActionResult> MergeFields([FromQuery] string? entity, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        return Ok(await _automations.MergeFieldsAsync(entity, ct));
    }

    // Which fields a "field changed" trigger can watch (form vocabulary),
    // derived from the field-change audit's allow-list. Same permission as the
    // other builder config reads (merge-fields).
    [HttpGet("watchable-fields")]
    public IActionResult WatchableFields()
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        return Ok(_automations.WatchableFields());
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var automation = await _automations.GetAsync(id, ct);
        if (automation is null) return NotFound(new { error = "Automation not found." });
        return Ok(automation);
    }

    [HttpGet("{id:guid}/versions")]
    public async Task<IActionResult> Versions(Guid id, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var versions = await _automations.VersionsAsync(id, ct);
        if (versions is null) return NotFound(new { error = "Automation not found." });
        return Ok(versions);
    }

    // E7.6 — a new automation may only be created while the org's plan
    // includes the "automations" feature; the background scan re-checks the
    // same gate on every due run (AutomationRunner), so a plan downgrade
    // stops execution too, not just creation.
    [HttpPost]
    [RequirePlanFeature(SalesApi.Dtos.PlanCatalogue.Features.Automations)]
    public async Task<IActionResult> Create([FromBody] AutomationInput input, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (created, refusal) = await _automations.CreateAsync(input.Name, input.Description, input.Key, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(created);
    }

    // Rename (E2.2 slice 6, design doc §12 slice 6) — name/description only,
    // kept as its own PATCH rather than folded into SaveDraft: renaming never
    // touches trigger/condition/actions and doesn't need a draft to exist.
    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Rename(Guid id, [FromBody] AutomationRenameInput input, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (result, refusal) = await _automations.RenameAsync(id, input.Name, input.Description, ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    [HttpPut("{id:guid}/draft")]
    public async Task<IActionResult> SaveDraft(Guid id, [FromBody] AutomationDraftInput input, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (result, refusal) = await _automations.SaveDraftAsync(
            id, input.Trigger, input.Condition, input.Actions, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    [HttpPost("{id:guid}/publish")]
    public async Task<IActionResult> Publish(Guid id, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (result, refusal) = await _automations.PublishAsync(id, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    [HttpPost("{id:guid}/disable")]
    public async Task<IActionResult> Disable(Guid id, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (ok, refusal) = await _automations.SetEnabledAsync(id, false, ct);
        return refusal is not null ? Refused(refusal) : Ok(new { ok });
    }

    [HttpPost("{id:guid}/enable")]
    public async Task<IActionResult> Enable(Guid id, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (ok, refusal) = await _automations.SetEnabledAsync(id, true, ct);
        return refusal is not null ? Refused(refusal) : Ok(new { ok });
    }

    [HttpPost("{id:guid}/archive")]
    public async Task<IActionResult> Archive(Guid id, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (ok, refusal) = await _automations.ArchiveAsync(id, ct);
        return refusal is not null ? Refused(refusal) : Ok(new { ok });
    }

    // "Restore" (the brief's word for this slice) is un-archiving a custom
    // automation back to active — mirrors PlaybooksController.Unarchive.
    // "Restore DEFAULT" (re-seeding a built-in's shipped definition, E2.0
    // decision 7) is an E2.5 concern: no built-in ships until that slice.
    [HttpPost("{id:guid}/restore")]
    public async Task<IActionResult> Restore(Guid id, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (ok, refusal) = await _automations.UnarchiveAsync(id, ct);
        return refusal is not null ? Refused(refusal) : Ok(new { ok });
    }

    // "Restore DEFAULT" (E2.5, design doc §12 slice 7 rule 3) — re-seeds a
    // BUILT-IN's shipped definition as a new draft version. Distinct from
    // Restore() above (un-archiving a custom automation).
    [HttpPost("{id:guid}/restore-default")]
    public async Task<IActionResult> RestoreDefault(Guid id, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (result, refusal) = await _automations.RestoreDefaultAsync(id, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    // Run log (E2.2 slice 2, design doc §12 slice 2, §10's "Run log tab") —
    // admin-only like every other endpoint here (§9: same base-role gate, no
    // team-scoped middle tier for automations).
    [HttpGet("{id:guid}/runs")]
    public async Task<IActionResult> Runs(Guid id, [FromQuery] string? cursor, [FromQuery] int? limit, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (page, refusal) = await _automations.RunsAsync(id, cursor, limit, ct);
        return refusal is not null ? Refused(refusal) : Ok(page);
    }

    // Retry a failed/partial run (design §10, 2026-09-27 "automation reach"
    // follow-up) — admin-only like every other endpoint here. See
    // AutomationRunner.RetryFailedActionsAsync for what "retry" means: only
    // the run's FAILED actions, against the record's current state, as a new
    // linked run.
    [HttpPost("{id:guid}/runs/{runId:guid}/retry")]
    public async Task<IActionResult> RetryRun(Guid id, Guid runId, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (result, refusal) = await _automations.RetryRunAsync(id, runId, ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    // Run preview (design doc §7, §12 slice 8, E2.0 decision 10) — admin-only
    // like every other endpoint here. GET, not POST: a pure read, writes
    // nothing, and idempotent to call as often as the builder likes while an
    // admin edits the draft.
    [HttpGet("{id:guid}/preview")]
    public async Task<IActionResult> Preview(Guid id, CancellationToken ct, [FromQuery] int? sampleSize = null)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (result, refusal) = await _automations.PreviewAsync(id, sampleSize, ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    // Publish-narrowing warning (design doc §7, E2.0 decision 11: "warn and
    // allow"). The builder calls this BEFORE calling POST .../publish and
    // shows its warning; Publish itself is unchanged and still succeeds.
    [HttpGet("{id:guid}/publish-preview")]
    public async Task<IActionResult> PublishPreview(Guid id, CancellationToken ct, [FromQuery] int? sampleSize = null)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (result, refusal) = await _automations.PublishPreviewAsync(id, sampleSize, ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id, [FromBody] AutomationDeleteInput input, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (ok, refusal) = await _automations.HardDeleteAsync(id, input.Confirmation, ct);
        return refusal is not null ? Refused(refusal) : Ok(new { ok });
    }
}

/// <summary><see cref="Key"/> is the E7.1 stable identity (design doc §10
/// owner answer 5) — left null to pre-fill it from <see cref="Name"/>. There
/// is no update endpoint for it: editing it after creation is refused by
/// omission, not by a guard.</summary>
public record AutomationInput(string? Name, string? Description, string? Key = null);
public record AutomationRenameInput(string? Name, string? Description);
public record AutomationDraftInput(JsonElement? Trigger, JsonElement? Condition, JsonElement? Actions);
public record AutomationDeleteInput(string? Confirmation);

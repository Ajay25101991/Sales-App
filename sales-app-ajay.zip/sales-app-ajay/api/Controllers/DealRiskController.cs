using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.ExperienceLayer.AiPlatform;
using SalesApi.Services;

namespace SalesApi.Controllers;

// GET /leads/{id}/risk (to-do/epics-ai-native-crm.md E5.6, story brief items
// 6-7). Permission = whoever can read the lead — the SAME RecordAccessContext
// LeadsController.Get uses (CallerContext, the shared "needs both the
// principal and a row" residual every migrated controller keeps).
[ApiController]
[Authorize]
public class DealRiskController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly DealRiskExperience _risk;

    public DealRiskController(CallerContext caller, DealRiskExperience risk)
    {
        _caller = caller;
        _risk = risk;
    }

    [HttpGet("leads/{id:guid}/risk")]
    public async Task<IActionResult> Get(Guid id)
    {
        var vis = await _caller.ForAsync(User);
        var (refusal, available, dto) = await _risk.GetAsync(vis, id);
        if (refusal is not null)
            return refusal.NotFound ? NotFound(new { error = refusal.Reason })
                : refusal.Forbidden ? StatusCode(403, new { error = refusal.Reason })
                : BadRequest(new { error = refusal.Reason });

        // Owner decision (to-do/epics-ai-native-crm.md "E5 build decisions"
        // item 2): AI off -> { "available": false }, nothing else on the wire.
        if (!available) return Ok(new SalesApi.Dtos.DealRiskUnavailableDto(false));
        // Available, but no row yet (a brand-new lead before the first sweep/
        // on-change compute has run) — available:true with nothing computed
        // yet, distinct from the AI-off shape above.
        return dto is null ? Ok(new { available = true, computed = false }) : Ok(dto);
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.WhatsApp;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E6.4 (design doc to-do/e6-connectors-design.md §4.6) — the "Unmatched
/// WhatsApp" triage inbox (owner answer 2's "triage" default): list, link to
/// an existing lead, create a new lead, or dismiss. Gated the same as the
/// setting that produces these rows (ManageSettings) — reusing the generic
/// activity/send permission would let any rep re-route stray inbound
/// messages, which is an admin-shaped decision.
/// </summary>
[ApiController]
[Authorize]
[Route("whatsapp/unmatched")]
public class WhatsAppUnmatchedController : ControllerBase
{
    private readonly WhatsAppTriageExperience _triage;
    public WhatsAppUnmatchedController(WhatsAppTriageExperience triage) => _triage = triage;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);

    [HttpGet]
    public async Task<IActionResult> List()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot view this." });
        return Ok(await _triage.ListAsync());
    }

    [HttpPost("{id:guid}/link")]
    public async Task<IActionResult> Link(Guid id, [FromBody] WhatsAppLinkUnmatchedInput input)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this." });
        var (refusal, dto) = await _triage.LinkAsync(id, input.LeadId, User.UserId());
        return refusal switch
        {
            { NotFound: true } => NotFound(new { error = refusal.Reason }),
            not null => BadRequest(new { error = refusal.Reason }),
            _ => Ok(dto),
        };
    }

    [HttpPost("{id:guid}/create-lead")]
    public async Task<IActionResult> CreateLead(Guid id)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this." });
        var (refusal, leadId) = await _triage.CreateLeadAsync(id, User.UserId());
        return refusal switch
        {
            { NotFound: true } => NotFound(new { error = refusal.Reason }),
            not null => BadRequest(new { error = refusal.Reason }),
            _ => Ok(new { lead_id = leadId }),
        };
    }

    [HttpPost("{id:guid}/dismiss")]
    public async Task<IActionResult> Dismiss(Guid id)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this." });
        var (refusal, dto) = await _triage.DismissAsync(id, User.UserId());
        return refusal switch
        {
            { NotFound: true } => NotFound(new { error = refusal.Reason }),
            not null => BadRequest(new { error = refusal.Reason }),
            _ => Ok(dto),
        };
    }
}

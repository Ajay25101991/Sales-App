using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Playbooks;
using SalesApi.ProcessLayer.Playbooks;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Playbooks: named pipeline definitions, versioned, published (design doc §3).
///
/// VISIBILITY IS DELIBERATELY NOT TEAM-SCOPED (decision D3). An UNASSIGNED
/// playbook is visible to org admins ONLY — it must never go through
/// WhereViewable/TeamScopedQueries, because those apply the convention that a
/// null team is visible org-wide. That convention is right for RECORDS and
/// wrong for CONFIGURATION: a playbook created and not yet assigned should be
/// invisible until someone assigns it, not visible to everyone.
///
/// Reuses CreateWorkflows for authoring rather than inventing a permission: a
/// playbook IS the workflow concept the roles system already names, and adding a
/// second permission would silently grant nobody anything until every role was
/// re-configured.
/// </summary>
[ApiController]
[Authorize]
[Route("playbooks")]
public class PlaybooksController : ControllerBase
{
    private readonly PlaybooksExperience _playbooks;
    private readonly PlaybookAssignmentExperience _assignment;
    public PlaybooksController(PlaybooksExperience playbooks, PlaybookAssignmentExperience assignment)
    {
        _playbooks = playbooks;
        _assignment = assignment;
    }

    private bool CanAuthor() => User.HasPermission(OrganizationPermissions.CreateWorkflows);
    private IActionResult Forbidden() => StatusCode(403, new { error = "Your role cannot create or publish playbooks." });

    /// <summary>
    /// Maps a Process/Experience refusal to the right HTTP status. Not found
    /// vs. a plain refusal is the only distinction that survives the trip —
    /// same mapping <c>TargetsController.Set</c> uses for the goals vertical.
    /// </summary>
    private IActionResult Refused(PlaybookProcess.Refusal refusal) =>
        refusal.NotFound
            ? NotFound(new { error = refusal.Reason })
            : refusal.Conflict
                ? Conflict(new { error = refusal.Reason })
                : BadRequest(new { error = refusal.Reason });

    // includeArchived: the Workflows screen's "show archived" filter (item 6),
    // same shape as the lead-form library's own archived_at column — org-admin
    // only, enforced in Process (a non-admin's request for archived rows just
    // gets the live list, same as omitting the param).
    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct, bool includeArchived = false)
    {
        if (!User.HasPermission(OrganizationPermissions.ViewTeam) && !CanAuthor()) return Forbidden();
        var rows = await _playbooks.ListAsync(User.IsOrgAdmin(), User.TeamScope(), includeArchived, ct);
        return Ok(rows);
    }

    /// <summary>
    /// The playbook PICKER's data source (design doc D10a) — id/name only, for
    /// LIVE playbooks this caller can see. Open to any signed-in user, unlike
    /// <see cref="List"/> (which needs ViewTeam or CreateWorkflows): D10a's
    /// Setting 2 defaults to "anyone who can create/edit the lead", and most
    /// reps hold neither of those permissions. This is not a privilege
    /// escalation — it returns strictly less than <see cref="List"/> (no
    /// versions, no match rules, no drafts) and is still scoped through
    /// <see cref="PlaybookProcess"/>'s internal visibility filter, so D3's
    /// admin-only-until-assigned rule for an unassigned playbook still
    /// applies. Whether the caller may actually SUBMIT a pick is enforced
    /// separately, server-side, by
    /// <see cref="Services.PlaybookPolicyService.CanChoose"/> at
    /// create/update time — this endpoint only decides what they may see.
    /// </summary>
    [HttpGet("live")]
    public async Task<IActionResult> Live(CancellationToken ct)
    {
        var rows = await _playbooks.LiveAsync(User.IsOrgAdmin(), User.TeamScope(), ct);
        return Ok(rows);
    }

    /// <summary>
    /// One playbook, WITH the stage list a builder can load and edit — the
    /// thing the library's row shape deliberately omits from <see cref="List"/>
    /// (a library screen renders a hundred rows and must not pull every
    /// version's jsonb to do it). Prefers the draft (what an author is
    /// actively editing); falls back to the live version so a never-drafted
    /// live playbook still opens with its real stages rather than empty.
    /// </summary>
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ViewTeam) && !CanAuthor()) return Forbidden();
        var playbook = await _playbooks.GetAsync(id, User.IsOrgAdmin(), User.TeamScope(), ct);
        if (playbook is null) return NotFound(new { error = "Playbook not found." });
        return Ok(playbook);
    }

    /// <summary>
    /// Every version this playbook has ever had, newest first — draft, live and
    /// archived rows, never deleted. Read-only, same visibility rule as
    /// <see cref="Get"/>: the library screen's row shape deliberately omits
    /// this (see <see cref="List"/>'s doc), so it is its own endpoint rather
    /// than a field the list would always have to pay for.
    /// </summary>
    [HttpGet("{id:guid}/versions")]
    public async Task<IActionResult> Versions(Guid id, CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ViewTeam) && !CanAuthor()) return Forbidden();
        var versions = await _playbooks.VersionsAsync(id, User.IsOrgAdmin(), User.TeamScope(), ct);
        if (versions is null) return NotFound(new { error = "Playbook not found." });
        return Ok(versions);
    }

    /// <summary>
    /// Copies a historical version's stage list into the DRAFT (never the live
    /// version, priority or match condition). 409 if an existing draft has
    /// unsaved content that differs from what would be restored, unless the
    /// body says <c>replace_draft: true</c> — restoring must never silently
    /// discard someone's in-progress edit.
    /// </summary>
    [HttpPost("{id:guid}/versions/{version:int}/restore")]
    public async Task<IActionResult> RestoreVersion(Guid id, int version, [FromBody] PlaybookRestoreInput? input, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        var (result, refusal) = await _playbooks.RestoreVersionAsync(
            id, User.IsOrgAdmin(), User.TeamScope(), version, input?.ReplaceDraft ?? false, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] PlaybookInput input, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        var (created, refusal) = await _playbooks.CreateAsync(input.Name, input.Description, input.Key, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(created);
    }

    /// <summary>
    /// Sets this playbook's Q14/D7 matching fields — priority and condition.
    /// Deliberately its OWN endpoint rather than folded into
    /// <see cref="SaveDraft"/> or <see cref="Publish"/>: D7's entire reasoning
    /// is that editing a match rule must NOT force a republish (which under D5
    /// also republishes the stage list and re-runs the stranded-leads
    /// guardrail for a change that has nothing to do with either).
    ///
    /// Takes effect immediately for the NEXT lead created — Q14 declined live
    /// re-evaluation and a manual override, so this can never move a lead that
    /// already has a <c>PlaybookId</c>, whatever it stamped under.
    /// </summary>
    [HttpPut("{id:guid}/matching")]
    public async Task<IActionResult> SetMatching(Guid id, [FromBody] PlaybookMatchingInput input, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        var (result, refusal) = await _playbooks.SetMatchingAsync(
            id, User.IsOrgAdmin(), User.TeamScope(), input.Priority, input.MatchCondition, ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    /// <summary>
    /// Leads matching genuinely ran on and found nothing for (design doc
    /// D4/D6a: "left open for the org admins" — this is the surface that
    /// makes that phrase real instead of a fiction).
    ///
    /// ORG ADMIN ONLY, same reasoning as <see cref="VisibleAsync"/> (D3): this
    /// is a configuration gap, not a record, so it does not get the
    /// fail-open "null team/owner is visible org-wide" treatment
    /// `TeamScope.Covers`/`RecordAccess` give real records. It is
    /// deliberately NOT run through those helpers.
    ///
    /// WHY NOT `WHERE playbook_id IS NULL`: every lead created before this
    /// feature shipped (3,135 of them in production as of 2026-08-24) also
    /// has a null <c>PlaybookId</c> — not because matching ran and found
    /// nothing, but because matching did not exist yet. Filtering on that
    /// alone would produce a screen of thousands of rows that mean nothing
    /// and look like it's working. <see cref="Lead.PlaybookMatchAttempted"/>
    /// is the column that draws the real line: true only where
    /// <c>LeadsController.Create</c> actually called
    /// <see cref="PlaybookMatchService"/>, never backfilled for older rows.
    ///
    /// WHAT THIS CANNOT DISTINGUISH: a lead whose CSV import or the
    /// stranded-lead publish remap left untouched (§4.2 paths 4-5, by design)
    /// looks identical to one that predates matching entirely — both read
    /// `PlaybookMatchAttempted = false`. Both are correctly excluded from
    /// this queue for the same reason: matching never ran on either, so there
    /// is no "no match found" verdict to surface.
    /// </summary>
    [HttpGet("unmatched-leads")]
    public async Task<IActionResult> UnmatchedLeads(CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return StatusCode(403, new { error = "Only org admins can see unmatched leads." });
        return Ok(await _playbooks.UnmatchedLeadsAsync(ct));
    }

    /// <summary>Replaces the draft's stage list. Creates the draft if publishing left none.</summary>
    [HttpPut("{id:guid}/draft")]
    public async Task<IActionResult> SaveDraft(Guid id, [FromBody] PlaybookDraftInput input, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        var (result, refusal) = await _playbooks.SaveDraftAsync(
            id, User.IsOrgAdmin(), User.TeamScope(), input.Stages, User.UserId(), ct, input.PostWin, input.StageValueFields);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    /// <summary>
    /// What publishing would do to leads already on this playbook. Every count
    /// comes from the leads table — the designer must never estimate it.
    /// </summary>
    [HttpGet("{id:guid}/publish-preview")]
    public async Task<IActionResult> PublishPreview(Guid id, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        var (preview, refusal) = await _playbooks.PublishPreviewAsync(id, User.IsOrgAdmin(), User.TeamScope(), ct);
        return refusal is not null ? Refused(refusal) : Ok(preview);
    }

    [HttpPost("{id:guid}/publish")]
    public async Task<IActionResult> Publish(Guid id, [FromBody] PlaybookPublishInput? input, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        var (result, refusal) = await _playbooks.PublishAsync(
            id, User.IsOrgAdmin(), User.TeamScope(), input?.Remap, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    /// <summary>
    /// Teams this playbook currently runs on. The "activate this one" control
    /// from the legacy single-live-workflow screen becomes "assign to teams" —
    /// PlaybookAssignment is MANY-TO-MANY on purpose (owner decision, 2026-08-24
    /// / design doc §10 Q4): a team may run several playbooks at once, so there
    /// is deliberately no unique index on (OrgId, TeamId) to enforce "one
    /// playbook per team".
    /// </summary>
    [HttpGet("{id:guid}/assignments")]
    public async Task<IActionResult> GetAssignments(Guid id, CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ViewTeam) && !CanAuthor()) return Forbidden();
        var (result, refusal) = await _playbooks.GetAssignmentsAsync(id, User.IsOrgAdmin(), User.TeamScope(), ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    /// <summary>
    /// Replaces the whole assignment set for this playbook — the same
    /// whole-set-PUT shape as <c>TeamsController.SetMembers</c>, for the same
    /// reason: two managers editing concurrently should collide on the whole
    /// set rather than interleave into an assignment list neither of them chose.
    /// </summary>
    [HttpPut("{id:guid}/assignments")]
    public async Task<IActionResult> SetAssignments(Guid id, [FromBody] PlaybookAssignmentsInput input, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        var (result, refusal) = await _playbooks.SetAssignmentsAsync(
            id, User.IsOrgAdmin(), User.TeamScope(), input.TeamIds, ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    // POST /playbooks/{id}/archive — mirrors LeadFormsController.Archive
    // (same CreateWorkflows-gated pattern, same { ok = true } body); refused,
    // Conflict, while the playbook is assigned to a team or leads still point
    // at it — see PlaybookProcess.ArchiveAsync's own doc comment.
    [HttpPost("{id:guid}/archive")]
    public async Task<IActionResult> Archive(Guid id, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        var (ok, refusal) = await _playbooks.ArchiveAsync(id, User.IsOrgAdmin(), User.TeamScope(), User.UserId(), ct);
        if (refusal is not null) return Refused(refusal);
        return Ok(new { ok });
    }

    // POST /playbooks/{id}/unarchive — the retire path's counterpart; lead
    // forms have no equivalent endpoint (see item 6's brief), so this is new
    // rather than mirrored.
    [HttpPost("{id:guid}/unarchive")]
    public async Task<IActionResult> Unarchive(Guid id, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        var (ok, refusal) = await _playbooks.UnarchiveAsync(id, User.IsOrgAdmin(), User.TeamScope(), User.UserId(), ct);
        if (refusal is not null) return Refused(refusal);
        return Ok(new { ok });
    }

    /// <summary>E3.7 — the shipped MEDDICC/BANT starting templates. Static,
    /// not scoped to any one playbook, so it needs no MineAsync lookup — same
    /// permission as <see cref="List"/> (an author browsing the library is the
    /// only caller who would ever need this).</summary>
    [HttpGet("qualification-templates")]
    public IActionResult QualificationTemplates()
    {
        if (!User.HasPermission(OrganizationPermissions.ViewTeam) && !CanAuthor()) return Forbidden();
        return Ok(Services.QualificationTemplates.All);
    }

    /// <summary>GET .../qualification-items — the builder's Qualification tab
    /// load. Same visibility/permission shape as <see cref="Get"/>.</summary>
    [HttpGet("{id:guid}/qualification-items")]
    public async Task<IActionResult> QualificationItems(Guid id, CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ViewTeam) && !CanAuthor()) return Forbidden();
        var (items, refusal) = await _playbooks.QualificationItemsAsync(id, User.IsOrgAdmin(), User.TeamScope(), ct);
        return refusal is not null ? Refused(refusal) : Ok(items);
    }

    /// <summary>PUT .../qualification-items — replaces the draft's whole item
    /// list, the same whole-list-PUT shape as <see cref="SaveDraft"/>.</summary>
    [HttpPut("{id:guid}/qualification-items")]
    public async Task<IActionResult> SaveQualificationItems(Guid id, [FromBody] QualificationItemsInput input, CancellationToken ct)
    {
        if (!CanAuthor()) return Forbidden();
        var (result, refusal) = await _playbooks.SaveQualificationItemsAsync(
            id, User.IsOrgAdmin(), User.TeamScope(), input.Items, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    private IActionResult RefusedAssignment(ProcessLayer.Playbooks.PlaybookAssignmentProcess.Refusal refusal) =>
        refusal.Conflict ? Conflict(new { error = refusal.Reason }) : BadRequest(new { error = refusal.Reason });

    /// <summary>
    /// "Apply to existing leads" (owner decision 2026-10-03,
    /// to-do/playbook-assignment-todo.md) — read-only preview of moving every
    /// lead whose team has exactly one live assigned playbook onto it.
    /// ManageSettings, not CreateWorkflows: this is a one-off data-correction
    /// action over leads/teams, not authoring a playbook.
    /// </summary>
    [HttpPost("apply-to-existing/preview")]
    public async Task<IActionResult> ApplyToExistingPreview(CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot apply playbook assignments to existing leads." });
        return Ok(await _assignment.PreviewAsync(ct));
    }

    /// <summary>
    /// Applies EXACTLY the previously previewed set, plus the admin's choices
    /// for any "needs a choice" team — refused if the underlying data moved
    /// since the preview (see <see cref="ProcessLayer.Playbooks.PlaybookAssignmentProcess"/>).
    /// </summary>
    [HttpPost("apply-to-existing")]
    public async Task<IActionResult> ApplyToExisting([FromBody] PlaybookApplyInput input, CancellationToken ct)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings))
            return StatusCode(403, new { error = "Your role cannot apply playbook assignments to existing leads." });
        var (result, refusal) = await _assignment.ApplyAsync(input.PreviewToken, input.Choices, User.UserId(), ct);
        return refusal is not null ? RefusedAssignment(refusal) : Ok(result);
    }
}

/// <summary><see cref="Key"/> is the E7.1 stable identity (design doc §10
/// owner answer 5) — left null to pre-fill it from <see cref="Name"/>. There
/// is no update endpoint for it: editing it after creation is refused by
/// omission, not by a guard.</summary>
public record PlaybookInput(string? Name, string? Description, string? Key = null);
// PostWin (E13): the workflow's after-the-win overrides. Absent leaves the draft's as they are; an object replaces them all
// (null fields = use the org setting; {} clears every override).
// StageValueFields (deal values per stage): absent leaves the draft's list; [] clears it and makes the stages' value_role markers authoritative.
public record PlaybookDraftInput(List<StageDefDto>? Stages, PlaybookPostWinDto? PostWin = null, List<string>? StageValueFields = null);
public record PlaybookPublishInput(Dictionary<string, string>? Remap);
public record PlaybookAssignmentsInput(List<Guid>? TeamIds);
public record PlaybookMatchingInput(int? Priority, JsonElement? MatchCondition);
public record PlaybookRestoreInput(bool? ReplaceDraft);
public record QualificationItemsInput(List<QualificationItemDto>? Items);

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Mailbox;
using SalesApi.ProcessLayer.Mailbox;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E12.6 - email a lead or contact from the rep's own Microsoft 365 mailbox without the address reaching the client. Contract:
/// to-do/sensitive-data-api.md section 8. Routes and picks a status code. Deliberately NOT behind [RequireSensitiveAccess]: a masked or
/// hidden caller may send (owner decision 30); the Process checks only that the caller can reach the record.
/// </summary>
[ApiController]
[Authorize]
public class RecordEmailsController : ControllerBase
{
    private readonly RecordEmailExperience _emails;
    private readonly CallerContext _caller;

    public RecordEmailsController(RecordEmailExperience emails, CallerContext caller)
    {
        _emails = emails;
        _caller = caller;
    }

    /// <summary>403/404/409/400/503 with <c>{error, code?}</c>; 202 with the sent summary.</summary>
    private IActionResult Respond<T>(RecordEmailProcess.Result<T> r) => r.Outcome switch
    {
        RecordEmailProcess.Outcome.NotFound => NotFound(new { error = r.Error }),
        RecordEmailProcess.Outcome.Forbidden => StatusCode(403, new { error = r.Error }),
        RecordEmailProcess.Outcome.Conflict => Conflict(new { error = r.Error, code = r.Code }),
        RecordEmailProcess.Outcome.Unavailable => StatusCode(503, new { error = r.Error, code = r.Code }),
        RecordEmailProcess.Outcome.Invalid => BadRequest(new { error = r.Error, code = r.Code }),
        _ => r.Value is RecordEmailSentDto ? StatusCode(202, r.Value) : Ok(r.Value),
    };

    /// <summary>The email templates usable in the compose (a subject set, no server purpose).</summary>
    [HttpGet("emails/templates")]
    public async Task<IActionResult> Templates(CancellationToken ct) => Ok(await _emails.TemplatesAsync(ct));

    [HttpPost("leads/{id:guid}/emails")]
    public async Task<IActionResult> SendToLead(Guid id, [FromBody] SendRecordEmailInput? input, CancellationToken ct) =>
        Respond(await _emails.SendToLeadAsync(
            await _caller.ForAsync(User), User.UserId(), await _caller.DisplayNameAsync(User), id, input ?? new SendRecordEmailInput(null, null), ct));

    [HttpPost("contacts/{id:guid}/emails")]
    public async Task<IActionResult> SendToContact(Guid id, [FromBody] SendRecordEmailInput? input, CancellationToken ct) =>
        Respond(await _emails.SendToContactAsync(
            await _caller.ForAsync(User), User.UserId(), await _caller.DisplayNameAsync(User), id, input ?? new SendRecordEmailInput(null, null), ct));

    /// <summary>Email an account: <c>to</c> is required (picked from the account's contacts or typed). Logged on the account's timeline.</summary>
    [HttpPost("accounts/{id:guid}/emails")]
    public async Task<IActionResult> SendToAccount(Guid id, [FromBody] SendRecordEmailInput? input, CancellationToken ct) =>
        Respond(await _emails.SendToAccountAsync(
            await _caller.ForAsync(User), User.UserId(), await _caller.DisplayNameAsync(User), id, input ?? new SendRecordEmailInput(null, null), ct));

    /// <summary>Who an email on this account can go to: its contacts, then the contacts of the partners on its deals.</summary>
    [HttpGet("accounts/{id:guid}/email-recipients")]
    public async Task<IActionResult> AccountRecipients(Guid id, CancellationToken ct) =>
        Respond(await _emails.AccountRecipientsAsync(await _caller.ForAsync(User), id, ct));

    // Invoices and AMCs sit behind financials.view everywhere else (their controllers' class-level permission), so these two do too.
    [HttpPost("invoices/{id:guid}/emails")]
    [RequirePermission(OrganizationPermissions.ViewFinancials)]
    public async Task<IActionResult> SendToInvoice(Guid id, [FromBody] SendRecordEmailInput? input, CancellationToken ct) =>
        Respond(await _emails.SendToInvoiceAsync(
            await _caller.ForAsync(User), User.UserId(), await _caller.DisplayNameAsync(User), id, input ?? new SendRecordEmailInput(null, null), ct));

    [HttpPost("amcs/{id:guid}/emails")]
    [RequirePermission(OrganizationPermissions.ViewFinancials)]
    public async Task<IActionResult> SendToAmc(Guid id, [FromBody] SendRecordEmailInput? input, CancellationToken ct) =>
        Respond(await _emails.SendToAmcAsync(
            await _caller.ForAsync(User), User.UserId(), await _caller.DisplayNameAsync(User), id, input ?? new SendRecordEmailInput(null, null), ct));

    /// <summary>Who can be copied: the contacts of the deal's account and partners (CC / BCC picker).</summary>
    [HttpGet("leads/{id:guid}/email-recipients")]
    public async Task<IActionResult> Recipients(Guid id, CancellationToken ct) =>
        Respond(await _emails.RecipientsAsync(await _caller.ForAsync(User), id, ct));

    /// <summary>"Reply" on a logged email (a timeline item's source_id): leaves a draft reply in the caller's own Outlook and returns its link. Sends and logs nothing.</summary>
    [HttpPost("emails/{eventId:guid}/reply-draft")]
    public async Task<IActionResult> ReplyDraft(Guid eventId, CancellationToken ct) =>
        Respond(await _emails.ReplyDraftAsync(await _caller.ForAsync(User), User.UserId(), eventId, ct));

    /// <summary>The lead's recent email threads that are in the caller's own mailbox, to reply on (owner decision 38).</summary>
    [HttpGet("leads/{id:guid}/email-threads")]
    public async Task<IActionResult> Threads(Guid id, CancellationToken ct) =>
        Respond(await _emails.ThreadsAsync(await _caller.ForAsync(User), User.UserId(), id, ct));
}

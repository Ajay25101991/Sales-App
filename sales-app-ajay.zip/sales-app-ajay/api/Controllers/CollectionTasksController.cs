using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.CollectionTasks;
using SalesApi.ProcessLayer.CollectionTasks;
using SalesApi.Services;

namespace SalesApi.Controllers;

// Field collection workflow: a manager assigns an invoice's amount + expected
// payment mode to be collected; it's broadcast to all collectors; whoever
// collects records the payment and gets a receipt back-linked to the invoice.
//
// MIGRATED to the layered API (api-led migration, step 8). Business rules that
// used to live inline here now live in SalesApi.ProcessApi/CollectionTasks/
// CollectionTaskProcess.cs, reached through SalesApi.ExperienceApi/
// CollectionTasks/CollectionTasksExperience.cs. What is left here: routing,
// [Authorize]/[RequirePermission], the manual manager/collector checks
// (request-shaped facts, not domain rules), model binding, and choosing the
// HTTP status for a Refusal.
[ApiController]
[Route("collection-tasks")]
[Authorize]
[RequirePermission(OrganizationPermissions.ViewFinancials)]
public class CollectionTasksController : ControllerBase
{
    private readonly CollectionTasksExperience _tasks;
    public CollectionTasksController(CollectionTasksExperience tasks)
    {
        _tasks = tasks;
    }

    // Money masking (invoice-money-masking, owner decision 2026-09-28): the
    // SAME permission every other invoice-money surface gates on. Both the
    // manager and collector DEFAULT roles hold it (OrganizationRoleService),
    // so this only narrows a custom role an org has deliberately trimmed —
    // access to the task itself (who may list/collect/cancel) is unchanged.
    private bool CanSeeFinancials =>
        User.HasPermission(OrganizationPermissions.ViewAccountFinancials);

    private IActionResult FromRefusal(CollectionTaskProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason }) : BadRequest(new { error = refusal.Reason });

    // GET /collection-tasks?status= — managers see all; collectors see the open
    // pool plus tasks they collected (for their receipts).
    [HttpGet]
    public async Task<IActionResult> List(string? status)
    {
        var isCollector = User.IsCollector();
        if (!isCollector && !User.IsManager())
            return StatusCode(403, new { error = "Not allowed" });
        return Ok(await _tasks.ListAsync(isCollector, User.UserId(), status, CanSeeFinancials));
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id)
    {
        if (!User.IsManager() && !User.IsCollector()) return StatusCode(403, new { error = "Not allowed" });
        var task = await _tasks.GetAsync(id, CanSeeFinancials);
        return task is null ? NotFound(new { error = "Task not found" }) : Ok(task);
    }

    // GET /collection-tasks/{id}/receipt/pdf — E17.1: the payment receipt of a collected task as a server-rendered PDF. Same
    // manager/collector gate and the same amount masking as the JSON read above.
    [HttpGet("{id:guid}/receipt/pdf")]
    public async Task<IActionResult> ReceiptPdf(Guid id)
    {
        if (!User.IsManager() && !User.IsCollector()) return StatusCode(403, new { error = "Not allowed" });
        var outcome = await _tasks.ReceiptPdfAsync(id, CanSeeFinancials);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : File(outcome.Bytes!, "application/pdf", outcome.FileName);
    }

    // GET /collection-tasks/{id}/modules — services the customer has purchased
    // (distinct module names across the task's invoice's lead's proposals).
    [HttpGet("{id:guid}/modules")]
    public async Task<IActionResult> CustomerModules(Guid id)
    {
        if (!User.IsManager() && !User.IsCollector()) return StatusCode(403, new { error = "Not allowed" });
        var modules = await _tasks.CustomerModulesAsync(id);
        return modules is null ? NotFound(new { error = "Task not found" }) : Ok(modules);
    }

    // POST /collection-tasks — managers assign a collection; broadcast to collectors.
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CollectionTaskInput input)
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can assign collections." });
        var outcome = await _tasks.CreateAsync(input.InvoiceId, input.Amount, input.Method, input.Notes, User.UserId(), CanSeeFinancials);
        if (outcome.Refusal is not null) return FromRefusal(outcome.Refusal);
        return StatusCode(201, outcome.Task);
    }

    // POST /collection-tasks/{id}/collect — a collector (or manager) records the
    // payment and generates a receipt.
    [HttpPost("{id:guid}/collect")]
    public async Task<IActionResult> Collect(Guid id, [FromBody] CollectTaskInput input)
    {
        if (!User.IsCollector() && !User.IsManager())
            return StatusCode(403, new { error = "Only collectors can collect." });
        var outcome = await _tasks.CollectAsync(
            id, input.Amount, input.Method, input.Reference, input.PaidAt, input.Note,
            input.Modules, input.ProofAttachmentId, input.ProofInvoiceIds, User.UserId(), CanSeeFinancials);
        if (outcome.Refusal is not null) return FromRefusal(outcome.Refusal);
        return Ok(outcome.Task);
    }

    // GET /collection-tasks/{id}/invoices — the task customer's open invoices,
    // for ticking which ones a single payment proof covers.
    [HttpGet("{id:guid}/invoices")]
    public async Task<IActionResult> CustomerInvoices(Guid id)
    {
        if (!User.IsManager() && !User.IsCollector()) return StatusCode(403, new { error = "Not allowed" });
        var outcome = await _tasks.CustomerInvoicesAsync(id, CanSeeFinancials);
        if (outcome.Refusal is not null) return FromRefusal(outcome.Refusal);
        return Ok(outcome.Invoices);
    }

    [HttpPost("{id:guid}/cancel")]
    public async Task<IActionResult> Cancel(Guid id)
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can cancel." });
        var outcome = await _tasks.CancelAsync(id, CanSeeFinancials);
        if (outcome.Refusal is not null) return FromRefusal(outcome.Refusal);
        return Ok(outcome.Task);
    }
}

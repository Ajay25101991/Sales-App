using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Teams;
using SalesApi.ProcessLayer.Teams;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Team CRUD and membership. Distinct from <see cref="TeamController"/> at
/// <c>/team</c>, which is the ORG ROSTER (people, roles, invites) and predates
/// teams-as-a-scoping-layer; this one is at <c>/teams</c> and owns the groups.
///
/// Gated on the existing <c>team.manage</c> permission rather than a new one:
/// PermissionIndexRegistry is append-only and an index slot is a permanent
/// commitment, so it should not be spent on something an existing permission
/// already covers.
///
/// API-LED MIGRATION (to-do/api-led-migration-plan.md, step 8): this controller
/// no longer touches <c>AppDbContext</c> at all. Every query and write goes
/// through <see cref="TeamsExperience"/> → <c>TeamProcess</c> → <c>TeamStore</c>.
/// What stays here, deliberately, is everything that IS an HTTP/auth concern:
/// routing, <c>[Authorize]</c>/<c>[RequirePermission]</c>, model binding, status
/// selection, and <see cref="CanAdminister"/> — a permission check about the
/// CALLER, not a rule about teams. The calendar shape check called from
/// <see cref="SetCalendar"/> used to be an exception, reaching across into
/// another controller; it is <c>CalendarValidation.Validate</c> in Contracts
/// now, shared by both calendars rather than borrowed from one of them.
/// </summary>
[ApiController]
[Route("teams")]
[Authorize]
public class TeamsController : ControllerBase
{
    private readonly TeamsExperience _experience;
    public TeamsController(TeamsExperience experience) { _experience = experience; }

    private Guid? Org => User.OrgId();

    /// <summary>
    /// May the caller administer this specific team? Org admins: any. Everyone else
    /// with <c>team.manage</c>: only teams they are in — a manager editing the roster
    /// of a team they are not a member of is a write outside their scope.
    /// </summary>
    /// <param name="user">Passed rather than read off <c>User</c> so this is a pure
    /// function of the principal — the projection on <see cref="List"/> and the four
    /// write paths call the SAME expression, and AdminFlagProjectionTests can call it
    /// without a database. Making the flag a second, parallel opinion of this rule is
    /// the failure mode the whole projection design exists to prevent.</param>
    internal static bool CanAdminister(ClaimsPrincipal user, Guid teamId) =>
        user.IsOrgAdmin() || user.TeamScope().Covers(teamId);

    // GET /teams — every team in the org, with member counts. Read is deliberately
    // wider than write: a rep needs to see team NAMES to make sense of a team column
    // on a list. Names are not sensitive; the records inside them are, and those are
    // gated by the scope predicate, not by this.
    //
    // Each row carries `can_manage`, the same flag GET /team sends per person and for
    // the same reason: read is wider than write here, so without it the management
    // screen either draws Rename/Archive/Members on every team and surfaces a 403 on
    // the ones the caller does not belong to, or recomputes CanAdminister client-side
    // and becomes a second opinion that drifts. This is a PROJECTION of the server's
    // answer — it widens nothing; the four write paths still call CanAdminister
    // themselves and refuse identically whatever this said.
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] bool includeArchived = false)
    {
        var rows = await _experience.ListAsync(includeArchived);
        // Projected after materialisation: CanAdminister reads the principal's team
        // scope, which is in memory and not translatable to SQL.
        return Ok(WithCanManage(User, rows));
    }

    /// <summary>
    /// Stamps <c>can_manage</c> onto rows already read from the database.
    ///
    /// Its own function purely so it is TESTABLE without a database — the projection is
    /// the thing that has to be proved to carry <see cref="CanAdminister"/>'s answer
    /// rather than a convenient constant, and a test that can only reach it through
    /// <see cref="List"/> cannot prove that. See AdminFlagProjectionTests.
    /// </summary>
    internal static List<TeamSummaryDto> WithCanManage(
        ClaimsPrincipal user, IEnumerable<TeamSummaryDto> rows) =>
        rows.Select(t => t with { CanManage = CanAdminister(user, t.Id) }).ToList();

    // GET /teams/{id} — one team plus its member ids, for the management screen.
    [HttpGet("{id:guid}")]
    [RequirePermission(OrganizationPermissions.ViewTeam)]
    public async Task<IActionResult> Get(Guid id)
    {
        var team = await _experience.GetAsync(id);
        if (team is null) return NotFound(new { error = "Team not found" });
        return Ok(team);
    }

    [HttpPost]
    [RequirePermission(OrganizationPermissions.ManageTeam)]
    public async Task<IActionResult> Create([FromBody] TeamInput input)
    {
        var (refusal, team) = await _experience.CreateAsync(Org, input.Name);
        if (refusal is not null) return RefusalResult(refusal);
        return StatusCode(201, team);
    }

    // PATCH /teams/{id} — rename. This is the answer to "we don't want to be called
    // 'ERP Team'": the seed name is a starting value applied uniformly to every org,
    // not a decision, and renaming it is a normal management action rather than a
    // migration.
    [HttpPatch("{id:guid}")]
    [RequirePermission(OrganizationPermissions.ManageTeam)]
    public async Task<IActionResult> Rename(Guid id, [FromBody] TeamInput input)
    {
        if (Org is not Guid org) return NotFound(new { error = "Team not found" });
        if (!CanAdminister(User, id)) return StatusCode(403, new { error = "You can only manage teams you belong to." });

        var (refusal, team) = await _experience.RenameAsync(org, id, input.Name);
        if (refusal is not null) return RefusalResult(refusal);
        // From CanAdminister rather than the literal `true` this line reached by
        // getting past the guard above: the cache this row replaces must carry the
        // same answer a refetch would, computed the same way.
        return Ok(team! with { CanManage = CanAdminister(User, id) });
    }

    // DELETE /teams/{id} — archive, never delete. Records keep a valid team_id and
    // the name becomes reusable. The default team CAN be archived now: nothing
    // falls through to it any more (numbers-audit-decisions.md #18 stage 3), so
    // the old "you must make another team the default first" refusal named an
    // action that never existed. See TeamProcess.ArchiveAsync / TeamStore.ArchiveAsync
    // for the retirement-not-revocation reasoning and the PrimaryTeamId detach.
    //
    // This used to bump members' role versions, on the stated grounds that archiving
    // "changes what its members can reach". It never did — see the original
    // controller history. That bump was never carried into the migrated version.
    [HttpDelete("{id:guid}")]
    [RequirePermission(OrganizationPermissions.ManageTeam)]
    // `moveTo` names the live team this one's PEOPLE move to. Their leads follow,
    // because a lead's team comes from its owner — so an archived team ends up
    // holding nothing. Omitted, it archives as before and leaves the roster and
    // the records where they are.
    public async Task<IActionResult> Archive(Guid id, [FromQuery] Guid? moveTo = null)
    {
        if (!CanAdminister(User, id)) return StatusCode(403, new { error = "You can only manage teams you belong to." });
        if (moveTo is Guid destination && !CanAdminister(User, destination))
            return StatusCode(403, new { error = "You can only move a team's people into a team you belong to." });

        var (outcome, detached) = await _experience.ArchiveAsync(id, moveTo, User.UserId());
        return outcome switch
        {
            TeamArchiveOutcome.NotFound => NotFound(new { error = "Team not found" }),
            // No `detached` field on the no-op path — see TeamArchiveOutcome's doc
            // comment for why that is the exact original shape, not an oversight.
            TeamArchiveOutcome.InvalidDestination =>
                BadRequest(new { error = "Choose a live team to move this team's people to." }),
            TeamArchiveOutcome.AlreadyArchived => Ok(new { ok = true }),
            _ => Ok(new { ok = true, detached }),
        };
    }

    // GET /teams/{id}/calendar — this team's calendar OVERRIDE (item 1), not the
    // resolved value: null fields mean "no override, follows the org default".
    // Use GET /settings/calendar for the org default, or ask a consumer (e.g.
    // notifications/settings) for the fully resolved calendar.
    [HttpGet("{id:guid}/calendar")]
    [RequirePermission(OrganizationPermissions.ViewTeam)]
    public async Task<IActionResult> GetCalendar(Guid id)
    {
        var (refusal, dto) = await _experience.GetCalendarAsync(id);
        if (refusal is not null) return RefusalResult(refusal);
        return Ok(dto);
    }

    // PUT /teams/{id}/calendar — set (or clear, with a null body) this team's
    // override of the org calendar. Same CanAdminister rule as renaming/archiving:
    // an org admin may override any team, everyone else with team.manage only
    // their own.
    [HttpPut("{id:guid}/calendar")]
    [RequirePermission(OrganizationPermissions.ManageTeam)]
    public async Task<IActionResult> SetCalendar(Guid id, [FromBody] CalendarSettingsInput? input)
    {
        if (Org is not Guid org) return NotFound(new { error = "Team not found" });
        if (!CanAdminister(User, id)) return StatusCode(403, new { error = "You can only manage teams you belong to." });

        // A null/empty body clears the override — the team goes back to following
        // the org default, which OrgCalendarService.ResolveAsync already handles as
        // "row absent" with no special case.
        if (input is null || string.IsNullOrWhiteSpace(input.TimeZoneId))
        {
            var clearRefusal = await _experience.ClearCalendarAsync(id);
            if (clearRefusal is not null) return RefusalResult(clearRefusal);
            return Ok((CalendarSettingsDto?)null);
        }

        // This used to be a controller-to-controller call into
        // SettingsController.ValidateCalendarInput, kept here only because Process
        // cannot see the host project. Migrating settings moved the check down into
        // Contracts, so both calendars — the org default and this team override —
        // now validate through the same CalendarValidation.Validate.
        var error = CalendarValidation.Validate(input.TimeZoneId, input.WeekStartDay, input.NonSendingDays);
        if (error is not null) return BadRequest(new { error });

        var (refusal, dto) = await _experience.SetCalendarAsync(
            org, id, input.TimeZoneId!.Trim(), input.WeekStartDay!.Value,
            input.NonSendingDays!.Distinct().OrderBy(x => x).ToList());
        if (refusal is not null) return RefusalResult(refusal);
        return Ok(dto);
    }

    // PUT /teams/{id}/members — replace the membership set wholesale. A whole-set PUT
    // rather than add/remove endpoints: the screen edits a checkbox list, and two
    // managers editing concurrently should collide on the whole set rather than
    // interleave into a roster neither of them chose.
    [HttpPut("{id:guid}/members")]
    [RequirePermission(OrganizationPermissions.ManageTeam)]
    public async Task<IActionResult> SetMembers(Guid id, [FromBody] TeamMembersInput input)
    {
        if (Org is not Guid org) return NotFound(new { error = "Team not found" });
        if (!CanAdminister(User, id)) return StatusCode(403, new { error = "You can only manage teams you belong to." });

        var (refusal, team) = await _experience.SetMembersAsync(org, id, input.UserIds);
        if (refusal is not null) return RefusalResult(refusal);
        return Ok(team);
    }

    /// <summary>Maps a <see cref="TeamProcess.Refusal"/> to the same status codes and
    /// error shapes the inline checks used to return: 404 for <c>NotFound</c>, 409 for
    /// <c>Conflict</c>, 400 otherwise.</summary>
    private IActionResult RefusalResult(TeamProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason })
        : refusal.Conflict ? StatusCode(StatusCodes.Status409Conflict, new { error = refusal.Reason })
        : BadRequest(new { error = refusal.Reason });
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.MessageTemplates;
using SalesApi.ProcessLayer.MessageTemplates;
using SalesApi.Services;

namespace SalesApi.Controllers;

// Reusable message/email snippets. Anyone signed in can read them (to insert);
// managers manage the catalog.
//
// MIGRATED to the layered API (api-led migration, step 8). CRUD now lives in
// SalesApi.ProcessApi/MessageTemplates/MessageTemplateProcess.cs, reached
// through SalesApi.ExperienceApi/MessageTemplates/MessageTemplatesExperience.cs.
// What is left here, deliberately: routing, [Authorize], the inline
// ManageSettings check on every write (a request-shaped fact about the
// caller, not a rule about a template), model binding, and choosing the HTTP
// status for a Refusal.
[ApiController]
[Route("message-templates")]
[Authorize]
public class MessageTemplatesController : ControllerBase
{
    private readonly MessageTemplatesExperience _templates;
    public MessageTemplatesController(MessageTemplatesExperience templates) => _templates = templates;

    private static IActionResult FromRefusal(MessageTemplateProcess.Refusal refusal) =>
        refusal.NotFound ? new NotFoundObjectResult(new { error = refusal.Reason })
        : new BadRequestObjectResult(new { error = refusal.Reason });

    [HttpGet]
    public async Task<IActionResult> List() => Ok(await _templates.ListAsync());

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] MessageTemplateInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot manage templates." });
        var outcome = await _templates.CreateAsync(input);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : StatusCode(201, outcome.Template);
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] MessageTemplateInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot manage templates." });
        var outcome = await _templates.UpdateAsync(id, input);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : Ok(outcome.Template);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot manage templates." });
        var outcome = await _templates.DeleteAsync(id);
        return outcome.Refusal is not null ? FromRefusal(outcome.Refusal) : NoContent();
    }
}

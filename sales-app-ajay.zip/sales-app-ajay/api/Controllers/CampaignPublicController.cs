using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SalesApi.ExperienceLayer.Campaigns;
using SalesApi.ProcessLayer.Campaigns;

namespace SalesApi.Controllers;

/// <summary>
/// E21 - the two PUBLIC doors of email campaigns, neither with a signed-in caller. Each proves itself before anything is read: the unsubscribe link by its signed
/// token, the SES feedback webhook by its SNS signature. Rate limited ("campaign-public"). Routes and picks status codes only; the rules are
/// <see cref="CampaignFeedbackProcess"/>.
/// </summary>
[ApiController]
[AllowAnonymous]
[EnableRateLimiting("campaign-public")]
public class CampaignPublicController : ControllerBase
{
    private readonly CampaignFeedbackExperience _feedback;
    public CampaignPublicController(CampaignFeedbackExperience feedback) => _feedback = feedback;

    // GET /unsubscribe/{token} - the confirm page (HTML). A mail client's link preview or a scanner fetching it changes nothing: only the POST opts anyone out.
    [HttpGet("unsubscribe/{token}")]
    public IActionResult UnsubscribePage(string token) =>
        Content(_feedback.ConfirmPage(token, $"/unsubscribe/{Uri.EscapeDataString(token)}"), "text/html");

    // POST /unsubscribe/{token} - the button, and the RFC 8058 one-click POST (body "List-Unsubscribe=One-Click"; the body is not needed). 200, or 400 for a bad token.
    [HttpPost("unsubscribe/{token}")]
    [IgnoreAntiforgeryToken]
    public async Task<IActionResult> Unsubscribe(string token, CancellationToken ct) =>
        await _feedback.UnsubscribeAsync(token, ct)
            ? Content(_feedback.DonePage(), "text/html")
            : new ContentResult { Content = _feedback.InvalidPage(), ContentType = "text/html", StatusCode = 400 };

    // POST /webhooks/ses - the SNS topic the SES configuration set's event destination publishes to. SNS posts JSON with content type text/plain, so the body is read
    // raw. 403 for a message that does not verify (nothing read from it), 400 for one that is not an SNS message, 200 otherwise (SNS retries anything else).
    [HttpPost("webhooks/ses")]
    public async Task<IActionResult> SesFeedback(CancellationToken ct)
    {
        using var reader = new StreamReader(Request.Body);
        var body = await reader.ReadToEndAsync(ct);
        return await _feedback.HandleSnsAsync(body, ct) switch
        {
            CampaignFeedbackProcess.SnsOutcome.Unverified => StatusCode(403),
            CampaignFeedbackProcess.SnsOutcome.Malformed => BadRequest(),
            _ => Ok(),
        };
    }
}

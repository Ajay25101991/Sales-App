using SalesApi.ExperienceLayer.Collections;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Collections;
using SalesApi.Services;
using SalesApi.SystemLayer.Collections;

namespace SalesApi.Controllers;

// Collections dashboard: outstanding vs overdue receivables + an aging
// breakdown. Scoped to the caller's own invoices, or the whole team for
// managers/admins (same rule as InvoicesController).
//
// MIGRATED to the layered API (step 8): this controller keeps routing,
// [Authorize]/[RequirePermission], the manager-only checks on the reminder
// endpoints, and status selection. Every business rule — the aging
// computation, the leaderboard and by-customer rollups, the reminder-config
// merge — lives in CollectionProcess.
[ApiController]
[Route("collections")]
[Authorize]
[RequirePermission(OrganizationPermissions.ViewFinancials)]
public class CollectionsController : ControllerBase
{
    private readonly CallerContext _caller;
    private readonly CollectionsExperience _collections;
    public CollectionsController(CallerContext caller, CollectionsExperience collections)
    {
        _caller = caller;
        _collections = collections;
    }

    // Money masking (invoice-money-masking, owner decision 2026-09-28): the
    // SAME permission InvoicesController.CanSeeInvoiceFinancials/
    // AccountsController.CanSeeFullAccountFinancials already gate on.
    private bool CanSeeFinancials =>
        User.HasPermission(OrganizationPermissions.ViewAccountFinancials);

    [HttpGet("dashboard")]
    public async Task<IActionResult> Dashboard()
    {
        var ctx = await _caller.ForAsync(User);
        return Ok(await _collections.DashboardAsync(ctx, DateTime.UtcNow, CanSeeFinancials));
    }

    // Shared AR aging + collected-cash computation, also read by GET
    // /reports/md-pack (the MD monthly pack) via this exact static method —
    // kept as a thin forwarding call so that call site (ReportsController) and
    // the tests exercising it directly (ReportingTimezoneBoundaryTests,
    // MdPackDsoTests) see byte-identical figures across the move to
    // CollectionProcess. Takes the access context rather than an owner id:
    // "whose receivables" is the team predicate, not one id or all of them.
    public static Task<CollectionsDto> ComputeAsync(AppDbContext db, RecordAccessContext ctx, DateTime fromCollected, DateTime toCollected) =>
        // Builds a PROCESS, not an Experience, and deliberately: this forwarder
        // serves ReportsController's MD pack, which is another server-side
        // caller rather than a screen. Experience shapes things for consumers;
        // a report reading receivables wants the business figure itself.
        new CollectionProcess(new CollectionStore(db), new ReportingCalendarService(db),
            new SalesApi.Services.PeopleScopeReader(db), new SalesApi.Services.CollectionReminderReader(db)).ComputeAsync(ctx, fromCollected, toCollected);

    // GET /collections/leaderboard — receivables per rep (manager=team, rep=self).
    [HttpGet("leaderboard")]
    public async Task<IActionResult> Leaderboard()
    {
        var ctx = await _caller.ForAsync(User);
        return Ok(await _collections.LeaderboardAsync(ctx, User.OrgId(), CanSeeFinancials));
    }

    // GET /collections/by-customer — receivables grouped by account. Invoices
    // with no AccountId are excluded — there's nothing to group them by, so
    // they stay visible only in the flat /invoices list.
    [HttpGet("by-customer")]
    public async Task<IActionResult> ByCustomer()
    {
        var ctx = await _caller.ForAsync(User);
        return Ok(await _collections.ByCustomerAsync(ctx, CanSeeFinancials));
    }

    // GET /collections/reminder-config — the auto payment-reminder schedule.
    // E13: read with financials.view (class gate) OR post_win.manage OR workflows.create; edit needs post_win.manage.
    [HttpGet("reminder-config")]
    [AlsoAllowPermission(OrganizationPermissions.ManagePostWin)]
    [AlsoAllowPermission(OrganizationPermissions.CreateWorkflows)] // workflow authors read the org setting to start an override (they cannot change it)
    public async Task<IActionResult> GetReminderConfig()
    {
        return Ok(await _collections.ReminderConfigAsync());
    }

    // PUT /collections/reminder-config — managers set the schedule.
    [HttpPut("reminder-config")]
    public async Task<IActionResult> SetReminderConfig([FromBody] CollectionReminderConfigInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManagePostWin)) return StatusCode(403, new { error = "Your role cannot change the after-the-win settings." });
        return Ok(await _collections.SetReminderConfigAsync(input));
    }

    // POST /collections/generate-reminders — run the generator now (managers).
    [HttpPost("generate-reminders")]
    public async Task<IActionResult> GenerateReminders()
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can trigger this." });
        return Ok(new { created = await _collections.GenerateRemindersAsync() });
    }
}

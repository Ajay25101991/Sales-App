using System.Globalization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Services;

namespace SalesApi.Controllers;

// The monthly management report: a dated HTML email of the month that just closed
// (owner decision §38 — no PDF, no attachment; the report IS the email body). The
// scheduled send lives in MonthlyReportService/MonthlyReportWorker; this controller
// is config plus a manual "send me mine now" action, mirroring DigestController.
[ApiController]
[Route("monthly-report")]
[Authorize]
public class MonthlyReportController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly CallerContext _caller;
    private readonly NotificationDispatcher _dispatcher;
    private readonly OrganizationRoleService _roles;

    public MonthlyReportController(AppDbContext db, CallerContext caller, NotificationDispatcher dispatcher, OrganizationRoleService roles)
    {
        _db = db;
        _caller = caller;
        _dispatcher = dispatcher;
        _roles = roles;
    }

    [HttpGet("config")]
    public async Task<IActionResult> GetConfig()
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can view this." });
        return Ok(await MonthlyReportService.GetConfigAsync(_db));
    }

    [HttpPut("config")]
    public async Task<IActionResult> SetConfig([FromBody] MonthlyReportConfigInput input)
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can change this." });
        var current = await MonthlyReportService.GetConfigAsync(_db);
        var saved = await MonthlyReportService.SaveConfigAsync(_db, new MonthlyReportConfigDto(
            input.Enabled ?? current.Enabled,
            input.DayOfMonth ?? current.DayOfMonth,
            input.Hour ?? current.Hour));
        return Ok(saved);
    }

    // POST /monthly-report/send — email the caller their own report for the most
    // recently completed calendar month, right now. Bypasses the day/hour gate and
    // the once-per-period guard (a manager pressing this is asking for delivery NOW,
    // same reasoning as POST /digest/send and POST /reminders/sweep) — but NOT the
    // recipient's own notification preferences or ViewLeadValues masking, which still
    // apply exactly as the scheduled send would: this goes through the same
    // MonthlyReportService.SendToAsync -> NotificationDispatcher path.
    [HttpPost("send")]
    public async Task<IActionResult> Send()
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "Only managers can request this." });

        var cal = await ReportingCalendar.ForAsync(_db);
        var (year, month) = ReportingCalendar.MonthOf(cal, DateTime.UtcNow);
        var reported = new DateOnly(year, month, 1).AddMonths(-1);
        var start = ReportingCalendar.StartOfMonthUtc(cal, reported.Year, reported.Month);
        var end = ReportingCalendar.EndOfMonthUtc(cal, reported.Year, reported.Month);
        // kind-safe: immediately formatted to a string, never bound or persisted.
        var monthLabel = reported.ToDateTime(TimeOnly.MinValue).ToString("MMMM yyyy", CultureInfo.InvariantCulture);
        var currency = await MoneyFormat.CurrencyAsync(_db);

        var people = await PeopleScope.VisibleIdsAsync(_db, await _caller.ForAsync(User));
        var figures = await MonthlyReportService.ComputeAsync(_db, people, start, end);
        await MonthlyReportService.SendToAsync(_db, _dispatcher, _roles, User.UserId(), User.Role(), monthLabel, figures, currency);
        return Ok(new { sent = true });
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Studio;
using SalesApi.ProcessLayer.Studio;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E7.4 implementation studio — access, assignments, org switching (design
/// doc to-do/e7-config-platform-design.md §5.1, §8 slice 13). Two audiences
/// share this controller: a suntech-admin grants/revokes engagements
/// (`admin/studio/...`), and an implementation user lists their own
/// engagements and switches into one (`studio/...`). Every write is audited
/// the ordinary way (the switch endpoints mint a token whose acting-org
/// writes carry the real user as actor — see FieldAudit/ActorContext — and
/// grant/revoke are themselves plain admin actions with no separate log to
/// forget).
/// </summary>
[ApiController]
[Authorize]
public class StudioController : ControllerBase
{
    private readonly StudioExperience _studio;
    public StudioController(StudioExperience studio) => _studio = studio;

    private IActionResult? RequirePlatformAdmin() =>
        User.IsSuntechAdmin() ? null : StatusCode(403, new { error = "Only an app administrator can do this." });

    private IActionResult Refused(StudioProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(refusal.ToDto()) : BadRequest(refusal.ToDto());

    // --- Platform-admin: grant / revoke (suntech-admin only) --------------

    /// <summary>POST /admin/studio/assignments — grant an implementation
    /// user access to one customer org.</summary>
    [HttpPost("admin/studio/assignments")]
    public async Task<IActionResult> Grant([FromBody] StudioGrantInput input)
    {
        if (RequirePlatformAdmin() is { } err) return err;
        if (input.ImplementationUserId is not Guid implUserId || input.OrgId is not Guid orgId)
            return BadRequest(new { error = "implementation_user_id and org_id are required." });

        var (result, refusal) = await _studio.GrantAsync(implUserId, orgId, User.UserId());
        return refusal is not null ? Refused(refusal) : StatusCode(201, result);
    }

    /// <summary>DELETE /admin/studio/assignments/{id} — revoke a grant.
    /// Takes effect on the implementation user's VERY NEXT request — see
    /// OrganizationPermissionMiddleware, which re-checks this on every one,
    /// never a cached answer.</summary>
    [HttpDelete("admin/studio/assignments/{id:guid}")]
    public async Task<IActionResult> Revoke(Guid id)
    {
        if (RequirePlatformAdmin() is { } err) return err;
        var (revoked, refusal) = await _studio.RevokeAsync(id, User.UserId());
        return refusal is not null ? Refused(refusal) : Ok(new { revoked });
    }

    /// <summary>GET /admin/studio/assignments — every grant ever made,
    /// newest first, revoked/expired included (their own `is_active` says
    /// which).</summary>
    [HttpGet("admin/studio/assignments")]
    public async Task<IActionResult> ListAssignments()
    {
        if (RequirePlatformAdmin() is { } err) return err;
        return Ok(await _studio.ListAssignmentsAsync());
    }

    /// <summary>GET /admin/studio/implementation-users — active profiles in
    /// the CALLER's own home org (platform staff), sorted by name, each with
    /// its current `is_implementation_user` flag.</summary>
    [HttpGet("admin/studio/implementation-users")]
    public async Task<IActionResult> ListImplementationUsers()
    {
        if (RequirePlatformAdmin() is { } err) return err;
        if (User.OrgId() is not Guid homeOrgId)
            return BadRequest(new { error = "Your account has no home organization configured." });
        return Ok(await _studio.ListImplementationUsersAsync(homeOrgId));
    }

    /// <summary>PUT /admin/studio/implementation-users/{profileId} — flips
    /// whether this platform-staff profile may be granted studio access.
    /// Refused for a profile outside the caller's own home org.</summary>
    [HttpPut("admin/studio/implementation-users/{profileId:guid}")]
    public async Task<IActionResult> SetImplementationUser(Guid profileId, [FromBody] StudioImplementationUserToggleInput input)
    {
        if (RequirePlatformAdmin() is { } err) return err;
        if (User.OrgId() is not Guid homeOrgId)
            return BadRequest(new { error = "Your account has no home organization configured." });

        var (result, refusal) = await _studio.SetImplementationUserFlagAsync(
            profileId, input.IsImplementationUser, homeOrgId, User.UserId());
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    // --- Implementation user: their own engagements + switching -----------
    //
    // Neither endpoint below re-checks Profile.IsImplementationUser at the
    // controller: the REAL gate is StudioProcess re-reading it fresh from
    // the database on every call (GrantAsync validated it at grant time;
    // SwitchToOrgAsync validates it again at switch time), which a
    // ClaimsPrincipal-level check here could only ever restate from a
    // possibly-stale token claim. A non-implementation-user calling these
    // simply finds they have no assignments / no active grant — an empty
    // list or a refusal, never a different code path to audit separately.

    /// <summary>GET /studio/orgs — this implementation user's own active
    /// assignments, for the org picker.</summary>
    [HttpGet("studio/orgs")]
    public async Task<IActionResult> MyOrgs()
    {
        return Ok(await _studio.AssignedOrgsAsync(User.UserId()));
    }

    /// <summary>POST /studio/switch/{orgId} — issues a scoped session for
    /// the target org (req 3). Refused unless the caller has an ACTIVE
    /// StudioAssignment for exactly this org.</summary>
    [HttpPost("studio/switch/{orgId:guid}")]
    public async Task<IActionResult> SwitchToOrg(Guid orgId)
    {
        var (result, refusal) = await _studio.SwitchToOrgAsync(User.UserId(), orgId);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    /// <summary>POST /studio/switch/home — returns to an ordinary session
    /// for the caller's own home org.</summary>
    [HttpPost("studio/switch/home")]
    public async Task<IActionResult> SwitchHome()
    {
        var (result, refusal) = await _studio.SwitchHomeAsync(User.UserId());
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    // --- Preview as role (slice 19, design doc §5.6) -------------------------
    //
    // "Org admins and switched implementation users" may preview — checked
    // here exactly as named, not re-derived: User.IsOrgAdmin() already reads
    // the CURRENT session's role (the caller's own, or an already-switched
    // impl session's org-admin-equivalent grant), and User.StudioKind() is
    // the same claim every other studio endpoint already trusts (re-verified
    // fresh every request by OrganizationPermissionMiddleware — see that
    // class's own comment). A caller already PREVIEWING as some other role
    // naturally fails this check too (IsOrgAdmin()/StudioKind() then read the
    // PREVIEWED role's own facts, not the real session's), which is exactly
    // "exit the preview before starting a different one" — no extra code
    // needed to enforce that.

    private IActionResult? RequirePreviewer() =>
        (User.IsOrgAdmin() || User.StudioKind() == StudioSessionKind.ImplementationUser)
            ? null
            : StatusCode(403, new { error = "Only an org admin or a switched implementation user can preview as a role." });

    /// <summary>POST /studio/preview/{roleKey} — starts a preview session IN
    /// THE CURRENT ORG (never a second org switch). Follow-up (2026-09-30,
    /// owner): when starting FROM a studio session (<c>User.StudioKind()</c>
    /// set), the current token's own real `exp` IS that studio session's end
    /// time (<c>JwtService.CreateStudioToken</c> never mints one any other
    /// way) — read here and carried into the preview token as `studio_exp`
    /// so <see cref="ExitPreview"/> can return to it unextended later.</summary>
    [HttpPost("studio/preview/{roleKey}")]
    public async Task<IActionResult> StartPreview(string roleKey)
    {
        if (RequirePreviewer() is { } err) return err;
        if (User.OrgId() is not Guid orgId)
            return BadRequest(new { error = "No organization to preview." });

        var (result, refusal) = await _studio.StartPreviewAsync(
            User.UserId(), orgId, User.StudioHomeOrgId(), User.StudioKind(), roleKey, User.TokenExpiresAt());
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    /// <summary>POST /studio/preview/exit — ends the preview session. Always
    /// reachable, including from inside a preview (StudioPreviewMiddleware
    /// carves out exactly this path) — otherwise a preview could never
    /// end. Passes <c>User.StudioExp()</c> (the ORIGINAL studio session's
    /// real end time, carried on the preview token) through so the studio
    /// token this mints never outlives it — see
    /// <c>StudioProcess.ExitPreviewAsync</c>'s own comment.</summary>
    [HttpPost("studio/preview/exit")]
    public async Task<IActionResult> ExitPreview()
    {
        if (User.OrgId() is not Guid orgId)
            return BadRequest(new { error = "No organization to return to." });

        var (result, refusal) = await _studio.ExitPreviewAsync(
            User.UserId(), orgId, User.StudioHomeOrgId(), User.StudioKind(), User.StudioExp());
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    /// <summary>GET /studio/preview/{roleKey}/capabilities — the plain-
    /// language capability list (mock: role picker banner), reachable before
    /// OR during a preview so the picker can show what a role can do before
    /// committing to it.</summary>
    [HttpGet("studio/preview/{roleKey}/capabilities")]
    public async Task<IActionResult> PreviewCapabilities(string roleKey)
    {
        if (RequirePreviewer() is { } err) return err;
        if (User.OrgId() is not Guid orgId)
            return BadRequest(new { error = "No organization to preview." });

        var (result, refusal) = await _studio.CapabilitiesAsync(orgId, roleKey);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }
}

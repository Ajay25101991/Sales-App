using System.Globalization;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Every analytics read, under one route prefix.
///
/// FULLY MIGRATED to the layered API (step 8). This controller routes, checks
/// permission, and picks a status code from what <see cref="ReportsExperience"/>
/// decides. The computations live in six Process classes behind it, split by
/// report rather than lumped together, because each is a body of figure
/// arithmetic where a mistake changes a NUMBER rather than failing a test:
/// ReportsProcess (the scope-and-shape reads), TrendsProcess, LeaderboardProcess,
/// MdPackProcess, ScorecardProcess and NeedsYouTodayProcess, plus MovementProcess
/// from the first slice.
///
/// TWO RULES survived the move and are documented where they now live, because
/// both are easy to undo by accident. Money figures are NULL for a caller
/// without lead_values.view, never 0 — a masked zero is a renderable currency
/// amount and reads as "closed nothing". And on the leaderboard, masking happens
/// after every figure is computed but before ranking reads them, or the medals
/// are handed out on an arbitrary order.
/// </summary>
[ApiController]
[Route("reports")]
[Authorize]
[RequirePermission(OrganizationPermissions.ViewReports)]
public class ReportsController : ControllerBase
{
    // The ONE remaining _db use, and a deliberate one: building the caller's
    // RecordAccessContext needs both the ClaimsPrincipal and the database, and a
    // System-layer service must not take a principal. AccountsController,
    // AttachmentsController and SettingsController keep the same residual for
    // the same reason.
    private readonly CallerContext _caller;
    private readonly SalesApi.ExperienceLayer.Reports.ReportsExperience _reports;
    public ReportsController(CallerContext caller, SalesApi.ExperienceLayer.Reports.ReportsExperience reports)
    {
        _caller = caller;
        _reports = reports;
    }

    // --- Team scoping -------------------------------------------------------
    //
    // Reports are keyed by PERSON, not by record: they read pre-aggregated
    // per-salesperson rows, so narrowing the records would do nothing. What
    // narrows them is the set of people whose rows may be read — see
    // Services/TeamScoping.cs's PeopleScope. `null` means no restriction (the org
    // admin), which is why every use below branches on `is not null` rather than
    // filtering by an empty list.
    private RecordAccessContext? _access;
    private async Task<RecordAccessContext> AccessAsync() =>
        _access ??= await _caller.ForAsync(User);

    /// <summary>Whether this caller may see money figures at all. Read once,
    /// named once: every report below passes it DOWN as data rather than each
    /// re-asking the principal, which is what lets the same computation serve a
    /// caller that is not an HTTP request.</summary>
    private bool ShowValues => User.HasPermission(OrganizationPermissions.ViewLeadValues);

    /// <summary>Same idea as <see cref="ShowValues"/>, for the invoice/AR
    /// money the MD pack's collections figures carry (invoice-money-masking,
    /// owner decision 2026-09-28) — the same permission InvoicesController/
    /// AccountsController/CollectionsController already gate their own
    /// figures on. ACCESS to the report is unchanged (still ViewFinancials +
    /// ViewLeadValues at :518); this only narrows which fields on it are real.</summary>
    private bool ShowFinancials => User.HasPermission(OrganizationPermissions.ViewAccountFinancials);

    // Same refusal TeamsController.CanAdminister / SettingsController.CanConfigureTeam
    // enforce for team writes, and GET /reports/leaderboard (:86) and
    // DashboardController.Get already enforce for their own team READ — pulled
    // out here so GET /reports/movement, /movement/lines and /movement/export
    // (three separate actions sharing one builder) don't restate it three times.
    // The team-less sentinel (AggregateOwner.Unassigned) is exempt: it names no
    // roster to be outside of.
    private async Task<IActionResult?> TeamAccessErrorAsync(Guid? teamId)
    {
        if (teamId is not { } tid || tid == AggregateOwner.Unassigned) return null;
        var access = await AccessAsync();
        if (access.IsOrgAdmin || access.Scope.Covers(tid)) return null;
        return StatusCode(403, new { error = "You do not have access to that team's figures." });
    }

    // E3.11d — same comma-separated multi-select convention LeadsController's
    // own `dealType` query param uses, and the same "null means no filter"
    // convention teamId already carries on this endpoint. Null, not an empty
    // list, when the param is absent — an empty-but-non-null list would read
    // as "match nothing" everywhere else a CSV filter in this codebase is
    // parsed.
    private static List<string>? ParseDealTypes(string? dealType) =>
        string.IsNullOrWhiteSpace(dealType)
            ? null
            : dealType.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();

    // Per-rep performance. Managers see the whole team; reps see only themselves.
    //
    // `teamId` (org-admin/manager team filter, 2026-08-27): the same
    // additional AND this endpoint's aggregate reads carry on the dashboard —
    // never a widening of `profiles`/`access`, which stays the security
    // boundary. See DashboardController.Get for the sentinel/"No team"
    // reasoning; identical here.
    //
    // `dealType` (E3.11d): a THIRD, independent narrowing alongside `teamId` —
    // see MeasureScope's own comment on why this filter reads live rather than
    // from a stored grain. Absent, every existing caller's response is
    // unchanged (LeaderboardProcess only branches on it when set).
    [HttpGet("leaderboard")]
    public async Task<IActionResult> Leaderboard(
        [FromQuery] string period = "all", [FromQuery] Guid? teamId = null, [FromQuery] string? dealType = null)
    {
        // SECURITY: same refusal TeamsController.CanAdminister /
        // SettingsController.CanConfigureTeam already enforce for team writes —
        // reused here for a team READ. Stays at the endpoint because it is a
        // question about the CALLER, not about the figures.
        if (await TeamAccessErrorAsync(teamId) is { } err) return err;
        return Ok(await _reports.LeaderboardAsync(await AccessAsync(), User.OrgId(), ShowValues, period, teamId, ParseDealTypes(dealType)));
    }

    // GET /reports/leaderboard/export?period= — the same rows as GET
    // /reports/leaderboard, as CSV, honoring the same period filter and
    // manager/rep scoping. Declared as its own literal route (not a query
    // param on the JSON endpoint) so it can carry its own permission gate,
    // matching the GET /leads/export precedent.
    [HttpGet("leaderboard/export")]
    [RequirePermission(OrganizationPermissions.CreateExports)]
    public async Task<IActionResult> LeaderboardExport(
        [FromQuery] string period = "all", [FromQuery] Guid? teamId = null, [FromQuery] string? dealType = null)
    {
        // `teamId` was once dropped here: filtering the JSON leaderboard to a
        // team and then exporting silently produced a CSV of EVERY team. It is
        // threaded through, and the same team refusal is enforced first — asked
        // directly now rather than by calling the sibling action and unwrapping
        // whatever IActionResult came back. `dealType` (E3.11d) follows it for
        // the same reason.
        if (await TeamAccessErrorAsync(teamId) is { } err) return err;

        // This route is gated on exports.create, NOT on lead_values.view — so
        // the underlying export drops the open_value/won_value COLUMNS instead
        // of zeroing them: downstream, in a spreadsheet, a masked zero and a
        // real zero are the same character. Extracted onto LeaderboardProcess
        // (E3.10) so the scheduled-delivery worker sends the identical file
        // this endpoint does, rather than a second CSV shape.
        var csv = await _reports.LeaderboardCsvAsync(await AccessAsync(), User.OrgId(), ShowValues, period, teamId, ParseDealTypes(dealType));
        return Content(csv, "text/csv; charset=utf-8");
    }

    // GET /reports/trends — the analytics page's time series, mix and funnels.
    // Computed by TrendsProcess; see there for the bucket-edge and masking rules.
    [HttpGet("trends")]
    public async Task<IActionResult> Trends([FromQuery] string granularity = "month") =>
        Ok(await _reports.TrendsAsync(
            await AccessAsync(), ShowValues,
            User.HasPermission(OrganizationPermissions.ViewFinancials), granularity));

    // GET /reports/win-loss?period=week|month|all — won/lost totals + breakdown
    // by close reason (managers: whole team; reps: their own).
    //
    // `period` means exactly what it means on GET /reports/leaderboard (:87):
    // "week" and "month" are the ROLLING 7- and 30-day windows anchored on today
    // UTC and inclusive of it — the same [end-(n-1), end] bucket span
    // DealStatsService.RecomputeRollingAsync builds — and anything else is
    // all-time. Reusing that reading rather than inventing calendar weeks is the
    // whole point: this panel sits beside the leaderboard table on one screen,
    // and a lifetime rail next to a weekly table is what made them disagree
    // (2 wins in the table, 15 on the rail).
    //
    // The default stays all-time, so every existing caller keeps the figure it
    // has today.
    //
    // `teamId` means what it means on GET /reports/leaderboard (:92), for the
    // same reason the `period` note above gives: this rail sits BESIDE that
    // table on one screen, and a rail that ignores the picker driving the table
    // is the disagreement this endpoint has already been fixed for once.
    [HttpGet("win-loss")]
    public async Task<IActionResult> WinLoss(
        [FromQuery] string period = "all", [FromQuery] Guid? teamId = null)
    {
        if (await TeamAccessErrorAsync(teamId) is { } err) return err;
        return Ok(await _reports.WinLossAsync(await AccessAsync(), ShowValues, period, teamId));
    }

    // GET /reports/forecast-snapshots — owner decision §22: the forecast
    // accuracy page reads stored snapshots, never a retrospective
    // reconstruction. Empty until ForecastSnapshotWorker has captured at least
    // one period; every row it returns is a period somebody's pipeline
    // actually predicted, joined against MonthlyDealStatsOrg's own WonValue for
    // the same period once it has closed (the SAME stored monthly figure every
    // other monthly report reads — never a second "actual" computation).
    [HttpGet("forecast-snapshots")]
    public async Task<IActionResult> ForecastSnapshots() =>
        Ok(await _reports.ForecastSnapshotsAsync(ShowValues));

    // GET /reports/compare — a governed measure over a period AND its prior
    // equivalent period (owner decision §34). The comparison BASIS is a
    // reader-chosen control, not a hidden assumption: `basis=trailing_window`
    // (the default — the only reading well-defined for an arbitrary range) or
    // `basis=same_period_last_year`. The chosen basis and its label travel back
    // on every response, so a client rendering a delta badge can always show
    // which comparison produced it rather than assuming one silently.
    //
    // This is deliberately thin: it resolves ONE governed measure
    // (MeasureRegistry) over two MeasureScope windows and returns both figures
    // — the arithmetic a KPI tile's delta badge needs, without a parallel
    // definition of what the measure means. `owner_id` narrows to one caller-
    // visible owner; omitted, the caller's own people-scope applies (a rep
    // sees their own figures, a manager the team's), exactly like every other
    // report in this controller.
    [HttpGet("compare")]
    public async Task<IActionResult> Compare(
        [FromQuery] string measure, [FromQuery] DateTime start, [FromQuery] DateTime end,
        [FromQuery] string? basis, [FromQuery] Guid? owner_id)
    {
        var (refusal, dto) = await _reports.CompareAsync(
            await AccessAsync(), ShowValues, measure, start, end, basis, owner_id);
        if (refusal is null) return Ok(dto);
        // An unknown measure key names nothing (404); an owner outside the
        // caller's scope is a refusal to answer (403). Two different answers,
        // which is why the refusal carries a flag rather than one message.
        return refusal.UnknownMeasure ? NotFound(refusal.Reason)
            : refusal.Forbidden ? Forbid()
            : BadRequest(new { error = refusal.Reason });
    }

    // GET /reports/explore/catalogue — every measure and dimension the Explore
    // builder may offer. The client's dropdowns MUST be built from this, never
    // a hand-written list — the binding rule this whole file's tests exist to
    // enforce (ExploreDimensionsAreBoundTests reads the source proving each
    // one actually resolves; this endpoint is what stops a client from
    // hand-copying the registry and drifting from it).
    [HttpGet("explore/catalogue")]
    public IActionResult ExploreCatalogue() => Ok(_reports.ExploreCatalogue());

    // GET /reports/explore — ad-hoc composition over the governed measure/
    // dimension registry (owner decision §28). `measures` and the CSV filter
    // params are comma-separated; `group_by` is required, `split_by` optional
    // (the frame's "Split by" — a second dimension, e.g. owner × stage);
    // `grain` (day|month|quarter) is required when either is `period`.
    [HttpGet("explore")]
    public async Task<IActionResult> Explore(
        [FromQuery] string measures,
        [FromQuery(Name = "group_by")] string groupBy,
        [FromQuery(Name = "split_by")] string? splitBy,
        [FromQuery] string? grain,
        [FromQuery] DateTime? start,
        [FromQuery] DateTime? end,
        [FromQuery] string? owners,
        [FromQuery] string? sources,
        [FromQuery] string? stages,
        [FromQuery] string? teams,
        [FromQuery(Name = "deal_types")] string? dealTypes,
        CancellationToken ct)
    {
        var (refusal, dto) = await _reports.ExploreAsync(
            await AccessAsync(), measures, groupBy, splitBy, grain, start, end, owners, sources, stages, teams, dealTypes, ct);
        if (refusal is null) return Ok(dto);
        // 422, not 400, when a GUARDRAIL refused: the query is well-formed and
        // Explore is choosing not to run it — the guardrail brief's "refuse it
        // with a message that explains itself", never a spinner that never
        // resolves. A malformed query is still a 400.
        return refusal.Refused
            ? UnprocessableEntity(new { error = refusal.Reason })
            : BadRequest(new { error = refusal.Reason });
    }

    // GET /reports/activity-effort — Analytics tab 4 ("Sources and effort"):
    // "activities per won deal" and "touches before close against value won".
    // Computed by ReportsProcess; see there for why Points is the one piece with
    // no stored fact to hit.
    [HttpGet("activity-effort")]
    public async Task<IActionResult> ActivityEffort([FromQuery] DateTime? start, [FromQuery] DateTime? end)
    {
        var (refusal, dto) = await _reports.ActivityEffortAsync(await AccessAsync(), ShowValues, start, end);
        return refusal is not null ? BadRequest(new { error = refusal }) : Ok(dto);
    }

    // GET /reports/cohorts — leads grouped by the MONTH THEY WERE CREATED,
    // followed forward to see what share of each cohort has reached Won by a
    // given age. Reads the fact table for an unrestricted caller and falls back
    // to a live scan for a restricted one — see ReportsProcess.CohortsAsync for
    // why the fact cannot answer the restricted case.
    [HttpGet("cohorts")]
    public async Task<IActionResult> Cohorts([FromQuery] int months = 6, [FromQuery] int maxAgeMonths = 6) =>
        Ok(await _reports.CohortsAsync(await AccessAsync(), months, maxAgeMonths));

    // GET /reports/activity — calls+meetings logged this week per rep vs the
    // quota (managers: whole team; reps: their own).
    [HttpGet("activity")]
    public async Task<IActionResult> Activity() =>
        Ok(await _reports.ActivityAsync(await AccessAsync(), User.OrgId()));

    // GET /reports/feed — unified recent activity across leads + invoices
    // (managers: whole team; reps: their own authored activity).
    [HttpGet("feed")]
    public async Task<IActionResult> Feed() => Ok(await _reports.FeedAsync(await AccessAsync()));

    /// <summary>The one place a rep-report refusal becomes a status code.</summary>
    private IActionResult RepRefused(SalesApi.ProcessLayer.Reports.ReportsProcess.RepRefusal refusal) =>
        refusal.NotFound
            ? NotFound(new { error = "Salesperson not found" })
            : StatusCode(403, new { error = "Not allowed to view this report" });

    // Detailed breakdown for one salesperson (managers: anyone; reps: only self).
    [HttpGet("rep/{id:guid}")]
    public async Task<IActionResult> Rep(Guid id)
    {
        var (refusal, dto) = await _reports.RepAsync(await AccessAsync(), User.OrgId(), ShowValues, id);
        return refusal is not null ? RepRefused(refusal) : Ok(dto);
    }

    // GET /reports/rep/{id}/export — the salesperson's own leads (one row per
    // lead, not the aggregated byStatus/bySource/recentWon buckets shown on
    // screen) as CSV. Same authorization as GET /reports/rep/{id}: managers
    // may export anyone on the org, reps only themselves.
    [HttpGet("rep/{id:guid}/export")]
    [RequirePermission(OrganizationPermissions.CreateExports)]
    public async Task<IActionResult> RepExport(Guid id)
    {
        var (refusal, csv) = await _reports.RepExportCsvAsync(await AccessAsync(), User.OrgId(), ShowValues, id);
        return refusal is not null ? RepRefused(refusal) : Content(csv!, "text/csv; charset=utf-8");
    }

    // GET /reports/stage-performance?days=90 — per-stage entered / moved on /
    // dwell time for the org's own open stages, for the admin about to reshape
    // the pipeline. Keyed on STAGE, never on owner — see
    // ReportsProcess.StagePerformanceAsync for why dimensioning it per person
    // was wrong and why scoping the input set still is not.
    [HttpGet("stage-performance")]
    public async Task<IActionResult> StagePerformance([FromQuery] int days = 90) =>
        Ok(await _reports.StagePerformanceAsync(await AccessAsync(), User.OrgId(), days));

    // The number of lines GET /reports/movement embeds per rep before the
    // caller has to ask for more (GET /reports/movement/lines). Matches
    // movement.tsx's own fetch-10-show-5 model (see RepCard's VISIBLE_LINES) —
    // the two are not wired together, so a change to one is a change to both,
    // same as VISIBLE_LINES itself already wasn't derived from anything server
    // side.
    private const int MovementLinesPageSize = 10;

    // GET /reports/movement?from=&to=&owner_id= — "what changed since last
    // Monday": deals that entered the pipeline, advanced, slipped backward, or
    // went quiet in the window, grouped by rep. Reps only ever see their own;
    // managers see the team and may filter to one rep via owner_id.
    //
    // Built entirely from lead_stage_events (see LeadStageEvent / B1), so it is
    // necessarily thin until that table has accumulated history — an empty or
    // near-empty result for a window before this shipped is expected, not a bug.
    //
    // Each rep's `Lines` is capped to MovementLinesPageSize here — this
    // endpoint used to return every line for every person unbounded, which was
    // the page's actual slowness (a busy week's card could carry hundreds of
    // rows the UI was already collapsing behind "Show N more"). `LineCount` on
    // the DTO carries the TRUE total so the client's disclosure control still
    // knows how much is hidden; rows past the first page come from GET
    // /reports/movement/lines. The header totals (open/won value, lead_count)
    // are untouched — BuildMovementReportAsync computes them from
    // PipelineStats/DailyDealStats, never from the `Lines` list, so capping it
    // here cannot touch them.
    [HttpGet("movement")]
    public async Task<IActionResult> Movement(
        [FromQuery] DateTime? from, [FromQuery] DateTime? to, [FromQuery] Guid? owner_id, [FromQuery] Guid? teamId = null)
    {
        if (await TeamAccessErrorAsync(teamId) is { } err) return err;
        var full = await _reports.MovementAsync(await AccessAsync(), User.OrgId(), ShowValues, from, to, owner_id, teamId);
        var paged = full.Reps.Select(r => r with
        {
            Lines = r.Lines.Take(MovementLinesPageSize).ToList(),
            LineCount = r.Lines.Count,
        }).ToList();
        return Ok(full with { Reps = paged });
    }

    // GET /reports/movement/lines?from=&to=&owner_id=&offset= — one rep's next
    // page of movement lines, past whatever GET /reports/movement already
    // embedded for them. `owner_id` is REQUIRED here (unlike the main report,
    // where it narrows an otherwise multi-person response) — this is always a
    // follow-up for one already-rendered card, never a first load.
    //
    // Re-runs the full, unscoped builder rather than adding a second
    // owner-filtered query path: BuildMovementReportAsync's scoping
    // (PeopleAsync, the routing-queue's AggregateOwner.Unassigned bucket) is
    // exactly the logic that decides who is even allowed to see `owner_id`'s
    // group, and re-deriving it here would risk the two drifting apart. The
    // group is found by matching OwnerId against the CALLER's own scoped
    // Reps list, not by trusting owner_id directly — a rep who is not a
    // manager only ever gets their own group back from PeopleAsync, so
    // requesting someone else's owner_id simply finds nothing (404), the same
    // as the main report already enforces. This is one extra full report
    // computation per "load more" click past the first ten rows, which is
    // deliberately not optimized — that click is rare, and duplicating the
    // scoping logic to shave it is the more expensive thing.
    [HttpGet("movement/lines")]
    public async Task<IActionResult> MovementLines(
        [FromQuery] DateTime? from, [FromQuery] DateTime? to,
        [FromQuery] Guid owner_id, [FromQuery] int offset = 0, [FromQuery] Guid? teamId = null)
    {
        if (offset < 0) return BadRequest(new { error = "offset must not be negative" });
        if (await TeamAccessErrorAsync(teamId) is { } err) return err;
        var full = await _reports.MovementAsync(await AccessAsync(), User.OrgId(), ShowValues, from, to, ownerId: null, teamId);
        var group = full.Reps.FirstOrDefault(r => r.OwnerId == owner_id);
        if (group is null) return NotFound();
        var page = group.Lines.Skip(offset).Take(MovementLinesPageSize).ToList();
        var hasMore = offset + page.Count < group.Lines.Count;
        return Ok(new MovementLinesPageDto(page, hasMore));
    }


    // GET /reports/movement/export?from=&to=&owner_id= — every line across
    // every rep group, as CSV — deliberately UNBOUNDED, unlike GET
    // /reports/movement. Calls BuildMovementReportAsync directly rather than
    // the JSON action (which now caps each rep to MovementLinesPageSize) —
    // routing this through Movement() the way it used to would silently
    // truncate the export to the same per-rep page, which is a wrong file, not
    // a slow one. Same scoping as GET /reports/movement: reps only ever see
    // their own; managers see the team and may filter to one rep via
    // owner_id. The per-rep header totals (open/won value, lead_count) are
    // not row-shaped like the lines are, so they are left out rather than
    // repeated on every line or given their own mismatched row.
    [HttpGet("movement/export")]
    [RequirePermission(OrganizationPermissions.CreateExports)]
    public async Task<IActionResult> MovementExport(
        [FromQuery] DateTime? from, [FromQuery] DateTime? to, [FromQuery] Guid? owner_id, [FromQuery] Guid? teamId = null)
    {
        if (await TeamAccessErrorAsync(teamId) is { } err) return err;
        var report = await _reports.MovementAsync(await AccessAsync(), User.OrgId(), ShowValues, from, to, owner_id, teamId);

        var csvRows = new List<IEnumerable<string?>>
        {
            new[]
            {
                "owner_name", "lead_name", "company", "value", "kind",
                "from_status", "to_status", "at", "days_in_prior_state", "is_backfilled",
            },
        };
        csvRows.AddRange(report.Reps.SelectMany(rep => rep.Lines.Select(l => new string?[]
        {
            rep.OwnerName,
            l.LeadName,
            l.Company,
            l.Value?.ToString(CultureInfo.InvariantCulture),
            l.Kind,
            l.FromLabel ?? l.FromStatus,
            l.ToLabel ?? l.ToStatus,
            l.At.ToUniversalTime().ToString("o"),
            l.DaysInPriorState.ToString(CultureInfo.InvariantCulture),
            l.IsBackfilled.ToString(),
        })));
        return Content(CsvUtil.ToCsv(csvRows), "text/csv; charset=utf-8");
    }

    // GET /reports/leads-added?from=&to= — how many leads each salesperson
    // added, in an optional date window (defaults to all time). Reps see only
    // their own count; managers see the whole team.
    //
    // Keyed on Lead.CreatedById, NOT Lead.OwnerId. It used to group by owner —
    // with a comment claiming "no new storage needed" — and Lead carried no
    // creator field at all, so the report answered a different question from the
    // one on its label: "leads created in this window that this person currently
    // OWNS". Those diverge whenever a manager creates and assigns, whenever
    // routing hands a lead to someone, and, worst, whenever a lead is REASSIGNED
    // — which moved a closed period's figure retroactively. See
    // to-do/numbers-audit-decisions.md, "Leads added cannot answer its own
    // question".
    //
    // The `OwnerId != null` filter that used to sit on this query is GONE, and
    // its removal is not the C6 "count the queue" change — it is a correctness
    // one. Ownership is now irrelevant to this figure: a lead Priya created and
    // then handed over is still Priya's addition, and one that has since fallen
    // back into the routing queue is too. Keeping the filter would have made
    // UNASSIGNING a lead erase its creator's credit — reintroducing, through the
    // back door, exactly the retroactive movement this change removes.
    [HttpGet("leads-added")]
    public async Task<IActionResult> LeadsAdded([FromQuery] DateTime? from, [FromQuery] DateTime? to) =>
        Ok(await _reports.LeadsAddedAsync(await AccessAsync(), User.OrgId(), from, to));

    // GET /reports/leads-added/export?from=&to= — the same per-rep counts as
    // GET /reports/leads-added, as CSV, honoring the same date window and
    // manager/rep scoping. The unattributed row exports like any other: omitting
    // it would make the file fail to sum to the screen it came from.
    [HttpGet("leads-added/export")]
    [RequirePermission(OrganizationPermissions.CreateExports)]
    public async Task<IActionResult> LeadsAddedExport([FromQuery] DateTime? from, [FromQuery] DateTime? to) =>
        Content(await _reports.LeadsAddedCsvAsync(await AccessAsync(), User.OrgId(), from, to), "text/csv; charset=utf-8");

    // GET /reports/quotes?period=week|month|all — quote conversion: how many
    // quotes went out, what they totalled, how many came back yes, and how long
    // a decision took.
    //
    // NOTE the vocabulary trap (M6): "week"/"month" here are CALENDAR
    // week-to-date and month-to-date, while the same two words on
    // /reports/leaderboard and /reports/win-loss mean the ROLLING 7 and 30 days.
    // Both readings are wanted and both are kept; each card on the reports
    // screen states its own window so the two are never silently compared.
    [HttpGet("quotes")]
    public async Task<IActionResult> Quotes([FromQuery] string period = "all") =>
        Ok(await _reports.QuotesAsync(await AccessAsync(), User.OrgId(), ShowValues, period));

    // GET /reports/pipeline-coverage — of OPEN pipeline, what share of value and
    // of count carries a rep-entered ExpectedCloseDate. A coverage measure, not
    // a forecast. See ReportsProcess for why the routing queue lands in the
    // org roll-up but in no rep's row.
    //
    // `teamId` scopes both halves — the rep rows AND the queue in the roll-up.
    // See ReportsProcess.PipelineCoverageAsync for why leaving the queue
    // unfiltered would drag one team's coverage percentage down with the whole
    // org's unowned pipeline.
    [HttpGet("pipeline-coverage")]
    public async Task<IActionResult> PipelineCoverage([FromQuery] Guid? teamId = null)
    {
        if (await TeamAccessErrorAsync(teamId) is { } err) return err;
        return Ok(await _reports.PipelineCoverageAsync(
            await AccessAsync(), User.OrgId(), ShowValues, teamId));
    }

    // GET /reports/md-pack?period=yyyy-MM — the "MD monthly pack" for a board
    // meeting. Manager-only, and gated on the same permissions as the screens it
    // summarizes. Every figure comes from the same code the underlying screen
    // uses — see MdPackProcess, which documents which method each one reuses.
    [HttpGet("md-pack")]
    [RequirePermission(OrganizationPermissions.ViewFinancials)]
    [RequirePermission(OrganizationPermissions.ViewLeadValues)]
    public async Task<IActionResult> MdPack([FromQuery] string? period)
    {
        if (!User.IsManager()) return StatusCode(403, new { error = "The MD pack is manager-only." });

        var (refusal, dto) = await _reports.MdPackAsync(await AccessAsync(), User.OrgId(), period, ShowFinancials);
        return refusal is not null ? BadRequest(new { error = refusal }) : Ok(dto);
    }

    /// <summary>The one place a scorecard refusal becomes a status code.</summary>
    private IActionResult ScorecardRefused(SalesApi.ProcessLayer.Reports.ScorecardProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = "Salesperson not found" })
        : refusal.BadPeriod ? BadRequest(new { error = "period must be yyyy-MM" })
        : StatusCode(403, new { error = "Not allowed to view this scorecard" });

    // GET /reports/scorecard?period=yyyy-MM&user_id= — the rep self-scorecard: a
    // private monthly view of one rep's own numbers, meant to be read before a
    // 1:1. No id param defaults to the caller; passing user_id for anyone else is
    // 403 unless the caller is a manager — mirrors GET /reports/rep/{id}.
    //
    // See ScorecardProcess for which existing definition each figure reuses, and
    // for why the team comparison is one median rather than a per-rep breakdown.
    [HttpGet("scorecard")]
    public async Task<IActionResult> Scorecard([FromQuery] string? period, [FromQuery] Guid? user_id)
    {
        var (refusal, dto) = await _reports.ScorecardAsync(
            await AccessAsync(), User.UserId(), User.OrgId(), ShowValues, period, user_id);
        return refusal is not null ? ScorecardRefused(refusal) : Ok(dto);
    }

    // GET /reports/scorecard/export — the same scorecard as CSV. It used to call
    // the JSON action and unwrap its OkObjectResult, inheriting that action's
    // refusals by accident of the cast; it asks the same Process method now, so
    // neither can widen what the other refused.
    [HttpGet("scorecard/export")]
    [RequirePermission(OrganizationPermissions.CreateExports)]
    public async Task<IActionResult> ScorecardExport([FromQuery] string? period, [FromQuery] Guid? user_id)
    {
        var (refusal, csv) = await _reports.ScorecardCsvAsync(
            await AccessAsync(), User.UserId(), User.OrgId(), ShowValues, period, user_id);
        return refusal is not null ? ScorecardRefused(refusal) : Content(csv!, "text/csv; charset=utf-8");
    }


    // GET /reports/needs-you-today — a prioritised action list, NOT a report:
    // deals that slipped or went quiet, overdue follow-ups, broken payment
    // promises, at-risk AMC renewals, and approvals waiting on this user's
    // decision. Reps see only their own actionable items; managers see the whole
    // team's. See NeedsYouTodayProcess for the section gates and why the risk
    // score is computed server-side over the uncapped collections.
    //
    // `teamId` scopes every section, because every section reaches a lead. See
    // NeedsYouTodayProcess for what a team filter means for an AMC whose lead is
    // null, which is the one case that needed a decision rather than a filter.
    [HttpGet("needs-you-today")]
    public async Task<IActionResult> NeedsYouToday([FromQuery] Guid? teamId = null)
    {
        if (await TeamAccessErrorAsync(teamId) is { } err) return err;
        return Ok(await _reports.NeedsYouTodayAsync(
            await AccessAsync(), User.OrgId(),
            showMoney: User.HasPermission(OrganizationPermissions.ViewFinancials),
            canDecideApprovals: User.HasPermission(OrganizationPermissions.DecideApprovals),
            teamId: teamId));
    }

    // GET /reports/estimated-vs-closed?from=&to=&team_id=&owner_id=&only_different=&cursor=&limit=
    // Won/sold leads whose reported CLOSED value (ClosedValue, or
    // EstimatedValue when it was never overridden) no longer matches what the
    // pipeline ESTIMATED — newest win first, keyset-paged.
    //
    // GATED HARD on lead_values.view, unlike every other report on this
    // controller: those mask money to null and still render a page; this
    // report's entire subject IS the money, so there is no reduced reading to
    // fall back to, and a caller without the permission gets a 403 with a plain
    // message instead of an empty/zeroed screen that would look like "nothing
    // to see" rather than "not allowed to see it".
    //
    // `team_id`/`owner_id` narrow the same way they do on every other report
    // here (team_id: TeamAccessErrorAsync below; owner_id: a plain AND on top
    // of this caller's own WhereViewable record scope, so asking for someone
    // outside that scope simply returns nothing — no separate 403 needed,
    // matching ReportsStore.ClosedLeadsAsync's own ForTeam+WhereViewable shape).
    [HttpGet("estimated-vs-closed")]
    [RequirePermission(OrganizationPermissions.ViewLeadValues)]
    public async Task<IActionResult> EstimatedVsClosed(
        [FromQuery] DateOnly? from, [FromQuery] DateOnly? to,
        [FromQuery] Guid? team_id, [FromQuery] Guid? owner_id,
        [FromQuery] bool only_different = true, [FromQuery] string? cursor = null, [FromQuery] int? limit = null,
        CancellationToken ct = default)
    {
        if (await TeamAccessErrorAsync(team_id) is { } err) return err;
        return Ok(await _reports.EstimatedVsClosedAsync(
            await AccessAsync(), team_id, owner_id, from, to, only_different, cursor, limit, ct));
    }
}

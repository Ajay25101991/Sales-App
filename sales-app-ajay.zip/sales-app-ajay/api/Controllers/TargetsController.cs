using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ExperienceLayer.Goals;
using SalesApi.ProcessLayer.Goals;
using SalesApi.Services;
using SalesApi.SystemLayer.Goals;

namespace SalesApi.Controllers;

[ApiController]
[Route("targets")]
[Authorize]
[RequirePermission(OrganizationPermissions.ViewLeadValues)]
public class TargetsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly CallerContext _caller;
    // The goals vertical's Experience layer. Every endpoint below now goes
    // through it; `_db` remains only for scoping reads (which people/period
    // this caller may see — an authorization question, resolved here from the
    // ClaimsPrincipal and handed down as data) and CurrentPeriodAsync, which
    // ReportsController also calls as a static.
    private readonly GoalsExperience _goals;
    public TargetsController(AppDbContext db, CallerContext caller, GoalsExperience goals)
    {
        _db = db;
        _caller = caller;
        _goals = goals;
    }

    // The period key for "this month" — the ORG's month, not UTC's. At UTC+4 the
    // last four hours of the 31st are already the 1st locally, and a target set
    // for the new month was being read a day early (or, symmetrically, the old
    // month's target kept being read after the new month had begun).
    public static string CurrentPeriod(CalendarDto cal) => ReportingCalendar.CurrentPeriod(cal);

    public static async Task<string> CurrentPeriodAsync(AppDbContext db) =>
        CurrentPeriod(await ReportingCalendar.ForAsync(db));
    private static bool ValidPeriod(string p) => Regex.IsMatch(p, @"^\d{4}-\d{2}$");

    // GET /targets?period=yyyy-MM — target + attainment per rep for the period.
    // Managers see everyone; reps see only their own.
    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] string? period)
    {
        period ??= await CurrentPeriodAsync(_db);
        if (!ValidPeriod(period)) return BadRequest(new { error = "period must be yyyy-MM" });

        // Team scoping: a manager's "everyone" is now their teams' people. This
        // is an authorization fact (needs the ClaimsPrincipal), so it is
        // resolved HERE and handed to Experience as data — same split every
        // other migrated domain uses.
        var people = await PeopleScope.VisibleIdsAsync(_db, await _caller.ForAsync(User));
        return Ok(await _goals.ComputeAsync(period, User.OrgId(), people));
    }

    // Shared bookings-vs-target computation: target + won value (closed-won,
    // dated by WonAt falling back to UpdatedAt for legacy rows) per rep for a
    // "yyyy-MM" period. Extracted so GET /targets and GET /reports/md-pack
    // (the MD monthly pack) read the identical figure for "bookings" /
    // "closed-won value" instead of two queries that could silently drift.
    //
    // MIGRATED (step 8, goals backfill): the computation itself now lives in
    // SalesApi.SystemApi/Goals/GoalStore.cs (GoalStore.ComputeManyAsync). It
    // stayed a STORE method rather than moving into GoalProcess because
    // ReportsController — a controller outside this domain, not touchable here
    // — calls this exact static with an already-loaded `List<Profile>`, and
    // Process's public surface may not name that System entity
    // (SalesApi.Tests/LayerBoundaryTests.cs). Keeping one copy of the
    // computation on the store, reached by both this static wrapper (unchanged
    // signature, so ReportsController needed zero edits) and by
    // GoalProcess.ComputeManyAsync (which resolves profiles from ids for this
    // controller's own endpoints), was the only shape that avoided a duplicate.
    public static async Task<List<TargetProgressDto>> ComputeAsync(AppDbContext db, string period, List<Profile> profiles)
        => (await ComputeManyAsync(db, new[] { period }, profiles))[period];

    // The same computation across several periods on ONE pass of the data —
    // see ComputeAsync's comment for why this delegates to GoalStore rather
    // than GoalProcess.
    public static Task<Dictionary<string, List<TargetProgressDto>>> ComputeManyAsync(
        AppDbContext db, IReadOnlyCollection<string> periods, List<Profile> profiles) =>
        new GoalStore(db).ComputeManyAsync(periods, profiles);

    // GET /targets/history?period=yyyy-MM&months=6 — the same per-rep rows GET
    // /targets returns, for the `months` periods ENDING at `period` (oldest
    // first). Same scoping: managers see their teams, reps see themselves.
    // One request rather than six, because six calls to GET /targets would be
    // six identical scans of every sold lead — see GoalStore.ComputeManyAsync.
    [HttpGet("history")]
    public async Task<IActionResult> History([FromQuery] string? period, [FromQuery] int months = 6)
    {
        period ??= await CurrentPeriodAsync(_db);
        if (!ValidPeriod(period)) return BadRequest(new { error = "period must be yyyy-MM" });

        var people = await PeopleScope.VisibleIdsAsync(_db, await _caller.ForAsync(User));
        // Bounds-clamping and the period-list expansion both live in
        // GoalProcess.HistoryAsync now — "months" is request shape, but the
        // clamp is a rule a non-HTTP caller should get too.
        return Ok(await _goals.HistoryAsync(period, months, User.OrgId(), people));
    }

    // GET /targets/total?period=yyyy-MM — the team total for the period, over
    // the SAME rep scope GET /targets returns (managers: their team; reps:
    // themselves). Sums the identical TargetProgressDto rows GET /targets
    // computes rather than a second query, so a client can never render a
    // team total that disagrees with the rows it was built from.
    [HttpGet("total")]
    public async Task<IActionResult> Total([FromQuery] string? period)
    {
        period ??= await CurrentPeriodAsync(_db);
        if (!ValidPeriod(period)) return BadRequest(new { error = "period must be yyyy-MM" });

        var people = await PeopleScope.VisibleIdsAsync(_db, await _caller.ForAsync(User));
        return Ok(await _goals.TotalAsync(period, User.OrgId(), people));
    }

    // PUT /targets — set a rep's target for a period. Gated on goals.manage
    // (replaces the old bare User.IsManager() check — see OrganizationPermissions.ManageGoals).
    [HttpPut]
    [RequirePermission(OrganizationPermissions.ManageGoals)]
    public async Task<IActionResult> Set([FromBody] TargetInput input)
    {
        // MIGRATED to the layered API (step 8, second vertical). The endpoint
        // resolves the default period — "which month is it for this org" is a
        // request-shaped question — then hands off. Every rule below the
        // hand-off is enforced again in Process and again in System, so a
        // second caller that is not an HTTP request gets the same guarantees.
        var period = string.IsNullOrEmpty(input.Period) ? await CurrentPeriodAsync(_db) : input.Period!;

        var refusal = await _goals.SetTargetAsync(
            input.UserId, period, input.Amount, User.OrgId(), User.UserId());
        if (refusal is not null)
            return refusal.NotFound
                ? NotFound(new { error = refusal.Reason })
                : BadRequest(new { error = refusal.Reason });

        return Ok(new TargetInput(input.UserId, period, input.Amount));
    }

    // --- Org and team goals (item 4) ---
    //
    // Deliberately independent of Target: soft-constrained, never derived. The
    // UI warns when team goals don't sum to the org goal (or people don't sum to
    // their team's), but nothing here is rejected at save time — see
    // OrgGoal/TeamGoal in Models/Goal.cs for why the goal can't be computed as a
    // sum of the layer below it (that would make the "over/under" banner
    // structurally impossible to draw).

    // GET /targets/goals?period=yyyy-MM — the org goal, every team's goal, and
    // the actual sums one layer down (team goals summed vs the org goal;
    // people's targets summed vs each team's goal) so the client can warn on a
    // mismatch without a second round trip.
    [HttpGet("goals")]
    public async Task<IActionResult> GetGoals([FromQuery] string? period)
    {
        period ??= await CurrentPeriodAsync(_db);
        if (!ValidPeriod(period)) return BadRequest(new { error = "period must be yyyy-MM" });

        // Each person's target for the period, attributed to Profile.PrimaryTeamId,
        // people with no PrimaryTeamId folded into a virtual "Unassigned" row, an
        // archived primary team treated the same as none — all preserved verbatim
        // in GoalProcess.OrgGoalsAsync (see its own comments for why).
        return Ok(await _goals.OrgGoalsAsync(period, User.OrgId()));
    }

    // PUT /targets/goals/org — set the org's revenue goal for a period.
    [HttpPut("goals/org")]
    [RequirePermission(OrganizationPermissions.ManageGoals)]
    public async Task<IActionResult> SetOrgGoal([FromBody] GoalInput input)
    {
        var period = string.IsNullOrEmpty(input.Period) ? await CurrentPeriodAsync(_db) : input.Period!;
        if (!ValidPeriod(period)) return BadRequest(new { error = "period must be yyyy-MM" });

        var refusal = await _goals.SetOrgGoalAsync(period, input.Amount, User.UserId());
        if (refusal is not null) return BadRequest(new { error = refusal.Reason });
        return Ok(new GoalInput(period, input.Amount));
    }

    // PUT /targets/goals/team — set one team's revenue goal for a period.
    [HttpPut("goals/team")]
    [RequirePermission(OrganizationPermissions.ManageGoals)]
    public async Task<IActionResult> SetTeamGoal([FromBody] TeamGoalInput input)
    {
        if (input.TeamId is null) return BadRequest(new { error = "team_id is required" });
        var period = string.IsNullOrEmpty(input.Period) ? await CurrentPeriodAsync(_db) : input.Period!;
        if (!ValidPeriod(period)) return BadRequest(new { error = "period must be yyyy-MM" });
        if (input.Amount is null || input.Amount < 0) return BadRequest(new { error = "amount must be >= 0" });
        // Team-not-found is checked BEFORE the admin-of-that-team check,
        // preserving the original response ordering exactly (a request for a
        // nonexistent team 404s even from a caller who administers no teams at
        // all, rather than 403ing first).
        if (!await _goals.TeamExistsAsync(input.TeamId.Value))
            return NotFound(new { error = "Team not found" });
        // A manager may set the org goal (org-wide by definition) but only their
        // own teams' goals — same rule TeamsController.CanAdminister enforces
        // for renaming/archiving a team. An authorization fact tied to the
        // ClaimsPrincipal, so it stays here rather than in Process — exactly the
        // same reasoning the team-domain migration used for UserAdminPolicy.
        if (!TeamsController.CanAdminister(User, input.TeamId.Value))
            return StatusCode(403, new { error = "You can only set goals for teams you belong to." });

        var refusal = await _goals.SetTeamGoalAsync(input.TeamId, period, input.Amount, User.UserId());
        if (refusal is not null)
            return refusal.NotFound
                ? NotFound(new { error = refusal.Reason })
                : BadRequest(new { error = refusal.Reason });

        return Ok(new TeamGoalInput(input.TeamId, period, input.Amount));
    }

    // --- Audit log (item 5) ---
    //
    // No locking, ever — targets/goals can change any time, in any month. Every
    // write above stages one audit row in the SAME SaveChangesAsync as the
    // write it describes (see GoalStore.SetOrgGoalAsync/SetTeamGoalAsync/
    // SetTargetAsync), so a target/goal change and its audit row commit or
    // roll back together, and a no-op write records nothing.

    // GET /targets/audit?period=yyyy-MM — the change history for that period's
    // targets/goals, newest first. Managers/admins only (same gate as writing).
    [HttpGet("audit")]
    [RequirePermission(OrganizationPermissions.ManageGoals)]
    public async Task<IActionResult> GetAudit([FromQuery] string? period)
    {
        period ??= await CurrentPeriodAsync(_db);
        if (!ValidPeriod(period)) return BadRequest(new { error = "period must be yyyy-MM" });
        return Ok(await _goals.AuditAsync(period));
    }
}

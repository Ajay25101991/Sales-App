using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ExperienceLayer.CustomFields;
using SalesApi.ProcessLayer.CustomFields;
using SalesApi.Services;

namespace SalesApi.Controllers;

[ApiController]
[Route("custom-fields")]
[Authorize]
public class CustomFieldsController : ControllerBase
{
    // MIGRATED to the layered API (step 8). This controller keeps routing,
    // auth and permission checks, model binding and status-code selection; the
    // rules about what a legal field IS — key/label validation, the type
    // vocabulary, options validation, duplicate keys, and what an archive does
    // to values already stored in leads.custom — live in CustomFieldsExperience so
    // a second caller (an importer, a migration script) gets the same
    // guarantees an HTTP request does.
    private readonly CustomFieldsExperience _fields;
    public CustomFieldsController(CustomFieldsExperience fields) => _fields = fields;

    // objectType defaults to "lead" — every caller before E3.1 (the mobile
    // apps, the existing lead form) never sent it and got only lead fields
    // back, so an unfiltered default here would start handing lead-form
    // renderers a pile of account/contact fields they don't understand. The
    // desktop object switcher passes "account"/"contact" explicitly; pass the
    // literal string "all" to get every object type in one call (the bulk
    // admin taxonomy tooling's use case).
    [HttpGet]
    public async Task<IActionResult> List(bool includeArchived = false, string objectType = "lead") =>
        Ok(await _fields.ListAsync(includeArchived, objectType == "all" ? null : objectType));

    // Managers/admins define fields.
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CustomFieldInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot define custom fields." });

        var (created, refusal) = await _fields.CreateAsync(input, actorId: User.UserId());
        if (refusal is not null) return Refuse(refusal);
        return StatusCode(201, created);
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] CustomFieldInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot edit custom fields." });

        var (updated, refusal) = await _fields.UpdateAsync(id, input);
        if (refusal is not null) return Refuse(refusal);
        return Ok(updated);
    }

    /// <summary>Reorder fields in one call — the designer drags, then saves the whole order.</summary>
    [HttpPost("reorder")]
    public async Task<IActionResult> Reorder([FromBody] CustomFieldReorderInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot edit custom fields." });

        var (reordered, refusal) = await _fields.ReorderAsync(input.Ids);
        if (refusal is not null) return Refuse(refusal);
        return Ok(reordered);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot delete custom fields." });

        var refusal = await _fields.DeleteAsync(id);
        if (refusal is not null) return Refuse(refusal);
        return NoContent();
    }

    private IActionResult Refuse(CustomFieldProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason })
        : refusal.Conflict ? Conflict(new { error = refusal.Reason })
        : BadRequest(new { error = refusal.Reason });
}

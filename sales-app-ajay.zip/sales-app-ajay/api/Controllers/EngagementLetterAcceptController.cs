using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.EngagementLetters;
using SalesApi.ProcessLayer.EngagementLetters;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E10.9 - the public (no-auth) accept page for an engagement letter, reached from the link in the email the rep sends. It mirrors
/// <see cref="QuotesController"/>'s <c>/quotes/accept/{token}</c> exactly: a token names one letter, the customer reads it and accepts by
/// typing their name, a stale link is refused on the page and again on the write, and a view is tracked best-effort. The page shell is
/// the quote page's own (<see cref="QuotesController.Html"/>). Routes and renders only; the rules are
/// <see cref="EngagementLetterAcceptProcess"/>.
/// </summary>
[ApiController]
[Route("engagement-letters")]
public class EngagementLetterAcceptController : ControllerBase
{
    private readonly EngagementLetterExperience _letters;
    public EngagementLetterAcceptController(EngagementLetterExperience letters) => _letters = letters;

    private static string Esc(string? s) => QuotesController.Esc(s);
    private static string Html(string title, string body) => QuotesController.Html(title, body);

    private const string NotFoundPage = "<p>This link is no longer valid.</p>";

    [HttpGet("accept/{token}")]
    [Produces("text/html")]
    [AllowAnonymous]
    public async Task<IActionResult> Page(string token)
    {
        // The IP and user agent are read here and handed down as plain strings (the layering rule), as the quote page does.
        var ip = HttpContext?.Connection?.RemoteIpAddress?.ToString();
        var userAgent = HttpContext?.Request?.Headers.UserAgent.ToString();
        var view = await _letters.ViewAsync(token, ip, userAgent);
        if (view.Outcome == EngagementLetterAcceptProcess.ViewOutcome.NotFound)
            return Content(Html("Engagement letter not found", NotFoundPage), "text/html");

        var letter = view.Letter!;
        var body = view.Outcome switch
        {
            EngagementLetterAcceptProcess.ViewOutcome.Accepted => AcceptedBody(letter),
            EngagementLetterAcceptProcess.ViewOutcome.Refused => RefusalBody(letter, view.Refusal!),
            _ => Summary(letter, token) +
                 $"<form method='post' action='/engagement-letters/accept/{Esc(token)}'>" +
                 "<input name='name' placeholder='Your full name' required />" +
                 "<button type='submit'>Accept engagement letter</button></form>",
        };
        return Content(Html(letter.Title, body), "text/html");
    }

    [HttpPost("accept/{token}")]
    [Consumes("application/x-www-form-urlencoded", "application/json")]
    [AllowAnonymous]
    public async Task<IActionResult> Accept(string token, [FromForm] string? name)
    {
        var result = await _letters.AcceptAsync(token, name);
        return result.Outcome switch
        {
            EngagementLetterAcceptProcess.AcceptOutcome.NotFound =>
                Content(Html("Engagement letter not found", NotFoundPage), "text/html"),
            // The refusal on the WRITE, independent of what the GET showed.
            EngagementLetterAcceptProcess.AcceptOutcome.Refused =>
                Content(Html("Engagement letter unavailable", RefusalBody(result.Letter!, result.Refusal!)), "text/html"),
            _ => Content(Html("Accepted", $"<div class='ok'>✓ Accepted</div><p>Thank you, {Esc(result.Letter!.AcceptedBy)}! Your acceptance has been recorded.</p>"), "text/html"),
        };
    }

    /// <summary>The letter's PDF, for the customer to read before accepting. Only a sent or accepted letter has one.</summary>
    [HttpGet("accept/{token}/pdf")]
    [AllowAnonymous]
    public async Task<IActionResult> Pdf(string token)
    {
        var file = await _letters.PdfAsync(token);
        if (file is null) return NotFound();
        Response.Headers.ContentDisposition = SalesApi.Services.DownloadFileName.ContentDisposition(file.Value.Filename, inline: true);
        return File(file.Value.Stream, "application/pdf");
    }

    private static string Summary(CustomerEngagementLetterDto letter, string token)
    {
        var sb = new StringBuilder();
        if (letter.QuoteNumber is not null) sb.Append($"<p class='num'>Engagement letter {Esc(letter.QuoteNumber)} - version {letter.Version}</p>");
        if (letter.Services.Count > 0) sb.Append($"<p>{Esc(string.Join(", ", letter.Services))}</p>");
        if (letter.Total is { } total && letter.Currency is not null)
            sb.Append($"<div class='total'>{ProposalTemplate.Money(total, letter.Currency)}</div>");
        if (letter.HasPdf)
            sb.Append($"<p><a class='cta' href='/engagement-letters/accept/{Esc(token)}/pdf' target='_blank'>Read the letter (PDF)</a></p>");
        return sb.ToString();
    }

    private static string AcceptedBody(CustomerEngagementLetterDto letter) =>
        $"<div class='ok'>✓ Accepted</div><p>Thanks{(letter.AcceptedBy is null ? "" : ", " + Esc(letter.AcceptedBy))} - this engagement letter was accepted on {letter.AcceptedAt:MMM d, yyyy}.</p>";

    private static string RefusalBody(CustomerEngagementLetterDto letter, EngagementLetterAcceptProcess.RefusalInfo refusal)
    {
        if (refusal.Kind == "superseded")
        {
            var sb = new StringBuilder();
            sb.Append("<div class='replaced'>This engagement letter has been replaced</div>");
            sb.Append($"<p>Version {letter.Version} is no longer current and can't be accepted.</p>");
            if (refusal.SuccessorToken is not null)
                sb.Append($"<p><a class='cta' href='/engagement-letters/accept/{Esc(refusal.SuccessorToken)}'>View the current version</a></p>");
            else
                sb.Append("<p class='valid'>Please contact us for the current version.</p>");
            return sb.ToString();
        }
        // A draft: never sent, so from the customer's side it does not exist. Says nothing of its contents.
        return "<div class='replaced'>This engagement letter isn't available</div><p>This link isn't active. Please contact us for a current letter.</p>";
    }
}

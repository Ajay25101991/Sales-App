using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.ExperienceLayer.Microsoft365;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// The Microsoft 365 umbrella's status and "Check access" (design doc
/// to-do/microsoft-365-sharepoint-design.md §3) — mirrors <c>WhatsAppSettingsController</c>.
/// Admin-only (<c>settings.manage</c>). Saving and removing the Entra credentials use the
/// generic <c>PUT /integrations/microsoft_365/credentials</c> and
/// <c>POST /integrations/microsoft_365/disconnect</c>; turning a feature on or off keeps
/// its existing endpoint (<c>/admin/sso</c>, <c>/settings/email-provider</c>,
/// <c>/admin/mailbox-settings</c>).
/// </summary>
[ApiController]
[Authorize]
public class Microsoft365SettingsController : ControllerBase
{
    private readonly Microsoft365SettingsExperience _settings;
    public Microsoft365SettingsController(Microsoft365SettingsExperience settings) => _settings = settings;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);

    [HttpGet("settings/microsoft-365")]
    public async Task<IActionResult> Get()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot view this setting." });
        return Ok(await _settings.GetAsync());
    }

    // PUT /settings/microsoft-365 { sharepoint: { enabled?, site_url?, kinds?, delete_mode? } } - mirrors
    // PUT /settings/whatsapp: omitted keys unchanged, a plain 400 { error } for anything refused.
    [HttpPut("settings/microsoft-365")]
    public async Task<IActionResult> Save([FromBody] SalesApi.Dtos.MicrosoftSettingsInput input)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (dto, refusal) = await _settings.SaveAsync(input, User.UserId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    // POST /settings/microsoft-365/test — "Check access". Sends nothing; fetches an
    // app-only token and reads which application permissions Microsoft has granted.
    // A failed check is a problem in the body, not an error status.
    [HttpPost("settings/microsoft-365/test")]
    public async Task<IActionResult> TestConnection()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        return Ok(await _settings.TestConnectionAsync(User.UserId()));
    }

    // POST /settings/microsoft-365/sharepoint/sync-problems/{id}/retry - hand a folder rename / move the dispatcher
    // gave up on back to it. Answers the GET body; 404 when that job is not (or no longer) in the list.
    [HttpPost("settings/microsoft-365/sharepoint/sync-problems/{id:guid}/retry")]
    public async Task<IActionResult> RetrySyncProblem(Guid id)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var dto = await _settings.RetrySyncProblemAsync(id);
        return dto is null ? NotFound(new { error = "That problem is no longer listed." }) : Ok(dto);
    }

    // POST /settings/microsoft-365/sharepoint/move/start | stop | retry-failed - "Move existing files to SharePoint".
    // start continues a stopped job; stop finishes the file in hand, then stops; retry-failed puts the failed files back in
    // the queue and starts. All answer the GET body; a plain 400 { error } when the request cannot be honoured now.
    [HttpPost("settings/microsoft-365/sharepoint/move/start")]
    public async Task<IActionResult> StartMove()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (dto, refusal) = await _settings.StartMoveAsync(User.UserId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    [HttpPost("settings/microsoft-365/sharepoint/move/stop")]
    public async Task<IActionResult> StopMove()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (dto, refusal) = await _settings.StopMoveAsync();
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }

    [HttpPost("settings/microsoft-365/sharepoint/move/retry-failed")]
    public async Task<IActionResult> RetryFailedMove()
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (dto, refusal) = await _settings.RetryFailedMoveAsync(User.UserId());
        return refusal is not null ? BadRequest(new { error = refusal.Reason }) : Ok(dto);
    }
}

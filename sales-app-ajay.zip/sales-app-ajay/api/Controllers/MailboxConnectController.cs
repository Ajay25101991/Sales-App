using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Mailbox;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E6.1/E6.2 — delegated Microsoft 365 mailbox/calendar connect flow (design
/// doc to-do/e6-capture-design.md §2). Routing, the permission check and
/// status-code selection only (API-led migration convention); the OAuth
/// state machine lives in <see cref="MailboxOAuthProcess"/>.
///
/// The callback is [AllowAnonymous] deliberately: it is hit by a full-page
/// browser redirect from Entra, never by this app's own fetch client, so
/// there is no Authorization header to check — the signed `state` parameter
/// IS the identity/authorization check (see <see cref="ProcessLayer.Mailbox.MailboxOAuthProcess"/>'s
/// own class comment for why that is safe).
/// </summary>
[ApiController]
[Route("mailbox")]
[Authorize]
public class MailboxConnectController : ControllerBase
{
    private readonly MailboxExperience _mailbox;
    public MailboxConnectController(MailboxExperience mailbox) => _mailbox = mailbox;

    private bool CanManage() => User.HasPermission(OrganizationPermissions.ManageSettings);

    // GET /mailbox/connect/start?connector=microsoft_365_mail — self. E7.6:
    // gated on the org's plan in addition to the deployment-level
    // Mailbox:Enabled flag MailboxOAuthProcess already checks.
    [HttpGet("connect/start")]
    [RequirePlanFeature(PlanCatalogue.Features.MailboxSync)]
    public async Task<IActionResult> ConnectStart([FromQuery] string connector)
    {
        var orgId = User.OrgId();
        if (orgId is null) return StatusCode(403, new { error = "No organization on this account." });

        var (refusal, result) = await _mailbox.BuildAuthorizeUrlAsync(orgId.Value, User.UserId(), connector);
        if (refusal is not null) return BadRequest(new { error = refusal.Message });
        return Ok(result);
    }

    // The desktop app's profile page — same host as the API (the device
    // loader at api/wwwroot/apps/sales/index.html routes phone vs desktop),
    // so a relative path is enough; no origin/host header to trust or
    // mis-trust.
    private const string ProfileRedirectPath = "/apps/desktop/profile";

    // GET /mailbox/connect/callback?code=&state= — hit by the browser's
    // redirect from Entra, not by this app's own client. No [Authorize]: the
    // signed state parameter carries the caller's identity (see class comment).
    //
    // REDIRECTS (302) to the desktop profile page rather than returning JSON
    // — this endpoint is hit by a full-page browser navigation, so a JSON
    // body would just be shown as raw text; the rep needs to land back on the
    // Connected-accounts card. `?mailbox=connected` on success,
    // `?mailbox=error&reason=<short code>` on failure — NEVER raw provider
    // text in the URL (query strings end up in browser history and server
    // access logs), same "reason a human can read, never the vendor's own
    // string" discipline GraphEmailSender's failure messages already follow.
    [HttpGet("connect/callback")]
    [AllowAnonymous]
    public async Task<IActionResult> ConnectCallback([FromQuery] string? code, [FromQuery] string? state, [FromQuery] string? error)
    {
        if (!string.IsNullOrEmpty(error))
            return Redirect($"{ProfileRedirectPath}?mailbox=error&reason=denied");
        if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(state))
            return Redirect($"{ProfileRedirectPath}?mailbox=error&reason=missing_params");

        var (refusal, result) = await _mailbox.ExchangeCallbackAsync(code, state);
        if (refusal is not null)
            return Redirect($"{ProfileRedirectPath}?mailbox=error&reason=exchange_failed");
        return Redirect($"{ProfileRedirectPath}?mailbox=connected");
    }

    // GET /mailbox/status?connector=microsoft_365_mail — self.
    [HttpGet("status")]
    public async Task<IActionResult> Status([FromQuery] string connector)
    {
        var result = await _mailbox.GetStatusAsync(User.UserId(), connector);
        return Ok(result); // connection: null (not_connected) is a valid, honest answer — never a 404 for "not yet connected".
    }

    // POST /mailbox/disconnect/{id} — self disconnect. A rep may only
    // disconnect their OWN connection here; force-disconnecting someone
    // else's requires the admin route below.
    [HttpPost("disconnect/{id:guid}")]
    public async Task<IActionResult> Disconnect(Guid id)
    {
        var mine = await _mailbox.GetMyConnectionAsync(User.UserId(), "microsoft_365_mail");
        var mineCalendar = await _mailbox.GetMyConnectionAsync(User.UserId(), "outlook_calendar");
        if ((mine is null || mine.Id != id) && (mineCalendar is null || mineCalendar.Id != id))
            return StatusCode(403, new { error = "You can only disconnect your own mailbox connection." });

        var ok = await _mailbox.DisconnectAsync(id);
        if (!ok) return NotFound(new { error = "That connection no longer exists." });
        return Ok(new { disconnected = true });
    }

    // GET /mailbox/admin/connections — every rep, every connector, this org. Admin only.
    [HttpGet("admin/connections")]
    public async Task<IActionResult> AdminList()
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot view mailbox connections." });
        return Ok(await _mailbox.ListAllAsync());
    }

    // POST /mailbox/admin/connections/{id}/disconnect — force-disconnect
    // (design §11.7). Admin only; audited via the row's own Status flip
    // (Services.FieldAudit — see MailboxOAuthProcess.DisconnectAsync).
    [HttpPost("admin/connections/{id:guid}/disconnect")]
    public async Task<IActionResult> AdminDisconnect(Guid id)
    {
        if (!CanManage()) return StatusCode(403, new { error = "Your role cannot manage mailbox connections." });
        var (refusal, result) = await _mailbox.AdminDisconnectAsync(id);
        if (refusal is not null) return NotFound(new { error = refusal.Message });
        return Ok(result);
    }
}

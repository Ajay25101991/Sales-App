using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.DataAccessLog;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E12.4 (owner decision 14): every CSV export writes ONE data-access-log entry - who, what kind, how many rows.
///
/// WHY A FILTER, not a line in each export endpoint: there are ten endpoints that answer <c>text/csv</c> (leads, accounts, the
/// report exports, the team roster) and an eleventh will be added. The response content type is the one thing they share, so the
/// log is written at that single choke point rather than remembered ten times. It runs BEFORE the result executes, so a failure to
/// write the entry stops the file leaving (the log cannot be skipped by an error), and it only fires for a 200 CSV a signed-in
/// person asked for. The rows are counted from the text already built; nothing about their content is read or stored.
/// </summary>
public sealed class DataExportLogFilter : IAsyncResultFilter
{
    private readonly DataAccessLogExperience _log;
    public DataExportLogFilter(DataAccessLogExperience log) => _log = log;

    public async Task OnResultExecutionAsync(ResultExecutingContext context, ResultExecutionDelegate next)
    {
        if (context.Result is ContentResult { ContentType: { } type } content
            && type.StartsWith("text/csv", StringComparison.OrdinalIgnoreCase)
            && (content.StatusCode ?? StatusCodes.Status200OK) == StatusCodes.Status200OK
            && context.HttpContext.User.Identity?.IsAuthenticated == true)
        {
            var template = (context.ActionDescriptor.AttributeRouteInfo?.Template ?? context.HttpContext.Request.Path.Value ?? "")
                .TrimStart('/');
            await _log.RecordExportAsync(
                context.HttpContext.User.UserId(), RecordTypeFor(template), CountRows(content.Content),
                // E18.4: the same export asked for as Excel (?format=xlsx, swapped later by XlsxExportFilter) is logged as such.
                XlsxExportFilter.WantsXlsx(context.HttpContext.Request) ? "xlsx" : "csv",
                context.HttpContext.RequestAborted);
        }
        await next();
    }

    /// <summary>leads/*, accounts/* and contacts/* are their own record types, the team roster is "team", everything else is a report.</summary>
    internal static string RecordTypeFor(string routeTemplate)
    {
        var first = routeTemplate.TrimStart('/').Split('/', 2)[0].ToLowerInvariant();
        return first switch
        {
            "leads" => DataAccessRecordTypes.Lead,
            "accounts" => DataAccessRecordTypes.Account,
            "contacts" => DataAccessRecordTypes.Contact,
            "team" => DataAccessRecordTypes.Team,
            _ => DataAccessRecordTypes.Report,
        };
    }

    /// <summary>Data rows in a CSV text: records minus the header. A newline inside a quoted cell does not start a record.</summary>
    internal static int CountRows(string? csv)
    {
        if (string.IsNullOrEmpty(csv)) return 0;
        var records = 0;
        var inQuotes = false;
        var sawContent = false;
        for (var i = 0; i < csv.Length; i++)
        {
            var ch = csv[i];
            if (ch == '"') { inQuotes = !inQuotes; sawContent = true; }
            else if (ch == '\n' && !inQuotes) { if (sawContent) records++; sawContent = false; }
            else if (ch != '\r') sawContent = true;
        }
        if (sawContent) records++;
        return Math.Max(0, records - 1);
    }
}

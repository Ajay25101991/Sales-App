using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Usage;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// Client usage (channel partners Phase 4; design 9.3.4; owner decisions 4.4 / 4.5 / 4.6): counts of invoices issued / received and API calls per client per month, imported by a
/// CSV (preview, then commit) by someone with <c>usage.import</c>, and read as counts against the contract's allowance with an ESTIMATED charge from the deal's frozen pricing.
/// The CRM creates no invoice from any of it.
///
/// This controller routes, checks the permission and picks a status code. Importing needs <c>usage.import</c> (admins, executive/owner, the ready-made Finance &amp; billing role);
/// reading a client's or a deal's usage follows the visibility of that account / deal, and the estimated charge additionally follows the Deal values category.
/// </summary>
[ApiController]
[Route("")]
[Authorize]
public class UsageController : ControllerBase
{
    private readonly UsageExperience _usage;
    private readonly CallerContext _caller;
    public UsageController(UsageExperience usage, CallerContext caller)
    {
        _usage = usage;
        _caller = caller;
    }

    private bool CanImport => User.HasPermission(OrganizationPermissions.ImportUsage);
    private ObjectResult No() => StatusCode(403, new { error = "Your role cannot import client usage." });

    /// <summary>Reads and checks a CSV (client, entity, period YYYY-MM, metric, count, partner, deal) and stores it as a PREVIEW. Nothing is imported until it is committed.</summary>
    [HttpPost("usage/imports")]
    public async Task<IActionResult> Preview([FromBody] UsageCsvInput input, CancellationToken ct) =>
        !CanImport ? No() : this.Respond(await _usage.PreviewCsvAsync(input, User.UserId(), ct), 201);

    [HttpGet("usage/imports")]
    public async Task<IActionResult> Imports(CancellationToken ct) =>
        !CanImport ? No() : this.Respond(await _usage.ListBatchesAsync(ct));

    [HttpGet("usage/imports/{id:guid}")]
    public async Task<IActionResult> Import(Guid id, CancellationToken ct) =>
        !CanImport ? No() : this.Respond(await _usage.GetBatchAsync(id, ct));

    /// <summary>Commits a previewed file that has no row errors: the numbers it replaces are superseded, the new ones inserted, the stored aggregate rewritten - in one transaction.</summary>
    [HttpPost("usage/imports/{id:guid}/commit")]
    public async Task<IActionResult> Commit(Guid id, CancellationToken ct) =>
        !CanImport ? No() : this.Respond(await _usage.CommitAsync(id, User.UserId(), ct));

    [HttpPost("usage/imports/{id:guid}/reject")]
    public async Task<IActionResult> Reject(Guid id, CancellationToken ct) =>
        !CanImport ? No() : this.Respond(await _usage.RejectAsync(id, User.UserId(), ct));

    /// <summary>A client's months from the stored aggregate (<c>from</c> / <c>to</c>: any day in the month). The client tab.</summary>
    [HttpGet("accounts/{id:guid}/usage")]
    public async Task<IActionResult> Account(Guid id, CancellationToken ct, [FromQuery] DateOnly? from = null, [FromQuery] DateOnly? to = null) =>
        this.Respond(await _usage.AccountAsync(await _caller.ForAsync(User), id, from, to, ct));

    /// <summary>A deal's usage in one contract year against its frozen quote's allowance, with the estimated charge (withheld below a raw read of Deal values).</summary>
    [HttpGet("leads/{id:guid}/usage")]
    public async Task<IActionResult> Deal(Guid id, CancellationToken ct, [FromQuery(Name = "contract_year")] int? contractYear = null) =>
        this.Respond(await _usage.DealAsync(await _caller.ForAsync(User), id, contractYear, ct));
}

/// <summary>
/// The platform pushing its own counts: <c>POST /partner/v1/usage</c>, authenticated by a scoped API key (<c>usage:write</c>) like the rest of the Partner API
/// (<see cref="PartnerApiController"/>: the "ApiKey" scheme, <see cref="RequireApiKeyScopeAttribute"/>, the key's org stamped as the tenant). A second adapter onto the SAME validation
/// and commit the CSV uses. All or nothing: a bad row refuses the whole push (the row errors come back as <c>issues</c>) and nothing is written.
/// </summary>
[ApiController]
[Route("partner/v1/usage")]
[Authorize(AuthenticationSchemes = ApiKeyAuthenticationDefaults.Scheme)]
[RequirePlanFeature(PlanCatalogue.Features.ApiWebhooks)]
public class PartnerUsageApiController : ControllerBase
{
    private readonly UsageExperience _usage;
    public PartnerUsageApiController(UsageExperience usage) => _usage = usage;

    [HttpPost]
    [RequireApiKeyScope(ApiKeyScopes.Keys.UsageWrite)]
    public async Task<IActionResult> PushUsage([FromBody] UsagePushInput input, CancellationToken ct)
    {
        Guid? keyId = Guid.TryParse(User.FindFirst("api_key_id")?.Value, out var id) ? id : null;
        return this.Respond(await _usage.PushAsync(input, keyId, ct), 201);
    }
}

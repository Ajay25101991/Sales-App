using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.ReportSchedules;
using SalesApi.ProcessLayer.Reports;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E3.10 — "Email me this". Owner-only CRUD, listed under Profile per the
/// owner decision (`to-do/epics-ai-native-crm.md` 2026-09-27): a personal
/// setting, not a distribution list a manager configures for someone else —
/// so every route below scopes to <c>User.UserId()</c>, never a body/query
/// owner id.
/// </summary>
[ApiController]
[Route("report-schedules")]
[Authorize]
public class ReportSchedulesController : ControllerBase
{
    private readonly ReportSchedulesExperience _schedules;
    public ReportSchedulesController(ReportSchedulesExperience schedules) => _schedules = schedules;

    [HttpGet]
    public async Task<IActionResult> List() => Ok(await _schedules.ListAsync(User.UserId()));

    // E7.6 — gated on the org's plan.
    [HttpPost]
    [RequirePlanFeature(PlanCatalogue.Features.ScheduledReports)]
    public async Task<IActionResult> Create([FromBody] ReportScheduleInput input)
    {
        var (refusal, dto) = await _schedules.CreateAsync(User.UserId(), input);
        return refusal is not null ? Refused(refusal) : Ok(dto);
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] ReportScheduleInput input)
    {
        var (refusal, dto) = await _schedules.UpdateAsync(User.UserId(), id, input);
        return refusal is not null ? Refused(refusal) : Ok(dto);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var refusal = await _schedules.DeleteAsync(User.UserId(), id);
        return refusal is not null ? Refused(refusal) : NoContent();
    }

    private IActionResult Refused(ReportScheduleProcess.Refusal r)
    {
        if (r.Forbidden) return StatusCode(403, new { error = r.Message ?? "You cannot do that." });
        if (r.NoProvider) return BadRequest(new { error = r.Message ?? "This organization has not configured email delivery.", code = "no_email_provider" });
        return BadRequest(new { error = r.Message ?? "Invalid schedule." });
    }
}

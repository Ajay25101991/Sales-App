using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.DocumentRequests;
using SalesApi.ProcessLayer.DocumentRequests;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E15 document requests (staff side): ask an account's client to upload the KYC documents it is missing through a secure link, resend or withdraw that
/// link, and read the requests with what came in. Routes, checks the permission (kyc.access, like the document register), and picks a status code; the
/// account-access rule (read = view the account, every write = manage it) and everything else is <see cref="DocumentRequestProcess"/>. The client's side is
/// <see cref="DocumentRequestPublicController"/>.
/// </summary>
[ApiController]
[Authorize]
[RequirePermission(OrganizationPermissions.KycAccess)]
public class DocumentRequestsController : ControllerBase
{
    private readonly DocumentRequestExperience _requests;
    private readonly CallerContext _caller;

    public DocumentRequestsController(DocumentRequestExperience requests, CallerContext caller)
    {
        _requests = requests;
        _caller = caller;
    }

    /// <summary>404/403/409/400/503 with <c>{error, code?}</c>; <c>code</c> is nothing_to_request, request_open, no_recipient, request_closed,
    /// mailbox_reconnect_required or mailbox_not_connected.</summary>
    private IActionResult Respond<T>(DocumentRequestProcess.Result<T> r, int okStatus = 200) => r.Outcome switch
    {
        DocumentRequestProcess.Outcome.NotFound => NotFound(new { error = r.Error }),
        DocumentRequestProcess.Outcome.Forbidden => StatusCode(403, new { error = r.Error }),
        DocumentRequestProcess.Outcome.Conflict => Conflict(new { error = r.Error, code = r.Code }),
        DocumentRequestProcess.Outcome.Unavailable => StatusCode(503, new { error = r.Error, code = r.Code }),
        DocumentRequestProcess.Outcome.Invalid => BadRequest(new { error = r.Error, code = r.Code }),
        _ => StatusCode(okStatus, r.Value),
    };

    /// <summary>POST /accounts/{id}/document-requests <c>{ document_types?, contact_id?, to?, message? }</c>: emails the client the secure upload link. 201 with the
    /// request. 409 <c>request_open</c> when the account already has one open (resend it); 400 <c>nothing_to_request</c> when nothing missing can be asked for.</summary>
    [HttpPost("accounts/{accountId:guid}/document-requests")]
    public async Task<IActionResult> Create(Guid accountId, [FromBody] CreateDocumentRequestInput? input, CancellationToken ct) =>
        Respond(await _requests.CreateAsync(
            await _caller.ForAsync(User), User.UserId(), await _caller.DisplayNameAsync(User), accountId, input ?? new CreateDocumentRequestInput(), ct), 201);

    /// <summary>GET /accounts/{id}/document-requests: the account's requests, newest first.</summary>
    [HttpGet("accounts/{accountId:guid}/document-requests")]
    public async Task<IActionResult> List(Guid accountId, CancellationToken ct) =>
        Respond(await _requests.ListAsync(await _caller.ForAsync(User), accountId, ct));

    /// <summary>POST /document-requests/{id}/resend: emails the SAME link again and restarts its clock.</summary>
    [HttpPost("document-requests/{id:guid}/resend")]
    public async Task<IActionResult> Resend(Guid id, CancellationToken ct) =>
        Respond(await _requests.ResendAsync(await _caller.ForAsync(User), User.UserId(), await _caller.DisplayNameAsync(User), id, ct));

    /// <summary>POST /document-requests/{id}/revoke: withdraws the link now. What was uploaded stays in the register.</summary>
    [HttpPost("document-requests/{id:guid}/revoke")]
    public async Task<IActionResult> Revoke(Guid id, CancellationToken ct) =>
        Respond(await _requests.RevokeAsync(await _caller.ForAsync(User), User.UserId(), id, ct));
}

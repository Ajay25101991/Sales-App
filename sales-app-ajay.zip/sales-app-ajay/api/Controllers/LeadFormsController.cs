using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.LeadForms;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// The lead form LIBRARY: named forms, plural, each optionally pointing at a
/// playbook (design doc D2, 2026-08-25).
///
/// This is NOT a replacement for `SettingsController`'s `/settings/lead-form*`
/// endpoints. Those keep working exactly as before, unconditionally against
/// the org's "Default" form (`LeadFormService.GetOrCreateDefaultFormAsync`) —
/// unchanged. This controller is purely ADMIN MANAGEMENT of the library: list
/// the forms that exist, create a new named one, rename one, point it at a
/// playbook, and edit/publish/roll back ITS OWN version history. "Which form a
/// rep sees when creating a lead", and whether an existing lead's form is
/// pinned, were D2's own "open and not yet decided" notes; both are now
/// decided (`lead_form_source` / `lead_form_pinning`,
/// `Services.LeadFormRoutingService`) and enforced in
/// `Controllers.LeadsController.Create`/`Update` — NOT here. This library
/// controller has no opinion on which form a rep sees; it only manages what
/// forms exist for that resolution to pick from.
///
/// Gated entirely by ManageSettings, unlike `/settings/lead-form` (open read
/// for `GET`, because every rep needs it to render the form at all) — every
/// route here is an admin-configuration one, so there is no open-read case to
/// carve out, same as `SettingsController.Update`.
/// </summary>
[ApiController]
[Authorize]
[Route("lead-forms")]
public class LeadFormsController : ControllerBase
{
    private readonly LeadFormLibraryExperience _library;
    public LeadFormsController(LeadFormLibraryExperience library) => _library = library;

    private bool CanManage() => User.HasPermission(OrganizationPermissions.ManageSettings);
    private IActionResult Forbidden() => StatusCode(403, new { error = "Your role cannot manage lead forms." });

    [HttpGet]
    public async Task<IActionResult> List()
    {
        if (!CanManage()) return Forbidden();
        return Ok(await _library.ListAsync());
    }

    /// <summary>Library warnings: a playbook with two forms, a live playbook with teams and no live form.</summary>
    [HttpGet("warnings")]
    public async Task<IActionResult> Warnings()
    {
        if (!CanManage()) return Forbidden();
        return Ok(await _library.WarningsAsync());
    }

    /// <summary>Which forms carry each custom field, for the Fields screen ("custom:&lt;key&gt;" -> forms).</summary>
    [HttpGet("field-usage")]
    public async Task<IActionResult> FieldUsage()
    {
        if (!CanManage()) return Forbidden();
        return Ok(await _library.FieldUsageAsync());
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateLeadFormRequest input)
    {
        if (!CanManage()) return Forbidden();

        var (form, refusal) = await _library.CreateAsync(
            input.Name, input.PlaybookId, input.Key, User.UserId(), copyFromFormId: input.CopyFromFormId);
        if (refusal is not null)
        {
            if (refusal.NotFound) return NotFound(new { error = refusal.Reason });
            // "A form needs a name" is the only refusal reachable before a
            // create was attempted; anything else is the name-collision the
            // filtered unique index would otherwise throw on.
            return string.IsNullOrWhiteSpace(input.Name)
                ? BadRequest(new { error = refusal.Reason })
                : Conflict(new { error = refusal.Reason });
        }
        return Ok(form);
    }

    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateLeadFormRequest input)
    {
        if (!CanManage()) return Forbidden();
        try
        {
            var form = await _library.UpdateAsync(id, input.Name, input.PlaybookId, input.ClearPlaybook ?? false);
            if (form is null)
            {
                // Ambiguous by design, matching LeadFormService.UpdateFormAsync's own
                // contract: null means either "no such (non-archived) form" or "name
                // collision" — a query first would defeat this method's whole point
                // of resolving both in one round trip. Report the collision case only
                // when the id genuinely exists, so a bad id still reads as 404.
                var exists = await _library.ExistsAsync(id);
                return exists
                    ? Conflict(new { error = $"A form named “{input.Name}” already exists." })
                    : NotFound(new { error = "Form not found." });
            }
            return Ok(form);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
        catch (InvalidOperationException ex)
        {
            // Renaming the Default form — same answer Archive gives for it.
            return BadRequest(new { error = ex.Message });
        }
    }

    [HttpPost("{id:guid}/archive")]
    public async Task<IActionResult> Archive(Guid id)
    {
        if (!CanManage()) return Forbidden();
        try
        {
            var ok = await _library.ArchiveAsync(id);
            if (!ok) return NotFound(new { error = "Form not found." });
            return Ok(new { ok = true });
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    // --- This form's own schema/versions — same shape as SettingsController's
    // lead-form endpoints, scoped to ONE form instead of the org singleton. ---

    [HttpGet("{id:guid}/draft")]
    public async Task<IActionResult> GetDraft(Guid id)
    {
        if (!CanManage()) return Forbidden();
        if (!await _library.ExistsAsync(id)) return NotFound(new { error = "Form not found." });
        return Ok(await _library.DraftAsync(id));
    }

    [HttpGet("{id:guid}/versions")]
    public async Task<IActionResult> GetVersions(Guid id)
    {
        if (!CanManage()) return Forbidden();
        if (!await _library.ExistsAsync(id)) return NotFound(new { error = "Form not found." });

        // Scoped by LeadFormId, unlike SettingsController.GetLeadFormVersions
        // (which queries LeadFormVersions with no such filter — see this
        // controller's class comment: that endpoint predates forms being
        // plural and still means "the Default form's history" only by
        // accident of there having been exactly one form when it was
        // written. It is not touched here; flagged in the handoff instead.)
        return Ok(await _library.VersionsAsync(id));
    }

    /// <summary>One saved version, read-only — the builder history's "Compare". Same shape as the draft read.</summary>
    [HttpGet("{id:guid}/versions/{version:int}")]
    public async Task<IActionResult> GetVersion(Guid id, int version)
    {
        if (!CanManage()) return Forbidden();
        if (!await _library.ExistsAsync(id)) return NotFound(new { error = "Form not found." });

        var found = await _library.VersionAsync(id, version);
        return found is null ? NotFound(new { error = $"There is no version {version}." }) : Ok(found);
    }

    [HttpPut("{id:guid}/draft")]
    public Task<IActionResult> SaveDraft(Guid id, [FromBody] Services.LeadFormSchemaModel input) =>
        Write(id, input, publish: false);

    [HttpPut("{id:guid}")]
    public Task<IActionResult> Publish(Guid id, [FromBody] Services.LeadFormSchemaModel input) =>
        Write(id, input, publish: true);

    /// <summary>Load an earlier version into the form's draft (not live). The builder's "Restore".</summary>
    [HttpPost("{id:guid}/versions/{version:int}/restore")]
    public async Task<IActionResult> Restore(Guid id, int version)
    {
        if (!CanManage()) return Forbidden();
        if (!await _library.ExistsAsync(id)) return NotFound(new { error = "Form not found." });

        var draft = await _library.RestoreAsync(id, version, User.UserId());
        return draft is null
            ? NotFound(new { error = $"There is no version {version} to restore." })
            : Ok(draft);
    }

    private async Task<IActionResult> Write(Guid id, Services.LeadFormSchemaModel input, bool publish)
    {
        if (!CanManage()) return Forbidden();
        if (!await _library.ExistsAsync(id)) return NotFound(new { error = "Form not found." });

        var (refusal, saved) = await _library.WriteAsync(id, input, publish, User.UserId());
        if (refusal is null) return Ok(saved);
        // A schema that fails validation carries the code and the per-field
        // problems the designer highlights; "the form is empty" is a plain
        // message, and has never carried either.
        return refusal.SchemaInvalid
            ? BadRequest(new
            {
                error = string.Join(" ", refusal.Problems),
                code = "invalid_form_schema",
                problems = refusal.Problems,
            })
            : BadRequest(new { error = string.Join(" ", refusal.Problems) });
    }
}

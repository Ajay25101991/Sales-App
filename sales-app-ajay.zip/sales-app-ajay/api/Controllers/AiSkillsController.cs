using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.AiPlatform;
using SalesApi.ProcessLayer.AiPlatform;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// The E4.4 prompt/skill registry (design doc to-do/e4-ai-platform-design.md
/// §4, §15 slice 6): CRUD/publish/rollback for an org's own skill overrides,
/// plus the effective-prompt resolver. ORG-ADMIN ONLY, same base-role gate
/// (not a configurable <see cref="OrganizationPermissions"/> key) that
/// <see cref="AutomationsController"/> uses for the identical reason — its
/// own header explains why "admins only" here means the base role, full
/// stop, not something an org's role configuration can hand to a manager by
/// accident. Mirrors Automation's admin-only posture per design §4.1
/// ("mirrors Automation/AutomationVersion… exactly").
/// </summary>
[ApiController]
[Authorize]
[Route("ai-skills")]
public class AiSkillsController : ControllerBase
{
    private readonly AiSkillExperience _skills;
    public AiSkillsController(AiSkillExperience skills) => _skills = skills;

    private IActionResult Forbidden() => StatusCode(403, new { error = "Only org admins can manage AI skills." });

    private IActionResult Refused(AiSkillProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason }) : BadRequest(new { error = refusal.Reason });

    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        return Ok(await _skills.ListAsync(User.OrgId()!.Value, ct));
    }

    [HttpGet("{id:guid}/versions")]
    public async Task<IActionResult> Versions(Guid id, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (versions, refusal) = await _skills.VersionsAsync(id, User.OrgId()!.Value, ct);
        return refusal is not null ? Refused(refusal) : Ok(versions);
    }

    /// <summary>The resolver design §4 asks for — "the effective prompt for
    /// skill X in org Y" — by skill KEY, since that is the stable identifier
    /// a future skill-invoking caller (E5, not this slice) would hold.</summary>
    [HttpGet("{key}/effective")]
    public async Task<IActionResult> Effective(string key, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (result, refusal) = await _skills.EffectivePromptAsync(key, User.OrgId()!.Value, ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    [HttpPut("{id:guid}/draft")]
    public async Task<IActionResult> SaveDraft(Guid id, [FromBody] AiSkillDraftInput input, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (result, refusal) = await _skills.SaveDraftAsync(id, User.OrgId()!.Value, input, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    [HttpPost("{id:guid}/publish")]
    public async Task<IActionResult> Publish(Guid id, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (result, refusal) = await _skills.PublishAsync(id, User.OrgId()!.Value, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    [HttpPost("{id:guid}/rollback/{versionId:guid}")]
    public async Task<IActionResult> Rollback(Guid id, Guid versionId, CancellationToken ct)
    {
        if (!User.IsOrgAdmin()) return Forbidden();
        var (result, refusal) = await _skills.RollbackAsync(id, User.OrgId()!.Value, versionId, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }
}

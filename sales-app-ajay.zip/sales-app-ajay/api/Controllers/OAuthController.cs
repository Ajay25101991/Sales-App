using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.OAuth;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// The CRM as a small OAuth 2.1 authorization server for ONE purpose (MCP phase 2, to-do/mcp-server-design.md): a person connects Claude / ChatGPT /
/// Cursor by signing in with their own CRM account. Discovery (RFC 9728 + RFC 8414), dynamic client registration (RFC 7591), authorize, token,
/// the consent API the desktop app's consent page calls, and the per-person / admin lists of connected tools.
///
/// Rules live in OAuthProcess / OAuthStore; this file routes, rate-limits, reads the request, runs the same /mcp gate (<see cref="McpAccess"/>) for
/// the consent verdict, checks the admin permission, and picks status codes. Absolute addresses are built from <see cref="PublicBaseUrl"/> exactly as
/// every other emailed or advertised link is.
/// </summary>
[ApiController]
public class OAuthController : ControllerBase
{
    private readonly OAuthExperience _oauth;
    private readonly McpAccess _access;
    private readonly IConfiguration _config;

    public OAuthController(OAuthExperience oauth, McpAccess access, IConfiguration config)
    {
        _oauth = oauth;
        _access = access;
        _config = config;
    }

    // --- Discovery ---

    // The /mcp 401 challenge points at the first route; the second is the path-suffixed form (RFC 9728 3.1) some clients probe directly.
    [AllowAnonymous]
    [HttpGet("/.well-known/oauth-protected-resource")]
    [HttpGet("/.well-known/oauth-protected-resource/mcp")]
    public IActionResult ProtectedResource() =>
        Ok(_oauth.ProtectedResource(McpOAuthUrls.Resource(_config, Request), McpOAuthUrls.Issuer(_config, Request)));

    [AllowAnonymous]
    [HttpGet("/.well-known/oauth-authorization-server")]
    public IActionResult AuthorizationServer() =>
        Ok(_oauth.ServerMetadata(
            McpOAuthUrls.Issuer(_config, Request),
            McpOAuthUrls.Absolute(_config, Request, "/oauth/authorize"),
            McpOAuthUrls.Absolute(_config, Request, "/oauth/token"),
            McpOAuthUrls.Absolute(_config, Request, "/oauth/register")));

    // --- Registration, authorize, token ---

    [AllowAnonymous]
    [EnableRateLimiting("auth")]
    [HttpPost("/oauth/register")]
    public async Task<IActionResult> Register([FromBody] OAuthRegisterRequest req)
    {
        var (refusal, response) = await _oauth.RegisterAsync(req);
        // RFC 7591 3.2.2 names the error members.
        if (refusal is not null) return BadRequest(new { error = "invalid_redirect_uri", error_description = refusal.Reason });
        return StatusCode(201, response);
    }

    /// <summary>
    /// Anonymous (the AI tool opens it in the person's browser). It only validates and parks the request, then sends the browser to the desktop
    /// consent page, where the person signs in and decides - the CRM's own sign-in is never re-implemented here.
    /// </summary>
    [AllowAnonymous]
    [EnableRateLimiting("auth")]
    [HttpGet("/oauth/authorize")]
    public async Task<IActionResult> Authorize()
    {
        string? Q(string key) => Request.Query.TryGetValue(key, out var v) ? v.ToString() : null;
        var outcome = await _oauth.AuthorizeAsync(
            new OAuthAuthorizeQuery(Q("client_id"), Q("redirect_uri"), Q("response_type"), Q("code_challenge"), Q("code_challenge_method"), Q("state"), Q("resource")),
            McpOAuthUrls.Resource(_config, Request));

        if (outcome.RedirectUrl is not null) return Redirect(outcome.RedirectUrl);
        if (outcome.ConsentRequestId is { } id) return Redirect(McpOAuthUrls.ConsentPage(_config, Request, Guid.Parse(id)));
        // The client or redirect_uri cannot be trusted, so nothing is redirected to it: a plain 400.
        return new ContentResult
        {
            Content = $"{outcome.Error}: {outcome.ErrorDescription}", ContentType = "text/plain; charset=utf-8", StatusCode = StatusCodes.Status400BadRequest,
        };
    }

    /// <summary>Form-encoded (RFC 6749 4.1.3). Rate-limited on "auth-refresh": the AI tool refreshes in the background, which is not a password guess.</summary>
    [AllowAnonymous]
    [EnableRateLimiting("auth-refresh")]
    [HttpPost("/oauth/token")]
    public async Task<IActionResult> Token()
    {
        Response.Headers.CacheControl = "no-store";
        Response.Headers.Pragma = "no-cache";
        if (!Request.HasFormContentType)
            return BadRequest(new OAuthTokenError("invalid_request", "Send application/x-www-form-urlencoded."));

        var form = await Request.ReadFormAsync();
        var values = form.ToDictionary(kv => kv.Key, kv => kv.Value.ToString(), StringComparer.Ordinal);
        var (error, response) = await _oauth.TokenAsync(values, McpOAuthUrls.Resource(_config, Request));
        if (error is not null)
            return StatusCode(error.Error == "invalid_client" ? StatusCodes.Status401Unauthorized : StatusCodes.Status400BadRequest, error);
        return Ok(response);
    }

    // --- Consent (a signed-in normal session; the desktop app's /oauth/consent page) ---

    /// <summary>The ONE gate /mcp runs, asked of this person now: plan feature, the connect permission, any override. <c>reason</c> is its plain sentence.</summary>
    private async Task<(bool Can, string? Reason)> CanConnectAsync()
    {
        var resolution = await _access.ResolveAsync(User, McpToolCatalogue.Names.Search, HttpContext.RequestAborted);
        return (resolution.Caller is not null, resolution.Refusal);
    }

    [Authorize]
    [HttpGet("/oauth/requests/{id:guid}")]
    public async Task<IActionResult> GetRequest(Guid id)
    {
        var (can, reason) = await CanConnectAsync();
        var consent = await _oauth.GetConsentAsync(id, can, reason);
        return consent is null ? NotFound(new { error = "This connection request has expired. Start again from the AI tool." }) : Ok(consent);
    }

    [Authorize]
    [HttpPost("/oauth/requests/{id:guid}/approve")]
    public async Task<IActionResult> Approve(Guid id)
    {
        var (can, reason) = await CanConnectAsync();
        var (refusal, redirect) = await _oauth.DecideAsync(id, approve: true, can, reason, User.UserId(), User.OrgId());
        return refusal is not null ? StatusCode(refusal.StatusCode, new { error = refusal.Reason }) : Ok(redirect);
    }

    [Authorize]
    [HttpPost("/oauth/requests/{id:guid}/deny")]
    public async Task<IActionResult> Deny(Guid id)
    {
        var (refusal, redirect) = await _oauth.DecideAsync(id, approve: false, canConnect: true, reason: null, User.UserId(), User.OrgId());
        return refusal is not null ? StatusCode(refusal.StatusCode, new { error = refusal.Reason }) : Ok(redirect);
    }

    // --- Connected tools ---

    [Authorize]
    [HttpGet("/me/ai-connections")]
    public async Task<IActionResult> Mine() => Ok(await _oauth.ListMineAsync(User.UserId()));

    [Authorize]
    [HttpDelete("/me/ai-connections/{id:guid}")]
    public async Task<IActionResult> DisconnectMine(Guid id) =>
        await _oauth.DisconnectMineAsync(id, User.UserId()) ? NoContent() : NotFound(new { error = "No such connection." });

    /// <summary>Admin: everyone's connected tools in this org, or one person's with <c>?user_id=</c>.</summary>
    [Authorize]
    [HttpGet("/mcp/connections")]
    public async Task<IActionResult> OrgConnections([FromQuery(Name = "user_id")] Guid? userId)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot view AI tool connections." });
        if (User.OrgId() is not Guid orgId) return StatusCode(403, new { error = "Your role cannot view AI tool connections." });
        return Ok(await _oauth.ListForOrgAsync(orgId, userId));
    }

    /// <summary>Admin: disconnect someone's AI tool. Another org's connection is a 404, not a 403 (it must not be confirmed to exist).</summary>
    [Authorize]
    [HttpDelete("/mcp/connections/{id:guid}")]
    public async Task<IActionResult> DisconnectInOrg(Guid id)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot disconnect AI tools." });
        if (User.OrgId() is not Guid orgId) return StatusCode(403, new { error = "Your role cannot disconnect AI tools." });
        return await _oauth.DisconnectInOrgAsync(id, orgId) ? NoContent() : NotFound(new { error = "No such connection." });
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.AiPlatform;
using SalesApi.ProcessLayer.AiPlatform;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// E5's shared AI-feedback frame (design doc to-do/e4-ai-platform-design.md
/// §3's "UserFeedback"; E5.0 design review decision 2's reject-reason
/// policy). <c>POST /ai/feedback</c> is used by every E5 AI-output surface —
/// not scoped under any one feature's route, since one accept/edit/reject
/// frame is shared across all of them (the "AI output frame" shared
/// component, to-do/epics-ai-native-crm.md line ~58). The settings pair is
/// admin-only, same <see cref="OrganizationPermissions.ManageSettings"/> gate
/// every other AI-platform admin setting in this codebase uses
/// (<c>AiCostPolicyController</c>).
/// </summary>
[ApiController]
[Authorize]
public class AiFeedbackController : ControllerBase
{
    private readonly AiFeedbackExperience _feedback;
    public AiFeedbackController(AiFeedbackExperience feedback) => _feedback = feedback;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);

    private IActionResult Refused(AiFeedbackProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason })
        : refusal.Forbidden ? StatusCode(403, new { error = refusal.Reason })
        : BadRequest(new { error = refusal.Reason });

    [HttpPost("ai/feedback")]
    public async Task<IActionResult> Submit([FromBody] AiFeedbackInput input, CancellationToken ct)
    {
        var (result, refusal) = await _feedback.SubmitAsync(input, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(result);
    }

    [HttpGet("admin/ai-feedback-settings")]
    public async Task<IActionResult> GetSettings(CancellationToken ct)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot view this setting." });
        return Ok(await _feedback.GetSettingsAsync(ct));
    }

    [HttpPut("admin/ai-feedback-settings")]
    public async Task<IActionResult> SaveSettings([FromBody] AiFeedbackSettingsInput input, CancellationToken ct)
    {
        if (!CanManage) return StatusCode(403, new { error = "Your role cannot change this setting." });
        var (dto, refusal) = await _feedback.SaveSettingsAsync(input, User.UserId(), ct);
        return refusal is not null ? Refused(refusal) : Ok(dto);
    }
}

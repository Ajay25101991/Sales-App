using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.Picklists;
using SalesApi.ProcessLayer.Picklists;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>E3.6 — org-managed picklists ("industries", "countries", and any
/// an admin creates for a "picklist"-type custom field). Read: anyone signed
/// in (forms and pickers need it). Write: ManageSettings, same gate every
/// other org-taxonomy screen uses (CustomFieldsController, sources).</summary>
[ApiController]
[Route("picklists")]
[Authorize]
public class PicklistsController : ControllerBase
{
    private readonly PicklistsExperience _picklists;
    public PicklistsController(PicklistsExperience picklists) => _picklists = picklists;

    [HttpGet]
    public async Task<IActionResult> List() => Ok(await _picklists.ListAsync());

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] PicklistInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot manage picklists." });

        var (created, refusal) = await _picklists.CreateAsync(input);
        if (refusal is not null) return Refuse(refusal);
        return StatusCode(201, created);
    }

    [HttpPost("{picklistId:guid}/values")]
    public async Task<IActionResult> AddValue(Guid picklistId, [FromBody] PicklistValueInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot manage picklists." });

        var (created, refusal) = await _picklists.AddValueAsync(picklistId, input);
        if (refusal is not null) return Refuse(refusal);
        return StatusCode(201, created);
    }

    [HttpPatch("values/{valueId:guid}")]
    public async Task<IActionResult> RenameValue(Guid valueId, [FromBody] PicklistValueInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot manage picklists." });

        var (updated, refusal) = await _picklists.RenameValueAsync(valueId, input);
        if (refusal is not null) return Refuse(refusal);
        return Ok(updated);
    }

    [HttpPost("values/{valueId:guid}/archive")]
    public async Task<IActionResult> Archive(Guid valueId)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot manage picklists." });

        var refusal = await _picklists.SetArchivedAsync(valueId, true);
        if (refusal is not null) return Refuse(refusal);
        return NoContent();
    }

    [HttpPost("values/{valueId:guid}/unarchive")]
    public async Task<IActionResult> Unarchive(Guid valueId)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot manage picklists." });

        var refusal = await _picklists.SetArchivedAsync(valueId, false);
        if (refusal is not null) return Refuse(refusal);
        return NoContent();
    }

    /// <summary>Reorder a picklist's values in one call — the settings
    /// screen drags, then saves the whole order, same shape as
    /// CustomFieldsController.Reorder.</summary>
    [HttpPost("{picklistId:guid}/values/reorder")]
    public async Task<IActionResult> Reorder(Guid picklistId, [FromBody] PicklistValueReorderInput input)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot manage picklists." });

        var (reordered, refusal) = await _picklists.ReorderValuesAsync(picklistId, input.Ids);
        if (refusal is not null) return Refuse(refusal);
        return Ok(reordered);
    }

    [HttpDelete("values/{valueId:guid}")]
    public async Task<IActionResult> DeleteValue(Guid valueId)
    {
        if (!User.HasPermission(OrganizationPermissions.ManageSettings)) return StatusCode(403, new { error = "Your role cannot manage picklists." });

        var refusal = await _picklists.DeleteValueAsync(valueId);
        if (refusal is not null) return Refuse(refusal);
        return NoContent();
    }

    private IActionResult Refuse(PicklistProcess.Refusal refusal) =>
        refusal.NotFound ? NotFound(new { error = refusal.Reason })
        : refusal.Conflict ? Conflict(new { error = refusal.Reason })
        : BadRequest(new { error = refusal.Reason });
}

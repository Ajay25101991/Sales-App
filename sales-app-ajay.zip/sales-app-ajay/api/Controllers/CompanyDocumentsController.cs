using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesApi.Dtos;
using SalesApi.ExperienceLayer.CompanyDocuments;
using SalesApi.ProcessLayer.CompanyDocuments;
using SalesApi.Services;

namespace SalesApi.Controllers;

/// <summary>
/// The company documents library (Settings -> Company documents). The admin half needs <c>settings.manage</c>; <c>GET options</c> is open to
/// anyone signed in, because the picker on a send is offered to whoever can email the record (the send itself enforces that). Routes, checks
/// the permission and picks a status code; it touches no _db.
/// </summary>
[ApiController]
[Route("company-documents")]
[Authorize]
public class CompanyDocumentsController : ControllerBase
{
    private readonly CompanyDocumentsExperience _documents;
    public CompanyDocumentsController(CompanyDocumentsExperience documents) => _documents = documents;

    private bool CanManage => User.HasPermission(OrganizationPermissions.ManageSettings);
    private ObjectResult Forbidden => StatusCode(403, new { error = "Your role cannot manage company documents." });

    private IActionResult Respond<T>(CompanyDocumentProcess.Result<T> r, int okStatus = 200) => r.Outcome switch
    {
        CompanyDocumentProcess.Outcome.NotFound => NotFound(new { error = r.Error }),
        CompanyDocumentProcess.Outcome.Invalid => BadRequest(new { error = r.Error }),
        CompanyDocumentProcess.Outcome.Unavailable => StatusCode(503, new { error = r.Error }),
        _ => StatusCode(okStatus, r.Value),
    };

    /// <summary>Admin list: every document with its latest version. <c>?include_archived=true</c> adds the archived ones.</summary>
    [HttpGet]
    public async Task<IActionResult> List([FromQuery(Name = "include_archived")] bool includeArchived, CancellationToken ct) =>
        CanManage ? Ok(await _documents.ListAsync(includeArchived, ct)) : Forbidden;

    /// <summary>The live documents a send can attach: name, category, latest version, size.</summary>
    [HttpGet("options")]
    public async Task<IActionResult> Options(CancellationToken ct) => Ok(await _documents.OptionsAsync(ct));

    [HttpGet("{id:guid}/versions")]
    public async Task<IActionResult> Versions(Guid id, CancellationToken ct) =>
        CanManage ? Respond(await _documents.VersionsAsync(id, ct)) : Forbidden;

    [HttpGet("{id:guid}/download")]
    public async Task<IActionResult> Download(Guid id, [FromQuery] int? version, CancellationToken ct)
    {
        if (!CanManage) return Forbidden;
        var r = await _documents.DownloadAsync(id, version, ct);
        return r.Outcome == CompanyDocumentProcess.Outcome.Ok ? File(r.Value.Bytes, r.Value.ContentType, r.Value.FileName) : Respond(r);
    }

    /// <summary>Multipart: <c>file</c>, optional <c>name</c> (default the file's name), optional <c>category</c>. A new document at version 1 (201).</summary>
    [HttpPost]
    [RequestSizeLimit(CompanyDocumentProcess.MaxBytes + 1024 * 1024)]
    [RequestFormLimits(MultipartBodyLengthLimit = CompanyDocumentProcess.MaxBytes + 1024 * 1024)]
    public async Task<IActionResult> Upload([FromForm] string? name, [FromForm] string? category, IFormFile? file, CancellationToken ct)
    {
        if (!CanManage) return Forbidden;
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required" });
        await using var stream = file.OpenReadStream();
        return Respond(await _documents.UploadAsync(name, category, file.FileName, file.ContentType, stream, file.Length, User.UserId(), ct), 201);
    }

    /// <summary>Multipart: <c>file</c>. Replaces the file: the document keeps its name and gains the next version (201).</summary>
    [HttpPost("{id:guid}/versions")]
    [RequestSizeLimit(CompanyDocumentProcess.MaxBytes + 1024 * 1024)]
    [RequestFormLimits(MultipartBodyLengthLimit = CompanyDocumentProcess.MaxBytes + 1024 * 1024)]
    public async Task<IActionResult> Replace(Guid id, IFormFile? file, CancellationToken ct)
    {
        if (!CanManage) return Forbidden;
        if (file is null || file.Length == 0) return BadRequest(new { error = "file is required" });
        await using var stream = file.OpenReadStream();
        return Respond(await _documents.ReplaceAsync(id, file.FileName, file.ContentType, stream, file.Length, User.UserId(), ct), 201);
    }

    /// <summary>Rename, recategorise (blank clears), archive or restore.</summary>
    [HttpPatch("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateCompanyDocumentInput? input, CancellationToken ct) =>
        CanManage ? Respond(await _documents.UpdateAsync(id, input ?? new UpdateCompanyDocumentInput(), ct)) : Forbidden;
}

using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.CompanyDocuments;

namespace SalesApi.ProcessLayer.CompanyDocuments;

/// <summary>
/// The company documents library: the admin's list / upload / replace / rename / archive, the read list a sender picks from, and the ONE
/// place a send turns picked ids into attachments (<see cref="ResolveAttachmentsAsync"/>, used by <c>DealEmailSender</c> and the record-email
/// compose so the IRL, the engagement letter and the compose all attach by the same rule: the LATEST version, nothing copied into Files).
/// Reads no principal: the controller checks <c>settings.manage</c> for the admin half; the sender half needs only the right to send the email.
/// </summary>
public sealed class CompanyDocumentProcess
{
    /// <summary>A library file is attached to email, so it may be no larger than Graph lets one attachment be.</summary>
    public const long MaxBytes = GraphMailClient.MaxAttachmentBytes;
    public const int MaxNameLength = 200;
    public const int MaxCategoryLength = 100;
    /// <summary>Most documents on one email.</summary>
    public const int MaxPerEmail = 10;

    public enum Outcome { Ok, NotFound, Invalid, Unavailable }

    public sealed record Result<T>(Outcome Outcome, T? Value, string? Error = null);
    private static Result<T> Ok<T>(T value) => new(Outcome.Ok, value);
    private static Result<T> Fail<T>(Outcome o, string error) => new(o, default, error);

    /// <summary>What a send attaches: the files, and the name and version of each for the timeline.</summary>
    internal sealed record Attached(List<GraphAttachment> Files, List<DomainEventPayloads.EmailedDocument> Documents);

    private readonly CompanyDocumentStore _store;
    public CompanyDocumentProcess(CompanyDocumentStore store) => _store = store;

    private static CompanyDocumentDto ToDto(CompanyDocumentStore.Listed l) => new(
        l.Document.Id, l.Document.Name, l.Document.Category, l.Latest.Version, l.Latest.FileName, l.Latest.ContentType, l.Latest.SizeBytes,
        l.Document.UpdatedAt, l.Document.ArchivedAt);

    // ---- admin ------------------------------------------------------------------------------------------------

    public async Task<List<CompanyDocumentDto>> ListAsync(bool includeArchived, CancellationToken ct = default) =>
        [.. (await _store.ListAsync(includeArchived, ct)).Select(ToDto)];

    public async Task<Result<List<CompanyDocumentVersionDto>>> VersionsAsync(Guid id, CancellationToken ct = default)
    {
        if (await _store.FindAsync(id, ct) is null) return Fail<List<CompanyDocumentVersionDto>>(Outcome.NotFound, "Document not found");
        return Ok((await _store.VersionsAsync(id, ct))
            .Select(v => new CompanyDocumentVersionDto(v.Version, v.FileName, v.ContentType, v.SizeBytes, v.UploadedAt, v.UploadedById)).ToList());
    }

    private static string? CheckFile(string? fileName, long length) =>
        string.IsNullOrWhiteSpace(fileName) ? "A file is required."
        : length <= 0 ? "The file is empty."
        : length > MaxBytes ? $"The file is larger than {MaxBytes / (1024 * 1024)} MB, the most an email can carry."
        : null;

    /// <summary>POST /company-documents (multipart). A new document at version 1. The name defaults to the file's name without its extension.</summary>
    public async Task<Result<CompanyDocumentDto>> UploadAsync(
        string? name, string? category, string? fileName, string? contentType, Stream content, long length, Guid? userId, CancellationToken ct = default)
    {
        if (CheckFile(fileName, length) is { } bad) return Fail<CompanyDocumentDto>(Outcome.Invalid, bad);
        var file = Path.GetFileName(fileName!.Trim());
        var shown = string.IsNullOrWhiteSpace(name) ? Path.GetFileNameWithoutExtension(file) : name.Trim();
        if (shown.Length == 0 || shown.Length > MaxNameLength) return Fail<CompanyDocumentDto>(Outcome.Invalid, $"The name must be 1 to {MaxNameLength} characters.");
        var cat = Clean(category);
        if (cat is { Length: > MaxCategoryLength }) return Fail<CompanyDocumentDto>(Outcome.Invalid, $"The category must be at most {MaxCategoryLength} characters.");
        return Ok(ToDto(await _store.AddAsync(shown, cat, file, contentType, content, length, userId, ct)));
    }

    /// <summary>POST /company-documents/{id}/versions (multipart). Replaces the file: a new numbered version; the name stays.</summary>
    public async Task<Result<CompanyDocumentDto>> ReplaceAsync(
        Guid id, string? fileName, string? contentType, Stream content, long length, Guid? userId, CancellationToken ct = default)
    {
        var doc = await _store.FindAsync(id, ct);
        if (doc is null) return Fail<CompanyDocumentDto>(Outcome.NotFound, "Document not found");
        if (doc.ArchivedAt is not null) return Fail<CompanyDocumentDto>(Outcome.Invalid, "This document is archived. Restore it before replacing the file.");
        if (CheckFile(fileName, length) is { } bad) return Fail<CompanyDocumentDto>(Outcome.Invalid, bad);
        var version = await _store.AddVersionAsync(doc, Path.GetFileName(fileName!.Trim()), contentType, content, length, userId, ct);
        return Ok(ToDto(new CompanyDocumentStore.Listed(doc, version)));
    }

    /// <summary>PATCH /company-documents/{id}: rename, recategorise, archive or restore.</summary>
    public async Task<Result<CompanyDocumentDto>> UpdateAsync(Guid id, UpdateCompanyDocumentInput input, CancellationToken ct = default)
    {
        var doc = await _store.FindAsync(id, ct);
        if (doc is null) return Fail<CompanyDocumentDto>(Outcome.NotFound, "Document not found");
        if (input.Name is not null)
        {
            var name = input.Name.Trim();
            if (name.Length == 0 || name.Length > MaxNameLength) return Fail<CompanyDocumentDto>(Outcome.Invalid, $"The name must be 1 to {MaxNameLength} characters.");
            doc.Name = name;
        }
        if (input.Category is not null)
        {
            var cat = Clean(input.Category);
            if (cat is { Length: > MaxCategoryLength }) return Fail<CompanyDocumentDto>(Outcome.Invalid, $"The category must be at most {MaxCategoryLength} characters.");
            doc.Category = cat;
        }
        if (input.Archived is bool archived) doc.ArchivedAt = archived ? doc.ArchivedAt ?? DateTime.UtcNow : null;
        doc.UpdatedAt = DateTime.UtcNow;
        await _store.SaveChangesAsync(ct);
        return Ok(ToDto(new CompanyDocumentStore.Listed(doc, (await _store.LatestAsync(id, ct))!)));
    }

    /// <summary>GET /company-documents/{id}/download[?version=n]: the file (default the latest), for the admin to check what is stored.</summary>
    public async Task<Result<(byte[] Bytes, string ContentType, string FileName)>> DownloadAsync(Guid id, int? version, CancellationToken ct = default)
    {
        if (await _store.FindAsync(id, ct) is null) return Fail<(byte[], string, string)>(Outcome.NotFound, "Document not found");
        var v = version is int n ? await _store.FindVersionAsync(id, n, ct) : await _store.LatestAsync(id, ct);
        if (v is null) return Fail<(byte[], string, string)>(Outcome.NotFound, "Version not found");
        var bytes = await _store.ReadBytesAsync(v, ct);
        return bytes is null
            ? Fail<(byte[], string, string)>(Outcome.Unavailable, "The file is missing from storage.")
            : Ok((bytes, v.ContentType, v.FileName));
    }

    private static string? Clean(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    // ---- the sender's list --------------------------------------------------------------------------------------

    /// <summary>GET /company-documents/options: the live documents, each at its latest version. Open to anyone who can send email.</summary>
    public async Task<List<CompanyDocumentOptionDto>> OptionsAsync(CancellationToken ct = default) =>
        [.. (await _store.ListAsync(false, ct)).Select(l => new CompanyDocumentOptionDto(
            l.Document.Id, l.Document.Name, l.Document.Category, l.Latest.Version, l.Latest.FileName, l.Latest.SizeBytes))];

    // ---- attaching to a send ------------------------------------------------------------------------------------

    /// <summary>
    /// The files for a send: each picked document at its LATEST version (read now, so a replace between picking and sending is honoured), as
    /// attachments named by the stored file name. An archived or unknown id refuses the whole send, rather than sending without it.
    /// Null or empty ids = nothing to attach. Nothing is copied into any record's Files.
    /// </summary>
    internal async Task<Result<Attached>> ResolveAttachmentsAsync(IReadOnlyList<Guid>? ids, CancellationToken ct = default)
    {
        var wanted = (ids ?? []).Distinct().ToList();
        if (wanted.Count == 0) return Ok(new Attached([], []));
        if (wanted.Count > MaxPerEmail) return Fail<Attached>(Outcome.Invalid, $"An email can carry at most {MaxPerEmail} company documents.");
        var found = (await _store.LiveByIdsAsync(wanted, ct)).ToDictionary(l => l.Document.Id);
        var files = new List<GraphAttachment>();
        var named = new List<DomainEventPayloads.EmailedDocument>();
        foreach (var id in wanted)   // in the order the rep picked them
        {
            if (!found.TryGetValue(id, out var l)) return Fail<Attached>(Outcome.Invalid, "A company document you picked is no longer available. Refresh the list and pick again.");
            var bytes = await _store.ReadBytesAsync(l.Latest, ct);
            if (bytes is null) return Fail<Attached>(Outcome.Unavailable, $"\"{l.Document.Name}\" is missing from storage, so the email was not sent.");
            files.Add(new GraphAttachment(l.Latest.FileName, l.Latest.ContentType, bytes));
            named.Add(new DomainEventPayloads.EmailedDocument(l.Document.Name, l.Latest.Version));
        }
        return Ok(new Attached(files, named));
    }
}

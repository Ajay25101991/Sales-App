using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.SystemLayer.AccountingSync;

namespace SalesApi.ProcessLayer.AccountingSync;

/// <summary>
/// The rules for the accounting sync log (E17.3): what "failed" means to a
/// finance user and when a row may be re-queued. The retry only re-queues — the
/// worker's next pass does the push, so pressing retry never blocks a request on
/// an outside system.
/// </summary>
public sealed class AccountingSyncProcess
{
    public const int DefaultLimit = 100;
    public const int MaxLimit = 500;

    private readonly AccountingSyncStore _store;
    public AccountingSyncProcess(AccountingSyncStore store) => _store = store;

    /// <summary>Rows whose last attempt failed — both those still on automatic retry and those that gave up.</summary>
    public async Task<List<AccountingSyncDto>> ListFailedAsync(int? limit, CancellationToken ct = default)
    {
        var take = Math.Clamp(limit ?? DefaultLimit, 1, MaxLimit);
        var rows = await _store.ListAsync(AccountingSyncStatus.Failed, take, ct);
        return rows.Select(ToDto).ToList();
    }

    public sealed record RetryOutcome(AccountingSyncDto? Row, string? Error, bool NotFound)
    {
        public static RetryOutcome Ok(AccountingSyncDto row) => new(row, null, false);
        public static RetryOutcome Missing() => new(null, "Sync record not found.", true);
        public static RetryOutcome Refused(string reason) => new(null, reason, false);
    }

    /// <summary>
    /// Puts a failed row back to pending, due now, with its attempt count reset so
    /// it gets the full retry schedule again. Only a failed row can be retried: a
    /// pending one is already queued and a succeeded one must not be pushed twice.
    /// </summary>
    public async Task<RetryOutcome> RetryAsync(Guid id, DateTime now, CancellationToken ct = default)
    {
        var row = await _store.FindAsync(id, ct);
        if (row is null) return RetryOutcome.Missing();
        if (row.Status != AccountingSyncStatus.Failed)
            return RetryOutcome.Refused(row.Status == AccountingSyncStatus.Succeeded
                ? "This record has already been pushed."
                : "This record is already queued to be pushed.");

        row.Status = AccountingSyncStatus.Pending;
        row.Attempts = 0;
        row.NextAttemptAt = now;
        await _store.SaveAsync(ct);
        return RetryOutcome.Ok(ToDto(row));
    }

    private static AccountingSyncDto ToDto(AccountingSyncLog r) => new(
        r.Id, r.System, r.EntityType, r.EntityId, r.Status, r.Attempts,
        r.LastError, r.LastAttemptAt, r.NextAttemptAt, r.NextAttemptAt != null,
        r.ExternalId, r.SucceededAt, r.CreatedAt);
}

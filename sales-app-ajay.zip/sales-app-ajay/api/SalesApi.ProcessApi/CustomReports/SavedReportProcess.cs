using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.CustomReports;

namespace SalesApi.ProcessLayer.CustomReports;

/// <summary>
/// Custom reports, slice 3 (to-do/report-builder-design.md) — saved reports.
/// Owns three things, same split as <c>SavedViewProcess</c>: (1) validating a
/// definition (delegated to <see cref="CustomReportProcess.ValidateDefinitionAsync"/>,
/// the SAME structural check an ad-hoc run goes through), (2) who may
/// read/write/share/delete a report ("Managers and admins create and share
/// reports. Everyone else can open the reports shared with them." — design
/// doc owner answer 4), (3) CRUD orchestration plus running/exporting a saved
/// report AS THE VIEWER. It never widens access: running or exporting goes
/// through <see cref="CustomReportProcess.RunAsync"/>/<c>ExportCsvAsync</c>
/// with the VIEWER's own <c>RecordAccessContext</c>/showValues/role — the
/// creator's never travels with the saved row (see <c>SavedReport</c>'s own
/// class remarks).
/// </summary>
public sealed class SavedReportProcess
{
    private readonly SavedReportStore _store;
    private readonly CustomReportProcess _reports;

    public SavedReportProcess(SavedReportStore store, CustomReportProcess reports)
    {
        _store = store;
        _reports = reports;
    }

    public sealed record Refusal(string Reason, bool NotFound = false, bool Forbidden = false);

    /// <summary>Everything a caller-scoped decision here needs, gathered once
    /// by the controller — plain values, not a ClaimsPrincipal or
    /// RecordAccessContext, same shape as <c>SavedViewProcess.Caller</c>.
    /// <see cref="IsManager"/> gates create/edit/share/delete (design doc
    /// owner answer 4 — "Managers and admins", i.e. <c>User.IsManager()</c>,
    /// which already covers manager/admin/suntech-admin).
    /// <see cref="TeamIds"/> is the caller's LIVE team roster, same reasoning
    /// as SavedViewStore.LiveTeamIdsForUserAsync: sharing with a team must
    /// reach every member of it regardless of the org's lead-visibility
    /// setting.</summary>
    public sealed record Caller(Guid UserId, bool IsManager, bool IsOrgAdmin, List<Guid> TeamIds, SensitiveAccess? Sensitive = null);

    // -------------------------------------------------------------------
    // Reads
    // -------------------------------------------------------------------

    /// <summary>Mine + shared with a team I'm on + org-wide, not archived.
    /// Available to EVERYONE with the reports permission (the controller's own
    /// gate) — "Everyone else can open the reports shared with them."</summary>
    public async Task<List<SavedReportDto>> ListForMeAsync(Caller caller, CancellationToken ct = default)
    {
        var reports = await _store.ListForUserAsync(caller.UserId, caller.TeamIds, ct);
        if (reports.Count == 0) return [];
        var names = await _store.CreatedByNamesAsync(reports.Select(r => r.CreatedById).Distinct().ToList(), ct);
        return reports.Select(r => ToDto(r, names.GetValueOrDefault(r.CreatedById), CanEdit(caller, r))).ToList();
    }

    public async Task<(SavedReportDto? Dto, Refusal? Refusal)> GetAsync(Caller caller, Guid id, CancellationToken ct = default)
    {
        var report = await _store.ByIdAsync(id, ct);
        if (report is null) return (null, new Refusal("Saved report not found.", NotFound: true));
        if (!CanView(caller, report)) return (null, new Refusal("You do not have access to that saved report.", Forbidden: true));
        var name = await _store.CreatedByNameAsync(report.CreatedById, ct);
        return (ToDto(report, name, CanEdit(caller, report)), null);
    }

    /// <summary>Own, org-wide, or shared with a team I'm currently on — same
    /// visibility ListForUserAsync's WHERE clause encodes.</summary>
    private static bool CanView(Caller caller, SavedReport report)
    {
        if (report.CreatedById == caller.UserId || report.Visibility == SavedReport.Visibilities.Org) return true;
        return report.Visibility == SavedReport.Visibilities.Team
            && report.TeamId is { } tid && caller.TeamIds.Contains(tid);
    }

    /// <summary>Creator, or an org admin — same "admin may edit any view, not
    /// just shared ones" reasoning SavedViewProcess.CanEdit documents (an
    /// admin edit right that evaporates the moment someone flips a report back
    /// to private would make Visibility a way to dodge oversight).</summary>
    private static bool CanEdit(Caller caller, SavedReport report) =>
        report.CreatedById == caller.UserId || caller.IsOrgAdmin;

    // -------------------------------------------------------------------
    // Writes — managers and admins only (design doc owner answer 4)
    // -------------------------------------------------------------------

    public async Task<(SavedReportDto? Created, Refusal? Refusal)> CreateAsync(
        Caller caller, Guid? orgId, string callerRole, SavedReportInput input, CancellationToken ct = default)
    {
        if (!caller.IsManager) return (null, new Refusal("Only a manager or admin may create a saved report.", Forbidden: true));
        if (string.IsNullOrWhiteSpace(input.Name)) return (null, new Refusal("A saved report needs a name."));
        if (input.Definition is not { } definition) return (null, new Refusal("definition is required."));

        var request = ParseRequest(definition);
        if (request is null) return (null, new Refusal("definition could not be read as a report body."));
        // E12: a definition naming a field this caller cannot use in reports (masked / hidden category) is refused, plain 400
        // (not a 404): the person must not be able to save what they could not run.
        if (await _reports.ValidateDefinitionAsync(orgId, callerRole, request, ct, caller.Sensitive) is { } badDefinition)
            return (null, new Refusal(badDefinition.Reason));

        var (visibility, teamId, sharingRefusal) = ResolveSharing(caller, input.Visibility, input.TeamId);
        if (sharingRefusal is not null) return (null, sharingRefusal);

        var report = new SavedReport
        {
            Name = input.Name.Trim(),
            CreatedById = caller.UserId,
            DefinitionJson = definition.GetRawText(),
            Visibility = visibility,
            TeamId = teamId,
        };
        await _store.AddAsync(report, ct);

        var (dto, _) = await GetAsync(caller, report.Id, ct);
        return (dto, null);
    }

    public async Task<(SavedReportDto? Updated, Refusal? Refusal)> UpdateAsync(
        Caller caller, Guid? orgId, string callerRole, Guid id, SavedReportInput input, CancellationToken ct = default)
    {
        var report = await _store.ByIdAsync(id, ct);
        if (report is null) return (null, new Refusal("Saved report not found.", NotFound: true));
        if (!caller.IsManager || !CanEdit(caller, report))
            return (null, new Refusal("Only the creator or an admin may edit this saved report.", Forbidden: true));

        if (input.Name is not null)
        {
            if (string.IsNullOrWhiteSpace(input.Name)) return (null, new Refusal("A saved report needs a name."));
            report.Name = input.Name.Trim();
        }

        if (input.Definition is { } definition)
        {
            var request = ParseRequest(definition);
            if (request is null) return (null, new Refusal("definition could not be read as a report body."));
            if (await _reports.ValidateDefinitionAsync(orgId, callerRole, request, ct, caller.Sensitive) is { } badDefinition)
                return (null, new Refusal(badDefinition.Reason));
            report.DefinitionJson = definition.GetRawText();
        }

        if (input.Visibility is not null || input.TeamId is not null)
        {
            var (visibility, teamId, sharingRefusal) = ResolveSharing(
                caller, input.Visibility ?? report.Visibility, input.TeamId);
            if (sharingRefusal is not null) return (null, sharingRefusal);
            report.Visibility = visibility;
            report.TeamId = teamId;
        }

        await _store.SaveAsync(ct);
        var (dto, _) = await GetAsync(caller, report.Id, ct);
        return (dto, null);
    }

    public async Task<Refusal?> DeleteAsync(Caller caller, Guid id, CancellationToken ct = default)
    {
        var report = await _store.ByIdAsync(id, ct);
        if (report is null) return new Refusal("Saved report not found.", NotFound: true);
        if (!caller.IsManager || !CanEdit(caller, report))
            return new Refusal("Only the creator or an admin may delete this saved report.", Forbidden: true);

        // Archive, not a hard delete (design doc: "DELETE /{id} (archive)") —
        // same "keep the row, hide it from lists" posture as a custom field's
        // own ArchivedAt.
        report.Archived = true;
        await _store.SaveAsync(ct);
        return null;
    }

    // -------------------------------------------------------------------
    // Run / export — always as the VIEWER (never the creator)
    // -------------------------------------------------------------------

    public async Task<(object? Dto, Refusal? Refusal)> RunAsync(
        Caller caller, RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole,
        Guid id, CancellationToken ct = default, ReportViewer? viewer = null)
    {
        var (report, refusal) = await LoadVisibleAsync(caller, id, ct);
        if (refusal is not null) return (null, refusal);

        var request = ParseRequest(JsonDocument.Parse(report!.DefinitionJson).RootElement)!;
        // lenient: true — a saved report still opens even if it now names an
        // archived/hidden field (design doc "Validation" rule); the dropped
        // column shows up in the table response's own DroppedColumns.
        // `viewer` (E18.2): the VIEWER's money / contact permissions, for a report over a non-lead source.
        var (runRefusal, dto) = await _reports.RunAsync(ctx, showValues, orgId, callerRole, request, ct, lenient: true, viewer: viewer);
        return runRefusal is not null ? (null, new Refusal(runRefusal.Reason, runRefusal.NotFound)) : (dto, null);
    }

    public async Task<(string? Csv, Refusal? Refusal)> ExportCsvAsync(
        Caller caller, RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole,
        Guid id, CancellationToken ct = default, ReportViewer? viewer = null)
    {
        var (report, refusal) = await LoadVisibleAsync(caller, id, ct);
        if (refusal is not null) return (null, refusal);

        var request = ParseRequest(JsonDocument.Parse(report!.DefinitionJson).RootElement)!;
        var (exportRefusal, csv) = await _reports.ExportCsvAsync(ctx, showValues, orgId, callerRole, request, ct, lenient: true, viewer: viewer);
        return exportRefusal is not null ? (null, new Refusal(exportRefusal.Reason, exportRefusal.NotFound)) : (csv, null);
    }

    private async Task<(SavedReport? Report, Refusal? Refusal)> LoadVisibleAsync(Caller caller, Guid id, CancellationToken ct)
    {
        var report = await _store.ByIdAsync(id, ct);
        if (report is null) return (null, new Refusal("Saved report not found.", NotFound: true));
        if (!CanView(caller, report)) return (null, new Refusal("You do not have access to that saved report.", Forbidden: true));
        return (report, null);
    }

    // -------------------------------------------------------------------
    // helpers
    // -------------------------------------------------------------------

    /// <summary>Validates visibility/teamId together, same "may only share
    /// into a team you can currently reach" rule SavedViewProcess applies —
    /// otherwise sharing would let someone hand a team's inbox a report its
    /// own members never asked for, from someone outside it.</summary>
    private static (string Visibility, Guid? TeamId, Refusal? Refusal) ResolveSharing(Caller caller, string? visibilityInput, Guid? teamId)
    {
        var visibility = string.IsNullOrWhiteSpace(visibilityInput) ? SavedReport.Visibilities.Private : visibilityInput;
        if (!SavedReport.Visibilities.All.Contains(visibility))
            return (visibility, teamId, new Refusal("visibility must be private, team or org."));

        if (visibility == SavedReport.Visibilities.Team)
        {
            if (teamId is null) return (visibility, null, new Refusal("Choose a team to share this report with."));
            if (!caller.IsOrgAdmin && !caller.TeamIds.Contains(teamId.Value))
                return (visibility, teamId, new Refusal("You can only share a report with a team you are currently on."));
            return (visibility, teamId, null);
        }

        if (teamId is not null)
            return (visibility, teamId, new Refusal("teamId only applies when visibility is 'team'."));
        return (visibility, null, null);
    }

    private static CustomReportRequestDto? ParseRequest(JsonElement definition)
    {
        // Snake case, like the wire the definition was posted in: without the policy `group_by`, `team_id` and the
        // one-table `column_filters` never bound to their properties and were silently lost. A definition written by
        // C# code with the property names as they are (PascalCase) keeps reading as it always did.
        var pascal = definition.ValueKind == JsonValueKind.Object && definition.EnumerateObject().Any(p => p.Name.Length > 0 && char.IsUpper(p.Name[0]));
        try { return JsonSerializer.Deserialize<CustomReportRequestDto>(
            definition.GetRawText(), new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                PropertyNamingPolicy = pascal ? null : JsonNamingPolicy.SnakeCaseLower,
            }); }
        catch (JsonException) { return null; }
    }

    private static SavedReportDto ToDto(SavedReport r, string? createdByName, bool canEdit) => new(
        r.Id, r.Name, ParseDefinition(r.DefinitionJson), r.Visibility, r.TeamId,
        r.CreatedById, createdByName, r.Archived, r.CreatedAt, r.UpdatedAt, canEdit);

    private static readonly JsonElement EmptyObject = JsonDocument.Parse("{}").RootElement;

    private static JsonElement ParseDefinition(string json)
    {
        try { using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(json) ? "{}" : json); return doc.RootElement.Clone(); }
        catch (JsonException) { return EmptyObject; }
    }
}

using System.Linq.Expressions;
using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.Services.Paging;
using SalesApi.Services.TableQuery;
using SalesApi.SystemLayer.CustomReports;

namespace SalesApi.ProcessLayer.CustomReports;

/// <summary>
/// Custom reports, slice 1 (to-do/report-builder-design.md): the breakdown
/// engine. Groups the caller's VISIBLE leads by one builtin field or one
/// dropdown/picklist/multi-select custom field, with the same five metric
/// groups every other value report in this codebase computes — leads, open,
/// won, lost, win rate — each dated per the design doc's own rule:
///
///   - Leads: created in the filter range.
///   - Won / lost: closed (WonAt/LostAt) in the filter range.
///   - Open: open RIGHT NOW, on the lead's OWN playbook, ignoring the range
///     entirely — same reasoning ReportsProcess.RepAsync's OpenLeads already
///     follows.
///
/// VALUE MASKING is the same rule as every other report here: a caller without
/// lead_values.view gets NULL money figures, never zero (see ReportsProcess's
/// own remarks) — `showValues` arrives as DATA, decided by the controller.
///
/// MULTI-SELECT group-by: a lead with N selected values lands in N rows (so
/// per-row sums are not comparable across rows — <c>MultiValue</c> on the
/// result says so), but TOTALS are computed over DISTINCT leads in one pass —
/// <c>CustomReportStore.BreakdownTotalsAsync</c> vs the per-key rows from
/// <c>CustomReportStore.BreakdownByMultiSelectAsync</c> (both SQL).
/// </summary>
public sealed class CustomReportProcess
{
    private const string NoneKey = "(none)";

    private readonly CustomReportStore _store;
    private readonly OrgSettingsReader _orgSettings;
    private readonly ReportingCalendarService _reportingCalendar;
    private readonly PlaybookPhaseLoader _phaseLoader;
    private readonly PipelineStages _stages;

    private readonly SalesApi.SystemLayer.Leads.LeadStore _leads;
    private readonly SearchCapabilities _search;
    private readonly ReportSourceRegistry? _sources;

    // `leads` (the column option lists the results table's headings offer) and `search` (whether a typo-tolerant text
    // filter can run) are optional, like TaskProcess's: DI always supplies the real ones; hand-built test chains that
    // never use the table's headings do not have to. `sources` (E18.2, the non-lead report sources) is optional the same way:
    // without it only the leads source exists.
    public CustomReportProcess(
        CustomReportStore store, OrgSettingsReader orgSettings,
        ReportingCalendarService reportingCalendar, PlaybookPhaseLoader phaseLoader, PipelineStages stages,
        SalesApi.SystemLayer.Leads.LeadStore? leads = null, SearchCapabilities? search = null,
        ReportSourceRegistry? sources = null)
    {
        _store = store;
        _orgSettings = orgSettings;
        _reportingCalendar = reportingCalendar;
        _phaseLoader = phaseLoader;
        _stages = stages;
        _leads = leads!;
        _search = search ?? new SearchCapabilities();
        _sources = sources;
    }

    private static readonly string[] BuiltinKeys = ["owner", "team", "stage", "source", "deal_type", "account_industry", "account_status"];

    // E18.2: the deal's ACCOUNT fields as lead columns and group-bys. Built-in ones are keyed like any built-in column; an account
    // custom field is its own kind ("account_custom_field") and its column key is "account_custom:<key>", so it can never collide
    // with a lead custom field of the same key.
    private const string AccountCustomKind = "account_custom_field";
    private const string AccountCustomPrefix = ReportTableColumns.AccountCustomPrefix;
    private static readonly string[] AccountBuiltinKeys = ["account_industry", "account_status"];

    public sealed record Refusal(string Reason, bool NotFound = false);

    // --- POST /reports/custom/run & /reports/custom/export ---------------------

    /// <summary><paramref name="Dto"/> is a <see cref="CustomReportResultDto"/>
    /// for breakdown mode, or a <see cref="CustomReportTableResultDto"/> for
    /// table mode — the two modes return different SHAPES by design (the
    /// design doc gives each its own response), so this stays <c>object</c>
    /// rather than forcing one envelope on both. <paramref name="lenient"/>
    /// true is the ONE path a saved report's own run/export takes
    /// (<c>SavedReportProcess</c>): an unknown/hidden column is DROPPED
    /// (<see cref="CustomReportTableResultDto.DroppedColumns"/>) instead of
    /// refusing the whole report, per the design doc's "a saved report...
    /// still opens, dropping that column" rule. An ad-hoc request from
    /// <c>POST /reports/custom/run</c> is always strict.</summary>
    /// <remarks><paramref name="viewer"/> (E18.2) is what the caller may do with money and contact data, for the non-lead
    /// sources; null means none of it. The lead source reads only <paramref name="showValues"/>, as before.</remarks>
    public async Task<(Refusal? Refusal, object? Dto)> RunAsync(
        RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole,
        CustomReportRequestDto request, CancellationToken ct = default, bool lenient = false, ReportViewer? viewer = null)
    {
        var (refusal, built) = await BuildAsync(ctx, showValues, orgId, callerRole, request, lenient, ct, viewer: viewer);
        return (refusal, built?.Dto);
    }

    public async Task<(Refusal? Refusal, string? Csv)> ExportCsvAsync(
        RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole,
        CustomReportRequestDto request, CancellationToken ct = default, bool lenient = false, ReportViewer? viewer = null)
    {
        var (refusal, built) = await BuildAsync(ctx, showValues, orgId, callerRole, request, lenient, ct, forExport: true, viewer: viewer);
        if (refusal is not null || built is null) return (refusal, null);

        return (null, built.Dto switch
        {
            CustomReportResultDto breakdown => BreakdownCsv(breakdown, showValues),
            CustomReportTableResultDto table => TableCsv(table),
            CustomReportSourceResultDto sourceBreakdown => SourceBreakdownCsv(sourceBreakdown),
            CustomReportSourceTableDto sourceTable => SourceTableCsv(sourceTable),
            _ => throw new InvalidOperationException("Unreachable: BuildAsync only ever returns one of the Dto shapes above."),
        });
    }

    /// <summary>Same rows and totals as the screen (design doc's own rule), as
    /// CSV. Money columns are OMITTED entirely when values are not visible —
    /// never zeroed — the same posture GET /reports/leaderboard/export
    /// already takes (a masked zero and a real zero are the same character in
    /// a spreadsheet).</summary>
    private static string BreakdownCsv(CustomReportResultDto dto, bool showValues)
    {
        var header = showValues
            ? new[] { "key", "label", "leads", "open_count", "open_value", "won_count", "won_value", "lost_count", "lost_value", "win_rate" }
            : new[] { "key", "label", "leads", "open_count", "won_count", "lost_count", "win_rate" };

        IEnumerable<string?> RowCells(CustomReportRow r) => showValues
            ? [r.Key, r.Label, r.Leads.ToString(), r.OpenCount.ToString(), r.OpenValue?.ToString(System.Globalization.CultureInfo.InvariantCulture),
               r.WonCount.ToString(), r.WonValue?.ToString(System.Globalization.CultureInfo.InvariantCulture),
               r.LostCount.ToString(), r.LostValue?.ToString(System.Globalization.CultureInfo.InvariantCulture),
               r.WinRate?.ToString(System.Globalization.CultureInfo.InvariantCulture)]
            : [r.Key, r.Label, r.Leads.ToString(), r.OpenCount.ToString(), r.WonCount.ToString(), r.LostCount.ToString(),
               r.WinRate?.ToString(System.Globalization.CultureInfo.InvariantCulture)];

        var rows = new List<IEnumerable<string?>> { header };
        rows.AddRange(dto.Rows.Select(RowCells));
        rows.Add(RowCells(dto.Totals));
        return SalesApi.Services.CsvUtil.ToCsvSafe(rows);
    }

    /// <summary>Table mode export: every matching row (design doc: "ALL rows
    /// ... no paging cap"), the SAME columns the screen requested — built via
    /// <see cref="CustomReportStore.AllTableLeadsAsync"/>, not the paged
    /// <see cref="CustomReportTableResultDto.Rows"/> the screen call already
    /// returned (export is its own fetch, always unpaged).</summary>
    private string TableCsv(CustomReportTableResultDto dto) =>
        ValuesCsv(dto.Columns, dto.Rows.Select(r => r.Values));

    /// <summary>The one writer behind every table CSV (leads and the E18.2 sources): the screen's columns, then each row's values.</summary>
    private static string ValuesCsv(List<CustomReportTableColumnDto> columns, IEnumerable<Dictionary<string, object?>> values)
    {
        var header = columns.Select(c => c.Key).ToArray();
        var rows = new List<IEnumerable<string?>> { header };
        rows.AddRange(values.Select(v => columns.Select(c => FormatCsvCell(v.GetValueOrDefault(c.Key)))));
        return SalesApi.Services.CsvUtil.ToCsvSafe(rows);
    }

    private static string SourceTableCsv(CustomReportSourceTableDto dto) =>
        ValuesCsv(dto.Columns, dto.Rows.Select(r => r.Values));

    /// <summary>A non-lead breakdown as the screen shows it: key, label, count and (when a sum field was chosen) its sum, then the totals row.</summary>
    private static string SourceBreakdownCsv(CustomReportSourceResultDto dto)
    {
        var withSum = dto.SumField is not null;
        IEnumerable<string?> Cells(CustomReportSourceRow r) => withSum
            ? [r.Key, r.Label, r.Count.ToString(), r.Sum?.ToString(System.Globalization.CultureInfo.InvariantCulture)]
            : [r.Key, r.Label, r.Count.ToString()];
        var rows = new List<IEnumerable<string?>> { withSum ? new[] { "key", "label", "count", dto.SumField } : new[] { "key", "label", "count" } };
        rows.AddRange(dto.Rows.Select(Cells));
        rows.Add(Cells(dto.Totals));
        return SalesApi.Services.CsvUtil.ToCsvSafe(rows);
    }

    private static string? FormatCsvCell(object? value) => value switch
    {
        null => null,
        DateTime dt => dt.ToString("O", System.Globalization.CultureInfo.InvariantCulture),
        decimal dec => dec.ToString(System.Globalization.CultureInfo.InvariantCulture),
        bool b => b ? "true" : "false",
        List<string> list => string.Join(";", list),
        _ => value.ToString(),
    };

    private sealed record Built(object Dto);

    private async Task<(Refusal? Refusal, Built? Built)> BuildAsync(
        RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole,
        CustomReportRequestDto request, bool lenient, CancellationToken ct, bool forExport = false, ReportViewer? viewer = null)
    {
        if (!string.Equals(request.Source, "leads", StringComparison.OrdinalIgnoreCase))
        {
            if (_sources?.Find(request.Source) is not { } source) return (new Refusal(UnknownSourceMessage()), null);
            var (sourceRefusal, sourceDto) = await BuildSourceAsync(source, ctx, orgId, callerRole, viewer, request, lenient, forExport, ct);
            return sourceRefusal is not null ? (sourceRefusal, null) : (null, new Built(sourceDto!));
        }

        if (string.Equals(request.Mode, "table", StringComparison.OrdinalIgnoreCase))
        {
            var (tableRefusal, tableDto) = await BuildTableAsync(ctx, showValues, orgId, callerRole, request, lenient, forExport, ct);
            return tableRefusal is not null ? (tableRefusal, null) : (null, new Built(tableDto!));
        }

        if (!string.Equals(request.Mode, "breakdown", StringComparison.OrdinalIgnoreCase))
            return (new Refusal("mode must be \"breakdown\" or \"table\"."), null);

        var (breakdownRefusal, breakdownDto) = await BuildBreakdownAsync(ctx, showValues, orgId, callerRole, request, ct);
        return breakdownRefusal is not null ? (breakdownRefusal, null) : (null, new Built(breakdownDto!));
    }

    private async Task<(Refusal? Refusal, CustomReportResultDto? Dto)> BuildBreakdownAsync(
        RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole,
        CustomReportRequestDto request, CancellationToken ct)
    {
        if (request.GroupBy is null || string.IsNullOrWhiteSpace(request.GroupBy.Key))
            return (new Refusal("group_by.key is required."), null);
        var kind = request.GroupBy.Kind;
        if (kind != "builtin" && kind != "custom_field" && kind != AccountCustomKind)
            return (new Refusal("group_by.kind must be \"builtin\", \"custom_field\" or \"account_custom_field\"."), null);

        CustomFieldDef? fieldDef = null;
        var isCustomField = kind == "custom_field";
        // E18.2: the deal's account custom field. Grouped exactly like a single-valued lead custom field, through the account the
        // lead points at; a lead with no account lands in "(none)".
        var isAccountCustom = kind == AccountCustomKind;
        if (isCustomField || isAccountCustom)
        {
            fieldDef = await _store.CustomFieldDefByKeyAsync(
                orgId, request.GroupBy.Key, ct, isAccountCustom ? CustomFieldDef.ObjectTypes.Account : CustomFieldDef.ObjectTypes.Lead);
            if (fieldDef is null) return (new Refusal($"Unknown custom field '{request.GroupBy.Key}'.", NotFound: true), null);
            if (!CustomFieldMasking.UsableInReports(fieldDef, callerRole, ctx.Sensitive))
                return (new Refusal($"Unknown custom field '{request.GroupBy.Key}'.", NotFound: true), null);
            if (isAccountCustom && fieldDef.Type == "multi_select")
                return (new Refusal("A multi-select account field cannot be grouped by."), null);
        }
        else if (!BuiltinKeys.Contains(request.GroupBy.Key))
        {
            return (new Refusal($"group_by.key must be one of: {string.Join(", ", BuiltinKeys)}."), null);
        }

        var filters = request.Filters;
        var cal = await _reportingCalendar.ForAsync(orgId);
        // Org-local day boundaries, not raw UTC midnight — same ReportingCalendar
        // StartOfDayUtc/EndOfDayUtc pair every other date-ranged report in this
        // codebase uses (see ReportingCalendar's own class remarks on why a
        // report boundary must be the ORG's day, not UTC's).
        DateTime? fromUtc = filters?.From is { } f ? ReportingCalendar.StartOfDayUtc(cal, DateOnly.FromDateTime(f)) : null;
        DateTime? toUtc = filters?.To is { } t ? ReportingCalendar.EndOfDayUtc(cal, DateOnly.FromDateTime(t)) : null;

        var phases = await _phaseLoader.LoadAllAsync(ct);

        // MULTI-SELECT: one lead can land in several buckets (every selected
        // value) — aggregated via CustomReportStore.BreakdownByMultiSelectAsync,
        // which unnests the stored jsonb array server-side (LEFT JOIN LATERAL),
        // same as every other group-by kind below. No leads list is ever
        // fetched into memory for this any more.
        var isMultiSelect = isCustomField && fieldDef!.Type == "multi_select";

        // Label lookups, resolved once regardless of how many distinct keys turn
        // up (cheap: one query per builtin, not per bucket).
        Dictionary<Guid, string> ownerNames = [];
        Dictionary<Guid, string> teamNames = [];
        Dictionary<string, string> stageLabels = [];
        Dictionary<string, string> customValueLabels = [];
        string groupByLabel;
        // A built-in key (owner, team, ..., account_industry): neither kind of custom field.
        var isBuiltin = !isCustomField && !isAccountCustom;

        if (isBuiltin)
        {
            switch (request.GroupBy.Key)
            {
                case "account_industry":
                    groupByLabel = "Account industry";
                    break;
                case "account_status":
                    // The org's account-status list: the stored key shows as its label.
                    customValueLabels = await _store.AccountStatusLabelsAsync(ct);
                    groupByLabel = "Account status";
                    break;
                case "owner":
                    ownerNames = (await _store.ProfilesAsync(orgId, ct))
                        .Where(p => !string.IsNullOrEmpty(p.FullName))
                        .ToDictionary(p => p.Id, p => p.FullName!);
                    groupByLabel = "Owner";
                    break;
                case "team":
                    teamNames = (await _store.TeamsAsync(orgId, ct)).ToDictionary(t => t.Id, t => t.Name);
                    groupByLabel = "Team";
                    break;
                case "stage":
                    // The ORG's default stage labels. A lead's own playbook can
                    // define a different label for the same status key, but the
                    // design doc's per-playbook rule binds OPEN/WON/LOST phase
                    // detection (handled below via PlaybookPhases), not which
                    // label this breakdown prints for a raw status key shared by
                    // leads on different playbooks — resolving one label per
                    // DISTINCT status actually present, per its own lead's
                    // playbook, is a reasonable follow-up but out of scope here.
                    // Falls back to the raw key when the org list doesn't name it.
                    stageLabels = await _stages.LabelsAsync();
                    groupByLabel = "Stage";
                    break;
                case "source":
                    groupByLabel = "Source";
                    break;
                default: // "deal_type"
                    groupByLabel = "Deal type";
                    break;
            }
        }
        else
        {
            groupByLabel = fieldDef!.Label;
            if (fieldDef.Type == "picklist" && fieldDef.PicklistKey is not null)
            {
                var values = await _store.PicklistValuesAsync(fieldDef.PicklistKey, ct);
                customValueLabels = values.ToDictionary(v => v.Value, v => v.Label, StringComparer.OrdinalIgnoreCase);
            }
            else
            {
                // dropdown/select/multi_select: Options IS the value and the
                // label (CustomFieldDef.Options remarks) — identity map.
                customValueLabels = fieldDef.Options.ToDictionary(o => o, o => o, StringComparer.OrdinalIgnoreCase);
            }
        }

        string Label(string key) => key == NoneKey ? NoneKey
            : request.GroupBy.Key switch
            {
                "owner" when isBuiltin => Guid.TryParse(key, out var oid) ? ownerNames.GetValueOrDefault(oid, key) : key,
                "team" when isBuiltin => Guid.TryParse(key, out var tid) ? teamNames.GetValueOrDefault(tid, key) : key,
                "stage" when isBuiltin => stageLabels.GetValueOrDefault(key, key),
                "account_status" when isBuiltin => customValueLabels.GetValueOrDefault(key, key),
                _ when isCustomField || isAccountCustom => customValueLabels.GetValueOrDefault(key, key),
                _ => key,
            };

        var buckets = new Dictionary<string, Bucket>();
        if (isMultiSelect)
        {
            // One GROUP BY query over the unnested jsonb array, aggregated by
            // Postgres (CustomReportStore.BreakdownByMultiSelectAsync) — same
            // shape as the MergeAsync branches below, just with a nullable SQL
            // key (a lead with no value) normalised to NoneKey here instead of
            // inside the store.
            var sqlRows = await _store.BreakdownByMultiSelectAsync(
                ctx, filters?.TeamId, filters?.OwnerId, filters?.Source, filters?.Stage, filters?.Custom,
                fieldDef!.Key, phases, fromUtc, toUtc, ct);
            foreach (var r in sqlRows)
            {
                var key = string.IsNullOrWhiteSpace(r.Key) ? NoneKey : r.Key;
                if (!buckets.TryGetValue(key, out var b)) buckets[key] = b = new Bucket();
                b.Leads += r.Leads;
                b.OpenCount += r.OpenCount; b.OpenValue += r.OpenValue;
                b.WonCount += r.WonCount; b.WonValue += r.WonValue;
                b.LostCount += r.LostCount; b.LostValue += r.LostValue;
            }
        }
        else
        {
            // Every other kind: one GROUP BY query, aggregated by Postgres
            // (CustomReportStore.BreakdownByAsync) — never a C# fold over every
            // lead. The raw group key is normalised to the display key
            // ("(none)", DealType's "new" sentinel, …) and merged here, the
            // SAME normalisation KeysFor used to apply per-lead, now applied
            // per (already-aggregated) SQL row instead — merging two SQL
            // groups that normalise to the same display key (e.g. a null and
            // an empty-string Source) by ADDING their already-summed figures,
            // never by re-counting a lead.
            async Task MergeAsync<TKey>(Expression<Func<Lead, TKey>> keySelector, Func<TKey, string> normalize)
            {
                var sqlRows = await _store.BreakdownByAsync(
                    ctx, filters?.TeamId, filters?.OwnerId, filters?.Source, filters?.Stage, filters?.Custom,
                    keySelector, phases, fromUtc, toUtc, ct);
                foreach (var r in sqlRows)
                {
                    var key = normalize(r.Key);
                    if (!buckets.TryGetValue(key, out var b)) buckets[key] = b = new Bucket();
                    b.Leads += r.Leads;
                    b.OpenCount += r.OpenCount; b.OpenValue += r.OpenValue;
                    b.WonCount += r.WonCount; b.WonValue += r.WonValue;
                    b.LostCount += r.LostCount; b.LostValue += r.LostValue;
                }
            }

            // A deal the viewer can see whose ACCOUNT they cannot has no account value: it falls in "(none)", like a deal with no account.
            var accountViewable = TeamScopedQueries.AccountViewable(ctx);
            if (isAccountCustom)
            {
                // E18.2: the deal's account custom field, through the lead's account (a lead with no account is "(none)").
                var accountFieldKey = fieldDef!.Key;
                await MergeAsync<string?>(
                    AccountVisibility.Through<string?>(a => JsonTextExtract.Value(a.Custom, accountFieldKey), accountViewable, null),
                    k => string.IsNullOrWhiteSpace(k) ? NoneKey : k);
            }
            else if (isBuiltin)
            {
                switch (request.GroupBy.Key)
                {
                    case "account_industry":
                        await MergeAsync<string?>(AccountVisibility.Through<string?>(a => a.Industry, accountViewable, null), k => string.IsNullOrWhiteSpace(k) ? NoneKey : k);
                        break;
                    case "account_status":
                        await MergeAsync<string?>(AccountVisibility.Through<string?>(a => a.Status, accountViewable, null), k => string.IsNullOrWhiteSpace(k) ? NoneKey : k);
                        break;
                    case "owner":
                        await MergeAsync<Guid?>(l => l.OwnerId, k => k?.ToString() ?? NoneKey);
                        break;
                    case "team":
                        await MergeAsync<Guid?>(l => l.TeamId, k => k?.ToString() ?? NoneKey);
                        break;
                    case "stage":
                        await MergeAsync<string>(l => l.Status, k => k ?? NoneKey);
                        break;
                    case "source":
                        await MergeAsync<string?>(l => l.Source, k => string.IsNullOrEmpty(k) ? NoneKey : k);
                        break;
                    default: // "deal_type" — DealStatsService.DealTypeKey's own sentinel; never buckets as "(none)"
                        await MergeAsync<string>(l => l.DealType ?? "new", k => k);
                        break;
                }
            }
            else
            {
                // Single-valued custom field (dropdown/select/picklist, or any
                // other non-multi_select type): extracted via the same
                // jsonb_extract_path_text-backed DbFunction table mode's own
                // custom-field sort already uses (JsonTextExtract), so this
                // stays one translated GROUP BY, not a per-lead jsonb parse.
                await MergeAsync<string?>(
                    l => JsonTextExtract.Value(l.Custom, fieldDef!.Key),
                    k => string.IsNullOrWhiteSpace(k) ? NoneKey : k);
            }
        }

        var rows = buckets
            .Select(kv => ToRow(kv.Key, Label(kv.Key), kv.Value, showValues))
            .OrderBy(r => r.Key == NoneKey ? 1 : 0).ThenBy(r => r.Label, StringComparer.OrdinalIgnoreCase)
            .ToList();

        // TOTALS: one aggregate query over DISTINCT leads (CustomReportStore.
        // BreakdownTotalsAsync), never a sum of the rows above and never a
        // second C# pass over `leads` — a multi-select group-by counts the
        // same lead in every selected row, so summing rows would double- (or
        // N-) count it; see the design doc's own "totals then are NOT the sum
        // of rows" rule. Totals never depend on the group-by dimension, so
        // this runs unconditionally, multi-select included.
        var totalsRow = await _store.BreakdownTotalsAsync(
            ctx, filters?.TeamId, filters?.OwnerId, filters?.Source, filters?.Stage, filters?.Custom,
            phases, fromUtc, toUtc, ct);
        var totalsBucket = new Bucket
        {
            Leads = totalsRow.Leads,
            OpenCount = totalsRow.OpenCount, OpenValue = totalsRow.OpenValue,
            WonCount = totalsRow.WonCount, WonValue = totalsRow.WonValue,
            LostCount = totalsRow.LostCount, LostValue = totalsRow.LostValue,
        };
        var totals = ToRow("_totals", "Total", totalsBucket, showValues);

        var multiValue = isMultiSelect;
        return (null, new CustomReportResultDto(groupByLabel, rows, totals, showValues, multiValue));
    }

    // --- E18.2: the non-lead sources ---------------------------------------------
    //
    // Leads keep the engine above. Every other source (accounts, contacts, invoices, payments, AMC renewal terms) is a
    // ReportSource<T> in the System layer: this section only turns a request into the source's query, the source's answer into
    // the wire shape, and a refusal into a Refusal. Breakdown = count plus the sum of the chosen field; table = the chosen
    // columns; the CSV is written from the SAME dto the screen gets.

    private string UnknownSourceMessage() => _sources is null
        ? "source must be \"leads\" — the only source in this slice."
        : $"source must be one of: leads, {string.Join(", ", _sources.All.Select(s => s.Key))}.";

    private static ReportSourceCaller SourceCaller(
        RecordAccessContext? ctx, ReportViewer? viewer, Guid? orgId, string role, SensitiveAccess? sensitive = null) =>
        new(ctx, viewer ?? new ReportViewer(false, false, false), orgId, role, sensitive ?? ctx?.Sensitive);

    private async Task<ReportSourceQuery> SourceQueryAsync(CustomReportRequestDto request, Guid? orgId)
    {
        var filters = request.Filters;
        var cal = await _reportingCalendar.ForAsync(orgId);
        DateTime? fromUtc = filters?.From is { } f ? ReportingCalendar.StartOfDayUtc(cal, DateOnly.FromDateTime(f)) : null;
        DateTime? toUtc = filters?.To is { } t ? ReportingCalendar.EndOfDayUtc(cal, DateOnly.FromDateTime(t)) : null;

        // The request's one legacy `sort` becomes a heading sort when there are no `sorts`.
        List<TableSortDto> sorts = request.Sorts ?? [];
        if (sorts.Count == 0 && request.Sort is { } legacy) sorts = [new TableSortDto(legacy.Key, legacy.Dir)];
        var context = new FilterContext(
            cal, DateTime.UtcNow, _search.TrgmEnabled, _search.LevenshteinEnabled, FuzzySearch.DefaultSimilarityThreshold);
        return new ReportSourceQuery(fromUtc, toUtc, filters?.OwnerId, filters?.TeamId, ColumnFiltersOf(request), sorts, context);
    }

    private async Task<(Refusal? Refusal, object? Dto)> BuildSourceAsync(
        IReportSource source, RecordAccessContext ctx, Guid? orgId, string callerRole, ReportViewer? viewer,
        CustomReportRequestDto request, bool lenient, bool forExport, CancellationToken ct)
    {
        var caller = SourceCaller(ctx, viewer, orgId, callerRole);
        var moneyVisible = caller.Viewer.ViewAccountFinancials;
        try
        {
            var query = await SourceQueryAsync(request, orgId);

            if (string.Equals(request.Mode, "table", StringComparison.OrdinalIgnoreCase))
            {
                if (request.Columns is not { Count: > 0 })
                    return (new Refusal("columns must include at least one column."), null);
                var columnKeys = request.Columns.Select(c => c.Key).ToList();

                var limit = request.Limit is > 0 and <= 500 ? request.Limit!.Value : 50;
                // The cursor is the same opaque "offset" payload leads' table mode uses, bound to everything that changes which rows
                // match or in what order.
                var fingerprint = CursorToken.Fingerprint(
                    JsonSerializer.Serialize(request.Filters), JsonSerializer.Serialize(query.Filters),
                    JsonSerializer.Serialize(query.Sorts), JsonSerializer.Serialize(columnKeys), limit.ToString());
                var decoded = CursorToken.Decode(request.Cursor);
                if (!string.IsNullOrEmpty(request.Cursor) && (decoded is null || decoded.Filters != fingerprint))
                    return (new Refusal("Your cursor is stale — reload the first page."), null);
                var offset = forExport ? 0 : decoded?.Offset ?? 0;

                // EXPORT: every matching row, no paging cap (limit 0), through the very call the screen makes.
                var table = await source.TableAsync(caller, query, columnKeys, offset, forExport ? 0 : limit + 1, lenient, ct);
                var rows = table.Rows;
                var hasMore = !forExport && rows.Count > limit;
                if (hasMore) rows = rows.Take(limit).ToList();

                var next = hasMore
                    ? CursorToken.Encode(new CursorPayload("offset", fingerprint, query.Sorts.FirstOrDefault()?.Field ?? "", null, offset + limit))
                    : null;
                return (null, new CustomReportSourceTableDto(
                    table.Columns.Select(f => new CustomReportTableColumnDto(f.Key, f.Label, f.Type)).ToList(),
                    rows.Select(r => new CustomReportSourceRowDto(r.Id, r.Values)).ToList(),
                    next, table.TotalCount, moneyVisible, table.Dropped));
            }

            if (!string.Equals(request.Mode, "breakdown", StringComparison.OrdinalIgnoreCase))
                return (new Refusal("mode must be \"breakdown\" or \"table\"."), null);
            if (request.GroupBy is null || string.IsNullOrWhiteSpace(request.GroupBy.Key))
                return (new Refusal("group_by.key is required."), null);

            var b = await source.BreakdownAsync(caller, query, request.GroupBy.Key, request.SumField, lenient, ct);

            // A blank key is the "(none)" bucket, like every other breakdown; two blank spellings (null, "") merge by adding.
            var buckets = new Dictionary<string, (string Label, int Count, decimal Sum)>();
            foreach (var r in b.Rows)
            {
                var key = string.IsNullOrWhiteSpace(r.Key) ? NoneKey : r.Key;
                var label = key == NoneKey ? NoneKey : string.IsNullOrWhiteSpace(r.Label) ? key : r.Label;
                buckets[key] = buckets.TryGetValue(key, out var cur)
                    ? (cur.Label, cur.Count + r.Count, cur.Sum + r.Sum)
                    : (label, r.Count, r.Sum);
            }
            decimal? Sum(decimal v) => b.SumKey is null ? null : v;
            var sourceRows = buckets
                .Select(kv => new CustomReportSourceRow(kv.Key, kv.Value.Label, kv.Value.Count, Sum(kv.Value.Sum)))
                .OrderBy(r => r.Key == NoneKey ? 1 : 0).ThenBy(r => r.Label, StringComparer.OrdinalIgnoreCase)
                .ToList();
            var totals = new CustomReportSourceRow("_totals", "Total", b.Totals.Count, Sum(b.Totals.Sum));
            return (null, new CustomReportSourceResultDto(b.GroupByLabel, sourceRows, totals, moneyVisible, false, b.SumKey, b.SumLabel));
        }
        catch (ReportSourceRefusedException e)
        {
            return (new Refusal(e.Message, e.NotFound), null);
        }
        catch (TableQueryRefusedException e)
        {
            return (new Refusal(e.Message), null);
        }
    }

    /// <summary>The definition check for a non-lead source (a saved report is validated when saved, before any viewer runs it):
    /// every field it names must be one the source offers, used the way the source offers it.</summary>
    private async Task<Refusal?> ValidateSourceAsync(
        IReportSource source, Guid? orgId, string callerRole, CustomReportRequestDto request, SensitiveAccess? sensitive, CancellationToken ct)
    {
        var fields = await source.FieldsAsync(new ReportSourceCaller(null, ReportViewer.Everything, orgId, callerRole, sensitive), ct) ?? [];
        var byKey = fields.ToDictionary(f => f.Key, StringComparer.Ordinal);

        if (string.Equals(request.Mode, "table", StringComparison.OrdinalIgnoreCase))
        {
            if (request.Columns is not { Count: > 0 })
                return new Refusal("columns must include at least one column.");
            foreach (var col in request.Columns)
                if (!byKey.ContainsKey(col.Key)) return new Refusal($"'{col.Key}' is not a column this report returns.", NotFound: true);
            if (request.Sort is { } sort && !(byKey.TryGetValue(sort.Key, out var sf) && sf.Sortable))
                return new Refusal($"'{sort.Key}' is not a column this report can sort by.");
            foreach (var f in ColumnFiltersOf(request))
                if (!(byKey.TryGetValue(f.Field, out var ff) && ff.Filterable)) return new Refusal($"There is no '{f.Field}' column to filter by.");
            foreach (var s in request.Sorts ?? [])
                if (!(byKey.TryGetValue(s.Field, out var sf2) && sf2.Sortable)) return new Refusal($"There is no '{s.Field}' column to sort by.");
            return null;
        }

        if (!string.Equals(request.Mode, "breakdown", StringComparison.OrdinalIgnoreCase))
            return new Refusal("mode must be \"breakdown\" or \"table\".");
        if (request.GroupBy is null || string.IsNullOrWhiteSpace(request.GroupBy.Key))
            return new Refusal("group_by.key is required.");
        if (!(byKey.TryGetValue(request.GroupBy.Key, out var g) && g.Groupable))
            return new Refusal($"'{request.GroupBy.Key}' cannot be grouped by.", NotFound: !byKey.ContainsKey(request.GroupBy.Key));
        if (!string.IsNullOrEmpty(request.SumField) && !(byKey.TryGetValue(request.SumField, out var sum) && sum.Summable))
            return new Refusal($"'{request.SumField}' is not a number or money field you can sum.");
        return null;
    }

    /// <summary>GET /reports/custom/sources: every source this caller may report over, with its fields. Leads list their group-by choices
    /// (the table's columns are at <c>/reports/custom/table-columns</c>); every other source lists its columns.</summary>
    public async Task<ReportSourcesDto> SourcesAsync(
        Guid? orgId, string callerRole, ReportViewer viewer, CancellationToken ct = default, SensitiveAccess? sensitive = null)
    {
        var leadFields = (await FieldsAsync(orgId, callerRole, ct, sensitive)).Fields.Select(f =>
            new ReportSourceFieldDto(f.Key, f.Label, f.Type ?? "pick", true, false, true, false,
                f.Options.Count == 0 ? null : f.Options.Select(o => new TableColumnOptionDto(o.Value, o.Label)).ToList(), f.Kind)).ToList();
        var sources = new List<ReportSourceDto> { new("leads", "Leads", "lead_metrics", leadFields) };

        var caller = SourceCaller(null, viewer, orgId, callerRole, sensitive);
        foreach (var source in _sources?.All ?? [])
            if (await source.FieldsAsync(caller, ct) is { } fields)
                sources.Add(new ReportSourceDto(source.Key, source.Label, "count_sum",
                    fields.Select(f => new ReportSourceFieldDto(f.Key, f.Label, f.Type, f.Filterable, f.Sortable, f.Groupable, f.Summable, f.Options)).ToList()));
        return new ReportSourcesDto(sources);
    }

    /// <summary>GET /reports/custom/sources/{key}/table-columns for a non-lead source: the columns catalogue its table's headings read.
    /// Null when there is no such source for this caller.</summary>
    public async Task<TableColumnsDto?> SourceTableColumnsAsync(
        string sourceKey, Guid? orgId, string callerRole, ReportViewer viewer, CancellationToken ct = default, SensitiveAccess? sensitive = null)
    {
        if (_sources?.Find(sourceKey) is not { } source) return null;
        try { return await source.CatalogueAsync(SourceCaller(null, viewer, orgId, callerRole, sensitive), ct); }
        catch (ReportSourceRefusedException) { return null; }
    }

    // --- Table mode (slice 3) ---------------------------------------------------

    /// <summary>
    /// Table mode: one row per VISIBLE lead, with the columns the caller
    /// picked — built-in fields or any custom field they may see
    /// (<see cref="CustomFieldMasking.IsVisibleTo"/>). <paramref name="lenient"/>
    /// (set only by <c>SavedReportProcess</c> replaying a saved definition)
    /// DROPS an unresolved column instead of refusing the whole request — see
    /// <see cref="RunAsync"/>'s own remarks.
    /// </summary>
    private async Task<(Refusal? Refusal, CustomReportTableResultDto? Dto)> BuildTableAsync(
        RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole,
        CustomReportRequestDto request, bool lenient, bool forExport, CancellationToken ct)
    {
        if (request.Columns is not { Count: > 0 })
            return (new Refusal("columns must include at least one column."), null);

        var allDefs = await _store.AllLeadFieldDefsAsync(orgId, ct);
        var visibleDefs = allDefs.Where(d => CustomFieldMasking.UsableInReports(d, callerRole, ctx.Sensitive))
            .ToDictionary(d => d.Key, d => d, StringComparer.OrdinalIgnoreCase);

        // E18.2: the deal's account custom fields this caller may use raw, as columns.
        var visibleAccountDefs = (await _store.AllAccountFieldDefsAsync(orgId, ct))
            .Where(d => CustomFieldMasking.UsableInReports(d, callerRole, ctx.Sensitive))
            .ToDictionary(d => d.Key, d => d, StringComparer.OrdinalIgnoreCase);

        var resolved = new List<(CustomReportColumnInput Input, CustomFieldDef? Def)>();
        var dropped = new List<string>();
        foreach (var col in request.Columns)
        {
            if (col.Kind == "builtin")
            {
                if (!CustomReportTableKeyset.BuiltinKeys.Contains(col.Key) && !AccountBuiltinKeys.Contains(col.Key))
                {
                    if (lenient) { dropped.Add(col.Key); continue; }
                    return (new Refusal($"'{col.Key}' is not a column this report returns."), null);
                }
                resolved.Add((col, null));
            }
            else if (col.Kind == AccountCustomKind)
            {
                if (!visibleAccountDefs.TryGetValue(col.Key, out var accountDef))
                {
                    if (lenient) { dropped.Add(AccountCustomPrefix + col.Key); continue; }
                    return (new Refusal($"Unknown account custom field '{col.Key}'.", NotFound: true), null);
                }
                resolved.Add((col, accountDef));
            }
            else if (col.Kind == "custom_field")
            {
                if (!visibleDefs.TryGetValue(col.Key, out var def))
                {
                    if (lenient) { dropped.Add(col.Key); continue; }
                    return (new Refusal($"Unknown custom field '{col.Key}'.", NotFound: true), null);
                }
                resolved.Add((col, def));
            }
            else
            {
                return (new Refusal("column.kind must be \"builtin\" or \"custom_field\"."), null);
            }
        }
        if (resolved.Count == 0)
            return (new Refusal("No requested column could be resolved — every one was unknown or hidden."), null);

        // Sort key: a builtin key, or "custom:<field key>" (contracts
        // remarks) for a visible custom field. Defaults to "created_at desc"
        // — newest leads first, same default direction the breakdown engine's
        // own "leads created in range" metric implies.
        var sortInput = request.Sort ?? new CustomReportSortInput("created_at", "desc");
        var desc = !string.Equals(sortInput.Dir, "asc", StringComparison.OrdinalIgnoreCase);
        string sortKey;
        string? sortCustomKey = null;
        string? sortCustomType = null;
        if (sortInput.Key.StartsWith("custom:", StringComparison.Ordinal))
        {
            sortCustomKey = sortInput.Key["custom:".Length..];
            if (!visibleDefs.TryGetValue(sortCustomKey, out var sortDef))
            {
                if (lenient) { sortInput = new CustomReportSortInput("created_at", "desc"); desc = true; sortCustomKey = null; sortKey = "created_at"; }
                else return (new Refusal($"Unknown custom field '{sortCustomKey}' to sort by.", NotFound: true), null);
            }
            else { sortKey = "custom_field"; sortCustomType = sortDef.Type; }
        }
        else if (CustomReportTableKeyset.BuiltinKeys.Contains(sortInput.Key))
        {
            sortKey = sortInput.Key;
        }
        else if (lenient)
        {
            sortKey = "created_at";
            desc = true;
        }
        else
        {
            return (new Refusal($"'{sortInput.Key}' is not a column this report can sort by."), null);
        }

        var filters = request.Filters;
        var cal = await _reportingCalendar.ForAsync(orgId);
        DateTime? fromUtc = filters?.From is { } f ? ReportingCalendar.StartOfDayUtc(cal, DateOnly.FromDateTime(f)) : null;
        DateTime? toUtc = filters?.To is { } t ? ReportingCalendar.EndOfDayUtc(cal, DateOnly.FromDateTime(t)) : null;

        // One-table: the headings' filters and sorts, checked against this caller's column catalogue.
        CustomReportStore.TableQueryPart? tablePart;
        string tableFingerprint;
        try
        {
            (tablePart, tableFingerprint) = await ResolveTableQueryAsync(
                showValues, orgId, callerRole, request, lenient ? dropped : null, ct, ctx.Sensitive, TeamScopedQueries.AccountViewable(ctx));
        }
        catch (TableQueryRefusedException e)
        {
            return (new Refusal(e.Message), null);
        }

        // EXPORT (design doc: "ALL rows ... no paging cap") skips cursor/limit
        // entirely and fetches every matching row via AllTableLeadsAsync —
        // never the paged TableLeadsAsync path below, so an export can never
        // be silently truncated to the screen's default page size.
        // E18.2: the rows carry their account only when an account column was asked for.
        var withAccount = resolved.Any(c => c.Input.Kind == AccountCustomKind || AccountBuiltinKeys.Contains(c.Input.Key));

        if (forExport)
        {
            var allRows = await _store.AllTableLeadsAsync(
                ctx, filters?.TeamId, filters?.OwnerId, filters?.Source, filters?.Stage, filters?.Custom,
                fromUtc, toUtc, sortKey, desc, sortCustomKey, sortCustomType, ct, tablePart, withAccount);
            var (exportColumns, exportRows) = await BuildTableRowsAsync(ctx, orgId, showValues, resolved, allRows, ct);
            return (null, new CustomReportTableResultDto(exportColumns, exportRows, null, exportRows.Count, showValues, dropped));
        }

        var limit = request.Limit is > 0 and <= 500 ? request.Limit!.Value : 50;

        // Opaque cursor, "offset" mode — see CustomReportTableKeyset's own
        // remarks on why table mode uses the offset fallback rather than a
        // true keyset predicate. Fingerprinted over everything that changes
        // which rows match or what order they come back in, same discipline
        // LeadListProcess's own stale-cursor check uses.
        var fingerprint = CursorToken.Fingerprint(
            JsonSerializer.Serialize(filters), JsonSerializer.Serialize(request.Columns),
            sortInput.Key, desc.ToString(), limit.ToString(), tableFingerprint);
        var decodedCursor = CursorToken.Decode(request.Cursor);
        if (!string.IsNullOrEmpty(request.Cursor) && (decodedCursor is null || decodedCursor.Filters != fingerprint))
            return (new Refusal("Your cursor is stale — reload the first page."), null);
        var offset = decodedCursor?.Offset ?? 0;

        var (rows, total) = await _store.TableLeadsAsync(
            ctx, filters?.TeamId, filters?.OwnerId, filters?.Source, filters?.Stage, filters?.Custom,
            fromUtc, toUtc, sortKey, desc, sortCustomKey, sortCustomType, offset, limit + 1, ct, tablePart, withAccount);

        var hasMore = rows.Count > limit;
        if (hasMore) rows = rows.Take(limit).ToList();

        var (columnDtos, rowDtos) = await BuildTableRowsAsync(ctx, orgId, showValues, resolved, rows, ct);

        var nextCursor = hasMore
            ? CursorToken.Encode(new CursorPayload("offset", fingerprint, sortInput.Key, null, offset + limit))
            : null;

        return (null, new CustomReportTableResultDto(columnDtos, rowDtos, nextCursor, total, showValues, dropped));
    }

    /// <summary>The key a column's values carry in a row: the request's own key, except an account custom field, which is
    /// "account_custom:&lt;key&gt;" (never equal to a lead custom field of the same key).</summary>
    private static string OutKey(CustomReportColumnInput input) =>
        input.Kind == AccountCustomKind ? AccountCustomPrefix + input.Key : input.Key;

    /// <summary>Resolves display columns/rows for an already-fetched page of
    /// leads — split out of <see cref="BuildTableAsync"/> so the export path
    /// (<see cref="CustomReportStore.AllTableLeadsAsync"/>'s unpaged rows)
    /// reuses the exact same column/value logic the screen uses, never a
    /// second hand-written copy.</summary>
    private async Task<(List<CustomReportTableColumnDto> Columns, List<CustomReportTableRowDto> Rows)> BuildTableRowsAsync(
        RecordAccessContext ctx, Guid? orgId, bool showValues, List<(CustomReportColumnInput Input, CustomFieldDef? Def)> resolved,
        List<Lead> rows, CancellationToken ct)
    {
        // A deal the viewer can see whose ACCOUNT they cannot shows no account values (null cells, as for a deal with no account).
        var withAccountColumn = resolved.Any(c => c.Input.Kind == AccountCustomKind || AccountBuiltinKeys.Contains(c.Input.Key));
        HashSet<Guid> viewableAccounts = withAccountColumn
            ? await _store.ViewableAccountIdsAsync(ctx, rows.Where(l => l.AccountId != null).Select(l => l.AccountId!.Value), ct)
            : new HashSet<Guid>();
        Account? AccountOf(Lead l) => l.Account is { } a && viewableAccounts.Contains(a.Id) ? a : null;

        var ownerIds = rows.Where(l => l.OwnerId is not null).Select(l => l.OwnerId!.Value).Distinct().ToList();
        var ownerNames = ownerIds.Count == 0 ? [] : (await _store.ProfilesAsync(orgId, ct))
            .Where(p => ownerIds.Contains(p.Id)).ToDictionary(p => p.Id, p => p.FullName ?? "");
        var teamNames = (await _store.TeamsAsync(orgId, ct)).ToDictionary(t => t.Id, t => t.Name);

        // Stage labels resolve against each lead's OWN playbook (design doc's
        // own rule) — one lookup per DISTINCT playbook actually present on
        // this page, plus the org default for a lead with none, never one
        // query per row.
        var stageLabelsByPlaybook = new Dictionary<Guid, Dictionary<string, string>>();
        Dictionary<string, string>? orgStageLabels = null;
        foreach (var pid in rows.Select(l => l.PlaybookId).Distinct())
        {
            if (pid is { } id) stageLabelsByPlaybook[id] = await _stages.LabelsAsync(id);
            else orgStageLabels ??= await _stages.LabelsAsync(null);
        }

        var picklistLabelsByField = new Dictionary<string, Dictionary<string, string>>(StringComparer.OrdinalIgnoreCase);
        foreach (var (_, def) in resolved)
        {
            if (def is { Type: "picklist", PicklistKey: { } pk } && !picklistLabelsByField.ContainsKey(def.Key))
            {
                var values = await _store.PicklistValuesAsync(pk, ct);
                picklistLabelsByField[def.Key] = values.ToDictionary(v => v.Value, v => v.Label, StringComparer.OrdinalIgnoreCase);
            }
        }

        // E18.2: an account status shows as the org's label for it.
        Dictionary<string, string> accountStatusLabels = resolved.Any(c => c.Input.Kind == "builtin" && c.Input.Key == "account_status")
            ? await _store.AccountStatusLabelsAsync(ct)
            : new();

        var columnDtos = resolved.Select(c => new CustomReportTableColumnDto(
            OutKey(c.Input),
            c.Input.Kind == AccountCustomKind ? "Account " + c.Def!.Label : c.Def?.Label ?? BuiltinColumnLabel(c.Input.Key),
            c.Def?.Type ?? BuiltinColumnType(c.Input.Key))).ToList();

        var rowDtos = rows.Select(l =>
        {
            var stageLabels = l.PlaybookId is { } pid ? stageLabelsByPlaybook.GetValueOrDefault(pid) : orgStageLabels;
            var values = new Dictionary<string, object?>();
            foreach (var (input, def) in resolved)
            {
                values[OutKey(input)] = input.Kind == AccountCustomKind
                    ? ExtractFieldValue(AccountOf(l)?.Custom ?? "{}", def!, picklistLabelsByField.GetValueOrDefault(def!.Key))
                    : def is not null
                        ? ExtractFieldValue(l.Custom, def, picklistLabelsByField.GetValueOrDefault(def.Key))
                        : BuiltinColumnValue(l, AccountOf(l), input.Key, showValues, ownerNames, teamNames, stageLabels, accountStatusLabels);
            }
            return new CustomReportTableRowDto(l.Id, values);
        }).ToList();

        return (columnDtos, rowDtos);
    }

    // --- the results table's headings: filters and sorts (owner decision 2026-10-08) -----------

    /// <summary>The column filters of a request: the canonical <c>column_filters</c>, or the one-table array a client
    /// wrote under <c>filters</c> (see <see cref="CustomReportFiltersInput"/>).</summary>
    private static List<TableFilterDto> ColumnFiltersOf(CustomReportRequestDto request) =>
        request.ColumnFilters ?? request.Filters?.ColumnFilters ?? [];

    /// <summary>
    /// Checks the request's heading filters and sorts against THIS caller's catalogue (<see cref="ReportTableColumns"/>)
    /// and turns them into a predicate and an ORDER BY. A field the caller may not see (the money columns without
    /// lead_values.view, a restricted custom field) is refused by name, like any other unknown field. With
    /// <paramref name="dropped"/> (a SAVED report replayed as its viewer) an unresolved field is dropped and listed there
    /// instead, the same way an unresolved column is.
    /// </summary>
    /// <returns>Null part when the request carries neither; the fingerprint binds a cursor to what they mean.</returns>
    private async Task<(CustomReportStore.TableQueryPart? Part, string Fingerprint)> ResolveTableQueryAsync(
        bool showValues, Guid? orgId, string callerRole, CustomReportRequestDto request, List<string>? dropped, CancellationToken ct,
        SensitiveAccess? sensitive = null, Expression<Func<Account, bool>>? accountViewable = null)
    {
        var filters = ColumnFiltersOf(request);
        var sorts = request.Sorts ?? [];
        if (filters.Count == 0 && sorts.Count == 0) return (null, "");

        var defs = await _store.AllLeadFieldDefsAsync(orgId, ct);
        var accountDefs = await _store.AllAccountFieldDefsAsync(orgId, ct);
        var ranks = sorts.Any(s => s.Field == "stage") ? await _store.StageRanksAsync(ct) : null;
        var visible = ReportTableColumns.Build(defs, showValues, callerRole, null, ranks, sensitive, accountDefs, accountViewable);
        var everything = ReportTableColumns.Build(defs, true, "admin", accountFieldDefs: accountDefs, accountViewable: accountViewable);

        if (dropped is not null)
        {
            var known = visible.Select(c => c.Key).ToHashSet(StringComparer.Ordinal);
            var gone = filters.Select(f => f.Field).Concat(sorts.Select(s => s.Field)).Where(f => !known.Contains(f)).Distinct().ToList();
            dropped.AddRange(gone.Where(g => !dropped.Contains(g)));
            filters = filters.Where(f => known.Contains(f.Field)).ToList();
            sorts = sorts.Where(s => known.Contains(s.Field)).ToList();
        }

        var wantsOverdue = filters.Any(f => (f.Conditions ?? []).Any(c =>
            string.Equals(c.Op, "preset", StringComparison.OrdinalIgnoreCase) &&
            c.Value is { ValueKind: JsonValueKind.String } v &&
            string.Equals(v.GetString(), "overdue", StringComparison.OrdinalIgnoreCase)));
        var resolved = await TableQuerySpecs.ResolveAsync<Lead>(visible, everything, filters, sorts, async () =>
            new FilterContext(
                await _reportingCalendar.ForAsync(orgId), DateTime.UtcNow, _search.TrgmEnabled, _search.LevenshteinEnabled,
                FuzzySearch.DefaultSimilarityThreshold,
                wantsOverdue ? (await _phaseLoader.LoadAllAsync(ct)).Matching<Lead>(l => l.PlaybookId, l => l.Status, s => s.OpenKeys) : null));

        var part = new CustomReportStore.TableQueryPart(
            resolved.Predicate,
            resolved.Sorts is { } keys ? src => TableMultiKeyset<Lead>.ApplyOrder(src, keys) : null,
            resolved.Fuzzy, resolved.ShortFuzzy);
        return (part, resolved.CanonicalFilters + "|" + resolved.CanonicalSorts);
    }

    /// <summary>GET /reports/custom/table-columns — the results table's columns as <c>/columns</c> catalogues describe
    /// theirs: type, whether it sorts / filters, its operators and its options, so the headings can drive the report.
    /// A column the caller may not see is absent. <c>key</c> is the field name a filter or sort uses
    /// (<c>owner</c>, <c>stage</c>, ..., <c>custom:&lt;key&gt;</c>).</summary>
    public async Task<TableColumnsDto> TableColumnsAsync(RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole, CancellationToken ct = default)
    {
        var options = await _leads.ColumnOptionsAsync(ctx);
        var defs = await _store.AllLeadFieldDefsAsync(orgId, ct);
        var accountDefs = await _store.AllAccountFieldDefsAsync(orgId, ct);
        return TableQuerySpecs.Catalogue(ReportTableColumns.Build(
            defs, showValues, callerRole, options, sensitive: ctx.Sensitive, accountFieldDefs: accountDefs));
    }

    // --- GET /reports/custom/fields ---------------------------------------------

    public async Task<CustomReportFieldsDto> FieldsAsync(
        Guid? orgId, string callerRole, CancellationToken ct = default, SensitiveAccess? sensitive = null)
    {
        var fields = new List<CustomReportFieldDto>
        {
            new("builtin", "owner", "Owner", null, []), // options: the org's existing people picker
            new("builtin", "team", "Team", null, []),   // options: the org's existing team picker
        };

        var stageLabels = await _stages.LabelsAsync();
        fields.Add(new("builtin", "stage", "Stage", null,
            stageLabels.Select(kv => new CustomReportFieldOptionDto(kv.Key, kv.Value)).ToList()));

        var sources = await _orgSettings.GetLeadSourcesAsync();
        fields.Add(new("builtin", "source", "Source", null,
            sources.Select(s => new CustomReportFieldOptionDto(s, s)).ToList()));

        var dealTypes = await _orgSettings.GetDealTypesAsync();
        fields.Add(new("builtin", "deal_type", "Deal type", null,
            dealTypes.Select(d => new CustomReportFieldOptionDto(d, d)).ToList()));

        // E18.2: the deal's account (industry and status are the account's own columns; its custom fields follow the lead's).
        fields.Add(new("builtin", "account_industry", "Account industry", null, []));
        fields.Add(new("builtin", "account_status", "Account status", null,
            (await _store.AccountStatusLabelsAsync(ct)).Select(kv => new CustomReportFieldOptionDto(kv.Key, kv.Value)).ToList()));

        async Task<List<CustomReportFieldOptionDto>> OptionsOfAsync(CustomFieldDef def)
        {
            if (def.Type == "picklist" && def.PicklistKey is not null)
            {
                var values = await _store.PicklistValuesAsync(def.PicklistKey, ct);
                return values.Select(v => new CustomReportFieldOptionDto(v.Value, v.Label)).ToList();
            }
            return def.Options.Select(o => new CustomReportFieldOptionDto(o, o)).ToList();
        }

        var defs = await _store.GroupableCustomFieldDefsAsync(orgId, ct);
        foreach (var def in defs)
        {
            if (!CustomFieldMasking.UsableInReports(def, callerRole, sensitive)) continue; // E3.2 / E12.2 — never advertise a field this caller cannot use
            fields.Add(new("custom_field", def.Key, def.Label, def.Type, await OptionsOfAsync(def)));
        }

        // A multi-select account field is not advertised: the group-by is single-valued through the account (it is refused by name if asked for).
        foreach (var def in await _store.GroupableCustomFieldDefsAsync(orgId, ct, CustomFieldDef.ObjectTypes.Account))
        {
            if (def.Type == "multi_select" || !CustomFieldMasking.UsableInReports(def, callerRole, sensitive)) continue;
            fields.Add(new(AccountCustomKind, def.Key, "Account " + def.Label, def.Type, await OptionsOfAsync(def)));
        }

        return new CustomReportFieldsDto(fields);
    }

    // --- helpers -----------------------------------------------------------

    private sealed class Bucket
    {
        public int Leads, OpenCount, WonCount, LostCount;
        public decimal OpenValue, WonValue, LostValue;
    }

    private static CustomReportRow ToRow(string key, string label, Bucket b, bool showValues)
    {
        var closed = b.WonCount + b.LostCount;
        return new CustomReportRow(
            key, label, b.Leads,
            b.OpenCount, showValues ? b.OpenValue : null,
            b.WonCount, showValues ? b.WonValue : null,
            b.LostCount, showValues ? b.LostValue : null,
            closed > 0 ? (double)b.WonCount / closed : null);
    }

    // --- table mode helpers --------------------------------------------------

    private static string BuiltinColumnLabel(string key) => key switch
    {
        "name" => "Name",
        "company" => "Company",
        "owner" => "Owner",
        "team" => "Team",
        "stage" => "Stage",
        "source" => "Source",
        "priority" => "Priority",
        "deal_type" => "Deal type",
        "estimated_value" => "Negotiation value",
        "closed_value" => "Closed value",
        "created_at" => "Created at",
        "won_at" => "Won at",
        "lost_at" => "Lost at",
        "expected_close_date" => "Expected close date",
        "account_industry" => "Account industry",
        "account_status" => "Account status",
        _ => key,
    };

    private static string BuiltinColumnType(string key) => key switch
    {
        "estimated_value" or "closed_value" => "money",
        "created_at" or "won_at" or "lost_at" or "expected_close_date" => "date",
        _ => "string",
    };

    /// <summary>A built-in column's value for one row. Money columns are
    /// NULL — never zero — when <paramref name="showValues"/> is false, the
    /// same masking rule the breakdown engine's own <c>ToRow</c> applies.
    /// "owner"/"team" fall back to the raw id (as a string) if the name
    /// lookup somehow misses (a profile/team deleted out from under a live
    /// lead) rather than silently showing nothing.</summary>
    private static object? BuiltinColumnValue(
        Lead l, Account? account, string key, bool showValues, Dictionary<Guid, string> ownerNames, Dictionary<Guid, string> teamNames,
        Dictionary<string, string>? stageLabels, Dictionary<string, string>? accountStatusLabels = null) => key switch
    {
        "account_industry" => account?.Industry,
        "account_status" => account is null ? null : accountStatusLabels?.GetValueOrDefault(account.Status, account.Status) ?? account.Status,
        "name" => l.Name,
        "company" => l.Company,
        "owner" => l.OwnerId is { } oid ? ownerNames.GetValueOrDefault(oid, oid.ToString()) : null,
        "team" => l.TeamId is { } tid ? teamNames.GetValueOrDefault(tid, tid.ToString()) : null,
        "stage" => stageLabels?.GetValueOrDefault(l.Status, l.Status) ?? l.Status,
        "source" => l.Source,
        "priority" => l.Priority,
        "deal_type" => l.DealType,
        "estimated_value" => showValues ? l.EstimatedValue : null,
        "closed_value" => showValues ? l.ClosedValue : (decimal?)null,
        "created_at" => l.CreatedAt,
        "won_at" => l.WonAt,
        "lost_at" => l.LostAt,
        "expected_close_date" => l.ExpectedCloseDate,
        _ => null,
    };

    /// <summary>A custom field's value for one row, typed by
    /// <see cref="CustomFieldDef.Type"/> so the client gets a real
    /// number/bool/array rather than everything flattened to a string. A
    /// "picklist" value resolves through <paramref name="picklistLabels"/>
    /// (its def's own vocabulary, see FieldsAsync's own picklist-label
    /// lookup); a "dropdown"/"select" value IS its own label (CustomFieldDef.Options
    /// remarks), so it needs no lookup.</summary>
    private static object? ExtractFieldValue(string customJson, CustomFieldDef def, Dictionary<string, string>? picklistLabels)
    {
        using var doc = JsonDocument.Parse(string.IsNullOrEmpty(customJson) ? "{}" : customJson);
        if (!doc.RootElement.TryGetProperty(def.Key, out var val) || val.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined)
            return null;

        switch (def.Type)
        {
            case "multi_select":
                return val.ValueKind == JsonValueKind.Array
                    ? val.EnumerateArray().Where(e => e.ValueKind == JsonValueKind.String).Select(e => e.GetString()!).ToList()
                    : null;
            case "checkbox":
                return val.ValueKind switch { JsonValueKind.True => true, JsonValueKind.False => false, _ => (bool?)null };
            case "number" or "currency" or "percentage":
                return val.ValueKind == JsonValueKind.Number ? val.GetDecimal()
                    : val.ValueKind == JsonValueKind.String && decimal.TryParse(val.GetString(), out var d) ? d
                    : (decimal?)null;
            case "picklist":
                var raw = val.ValueKind == JsonValueKind.String ? val.GetString() : null;
                return raw is null ? null : (picklistLabels?.GetValueOrDefault(raw, raw) ?? raw);
            default: // text, dropdown, select, date, email, phone, url, long_text, user
                return val.ValueKind == JsonValueKind.String ? val.GetString() : val.GetRawText();
        }
    }

    // --- shared with SavedReportProcess ---------------------------------------

    /// <summary>
    /// Structural validation ONLY — source/mode/group-by-or-columns shape,
    /// and that every referenced field exists and is visible to
    /// <paramref name="callerRole"/> — WITHOUT a <c>RecordAccessContext</c>
    /// (a saved report is validated at save time, for whoever is creating or
    /// editing it, not replayed as any particular viewer yet; see
    /// <c>SavedReportProcess.CreateAsync</c>). Deliberately does not check
    /// filters' team/owner ids resolve to anything — that already degrades
    /// safely to "zero rows" at run time, same as the lead list's own filters,
    /// and re-checking it here would need a RecordAccessContext this method
    /// is specifically built to avoid.
    /// </summary>
    public async Task<Refusal?> ValidateDefinitionAsync(
        Guid? orgId, string callerRole, CustomReportRequestDto request, CancellationToken ct = default, SensitiveAccess? sensitive = null)
    {
        if (!string.Equals(request.Source, "leads", StringComparison.OrdinalIgnoreCase))
        {
            if (_sources?.Find(request.Source) is not { } source) return new Refusal(UnknownSourceMessage());
            return await ValidateSourceAsync(source, orgId, callerRole, request, sensitive, ct);
        }

        if (string.Equals(request.Mode, "table", StringComparison.OrdinalIgnoreCase))
        {
            if (request.Columns is not { Count: > 0 })
                return new Refusal("columns must include at least one column.");
            var allDefs = await _store.AllLeadFieldDefsAsync(orgId, ct);
            var visible = allDefs.Where(d => CustomFieldMasking.UsableInReports(d, callerRole, sensitive))
                .Select(d => d.Key).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var visibleAccount = (await _store.AllAccountFieldDefsAsync(orgId, ct))
                .Where(d => CustomFieldMasking.UsableInReports(d, callerRole, sensitive))
                .Select(d => d.Key).ToHashSet(StringComparer.OrdinalIgnoreCase);
            foreach (var col in request.Columns)
            {
                if (col.Kind == "builtin")
                {
                    if (!CustomReportTableKeyset.BuiltinKeys.Contains(col.Key) && !AccountBuiltinKeys.Contains(col.Key))
                        return new Refusal($"'{col.Key}' is not a column this report returns.");
                }
                else if (col.Kind == AccountCustomKind)
                {
                    if (!visibleAccount.Contains(col.Key))
                        return new Refusal($"Unknown account custom field '{col.Key}'.", NotFound: true);
                }
                else if (col.Kind == "custom_field")
                {
                    if (!visible.Contains(col.Key))
                        return new Refusal($"Unknown custom field '{col.Key}'.", NotFound: true);
                }
                else
                {
                    return new Refusal("column.kind must be \"builtin\" or \"custom_field\".");
                }
            }
            if (request.Sort is { } sort)
            {
                var sortKey = sort.Key.StartsWith("custom:", StringComparison.Ordinal) ? sort.Key["custom:".Length..] : sort.Key;
                var sortIsCustom = sort.Key.StartsWith("custom:", StringComparison.Ordinal);
                if (sortIsCustom ? !visible.Contains(sortKey) : !CustomReportTableKeyset.BuiltinKeys.Contains(sortKey))
                    return new Refusal($"'{sort.Key}' is not a column this report can sort by.");
            }
            // The headings' filters and sorts, against the same catalogue a run uses (money columns assumed visible:
            // who SAVES a report is not who runs it, and a run re-checks them for the viewer).
            try { await ResolveTableQueryAsync(true, orgId, callerRole, request, null, ct, sensitive); }
            catch (TableQueryRefusedException e) { return new Refusal(e.Message); }
            return null;
        }

        if (!string.Equals(request.Mode, "breakdown", StringComparison.OrdinalIgnoreCase))
            return new Refusal("mode must be \"breakdown\" or \"table\".");

        if (request.GroupBy is null || string.IsNullOrWhiteSpace(request.GroupBy.Key))
            return new Refusal("group_by.key is required.");
        var kind = request.GroupBy.Kind;
        if (kind != "builtin" && kind != "custom_field" && kind != AccountCustomKind)
            return new Refusal("group_by.kind must be \"builtin\", \"custom_field\" or \"account_custom_field\".");

        if (kind == "custom_field")
        {
            var fieldDef = await _store.CustomFieldDefByKeyAsync(orgId, request.GroupBy.Key, ct);
            if (fieldDef is null || !CustomFieldMasking.UsableInReports(fieldDef, callerRole, sensitive))
                return new Refusal($"Unknown custom field '{request.GroupBy.Key}'.", NotFound: true);
        }
        else if (kind == AccountCustomKind)
        {
            var fieldDef = await _store.CustomFieldDefByKeyAsync(orgId, request.GroupBy.Key, ct, CustomFieldDef.ObjectTypes.Account);
            if (fieldDef is null || !CustomFieldMasking.UsableInReports(fieldDef, callerRole, sensitive))
                return new Refusal($"Unknown account custom field '{request.GroupBy.Key}'.", NotFound: true);
            if (fieldDef.Type == "multi_select")
                return new Refusal("A multi-select account field cannot be grouped by.");
        }
        else if (!BuiltinKeys.Contains(request.GroupBy.Key))
        {
            return new Refusal($"group_by.key must be one of: {string.Join(", ", BuiltinKeys)}.");
        }

        return null;
    }
}

using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.Services.Paging;
using SalesApi.Services.TableQuery;
using SalesApi.SystemLayer.Accounts;
using SalesApi.ProcessLayer.CustomFields;
using SalesApi.ProcessLayer.Leads;

namespace SalesApi.ProcessLayer.Accounts;

/// <summary>
/// Accounts: search/list/facets/export/match, the account-360 composite read,
/// and account + contact CRUD. The loyalty slice of this domain
/// (<see cref="ProcessLayer.Loyalty.LoyaltyStatusProcess"/>) is migrated
/// separately and untouched by this file.
///
/// Layering round 4 (owner decision 2026-09-30): no longer holds
/// <see cref="AppDbContext"/> directly — search ordering/paging
/// (<see cref="AccountKeyset"/>, <see cref="CursorToken"/>,
/// <see cref="FuzzySearch"/>) and record scoping (<see cref="RecordAccess"/>,
/// <see cref="TeamScopedQueries"/>) stay System-layer material reached through
/// <see cref="AccountStore"/>, and <see cref="DomainEvents.Raise"/>/
/// <see cref="OrgSettings"/> through <see cref="DomainEventWriter"/>/
/// <see cref="OrgSettingsReader"/> — a business DECISION here is "which page,
/// which sort, does this row become a DTO the same way for every caller", not
/// the SQL that gets there.
/// </summary>
public sealed class AccountProcess
{
    private readonly AccountStore _store;
    private readonly SearchCapabilities _search;
    private readonly CustomFieldProcess _customFields;
    private readonly DomainEventWriter _events;
    private readonly OrgSettingsReader _orgSettings;

    // Null in the hand-built test call sites that never wire it: the deleted account's files are then not stamped.
    private readonly RecordFileRetention? _recordFiles;

    // Accounts rework: "Also move N open leads" runs each lead through the EXISTING lead assign path, and "also delete its
    // deals" through the EXISTING lead delete (so the lead rules - team check, invoices follow owner, the issued-invoice guard
    // - are not copied here). Optional so the ~60 hand-built test chains keep compiling; DI always supplies both, and a
    // path that needs one with it missing fails loudly rather than silently doing less.
    private readonly LeadAssignProcess? _leadAssign;
    private readonly LeadMergeProcess? _leadDelete;

    public AccountProcess(
        AccountStore store, SearchCapabilities search, CustomFieldProcess customFields,
        DomainEventWriter events, OrgSettingsReader orgSettings, RecordFileRetention? recordFiles = null,
        LeadAssignProcess? leadAssign = null, LeadMergeProcess? leadDelete = null)
    {
        _store = store;
        _search = search;
        _customFields = customFields;
        _events = events;
        _orgSettings = orgSettings;
        _recordFiles = recordFiles;
        _leadAssign = leadAssign;
        _leadDelete = leadDelete;
    }

    /// <summary>Why a request could not be carried out, or null when it can. A
    /// RESULT rather than an exception — an ordinary "not found" or "not
    /// allowed" must not become a 500.</summary>
    public sealed record Refusal(
        string Reason, bool NotFound = false, bool Forbidden = false, string? Code = null, string? Field = null,
        // Accounts rework: a 409 (owner outside the account's team; a delete blocked by issued invoices) and the data the
        // client acts on - the account's team and the new owner's, or the deals that block the delete.
        bool Conflict = false, Guid? TeamId = null, IReadOnlyList<Guid>? OwnerTeamIds = null, IReadOnlyList<BlockedDealDto>? BlockedDeals = null,
        // E12.2 - the fields a "sensitive_read_only" refusal names.
        IReadOnlyList<string>? Fields = null);

    /// <summary>E12.2 - an account save judged against the caller's category levels; null when allowed.</summary>
    private static Refusal? SensitiveWriteRefusal(
        SensitiveAccess? access, AccountInput i, Account? stored, Guid ownerId, IReadOnlyCollection<CustomFieldDef> defs)
    {
        if (access is null) return null;
        var cd = SensitiveCategories.ContactDetails;
        var T = CustomFieldMasking.Kind.Text;
        var writes = new List<SensitiveFieldWrite>
        {
            new(cd, "phone", i.Phone, stored?.Phone, CustomFieldMasking.Kind.Phone),
            new(cd, "address", i.Address, stored?.Address, T),
            new(cd, "city", i.City, stored?.City, T),
            new(cd, "state", i.State, stored?.State, T),
            new(cd, "postal_code", i.PostalCode, stored?.PostalCode, T),
            new(cd, "country", i.Country, stored?.Country, T),
            new(cd, "country_code", i.CountryCode, stored?.CountryCode, T),
        };
        writes.AddRange(SensitiveWriteGuard.CustomWrites(i.Custom, ParseCustom(stored?.Custom), defs));
        var v = SensitiveWriteGuard.Check(access, stored?.OwnerId ?? ownerId, stored?.TeamId, stored is null, writes);
        return v is null ? null : new Refusal(v.Message, Code: SensitiveWriteGuard.Code, Fields: v.Fields);
    }

    /// <summary>E12.2 - the contact twin: judged against the ACCOUNT the contact sits on.</summary>
    internal static (string Reason, IReadOnlyList<string> Fields)? SensitiveContactWriteRefusal(
        SensitiveAccess? access, ContactInput i, Contact? stored, Guid? ownerId, Guid? teamId, IReadOnlyCollection<CustomFieldDef> defs)
    {
        if (access is null) return null;
        var cd = SensitiveCategories.ContactDetails;
        var writes = new List<SensitiveFieldWrite>
        {
            new(cd, "email", i.Email, stored?.Email, CustomFieldMasking.Kind.Email),
            new(cd, "phone", i.Phone, stored?.Phone, CustomFieldMasking.Kind.Phone),
            new(cd, "phone_country_code", i.PhoneCountryCode, stored?.PhoneCountryCode, CustomFieldMasking.Kind.Text),
        };
        writes.AddRange(SensitiveWriteGuard.CustomWrites(i.Custom, ParseCustom(stored?.Custom), defs));
        var v = SensitiveWriteGuard.Check(access, ownerId, teamId, stored is null, writes);
        return v is null ? null : (v.Message, v.Fields);
    }

    /// <summary>Everything about the CALLER the account writes need, resolved once by the controller (the account twin of
    /// <c>LeadActor</c>): who is acting, their org, their display name (for the lead path), whether they are a manager, their
    /// lead visibility, whether they may mint tags, and their role.</summary>
    public readonly record struct AccountActor(
        Guid Id, Guid? OrgId, string Name, bool IsManager, string Visibility, bool CanCreateTags, string Role);

    /// <summary>Extras the account DTO carries beyond the row itself: last contact, next step and the two tag sets, each
    /// loaded for a whole page in one query apiece.</summary>
    private sealed class Extras
    {
        public Dictionary<Guid, DateTime> LastContact { get; init; } = [];
        public Dictionary<Guid, NextStepDto> Steps { get; init; } = [];
        public Dictionary<Guid, List<TagRefDto>> OwnTags { get; init; } = [];
        public Dictionary<Guid, List<TagRefDto>> LeadTags { get; init; } = [];
        public Dictionary<Guid, DateTime> Renewals { get; init; } = [];
        // E14.1: the org's inheriting field keys, and each child's direct parent (id, name) - "from <parent>" on the DTO.
        public List<string> InheritedFields { get; init; } = [];
        public Dictionary<Guid, (Guid ParentId, string ParentName)> Parents { get; init; } = [];
    }

    private async Task<Extras> ExtrasForAsync(IReadOnlyCollection<Guid> accountIds, CancellationToken ct)
    {
        var now = DateTime.UtcNow;
        var inherited = (await _orgSettings.GetAccountInheritedFieldsAsync()).Where(AccountInheritance.IsKnownKey).ToList();
        return new Extras
        {
            LastContact = await _store.LastContactForAccountsAsync(accountIds, now, ct),
            Steps = await _store.NextStepsForAccountsAsync(accountIds, now, ct),
            OwnTags = await _store.OwnTagsForManyAsync(accountIds, ct),
            LeadTags = await _store.LeadTagsForAccountsAsync(accountIds, ct),
            Renewals = await _store.NextRenewalsForAccountsAsync(accountIds, ct),
            InheritedFields = inherited,
            Parents = inherited.Count == 0 ? [] : await _store.ParentsOfAsync(accountIds, ct),
        };
    }

    public sealed record AccountOutcome(Refusal? Refusal, AccountDto? Account)
    {
        public static AccountOutcome Refused(Refusal r) => new(r, null);
        public static AccountOutcome Ok(AccountDto a) => new(null, a);
    }

    public sealed record AccountDetailOutcome(Refusal? Refusal, AccountDetailDto? Detail)
    {
        public static AccountDetailOutcome Refused(Refusal r) => new(r, null);
        public static AccountDetailOutcome Ok(AccountDetailDto d) => new(null, d);
    }

    public sealed record ContactOutcome(Refusal? Refusal, ContactDto? Contact)
    {
        public static ContactOutcome Refused(Refusal r) => new(r, null);
        public static ContactOutcome Ok(ContactDto c) => new(null, c);
    }

    public sealed record ContactsOutcome(Refusal? Refusal, List<ContactDto>? Contacts)
    {
        public static ContactsOutcome Refused(Refusal r) => new(r, null);
        public static ContactsOutcome Ok(List<ContactDto> c) => new(null, c);
    }

    /// <summary><paramref name="DealsDeleted"/> / <paramref name="DealSkips"/> are only filled when "also delete its deals" was
    /// asked for: the deals that went with the account, and the ones the caller may not delete (those stay, unlinked).</summary>
    public sealed record DeleteOutcome(Refusal? Refusal, int DealsDeleted = 0, List<BulkSkipDto>? DealSkips = null)
    {
        public static DeleteOutcome Refused(Refusal r) => new(r);
        public static readonly DeleteOutcome Ok = new((Refusal?)null);
    }

    private const int ContactNamePreview = 3;

    /// <summary>Active defs for one object type, fetched fresh per call — this
    /// table is per-org field count, not per-row, so one read per request is
    /// cheap. Used to mask <c>Custom</c> per-key (E3.2) in <see cref="ToDto"/>/
    /// <see cref="ContactToDto"/>.</summary>
    private Task<List<CustomFieldDef>> ActiveDefsAsync(string objectType, CancellationToken ct = default) =>
        _store.ActiveCustomFieldDefsAsync(objectType, ct);

    private static JsonElement ParseCustom(string? json)
    {
        try { return JsonSerializer.Deserialize<JsonElement>(string.IsNullOrEmpty(json) ? "{}" : json); }
        catch { return JsonSerializer.Deserialize<JsonElement>("{}"); }
    }

    /// <summary><paramref name="callerRole"/> defaults to "" (fail-closed): a
    /// caller this method wasn't told the role of sees a role-restricted field
    /// masked, the same as any role outside that field's list would.</summary>
    private static ContactDto ContactToDto(
        Contact c, List<CustomFieldDef>? defs = null, string callerRole = "",
        IReadOnlyDictionary<Guid, string>? reportsToNames = null,
        // E12.2 - the caller's access, and the owner/team of the ACCOUNT the contact belongs to (a contact has neither),
        // which is the record the assigned scope is judged against.
        SensitiveAccess? sensitive = null, Guid? ownerId = null, Guid? teamId = null)
    {
        sensitive = sensitive?.ForRecord("contact", c.Id); // E12.5: an approved reveal for THIS contact
        var fa = new Dictionary<string, string>(StringComparer.Ordinal);
        var cd = (sensitive ?? SensitiveAccess.Unrestricted).LevelFor(SensitiveCategories.ContactDetails, ownerId, teamId);
        return new(c.Id, c.AccountId, c.Name, c.Title,
            CustomFieldMasking.Text("email", c.Email, cd, CustomFieldMasking.Kind.Email, fa),
            CustomFieldMasking.Text("phone", c.Phone, cd, CustomFieldMasking.Kind.Phone, fa), c.Notes, c.CreatedAt,
            CustomFieldMasking.Text("phone_country_code", c.PhoneCountryCode, cd, CustomFieldMasking.Kind.Text, fa),
            CustomFieldMasking.Apply(ParseCustom(c.Custom), defs ?? new(), callerRole, sensitive, ownerId, teamId, fa),
            c.ReportsToContactId,
            c.ReportsToContactId is { } rid && reportsToNames is not null ? reportsToNames.GetValueOrDefault(rid) : null,
            fa.Count == 0 ? null : fa,
            sensitive?.RevealExpiries, c.PreferredLanguage, c.OptedOutChannels(), c.BuyingRoles.ToList());
    }

    /// <summary>
    /// Every money figure on the account rollup, in one place, so "not one
    /// figure may move" has exactly one function to review. `billed`
    /// (WonValue on the wire) is gross non-void, non-draft invoice value — NOT
    /// the sum of won lead estimates, deliberately: a draft has not actually
    /// been billed, and a written-off/void invoice never was real money.
    /// `overdue` uses the org's own reporting-calendar timezone, the same
    /// definition /collections uses, so the two never disagree for four hours
    /// a day.
    ///
    /// Masking (account-money-masking, owner decision 2026-09-27):
    /// <paramref name="canSeeValues"/> (ViewLeadValues) masks OpenValue to
    /// null — the SAME permission and the SAME null-not-zero convention
    /// LeadMapping.ToDto already applies to Lead.EstimatedValue, because an
    /// account tile summing lead estimates is exactly the figure that
    /// permission already hides one level down. <paramref name="canSeeFinancials"/>
    /// (ViewAccountFinancials — the same flag callers already thread through
    /// as `canSeeFullFinancials` to choose WHICH invoices are summed) now ALSO
    /// masks the resulting Billed/Outstanding/Overdue/NextPromisedDate to
    /// null: previously that permission only narrowed which invoices counted
    /// and the total itself was never hidden, which is the leak this story
    /// fixes. Both default to `true` (no-op) for the same reason
    /// customFieldDefs/callerRole above do: every existing 2-8 arg call/test
    /// site keeps compiling and behaving exactly as before until its caller
    /// is updated to pass the real permission.
    /// </summary>
    private static AccountDto ToDto(
        PlaybookPhases phases, CalendarDto cal, Account a, List<Lead> leads, List<Invoice>? invoices = null,
        DateTime? nextPromisedDate = null, List<CustomFieldDef>? defs = null, string callerRole = "",
        bool canSeeValues = true, bool canSeeFinancials = true, Extras? extras = null,
        // E12.2 - the caller's sensitive-data access (ctx.Sensitive). Null = every category at full, today's behaviour.
        SensitiveAccess? sensitive = null)
    {
        sensitive = sensitive?.ForRecord("account", a.Id); // E12.5: an approved reveal for THIS account
        var fa = new Dictionary<string, string>(StringComparer.Ordinal);
        var cd = (sensitive ?? SensitiveAccess.Unrestricted).LevelFor(SensitiveCategories.ContactDetails, a.OwnerId, a.TeamId);
        string? C(string f, string? v, CustomFieldMasking.Kind k = CustomFieldMasking.Kind.Text) => CustomFieldMasking.Text(f, v, cd, k, fa);
        // D5: each lead's OWN playbook, not the org list alone — the exact bug
        // the owner found (a chip on this page reading the playbook's raw
        // "proposal_sent" key because it wasn't even recognised as open).
        var open = leads.Where(l => phases.IsOpen(l.PlaybookId, l.Status)).ToList();
        var inv = invoices ?? new List<Invoice>();
        var billed = inv.Where(i => i.Status != "void" && i.Status != "draft").Sum(i => i.Amount);
        var outstandingInvoices = inv.Where(i => Invoice.IsReceivable(i.Status)).ToList();
        var outstanding = outstandingInvoices.Sum(Invoice.BalanceOf);
        var now = DateTime.UtcNow;
        var overdue = outstandingInvoices
            .Where(i => ReportingCalendar.IsOverdue(cal, i.DueDate, now))
            .Sum(Invoice.BalanceOf);
        return new AccountDto(
            a.Id, a.OwnerId, a.Name, a.Industry, a.Website, C("phone", a.Phone, CustomFieldMasking.Kind.Phone), a.Notes,
            C("address", a.Address), C("city", a.City), C("state", a.State), C("postal_code", a.PostalCode), C("country", a.Country),
            a.Owner?.FullName, a.Contacts.Count, open.Count,
            canSeeValues ? open.Sum(l => l.EstimatedValue) : null,
            canSeeFinancials ? billed : null,
            canSeeFinancials ? outstanding : null,
            canSeeFinancials ? overdue : null,
            canSeeFinancials ? nextPromisedDate : null, a.CreatedAt, a.UpdatedAt,
            a.Contacts.OrderBy(c => c.Name, StringComparer.Ordinal).Take(ContactNamePreview).Select(c => c.Name).ToList(),
            a.CountryCode,
            CustomFieldMasking.Apply(ParseCustom(a.Custom), defs ?? new(), callerRole, sensitive, a.OwnerId, a.TeamId, fa),
            a.EmailDomain,
            extras is not null && extras.LastContact.TryGetValue(a.Id, out var lastContactAt) ? lastContactAt : null,
            extras?.Steps.GetValueOrDefault(a.Id),
            extras is null ? null : extras.OwnTags.GetValueOrDefault(a.Id) ?? [],
            extras is null ? null : extras.LeadTags.GetValueOrDefault(a.Id) ?? [],
            extras is not null && extras.Renewals.TryGetValue(a.Id, out var renewalDate) ? renewalDate : null,
            fa.Count == 0 ? null : fa,
            sensitive?.RevealExpiries,
            a.Status,
            a.ChildCount,
            InheritedFieldsOf(a, extras),
            a.LoyaltyBalance,
            a.LoyaltyTier);
    }

    /// <summary>E14.1: for each inheriting field, whether the account follows its direct parent and who that parent is; null when it has no parent
    /// or the org lists no inheriting field (or the response did not load extras).</summary>
    private static Dictionary<string, AccountInheritedFieldDto>? InheritedFieldsOf(Account a, Extras? extras)
    {
        if (extras is null || extras.InheritedFields.Count == 0 || !extras.Parents.TryGetValue(a.Id, out var parent)) return null;
        return extras.InheritedFields.ToDictionary(f => f, f => new AccountInheritedFieldDto(!a.InheritOverrides.Contains(f), parent.ParentId, parent.ParentName));
    }

    // --- list / count / facets ---

    /// <summary>
    /// May this caller VIEW this account? The three loyalty endpoints each loaded
    /// the account themselves purely to answer it, which was the last reason
    /// AccountsController held a DbContext.
    ///
    /// Returns a Refusal or null, rather than the account: none of those callers
    /// wanted the entity, only permission to proceed.
    /// </summary>
    public async Task<Refusal?> CheckViewAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default)
    {
        var account = await _store.FindForAccessAsync(id, ct);
        if (account is null) return new Refusal("Account not found", NotFound: true);
        return RecordAccess.CanView(ctx, account.Value.OwnerId, account.Value.TeamId)
            ? null
            : new Refusal("Not allowed to access this account", Forbidden: true);
    }

    // --- GET /accounts/{id}/history --------------------------------------------

    /// <summary>
    /// Field-change audit for this account, newest-first, cursor-paged (design
    /// §6/§8). Same view-authorization as GET /accounts/{id}. Scoped to the
    /// account's OWN rows only — not a rollup of its leads' history (that is
    /// E1.6's timeline, a later, separate feature; this is just the audit read).
    /// </summary>
    public async Task<(Refusal? Refusal, PagedResult<FieldChangeAuditEntryDto>? Page)> HistoryAsync(
        RecordAccessContext ctx, bool canSeeValues, bool canSeeContactDetails, Guid id, string? cursor, int? limit, CancellationToken ct = default)
    {
        var refusal = await CheckViewAsync(ctx, id, ct);
        if (refusal is not null) return (refusal, null);

        var histAccount = await _store.GetForAccessCheckAsync(id);
        var page = await _store.HistoryPageAsync(
            FieldAudit.EntityTypes.Account, id, cursor, limit, canSeeValues, canSeeContactDetails, ct,
            ctx.Sensitive, histAccount?.OwnerId, histAccount?.TeamId);
        return (null, page);
    }

    // --- GET /accounts/{id}/timeline ---------------------------------------------

    /// <summary>
    /// The unified record timeline (design §7/§8/§9), newest first, cursor-paged.
    /// <paramref name="scope"/> "all" (default) rolls up every child lead's
    /// items, tagged with lead id/name; "account" narrows to this account
    /// row's own items. Same view-authorization as GET /accounts/{id}. See
    /// <see cref="TimelineService"/> for the union query, precedence/dedupe
    /// rule, and masking.
    /// </summary>
    public async Task<(Refusal? Refusal, PagedResult<TimelineItemDto>? Page)> TimelineAsync(
        RecordAccessContext ctx, bool canSeeValues, bool canSeeContactDetails, bool canSeeFinancials,
        Guid id, string? cursor, int? limit, string? kinds, string? scope, CancellationToken ct = default)
    {
        var refusal = await CheckViewAsync(ctx, id, ct);
        if (refusal is not null) return (refusal, null);

        var page = await _store.TimelinePageAsync(
            id, cursor, limit, kinds, scope,
            new TimelineService.TimelineView(canSeeValues, canSeeContactDetails, canSeeFinancials), ct);
        // The rollup spans child leads; the account's own owner/team is the scope the number is judged on (fails closed).
        var timelineAccount = await _store.GetForAccessCheckAsync(id);
        return (null, CustomFieldMasking.MaskTimeline(page, ctx.Sensitive, timelineAccount?.OwnerId, timelineAccount?.TeamId));
    }

    public sealed record ListParams(
        string? Search, int? Limit, int? Offset, double? Similarity,
        string? Owner, string? Industry, bool? HasOpenValue, string? Sort,
        bool Paged, string? Cursor,
        // One-table: JSON `filters` / `sorts` (TableFilterDto / TableSortDto). `sorts`, when present, wins over
        // the legacy `sort`; every other parameter keeps its meaning and ANDs with `filters`.
        string? Filters = null, string? Sorts = null);

    public sealed record ListOutcome(Refusal? Refusal, List<AccountDto>? Items, string? NextCursor)
    {
        public static ListOutcome Refused(Refusal r) => new(r, null, null);
        public static ListOutcome Ok(List<AccountDto> items, string? cursor) => new(null, items, cursor);
    }

    /// <summary>
    /// `sort`/`hasOpenValue` guard (account-money-masking, owner decision
    /// 2026-09-27, build item 2): a caller may not sort or filter by a figure
    /// this same call already masks to null for them — IGNORED (silently
    /// falls back to the unfiltered/default-sorted list) rather than refused,
    /// so an existing bookmark/saved view a caller's role later loses a
    /// permission under doesn't start 400ing. No precedent exists on the leads
    /// side to mirror: LeadListProcess's own `sort=value` carries no such
    /// guard at all (reported to the coordinator as a second leak, out of
    /// this story's scope to fix) and leads have no value-presence filter to
    /// compare against.
    /// </summary>
    private static string SortForCaller(string? sort, bool canSeeValues, bool canSeeFinancials)
    {
        var normalized = AccountKeyset.NormalizeSort(sort);
        if (normalized == "open_value" && !canSeeValues) return AccountKeyset.DefaultSort;
        if (normalized == "won_value" && !canSeeFinancials) return AccountKeyset.DefaultSort;
        return normalized;
    }

    private static bool? OpenValueFilterForCaller(bool? hasOpenValue, bool canSeeValues) =>
        canSeeValues ? hasOpenValue : null;

    // ---- one-table: columns, filters, sorts ------------------------------------------

    /// <summary>The columns this caller may use, and the same list for a caller who may use all of them (so a
    /// hidden column is refused by name rather than reported as unknown).</summary>
    private async Task<(List<TableColumn<Account>> Visible, List<TableColumn<Account>> Everything)> ColumnSetsAsync(
        RecordAccessContext ctx, bool canSeeValues, bool canSeeFinancials, string callerRole, PlaybookPhases phases,
        AccountColumnOptionSources? options, CancellationToken ct)
    {
        var defs = await ActiveDefsAsync(CustomFieldDef.ObjectTypes.Account, ct);
        var invoices = await _store.ReceivableInvoicesAsync(ctx, canSeeFinancials);
        // Accounts rework: the shared last-contact moments, the AMCs and "start of the org's today" for the new columns.
        var sources = await _store.ColumnSourcesAsync(DateTime.UtcNow);
        // The org's status list always goes in (not only for the catalogue): it is the natural sort order of the status column.
        var statuses = (await _store.StatusListAsync(ct)).Select(s => new TableColumnOptionDto(s.Key, s.Label)).ToList();
        return (
            AccountColumnRegistry.Build(defs, canSeeValues, canSeeFinancials, callerRole, phases, invoices, options, sources, ctx.Sensitive, statuses),
            AccountColumnRegistry.Build(defs, true, true, "admin", phases, invoices, null, sources, statuses: statuses));
    }

    private async Task<ResolvedTableQuery<Account>> ResolveTableAsync(
        RecordAccessContext ctx, bool canSeeValues, bool canSeeFinancials, string callerRole, PlaybookPhases phases,
        string? filters, string? sorts, double? similarity, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(filters) && string.IsNullOrWhiteSpace(sorts)) return ResolvedTableQuery<Account>.None;
        var (visible, everything) = await ColumnSetsAsync(ctx, canSeeValues, canSeeFinancials, callerRole, phases, null, ct);
        return await TableQuerySpecs.ResolveAsync(visible, everything, filters, sorts,
            async () => new FilterContext(await _store.CalendarAsync(), DateTime.UtcNow, _search.TrgmEnabled,
                _search.LevenshteinEnabled, similarity is > 0 and <= 1 ? similarity.Value : FuzzySearch.DefaultSimilarityThreshold));
    }

    /// <summary>The filtered query with the column filters ANDed in, and the pg_trgm scoping their typo-tolerant
    /// operators need. Not for the list itself, whose search-ranking branch must not be triggered by a column filter.</summary>
    private static AccountStore.FilteredAccountsQuery Narrow(
        AccountStore.FilteredAccountsQuery f, ResolvedTableQuery<Account> tq, double? similarity) =>
        tq.Predicate is null ? f : f with
        {
            Query = tq.Filter(f.Query),
            FuzzyActive = f.FuzzyActive || tq.Fuzzy,
            ShortFuzzyActive = f.ShortFuzzyActive || tq.ShortFuzzy,
            Threshold = f.FuzzyActive ? f.Threshold : (similarity is > 0 and <= 1 ? similarity.Value : f.Threshold),
        };

    /// <summary>GET /accounts/columns — the catalogue for this caller.</summary>
    public async Task<TableColumnsDto> ColumnsAsync(
        RecordAccessContext ctx, bool canSeeFullFinancials, bool canSeeValues, string callerRole = "", CancellationToken ct = default)
    {
        var phases = await _store.PhasesAsync(ct);
        var options = new AccountColumnOptionSources(
            await _store.TeamOptionsAsync(ctx), await _store.IndustryOptionsAsync(ctx), await _store.TagOptionsAsync(),
            await _store.PersonOptionsAsync(ctx));
        var (visible, _) = await ColumnSetsAsync(ctx, canSeeValues, canSeeFullFinancials, callerRole, phases, options, ct);
        return TableQuerySpecs.Catalogue(visible);
    }

    public async Task<ListOutcome> ListAsync(
        RecordAccessContext ctx, bool canSeeFullFinancials, bool canSeeValues, ListParams p, string callerRole = "", CancellationToken ct = default)
    {
        try
        {
            return await ListCoreAsync(ctx, canSeeFullFinancials, canSeeValues, p, callerRole, ct);
        }
        catch (TableQueryRefusedException e)
        {
            return ListOutcome.Refused(new Refusal(e.Message, Code: "invalid_query", Field: e.Field));
        }
    }

    private async Task<ListOutcome> ListCoreAsync(
        RecordAccessContext ctx, bool canSeeFullFinancials, bool canSeeValues, ListParams p, string callerRole, CancellationToken ct)
    {
        var accountDefs = await ActiveDefsAsync(CustomFieldDef.ObjectTypes.Account, ct);
        var phases = await _store.PhasesAsync(ct);
        var effectiveHasOpenValue = OpenValueFilterForCaller(p.HasOpenValue, canSeeValues);
        var f = await _store.BuildFilteredQueryAsync(ctx, phases, _search, p.Search, p.Similarity, p.Owner, p.Industry, hasOpenValue: effectiveHasOpenValue);
        var tq = await ResolveTableAsync(ctx, canSeeValues, canSeeFullFinancials, callerRole, phases, p.Filters, p.Sorts, p.Similarity, ct);
        var q = tq.Filter(f.Query);
        // A team sort reads the team's name; the cursor of the last row needs it loaded.
        if (tq.Sorts is { } sortKeys && sortKeys.Any(k => k.Column.Key == "team_id")) q = q.Include(a => a.Team);
        // A typo-tolerant column filter needs the pg_trgm scoping even when the search box is empty.
        var needsTrgm = f.FuzzyActive || tq.Fuzzy;
        var needsShortTrgm = f.ShortFuzzyActive || tq.ShortFuzzy;
        var trgmThreshold = f.FuzzyActive ? f.Threshold : (p.Similarity is > 0 and <= 1 ? p.Similarity.Value : f.Threshold);
        var sortKey = SortForCaller(p.Sort, canSeeValues, canSeeFullFinancials);
        var invoicesQ = await _store.ReceivableInvoicesAsync(ctx, canSeeFullFinancials);

        IOrderedQueryable<Account> ordered;
        if (f.FuzzyActive)
        {
            var relevance = q
                .OrderBy(a => !(
                    EF.Functions.ILike(a.Name, f.SearchLike!) ||
                    (a.Industry != null && EF.Functions.ILike(a.Industry, f.SearchLike!)) ||
                    f.ExactContactIds.Contains(a.Id)))
                .ThenByDescending(a =>
                    EF.Functions.TrigramsSimilarity(a.Name, f.SearchTerm!) +
                    (a.Industry != null ? EF.Functions.TrigramsSimilarity(a.Industry, f.SearchTerm!) : 0));
            ordered = tq.Sorts is { } rk
                ? TableMultiKeyset<Account>.ApplyOrder(relevance, rk, alreadyOrdered: true)
                : AccountKeyset.ApplyRelevanceTiebreak(relevance, sortKey, phases, invoicesQ);
        }
        else
        {
            ordered = tq.Sorts is { } ok
                ? TableMultiKeyset<Account>.ApplyOrder(q, ok)
                : AccountKeyset.ApplyOrder(q, sortKey, phases, invoicesQ);
        }

        if (!p.Paged)
        {
            var legacy = ordered.AsQueryable();
            if (p.Offset is int off && off > 0) legacy = legacy.Skip(off);
            if (p.Limit is int lim && lim > 0) legacy = legacy.Take(lim);
            var legacyRows = await _store.RunAsync(needsTrgm, needsShortTrgm, trgmThreshold, () => legacy.ToListAsync());
            var (legacyInvoices, legacyPromised) = await _store.LoadReceivablesAsync(legacyRows.Select(a => a.Id), ctx, canSeeFullFinancials);
            var legacyCal = await _store.CalendarAsync();
            var legacyExtras = await ExtrasForAsync(legacyRows.Select(a => a.Id).ToList(), ct);
            var legacyItems = legacyRows.Select(a => ToDto(
                phases, legacyCal, a, a.Leads.ToList(),
                legacyInvoices.GetValueOrDefault(a.Id),
                legacyPromised.TryGetValue(a.Id, out var d) ? d : null, accountDefs, callerRole,
                canSeeValues, canSeeFullFinancials, legacyExtras, ctx.Sensitive)).ToList();
            return ListOutcome.Ok(legacyItems, null);
        }

        var pageSize = p.Limit is int l2 && l2 > 0 ? l2 : 20;
        var fingerprint = CursorToken.Fingerprint(
            p.Search, p.Owner, p.Industry, p.Similarity?.ToString(CultureInfo.InvariantCulture), f.FuzzyActive.ToString(),
            sortKey, effectiveHasOpenValue?.ToString(), tq.CanonicalFilters, tq.CanonicalSorts);
        var decoded = CursorToken.Decode(p.Cursor);
        if (decoded != null && decoded.Filters != fingerprint)
            return ListOutcome.Refused(new Refusal(
                "The filters changed since this page was fetched. Reload the list from the start.",
                Code: "stale_cursor"));

        List<Account> pageRows;
        string? nextCursor = null;
        var keysetHasMore = false;
        if (f.FuzzyActive)
        {
            var startOffset = decoded is { Mode: "offset" } ? decoded.Offset ?? 0 : 0;
            var fetched = await _store.RunAsync(needsTrgm, needsShortTrgm, trgmThreshold, () => ordered.Skip(startOffset).Take(pageSize + 1).ToListAsync());
            var hasMore = fetched.Count > pageSize;
            pageRows = fetched.Take(pageSize).ToList();
            nextCursor = hasMore
                ? CursorToken.Encode(new CursorPayload("offset", fingerprint, sortKey, null, startOffset + pageSize))
                : null;
        }
        else
        {
            var scoped = decoded is { Mode: "keyset", Key: not null }
                ? (tq.Sorts is { } ck
                    ? TableMultiKeyset<Account>.ApplyCursor(ordered, ck, decoded.Key)
                    : AccountKeyset.ApplyCursor(ordered, sortKey, decoded.Key, phases, invoicesQ))
                : (IQueryable<Account>)ordered;
            var fetched = tq.Fuzzy
                ? await _store.RunAsync(needsTrgm, needsShortTrgm, trgmThreshold, () => scoped.Take(pageSize + 1).ToListAsync())
                : await scoped.Take(pageSize + 1).ToListAsync();
            keysetHasMore = fetched.Count > pageSize;
            pageRows = fetched.Take(pageSize).ToList();
        }

        var (invoicesByAccount, nextPromised) = await _store.LoadReceivablesAsync(pageRows.Select(a => a.Id), ctx, canSeeFullFinancials);
        var pageExtras = await ExtrasForAsync(pageRows.Select(a => a.Id).ToList(), ct);

        if (!f.FuzzyActive && keysetHasMore)
        {
            // The billed total of an account, from the SAME bulk invoices query the page's DTOs are rendered from
            // (never re-queried per row), with the identical not-void/not-draft filter `billed` uses.
            decimal BilledOf(Account a) =>
                (invoicesByAccount.GetValueOrDefault(a.Id) ?? new List<Invoice>())
                    .Where(i => i.Status != "void" && i.Status != "draft").Sum(i => i.Amount);
            decimal OutstandingOf(Account a) =>
                (invoicesByAccount.GetValueOrDefault(a.Id) ?? new List<Invoice>())
                    .Where(i => Invoice.IsReceivable(i.Status)).Sum(Invoice.BalanceOf);
            if (tq.Sorts is { } nk)
            {
                nextCursor = CursorToken.Encode(new CursorPayload(
                    "keyset", fingerprint, "sorts",
                    TableMultiKeyset<Account>.KeyOf(pageRows[^1], nk, (col, a) => col.Key switch
                    {
                        "won_value" => BilledOf(a),
                        "outstanding" => OutstandingOf(a),
                        // The shared last-contact value of THIS page's rows (the row cannot run the subquery itself).
                        "last_contact_at" => LastContactService.Effective(pageExtras.LastContact, a.Id, a.CreatedAt),
                        "renewal_date" => pageExtras.Renewals.TryGetValue(a.Id, out var renewal) ? renewal : null,
                        _ => null,
                    }), null));
            }
            else
            {
                Dictionary<Guid, decimal>? wonValues = sortKey == "won_value"
                    ? pageRows.ToDictionary(a => a.Id, BilledOf)
                    : null;
                nextCursor = CursorToken.Encode(new CursorPayload(
                    "keyset", fingerprint, sortKey, AccountKeyset.KeyOf(pageRows[^1], sortKey, phases, wonValues), null));
            }
        }

        var pageCal = await _store.CalendarAsync();
        var items = pageRows.Select(a => ToDto(
            phases, pageCal, a, a.Leads.ToList(),
            invoicesByAccount.GetValueOrDefault(a.Id),
            nextPromised.TryGetValue(a.Id, out var d) ? d : null, accountDefs, callerRole,
            canSeeValues, canSeeFullFinancials, pageExtras, ctx.Sensitive)).ToList();
        return ListOutcome.Ok(items, nextCursor);
    }

    public async Task<int> CountAsync(
        RecordAccessContext ctx, string? search, double? similarity, string? owner, string? industry, bool? hasOpenValue,
        bool canSeeValues = true, CancellationToken ct = default,
        string? filters = null, bool canSeeFullFinancials = true, string callerRole = "")
    {
        var phases = await _store.PhasesAsync(ct);
        var f = await _store.BuildFilteredQueryAsync(
            ctx, phases, _search, search, similarity, owner, industry, hasOpenValue: OpenValueFilterForCaller(hasOpenValue, canSeeValues));
        // The count describes the identical set the list does, so the column filters apply here too.
        f = Narrow(f, await ResolveTableAsync(ctx, canSeeValues, canSeeFullFinancials, callerRole, phases, filters, null, similarity, ct), similarity);
        return await _store.RunAsync(f, () => f.Query.CountAsync());
    }

    /// <summary>"Select all N matching" (POST /accounts/bulk with <c>match</c>): the ids of the identical set <see cref="CountAsync"/>
    /// counts - the same filtered query, the same caller scoping and column-filter narrowing - so the total the client shows from
    /// /accounts/count is the set this resolves. The bulk path then checks each account on its own.</summary>
    public async Task<List<Guid>> MatchingIdsAsync(
        RecordAccessContext ctx, AccountMatchInput m, bool canSeeValues, bool canSeeFullFinancials, string callerRole, CancellationToken ct = default)
    {
        var phases = await _store.PhasesAsync(ct);
        var f = await _store.BuildFilteredQueryAsync(
            ctx, phases, _search, m.Search, m.Similarity, m.Owner, m.Industry, hasOpenValue: OpenValueFilterForCaller(m.HasOpenValue, canSeeValues));
        f = Narrow(f, await ResolveTableAsync(ctx, canSeeValues, canSeeFullFinancials, callerRole, phases, m.Filters, null, m.Similarity, ct), m.Similarity);
        // Bounded by the org's bulk_match_limit BEFORE anything is written: read one past the limit, and only then count exactly.
        var limit = await _orgSettings.GetBulkMatchLimitAsync();
        var ids = await _store.RunAsync(f, () => f.Query.Select(a => a.Id).Take(limit + 1).ToListAsync());
        if (ids.Count > limit) throw new BulkMatchTooLargeException(await _store.RunAsync(f, () => f.Query.CountAsync()), limit);
        return ids;
    }

    public async Task<AccountFacetsDto> FacetsAsync(
        RecordAccessContext ctx, string? search, double? similarity, string? owner, string? industry, bool? hasOpenValue,
        bool canSeeValues = true, CancellationToken ct = default,
        string? filters = null, bool canSeeFullFinancials = true, string callerRole = "")
    {
        hasOpenValue = OpenValueFilterForCaller(hasOpenValue, canSeeValues);
        static List<FacetCount> Shape(IEnumerable<(string? Key, int Count)> rows) =>
            rows.Where(r => !string.IsNullOrWhiteSpace(r.Key))
                .Select(r => new FacetCount(r.Key!, r.Count))
                .OrderByDescending(r => r.Count)
                .ToList();

        var phases = await _store.PhasesAsync(ct);
        // Each option's count describes the list as filtered, so the column filters narrow every facet too.
        var tq = await ResolveTableAsync(ctx, canSeeValues, canSeeFullFinancials, callerRole, phases, filters, null, similarity, ct);

        var fo = Narrow(await _store.BuildFilteredQueryAsync(ctx, phases, _search, search, similarity, owner, industry, "owner", hasOpenValue), tq, similarity);
        var ownerRows = await _store.RunAsync(fo,
            () => fo.Query.GroupBy(a => a.OwnerId).Select(g => new { g.Key, C = g.Count() }).ToListAsync());

        var fi = Narrow(await _store.BuildFilteredQueryAsync(ctx, phases, _search, search, similarity, owner, industry, "industry", hasOpenValue), tq, similarity);
        var industryRows = await _store.RunAsync(fi,
            () => fi.Query.GroupBy(a => a.Industry).Select(g => new { g.Key, C = g.Count() }).ToListAsync());

        return new AccountFacetsDto(
            Shape(ownerRows.Select(r => ((string?)r.Key.ToString(), r.C))),
            Shape(industryRows.Select(r => (r.Key, r.C))));
    }

    // --- export ---

    // Public, not internal: ProcessApi has no InternalsVisibleTo grant for
    // SalesApi.Tests (only the host SalesApi and SalesApi.SystemApi do), and
    // this array is exactly the sort of explicit, reviewable export contract
    // a test should be able to assert against directly.
    public static readonly string[] CsvColumns =
    {
        "name", "industry", "status", "website", "phone", "address", "city", "state",
        "postal_code", "country", "contact_count", "open_leads", "open_value", "won_value",
    };

    // Mirrors LeadListProcess.ExportCsvAsync's own "canSeeValues ? value.ToString()
    // : null — left EMPTY rather than dropped from the header" convention
    // exactly (account-money-masking): open_value follows ViewLeadValues,
    // won_value follows ViewAccountFinancials, same as every other surface in
    // this class.
    public async Task<string> ExportCsvAsync(
        RecordAccessContext ctx, bool canSeeFullFinancials, bool canSeeValues = true, CancellationToken ct = default,
        string? filters = null, string? sorts = null, string callerRole = "", IReadOnlyCollection<Guid>? ids = null)
    {
        var phases = await _store.PhasesAsync(ct);
        // One-table: the file holds the rows the filtered, sorted table shows (everything, as before, with neither).
        var tq = await ResolveTableAsync(ctx, canSeeValues, canSeeFullFinancials, callerRole, phases, filters, sorts, null, ct);
        Func<IQueryable<Account>, IOrderedQueryable<Account>>? order = tq.Sorts is { } xk
            ? src => TableMultiKeyset<Account>.ApplyOrder(src, xk)
            : null;
        // Accounts rework (decision 13): "Export selected" passes the ticked ids; they narrow the visible set, never widen it.
        var accounts = await _store.ExportRowsAsync(ctx, tq.Predicate, order, tq.Fuzzy, tq.ShortFuzzy, ids: ids);
        var (invoicesByAccount, _) = await _store.LoadReceivablesAsync(accounts.Select(a => a.Id), ctx, canSeeFullFinancials);

        // The status column carries the LABEL (the file is for people); a key the org no longer lists is written as stored.
        var statusLabels = (await _store.StatusListAsync(ct)).ToDictionary(s => s.Key, s => s.Label);
        var rows = new List<IEnumerable<string?>> { CsvColumns.Append("owner_name") };
        foreach (var a in accounts)
        {
            var open = a.Leads.Where(l => phases.IsOpen(l.PlaybookId, l.Status)).ToList();
            var billed = (invoicesByAccount.GetValueOrDefault(a.Id) ?? new List<Invoice>())
                .Where(i => i.Status != "void" && i.Status != "draft").Sum(i => i.Amount);
            // E12.2 - exactly what the account DTO shows this caller (masked text / blank), per record.
            var cd = (ctx.Sensitive ?? SensitiveAccess.Unrestricted).LevelFor(SensitiveCategories.ContactDetails, a.OwnerId, a.TeamId);
            string? Cell(string? v, CustomFieldMasking.Kind k = CustomFieldMasking.Kind.Text) => CustomFieldMasking.Text("export", v, cd, k, null);
            rows.Add(new string?[]
            {
                a.Name, a.Industry, statusLabels.GetValueOrDefault(a.Status) ?? a.Status, a.Website, Cell(a.Phone, CustomFieldMasking.Kind.Phone), Cell(a.Address), Cell(a.City), Cell(a.State), Cell(a.PostalCode), Cell(a.Country),
                a.Contacts.Count.ToString(CultureInfo.InvariantCulture),
                open.Count.ToString(CultureInfo.InvariantCulture),
                canSeeValues ? open.Sum(l => l.EstimatedValue).ToString(CultureInfo.InvariantCulture) : null,
                canSeeFullFinancials ? billed.ToString(CultureInfo.InvariantCulture) : null,
                a.Owner?.FullName,
            });
        }
        return CsvUtil.ToCsv(rows);
    }

    // --- match / match-bulk ---

    private static string NormalizeCompany(string? name) => AccountLinkService.CompanyKey(name);

    private static string ExtractDomain(string? email)
    {
        if (string.IsNullOrWhiteSpace(email)) return "";
        var m = Regex.Match(email, @"@([A-Za-z0-9.-]+\.[A-Za-z]{2,})\s*$");
        return m.Success ? m.Groups[1].Value.ToLowerInvariant() : "";
    }

    /// <summary>
    /// THE "looks like the same company" predicate - behind GET /accounts/match AND the create-time "block" mode (decision 8), so
    /// there is one definition of a near match: a company-name token of 3+ letters (after <see cref="AccountLinkService.CompanyKey"/>
    /// normalisation) found in the account's name, or an email domain matching the website / name root / a contact's address.
    /// </summary>
    private static List<Account> NearMatches(IEnumerable<Account> accounts, string? company, string? email)
    {
        var all = accounts as IList<Account> ?? accounts.ToList();
        var matches = new List<Account>();

        var core = NormalizeCompany(company);
        var tokens = core.Split(' ', StringSplitOptions.RemoveEmptyEntries).Where(t => t.Length >= 3).ToArray();
        if (tokens.Length > 0)
        {
            var rx = new Regex(string.Join("|", tokens.Select(Regex.Escape)), RegexOptions.IgnoreCase);
            matches.AddRange(all.Where(a => rx.IsMatch(NormalizeCompany(a.Name))));
        }

        var domain = ExtractDomain(email);
        if (!string.IsNullOrEmpty(domain))
        {
            var root = domain.Split('.')[0];
            matches.AddRange(all.Where(a =>
                (a.Website != null && a.Website.Contains(domain, StringComparison.OrdinalIgnoreCase)) ||
                (root.Length >= 3 && a.Name.Contains(root, StringComparison.OrdinalIgnoreCase)) ||
                a.Contacts.Any(c => c.Email != null && c.Email.EndsWith("@" + domain, StringComparison.OrdinalIgnoreCase))));
        }
        return matches.DistinctBy(a => a.Id).ToList();
    }

    public async Task<List<AccountDto>> MatchAsync(
        RecordAccessContext ctx, bool canSeeFullFinancials, string? company, string? email,
        bool canSeeValues = true, CancellationToken ct = default)
    {
        var accounts = await _store.AllViewableWithIncludesAsync(ctx);
        var top = NearMatches(accounts, company, email).Take(5).ToList();
        var (invoicesByAccount, nextPromised) = await _store.LoadReceivablesAsync(top.Select(a => a.Id), ctx, canSeeFullFinancials);
        var phases = await _store.PhasesAsync(ct);
        var cal = await _store.CalendarAsync();
        var matchExtras = await ExtrasForAsync(top.Select(a => a.Id).ToList(), ct);
        return top.Select(a => ToDto(
            phases, cal, a, a.Leads.ToList(),
            invoicesByAccount.GetValueOrDefault(a.Id),
            nextPromised.TryGetValue(a.Id, out var d) ? d : null,
            canSeeValues: canSeeValues, canSeeFinancials: canSeeFullFinancials, extras: matchExtras, sensitive: ctx.Sensitive)).ToList();
    }

    /// <summary>Design §4.1's automatic derivation — fills
    /// <see cref="Account.EmailDomain"/> only when it is currently null;
    /// never overwrites a value a rep already set/derived (Apply's own
    /// comment). Reads existing contacts' emails from the DATABASE (a
    /// just-added, not-yet-saved contact would not appear in that query, so
    /// <paramref name="extraEmail"/> carries the current call's OWN new/
    /// changed email alongside the already-persisted ones).
    ///
    /// <paramref name="account"/> here typically comes from a no-tracking
    /// read (<c>AccountStore.GetForAccessCheckAsync</c>) — if the context is
    /// ALREADY tracking a different instance with the same key (a caller
    /// that loaded its own copy earlier in the same unit of work), that
    /// tracked instance is updated instead of attaching a second, conflicting
    /// one for the same id; only THIS one property is ever marked modified,
    /// so the write cannot clobber any other field this call never touched.</summary>
    private async Task RecomputeEmailDomainIfUnsetAsync(Account account, string? extraEmail, CancellationToken ct)
    {
        if (!string.IsNullOrEmpty(account.EmailDomain)) return;
        var emails = await _store.ContactEmailsForAccountAsync(account.Id, ct);
        if (extraEmail is not null) emails.Add(extraEmail);
        var domain = MailboxEmailDomain.MajorityDomain(emails);
        if (domain is null) return;

        _store.SetEmailDomain(account, domain);
    }

    public static string CompanyKey(string? name) => AccountLinkService.CompanyKey(name);

    public async Task<MatchBulkResultDto> MatchBulkAsync(RecordAccessContext ctx, List<string>? companies, CancellationToken ct = default)
    {
        var names = (companies ?? [])
            .Select(c => (c ?? "").Trim())
            .Where(c => c.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(2000)
            .ToList();
        if (names.Count == 0) return new MatchBulkResultDto(new(), new());

        var existing = await _store.ExistingAccountNamesAsync(ctx);
        var byKey = new Dictionary<string, (Guid Id, string Name)>(StringComparer.Ordinal);
        foreach (var a in existing)
        {
            var key = CompanyKey(a.Name);
            if (key.Length > 0) byKey.TryAdd(key, (a.Id, a.Name));
        }

        var matched = new List<MatchedAccountDto>();
        var unmatched = new List<string>();
        foreach (var name in names)
        {
            if (byKey.TryGetValue(CompanyKey(name), out var hit))
                matched.Add(new MatchedAccountDto(name, hit.Id, hit.Name));
            else unmatched.Add(name);
        }
        return new MatchBulkResultDto(matched, unmatched);
    }

    // --- S9c: the one-off "link my existing unlinked leads" admin tool ---
    //
    // Most leads predate any account-linking feature at all (162 accounts
    // against ~3,165 leads org-wide, at the time this was built) — CSV
    // import's own `link`/`link_and_create` modes only ever touch a NEW
    // import, never leads that already exist. This is the batch equivalent
    // for the leads already sitting there: preview what WOULD happen, then
    // (only on an explicit second call) apply exactly that. Same matcher as
    // CSV import (`AccountLinkService.CompanyKey`) — not a second one — and
    // the same "link only, never create, never merge" rule: an unmatched
    // lead's company simply has no account yet, and this tool does not
    // invent one.
    private async Task<(List<(Guid LeadId, Guid AccountId)> Matches, int Unmatched, int TotalUnlinked)>
        MatchUnlinkedLeadsAsync(RecordAccessContext ctx, CancellationToken ct)
    {
        var unlinked = await _store.UnlinkedLeadsAsync(ctx, ct);

        var accountsByKey = new Dictionary<string, Guid>(StringComparer.Ordinal);
        foreach (var a in await _store.ExistingAccountNamesAsync(ctx))
        {
            var key = CompanyKey(a.Name);
            if (key.Length > 0) accountsByKey.TryAdd(key, a.Id);
        }

        var matches = new List<(Guid, Guid)>();
        var unmatched = 0;
        foreach (var l in unlinked)
        {
            var key = CompanyKey(l.Company);
            if (key.Length > 0 && accountsByKey.TryGetValue(key, out var accountId))
                matches.Add((l.Id, accountId));
            else
                unmatched++;
        }
        return (matches, unmatched, unlinked.Count);
    }

    /// <summary>Writes nothing — the preview half of the tool.</summary>
    public async Task<LinkUnlinkedLeadsPreviewDto> PreviewLinkUnlinkedLeadsAsync(RecordAccessContext ctx, CancellationToken ct = default)
    {
        var (matches, unmatched, total) = await MatchUnlinkedLeadsAsync(ctx, ct);
        var accountIds = matches.Select(m => m.AccountId).Distinct().ToList();
        var names = await _store.AccountNamesByIdsAsync(accountIds, ct);
        var byAccount = matches.GroupBy(m => m.AccountId)
            .Select(g => new UnlinkedLeadMatchDto(g.Key, names.GetValueOrDefault(g.Key, "?"), g.Count()))
            .OrderByDescending(m => m.LeadCount)
            .ToList();
        return new LinkUnlinkedLeadsPreviewDto(total, byAccount, unmatched);
    }

    /// <summary>
    /// Applies EXACTLY the preview's own matching — recomputed rather than
    /// trusting a client-held snapshot, so a lead someone else linked or
    /// re-companied between the preview and this call is never double-handled
    /// or linked to a now-stale account. Also backfills any of those leads'
    /// EXISTING invoices that still point at no account (see S9b, and
    /// `LeadWriteProcess.UpdateAsync`'s own identical backfill for the
    /// interactive edit path — this is the same fix for the batch path).
    /// </summary>
    public async Task<LinkUnlinkedLeadsResultDto> LinkUnlinkedLeadsAsync(RecordAccessContext ctx, CancellationToken ct = default)
    {
        var (matches, _, _) = await MatchUnlinkedLeadsAsync(ctx, ct);
        if (matches.Count == 0) return new LinkUnlinkedLeadsResultDto(0, 0, 0);

        var leadIds = matches.Select(m => m.LeadId).ToList();
        var accountByLead = matches.ToDictionary(m => m.LeadId, m => m.AccountId);

        // Loaded and saved, not `ExecuteUpdateAsync`: EF InMemory (this
        // suite's own test provider) cannot translate a bulk update, only a
        // real relational provider can — see the identical note on
        // `LeadWriteProcess.UpdateAsync`'s own backfill. A few thousand leads
        // is a perfectly ordinary tracked batch, not the scale that needs a
        // bulk statement.
        var leadRows = await _store.LeadsByIdsTrackedAsync(leadIds, ct);
        foreach (var lead in leadRows)
        {
            var before = DomainEventWriter.LeadFolderFacts.Of(lead); // the lead's SharePoint folder moves under the account's
            lead.AccountId = accountByLead[lead.Id];
            _events.LeadChanged(lead.Id, ctx.UserId, before, DomainEventWriter.LeadFolderFacts.Of(lead));
        }

        var invoiceRows = await _store.InvoicesWithoutAccountForLeadsAsync(leadIds, ct);
        foreach (var inv in invoiceRows) inv.AccountId = accountByLead[inv.LeadId];

        await _store.SaveChangesAsync(ct);

        return new LinkUnlinkedLeadsResultDto(
            leadIds.Count, accountByLead.Values.Distinct().Count(), invoiceRows.Count);
    }

    // --- composite read (GET /accounts/{id}) ---

    public async Task<AccountDetailOutcome> GetAsync(
        RecordAccessContext ctx, bool canSeeFullFinancials, Guid id, string callerRole = "",
        bool canSeeValues = true, CancellationToken ct = default)
    {
        var account = await _store.GetDetailAsync(id);
        if (account is null) return AccountDetailOutcome.Refused(new Refusal("Account not found", NotFound: true));
        if (!RecordAccess.CanView(ctx, account.OwnerId, account.TeamId))
            return AccountDetailOutcome.Refused(new Refusal("Not allowed to access this account", Forbidden: true));

        var leads = account.Leads.OrderByDescending(l => l.UpdatedAt).ToList();
        var (invoicesByAccount, nextPromised) = await _store.LoadReceivablesAsync(new[] { account.Id }, ctx, canSeeFullFinancials);
        var accountInvoices = invoicesByAccount.GetValueOrDefault(account.Id) ?? new List<Invoice>();

        var invoiceRows = accountInvoices
            .OrderByDescending(i => i.IssuedAt)
            .Select(i => new AccountInvoiceLite(i.Id, i.Number, i.Amount, Invoice.BalanceOf(i), i.Status, i.DueDate))
            .ToList();
        var amcRows = (await _store.AmcsForAccountAsync(account.Id))
            .Select(a => new AccountAmcLite(a.Id, a.Title, a.ContractValue, a.RenewalDate, a.Status))
            .ToList();

        // Tags: DERIVED read — the plain union of the tags on this account's own
        // leads, deduped by tag id. No stored copy, no per-tag lead count.
        var accountTagRows = await _store.TagsForLeadsAsync(leads.Select(l => l.Id).ToList());
        var accountTags = accountTagRows
            .GroupBy(t => t.Id).Select(g => g.First())
            .OrderBy(t => t.NormalizedName)
            .Select(t => new TagRefDto(t.Id, t.Name, t.NormalizedName, t.Color))
            .ToList();

        var phases = await _store.PhasesAsync(ct);
        var cal = await _store.CalendarAsync();
        var accountDefs = await ActiveDefsAsync(CustomFieldDef.ObjectTypes.Account, ct);
        var contactDefs = await ActiveDefsAsync(CustomFieldDef.ObjectTypes.Contact, ct);

        // E3.4 — reports-to can point outside this account's own Contacts
        // collection (same-tree, not just same-account — see
        // ContactProcess.IsInSameAccountFamilyAsync), so the name lookup is a
        // small extra query rather than a lookup within `account.Contacts`.
        var reportsToIds = account.Contacts.Where(c => c.ReportsToContactId is not null)
            .Select(c => c.ReportsToContactId!.Value).Distinct().ToList();
        var reportsToNames = reportsToIds.Count == 0
            ? new Dictionary<Guid, string>()
            : await _store.ContactNamesByIdsAsync(reportsToIds, ct);

        // E3.4 — parent/subsidiary, direct children, relationships, external
        // ids and the rollup. Additive on AccountDetailDto (see its own doc),
        // so this never changes what any existing caller already reads.
        string? parentName = null;
        if (account.ParentAccountId is { } parentId)
        {
            var parent = await _store.LiteAsync(parentId, ct);
            // A parent the caller cannot even see is still named here — same
            // "the fact that a parent exists is not itself hidden" reasoning
            // as a lead's own ContactId pointing at a contact the caller may
            // not have contact_details.view for; only the FIGURES (the
            // rollup) are visibility-scoped, not the existence of a link.
            parentName = parent?.Name;
        }
        // Same visibility rule as ViewableDescendantsAsync/ChildrenTreeAsync — a
        // subsidiary the caller cannot see must not even show up as a name in
        // this list, the same "omitted, not just figure-less" rule the rollup
        // and the /tree endpoint both apply.
        var directChildren = (await _store.ChildrenOfAsync(new[] { account.Id }, ct))
            .Where(c => RecordAccess.CanView(ctx, c.OwnerId, c.TeamId)).ToList();
        // One batched read of the children's own tags (same OwnTagsForManyAsync the list DTO uses), not one per child.
        var childTags = await _store.OwnTagsForManyAsync(directChildren.Select(c => c.Id).ToList(), ct);
        var childSummaries = new List<AccountChildSummaryDto>();
        foreach (var c in directChildren.OrderBy(c => c.Name, StringComparer.Ordinal))
            childSummaries.Add(new AccountChildSummaryDto(c.Id, c.Name, c.ChildCount, // stored count (AccountChildCount keeps it), not a query per child
                c.Status, childTags.GetValueOrDefault(c.Id) ?? []));

        var relationshipRows = await _store.RelationshipsForAccountAsync(account.Id, ct);
        var relationships = relationshipRows.Select(r => ToRelationshipDto(r, account.Id))
            .OrderBy(r => r.Type).ThenBy(r => r.CounterpartyAccountName).ToList();

        var externalIdRows = await _store.ExternalIdsForAccountAsync(account.Id, ct);
        var externalIds = externalIdRows.Select(x => new AccountExternalIdDto(x.Id, x.System, x.Value, x.CreatedAt)).ToList();

        var rollup = await RollupAsync(ctx, canSeeFullFinancials, canSeeValues, account.Id, phases, ct);
        var detailExtras = await ExtrasForAsync([account.Id], ct);

        return AccountDetailOutcome.Ok(new AccountDetailDto(
            ToDto(phases, cal, account, leads, accountInvoices, nextPromised.TryGetValue(account.Id, out var d) ? d : null, accountDefs, callerRole,
                canSeeValues, canSeeFullFinancials, detailExtras, ctx.Sensitive),
            account.Contacts.OrderBy(c => c.Name).Select(c => ContactToDto(c, contactDefs, callerRole, reportsToNames, ctx.Sensitive, account.OwnerId, account.TeamId)).ToList(),
            // EstimatedValue masked without ViewLeadValues — same rule as
            // AccountDto.OpenValue/LeadDto.EstimatedValue (account-money-masking).
            leads.Select(l => new AccountLeadLite(
                l.Id, l.Name, l.Status, canSeeValues ? l.EstimatedValue : null, l.PlaybookId, l.DealType, l.ContactId, l.Company)).ToList(),
            invoiceRows,
            amcRows,
            accountTags,
            account.ParentAccountId, parentName, childSummaries, relationships, externalIds, rollup));
    }

    // --- create / update / delete ---

    // E3.1b (item 4) — customFieldDefs/callerRole default to null/"" (no-op:
    // see CustomFieldMasking.PreserveHidden's own early return) so every
    // existing 2-arg call/test keeps compiling; CreateAsync/UpdateAsync below
    // pass the real defs + role so a caller who cannot SEE a hidden Custom key
    // cannot blank it out by PATCHing a blob that omits it either.
    private static void Apply(Account a, AccountInput i, IReadOnlyCollection<CustomFieldDef>? customFieldDefs = null, string callerRole = "")
    {
        if (i.Name != null) a.Name = i.Name.Trim();
        if (i.Industry != null) a.Industry = i.Industry;
        if (i.Website != null) a.Website = i.Website;
        if (i.Phone != null) a.Phone = i.Phone;
        if (i.Notes != null) a.Notes = i.Notes;
        if (i.Address != null) a.Address = i.Address;
        if (i.City != null) a.City = i.City;
        if (i.State != null) a.State = i.State;
        if (i.PostalCode != null) a.PostalCode = i.PostalCode;
        if (i.Country != null) a.Country = i.Country;
        if (i.CountryCode != null) a.CountryCode = i.CountryCode;
        // E6.1 — an explicit edit always wins over the automatic derivation
        // (RecomputeEmailDomainAsync below only ever fills a NULL value).
        // Empty string clears a previously-set/derived domain.
        if (i.EmailDomain != null) a.EmailDomain = i.EmailDomain.Length == 0 ? null : i.EmailDomain.Trim().ToLowerInvariant();
        // E3.1 — validated by the caller (CreateAsync/UpdateAsync) BEFORE this
        // runs; Apply only ever writes an already-validated blob.
        if (i.Custom is { } custom)
        {
            var merged = CustomFieldMasking.PreserveHidden(
                custom, ParseCustom(a.Custom), customFieldDefs ?? Array.Empty<CustomFieldDef>(), callerRole);
            a.Custom = merged.GetRawText();
        }
    }

    public async Task<AccountOutcome> CreateAsync(
        Guid ownerId, Guid? orgId, AccountInput input, string callerRole = "",
        bool canSeeValues = true, bool canSeeFullFinancials = true, CancellationToken ct = default, bool canCreateTags = false, SensitiveAccess? sensitive = null,
        RecordAccessContext? access = null)
    {
        if (string.IsNullOrWhiteSpace(input.Name))
            return AccountOutcome.Refused(new Refusal("name is required"));
        // One account per company name. Without this an org could hold two
        // "Acme Ltd" rows, and a customer's leads, contacts and invoices would
        // split across them with nothing on screen explaining why.
        if (await _store.NameTakenAsync(input.Name!, null, ct))
            return AccountOutcome.Refused(new Refusal("An account named \"" + input.Name!.Trim() + "\" already exists.", Code: "duplicate_account_name"));
        // Decision 8: an EXACT name is always refused (above, both modes). In "block" mode a NEAR match is refused too, by the same
        // matcher GET /accounts/match runs; in "warn" (default) it goes through and the screen has already warned.
        if (await _orgSettings.GetAccountDuplicateModeAsync() == OrgSettings.AccountDuplicateBlock)
        {
            var near = NearMatches(await _store.AllAccountsForMatchAsync(), input.Name, null);
            if (near.Count > 0)
                return AccountOutcome.Refused(new Refusal(
                    "A similar account already exists: " + string.Join(", ", near.Take(3).Select(a => a.Name)) + ". Open it instead, or change the name.",
                    Code: "similar_account_name", Field: "name"));
        }
        if (input.Custom is { } newCustom)
        {
            var validationRefusal = await _customFields.ValidateValuesAsync(CustomFieldDef.ObjectTypes.Account, newCustom, callerRole, ct);
            if (validationRefusal is not null) return AccountOutcome.Refused(new Refusal(validationRefusal.Reason));
        }
        // Explicit Id, not the column's own `gen_random_uuid()` default — the
        // AccountCreated raise below (same save) needs the real id before
        // SaveChanges; see LeadWriteProcess.CreateAsync's identical comment.
        var account = new Account { Id = Guid.NewGuid(), OwnerId = ownerId, Name = input.Name!.Trim() };
        // Status: the org's list decides what is valid; a new account starts at prospect unless the caller picks another.
        var statusList = await _store.StatusListAsync(ct);
        if (input.Status is not null)
        {
            var statusRefusal = AccountStatuses.Refusal(statusList, input.Status);
            if (statusRefusal is not null) return AccountOutcome.Refused(new Refusal(statusRefusal, Field: "status"));
        }
        account.Status = input.Status ?? AccountStatuses.DefaultFor(statusList);
        // Accounts carry their own team because they are created and listed
        // independently of leads; deriving one from their leads would be
        // ambiguous (leads may sit in different teams) as well as slow.
        account.TeamId = orgId is Guid org ? await _store.ResolveTeamAsync(org, ownerId) : null;
        // E14.1: a child created under a parent starts following it - AccountInheritance (the save step) copies the parent's inheriting
        // values onto it, keeping any non-empty value the creator typed that differs. Same checks as PUT /accounts/{id}/parent.
        if (input.ParentAccountId is { } parentOnCreate)
        {
            if (access is null) return AccountOutcome.Refused(new Refusal("A parent account can only be set by a signed-in caller."));
            if (await ValidateParentAsync(access.Value, account.Id, parentOnCreate, ct) is { } parentRefusal) return AccountOutcome.Refused(parentRefusal);
            account.ParentAccountId = parentOnCreate;
        }
        var createdDefs = await ActiveDefsAsync(CustomFieldDef.ObjectTypes.Account, ct);
        if (SensitiveWriteRefusal(sensitive, input, null, ownerId, createdDefs) is { } createSensitive) return AccountOutcome.Refused(createSensitive);
        Apply(account, input, createdDefs, callerRole);
        _store.AddAccount(account);
        if (input.TagIds is not null || input.TagNames is not null)
        {
            var tagRefusal = await ApplyTagsAsync(account, ownerId, canCreateTags, input.TagIds, input.TagNames);
            if (tagRefusal is not null) return AccountOutcome.Refused(tagRefusal);
        }
        // E1 step 4 (to-do/e1-event-backbone-design.md §4) — "manual": a person
        // typed this in through POST /accounts, as opposed to CSV import or the
        // contact-promotion account-first step (AccountLinkService).
        _events.Raise(DomainEventTypes.Keys.AccountCreated, DomainEventTypes.AggregateTypes.Account, account.Id, ownerId,
            new DomainEventPayloads.AccountCreated(account.Id, account.Name, "manual"));
        await _store.SaveChangesAsync(ct);
        await _store.LoadOwnerAsync(account);
        var phases = await _store.PhasesAsync(ct);
        var cal = await _store.CalendarAsync();
        return AccountOutcome.Ok(ToDto(phases, cal, account, new List<Lead>(), defs: createdDefs, callerRole: callerRole,
            canSeeValues: canSeeValues, canSeeFinancials: canSeeFullFinancials, extras: await ExtrasForAsync([account.Id], ct), sensitive: sensitive));
    }

    public async Task<AccountOutcome> UpdateAsync(
        RecordAccessContext ctx, Guid id, AccountInput input, string callerRole = "",
        bool canSeeValues = true, bool canSeeFullFinancials = true, CancellationToken ct = default, bool canCreateTags = false)
    {
        var account = await _store.GetTrackedForUpdateAsync(id);
        if (account is null) return AccountOutcome.Refused(new Refusal("Account not found", NotFound: true));
        if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId))
            return AccountOutcome.Refused(new Refusal("Not allowed to edit this account", Forbidden: true));
        // A rename can collide just as a create can — and silently merging two
        // customers' records is worse than refusing the edit.
        if (!string.IsNullOrWhiteSpace(input.Name) && await _store.NameTakenAsync(input.Name!, id, ct))
            return AccountOutcome.Refused(new Refusal("An account named \"" + input.Name!.Trim() + "\" already exists.", Code: "duplicate_account_name"));
        // Decision 8 on a RENAME: in "block" mode a name that CHANGES to a near match of another account is refused like a create
        // (same NearMatches predicate, the account itself excluded); an unchanged name or an unrelated one is fine; "warn" allows it.
        if (!string.IsNullOrWhiteSpace(input.Name) && !string.Equals(input.Name.Trim(), account.Name, StringComparison.OrdinalIgnoreCase)
            && await _orgSettings.GetAccountDuplicateModeAsync() == OrgSettings.AccountDuplicateBlock)
        {
            var near = NearMatches((await _store.AllAccountsForMatchAsync()).Where(a => a.Id != id), input.Name, null);
            if (near.Count > 0)
                return AccountOutcome.Refused(new Refusal(
                    "A similar account already exists: " + string.Join(", ", near.Take(3).Select(a => a.Name)) + ". Open it instead, or change the name.",
                    Code: "similar_account_name", Field: "name"));
        }
        if (input.Custom is { } updatedCustom)
        {
            var validationRefusal = await _customFields.ValidateValuesAsync(CustomFieldDef.ObjectTypes.Account, updatedCustom, callerRole, ct, existing: ParseCustom(account.Custom));
            if (validationRefusal is not null) return AccountOutcome.Refused(new Refusal(validationRefusal.Reason));
        }
        // E1 step 4 (to-do/e1-event-backbone-design.md §4) — "changed_fields[]":
        // only the fields this request actually SET are candidates (Apply only
        // overwrites those), and only the ones that differ from the stored value
        // count as changed — same "only judge what actually changed" reasoning
        // ContactProcess.Changed applies to its own contact-shape validation.
        var changedFields = new List<string>();
        void NoteIfChanged(string field, string? incoming, string? stored)
        {
            if (incoming != null && incoming != stored) changedFields.Add(field);
        }
        NoteIfChanged("name", input.Name?.Trim(), account.Name);
        NoteIfChanged("industry", input.Industry, account.Industry);
        NoteIfChanged("website", input.Website, account.Website);
        NoteIfChanged("phone", input.Phone, account.Phone);
        NoteIfChanged("notes", input.Notes, account.Notes);
        NoteIfChanged("address", input.Address, account.Address);
        NoteIfChanged("city", input.City, account.City);
        NoteIfChanged("state", input.State, account.State);
        NoteIfChanged("postal_code", input.PostalCode, account.PostalCode);
        NoteIfChanged("country", input.Country, account.Country);
        NoteIfChanged("country_code", input.CountryCode, account.CountryCode);
        // Status: validated against the org's list (an archived key is accepted only when the account already has it); information only.
        if (input.Status is not null && input.Status != account.Status)
        {
            var statusRefusal = AccountStatuses.Refusal(await _store.StatusListAsync(ct), input.Status, account.Status);
            if (statusRefusal is not null) return AccountOutcome.Refused(new Refusal(statusRefusal, Field: "status"));
            account.Status = input.Status;
            changedFields.Add("status");
        }

        var updatedDefs = await ActiveDefsAsync(CustomFieldDef.ObjectTypes.Account, ct);
        if (SensitiveWriteRefusal(ctx.Sensitive, input, account, account.OwnerId, updatedDefs) is { } editSensitive) return AccountOutcome.Refused(editSensitive);
        Apply(account, input, updatedDefs, callerRole);
        account.UpdatedAt = DateTime.UtcNow;
        // Decision 9: the account's OWN tags, set exactly like a lead's (tag_ids / tag_names replace the set).
        if (input.TagIds is not null || input.TagNames is not null)
        {
            var tagRefusal = await ApplyTagsAsync(account, ctx.UserId, canCreateTags, input.TagIds, input.TagNames);
            if (tagRefusal is not null) return AccountOutcome.Refused(tagRefusal);
        }
        if (changedFields.Count > 0)
            _events.Raise(DomainEventTypes.Keys.AccountUpdated, DomainEventTypes.AggregateTypes.Account, account.Id, ctx.UserId,
                new DomainEventPayloads.AccountUpdated(account.Id, [.. changedFields]));
        await _store.SaveChangesAsync(ct);
        var phases = await _store.PhasesAsync(ct);
        var cal = await _store.CalendarAsync();
        return AccountOutcome.Ok(ToDto(phases, cal, account, account.Leads.ToList(), defs: updatedDefs, callerRole: callerRole,
            canSeeValues: canSeeValues, canSeeFinancials: canSeeFullFinancials, extras: await ExtrasForAsync([account.Id], ct), sensitive: ctx.Sensitive));
    }

    /// <summary>Resolves tag_ids / tag_names and replaces the account's OWN tag rows with exactly that set - the account twin
    /// of LeadWriteProcess.ApplyTagsAsync (existing tags attach freely; a new name needs tags.create). Does not save.</summary>
    private async Task<Refusal?> ApplyTagsAsync(Account account, Guid actorId, bool canCreateTags, Guid[]? tagIds, string[]? tagNames)
    {
        var resolved = await _store.ResolveTagsAsync(tagIds, tagNames, actorId, canCreateTags);
        if (resolved.Error is not null) return new Refusal(resolved.Error);
        var wanted = resolved.TagIds;
        var current = await _store.TrackedAccountTagsAsync(account.Id);
        var currentIds = current.Select(t => t.TagId).ToHashSet();
        var toRemove = current.Where(t => !wanted.Contains(t.TagId)).ToList();
        var toAdd = wanted.Where(t => !currentIds.Contains(t)).ToList();
        if (toRemove.Count > 0) _store.RemoveAccountTags(toRemove);
        if (toAdd.Count > 0) _store.AddAccountTags(toAdd.Select(t => new AccountTag { AccountId = account.Id, TagId = t }));
        return null;
    }

    public async Task<DeleteOutcome> DeleteAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        await DeleteAsync(ctx, id, deleteDeals: false, ct);

    /// <summary>
    /// Deletes the account (contacts go, leads and invoices are UNLINKED and kept - today's effect). With
    /// <paramref name="deleteDeals"/> each of its deals also goes, through the EXISTING lead delete (so each deal's own
    /// permission applies: a deal the caller may not delete stays, unlinked, and is reported). If ANY deal has issued invoices
    /// the WHOLE delete is refused and nothing is deleted (409 <c>invoices_issued</c>, listing the blocked deals).
    /// </summary>
    public async Task<DeleteOutcome> DeleteAsync(RecordAccessContext ctx, Guid id, bool deleteDeals, CancellationToken ct = default)
    {
        var account = await _store.GetTrackedForDeleteAsync(id);
        if (account is null) return DeleteOutcome.Refused(new Refusal("Account not found", NotFound: true));
        if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId))
            return DeleteOutcome.Refused(new Refusal("Not allowed to delete this account", Forbidden: true));
        var result = await DeleteCoreAsync(ctx, account, deleteDeals, ct);
        return result.Refusal is not null ? DeleteOutcome.Refused(result.Refusal) : new DeleteOutcome(null, result.DealsDeleted, result.DealSkips);
    }

    private sealed record DeleteResult(Refusal? Refusal, int DealsDeleted, List<BulkSkipDto> DealSkips);

    private async Task<DeleteResult> DeleteCoreAsync(RecordAccessContext ctx, Account account, bool deleteDeals, CancellationToken ct)
    {
        var dealSkips = new List<BulkSkipDto>();
        var dealsDeleted = 0;
        // Channel partners: money history (ledger, payouts, statements) is a record, not a draft - an account that has any cannot be deleted.
        if (await _store.HasPartnerMoneyAsync(account.Id, ct))
            return new DeleteResult(new Refusal(
                "This account is a channel partner with money history (ledger entries, payouts or statements), so it can't be deleted. Set the partner to terminated instead.",
                Conflict: true, Code: "partner_money"), 0, dealSkips);
        if (await _store.HasPortalUsersAsync(account.Id, ct))
            return new DeleteResult(new Refusal(
                "This account is a channel partner with portal users (people who sign in to the partner portal), so it can't be deleted. Switch its portal users off and set the partner to terminated instead.",
                Conflict: true, Code: "partner_portal_users"), 0, dealSkips);
        if (deleteDeals)
        {
            var preview = await _store.DeletePreviewAsync(account.Id, ctx, ct);
            if (preview.DealsBlocked > 0)
            {
                // ANY deal that cannot go - issued invoices OR a deal the caller may not delete - refuses the WHOLE delete.
                var byInvoices = preview.BlockedDeals.Any(d => d.Code == "invoices_issued");
                return new DeleteResult(new Refusal(
                    byInvoices
                        ? $"{preview.DealsBlocked} deal(s) can't be deleted (issued invoices or no permission). Void the invoices, or delete the account without its deals."
                        : $"You can't delete {preview.DealsBlocked} of this account's deals. Delete the account without its deals, or ask their owners.",
                    Conflict: true, Code: byInvoices ? "invoices_issued" : "deals_not_deletable", BlockedDeals: preview.BlockedDeals), 0, dealSkips);
            }
            var leadDelete = _leadDelete ?? throw new InvalidOperationException("AccountProcess needs a LeadMergeProcess to delete an account's deals.");
            foreach (var leadId in await _store.LeadIdsOfAccountAsync(account.Id, ct))
            {
                var refusal = await leadDelete.DeleteAsync(ctx, leadId);
                if (refusal is null) dealsDeleted++;
                else dealSkips.Add(new BulkSkipDto(leadId, refusal.Code ?? (refusal.Forbidden ? "not_allowed" : "refused"), refusal.Reason));
            }
        }
        var markedFiles = _recordFiles is null ? new List<Guid>() : await _recordFiles.MarkRecordsAsync(AttachmentRecordType.Account, new[] { account.Id }, ct: ct);
        await _store.RemoveAccountActivitiesAsync(account.Id, ct);
        _store.RemoveAccount(account);
        // Another request (a retried bulk delete) may have deleted this account since it was loaded: that is a skip, not a 500.
        // The failed entries are detached so the shared context stays usable for the rest of a batch.
        var gone = await _store.SaveDeletesAsync(ct);
        if (_recordFiles is not null) await _recordFiles.SettleAsync(markedFiles, ct);
        if (gone.Contains(account)) return new DeleteResult(new Refusal(GoneRowSave.Reason, NotFound: true, Code: GoneRowSave.Code), dealsDeleted, dealSkips);
        return new DeleteResult(null, dealsDeleted, dealSkips);
    }

    /// <summary>GET /accounts/{id}/delete-preview: the counts the confirm text states (contacts deleted, leads and invoices
    /// unlinked) and the split of its deals into deletable and blocked. Same permission as the delete itself.</summary>
    public async Task<(Refusal? Refusal, AccountDeletePreviewDto? Preview)> DeletePreviewAsync(
        RecordAccessContext ctx, Guid id, CancellationToken ct = default)
    {
        var account = await _store.GetForAccessCheckAsync(id);
        if (account is null) return (new Refusal("Account not found", NotFound: true), null);
        if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId))
            return (new Refusal("Not allowed to delete this account", Forbidden: true), null);
        return (null, await _store.DeletePreviewAsync(id, ctx, ct));
    }

    // =====================================================================
    // Accounts rework (to-do/accounts-rework-design.md)
    // =====================================================================

    // --- decision 1: an activity on the account itself -----------------------------------------

    /// <summary>The types an account activity may carry. Narrower than the lead path (which stores whatever it is given):
    /// status_change is the system's own row, never typed in.</summary>
    public static readonly string[] ActivityTypes = ["note", "call", "email", "meeting"];

    /// <summary>GET /accounts/{id}/activities - the account's own activities plus every activity of its leads, newest first.
    /// Same view-authorization as the account read (404-not-403 shape lives in the controller's FromRefusal).</summary>
    public async Task<(Refusal? Refusal, List<ActivityDto>? Dto)> ActivitiesAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default)
    {
        var refusal = await CheckViewAsync(ctx, id, ct);
        if (refusal is not null) return (refusal, null);
        return (null, CustomFieldMasking.MaskActivities(await _store.ActivitiesForAccountAsync(id, ct), ctx.Sensitive));
    }

    /// <summary>
    /// POST /accounts/{id}/activities - mirrors <c>LeadReadProcess.AddActivityAsync</c>. With no <c>lead_id</c> the activity
    /// belongs to the account alone; with one (it must be a deal of THIS account, and the caller must manage it) it is an
    /// ordinary lead activity, also stamped with the account, raising the same <c>activity.logged</c> event. L6:
    /// <c>next_follow_up_at</c> sets that deal's next follow-up in the same step, so it needs a <c>lead_id</c>.
    /// </summary>
    public async Task<(Refusal? Refusal, ActivityDto? Dto)> AddActivityAsync(
        RecordAccessContext ctx, Guid actorId, Guid id, AccountActivityInput input, CancellationToken ct = default)
    {
        var account = await _store.GetForAccessCheckAsync(id);
        if (account is null) return (new Refusal("Account not found", NotFound: true), null);
        if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId))
            return (new Refusal("Not allowed to edit this account", Forbidden: true), null);

        var type = string.IsNullOrWhiteSpace(input.Type) ? "note" : input.Type.Trim();
        if (!ActivityTypes.Contains(type))
            return (new Refusal("type must be note, call, email or meeting", Code: "invalid_type", Field: "type"), null);

        Lead? lead = null;
        if (input.LeadId is Guid leadId)
        {
            lead = await _store.TrackedLeadAsync(leadId);
            if (lead is null || lead.AccountId != id)
                return (new Refusal("That deal isn't on this account", Code: "lead_not_on_account", Field: "lead_id"), null);
            if (!RecordAccess.CanManage(ctx, lead.OwnerId, lead.TeamId))
                return (new Refusal("Not allowed to edit that deal", Forbidden: true), null);
        }
        else if (input.NextFollowUpAt is not null)
        {
            return (new Refusal("A follow-up date belongs to a deal. Choose one of this account's deals to file the note under.",
                Code: "follow_up_needs_deal", Field: "next_follow_up_at"), null);
        }

        var activity = new LeadActivity
        {
            // Explicit Id - the ActivityLogged raise below (same save) needs the real id before SaveChanges.
            Id = Guid.NewGuid(), LeadId = lead?.Id, AccountId = id, AuthorId = actorId, Type = type, Body = input.Body,
        };
        _store.AddActivity(activity);
        if (lead is null)
        {
            // An activity on the account itself (no deal): the ACCOUNT is the aggregate, so account automations (and webhooks) can react -
            // the automation engine reads the record from the event's aggregate. Lead-filed activities keep their lead-shaped event below.
            _events.Raise(DomainEventTypes.Keys.ActivityLogged, DomainEventTypes.AggregateTypes.Account, id, actorId,
                new DomainEventPayloads.ActivityLogged(activity.Id, null, actorId, type, id));
        }
        if (lead is not null)
        {
            if (input.NextFollowUpAt is DateTime nextFollowUp)
            {
                lead.NextFollowUpAt = nextFollowUp.Kind == DateTimeKind.Unspecified
                    ? DateTime.SpecifyKind(nextFollowUp, DateTimeKind.Utc) : nextFollowUp.ToUniversalTime();
                lead.UpdatedAt = DateTime.UtcNow;
            }
            // Same event, same aggregate quirk (the ACTIVITY id on a lead aggregate) as LeadReadProcess.AddActivityAsync, so the
            // owner notification and deal-risk recompute follow a filed-under note exactly as they follow a lead note.
            _events.Raise(DomainEventTypes.Keys.ActivityLogged, DomainEventTypes.AggregateTypes.Lead, activity.Id, actorId,
                new DomainEventPayloads.ActivityLogged(activity.Id, lead.Id, actorId, type, id));
        }
        await _store.SaveChangesAsync(ct);
        return (null, new ActivityDto(activity.Id, activity.LeadId, activity.AuthorId, activity.Type, activity.Body, activity.CreatedAt, activity.AccountId));
    }

    // --- decision 5: change the account's owner ---------------------------------------------------

    public sealed record AssignOutcome(Refusal? Refusal, AccountAssignResult? Result);

    /// <summary>
    /// POST /accounts/{id}/assign - copies <c>LeadAssignProcess.AssignAsync</c>: managers and admins only, the caller must
    /// manage the account, the new owner must be in the account's team (409 <c>owner_outside_team</c> carrying both team
    /// sets), a "Reassigned to X" activity lands on the account, and <c>account.assigned</c> is raised for the
    /// notification handler. The account's leads KEEP their owners unless <c>move_open_leads</c> asks otherwise, in which
    /// case each playbook-open lead goes through the existing lead assign (its own rules run) and the ones that could not
    /// move come back with their reasons.
    /// </summary>
    public async Task<AssignOutcome> AssignAsync(
        RecordAccessContext ctx, AccountActor actor, Guid id, AccountAssignInput input,
        bool canSeeValues = true, bool canSeeFullFinancials = true, CancellationToken ct = default)
    {
        if (!actor.IsManager && actor.Visibility != "manage")
            return new AssignOutcome(new Refusal("Only managers can reassign accounts", Forbidden: true), null);
        if (input.OwnerId is null) return new AssignOutcome(new Refusal("owner_id is required"), null);
        if (!await _store.ProfileInOrgAsync(input.OwnerId.Value, actor.OrgId))
            return new AssignOutcome(new Refusal("Assignee not found", NotFound: true), null);

        var account = await _store.GetTrackedForUpdateAsync(id);
        if (account is null) return new AssignOutcome(new Refusal("Account not found", NotFound: true), null);

        var refusal = await AssignCoreAsync(ctx, actor, account, input.OwnerId.Value, ct);
        if (refusal is not null) return new AssignOutcome(refusal, null);

        var (moved, leadSkips) = input.MoveOpenLeads == true
            ? await MoveOpenLeadsAsync(ctx, actor, account.Id, input.OwnerId.Value, ct)
            : (0, new List<BulkSkipDto>());

        var phases = await _store.PhasesAsync(ct);
        var cal = await _store.CalendarAsync();
        var defs = await ActiveDefsAsync(CustomFieldDef.ObjectTypes.Account, ct);
        var dto = ToDto(phases, cal, account, account.Leads.ToList(), defs: defs, callerRole: actor.Role,
            canSeeValues: canSeeValues, canSeeFinancials: canSeeFullFinancials, extras: await ExtrasForAsync([account.Id], ct), sensitive: ctx.Sensitive);
        return new AssignOutcome(null, new AccountAssignResult(dto, moved, leadSkips));
    }

    /// <summary>The owner change itself, saved: checks manage + team, sets the owner, writes the account activity and the
    /// event. Shared by the single and the bulk assign. Returns null on success.</summary>
    private async Task<Refusal?> AssignCoreAsync(RecordAccessContext ctx, AccountActor actor, Account account, Guid newOwnerId, CancellationToken ct)
    {
        if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId))
            return new Refusal("Not allowed to reassign this account", Forbidden: true);

        // Same rule as the lead: a team move is its own act, so an owner outside the account's team is REFUSED.
        var ownerTeams = await _store.ActiveTeamIdsForUserAsync(newOwnerId);
        if (account.TeamId is Guid accountTeam && !ownerTeams.Contains(accountTeam))
            return new Refusal("That rep isn't in this account's team. Move the account to one of their teams first.",
                Code: "owner_outside_team", Conflict: true, TeamId: accountTeam, OwnerTeamIds: ownerTeams);

        var previousOwnerId = account.OwnerId;
        account.OwnerId = newOwnerId;
        account.UpdatedAt = DateTime.UtcNow;
        var newOwnerName = await _store.ProfileFullNameAsync(newOwnerId);
        _store.AddActivity(new LeadActivity
        {
            Id = Guid.NewGuid(), LeadId = null, AccountId = account.Id, AuthorId = actor.Id, Type = "note",
            Body = $"Reassigned to {newOwnerName ?? "another rep"}",
        });
        _events.Raise(DomainEventTypes.Keys.AccountAssigned, DomainEventTypes.AggregateTypes.Account, account.Id, actor.Id,
            new DomainEventPayloads.AccountAssigned(account.Id, previousOwnerId, newOwnerId, actor.Id));
        await _store.SaveChangesAsync(ct);
        await _store.RefreshOwnerAsync(account);
        return null;
    }

    private async Task<(int Moved, List<BulkSkipDto> Skips)> MoveOpenLeadsAsync(
        RecordAccessContext ctx, AccountActor actor, Guid accountId, Guid newOwnerId, CancellationToken ct)
    {
        var leadAssign = _leadAssign ?? throw new InvalidOperationException("AccountProcess needs a LeadAssignProcess to move an account's open leads.");
        var skips = new List<BulkSkipDto>();
        var moved = 0;
        var phases = await _store.PhasesAsync(ct);
        foreach (var (leadId, name) in await _store.OpenLeadsOfAccountAsync(accountId, phases, ct))
        {
            // The lead's own assign path: its manager gate, CanManage, team check and invoices-follow-owner all run.
            var (r, _) = await leadAssign.AssignAsync(
                ctx, new LeadView(false, false, actor.Role), actor.Id, actor.Name, actor.OrgId, actor.IsManager, actor.Visibility,
                leadId, new AssignInput(newOwnerId));
            if (r is null) { moved++; continue; }
            var code = r.OwnerOutsideTeam ? "owner_outside_team" : r.Forbidden ? "not_allowed" : r.NotFound ? "not_found" : "refused";
            skips.Add(new BulkSkipDto(leadId, code, $"{name}: {r.Reason}"));
        }
        return (moved, skips);
    }

    // --- decision 13: bulk actions on ticked accounts ----------------------------------------------

    /// <summary>
    /// POST /accounts/bulk - mirrors <c>LeadWriteProcess.BulkAsync</c>: every account is checked on its own, one that cannot
    /// be actioned is SKIPPED with its reason rather than failing the batch. <c>assign</c> carries the single assign's rules
    /// (manager/admin only, manage, team check, optional <c>move_open_leads</c>); <c>delete</c> the single delete's, with the
    /// <c>delete_deals</c> tick box - an account whose deals have issued invoices is skipped (nothing of it deleted) and counted.
    /// </summary>
    public async Task<(Refusal? Refusal, AccountBulkResult? Result)> BulkAsync(
        RecordAccessContext ctx, AccountActor actor, AccountBulkInput input, CancellationToken ct = default,
        bool canSeeValues = true, bool canSeeFullFinancials = true)
    {
        // Exactly one of ids / match. A match ("select all N matching") is resolved to ids by the list's own filtered query, then
        // the ordinary per-row path below runs on them - same rules, skips counted.
        if (input.Match is not null && input.Ids is not null) return (new Refusal("Send either ids or match, not both"), null);
        var action = input.Action;
        if (input.Match is not null && action is not ("assign" or "tag_add" or "tag_remove" or "set_status" or "delete"))
            return (new Refusal("action must be assign, tag_add, tag_remove, set_status or delete"), null);
        var ids = input.Match is { } match
            ? await MatchingIdsAsync(ctx, match, canSeeValues, canSeeFullFinancials, actor.Role, ct)
            : (input.Ids ?? []).Distinct().ToList();
        // A match that finds nothing is a successful no-op; an empty ticked list is still "ids is required".
        if (ids.Count == 0 && input.Match is not null) return (null, new AccountBulkResult(0, 0, []));
        if (ids.Count == 0) return (new Refusal("ids is required"), null);
        if (action is not ("assign" or "tag_add" or "tag_remove" or "set_status" or "delete"))
            return (new Refusal("action must be assign, tag_add, tag_remove, set_status or delete"), null);
        if (action == "assign")
        {
            if (!actor.IsManager && actor.Visibility != "manage")
                return (new Refusal("Only managers can reassign accounts", Forbidden: true), null);
            if (input.OwnerId is null) return (new Refusal("owner_id is required"), null);
            if (!await _store.ProfileInOrgAsync(input.OwnerId.Value, actor.OrgId))
                return (new Refusal("Assignee not found", NotFound: true), null);
        }
        if (action == "set_status")
        {
            if (string.IsNullOrWhiteSpace(input.Status)) return (new Refusal("status is required", Field: "status"), null);
            var statusRefusal = AccountStatuses.Refusal(await _store.StatusListAsync(ct), input.Status);
            if (statusRefusal is not null) return (new Refusal(statusRefusal, Field: "status"), null);
        }
        if (action is "tag_add" or "tag_remove")
        {
            if (input.TagId is null) return (new Refusal("tag_id is required"), null);
            if (!await _store.TagExistsAsync(input.TagId.Value)) return (new Refusal("Tag not found", NotFound: true), null);
        }

        var accounts = await _store.TrackedByIdsAsync(ids, ct);
        var skips = new List<BulkSkipDto>();
        var leadSkips = new List<BulkSkipDto>();
        var updated = 0;
        var leadsMoved = 0;
        void Skip(Guid accountId, string code, string reason) => skips.Add(new BulkSkipDto(accountId, code, reason));
        var tagLinks = action is "tag_add" or "tag_remove"
            ? await _store.AccountTagsForAccountsAsync(accounts.Select(a => a.Id).ToList(), input.TagId!.Value, ct)
            : new Dictionary<Guid, AccountTag>();

        foreach (var account in accounts)
        {
            if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId)) { Skip(account.Id, "not_allowed", "You can't manage this account"); continue; }
            switch (action)
            {
                case "assign":
                {
                    var refusal = await AssignCoreAsync(ctx, actor, account, input.OwnerId!.Value, ct);
                    if (refusal is not null) { Skip(account.Id, refusal.Code ?? "refused", $"{account.Name}: {refusal.Reason}"); continue; }
                    updated++;
                    if (input.MoveOpenLeads == true)
                    {
                        var (moved, s) = await MoveOpenLeadsAsync(ctx, actor, account.Id, input.OwnerId!.Value, ct);
                        leadsMoved += moved;
                        leadSkips.AddRange(s);
                    }
                    break;
                }
                case "tag_add":
                    if (tagLinks.ContainsKey(account.Id)) { Skip(account.Id, "already_tagged", "Already has that tag"); continue; }
                    _store.AddAccountTags([new AccountTag { AccountId = account.Id, TagId = input.TagId!.Value }]);
                    updated++;
                    break;
                case "tag_remove":
                    if (!tagLinks.TryGetValue(account.Id, out var link)) { Skip(account.Id, "not_tagged", "Doesn't have that tag"); continue; }
                    _store.RemoveAccountTags([link]);
                    updated++;
                    break;
                case "set_status":
                    // The same rule as a single PATCH: the key must be in the org's list (checked once, above); an account already there is skipped.
                    if (account.Status == input.Status) { Skip(account.Id, "already_status", "Already has that status"); continue; }
                    account.Status = input.Status!;
                    account.UpdatedAt = DateTime.UtcNow;
                    _events.Raise(DomainEventTypes.Keys.AccountUpdated, DomainEventTypes.AggregateTypes.Account, account.Id, ctx.UserId,
                        new DomainEventPayloads.AccountUpdated(account.Id, ["status"]));
                    updated++;
                    break;
                case "delete":
                {
                    var result = await DeleteCoreAsync(ctx, account, input.DeleteDeals == true, ct);
                    if (result.Refusal is not null) { Skip(account.Id, result.Refusal.Code ?? "refused", $"{account.Name}: {result.Refusal.Reason}"); continue; }
                    updated++;
                    leadSkips.AddRange(result.DealSkips);
                    break;
                }
            }
        }
        foreach (var missing in ids.Except(accounts.Select(a => a.Id))) Skip(missing, "not_found", "Account not found");
        if (action is "tag_add" or "tag_remove" or "set_status") await _store.SaveChangesAsync(ct);

        return (null, new AccountBulkResult(updated, skips.Count, skips, leadSkips.Count > 0 ? leadSkips : null, action == "assign" && input.MoveOpenLeads == true ? leadsMoved : null));
    }

    // --- contacts ---

    public async Task<ContactsOutcome> ContactsAsync(RecordAccessContext ctx, Guid id, string callerRole = "", CancellationToken ct = default)
    {
        var account = await _store.GetForAccessCheckAsync(id);
        if (account is null) return ContactsOutcome.Refused(new Refusal("Account not found", NotFound: true));
        if (!RecordAccess.CanView(ctx, account.OwnerId, account.TeamId))
            return ContactsOutcome.Refused(new Refusal("Not allowed to access this account", Forbidden: true));
        var rows = await _store.ContactsForAccountAsync(id);
        var contactDefs = await ActiveDefsAsync(CustomFieldDef.ObjectTypes.Contact, ct);
        return ContactsOutcome.Ok(rows.Select(c => ContactToDto(c, contactDefs, callerRole, null, ctx.Sensitive, account.OwnerId, account.TeamId)).ToList());
    }

    public async Task<ContactOutcome> AddContactAsync(
        RecordAccessContext ctx, Guid id, ContactInput input, string callerRole = "", CancellationToken ct = default)
    {
        var account = await _store.GetForAccessCheckAsync(id);
        if (account is null) return ContactOutcome.Refused(new Refusal("Account not found", NotFound: true));
        if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId))
            return ContactOutcome.Refused(new Refusal("Not allowed to edit this account", Forbidden: true));
        if (string.IsNullOrWhiteSpace(input.Name))
            return ContactOutcome.Refused(new Refusal("name is required"));
        if (input.Custom is { } contactCustom)
        {
            var validationRefusal = await _customFields.ValidateValuesAsync(CustomFieldDef.ObjectTypes.Contact, contactCustom, callerRole, ct);
            if (validationRefusal is not null) return ContactOutcome.Refused(new Refusal(validationRefusal.Reason));
        }
        // Same rule Lead's create/update path enforces (ContactFieldFormat):
        // email is optional but must look like an address when given, and
        // phone must not have taken on the spreadsheet-float shape.
        if (!string.IsNullOrEmpty(input.Email) && !ContactFieldFormat.IsValidEmailFormat(input.Email))
            return ContactOutcome.Refused(new Refusal("email is not a valid address"));
        if (!string.IsNullOrEmpty(input.Phone) && ContactFieldFormat.LooksLikeSpreadsheetFloat(input.Phone))
            return ContactOutcome.Refused(new Refusal(
                "phone looks like a spreadsheet number (e.g. 9.7153E+11), not a phone number — re-enter the digits"));
        // Buying roles: every key must be on the org picklist (the same check a deal's stakeholder roles face).
        var buyingRoles = SalesApi.SystemLayer.Stakeholders.StakeholderRoles.Canonicalise(
            input.BuyingRoles, input.BuyingRoles is null ? new List<string>() : await _orgSettings.GetBuyingRolesAsync(), out var unknownRole);
        if (unknownRole is not null) return ContactOutcome.Refused(new Refusal($"'{unknownRole}' is not a configured buying role."));
        var addContactDefs = await ActiveDefsAsync(CustomFieldDef.ObjectTypes.Contact, ct);
        if (SensitiveContactWriteRefusal(ctx.Sensitive, input, null, account.OwnerId, account.TeamId, addContactDefs) is { } addSensitive)
            return ContactOutcome.Refused(new Refusal(addSensitive.Reason, Code: SensitiveWriteGuard.Code, Fields: addSensitive.Fields));
        var contact = new Contact
        {
            // Explicit Id — the ContactCreated raise below (same save) needs the
            // real id before SaveChanges; see LeadWriteProcess.CreateAsync's
            // identical comment on why a `gen_random_uuid()` default can't be
            // relied on here.
            Id = Guid.NewGuid(),
            AccountId = id,
            Name = input.Name!.Trim(),
            Title = input.Title,
            Email = input.Email,
            Phone = input.Phone,
            PhoneCountryCode = input.PhoneCountryCode,
            Notes = input.Notes,
            Custom = input.Custom?.GetRawText() ?? "{}",
            PreferredLanguage = MessageMergeFields.IsLanguageCode(input.PreferredLanguage) ? MessageMergeFields.NormalizeLanguage(input.PreferredLanguage) : null,
            BuyingRoles = buyingRoles,
        };
        _store.AddContact(contact);
        // E1 step 4 (to-do/e1-event-backbone-design.md §4) — the manual-add path;
        // ContactPromotionService.PromoteAsync raises the same event for the
        // promotion path, so together every way a Contact row comes into being
        // is covered.
        _events.Raise(DomainEventTypes.Keys.ContactCreated, DomainEventTypes.AggregateTypes.Contact, contact.Id, ctx.UserId,
            new DomainEventPayloads.ContactCreated(contact.Id, id, null));
        // E6.1 (design §4.1) — a fresh contact's email may be the first
        // evidence of this account's company domain; only fills a NULL
        // EmailDomain (see Apply's own comment on why a manual edit is never
        // overwritten).
        await RecomputeEmailDomainIfUnsetAsync(account, extraEmail: contact.Email, ct);
        await _store.SaveChangesAsync(ct);
        var newContactDefs = await ActiveDefsAsync(CustomFieldDef.ObjectTypes.Contact, ct);
        return ContactOutcome.Ok(ContactToDto(contact, newContactDefs, callerRole, null, ctx.Sensitive, account.OwnerId, account.TeamId));
    }

    // =====================================================================
    // E3.4 — account relationships: parent/subsidiary, related companies,
    // external ids, and the rollup they feed.
    // =====================================================================

    /// <summary>
    /// How many levels a parent chain or children tree is ever walked. No
    /// precedent existed for this number anywhere in the codebase (own search,
    /// nothing named "MaxDepth"/"depth guard" turned up) — 8 is this story's
    /// OWN choice, deep enough for any real corporate structure (few orgs run
    /// more than 4-5 levels of subsidiaries) while keeping the bounded walks
    /// (<see cref="ViewableDescendantsAsync"/>, <see cref="ChildrenTreeAsync"/>,
    /// <c>AccountStore.AncestorIdsAsync</c>) cheap and finite even against a
    /// corrupt or adversarial chain. Flagged here as a decision this story
    /// made, not one carried over from an existing rule.
    /// </summary>
    public const int MaxHierarchyDepth = 8;

    private static Refusal? ValidateNoSelfParent(Guid id, Guid? parentAccountId) =>
        parentAccountId == id ? new Refusal("An account cannot be its own parent") : null;

    /// <summary>
    /// Every descendant the CALLER may view, walked level by level so a hidden
    /// node's children are never even fetched — the visibility cutoff has to
    /// happen DURING the walk (see AccountStore.DescendantIdsAsync's own doc
    /// for why its unfiltered version cannot be filtered after the fact and
    /// give the same guarantee). This is the one place E3.4's own visibility
    /// rule lives: "a rep who can't see a subsidiary must not learn its
    /// pipeline via the parent's rollup" — decided by mirroring
    /// RecordAccess.CanView, the exact same predicate GET /accounts/{id}
    /// already gates on for the parent account itself.
    /// </summary>
    private async Task<List<AccountStore.AccountLite>> ViewableDescendantsAsync(
        RecordAccessContext ctx, Guid rootId, CancellationToken ct)
    {
        var result = new List<AccountStore.AccountLite>();
        var frontier = new List<Guid> { rootId };
        for (var depth = 0; depth < MaxHierarchyDepth && frontier.Count > 0; depth++)
        {
            var children = await _store.ChildrenOfAsync(frontier, ct);
            var viewable = children.Where(c => RecordAccess.CanView(ctx, c.OwnerId, c.TeamId)).ToList();
            result.AddRange(viewable);
            frontier = viewable.Select(c => c.Id).ToList();
        }
        return result;
    }

    /// <summary>
    /// GET /accounts/{id}/tree — this account's own subtree bounded to
    /// <see cref="MaxHierarchyDepth"/> levels, hidden nodes (and everything
    /// beneath them) omitted per <see cref="ViewableDescendantsAsync"/>'s own
    /// rule. Built breadth-first then folded into the recursive shape, so the
    /// whole tree is at most <see cref="MaxHierarchyDepth"/> round trips no
    /// matter how wide it is.
    /// </summary>
    public async Task<(Refusal? Refusal, AccountChildNodeDto? Tree)> ChildrenTreeAsync(
        RecordAccessContext ctx, Guid id, CancellationToken ct = default)
    {
        var refusal = await CheckViewAsync(ctx, id, ct);
        if (refusal is not null) return (refusal, null);

        var root = await _store.LiteAsync(id, ct);
        if (root is null) return (new Refusal("Account not found", NotFound: true), null);

        var byParent = new Dictionary<Guid, List<AccountStore.AccountLite>>();
        var frontier = new List<Guid> { id };
        var truncatedIds = new HashSet<Guid>();
        for (var depth = 0; depth < MaxHierarchyDepth && frontier.Count > 0; depth++)
        {
            var children = await _store.ChildrenOfAsync(frontier, ct);
            var viewable = children.Where(c => RecordAccess.CanView(ctx, c.OwnerId, c.TeamId)).ToList();
            foreach (var c in viewable)
            {
                if (c.ParentAccountId is not { } pid) continue;
                if (!byParent.TryGetValue(pid, out var list)) byParent[pid] = list = new();
                list.Add(c);
            }
            var next = viewable.Select(c => c.Id).ToList();
            // The bound was hit with candidates still pending expansion: mark
            // every leaf at this depth as truncated so the client can say
            // "more levels not shown" instead of it silently looking final.
            if (depth == MaxHierarchyDepth - 1 && next.Count > 0)
                foreach (var nid in next) truncatedIds.Add(nid);
            frontier = next;
        }

        AccountChildNodeDto Build(Guid accountId, string name)
        {
            var kids = byParent.GetValueOrDefault(accountId, new()).Select(c => Build(c.Id, c.Name)).ToList();
            return new AccountChildNodeDto(accountId, name, kids, truncatedIds.Contains(accountId));
        }
        return (null, Build(root.Id, root.Name));
    }

    /// <summary>
    /// The account + every viewable descendant's rollup — see
    /// <see cref="Dtos.AccountRollupDto"/>'s own doc for the masking and
    /// period decisions (both mirror AccountDto's existing single-account
    /// figures exactly, nothing new invented). Reuses the same
    /// <c>canSeeFullFinancials</c>-gated invoice scoping <see cref="ToDto"/>
    /// already applies to a single account — the rollup is that same
    /// computation summed over a wider account-id set, not a different rule.
    /// </summary>
    private async Task<AccountRollupDto> RollupAsync(
        RecordAccessContext ctx, bool canSeeFullFinancials, bool canSeeValues, Guid rootId, PlaybookPhases phases, CancellationToken ct)
    {
        var descendants = await ViewableDescendantsAsync(ctx, rootId, ct);
        var accountIds = new List<Guid> { rootId };
        accountIds.AddRange(descendants.Select(d => d.Id));

        var leads = await _store.LeadsForAccountsAsync(accountIds, ct);
        var open = leads.Where(l => phases.IsOpen(l.PlaybookId, l.Status)).ToList();

        var invoicesQ = await _store.ReceivableInvoicesAsync(ctx, canSeeFullFinancials);
        var idSet = accountIds.ToHashSet();
        var invoices = await invoicesQ.Where(i => i.AccountId != null && idSet.Contains(i.AccountId.Value)).ToListAsync(ct);
        var wonValue = invoices.Where(i => i.Status != "void" && i.Status != "draft").Sum(i => i.Amount);
        var outstanding = invoices.Where(i => Invoice.IsReceivable(i.Status)).Sum(Invoice.BalanceOf);

        // Masking (account-money-masking) — OpenPipelineValue follows
        // ViewLeadValues, WonValue/InvoiceOutstanding follow
        // ViewAccountFinancials, same as AccountDto's own single-account
        // figures this rollup generalises. OpenDealsCount/DescendantAccountCount
        // are counts, not values, and stay unmasked.
        return new AccountRollupDto(
            open.Count,
            canSeeValues ? open.Sum(l => l.EstimatedValue) : null,
            canSeeFullFinancials ? wonValue : null,
            canSeeFullFinancials ? outstanding : null,
            descendants.Count);
    }

    // --- parent / subsidiary ---

    /// <summary>
    /// May <paramref name="id"/> sit directly under <paramref name="newParentId"/>? Shared by PUT /accounts/{id}/parent and a create that names a
    /// parent (E14.1), so the two can never disagree: the parent must exist and be visible to the caller, the link must not loop, and the
    /// chain must stay within <see cref="MaxHierarchyDepth"/>. Null = allowed.
    /// </summary>
    private async Task<Refusal?> ValidateParentAsync(RecordAccessContext ctx, Guid id, Guid newParentId, CancellationToken ct)
    {
        var parent = await _store.LiteAsync(newParentId, ct);
        if (parent is null) return new Refusal("Parent account not found", NotFound: true);
        // The caller must at least be able to SEE the account they are
        // linking to — the same bar AddRelationshipAsync's counterparty
        // check below applies, and the bar CheckViewAsync applies to every
        // other cross-account reference in this controller.
        if (!RecordAccess.CanView(ctx, parent.OwnerId, parent.TeamId))
            return new Refusal("Not allowed to link to that account", Forbidden: true);

        // Loop refusal: would walking UP from the proposed parent ever
        // reach this account? A bounded structural walk — see
        // AccountStore.AncestorIdsAsync's own doc for why it carries no
        // visibility filtering (this is a topology question, not one of
        // who may see what).
        var ancestors = await _store.AncestorIdsAsync(newParentId, MaxHierarchyDepth, ct);
        if (newParentId == id || ancestors.Contains(id))
            return new Refusal("This would create a circular hierarchy", Code: "circular_hierarchy");
        // ancestors holds newParentId's OWN ancestors — it does not include
        // newParentId itself, nor the account being attached beneath it.
        // Total depth after this write would be ancestors.Count (existing
        // ancestors) + 1 (newParentId) + 1 (this account) — refuse once
        // that would exceed MaxHierarchyDepth.
        if (ancestors.Count + 2 > MaxHierarchyDepth)
            return new Refusal($"This account hierarchy already reaches the maximum depth of {MaxHierarchyDepth} levels", Code: "hierarchy_too_deep");
        return null;
    }

    /// <summary>
    /// E14.1 "follow parent again": the account stops overriding the named inheriting fields (omitted or empty = every one it overrides) and takes
    /// the parent's stored value again. The copy is a tracked edit, so the audit, <c>field_changed</c> and the child's own subtree see it. A field the
    /// org does not list as inheriting, or an account with no parent, is refused rather than silently ignored.
    /// </summary>
    public async Task<AccountOutcome> FollowParentAsync(
        RecordAccessContext ctx, Guid id, List<string>? fields, string callerRole = "",
        bool canSeeValues = true, bool canSeeFullFinancials = true, CancellationToken ct = default)
    {
        var pair = await _store.GetTrackedWithParentAsync(id, ct);
        if (pair is null) return AccountOutcome.Refused(new Refusal("Account not found", NotFound: true));
        var (account, parent) = pair.Value;
        if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId))
            return AccountOutcome.Refused(new Refusal("Not allowed to edit this account", Forbidden: true));
        if (parent is null) return AccountOutcome.Refused(new Refusal("This account has no parent to follow.", Code: "no_parent"));

        var inheriting = (await _orgSettings.GetAccountInheritedFieldsAsync()).Where(AccountInheritance.IsKnownKey).ToList();
        var wanted = fields is { Count: > 0 } ? fields.Select(f => f.Trim()).Distinct().ToList() : account.InheritOverrides.Where(inheriting.Contains).ToList();
        var unknown = wanted.FirstOrDefault(f => !inheriting.Contains(f));
        if (unknown is not null)
            return AccountOutcome.Refused(new Refusal($"\"{unknown}\" is not a field this organization inherits from a parent.", Code: "not_inherited", Field: unknown));

        if (wanted.Count > 0)
        {
            account.InheritOverrides = account.InheritOverrides.Where(o => !wanted.Contains(o)).ToList();
            foreach (var f in wanted) AccountInheritance.CopyFrom(account, parent, f);
            account.UpdatedAt = DateTime.UtcNow;
            await _store.SaveChangesAsync(ct);
        }

        var phases = await _store.PhasesAsync(ct);
        var cal = await _store.CalendarAsync();
        var defs = await ActiveDefsAsync(CustomFieldDef.ObjectTypes.Account, ct);

        return AccountOutcome.Ok(ToDto(phases, cal, account, [], defs: defs, callerRole: callerRole,
            canSeeValues: canSeeValues, canSeeFinancials: canSeeFullFinancials, extras: await ExtrasForAsync([account.Id], ct), sensitive: ctx.Sensitive));
    }

    public async Task<AccountOutcome> SetParentAsync(
        RecordAccessContext ctx, Guid id, Guid? parentAccountId, Guid actorId, string callerRole = "",
        bool canSeeValues = true, bool canSeeFullFinancials = true, CancellationToken ct = default)
    {
        var account = await _store.GetTrackedForUpdateAsync(id);
        if (account is null) return AccountOutcome.Refused(new Refusal("Account not found", NotFound: true));
        if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId))
            return AccountOutcome.Refused(new Refusal("Not allowed to edit this account", Forbidden: true));

        var selfRefusal = ValidateNoSelfParent(id, parentAccountId);
        if (selfRefusal is not null) return AccountOutcome.Refused(selfRefusal);

        if (parentAccountId is { } newParentId && await ValidateParentAsync(ctx, id, newParentId, ct) is { } parentRefusal)
            return AccountOutcome.Refused(parentRefusal);

        var oldParentId = account.ParentAccountId;
        if (oldParentId != parentAccountId)
        {
            _store.SetParent(account, parentAccountId);
            account.UpdatedAt = DateTime.UtcNow;
            _events.Raise(DomainEventTypes.Keys.AccountParentChanged, DomainEventTypes.AggregateTypes.Account, account.Id, actorId,
                new DomainEventPayloads.AccountParentChanged(account.Id, oldParentId, parentAccountId));
            await _store.SaveChangesAsync(ct);
        }

        var phases = await _store.PhasesAsync(ct);
        var cal = await _store.CalendarAsync();
        var defs = await ActiveDefsAsync(CustomFieldDef.ObjectTypes.Account, ct);
        return AccountOutcome.Ok(ToDto(phases, cal, account, account.Leads.ToList(), defs: defs, callerRole: callerRole,
            canSeeValues: canSeeValues, canSeeFinancials: canSeeFullFinancials, extras: await ExtrasForAsync([account.Id], ct), sensitive: ctx.Sensitive));
    }

    // --- related companies ---

    private static AccountRelationshipDto ToRelationshipDto(AccountRelationship r, Guid fromPerspectiveOf) =>
        fromPerspectiveOf == r.FromAccountId
            ? new AccountRelationshipDto(r.Id, "outgoing", r.ToAccountId, r.ToAccount?.Name ?? "?", r.Type, r.CreatedAt)
            : new AccountRelationshipDto(r.Id, "incoming", r.FromAccountId, r.FromAccount?.Name ?? "?", r.Type, r.CreatedAt);

    public async Task<(Refusal? Refusal, List<AccountRelationshipDto>? Relationships)> RelationshipsAsync(
        RecordAccessContext ctx, Guid id, CancellationToken ct = default)
    {
        var refusal = await CheckViewAsync(ctx, id, ct);
        if (refusal is not null) return (refusal, null);
        var rows = await _store.RelationshipsForAccountAsync(id, ct);
        return (null, rows.Select(r => ToRelationshipDto(r, id)).OrderBy(r => r.Type).ThenBy(r => r.CounterpartyAccountName).ToList());
    }

    public async Task<(Refusal? Refusal, AccountRelationshipDto? Relationship)> AddRelationshipAsync(
        RecordAccessContext ctx, Guid id, AccountRelationshipInput input, Guid actorId, CancellationToken ct = default)
    {
        var account = await _store.GetForAccessCheckAsync(id);
        if (account is null) return (new Refusal("Account not found", NotFound: true), null);
        if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId))
            return (new Refusal("Not allowed to edit this account", Forbidden: true), null);

        if (input.ToAccountId is not { } toId)
            return (new Refusal("to_account_id is required"), null);
        if (toId == id)
            return (new Refusal("An account cannot have a relationship with itself"), null);
        var type = (input.Type ?? "").Trim();
        if (type.Length == 0)
            return (new Refusal("type is required"), null);

        var allowedTypes = await _orgSettings.GetAccountRelationshipTypesAsync();
        if (!allowedTypes.Contains(type, StringComparer.OrdinalIgnoreCase))
            return (new Refusal($"type must be one of: {string.Join(", ", allowedTypes)}"), null);

        var target = await _store.LiteAsync(toId, ct);
        if (target is null) return (new Refusal("Related account not found", NotFound: true), null);
        if (!RecordAccess.CanView(ctx, target.OwnerId, target.TeamId))
            return (new Refusal("Not allowed to link to that account", Forbidden: true), null);

        if (await _store.RelationshipExistsAsync(id, toId, type, ct))
            return (new Refusal("This relationship already exists", Code: "duplicate_relationship"), null);

        var relationship = new AccountRelationship
        {
            Id = Guid.NewGuid(), FromAccountId = id, ToAccountId = toId, Type = type, CreatedById = actorId,
        };
        _store.AddRelationship(relationship);
        _events.Raise(DomainEventTypes.Keys.AccountRelationshipAdded, DomainEventTypes.AggregateTypes.Account, id, actorId,
            new DomainEventPayloads.AccountRelationshipAdded(relationship.Id, id, toId, type));
        await _store.SaveChangesAsync(ct);
        return (null, new AccountRelationshipDto(relationship.Id, "outgoing", toId, target.Name, type, relationship.CreatedAt));
    }

    public async Task<Refusal?> RemoveRelationshipAsync(
        RecordAccessContext ctx, Guid id, Guid relationshipId, Guid actorId, CancellationToken ct = default)
    {
        var account = await _store.GetForAccessCheckAsync(id);
        if (account is null) return new Refusal("Account not found", NotFound: true);
        if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId))
            return new Refusal("Not allowed to edit this account", Forbidden: true);

        var relationship = await _store.RelationshipByIdAsync(relationshipId, ct);
        if (relationship is null || (relationship.FromAccountId != id && relationship.ToAccountId != id))
            return new Refusal("Relationship not found", NotFound: true);

        _store.RemoveRelationship(relationship);
        _events.Raise(DomainEventTypes.Keys.AccountRelationshipRemoved, DomainEventTypes.AggregateTypes.Account, id, actorId,
            new DomainEventPayloads.AccountRelationshipRemoved(relationship.Id, relationship.FromAccountId, relationship.ToAccountId, relationship.Type));
        await _store.SaveChangesAsync(ct);
        return null;
    }

    // --- external ids (ERP/Zoho matching) ---

    public async Task<(Refusal? Refusal, List<AccountExternalIdDto>? Ids)> ExternalIdsAsync(
        RecordAccessContext ctx, Guid id, CancellationToken ct = default)
    {
        var refusal = await CheckViewAsync(ctx, id, ct);
        if (refusal is not null) return (refusal, null);
        var rows = await _store.ExternalIdsForAccountAsync(id, ct);
        return (null, rows.Select(x => new AccountExternalIdDto(x.Id, x.System, x.Value, x.CreatedAt)).ToList());
    }

    public async Task<(Refusal? Refusal, AccountExternalIdDto? ExternalId)> AddExternalIdAsync(
        RecordAccessContext ctx, Guid id, AccountExternalIdInput input, CancellationToken ct = default)
    {
        var account = await _store.GetForAccessCheckAsync(id);
        if (account is null) return (new Refusal("Account not found", NotFound: true), null);
        if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId))
            return (new Refusal("Not allowed to edit this account", Forbidden: true), null);

        var system = (input.System ?? "").Trim();
        var value = (input.Value ?? "").Trim();
        if (system.Length == 0) return (new Refusal("system is required"), null);
        if (value.Length == 0) return (new Refusal("value is required"), null);

        if (await _store.ExternalIdTakenAsync(system, value, ct))
            return (new Refusal($"An account is already mapped to {system}:{value}", Code: "duplicate_external_id"), null);

        var externalId = new AccountExternalId { Id = Guid.NewGuid(), AccountId = id, System = system, Value = value };
        _store.AddExternalId(externalId);
        await _store.SaveChangesAsync(ct);
        return (null, new AccountExternalIdDto(externalId.Id, externalId.System, externalId.Value, externalId.CreatedAt));
    }

    public async Task<Refusal?> RemoveExternalIdAsync(
        RecordAccessContext ctx, Guid id, Guid externalIdId, CancellationToken ct = default)
    {
        var account = await _store.GetForAccessCheckAsync(id);
        if (account is null) return new Refusal("Account not found", NotFound: true);
        if (!RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId))
            return new Refusal("Not allowed to edit this account", Forbidden: true);

        var externalId = await _store.ExternalIdByIdAsync(externalIdId, ct);
        if (externalId is null || externalId.AccountId != id)
            return new Refusal("External id not found", NotFound: true);

        _store.RemoveExternalId(externalId);
        await _store.SaveChangesAsync(ct);
        return null;
    }
}

using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Accounts;
using SalesApi.ProcessLayer.DocumentRegister;
using SalesApi.Services;
using SalesApi.SystemLayer.ClientDocuments;

namespace SalesApi.ProcessLayer.ClientDocuments;

/// <summary>
/// Client-document reading (to-do/proposal-deck-port-scope.md, decisions 6, 10, 11).
///
/// A client's own documents are attached to a deal or an account with the tag <c>doctype:{key}</c>. This class:
///  1. READS them: <see cref="RunPassAsync"/> (the worker's pass) takes the files waiting in <c>read_state = queued</c>, gets their
///     text through <see cref="IDocumentTextExtractor"/> (open-source OCR on this server), finds the values with
///     <see cref="ClientDocumentExtractor"/> and stores each as a PENDING <see cref="ClientDocumentValue"/>;
///  2. lets a person CONFIRM, EDIT-and-confirm, REJECT, or ENTER a value by hand. Only a confirmed value is written, to the
///     account's custom field of that key, through the EXISTING <see cref="AccountProcess.UpdateAsync"/> - so the account edit
///     permission, the sensitive-data write guard, validation, the domain event and FieldAudit's old/new all apply unchanged.
///     An edited or hand-typed value needs a REASON, written as a note on the account through the EXISTING
///     <see cref="AccountProcess.AddActivityAsync"/> (no reason column anywhere).
///
/// Never writes anything it read until a person has confirmed it. Business policy needs no org setting here: the
/// "confirm every value" rule is the owner's fixed decision, and the OCR limits (pages, timeout) are deployment resource limits.
/// </summary>
public sealed class ClientDocumentProcess
{
    private readonly ClientDocumentStore _store;
    private readonly AccountProcess _accounts;
    private readonly IDocumentTextExtractor _text;
    private readonly DocumentRegisterProcess? _register;

    // The register is E15.1's: a confirmed number / expiry is written to it too. Optional and last so existing hand-wired chains compile;
    // Program.cs supplies it.
    private readonly OrgSettingsReader? _orgSettings;
    public ClientDocumentProcess(ClientDocumentStore store, AccountProcess accounts, IDocumentTextExtractor text, DocumentRegisterProcess? register = null,
        OrgSettingsReader? orgSettings = null)
    {
        _orgSettings = orgSettings;
        _store = store;
        _accounts = accounts;
        _text = text;
        _register = register;
    }

    /// <summary>Why a request could not be carried out. Same shape as AccountProcess.Refusal (the controller picks the status).</summary>
    public sealed record Refusal(
        string Reason, bool NotFound = false, bool Forbidden = false, string? Code = null, string? Field = null,
        IReadOnlyList<string>? Fields = null);

    public sealed record ListOutcome(Refusal? Refusal, ClientDocumentsDto? Result)
    {
        public static ListOutcome Refused(Refusal r) => new(r, null);
    }

    public sealed record ValueOutcome(Refusal? Refusal, ClientDocumentValueDto? Value)
    {
        public static ValueOutcome Refused(Refusal r) => new(r, null);
    }

    public const int MaxReasonLength = 500;
    public const int MaxValueLength = 500;
    private const int ReasonMinLength = 3;

    // --- reading ---------------------------------------------------------------------------------------------

    /// <summary>GET /client-documents/fields: what each document type can fill.</summary>
    public static List<ClientDocumentTypeDto> Catalogue() => ClientDocumentFields.ToDtos();

    /// <summary>
    /// The worker's pass for the current org: puts back reads a stopped task left half-done, then reads up to <paramref name="take"/>
    /// queued files, one after another. A file that fails is marked failed with a plain reason and never blocks the others.
    /// Returns how many files were handled.
    /// </summary>
    public async Task<int> RunPassAsync(int take = 3, CancellationToken ct = default)
    {
        await _store.RequeueStaleReadsAsync(DateTime.UtcNow.AddMinutes(-10), ct);
        var queued = await _store.QueuedAsync(take, ct);
        foreach (var file in queued)
            await ReadAsync(file, ct);
        return queued.Count;
    }

    /// <summary>Reads one file now (whatever its state) - for a test, or a "read now" path, without the worker. False when it is not a client document.</summary>
    public async Task<bool> ReadNowAsync(Guid attachmentId, CancellationToken ct = default)
    {
        var file = await _store.FindAttachmentAsync(attachmentId, ct);
        if (file is null || !AttachmentTags.IsClientDocument(file.Tag)) return false;
        await ReadAsync(file, ct);
        return true;
    }

    private async Task ReadAsync(Attachment file, CancellationToken ct)
    {
        var docType = AttachmentTags.ClientDocumentType(file.Tag);
        var rules = docType is null ? null : ClientDocumentFields.Type(docType);
        if (rules is null)
        {
            await SetStateAsync(file, ClientDocumentReadStates.NotApplicable,
                "This type of document is kept with the record but not read automatically. Enter its values by hand.", ct);
            return;
        }
        if (file.Kind == AttachmentKind.SharePointLink)
        {
            await SetStateAsync(file, ClientDocumentReadStates.Failed,
                "A linked SharePoint file cannot be read here. Upload the file itself, or enter the values by hand.", ct);
            return;
        }

        file.ReadState = ClientDocumentReadStates.Reading;
        file.ReadAt = DateTime.UtcNow;
        await _store.SaveAsync(ct);

        try
        {
            await using var bytes = await _store.OpenAsync(file, ct);
            if (bytes is null)
            {
                await SetStateAsync(file, ClientDocumentReadStates.Failed, "The file is missing from storage.", ct);
                return;
            }
            var result = await _text.ExtractAsync(bytes, file.Filename, file.MimeType, ct);
            if (result.Status != DocumentTextStatus.Ok)
            {
                await SetStateAsync(file, ClientDocumentReadStates.Failed, result.Message ?? "This file could not be read.", ct);
                return;
            }

            var found = ClientDocumentExtractor.Extract(rules.Key, result.Text);
            var accountId = file.RecordType == AttachmentRecordType.Account
                ? file.RecordId
                : await _store.AccountIdOfLeadAsync(file.RecordId, ct);
            Guid? leadId = file.RecordType == AttachmentRecordType.Lead ? file.RecordId : null;

            // A re-read replaces this file's own unconfirmed rows; confirmed ones are history and stay.
            foreach (var old in await _store.PendingOfAttachmentAsync(file.Id, ct))
                old.Status = ClientDocumentValueStatus.Superseded;

            var added = 0;
            foreach (var f in found)
            {
                // Nothing to confirm when the account already holds exactly this, confirmed.
                if (accountId is Guid a && await _store.ConfirmedValueExistsAsync(a, f.FieldKey, f.Value, ct)) continue;
                _store.Add(new ClientDocumentValue
                {
                    Id = Guid.NewGuid(),
                    AccountId = accountId,
                    LeadId = leadId,
                    FieldKey = f.FieldKey,
                    DocumentType = rules.Key,
                    Value = f.Value,
                    ReadValue = f.Value,
                    SourceAttachmentId = file.Id,
                    SourceFileName = file.Filename,
                    Confidence = f.Confidence,
                    Evidence = f.Evidence,
                    Status = ClientDocumentValueStatus.Pending,
                    Origin = ClientDocumentValueOrigin.Read,
                    ReadAt = DateTime.UtcNow,
                });
                added++;
            }
            file.ReadState = ClientDocumentReadStates.Read;
            file.ReadAt = DateTime.UtcNow;
            file.ReadMessage = found.Count == 0
                ? "Nothing could be picked out of this document. Enter the values by hand."
                : added == 0 ? "Everything found is already confirmed on the account." : null;
            await _store.SaveAsync(ct);
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception)
        {
            // A read must never take the worker or a request down; the person is told in words and can read again or type the values.
            await SetStateAsync(file, ClientDocumentReadStates.Failed, "This file could not be read. Try again, or enter the values by hand.", ct);
        }
    }

    private async Task SetStateAsync(Attachment file, string state, string? message, CancellationToken ct)
    {
        file.ReadState = state;
        file.ReadMessage = message;
        file.ReadAt = DateTime.UtcNow;
        await _store.SaveAsync(ct);
    }

    /// <summary>POST /client-documents/files/{attachmentId}/read: "Read again". The caller must be able to edit the file's record.</summary>
    public async Task<Refusal?> ReadAgainAsync(RecordAccessContext ctx, Guid attachmentId, CancellationToken ct = default)
    {
        var file = await _store.FindAttachmentAsync(attachmentId, ct);
        if (file is null || !AttachmentTags.IsClientDocument(file.Tag))
            return new Refusal("File not found", NotFound: true);
        var refusal = await CanManageRecordAsync(ctx, file.RecordType, file.RecordId, ct);
        if (refusal is not null) return refusal;
        file.ReadState = ClientDocumentReadStates.Queued;
        file.ReadMessage = null;
        await _store.SaveAsync(ct);
        return null;
    }

    // --- listing ---------------------------------------------------------------------------------------------

    /// <summary>
    /// GET /client-documents?account_id= | lead_id= [&amp;status=pending|confirmed|all]. For an account: its document files (on the account and
    /// on its deals) and its values. For a deal: the deal's files, and the values of the deal's account (or the deal's own, while it
    /// has no account - <c>needs_account</c> then tells the screen why nothing can be confirmed yet). Default status: pending and confirmed.
    /// A value the caller may not see at full is masked the way the account's own custom field is.
    /// </summary>
    public async Task<ListOutcome> ListAsync(
        RecordAccessContext ctx, string callerRole, Guid? accountId, Guid? leadId, string? status, CancellationToken ct = default)
    {
        if ((accountId is null) == (leadId is null))
            return ListOutcome.Refused(new Refusal("Give exactly one of account_id or lead_id."));
        if (status is not null && status != "all" && !ClientDocumentValueStatus.All.Contains(status))
            return ListOutcome.Refused(new Refusal("status must be pending, confirmed, rejected, superseded or all"));

        Guid? effectiveAccount;
        Guid? ownerId, teamId;
        List<Attachment> files;
        if (accountId is Guid aid)
        {
            var viewRefusal = await ViewAccountAsync(ctx, aid, ct);
            if (viewRefusal is not null) return ListOutcome.Refused(viewRefusal);
            var account = await _store.FindAccountAsync(aid, ct);
            effectiveAccount = aid; ownerId = account?.OwnerId; teamId = account?.TeamId;
            files = await _store.DocumentFilesOfAccountAsync(aid, ct);
        }
        else
        {
            var lead = await _store.FindLeadAsync(leadId!.Value, ct);
            if (lead is null || !RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId))
                return ListOutcome.Refused(new Refusal("Deal not found", NotFound: true));
            effectiveAccount = lead.AccountId;
            ownerId = lead.OwnerId; teamId = lead.TeamId;
            if (effectiveAccount is Guid la)
            {
                var account = await _store.FindAccountAsync(la, ct);
                ownerId = account?.OwnerId ?? ownerId; teamId = account?.TeamId ?? teamId;
            }
            files = await _store.DocumentFilesOfLeadAsync(lead.Id, ct);
        }

        var rows = effectiveAccount is Guid ea ? await _store.ValuesOfAccountAsync(ea, ct) : await _store.ValuesOfLeadAsync(leadId!.Value, ct);
        var wanted = status switch
        {
            null => new[] { ClientDocumentValueStatus.Pending, ClientDocumentValueStatus.Confirmed },
            "all" => ClientDocumentValueStatus.All,
            var s => new[] { s },
        };
        // Boot seeds these fields for every org; an org created since gets them here, so the masking below always has the definitions.
        await _store.EnsureAccountFieldsAsync(ct);
        var defs = await _store.ActiveAccountDefsAsync(ct);
        var companyTypes = await CompanyDocumentTypesAsync();
        var values = rows.Where(v => wanted.Contains(v.Status))
            .OrderBy(v => v.Status == ClientDocumentValueStatus.Pending ? 0 : 1).ThenByDescending(v => v.ReadAt)
            .Select(v => ToDto(v, defs, callerRole, ctx.Sensitive, ownerId, teamId, companyTypes)).ToList();
        var fileDtos = files.Select(f => new ClientDocumentFileDto(
            f.Id, f.Filename, AttachmentTags.ClientDocumentType(f.Tag) ?? "", f.RecordType, f.RecordId, f.ReadState, f.ReadMessage,
            f.ReadAt, f.CreatedAt, FileUrl(f.Id),
            // Owner 2026-11-16: an identity / bank file is listed but cannot be opened below a raw ID & bank read.
            CanOpen: IdBankDocuments.MayOpen(AttachmentTags.ClientDocumentType(f.Tag), ctx.Sensitive, companyTypes))).ToList();
        return new ListOutcome(null, new ClientDocumentsDto(fileDtos, values, effectiveAccount, NeedsAccount: effectiveAccount is null));
    }

    // --- confirming ------------------------------------------------------------------------------------------

    /// <summary>POST /client-documents/values/{id}/confirm: the value as read becomes the account's field value.</summary>
    public async Task<ValueOutcome> ConfirmAsync(RecordAccessContext ctx, string callerRole, Guid valueId, CancellationToken ct = default)
    {
        var value = await _store.FindValueAsync(valueId, ct);
        if (value is null) return ValueOutcome.Refused(new Refusal("Value not found", NotFound: true));
        return await ConfirmCoreAsync(ctx, callerRole, value, value.Value, ClientDocumentValueOrigin.Read, reason: null, isNew: false, ct);
    }

    /// <summary>POST /client-documents/values/{id}/confirm-edited: a person changes what was read, then confirms it. A reason is
    /// required whenever the value differs from what was read; it is written as a note on the account.</summary>
    public async Task<ValueOutcome> ConfirmEditedAsync(
        RecordAccessContext ctx, string callerRole, Guid valueId, ClientDocumentEditInput input, CancellationToken ct = default)
    {
        var value = await _store.FindValueAsync(valueId, ct);
        if (value is null) return ValueOutcome.Refused(new Refusal("Value not found", NotFound: true));
        var spec = ClientDocumentFields.Field(value.FieldKey);
        if (spec is null) return ValueOutcome.Refused(new Refusal("That field is not one documents fill."));

        var (final, valueRefusal) = CleanValue(spec, input.Value);
        if (valueRefusal is not null) return ValueOutcome.Refused(valueRefusal);
        if (string.Equals(final, value.Value, StringComparison.Ordinal))
            return await ConfirmCoreAsync(ctx, callerRole, value, value.Value, ClientDocumentValueOrigin.Read, reason: null, isNew: false, ct);

        var (reason, reasonRefusal) = CleanReason(input.Reason);
        if (reasonRefusal is not null) return ValueOutcome.Refused(reasonRefusal);
        return await ConfirmCoreAsync(ctx, callerRole, value, final!, ClientDocumentValueOrigin.Edited, reason, isNew: false, ct);
    }

    /// <summary>POST /client-documents/values: a value typed in with no file. A reason is required. Written straight to the account
    /// (a person typed it - there is nothing for a second person to confirm).</summary>
    public async Task<ValueOutcome> AddManualAsync(
        RecordAccessContext ctx, string callerRole, ClientDocumentManualInput input, CancellationToken ct = default)
    {
        if (input.AccountId is not Guid accountId) return ValueOutcome.Refused(new Refusal("account_id is required", Field: "account_id"));
        var spec = input.FieldKey is null ? null : ClientDocumentFields.Field(input.FieldKey.Trim());
        if (spec is null)
            return ValueOutcome.Refused(new Refusal("field_key must be one of: " + string.Join(", ", ClientDocumentFields.AccountFields.Select(f => f.Key)), Field: "field_key"));
        var (final, valueRefusal) = CleanValue(spec, input.Value);
        if (valueRefusal is not null) return ValueOutcome.Refused(valueRefusal);
        var (reason, reasonRefusal) = CleanReason(input.Reason);
        if (reasonRefusal is not null) return ValueOutcome.Refused(reasonRefusal);
        var viewRefusal = await ViewAccountAsync(ctx, accountId, ct);
        if (viewRefusal is not null) return ValueOutcome.Refused(viewRefusal);

        var row = new ClientDocumentValue
        {
            Id = Guid.NewGuid(),
            AccountId = accountId,
            FieldKey = spec.Key,
            DocumentType = string.IsNullOrWhiteSpace(input.DocumentType) ? "" : input.DocumentType.Trim(),
            Value = final!,
            Status = ClientDocumentValueStatus.Pending,
            Origin = ClientDocumentValueOrigin.Manual,
            ReadAt = DateTime.UtcNow,
        };
        return await ConfirmCoreAsync(ctx, callerRole, row, final!, ClientDocumentValueOrigin.Manual, reason, isNew: true, ct);
    }

    /// <summary>POST /client-documents/values/{id}/reject: the value is wrong; it is kept as rejected and never written.</summary>
    public async Task<ValueOutcome> RejectAsync(RecordAccessContext ctx, string callerRole, Guid valueId, CancellationToken ct = default)
    {
        var value = await _store.FindValueAsync(valueId, ct);
        if (value is null) return ValueOutcome.Refused(new Refusal("Value not found", NotFound: true));
        if (value.Status != ClientDocumentValueStatus.Pending)
            return ValueOutcome.Refused(new Refusal("That value has already been dealt with.", Code: "not_pending"));
        var (refusal, accountId) = await RecordOfValueAsync(ctx, value, ct);
        if (refusal is not null) return ValueOutcome.Refused(refusal);

        value.Status = ClientDocumentValueStatus.Rejected;
        value.ConfirmedById = ctx.UserId;   // who dealt with it
        value.ConfirmedAt = DateTime.UtcNow;
        await _store.SaveAsync(ct);
        return new ValueOutcome(null, await ToDtoAsync(ctx, callerRole, value, accountId, ct));
    }

    private async Task<ValueOutcome> ConfirmCoreAsync(
        RecordAccessContext ctx, string callerRole, ClientDocumentValue value, string final, string origin, string? reason, bool isNew, CancellationToken ct)
    {
        if (!isNew && value.Status != ClientDocumentValueStatus.Pending)
            return ValueOutcome.Refused(new Refusal("That value has already been dealt with.", Code: "not_pending"));
        var spec = ClientDocumentFields.Field(value.FieldKey);
        if (spec is null) return ValueOutcome.Refused(new Refusal("That field is not one documents fill."));

        var accountId = value.AccountId ?? (value.LeadId is Guid lid ? await _store.AccountIdOfLeadAsync(lid, ct) : null);
        if (accountId is null)
            return ValueOutcome.Refused(new Refusal(
                "This deal has no account yet. Link the deal to an account first, then confirm the values.", Code: "needs_account"));
        if (!isNew)
        {
            var (recordRefusal, _) = await RecordOfValueAsync(ctx, value, ct);
            if (recordRefusal is not null) return ValueOutcome.Refused(recordRefusal);
        }

        // The field must exist before the account save so the update path validates it by its type; boot seeds it, this covers an org
        // created since.
        await _store.EnsureAccountFieldsAsync(ct);

        // An admins-only field: a caller who may not see it cannot write it either (the account save would silently keep the old value),
        // so say so instead.
        var fieldDef = (await _store.ActiveAccountDefsAsync(ct)).FirstOrDefault(d => string.Equals(d.Key, spec.Key, StringComparison.OrdinalIgnoreCase));
        if (fieldDef is not null && !CustomFieldMasking.IsVisibleTo(fieldDef, callerRole))
            return ValueOutcome.Refused(new Refusal($"Only an admin can confirm or enter {spec.Label}.", Forbidden: true));

        // The write is the ordinary account update: edit permission, sensitive-data write guard, validation, event and FieldAudit.
        var custom = JsonSerializer.SerializeToElement(new Dictionary<string, string> { [spec.Key] = final });
        var update = await _accounts.UpdateAsync(
            ctx, accountId.Value,
            new AccountInput(null, null, null, null, null, null, null, null, null, null, Custom: custom),
            callerRole, ct: ct);
        if (update.Refusal is { } r)
            return ValueOutcome.Refused(new Refusal(r.Reason, r.NotFound, r.Forbidden, r.Code, r.Field, r.Fields));

        // The receipt.
        foreach (var older in await _store.ConfirmedOfFieldAsync(accountId.Value, spec.Key, value.Id, ct))
            older.Status = ClientDocumentValueStatus.Superseded;
        value.AccountId = accountId;
        value.Value = final;
        value.Origin = origin;
        value.Status = ClientDocumentValueStatus.Confirmed;
        value.ConfirmedById = ctx.UserId;
        value.ConfirmedAt = DateTime.UtcNow;
        if (isNew) _store.Add(value);
        await _store.SaveAsync(ct);
        // E15.1: the document register follows what a person confirmed (the account field above is already written).
        if (_register is not null)
            await _register.RecordConfirmedValueAsync(
                accountId.Value, value.DocumentType, spec.Key, final, value.SourceAttachmentId, value.SourceFileName, ctx.UserId, ct);

        if (reason is not null)
        {
            var note = await _accounts.AddActivityAsync(ctx, ctx.UserId, accountId.Value,
                new AccountActivityInput("note", ReasonNote(spec, value, reason, origin)), ct);
            // The value is already written and receipted; a note that cannot be filed is reported, not hidden.
            if (note.Refusal is { } nr)
                return ValueOutcome.Refused(new Refusal(
                    "The value was saved, but the note giving your reason could not be filed: " + nr.Reason, nr.NotFound, nr.Forbidden, "note_not_filed"));
        }
        return new ValueOutcome(null, await ToDtoAsync(ctx, callerRole, value, accountId, ct));
    }

    /// <summary>The account note that carries an edit's or a hand entry's reason. For a field with a sensitive-data category the
    /// values themselves are left out: the note is on a timeline many roles read.</summary>
    private static string ReasonNote(AccountFieldSpec spec, ClientDocumentValue value, string reason, string origin)
    {
        var shown = !spec.Sensitive;
        if (origin == ClientDocumentValueOrigin.Manual)
            return shown
                ? $"Client document field \"{spec.Label}\" entered by hand: \"{value.Value}\". Reason: {reason}"
                : $"Client document field \"{spec.Label}\" entered by hand. Reason: {reason}";
        return shown
            ? $"Client document field \"{spec.Label}\" read as \"{value.ReadValue}\" from {value.SourceFileName ?? "a document"}, confirmed as \"{value.Value}\". Reason: {reason}"
            : $"Client document field \"{spec.Label}\" read from {value.SourceFileName ?? "a document"} and changed before confirming. Reason: {reason}";
    }

    // --- rules -----------------------------------------------------------------------------------------------

    private static (string? Value, Refusal? Refusal) CleanValue(AccountFieldSpec spec, string? raw)
    {
        var v = raw?.Trim();
        if (string.IsNullOrEmpty(v)) return (null, new Refusal("A value is required.", Field: "value"));
        if (v.Length > MaxValueLength) return (null, new Refusal($"The value is too long (at most {MaxValueLength} characters).", Field: "value"));
        if (spec.Type == "date")
        {
            var iso = ClientDocumentExtractor.ParseDate(v);
            if (iso is null) return (null, new Refusal($"{spec.Label}: enter a date, for example 31/12/2027.", Field: "value"));
            return (iso, null);
        }
        return (v, null);
    }

    private static (string? Reason, Refusal? Refusal) CleanReason(string? raw)
    {
        var r = raw?.Trim();
        if (string.IsNullOrEmpty(r) || r.Length < ReasonMinLength)
            return (null, new Refusal("A reason is required when you change a value or enter one by hand.", Code: "reason_required", Field: "reason"));
        return (r.Length > MaxReasonLength ? r[..MaxReasonLength] : r, null);
    }

    /// <summary>The caller may view the account (its own rule: 404 not found, 403 not allowed).</summary>
    private async Task<Refusal?> ViewAccountAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct)
    {
        var r = await _accounts.CheckViewAsync(ctx, accountId, ct);
        return r is null ? null : new Refusal(r.Reason, r.NotFound, r.Forbidden, r.Code, r.Field, r.Fields);
    }

    /// <summary>May the caller act on the record this value hangs on (its account, else its deal)? View is enough to look; the
    /// write itself is judged by the account update.</summary>
    private async Task<(Refusal? Refusal, Guid? AccountId)> RecordOfValueAsync(RecordAccessContext ctx, ClientDocumentValue value, CancellationToken ct)
    {
        if (value.AccountId is Guid aid)
        {
            var r = await ViewAccountAsync(ctx, aid, ct);
            return (r, aid);
        }
        if (value.LeadId is Guid lid)
        {
            var lead = await _store.FindLeadAsync(lid, ct);
            if (lead is null || !RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId)) return (new Refusal("Deal not found", NotFound: true), null);
            if (lead.AccountId is Guid la)
            {
                var r = await ViewAccountAsync(ctx, la, ct);
                return (r, la);
            }
            return (null, null);
        }
        return (new Refusal("Value not found", NotFound: true), null);
    }

    private async Task<Refusal?> CanManageRecordAsync(RecordAccessContext ctx, string recordType, Guid recordId, CancellationToken ct)
    {
        if (recordType == AttachmentRecordType.Account)
        {
            var account = await _store.FindAccountAsync(recordId, ct);
            if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return new Refusal("File not found", NotFound: true);
            return RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId) ? null : new Refusal("Not allowed to edit this account", Forbidden: true);
        }
        var lead = await _store.FindLeadAsync(recordId, ct);
        if (lead is null || !RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId)) return new Refusal("File not found", NotFound: true);
        return RecordAccess.CanManage(ctx, lead.OwnerId, lead.TeamId) ? null : new Refusal("Not allowed to edit this deal", Forbidden: true);
    }

    // --- shaping ---------------------------------------------------------------------------------------------

    /// <summary>Owner 2026-11-16: the org's company-document types (no ID or bank data); the built-in default when unwired or unset.</summary>
    private async Task<IReadOnlyCollection<string>> CompanyDocumentTypesAsync() =>
        _orgSettings is null ? IdBankDocuments.CompanyDocumentTypes : await _orgSettings.GetCompanyDocumentTypesAsync();

    private static string FileUrl(Guid attachmentId) => $"/attachments/{attachmentId}/file";

    private async Task<ClientDocumentValueDto> ToDtoAsync(
        RecordAccessContext ctx, string callerRole, ClientDocumentValue v, Guid? accountId, CancellationToken ct)
    {
        Guid? owner = null, team = null;
        if (accountId is Guid a && await _store.FindAccountAsync(a, ct) is { } account) { owner = account.OwnerId; team = account.TeamId; }
        return ToDto(v, await _store.ActiveAccountDefsAsync(ct), callerRole, ctx.Sensitive, owner, team, await CompanyDocumentTypesAsync());
    }

    /// <summary>The value as the caller may see it: run through the SAME masking as the account's custom fields (role list, sensitive
    /// flag, E12 category level), so a screen never shows a value the account page would hide.</summary>
    private static ClientDocumentValueDto ToDto(
        ClientDocumentValue v, IReadOnlyCollection<CustomFieldDef> defs, string callerRole, SensitiveAccess? sensitive, Guid? ownerId, Guid? teamId,
        IReadOnlyCollection<string>? companyTypes = null)
    {
        var label = ClientDocumentFields.Field(v.FieldKey)?.Label ?? v.FieldKey;
        string? value = v.Value, readValue = v.ReadValue;
        var masked = false;
        if (defs.Any(d => string.Equals(d.Key, v.FieldKey, StringComparison.OrdinalIgnoreCase)))
        {
            (value, masked) = Mask(v.FieldKey, v.Value, defs, callerRole, sensitive, ownerId, teamId);
            if (readValue is not null) readValue = Mask(v.FieldKey, readValue, defs, callerRole, sensitive, ownerId, teamId).Value;
        }
        // Owner 2026-11-16 (decision 5): what is READ from an identity / bank document is ID & bank data. Below a raw read the id number is withheld (masked, like the account's own field),
        // and the evidence snippet (the text around the match, which can hold the number or an IBAN) and the link to the file go with it.
        var canOpen = IdBankDocuments.MayOpen(v.DocumentType, sensitive, companyTypes);
        var evidence = canOpen ? v.Evidence : null;
        if (!canOpen && ClientDocumentFields.Types.Any(t => t.Key == v.DocumentType && t.Rules.Any(r => r.FieldKey == v.FieldKey && r.Kind == DocValueKind.IdNumber)))
        {
            value = null; readValue = null; masked = true;
        }
        return new ClientDocumentValueDto(
            v.Id, v.AccountId, v.LeadId, v.FieldKey, label, v.DocumentType, value, masked, v.Status, v.Origin, v.Confidence, evidence,
            v.SourceAttachmentId, v.SourceFileName, v.SourceAttachmentId is Guid sid && canOpen ? FileUrl(sid) : null,
            v.ReadAt, v.ConfirmedById, v.ConfirmedAt, readValue);
    }

    internal static (string? Value, bool Masked) Mask(
        string key, string value, IReadOnlyCollection<CustomFieldDef> defs, string callerRole, SensitiveAccess? sensitive, Guid? ownerId, Guid? teamId)
    {
        var blob = JsonSerializer.SerializeToElement(new Dictionary<string, string> { [key] = value });
        var shown = CustomFieldMasking.Apply(blob, defs, callerRole, sensitive, ownerId, teamId);
        if (shown.ValueKind != JsonValueKind.Object || !shown.TryGetProperty(key, out var p)) return (null, true);   // hidden: the key is dropped
        var text = p.ValueKind == JsonValueKind.String ? p.GetString() : null;
        return (text, !string.Equals(text, value, StringComparison.Ordinal));
    }
}

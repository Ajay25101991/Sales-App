using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using SalesApi.SystemLayer.ClientDocuments;

namespace SalesApi.ProcessLayer.ClientDocuments;

/// <summary>A value found in a document's text: the account field it fills, what was read, how sure, and why.</summary>
/// <param name="Confidence">"high" (the shape of the value itself was checked: a 15-digit TRN, an Emirates ID), "medium" (found beside its label on the same line) or "low" (taken from the next line, or from wording).</param>
/// <param name="Evidence">Plain words for the person confirming: <c>Found near "Licence No."</c>.</param>
public sealed record FoundValue(string FieldKey, string Value, string Confidence, string Evidence);

/// <summary>
/// Finds the values of one kind of client document in its OCR text. PURE: text in, values out, no database, no process, so it is
/// tested with hand-written English and Arabic fixtures. What is looked for, and beside which labels, is the data in
/// <see cref="ClientDocumentFields"/>; this is the engine that applies it. It guesses, which is why every value it finds waits
/// for a person to confirm it.
/// </summary>
public static class ClientDocumentExtractor
{
    public const string High = "high";
    public const string Medium = "medium";
    public const string Low = "low";
    private const int MaxValueLength = 200;

    public static List<FoundValue> Extract(string documentType, string? text)
    {
        var found = new List<FoundValue>();
        var rules = ClientDocumentFields.Type(documentType);
        if (rules is null || string.IsNullOrWhiteSpace(text)) return found;

        var normalised = Normalise(text);
        var lines = normalised.Split('\n').Select(l => l.TrimEnd('\r')).ToArray();
        var anyLabelAtStart = AnyLabelAtStart(rules);

        foreach (var rule in rules.Rules)
        {
            if (found.Any(f => f.FieldKey == rule.FieldKey)) continue; // one value per field per document
            var value = Find(rule, normalised, lines, anyLabelAtStart);
            if (value is not null) found.Add(value);
        }
        return found;
    }

    // --- text clean-up --------------------------------------------------------------------------------------

    /// <summary>Eastern Arabic and Persian digits become 0-9, the invisible direction marks OCR and PDFs sprinkle in are dropped,
    /// and a no-break space is a space.</summary>
    public static string Normalise(string text)
    {
        var sb = new StringBuilder(text.Length);
        foreach (var c in text)
        {
            if (c is >= '٠' and <= '٩') sb.Append((char)('0' + (c - '٠')));
            else if (c is >= '۰' and <= '۹') sb.Append((char)('0' + (c - '۰')));
            else if (c is '‎' or '‏' or (>= '‪' and <= '‮') or '⁦' or '⁧' or '⁨' or '⁩' or '﻿') continue;
            else if (c == ' ') sb.Append(' ');
            else sb.Append(c);
        }
        return sb.ToString();
    }

    // --- label matching -------------------------------------------------------------------------------------

    private static readonly Dictionary<string, Regex> LabelCache = new();

    private static Regex LabelRegex(IEnumerable<string> labels)
    {
        var pattern = @"(?<![\p{L}\p{N}])(?:" + string.Join("|", labels) + @")(?![\p{L}\p{N}])";
        lock (LabelCache)
        {
            if (!LabelCache.TryGetValue(pattern, out var re))
                LabelCache[pattern] = re = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Compiled, TimeSpan.FromSeconds(2));
            return re;
        }
    }

    /// <summary>"Starts with ANY label of this kind of document": a line that is itself a label is not a value (the label's own value was
    /// on its row, and the next row is the next label).</summary>
    private static Regex AnyLabelAtStart(DocTypeRules rules)
    {
        var all = rules.Rules.SelectMany(r => r.Labels).Distinct();
        var pattern = @"^\s*(?:" + string.Join("|", all) + @")(?![\p{L}\p{N}])";
        lock (LabelCache)
        {
            if (!LabelCache.TryGetValue(pattern, out var re))
                LabelCache[pattern] = re = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Compiled, TimeSpan.FromSeconds(2));
            return re;
        }
    }

    private static readonly Regex LeadingSeparators = new(@"^[\s:：\-–—|/.،]+", RegexOptions.Compiled);
    private static readonly Regex ColumnBreak = new(@"\s{3,}|\t", RegexOptions.Compiled);
    private static readonly Regex MailLine = new(@"e-?mail|البريد", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    /// <summary>The first column of what follows a label: a layout-preserved PDF puts the English label, the value and the Arabic
    /// label on one line, separated by runs of spaces.</summary>
    private static string FirstColumn(string s)
    {
        var trimmed = LeadingSeparators.Replace(s, "").Trim();
        if (trimmed.Length == 0) return "";
        return ColumnBreak.Split(trimmed).Select(p => p.Trim()).FirstOrDefault(p => p.Length > 0) ?? "";
    }

    private static FoundValue? Find(DocFieldRule rule, string text, string[] lines, Regex anyLabelAtStart)
    {
        if (rule.Kind == DocValueKind.Law) return FindLaw(rule, lines);

        // The kinds whose VALUE has a checkable shape are looked for in the whole text first: a label is a hint, not a requirement.
        switch (rule.Kind)
        {
            case DocValueKind.Trn:
            {
                var trn = TrnPattern.Match(text);
                if (trn.Success)
                {
                    var digits = new string(trn.Value.Where(char.IsDigit).ToArray());
                    var label = NearestLabel(rule, lines, trn.Value);
                    return new FoundValue(rule.FieldKey, digits, High,
                        label is null ? "Matched the 15-digit Tax Registration Number format" : $"Matched the 15-digit TRN format, near \"{label}\"");
                }
                break;
            }
            case DocValueKind.IdNumber:
            {
                var eid = EmiratesIdPattern.Match(text);
                if (eid.Success)
                {
                    var d = new string(eid.Value.Where(char.IsDigit).ToArray());
                    return new FoundValue(rule.FieldKey, $"{d[..3]}-{d[3..7]}-{d[7..14]}-{d[14..]}", High, "Matched the Emirates ID number format");
                }
                break;
            }
        }

        var byLabel = FindByLabel(rule, lines, anyLabelAtStart);
        if (byLabel is not null) return byLabel;

        // Nothing beside a label: the wording itself may name it.
        switch (rule.Kind)
        {
            case DocValueKind.LegalForm:
            {
                var best = ClientDocumentFields.KnownLegalForms
                    .Select(f => (Form: f, M: FormRegex(f).Match(text)))
                    .Where(x => x.M.Success)
                    // The fullest wording wins ("Free Zone Limited Liability Company" over "LLC"); earliest on a tie.
                    .OrderByDescending(x => x.Form.Length).ThenBy(x => x.M.Index)
                    .FirstOrDefault();
                if (best.M is { Success: true })
                    return new FoundValue(rule.FieldKey, best.Form, Low, $"The document names \"{best.Form}\"");
                break;
            }
            case DocValueKind.Authority:
            {
                foreach (var line in lines)
                {
                    var hit = ClientDocumentFields.KnownAuthorities.FirstOrDefault(a => FormRegex(a).IsMatch(line));
                    if (hit is null) continue;
                    var value = Clean(FirstColumn(line));
                    if (value.Length > 0) return new FoundValue(rule.FieldKey, Truncate(value, 120), Low, $"A line of the document names \"{hit}\"");
                }
                break;
            }
            case DocValueKind.Place:
            {
                var m = IncorporatedIn.Match(text);
                if (m.Success)
                    return new FoundValue(rule.FieldKey, Clean(m.Groups["p"].Value), Low, $"The document says \"{Truncate(m.Value.Trim(), 80)}\"");
                break;
            }
        }
        return null;
    }

    // --- the governing law ----------------------------------------------------------------------------------

    private static readonly Regex LawWord = new(
        @"(?<![\p{L}])(?:law|decree|decree-law|regulations?|act|ordinance|code)(?![\p{L}])|قانون|مرسوم|لائحة|لوائح|نظام",
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Compiled, TimeSpan.FromSeconds(2));
    // "in accordance with the provisions of this Memorandum" / "pursuant to Article 5" are not a law.
    private static readonly Regex NotALaw = new(
        @"^(?:the\s+)?(?:articles?|clauses?|sections?|paragraphs?|provisions\s+of\s+this|this|these|المادة|البند|هذا|هذه)(?![\p{L}])",
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Compiled, TimeSpan.FromSeconds(2));
    private static readonly Regex OpenEnded = new(@"(?:\bNo\.?|\bof|\band|\bon|\bLaw|رقم|لسنة)$", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    /// <summary>
    /// The law the company is incorporated under, COPIED as the document states it after a cue ("incorporated under", "established in
    /// accordance with", "بموجب"...). A statement that names a law (law / decree / regulations...) is medium confidence. A statement that
    /// only names an authority or free zone is offered as it reads, low confidence, for the person to check - a law is never made up
    /// from an authority, and with no cue nothing is offered.
    /// </summary>
    private static FoundValue? FindLaw(DocFieldRule rule, string[] lines)
    {
        var cue = LabelRegex(rule.Labels);
        FoundValue? weak = null;
        for (var i = 0; i < lines.Length; i++)
        {
            var m = cue.Match(lines[i]);
            if (!m.Success) continue;
            var shown = m.Value.Trim();
            var rest = LeadingSeparators.Replace(lines[i][(m.Index + m.Length)..], "").Trim();
            if (rest.Length == 0 && i + 1 < lines.Length) rest = lines[i + 1].Trim();
            else if (OpenEnded.IsMatch(rest) && i + 1 < lines.Length && lines[i + 1].Trim().Length > 0) rest += " " + lines[i + 1].Trim();
            var cut = rest.IndexOf(';');
            if (cut >= 0) rest = rest[..cut];
            rest = Regex.Replace(rest, @"^(?:the\s+)", "", RegexOptions.IgnoreCase);
            var value = Truncate(Clean(rest), MaxValueLength);
            if (value.Length < 4 || NotALaw.IsMatch(value)) continue;

            if (LawWord.IsMatch(value)) return new FoundValue(rule.FieldKey, value, Medium, $"Found after \"{shown}\"");
            if (weak is null && ClientDocumentFields.KnownAuthorities.Any(a => FormRegex(a).IsMatch(value)))
                weak = new FoundValue(rule.FieldKey, value, Low, $"Only an authority is named after \"{shown}\" - no law. Check it");
        }
        return weak;
    }

    private static FoundValue? FindByLabel(DocFieldRule rule, string[] lines, Regex anyLabelAtStart)
    {
        var label = LabelRegex(rule.Labels);
        for (var i = 0; i < lines.Length; i++)
        {
            var line = lines[i];
            var m = label.Match(line);
            if (!m.Success) continue;
            if (rule.Kind == DocValueKind.Address && MailLine.IsMatch(line)) continue;

            var shown = m.Value.Trim().TrimEnd(':', '.');
            var sameLine = FirstColumn(line[(m.Index + m.Length)..]);
            var nextLine = false;
            string? raw = sameLine;
            var at = i;
            if (!IsUsable(raw, anyLabelAtStart))
            {
                raw = null;
                for (var j = i + 1; j <= Math.Min(i + 2, lines.Length - 1); j++)
                {
                    var candidate = FirstColumn(lines[j]);
                    if (candidate.Length == 0) continue;
                    if (IsUsable(candidate, anyLabelAtStart)) { raw = candidate; at = j; nextLine = true; }
                    break; // only the first non-empty line: anything further is a different row
                }
            }
            if (raw is null) continue;

            var value = rule.Kind == DocValueKind.Address ? GatherAddress(raw, lines, at, anyLabelAtStart) : Refine(rule.Kind, raw);
            if (string.IsNullOrWhiteSpace(value)) continue;
            return new FoundValue(rule.FieldKey, value, nextLine ? Low : Medium,
                nextLine ? $"Found on the line after \"{shown}\"" : $"Found near \"{shown}\"");
        }
        return null;
    }

    private static bool IsUsable(string s, Regex anyLabelAtStart) =>
        s.Length >= 2 && s.Any(char.IsLetterOrDigit) && !anyLabelAtStart.IsMatch(s);

    // --- cleaning each kind of value ------------------------------------------------------------------------

    private static string? Refine(DocValueKind kind, string raw)
    {
        switch (kind)
        {
            case DocValueKind.Date:
                return ParseDate(raw);
            case DocValueKind.Trn:
            {
                var digits = new string(raw.Where(char.IsDigit).ToArray());
                return digits.Length == 15 && digits.StartsWith("100", StringComparison.Ordinal) ? digits : null;
            }
            case DocValueKind.IdNumber:
            {
                var token = Regex.Match(raw, @"[A-Za-z0-9][A-Za-z0-9\- ]{4,20}").Value.Replace(" ", "").ToUpperInvariant();
                return token.Length >= 6 && token.Any(char.IsDigit) ? token : null;
            }
            default:
            {
                var cleaned = Truncate(Clean(raw), MaxValueLength);
                return cleaned.Length >= 2 ? cleaned : null;
            }
        }
    }

    private static string Clean(string s) => Regex.Replace(s, @"\s+", " ").Trim().Trim(',', ';', ':', '|', '-', '.', ' ');

    private static string Truncate(string s, int max) => s.Length <= max ? s : s[..max].TrimEnd();

    /// <summary>The label's value plus up to two more lines, while they look like a continuation (not blank, not another label, not "Word: value").</summary>
    private static string GatherAddress(string first, string[] lines, int at, Regex anyLabelAtStart)
    {
        var parts = new List<string> { Clean(first) };
        for (var j = at + 1; j <= Math.Min(at + 2, lines.Length - 1); j++)
        {
            var next = FirstColumn(lines[j]);
            if (next.Length == 0) break;
            if (anyLabelAtStart.IsMatch(next) || LooksLikeLabeledRow.IsMatch(next)) break;
            // A row with a second column ("Effective date    01/01/2018") is a label and a value, not the address running on.
            if (ColumnBreak.Split(LeadingSeparators.Replace(lines[j], "").Trim()).Count(p => p.Trim().Length > 0) > 1) break;
            parts.Add(Clean(next));
        }
        return Truncate(string.Join(", ", parts.Where(p => p.Length > 0)), MaxValueLength);
    }

    private static readonly Regex LooksLikeLabeledRow = new(@"^[\p{L}][\p{L} .'/]{1,30}\s*:", RegexOptions.Compiled);

    // --- shaped values --------------------------------------------------------------------------------------

    // 15 digits starting 100, with the spaces or dashes a printed number may carry between them.
    private static readonly Regex TrnPattern = new(@"(?<![\d])100(?:[ \-]?\d){12}(?![\d])", RegexOptions.Compiled);
    // 784-YYYY-NNNNNNN-C
    private static readonly Regex EmiratesIdPattern = new(@"(?<![\d])784[ \-]?\d{4}[ \-]?\d{7}[ \-]?\d(?![\d])", RegexOptions.Compiled);
    private static readonly Regex IncorporatedIn = new(
        @"(?i:incorporated|established|registered|domiciled)\s+(?i:in|under\s+the\s+laws\s+of)\s+(?i:the\s+)?(?<p>[A-Z][A-Za-z]+(?:\s+(?:(?i:of)\s+)?(?:(?i:the)\s+)?[A-Z][A-Za-z]+){0,4})",
        RegexOptions.Compiled);

    private static readonly System.Collections.Concurrent.ConcurrentDictionary<string, Regex> PhraseCache = new();

    private static Regex FormRegex(string phrase) =>
        PhraseCache.GetOrAdd(phrase, p => new Regex(@"(?<![\p{L}\p{N}])" + Regex.Escape(p) + @"(?![\p{L}\p{N}])",
            RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromSeconds(2)));

    /// <summary>The label nearest above (or on) the line holding a shaped value, for the note only.</summary>
    private static string? NearestLabel(DocFieldRule rule, string[] lines, string matched)
    {
        var label = LabelRegex(rule.Labels);
        for (var i = 0; i < lines.Length; i++)
        {
            if (!lines[i].Contains(matched, StringComparison.Ordinal)) continue;
            for (var j = i; j >= Math.Max(0, i - 1); j--)
            {
                var m = label.Match(lines[j]);
                if (m.Success) return m.Value.Trim().TrimEnd(':', '.');
            }
            return null;
        }
        return null;
    }

    // --- dates ----------------------------------------------------------------------------------------------

    private static readonly string[] MonthNames =
        ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];

    /// <summary>A date in any common printed layout, as yyyy-MM-dd; null when none is found. Day first when ambiguous (this is UAE paper).</summary>
    public static string? ParseDate(string s)
    {
        var n = Normalise(s);
        Match m;
        if ((m = Regex.Match(n, @"(?<!\d)(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})(?!\d)")).Success)
            return Iso(int.Parse(m.Groups[1].Value), int.Parse(m.Groups[2].Value), int.Parse(m.Groups[3].Value));
        if ((m = Regex.Match(n, @"(?<!\d)(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})(?!\d)")).Success)
            return Iso(int.Parse(m.Groups[3].Value), int.Parse(m.Groups[2].Value), int.Parse(m.Groups[1].Value));
        if ((m = Regex.Match(n, @"(?<!\d)(\d{1,2})(?:st|nd|rd|th)?[\s\-/.,]+([A-Za-z]{3,9})\.?[\s\-/.,]+(\d{4})")).Success && Month(m.Groups[2].Value) is int mo1)
            return Iso(int.Parse(m.Groups[3].Value), mo1, int.Parse(m.Groups[1].Value));
        if ((m = Regex.Match(n, @"([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})")).Success && Month(m.Groups[1].Value) is int mo2)
            return Iso(int.Parse(m.Groups[3].Value), mo2, int.Parse(m.Groups[2].Value));
        return null;
    }

    private static int? Month(string word)
    {
        var i = Array.IndexOf(MonthNames, word.Length >= 3 ? word[..3].ToLowerInvariant() : word.ToLowerInvariant());
        return i >= 0 ? i + 1 : null;
    }

    private static string? Iso(int year, int month, int day)
    {
        if (year is < 1950 or > 2100 || month is < 1 or > 12 || day is < 1 or > 31) return null;
        try { return new DateTime(year, month, day).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture); }
        catch (ArgumentOutOfRangeException) { return null; }
    }
}

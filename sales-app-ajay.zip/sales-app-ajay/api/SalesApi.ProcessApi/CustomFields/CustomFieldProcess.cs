using System.Text.RegularExpressions;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.CustomFields;
using SalesApi.SystemLayer.Picklists;

namespace SalesApi.ProcessLayer.CustomFields;

/// <summary>
/// What a legal custom field definition IS, separated from the writes
/// themselves: key/label rules, the type vocabulary, options validation, and
/// what a delete does to values already stored in leads.custom. None of these
/// are HTTP facts — they are as true of a field defined by an importer or a
/// migration script as by a designer screen, and today the controller is the
/// only thing that knows them.
/// </summary>
public sealed class CustomFieldProcess
{
    private readonly CustomFieldStore _store;
    // E3.6 — nullable so every pre-existing construction site (three in
    // Process classes, one in a live check) keeps compiling; a null store
    // means a "picklist"-type value is accepted unvalidated rather than the
    // whole save 500ing over a dependency an older call site never wired.
    // Every REAL caller (Program.cs, LoyaltyLayers.cs) supplies one.
    private readonly PicklistStore? _picklists;
    public CustomFieldProcess(CustomFieldStore store, PicklistStore? picklists = null)
    {
        _store = store;
        _picklists = picklists;
    }

    /// <summary>
    /// Why a request could not be honoured, or null when it can. A RESULT
    /// rather than an exception — "that field doesn't exist" and "that name is
    /// taken" are ordinary answers, and exceptions used for ordinary answers
    /// are how a 404/409 becomes a 500.
    /// </summary>
    public sealed record Refusal(string Reason, bool NotFound = false, bool Conflict = false);

    // date/checkbox exist so the designer's palette can offer them; both store
    // fine in the leads.custom jsonb (ISO string / bool), so neither needed a
    // migration — only this list had to stop rejecting them. `dropdown` is
    // `select`'s sibling: same `Options` list, same stored value shape, and
    // differs only in how the form renders it (inline chips vs. a picker) —
    // see OptionTypes below for the set that carries options.
    //
    // E3.1 additions: currency/percentage (numeric, rendered differently),
    // email/phone/url (string with a format rule — see ValidateValue),
    // multi_select (options-carrying, stores a JSON array of strings instead
    // of one), user (a profile id — format-checked as a GUID only; this build
    // does not verify the id names a real profile in the org, see remarks on
    // ValidateValue), long_text (string, no length cap beyond the column's
    // own). "reference" (a pointer to another lead/account/contact) is
    // EXPLICITLY DEFERRED — it needs its own storage shape (an id, not a
    // scalar) and a picker UI this story does not build.
    // E3.6 addition: "picklist" — like select/dropdown, but its choices come
    // from an OrgPicklist (CustomFieldDef.PicklistKey) instead of this
    // definition's own free-typed Options, so renaming a value's label never
    // rewrites every record that chose it (see OrgPicklistValue's remarks).
    public static readonly string[] ValidTypes =
    {
        "text", "number", "select", "date", "checkbox", "dropdown",
        "currency", "percentage", "email", "phone", "url", "multi_select", "user", "long_text", "picklist",
    };

    /// <summary>
    /// Types whose form control is driven by <c>Options</c>. Kept in one place
    /// so the next options-carrying type is one addition here, not an audit of
    /// every validation/rendering site that currently special-cases "select".
    /// </summary>
    private static readonly HashSet<string> OptionTypes = new() { "select", "dropdown", "multi_select" };

    /// <summary>
    /// Options-carrying types must ship a usable option list: trimmed,
    /// non-empty, de-duplicated (case-insensitively — "Tech" and "tech" render
    /// as the same control state to a user). An empty list is refused outright
    /// rather than silently defaulted to a placeholder like ["Option A"] — that
    /// literal string showing up on a live form is itself a bug, not a value.
    /// </summary>
    public static bool TryNormalizeOptions(string type, List<string>? raw, out List<string> normalized, out string? error)
    {
        error = null;
        if (!OptionTypes.Contains(type))
        {
            // Not an options-carrying type — Options is unused, so pass whatever
            // was sent straight through rather than silently dropping it.
            normalized = raw ?? new();
            return true;
        }

        normalized = new();
        var trimmed = (raw ?? new()).Select(o => o?.Trim() ?? "").ToList();
        if (trimmed.Any(o => o.Length == 0))
        {
            error = "Options cannot be blank";
            return false;
        }
        if (trimmed.Count == 0)
        {
            error = "A choice/dropdown field needs at least one option";
            return false;
        }
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var o in trimmed)
        {
            if (!seen.Add(o))
            {
                error = $"Duplicate option: \"{o}\"";
                return false;
            }
        }
        normalized = trimmed;
        return true;
    }

    public static string ToKey(string label)
    {
        var k = Regex.Replace(label.ToLowerInvariant(), "[^a-z0-9]+", "_").Trim('_');
        return k.Length > 40 ? k[..40] : k;
    }

    /// <summary>Object types a definition may target — the object switcher's
    /// own vocabulary.</summary>
    public static readonly string[] ValidObjectTypes =
        { CustomFieldDef.ObjectTypes.Lead, CustomFieldDef.ObjectTypes.Account, CustomFieldDef.ObjectTypes.Contact };

    private static CustomFieldDefDto ToDto(CustomFieldDef d) =>
        new(d.Id, d.Key, d.Label, d.Type, d.Options, d.SortOrder, d.CreatedAt, d.Required, d.ArchivedAt,
            d.ObjectType, d.Description, d.Sensitive, d.Searchable, d.Reportable, d.AiVisible, d.AuditChanges,
            d.VisibleToRoles, d.PicklistKey, null, d.Category);

    // Anyone signed in can read the definitions (needed to render forms).
    // Archived fields are excluded by default: they stay in the table only so
    // historical values in leads.custom (or accounts.custom/contacts.custom)
    // remain labelled on the record's detail screen.
    public async Task<List<CustomFieldDefDto>> ListAsync(bool includeArchived, string? objectType = null, CancellationToken ct = default) =>
        (await _store.ListAsync(includeArchived, objectType, ct)).Select(ToDto).ToList();

    /// <param name="actorId">Who is creating it — recorded on the draft each <c>FormIds</c> form gets.
    /// Only needed when <c>FormIds</c> is given.</param>
    public async Task<(CustomFieldDefDto? Created, Refusal? Refusal)> CreateAsync(
        CustomFieldInput input, CancellationToken ct = default, Guid? actorId = null)
    {
        if (string.IsNullOrWhiteSpace(input.Label)) return (null, new Refusal("label is required"));
        var objectType = string.IsNullOrEmpty(input.ObjectType) ? CustomFieldDef.ObjectTypes.Lead : input.ObjectType;
        if (!ValidObjectTypes.Contains(objectType))
            return (null, new Refusal($"object type must be one of: {string.Join(", ", ValidObjectTypes)}"));
        var type = string.IsNullOrEmpty(input.Type) ? "text" : input.Type;
        if (!ValidTypes.Contains(type)) return (null, new Refusal($"type must be one of: {string.Join(", ", ValidTypes)}"));
        if (!TryNormalizeOptions(type, input.Options, out var options, out var optionsError))
            return (null, new Refusal(optionsError!));
        // E3.6 — a "picklist" field must name a real, live picklist; nothing
        // else about it is meaningful without one (mirrors the options-carrying
        // types requiring a non-empty Options list above).
        if (type == "picklist")
        {
            if (string.IsNullOrWhiteSpace(input.PicklistKey))
                return (null, new Refusal("A picklist field must reference a picklist"));
            if (_picklists is not null && !await _picklists.KeyExistsAsync(input.PicklistKey, ct))
                return (null, new Refusal("That picklist does not exist"));
        }

        if (!string.IsNullOrEmpty(input.Category) && !SensitiveCategories.IsValid(input.Category))
            return (null, new Refusal($"category must be one of: {string.Join(", ", SensitiveCategories.All)}"));
        var key = string.IsNullOrWhiteSpace(input.Key) ? ToKey(input.Label!) : ToKey(input.Key!);
        if (string.IsNullOrEmpty(key)) return (null, new Refusal("label must contain letters or numbers"));
        if (await _store.ActiveKeyExistsAsync(key, objectType, ct: ct))
            return (null, new Refusal("A field with a similar name already exists", Conflict: true));

        // Owner decision 2 (form builder rework): a new LEAD field reaches only the forms the admin picked,
        // as a draft change on each. Checked before anything is written, so a bad id creates nothing.
        var formIds = (input.FormIds ?? new()).Distinct().ToList();
        if (formIds.Count > 0)
        {
            if (objectType != CustomFieldDef.ObjectTypes.Lead)
                return (null, new Refusal("form_ids only applies to lead fields"));
            if (await _store.CountActiveFormsAsync(formIds, ct) != formIds.Count)
                return (null, new Refusal("One or more of those forms was not found"));
        }

        var isLead = objectType == CustomFieldDef.ObjectTypes.Lead;
        var def = new CustomFieldDef
        {
            ObjectType = objectType,
            Key = key,
            Label = input.Label!.Trim(),
            Type = type,
            Options = options,
            // Owner decision 3: for a LEAD field the form decides Required (the schema's flag is the source of
            // truth), so the definition never stores it. `input.Required` is then the field's initial Required
            // on the forms in FormIds. Accounts and contacts have no forms: theirs stays on the definition.
            Required = !isLead && (input.Required ?? false),
            SortOrder = input.SortOrder ?? 0,
            Description = input.Description,
            Sensitive = input.Sensitive ?? false,
            Searchable = input.Searchable ?? false,
            Reportable = input.Reportable ?? false,
            AiVisible = input.AiVisible ?? false,
            AuditChanges = input.AuditChanges ?? true,
            VisibleToRoles = input.VisibleToRoles ?? new(),
            Category = string.IsNullOrEmpty(input.Category) ? null : input.Category,
            PicklistKey = type == "picklist" ? input.PicklistKey : null,
        };
        await _store.AddAsync(def, ct);
        if (formIds.Count == 0) return (ToDto(def), null);

        var added = await _store.AddToFormDraftsAsync(def, formIds, input.Required ?? false, actorId ?? Guid.Empty, ct);
        return (ToDto(def) with { AddedToFormIds = added }, null);
    }

    /// <summary>
    /// Edit a field. The storage key is editable, not frozen: renaming it
    /// migrates the value on every lead and repoints everything that referred
    /// to the old key, so a rename is a real rename rather than a new field
    /// that orphans the old data.
    /// </summary>
    public async Task<(CustomFieldDefDto? Updated, Refusal? Refusal)> UpdateAsync(
        Guid id, CustomFieldInput input, CancellationToken ct = default)
    {
        var def = await _store.ActiveByIdAsync(id, ct);
        if (def is null) return (null, new Refusal("Field not found", NotFound: true));

        if (input.Type is { } type && !ValidTypes.Contains(type))
            return (null, new Refusal($"type must be one of: {string.Join(", ", ValidTypes)}"));

        // Validate against whichever type/options end up in effect, whenever
        // either is part of this patch — a type flip onto select/dropdown with
        // no new options carries over the old (possibly empty, possibly
        // non-option) Options array, and a bare options edit must still pass
        // the same rules as create.
        if (input.Type is not null || input.Options is not null)
        {
            var effectiveType = input.Type ?? def.Type;
            var effectiveOptions = input.Options ?? def.Options;
            if (!TryNormalizeOptions(effectiveType, effectiveOptions, out var normalized, out var optionsError))
                return (null, new Refusal(optionsError!));
            def.Options = normalized;
        }
        // E3.6 — same "must name a real picklist" rule as create, evaluated
        // against whichever type ends up in effect (mirrors the options
        // re-validation immediately above).
        var effectivePicklistType = input.Type ?? def.Type;
        if (effectivePicklistType == "picklist")
        {
            var effectivePicklistKey = input.PicklistKey ?? def.PicklistKey;
            if (string.IsNullOrWhiteSpace(effectivePicklistKey))
                return (null, new Refusal("A picklist field must reference a picklist"));
            if (_picklists is not null && !await _picklists.KeyExistsAsync(effectivePicklistKey, ct))
                return (null, new Refusal("That picklist does not exist"));
        }
        if (input.Type is { } newType) def.Type = newType;
        if (input.PicklistKey is not null) def.PicklistKey = input.PicklistKey;
        if (effectivePicklistType != "picklist") def.PicklistKey = null;
        if (input.Label is { } label)
        {
            if (string.IsNullOrWhiteSpace(label)) return (null, new Refusal("label is required"));
            def.Label = label.Trim();
        }
        // Lead fields: Required is the form's (owner decision 3), so a PATCH of it is accepted and ignored
        // rather than turned back on as a second source of truth. Accounts and contacts keep theirs.
        if (input.Required is { } required && def.ObjectType != CustomFieldDef.ObjectTypes.Lead) def.Required = required;
        if (input.SortOrder is { } sortOrder) def.SortOrder = sortOrder;
        // E3.2 flags. ObjectType is deliberately NOT settable here — see the
        // CustomFieldInput.ObjectType remark: it is a create-only decision,
        // like which entity an EF migration targets.
        if (input.Description is not null) def.Description = input.Description;
        if (input.Sensitive is { } sensitive) def.Sensitive = sensitive;
        if (input.Searchable is { } searchable) def.Searchable = searchable;
        if (input.Reportable is { } reportable) def.Reportable = reportable;
        if (input.AiVisible is { } aiVisible) def.AiVisible = aiVisible;
        if (input.AuditChanges is { } auditChanges) def.AuditChanges = auditChanges;
        if (input.VisibleToRoles is not null) def.VisibleToRoles = input.VisibleToRoles;
        if (input.Category is not null)
        {
            if (input.Category.Length > 0 && !SensitiveCategories.IsValid(input.Category))
                return (null, new Refusal($"category must be one of: {string.Join(", ", SensitiveCategories.All)}"));
            def.Category = input.Category.Length == 0 ? null : input.Category;
        }

        var oldKey = def.Key;
        var newKey = input.Key is null ? oldKey : ToKey(input.Key);
        if (newKey != oldKey)
        {
            if (string.IsNullOrEmpty(newKey)) return (null, new Refusal("key must contain letters or numbers"));
            if (await _store.ActiveKeyExistsAsync(newKey, def.ObjectType, id, ct))
                return (null, new Refusal("Another field already uses that name", Conflict: true));

            def.Key = newKey;
            await _store.MigrateKeyAsync(oldKey, newKey, ct);
        }

        await _store.SaveAsync(ct);
        return (ToDto(def), null);
    }

    /// <summary>Reorder fields in one call — the designer drags, then saves the whole order.</summary>
    public async Task<(List<CustomFieldDefDto>? Reordered, Refusal? Refusal)> ReorderAsync(
        List<Guid>? ids, CancellationToken ct = default)
    {
        var idList = ids ?? new();
        if (idList.Count == 0) return (null, new Refusal("ids is required"));
        var reordered = await _store.ReorderAsync(idList, ct);
        return (reordered.Select(ToDto).ToList(), null);
    }

    /// <summary>
    /// Archive rather than delete. The values already written to leads.custom
    /// are real history — hard-deleting the definition left them in the jsonb
    /// with nothing to label them, which is data loss that looks like a
    /// successful delete.
    ///
    /// Refused while a stage entry gate requires the field. Archiving it anyway
    /// left the gate demanding a field no form could offer, so every lead trying
    /// to enter that stage failed a requirement nobody could satisfy — and the
    /// admin who caused it got a silent 204.
    ///
    /// A5 — that check now also covers PLAYBOOK gates (D5: a playbook owns its
    /// own stage list, so the org-wide list alone missed these entirely
    /// before). A DRAFT playbook gate is not a refusal reason: a draft is
    /// explicitly mutable pre-publish scratch state, so it is safe to cascade
    /// — the gate is removed from the draft's stage snapshot as part of this
    /// same delete. A LIVE playbook gate blocks the delete exactly like an
    /// org-wide one, because PlaybookService never edits a published snapshot
    /// in place; the fix there is to republish that playbook without the gate
    /// first, not to have this call silently rewrite a live, audited version.
    ///
    /// E0.4 — a GATE was never the only thing that can go dangling: a
    /// PUBLISHED lead-form visibility rule ("show this field only when X is
    /// set") or a playbook MATCH condition naming this key both silently stop
    /// doing anything the moment the field is archived out from under them —
    /// neither was checked here before, so the delete dialog said "nothing
    /// else reads it" while a rule quietly went dead. Both now block the same
    /// way a live gate does when the reader is actually LIVE (a published
    /// form; a playbook with a live version to evaluate the condition
    /// against); an unpublished form draft or a not-yet-published playbook's
    /// match rule is not blocking (nothing live breaks) but IS cascaded away —
    /// same "safe to cascade because nothing live depends on it" reasoning as
    /// a draft playbook gate — so a delete never leaves even a draft with a
    /// rule pointing at a field that no longer exists.
    ///
    /// Null means success — including the idempotent case where the field was
    /// ALREADY archived (mirrors the original controller's early `NoContent()`).
    /// </summary>
    public async Task<Refusal?> DeleteAsync(Guid id, CancellationToken ct = default)
    {
        var def = await _store.ByIdAsync(id, ct);
        if (def is null) return new Refusal("Field not found", NotFound: true);
        if (def.ArchivedAt is not null) return null;

        // E3.1 — every one of these readers (stage gates, playbook gates, form
        // visibility rules, playbook match conditions) is a LEAD concept and
        // matches purely on the definition's Key string, with no ObjectType of
        // its own to compare against. Before per-object keys existed that was
        // safe (every key was a lead key); now that "industry" can be an
        // account field AND a separate lead field, running these checks for a
        // non-lead def would block deleting the ACCOUNT field on a lead gate
        // that happens to share its name. No account/contact field is read by
        // any of these readers today (per the E3.1 brief), so skipping them
        // entirely for a non-lead def is not a narrowed check — it is the
        // correct one.
        var orgGates = def.ObjectType == CustomFieldDef.ObjectTypes.Lead
            ? await _store.StageGatesForKeyAsync(def.Key, ct) : new List<string>();
        var playbookGates = def.ObjectType == CustomFieldDef.ObjectTypes.Lead
            ? await _store.PlaybookGatesForKeyAsync(def.Key, ct) : new();
        var liveGates = playbookGates
            .Where(g => !g.IsDraft)
            .Select(g => $"{g.PlaybookName} › {g.StageLabel} stage gate")
            .ToList();

        var formRules = def.ObjectType == CustomFieldDef.ObjectTypes.Lead
            ? await _store.FormRuleReadersForKeyAsync(def.Key, ct) : new();
        var liveFormRules = formRules
            .Where(r => r.IsLive)
            .Select(r => $"{r.FormName} form › “{r.ReaderLabel}” visibility rule")
            .ToList();

        var matchRules = def.ObjectType == CustomFieldDef.ObjectTypes.Lead
            ? await _store.PlaybookMatchReadersForKeyAsync(def.Key, ct) : new();
        var liveMatchRules = matchRules
            .Where(r => r.IsLive)
            .Select(r => $"{r.PlaybookName} match rule")
            .ToList();

        var blocking = orgGates.Concat(liveGates).Concat(liveFormRules).Concat(liveMatchRules).ToList();
        if (blocking.Count > 0)
            return new Refusal(
                $"“{def.Label}” is still in use ({string.Join(", ", blocking)}). Remove that requirement first.",
                Conflict: true);

        // Draft gates, draft form versions, and not-yet-live playbook match
        // rules are all safe to cascade — nothing live depends on any of them.
        if (playbookGates.Any(g => g.IsDraft))
            await _store.RemoveCustomGateFromDraftsAsync(def.Key, ct);
        if (formRules.Any(r => !r.IsLive))
            await _store.RemoveConditionFromDraftFormsAsync(def.Key, ct);
        // A draft-only playbook match rule is left as-is rather than cascaded:
        // unlike a stage gate or a form condition (both structured JSON this
        // code already parses and rewrites), a match condition is a single
        // free-standing rule an admin wrote deliberately — silently rewriting
        // it out from under them on an unrelated field's delete would be a
        // surprising edit to someone else's playbook, not a cleanup. It is
        // reported to the admin (via LeadTaxonomyUsageAsync's preview) so they
        // can fix it themselves before ever publishing that playbook — and
        // PUBLISHING it while the condition names an archived field is
        // refused by SetMatchingAsync's own save-time validation regardless.

        await _store.ArchiveAsync(def, ct);
        return null;
    }

    // --- E3.1 value validation (account/contact create & update) ---

    private static readonly Regex EmailPattern = new(@"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.Compiled);
    // Loose on purpose: this is a data-quality check, not a delivery guarantee.
    // Digits plus the punctuation people actually type ("+971 4 123 4567",
    // "(04) 123-4567"), at least 6 digits total so "n/a" or "-" is refused.
    private static readonly Regex PhonePattern = new(@"^[0-9+()\-.\s]{6,}$", RegexOptions.Compiled);

    /// <summary>
    /// Validates a record's proposed `Custom` blob against this org's ACTIVE
    /// definitions for <paramref name="objectType"/> only — an archived field's
    /// `Required` flag can never block a save (same "archived stops appearing
    /// on the form, never stops being readable" rule the lead form already
    /// follows), and a key with no definition at all (an old key from before
    /// this validation existed, or one belonging to a different object type)
    /// passes through unexamined rather than being refused for a rule that was
    /// never told about it.
    ///
    /// E3.2 — a field masked from <paramref name="callerRole"/> by
    /// <see cref="CustomFieldMasking.IsVisibleTo"/> is never required either,
    /// same reasoning as <see cref="Services.LeadFormService.MissingRequired"/>'s
    /// own role-aware skip: a caller cannot be blocked over a value on a field
    /// their form never showed them. <paramref name="callerRole"/> defaults away
    /// so a caller with no role context (there is none today) keeps the old
    /// behaviour of enforcing every active definition's Required flag.
    /// </summary>
    public async Task<Refusal?> ValidateValuesAsync(
        string objectType, System.Text.Json.JsonElement custom, string callerRole = "", CancellationToken ct = default,
        System.Text.Json.JsonElement? existing = null)
    {
        // `existing` is the record's stored blob on an EDIT. A save changes only the keys it sends
        // (CustomFieldMasking.Overlay), so Required is judged on the post-save values: a required
        // field that already holds a value and is not resent passes; it is refused only if it would
        // end up empty. Only the SENT values are type-checked below.
        var postSave = existing is { } stored ? CustomFieldMasking.Overlay(stored, custom) : custom;
        var defs = await _store.ListAsync(includeArchived: false, objectType, ct);
        var byKey = defs.ToDictionary(d => d.Key, StringComparer.OrdinalIgnoreCase);

        // E3.6 — every distinct picklist a "picklist"-type def in this batch
        // references, resolved once. Deliberately ALL of a picklist's values,
        // active AND archived: the whole `Custom` blob is resent on every
        // save (see AccountProcess/ContactProcess), so an already-chosen
        // value must keep validating even after an admin archives it —
        // archiving only removes it from the PICKER going forward, per
        // OrgPicklistValue's own class remarks.
        var picklistValues = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);
        if (_picklists is not null)
        {
            foreach (var key in defs.Where(d => d.Type == "picklist" && d.PicklistKey is not null)
                         .Select(d => d.PicklistKey!).Distinct(StringComparer.OrdinalIgnoreCase))
            {
                var picklist = await _picklists.ByKeyAsync(key, ct);
                picklistValues[key] = picklist is null
                    ? new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    : picklist.Values.Select(v => v.Value).ToHashSet(StringComparer.OrdinalIgnoreCase);
            }
        }

        var hasValue = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (custom.ValueKind == System.Text.Json.JsonValueKind.Object)
        {
            foreach (var prop in custom.EnumerateObject())
            {
                if (!byKey.TryGetValue(prop.Name, out var def)) continue; // unknown key — pass through
                if (IsBlank(prop.Value)) continue; // present-but-empty is "not set", same as absent
                hasValue.Add(prop.Name);
                var error = ValidateValue(def, prop.Value, picklistValues);
                if (error is not null) return new Refusal($"{def.Label}: {error}");
            }
        }
        // Stored values that this save leaves in place also satisfy Required.
        if (existing is not null && postSave.ValueKind == System.Text.Json.JsonValueKind.Object)
            foreach (var prop in postSave.EnumerateObject())
                if (byKey.ContainsKey(prop.Name) && !IsBlank(prop.Value)) hasValue.Add(prop.Name);

        foreach (var def in defs)
        {
            if (!def.Required || hasValue.Contains(def.Key)) continue;
            if (!CustomFieldMasking.IsVisibleTo(def, callerRole)) continue; // E3.2 — never blocked by a field they can't see
            return new Refusal($"{def.Label} is required");
        }
        return null;
    }

    private static bool IsBlank(System.Text.Json.JsonElement v) => v.ValueKind switch
    {
        System.Text.Json.JsonValueKind.Null or System.Text.Json.JsonValueKind.Undefined => true,
        System.Text.Json.JsonValueKind.String => string.IsNullOrWhiteSpace(v.GetString()),
        System.Text.Json.JsonValueKind.Array => v.GetArrayLength() == 0,
        _ => false,
    };

    /// <summary>One field's value against its own definition's type. Returns
    /// null when valid, an error string otherwise.</summary>
    private static string? ValidateValue(
        CustomFieldDef def, System.Text.Json.JsonElement v,
        IReadOnlyDictionary<string, HashSet<string>> picklistValues)
    {
        switch (def.Type)
        {
            case "picklist":
                var picked = v.ValueKind == System.Text.Json.JsonValueKind.String ? v.GetString() : null;
                if (def.PicklistKey is null || !picklistValues.TryGetValue(def.PicklistKey, out var allowed))
                    return "picklist is not configured";
                return picked is not null && allowed.Contains(picked)
                    ? null : "must be one of that picklist's values";
            case "number":
            case "currency":
            case "percentage":
                if (v.ValueKind != System.Text.Json.JsonValueKind.Number &&
                    !(v.ValueKind == System.Text.Json.JsonValueKind.String && double.TryParse(v.GetString(), out _)))
                    return "must be a number";
                return null;
            case "checkbox":
                return v.ValueKind is System.Text.Json.JsonValueKind.True or System.Text.Json.JsonValueKind.False
                    ? null : "must be true or false";
            case "date":
                var dateText = v.ValueKind == System.Text.Json.JsonValueKind.String ? v.GetString() : null;
                return dateText is not null && DateTime.TryParse(dateText, out _) ? null : "must be a valid date";
            case "select":
            case "dropdown":
                var one = v.ValueKind == System.Text.Json.JsonValueKind.String ? v.GetString() : null;
                return one is not null && def.Options.Contains(one, StringComparer.OrdinalIgnoreCase)
                    ? null : $"must be one of: {string.Join(", ", def.Options)}";
            case "multi_select":
                if (v.ValueKind != System.Text.Json.JsonValueKind.Array) return "must be a list of options";
                foreach (var item in v.EnumerateArray())
                {
                    var s = item.ValueKind == System.Text.Json.JsonValueKind.String ? item.GetString() : null;
                    if (s is null || !def.Options.Contains(s, StringComparer.OrdinalIgnoreCase))
                        return $"must be one of: {string.Join(", ", def.Options)}";
                }
                return null;
            case "email":
                var email = v.ValueKind == System.Text.Json.JsonValueKind.String ? v.GetString() : null;
                return email is not null && EmailPattern.IsMatch(email) ? null : "must be a valid email address";
            case "phone":
                var phone = v.ValueKind == System.Text.Json.JsonValueKind.String ? v.GetString() : null;
                return phone is not null && PhonePattern.IsMatch(phone) ? null : "must be a valid phone number";
            case "url":
                var url = v.ValueKind == System.Text.Json.JsonValueKind.String ? v.GetString() : null;
                return url is not null && Uri.TryCreate(url, UriKind.Absolute, out var uri) &&
                       (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps)
                    ? null : "must be a valid http(s) URL";
            case "user":
                // Format-only: this build does not check that the id names a
                // real profile in the org — see ValidTypes remarks.
                var userId = v.ValueKind == System.Text.Json.JsonValueKind.String ? v.GetString() : null;
                return userId is not null && Guid.TryParse(userId, out _) ? null : "must be a user";
            case "text":
            case "long_text":
            default:
                return v.ValueKind == System.Text.Json.JsonValueKind.String ? null : "must be text";
        }
    }
}

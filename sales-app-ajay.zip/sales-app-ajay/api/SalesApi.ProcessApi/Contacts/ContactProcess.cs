using System.Globalization;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Accounts;
using SalesApi.ProcessLayer.CustomFields;
using SalesApi.Services;
using SalesApi.Services.Paging;
using SalesApi.Services.TableQuery;
using SalesApi.SystemLayer.Accounts;
using SalesApi.SystemLayer.Contacts;

namespace SalesApi.ProcessLayer.Contacts;

/// <summary>
/// Editing a contact: the account-scoping rule that used to live inline in
/// <c>ContactsController.LoadOwnedAsync</c>, moved here verbatim.
///
/// A contact carries no owner/team of its own — it belongs to an Account, and
/// access is decided THROUGH that account, using the account's own
/// <see cref="RecordAccess.CanManage"/> predicate. A contact left org-wide
/// would be a way to read (or edit) another team's customer list sideways,
/// which is exactly what routing the check through the account closes.
///
/// Layering round 4 (owner decision 2026-09-30): no longer holds
/// <see cref="AppDbContext"/> — <see cref="DomainEvents.Raise"/> is reached
/// through the injected <see cref="DomainEventWriter"/> instead; no public
/// surface here names a System type.
/// </summary>
public sealed class ContactProcess
{
    private readonly ContactStore _store;
    private readonly CustomFieldProcess _customFields;
    private readonly AccountStore _accounts;
    private readonly PipelineStages _stages;
    private readonly DomainEventWriter _events;
    private readonly SearchCapabilities _search;

    public ContactProcess(
        ContactStore store,
        CustomFieldProcess customFields,
        AccountStore accounts,
        PipelineStages stages,
        DomainEventWriter events,
        // Optional, like TaskProcess: DI always supplies the real one; hand-built test chains that never search or filter by
        // typo-tolerant text do not have to.
        SearchCapabilities? search = null)
    {
        _search = search ?? new SearchCapabilities();
        _store = store;
        _customFields = customFields;
        _accounts = accounts;
        _stages = stages;
        _events = events;
    }

    /// <summary>Active (non-archived) contact-object custom field defs for
    /// this org — see LeadMapping.ActiveDefsAsync's identical remarks on why
    /// one read per call is cheap enough not to cache.</summary>
    private Task<List<CustomFieldDef>> ActiveDefsAsync(CancellationToken ct = default) =>
        _store.ActiveCustomFieldDefsAsync(ct);

    /// <summary>Same defensive parse as LeadMapping.ParseJson/AccountProcess's
    /// own private copy — a malformed/empty blob reads as an empty object.</summary>
    private static JsonElement ParseCustom(string? json)
    {
        try { return JsonSerializer.Deserialize<JsonElement>(string.IsNullOrEmpty(json) ? "{}" : json); }
        catch { return JsonSerializer.Deserialize<JsonElement>("{}"); }
    }

    /// <summary>Why a request could not be carried out, or null when it can.
    /// A RESULT, not an exception — same shape as <c>AmcProcess.Refusal</c> —
    /// because "not found" and "not allowed" are ordinary answers here, not
    /// server errors.</summary>
    public sealed record Refusal(string Reason, bool NotFound = false, bool Forbidden = false, string? Code = null, IReadOnlyList<string>? Fields = null, string? Field = null);

    // ---- the all-contacts table (GET /contacts, /contacts/columns, /contacts/count, /contacts/export) ----------------
    // Mirrors the accounts list: the same one-table contract (ContactColumnRegistry is its column set), the same cursor, fuzzy search
    // and refusals. Visibility is the contact's ACCOUNT's (TeamScopedQueries.WhereViewable over contacts).

    public sealed record ListParams(
        string? Search, int? Limit, int? Offset, double? Similarity, bool Paged, string? Cursor,
        string? Filters = null, string? Sorts = null);

    public sealed record ListOutcome(Refusal? Refusal, List<ContactListItemDto>? Items, string? NextCursor)
    {
        public static ListOutcome Refused(Refusal r) => new(r, null, null);
        public static ListOutcome Ok(List<ContactListItemDto> items, string? cursor) => new(null, items, cursor);
    }

    /// <summary>The columns this caller may use, and the same list for a caller who may use all of them (so a hidden column is
    /// refused by name rather than reported as unknown).</summary>
    private async Task<(List<TableColumn<Contact>> Visible, List<TableColumn<Contact>> Everything)> ColumnSetsAsync(
        RecordAccessContext ctx, bool canViewContactDetails, string callerRole, ContactColumnOptionSources? options, CancellationToken ct)
    {
        var defs = await ActiveDefsAsync(ct);
        return (
            ContactColumnRegistry.Build(defs, callerRole, ctx.Sensitive, canViewContactDetails, options),
            ContactColumnRegistry.Build(defs, "admin", null, true));
    }

    /// <summary>The checked filters and sorts, plus the order the rows come in: the request's sorts, else name A-Z (the id tiebreak
    /// is added by the keyset). The list, its cursor and the export all read this one order.</summary>
    private async Task<(ResolvedTableQuery<Contact> Tq, IReadOnlyList<TableSortKey<Contact>> Order)> ResolveTableAsync(
        RecordAccessContext ctx, bool canViewContactDetails, string callerRole, string? filters, string? sorts, double? similarity, CancellationToken ct)
    {
        var (visible, everything) = await ColumnSetsAsync(ctx, canViewContactDetails, callerRole, null, ct);
        var tq = await TableQuerySpecs.ResolveAsync(visible, everything, filters, sorts,
            async () => new FilterContext(await _accounts.CalendarAsync(), DateTime.UtcNow, _search.TrgmEnabled,
                _search.LevenshteinEnabled, similarity is > 0 and <= 1 ? similarity.Value : FuzzySearch.DefaultSimilarityThreshold));
        IReadOnlyList<TableSortKey<Contact>> order = tq.Sorts
            ?? new List<TableSortKey<Contact>> { new(visible.First(c => c.Key == "name"), false) };
        return (tq, order);
    }

    /// <summary>GET /contacts/columns - the catalogue for this caller.</summary>
    public async Task<TableColumnsDto> ColumnsAsync(
        RecordAccessContext ctx, bool canViewContactDetails, string callerRole = "", CancellationToken ct = default)
    {
        var options = new ContactColumnOptionSources(await _accounts.TeamOptionsAsync(ctx), await _accounts.PersonOptionsAsync(ctx));
        var (visible, _) = await ColumnSetsAsync(ctx, canViewContactDetails, callerRole, options, ct);
        return TableQuerySpecs.Catalogue(visible);
    }

    public async Task<ListOutcome> ListAsync(
        RecordAccessContext ctx, bool canViewContactDetails, ListParams p, string callerRole = "", CancellationToken ct = default)
    {
        try
        {
            return await ListCoreAsync(ctx, canViewContactDetails, p, callerRole, ct);
        }
        catch (TableQueryRefusedException e)
        {
            return ListOutcome.Refused(new Refusal(e.Message, Code: "invalid_query", Field: e.Field));
        }
    }

    private async Task<ListOutcome> ListCoreAsync(
        RecordAccessContext ctx, bool canViewContactDetails, ListParams p, string callerRole, CancellationToken ct)
    {
        var defs = await ActiveDefsAsync(ct);
        var searchEmail = ContactColumnRegistry.ContactDetailsUsableRaw(canViewContactDetails, ctx.Sensitive);
        var f = _store.BuildFilteredQuery(ctx, _search, p.Search, p.Similarity, searchEmail);
        var (tq, order) = await ResolveTableAsync(ctx, canViewContactDetails, callerRole, p.Filters, p.Sorts, p.Similarity, ct);
        var q = tq.Filter(f.Query);
        // A typo-tolerant column filter needs the pg_trgm scoping even when the search box is empty.
        var needsTrgm = f.FuzzyActive || tq.Fuzzy;
        var needsShortTrgm = f.ShortFuzzyActive || tq.ShortFuzzy;
        var trgmThreshold = f.FuzzyActive ? f.Threshold : (p.Similarity is > 0 and <= 1 ? p.Similarity.Value : f.Threshold);

        // A fuzzy search keeps its relevance ranking first; the table's order is the tiebreak (like the accounts list).
        var ordered = f.FuzzyActive
            ? TableMultiKeyset<Contact>.ApplyOrder(ContactStore.OrderByRelevance(q, f), order, alreadyOrdered: true)
            : TableMultiKeyset<Contact>.ApplyOrder(q, order);

        ContactListItemDto Item(Contact c) => ToListItem(c, defs, callerRole, ctx.Sensitive, canViewContactDetails);

        if (!p.Paged)
        {
            var legacy = ordered.AsQueryable();
            if (p.Offset is int off && off > 0) legacy = legacy.Skip(off);
            if (p.Limit is int lim && lim > 0) legacy = legacy.Take(lim);
            var rows = await _store.RunAsync(needsTrgm, needsShortTrgm, trgmThreshold, () => legacy.ToListAsync(ct));
            return ListOutcome.Ok(rows.Select(Item).ToList(), null);
        }

        var pageSize = p.Limit is int l2 && l2 > 0 ? l2 : 20;
        var fingerprint = CursorToken.Fingerprint(
            p.Search, p.Similarity?.ToString(CultureInfo.InvariantCulture), f.FuzzyActive.ToString(), tq.CanonicalFilters, tq.CanonicalSorts);
        var decoded = CursorToken.Decode(p.Cursor);
        if (decoded != null && decoded.Filters != fingerprint)
            return ListOutcome.Refused(new Refusal(
                "The filters changed since this page was fetched. Reload the list from the start.", Code: "stale_cursor"));

        List<Contact> pageRows;
        string? nextCursor = null;
        if (f.FuzzyActive)
        {
            // Relevance is not a stored column, so a search pages by offset (the accounts list's limitation, for the same reason).
            var startOffset = decoded is { Mode: "offset" } ? decoded.Offset ?? 0 : 0;
            var fetched = await _store.RunAsync(needsTrgm, needsShortTrgm, trgmThreshold,
                () => ordered.Skip(startOffset).Take(pageSize + 1).ToListAsync(ct));
            pageRows = fetched.Take(pageSize).ToList();
            nextCursor = fetched.Count > pageSize
                ? CursorToken.Encode(new CursorPayload("offset", fingerprint, "sorts", null, startOffset + pageSize))
                : null;
        }
        else
        {
            var scoped = decoded is { Mode: "keyset", Key: not null }
                ? TableMultiKeyset<Contact>.ApplyCursor(ordered, order, decoded.Key)
                : (IQueryable<Contact>)ordered;
            var fetched = tq.Fuzzy
                ? await _store.RunAsync(needsTrgm, needsShortTrgm, trgmThreshold, () => scoped.Take(pageSize + 1).ToListAsync(ct))
                : await scoped.Take(pageSize + 1).ToListAsync(ct);
            pageRows = fetched.Take(pageSize).ToList();
            if (fetched.Count > pageSize)
                nextCursor = CursorToken.Encode(new CursorPayload(
                    "keyset", fingerprint, "sorts", TableMultiKeyset<Contact>.KeyOf(pageRows[^1], order), null));
        }
        return ListOutcome.Ok(pageRows.Select(Item).ToList(), nextCursor);
    }

    /// <summary>GET /contacts/count - the total rows for the identical search and filters the list uses, so a count can never
    /// disagree with the list it describes. A refused filter throws <see cref="TableQueryRefusedException"/> (the controller's 400).</summary>
    public async Task<int> CountAsync(
        RecordAccessContext ctx, bool canViewContactDetails, string? search, double? similarity, string? filters,
        string callerRole = "", CancellationToken ct = default)
    {
        var f = _store.BuildFilteredQuery(
            ctx, _search, search, similarity, ContactColumnRegistry.ContactDetailsUsableRaw(canViewContactDetails, ctx.Sensitive));
        var (tq, _) = await ResolveTableAsync(ctx, canViewContactDetails, callerRole, filters, null, similarity, ct);
        var q = tq.Filter(f.Query);
        var threshold = f.FuzzyActive ? f.Threshold : (similarity is > 0 and <= 1 ? similarity.Value : f.Threshold);
        return await _store.RunAsync(f.FuzzyActive || tq.Fuzzy, f.ShortFuzzyActive || tq.ShortFuzzy, threshold, () => q.CountAsync(ct));
    }

    // ---- E21: the audience of an email campaign -----------------------------------------------------------------------------

    /// <summary>What a campaign needs of a contact: who to address, the wording to merge and the language to pick a template by. <c>Company</c> is the contact's own
    /// company, else its account's name. <c>EmailOptedOutAt</c> is the contact's own opt-out (the send guard also reads a shared address).</summary>
    public sealed record AudienceContact(Guid Id, string Name, string? Company, string? Email, string? PreferredLanguage, DateTime? EmailOptedOutAt);

    /// <summary>The contacts list's own inputs, replayed: the saved view's search box, similarity and column filters (the one-table JSON), plus an optional buying role on a deal and an optional buying role of the contact itself (both set = both must match).</summary>
    public sealed record AudienceParams(string? Search, double? Similarity, string? Filters, string? BuyingRole, string? OwnBuyingRole = null);

    public sealed record AudienceOutcome(Refusal? Refusal, List<AudienceContact>? Contacts)
    {
        public static AudienceOutcome Refused(Refusal r) => new(r, null);
        public static AudienceOutcome Ok(List<AudienceContact> c) => new(null, c);
    }

    /// <summary>
    /// EVERY contact the caller may view that the list would show for these inputs (no paging), name order. This is the contacts list's own query - the same
    /// visibility (<c>ViewableWithAccount</c>), search box and column filters as <see cref="ListAsync"/> - with the buying-role narrowing on top, so an email
    /// campaign can never reach a contact the person scheduling it could not have listed. A refused filter is a Refusal (code invalid_query), not an exception.
    /// </summary>
    public async Task<AudienceOutcome> AudienceAsync(
        RecordAccessContext ctx, bool canViewContactDetails, string callerRole, AudienceParams p, CancellationToken ct = default)
    {
        try
        {
            var f = _store.BuildFilteredQuery(
                ctx, _search, p.Search, p.Similarity, ContactColumnRegistry.ContactDetailsUsableRaw(canViewContactDetails, ctx.Sensitive));
            var (tq, _) = await ResolveTableAsync(ctx, canViewContactDetails, callerRole, p.Filters, null, p.Similarity, ct);
            var q = tq.Filter(f.Query);
            if (!string.IsNullOrWhiteSpace(p.BuyingRole)) q = await _store.WhereBuyingRoleAsync(q, p.BuyingRole);
            if (!string.IsNullOrWhiteSpace(p.OwnBuyingRole)) q = await _store.WhereOwnBuyingRoleAsync(q, p.OwnBuyingRole);
            var threshold = f.FuzzyActive ? f.Threshold : (p.Similarity is > 0 and <= 1 ? p.Similarity.Value : f.Threshold);
            var rows = await _store.RunAsync(f.FuzzyActive || tq.Fuzzy, f.ShortFuzzyActive || tq.ShortFuzzy, threshold, () =>
                q.OrderBy(c => c.Name).ThenBy(c => c.Id)
                    .Select(c => new AudienceContact(
                        c.Id, c.Name, c.Company ?? (c.Account != null ? c.Account.Name : null), c.Email, c.PreferredLanguage, c.EmailOptedOutAt))
                    .ToListAsync(ct));
            return AudienceOutcome.Ok(rows);
        }
        catch (TableQueryRefusedException e)
        {
            return AudienceOutcome.Refused(new Refusal(e.Message, Code: "invalid_query", Field: e.Field));
        }
    }

    /// <summary>One row of the table: the masked values are exactly what <see cref="ToDto"/> gives this caller for the same contact
    /// (email / phone also blank without <c>contact_details.view</c>, matching the columns that are then absent).</summary>
    private static ContactListItemDto ToListItem(
        Contact c, List<CustomFieldDef> defs, string callerRole, SensitiveAccess? sensitive, bool canViewContactDetails)
    {
        var dto = ToDto(c, defs, callerRole, null, sensitive);
        return new ContactListItemDto(
            c.Id, c.AccountId, c.Account?.Name, c.Name, c.Title, c.Company,
            canViewContactDetails ? dto.Email : null, canViewContactDetails ? dto.Phone : null, dto.PhoneCountryCode,
            dto.PreferredLanguage, dto.OptedOut,
            c.Account?.OwnerId, c.Account?.Owner?.FullName, c.Account?.TeamId, c.Account?.Team?.Name,
            dto.Custom, dto.FieldAccess, c.CreatedAt, c.UpdatedAt);
    }

    /// <summary>The export file's columns, in order. Public so a test can assert the contract directly (like <c>AccountProcess.CsvColumns</c>).</summary>
    public static readonly string[] CsvColumns =
    {
        "name", "account", "title", "company", "email", "phone", "preferred_language",
        "opted_out_email", "opted_out_sms", "opted_out_whatsapp", "account_owner", "account_team", "created_at",
    };

    /// <summary>GET /contacts/export - the rows the filtered, sorted table shows (everything the caller may view with neither), as CSV.
    /// Email and phone are written exactly as the list shows them to this caller (masked or blank).</summary>
    public async Task<string> ExportCsvAsync(
        RecordAccessContext ctx, bool canViewContactDetails, string? filters = null, string? sorts = null,
        string callerRole = "", IReadOnlyCollection<Guid>? ids = null, CancellationToken ct = default)
    {
        var defs = await ActiveDefsAsync(ct);
        var (tq, order) = await ResolveTableAsync(ctx, canViewContactDetails, callerRole, filters, sorts, null, ct);
        var contacts = await _store.ExportRowsAsync(ctx, tq.Predicate, src => TableMultiKeyset<Contact>.ApplyOrder(src, order),
            tq.Fuzzy, tq.ShortFuzzy, ids: ids);

        static string? Day(Dictionary<string, DateTime>? optedOut, string channel) =>
            optedOut is not null && optedOut.TryGetValue(channel, out var at) ? at.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : null;

        var rows = new List<IEnumerable<string?>> { CsvColumns };
        foreach (var c in contacts)
        {
            var item = ToListItem(c, defs, callerRole, ctx.Sensitive, canViewContactDetails);
            rows.Add(new string?[]
            {
                item.Name, item.AccountName, item.Title, item.Company, item.Email, item.Phone, item.PreferredLanguage,
                Day(item.OptedOut, ConsentChannels.Email), Day(item.OptedOut, ConsentChannels.Sms), Day(item.OptedOut, ConsentChannels.WhatsApp),
                item.OwnerName, item.TeamName, item.CreatedAt.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
            });
        }
        return CsvUtil.ToCsv(rows);
    }

    public sealed record ContactOutcome(Refusal? Refusal, ContactDto? Contact)
    {
        public static ContactOutcome Refused(Refusal r) => new(r, null);
        public static ContactOutcome Ok(ContactDto c) => new(null, c);
    }

    public sealed record DeleteOutcome(Refusal? Refusal)
    {
        public static DeleteOutcome Refused(Refusal r) => new(r);
        public static readonly DeleteOutcome Ok = new((Refusal?)null);
    }

    public sealed record ContactDetailOutcome(Refusal? Refusal, ContactDetailDto? Detail)
    {
        public static ContactDetailOutcome Refused(Refusal r) => new(r, null);
        public static ContactDetailOutcome Ok(ContactDetailDto d) => new(null, d);
    }

    /// <summary>
    /// E3.11d — GET /contacts/{id}. A read, so <see cref="RecordAccess.CanView"/>
    /// through the owning account — same account-routed visibility every other
    /// contact read in this class uses (<see cref="DealsAsync"/>,
    /// <see cref="LoadOwnedAsync"/>'s own CanManage for edits). Custom-field
    /// masking is <see cref="ToDto"/>'s existing <c>CustomFieldMasking.Apply</c>
    /// call, unchanged; contact-detail masking itself (email/phone/name) is the
    /// class-level <c>ViewContactDetails</c> permission every action on
    /// <c>ContactsController</c> already requires — there is no partial view of
    /// a contact today, only "may see this contact" or not.
    ///
    /// OUT-OF-SCOPE READS COME BACK 404, not 403 — a deliberate departure from
    /// <see cref="LoadOwnedAsync"/>'s own Forbidden, mirroring
    /// <c>LeadsController</c>'s <c>GET /leads/{id}/history</c> precedent (see
    /// that endpoint's own comment): a caller who cannot see the contact gets
    /// the SAME 404 as a contact that does not exist, never a 403 that would
    /// confirm the id is real.
    /// </summary>
    public async Task<ContactDetailOutcome> GetAsync(
        RecordAccessContext ctx, Guid id, string callerRole = "", CancellationToken ct = default)
    {
        var contact = await _store.LoadWithAccountAsync(id, ct);
        if (contact is null) return ContactDetailOutcome.Refused(new Refusal("Contact not found", NotFound: true));
        if (!RecordAccess.CanView(ctx, contact.Account!.OwnerId, contact.Account.TeamId))
            return ContactDetailOutcome.Refused(new Refusal("Contact not found", NotFound: true));

        var contactDefs = await ActiveDefsAsync(ct);
        string? reportsToName = contact.ReportsToContactId is { } rid
            ? (await _store.LiteAsync(rid, ct))?.Name : null;
        return ContactDetailOutcome.Ok(new ContactDetailDto(
            ToDto(contact, contactDefs, callerRole, reportsToName, ctx.Sensitive), contact.AccountId, contact.Account.Name));
    }

    /// <summary>E3.1b (item 5) — masks Custom exactly like AccountProcess's own
    /// ContactToDto (<paramref name="callerRole"/> defaults to "" — fail-closed,
    /// same reasoning as that mapper's doc comment). This class used to build
    /// a ContactDto with NO Custom at all, silently dropping every contact
    /// custom field from the one write path that could ever set one
    /// (AccountProcess.AddContactAsync creates them; this is the only
    /// updater) — fixed as part of building the missing write support below,
    /// not a second bug.</summary>
    private static ContactDto ToDto(
        Contact c, List<CustomFieldDef>? defs = null, string callerRole = "", string? reportsToName = null,
        // E12.2 - same mapping as AccountProcess.ContactToDto; the assigned scope is judged on the contact's ACCOUNT.
        SensitiveAccess? sensitive = null)
    {
        sensitive = sensitive?.ForRecord("contact", c.Id); // E12.5: an approved reveal for THIS contact
        var fa = new Dictionary<string, string>(StringComparer.Ordinal);
        var ownerId = c.Account?.OwnerId;
        var teamId = c.Account?.TeamId;
        var cd = (sensitive ?? SensitiveAccess.Unrestricted).LevelFor(SensitiveCategories.ContactDetails, ownerId, teamId);
        return new(c.Id, c.AccountId, c.Name, c.Title,
            CustomFieldMasking.Text("email", c.Email, cd, CustomFieldMasking.Kind.Email, fa),
            CustomFieldMasking.Text("phone", c.Phone, cd, CustomFieldMasking.Kind.Phone, fa), c.Notes, c.CreatedAt,
            CustomFieldMasking.Text("phone_country_code", c.PhoneCountryCode, cd, CustomFieldMasking.Kind.Text, fa),
            CustomFieldMasking.Apply(ParseCustom(c.Custom), defs ?? new(), callerRole, sensitive, ownerId, teamId, fa),
            c.ReportsToContactId, reportsToName, fa.Count == 0 ? null : fa, sensitive?.RevealExpiries, c.PreferredLanguage, c.OptedOutChannels(), c.BuyingRoles.ToList());
    }

    private async Task<(Contact? Contact, Refusal? Refusal)> LoadOwnedAsync(
        RecordAccessContext ctx, Guid id, CancellationToken ct)
    {
        var contact = await _store.LoadWithAccountAsync(id, ct);
        if (contact is null) return (null, new Refusal("Contact not found", NotFound: true));
        // Through the account, using the account's own predicate: contacts left
        // org-wide would be a way to read another team's customer list sideways.
        if (!RecordAccess.CanManage(ctx, contact.Account!.OwnerId, contact.Account.TeamId))
            return (null, new Refusal("Not allowed to edit this contact", Forbidden: true));
        return (contact, null);
    }

    // Same rule Lead's create/update path enforces (see
    // ContactFieldFormat) — email is optional, only a non-empty value that
    // cannot be an address is refused; phone is refused only when it has
    // taken on the spreadsheet-float shape ("9.7153E+11").

    /// <summary>
    /// Whether an incoming value is actually a CHANGE to what is stored. An
    /// UNCHANGED value is never re-validated.
    ///
    /// This matters far more than it looks. The production audit found 685 leads
    /// whose phone had already been mangled into a spreadsheet float and 63 with
    /// an unusable email — all of them predating these guards. Validating on
    /// every update would have made each of those leads UNEDITABLE: the edit
    /// form resubmits the fields it loaded, so someone moving a lead to Won
    /// would be refused over a phone number they never touched and whose digits
    /// are unrecoverable anyway. A guard is meant to stop bad data ARRIVING, not
    /// to hold a record hostage over data that is already there.
    /// </summary>
    private static bool Changed(string? incoming, string? stored) =>
        incoming is not null && !string.Equals(incoming.Trim(), (stored ?? string.Empty).Trim(), StringComparison.Ordinal);

    private static Refusal? ValidateContactShape(string? email, string? phone, string? language = null)
    {
        if (!string.IsNullOrWhiteSpace(language) && !MessageMergeFields.IsLanguageCode(language))
            return new Refusal("preferred_language must be a language code such as en or ar");
        if (!string.IsNullOrEmpty(email) && !ContactFieldFormat.IsValidEmailFormat(email))
            return new Refusal("email is not a valid address");
        if (!string.IsNullOrEmpty(phone) && ContactFieldFormat.LooksLikeSpreadsheetFloat(phone))
            return new Refusal(
                "phone looks like a spreadsheet number (e.g. 9.7153E+11), not a phone number — re-enter the digits");
        return null;
    }

    public async Task<ContactOutcome> UpdateAsync(
        RecordAccessContext ctx, Guid id, ContactInput input, string callerRole = "", CancellationToken ct = default)
    {
        var (contact, refusal) = await LoadOwnedAsync(ctx, id, ct);
        if (refusal is not null) return ContactOutcome.Refused(refusal);

        // Only what this edit actually CHANGES is judged — see Changed().
        var shapeRefusal = ValidateContactShape(
            Changed(input.Email, contact!.Email) ? input.Email : null,
            Changed(input.Phone, contact!.Phone) ? input.Phone : null,
            input.PreferredLanguage);
        if (shapeRefusal is not null) return ContactOutcome.Refused(shapeRefusal);

        // Buying roles: every key must be on the org picklist; stored with the picklist's own spelling, de-duplicated.
        List<string>? newBuyingRoles = null;
        if (input.BuyingRoles is not null)
        {
            newBuyingRoles = SalesApi.SystemLayer.Stakeholders.StakeholderRoles.Canonicalise(input.BuyingRoles, await _store.BuyingRolesAsync(), out var unknownRole);
            if (unknownRole is not null) return ContactOutcome.Refused(new Refusal($"'{unknownRole}' is not a configured buying role."));
        }

        // E12.2 - judged against the level for the ACCOUNT this contact sits on.
        if (AccountProcess.SensitiveContactWriteRefusal(ctx.Sensitive, input, contact, contact!.Account?.OwnerId, contact.Account?.TeamId,
                await ActiveDefsAsync(ct)) is { } sensitiveRefusal)
            return ContactOutcome.Refused(new Refusal(sensitiveRefusal.Reason, Code: SensitiveWriteGuard.Code, Fields: sensitiveRefusal.Fields));

        // E3.1b — same validation AccountProcess.AddContactAsync already runs
        // against a NEW contact's Custom, now also enforced on an edit.
        if (input.Custom is { } newCustom)
        {
            var validationRefusal = await _customFields.ValidateValuesAsync(CustomFieldDef.ObjectTypes.Contact, newCustom, callerRole, ct, existing: ParseCustom(contact!.Custom));
            if (validationRefusal is not null) return ContactOutcome.Refused(new Refusal(validationRefusal.Reason));
        }

        // E1 step 4 (to-do/e1-event-backbone-design.md §4) — "changed_fields[]":
        // only fields this request set AND that actually differ, same style as
        // AccountProcess.UpdateAsync's own ContactUpdated-shaped sibling.
        var changedFields = new List<string>();
        void NoteIfChanged(string field, string? incoming, string? stored)
        {
            if (incoming != null && incoming != stored) changedFields.Add(field);
        }
        NoteIfChanged("name", input.Name?.Trim(), contact!.Name);
        NoteIfChanged("title", input.Title, contact!.Title);
        NoteIfChanged("email", input.Email, contact!.Email);
        NoteIfChanged("phone", input.Phone, contact!.Phone);
        NoteIfChanged("phone_country_code", input.PhoneCountryCode, contact!.PhoneCountryCode);
        NoteIfChanged("notes", input.Notes, contact!.Notes);

        if (input.Name != null) contact!.Name = input.Name.Trim();
        if (input.Title != null) contact!.Title = input.Title;
        if (input.Email != null) contact!.Email = input.Email;
        if (input.Phone != null) contact!.Phone = input.Phone;
        if (input.PhoneCountryCode != null) contact!.PhoneCountryCode = input.PhoneCountryCode;
        if (input.Notes != null) contact!.Notes = input.Notes;
        // E16.3 - "" clears the language back to English; anything else is stored as the bare language code.
        if (input.PreferredLanguage != null)
            contact!.PreferredLanguage = string.IsNullOrWhiteSpace(input.PreferredLanguage) ? null : MessageMergeFields.NormalizeLanguage(input.PreferredLanguage);
        // The contact's roles are read LIVE by every open deal that inherits them (StakeholderRoles); a closed deal holds its own snapshot.
        if (newBuyingRoles is not null && !newBuyingRoles.SequenceEqual(contact!.BuyingRoles, StringComparer.Ordinal))
        {
            changedFields.Add("buying_roles");
            contact.BuyingRoles = newBuyingRoles;
        }
        if (input.Custom is { } custom)
        {
            // E3.1b (item 4/5) — a caller who cannot SEE a masked contact
            // field must not be able to blank it out by PATCHing a blob that
            // omits it or echoes the "Hidden" placeholder back; see
            // CustomFieldMasking.PreserveHidden's own remarks.
            var contactDefsForWrite = await ActiveDefsAsync(ct);
            var merged = CustomFieldMasking.PreserveHidden(custom, ParseCustom(contact!.Custom), contactDefsForWrite, callerRole);
            contact!.Custom = merged.GetRawText();
        }
        contact!.UpdatedAt = DateTime.UtcNow;
        if (changedFields.Count > 0)
            _events.Raise(DomainEventTypes.Keys.ContactUpdated, DomainEventTypes.AggregateTypes.Contact, contact.Id, ctx.UserId,
                new DomainEventPayloads.ContactUpdated(contact.Id, [.. changedFields]));
        await _store.SaveChangesAsync(ct);
        var contactDefs = await ActiveDefsAsync(ct);
        return ContactOutcome.Ok(ToDto(contact, contactDefs, callerRole, null, ctx.Sensitive));
    }

    public sealed record DealsOutcome(Refusal? Refusal, List<ContactDealDto>? Deals)
    {
        public static DealsOutcome Refused(Refusal r) => new(r, null);
        public static DealsOutcome Ok(List<ContactDealDto> d) => new(null, d);
    }

    /// <summary>
    /// E3.11 / E3.11e — GET /contacts/{id}/deals: every lead this contact is
    /// linked to via `lead_contacts` — as the lead's primary contact OR as any
    /// other buying-committee stakeholder (E3.3) — newest first, open and
    /// closed alike, each carrying that link's Role/IsPrimary. A read, so
    /// CanView — not the CanManage <see cref="LoadOwnedAsync"/> uses for edits
    /// — same account-routed visibility every other contact read in this class
    /// uses; UNCHANGED from before E3.11e — access is still decided once,
    /// through the CONTACT's own account, not per-lead (a stakeholder's
    /// contact is always on the lead's own account or resolved through it —
    /// see StakeholderProcess.ResolveContactAsync — so every lead this query
    /// returns is already within that same boundary).
    /// </summary>
    public async Task<DealsOutcome> DealsAsync(
        RecordAccessContext ctx, Guid id, bool canSeeValues, CancellationToken ct = default)
    {
        var contact = await _store.LoadWithAccountAsync(id, ct);
        if (contact is null) return DealsOutcome.Refused(new Refusal("Contact not found", NotFound: true));
        if (!RecordAccess.CanView(ctx, contact.Account!.OwnerId, contact.Account.TeamId))
            return DealsOutcome.Refused(new Refusal("Not allowed to view this contact", Forbidden: true));

        var rows = await _store.DealsForContactAsync(id, ct);
        var labelsByPlaybook = new Dictionary<Guid, Dictionary<string, string>>();
        var result = new List<ContactDealDto>();
        foreach (var row in rows)
        {
            var l = row.Lead;
            var key = l.PlaybookId ?? Guid.Empty;
            if (!labelsByPlaybook.TryGetValue(key, out var labels))
                labelsByPlaybook[key] = labels = await _stages.LabelsAsync(l.PlaybookId);
            result.Add(new ContactDealDto(
                l.Id, l.Name, labels.GetValueOrDefault(l.Status, l.Status), l.DealType,
                canSeeValues ? l.EstimatedValue : null, l.CreatedAt, l.WonAt, l.LostAt,
                row.Roles.FirstOrDefault(), row.IsPrimary, l.Company, row.Roles));
        }
        return DealsOutcome.Ok(result);
    }

    public async Task<DeleteOutcome> DeleteAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default)
    {
        var (contact, refusal) = await LoadOwnedAsync(ctx, id, ct);
        if (refusal is not null) return DeleteOutcome.Refused(refusal);

        _store.Remove(contact!);
        await _store.SaveChangesAsync(ct);
        return DeleteOutcome.Ok;
    }

    // =====================================================================
    // E3.4 — "reports to" (an org-chart edge between two contacts).
    // =====================================================================

    /// <summary>
    /// Decision this story made (brief left it open): the target contact must
    /// belong to the SAME account as the source, or to an account inside that
    /// account's own hierarchy TREE (ancestors and descendants alike, bounded
    /// by <c>AccountProcess.MaxHierarchyDepth</c>) — not just the one account.
    /// A regional buyer reporting to a group-level economic buyer at the
    /// parent company is exactly the E3.4 parent/subsidiary feature is for;
    /// restricting reports-to to one account row would make that the one
    /// stakeholder relationship the feature cannot record. Structural only —
    /// no RecordAccess filtering — because this asks "is this an organisational
    /// possibility", not "may the caller see it" (that is CanView on the
    /// target's own account, checked separately below).
    /// </summary>
    private async Task<bool> IsInSameAccountFamilyAsync(Guid sourceAccountId, Guid targetAccountId, CancellationToken ct)
    {
        if (sourceAccountId == targetAccountId) return true;
        var ancestors = await _accounts.AncestorIdsAsync(sourceAccountId, AccountProcess.MaxHierarchyDepth, ct);
        if (ancestors.Contains(targetAccountId)) return true;
        var descendants = await _accounts.DescendantIdsAsync(sourceAccountId, AccountProcess.MaxHierarchyDepth, ct);
        return descendants.Contains(targetAccountId);
    }

    /// <summary>PUT /contacts/{id}/reports-to. Null clears it. Loop refusal
    /// mirrors AccountProcess.SetParentAsync's own — walk the chain from the
    /// PROPOSED target and refuse if it ever reaches the contact being
    /// edited, bounded the same way.</summary>
    public async Task<ContactOutcome> SetReportsToAsync(
        RecordAccessContext ctx, Guid id, Guid? reportsToContactId, string callerRole = "", CancellationToken ct = default)
    {
        var (contact, refusal) = await LoadOwnedAsync(ctx, id, ct);
        if (refusal is not null) return ContactOutcome.Refused(refusal);

        if (reportsToContactId == id)
            return ContactOutcome.Refused(new Refusal("A contact cannot report to themselves"));

        string? targetName = null;
        if (reportsToContactId is { } targetId)
        {
            var target = await _store.LiteAsync(targetId, ct);
            if (target is null) return ContactOutcome.Refused(new Refusal("Contact not found", NotFound: true));

            if (!await IsInSameAccountFamilyAsync(contact!.AccountId, target.AccountId, ct))
                return ContactOutcome.Refused(new Refusal(
                    "reports_to must be a contact at the same account or within its account hierarchy"));

            // The caller must be able to at least SEE the target's account —
            // same bar AccountProcess.AddRelationshipAsync applies to a
            // cross-account reference.
            var targetAccount = await _accounts.FindForAccessAsync(target.AccountId, ct);
            if (targetAccount is null || !RecordAccess.CanView(ctx, targetAccount.Value.OwnerId, targetAccount.Value.TeamId))
                return ContactOutcome.Refused(new Refusal("Not allowed to link to that contact", Forbidden: true));

            // Loop refusal: walking UP from the proposed target must never
            // reach the contact being edited.
            var visited = new HashSet<Guid>();
            var currentId = targetId;
            for (var i = 0; i < AccountProcess.MaxHierarchyDepth; i++)
            {
                if (currentId == id)
                    return ContactOutcome.Refused(new Refusal("This would create a circular reporting chain", Forbidden: false));
                var current = await _store.LiteAsync(currentId, ct);
                if (current?.ReportsToContactId is not { } nextId || !visited.Add(nextId)) break;
                currentId = nextId;
            }
            targetName = target.Name;
        }

        contact!.ReportsToContactId = reportsToContactId;
        contact.UpdatedAt = DateTime.UtcNow;
        _events.Raise(DomainEventTypes.Keys.ContactUpdated, DomainEventTypes.AggregateTypes.Contact, contact.Id, ctx.UserId,
            new DomainEventPayloads.ContactUpdated(contact.Id, ["reports_to_contact_id"]));
        await _store.SaveChangesAsync(ct);

        var contactDefs = await ActiveDefsAsync(ct);
        return ContactOutcome.Ok(ToDto(contact, contactDefs, callerRole, targetName, ctx.Sensitive));
    }
}

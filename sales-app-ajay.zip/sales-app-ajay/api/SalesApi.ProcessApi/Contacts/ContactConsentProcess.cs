using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.Contacts;

namespace SalesApi.ProcessLayer.Contacts;

/// <summary>
/// E16.1 - staff opt a contact out of, or back into, one channel (email, sms, whatsapp), and read the append-only consent log.
///
/// Access is the contact's own rule, decided through its ACCOUNT exactly like <see cref="ContactProcess"/>: reading the log needs
/// <see cref="RecordAccess.CanView"/>, changing it <see cref="RecordAccess.CanManage"/>. The refusals are <see cref="ContactProcess.Refusal"/>
/// so the controller maps them with the one mapper it already has. The system sources of an opt-out (a WhatsApp STOP, later an unsubscribe
/// link) write through <see cref="ContactConsentStore"/> directly - they have no signed-in caller to check.
///
/// Only an explicit opt-in clears an opt-out; opting out twice keeps the first date and writes no second log line.
/// </summary>
public sealed class ContactConsentProcess
{
    private readonly ContactStore _contacts;
    private readonly ContactConsentStore _consent;
    private readonly DomainEventWriter _events;

    public ContactConsentProcess(ContactStore contacts, ContactConsentStore consent, DomainEventWriter events)
    {
        _contacts = contacts;
        _consent = consent;
        _events = events;
    }

    public sealed record StateOutcome(ContactProcess.Refusal? Refusal, ContactOptOutStateDto? State)
    {
        public static StateOutcome Refused(ContactProcess.Refusal r) => new(r, null);
        public static StateOutcome Ok(ContactOptOutStateDto s) => new(null, s);
    }

    public sealed record HistoryOutcome(ContactProcess.Refusal? Refusal, List<ContactConsentEntryDto>? Entries)
    {
        public static HistoryOutcome Refused(ContactProcess.Refusal r) => new(r, null);
        public static HistoryOutcome Ok(List<ContactConsentEntryDto> e) => new(null, e);
    }

    private static ContactProcess.Refusal? BadChannel(string? channel) =>
        ContactConsentStore.IsChannel(channel)
            ? null
            : new ContactProcess.Refusal("channel must be one of: " + string.Join(", ", ConsentChannels.All));

    /// <summary>POST /contacts/{id}/opt-out - source "staff".</summary>
    public Task<StateOutcome> OptOutAsync(RecordAccessContext ctx, Guid id, ContactOptOutInput input, CancellationToken ct = default) =>
        ChangeAsync(ctx, id, input, optOut: true, ct);

    /// <summary>POST /contacts/{id}/opt-in - the explicit opt-in, source "staff", the only thing that clears an opt-out.</summary>
    public Task<StateOutcome> OptInAsync(RecordAccessContext ctx, Guid id, ContactOptOutInput input, CancellationToken ct = default) =>
        ChangeAsync(ctx, id, input, optOut: false, ct);

    private async Task<StateOutcome> ChangeAsync(RecordAccessContext ctx, Guid id, ContactOptOutInput input, bool optOut, CancellationToken ct)
    {
        if (BadChannel(input.Channel) is { } bad) return StateOutcome.Refused(bad);
        var contact = await _contacts.LoadWithAccountAsync(id, ct);
        if (contact is null) return StateOutcome.Refused(new ContactProcess.Refusal("Contact not found", NotFound: true));
        if (!RecordAccess.CanManage(ctx, contact.Account!.OwnerId, contact.Account.TeamId))
            return StateOutcome.Refused(new ContactProcess.Refusal("Not allowed to edit this contact", Forbidden: true));

        var channel = input.Channel!;
        var changed = optOut
            ? _consent.StageOptOut(contact, channel, ConsentSources.Staff, input.Reason, ctx.UserId, DateTime.UtcNow)
            : _consent.StageOptIn(contact, channel, ConsentSources.Staff, input.Reason, ctx.UserId, DateTime.UtcNow);
        if (changed)
        {
            contact.UpdatedAt = DateTime.UtcNow;
            _events.Raise(DomainEventTypes.Keys.ContactUpdated, DomainEventTypes.AggregateTypes.Contact, contact.Id, ctx.UserId,
                new DomainEventPayloads.ContactUpdated(contact.Id, [$"opted_out_{channel}"]));
            await _contacts.SaveChangesAsync(ct);
        }
        return StateOutcome.Ok(new ContactOptOutStateDto(contact.OptedOutChannels() ?? new()));
    }

    /// <summary>GET /contacts/{id}/consent-history - newest first. Out-of-scope reads come back 404, like <see cref="ContactProcess.GetAsync"/>.</summary>
    public async Task<HistoryOutcome> HistoryAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default)
    {
        var contact = await _contacts.LoadWithAccountAsync(id, ct);
        if (contact is null || !RecordAccess.CanView(ctx, contact.Account!.OwnerId, contact.Account.TeamId))
            return HistoryOutcome.Refused(new ContactProcess.Refusal("Contact not found", NotFound: true));
        var rows = await _consent.HistoryAsync(id, ct);
        return HistoryOutcome.Ok([.. rows.Select(e => new ContactConsentEntryDto(
            e.Id, e.Channel, e.Action, e.Source, e.Reason, e.Address, e.ActorId, e.OccurredAt))]);
    }
}

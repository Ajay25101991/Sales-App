using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Sandbox;
using SalesApi.Services;
using SalesApi.SystemLayer.ChangeRequests;

namespace SalesApi.ProcessLayer.ChangeRequests;

/// <summary>
/// The state machine behind E7.4 change requests (design doc
/// to-do/e7-config-platform-design.md §5.4/§5.5, §10 owner answer 4):
/// requested → built_in_sandbox → customer_approved → promoted | rejected,
/// every transition enforced HERE, never trusted from client input (the
/// story brief's "state machine enforced server-side").
///
/// Promote reuses <see cref="SandboxProcess.PromoteAsync"/> UNCHANGED — this
/// class only ever replays the item selection it saved at the
/// built_in_sandbox transition, the same request body an ordinary sandbox
/// promote already validates end to end (unresolved conflicts, unacknowledged
/// removals, a fresh re-export of the sandbox). No parallel promote path.
/// </summary>
public sealed class ChangeRequestProcess
{
    private readonly ChangeRequestStore _store;
    private readonly SandboxProcess _sandbox;

    public ChangeRequestProcess(ChangeRequestStore store, SandboxProcess sandbox)
    {
        _store = store;
        _sandbox = sandbox;
    }

    /// <summary>Story brief: "expiring (named constant)". A minted approval
    /// link is usable for this many days from the moment it is (re)issued —
    /// resolved once at mint time into <see cref="ChangeRequest.ApprovalTokenExpiresAt"/>,
    /// an absolute instant, same "not recomputed later" rule
    /// <c>InviteTokenService.IssueAsync</c> documents for its own lifetime.</summary>
    public const int ApprovalTokenLifetimeDays = 14;

    public sealed record Refusal(
        string Reason, bool NotFound = false, bool Conflict = false,
        List<string>? ConflictingStableKeys = null, Guid? ConflictingChangeRequestId = null,
        string? ConflictingChangeRequestTitle = null, List<string>? UnacknowledgedStableKeys = null)
    {
        public ChangeRequestRefusalDto ToDto() => new(
            Reason, NotFound, Conflict, ConflictingStableKeys,
            ConflictingChangeRequestId, ConflictingChangeRequestTitle, UnacknowledgedStableKeys);
    }

    // --- Mapping -------------------------------------------------------------

    private static List<ChangeRequestItemSelectionDto> ParseItems(string json) =>
        JsonSerializer.Deserialize<List<ChangeRequestItemSelectionDto>>(json) ?? new();

    private static List<ChangeRequestRemovalSelectionDto> ParseRemovals(string json) =>
        JsonSerializer.Deserialize<List<ChangeRequestRemovalSelectionDto>>(json) ?? new();

    private static ChangeRequestDto ToDto(ChangeRequest c) => new(
        c.Id, c.Title, c.Description, c.Status, c.RequestedById, c.CreatedAt,
        ParseItems(c.LinkedItemsJson), ParseRemovals(c.LinkedRemovalsJson),
        c.PackageApplyRecordId, c.BuiltInSandboxAt,
        c.CustomerApprovedAt, c.CustomerApprovedById,
        c.RejectedAt, c.RejectedById,
        c.PromotedAt, c.PromotedById,
        HasOpenApprovalLink: c.ApprovalTokenHash is not null
            && c.ApprovalTokenConsumedAt is null
            && c.ApprovalTokenExpiresAt is DateTime exp && exp > DateTime.UtcNow);

    /// <summary>Every (kind, stable key) this request touches — linked items
    /// AND linked removals both count as "touching" that key (§5.4/§10 owner
    /// answer 4's conflict rule doesn't distinguish create/update from
    /// remove: two requests can't both claim the same item either way).</summary>
    private static HashSet<(string Kind, string StableKey)> TouchedKeys(ChangeRequest c) =>
        ParseItems(c.LinkedItemsJson).Select(i => (i.Kind, i.StableKey))
            .Concat(ParseRemovals(c.LinkedRemovalsJson).Select(r => (r.Kind, r.StableKey)))
            .ToHashSet();

    // --- List / detail / comments ---------------------------------------------

    public async Task<List<ChangeRequestDto>> ListAsync(CancellationToken ct = default) =>
        (await _store.ListAsync(ct)).Select(ToDto).ToList();

    public async Task<(Refusal? Refusal, ChangeRequestDetailDto? Dto)> DetailAsync(Guid id, CancellationToken ct = default)
    {
        var cr = await _store.FindAsync(id, ct);
        if (cr is null) return (new Refusal("Change request not found.", NotFound: true), null);
        var comments = await _store.CommentsAsync(id, ct);
        return (null, new ChangeRequestDetailDto(ToDto(cr), comments.Select(ToCommentDto).ToList()));
    }

    private static ChangeRequestCommentDto ToCommentDto(ChangeRequestComment c) => new(c.Id, c.AuthorId, c.Body, c.CreatedAt);

    public async Task<ChangeRequestDto> CreateAsync(Guid orgId, Guid actorId, string title, string description, CancellationToken ct = default)
    {
        var cr = new ChangeRequest
        {
            OrgId = orgId,
            Title = title.Trim(),
            Description = description?.Trim() ?? "",
            Status = ChangeRequestStatus.Requested,
            RequestedById = actorId,
        };
        _store.Add(cr);
        await _store.SaveAsync(ct);
        return ToDto(cr);
    }

    public async Task<(Refusal? Refusal, ChangeRequestCommentDto? Dto)> CommentAsync(
        Guid id, Guid actorId, string body, CancellationToken ct = default)
    {
        var cr = await _store.FindAsync(id, ct);
        if (cr is null) return (new Refusal("Change request not found.", NotFound: true), null);
        if (string.IsNullOrWhiteSpace(body)) return (new Refusal("A comment needs some text."), null);

        var comment = new ChangeRequestComment
        {
            OrgId = cr.OrgId,
            ChangeRequestId = cr.Id,
            AuthorId = actorId,
            Body = body.Trim(),
        };
        _store.AddComment(comment);
        await _store.SaveAsync(ct);
        return (null, ToCommentDto(comment));
    }

    // --- Requested → BuiltInSandbox (link items, §5.4) -------------------------

    /// <summary>Sets/replaces the item selection this request covers and
    /// (re)mints the customer approval link. Valid from Requested (first
    /// link) or BuiltInSandbox (an implementation user iterating before the
    /// customer looks) — never once the customer has already decided, so a
    /// re-link can't silently change what an approval or rejection was about.</summary>
    public async Task<(Refusal? Refusal, ChangeRequestDto? Dto, string? RawApprovalToken)> LinkItemsAsync(
        Guid id, List<ChangeRequestItemSelectionDto> items, List<ChangeRequestRemovalSelectionDto> removals, CancellationToken ct = default)
    {
        var cr = await _store.FindAsync(id, ct);
        if (cr is null) return (new Refusal("Change request not found.", NotFound: true), null, null);
        if (cr.Status is not (ChangeRequestStatus.Requested or ChangeRequestStatus.BuiltInSandbox))
            return (new Refusal($"Cannot link items while the request is '{cr.Status}'."), null, null);
        if (items.Count == 0 && removals.Count == 0)
            return (new Refusal("Link at least one item or removal."), null, null);

        var newKeys = items.Select(i => (i.Kind, i.StableKey)).Concat(removals.Select(r => (r.Kind, r.StableKey))).ToHashSet();
        var conflict = await FindConflictAsync(id, newKeys, ct);
        if (conflict is not null) return (conflict, null, null);

        cr.LinkedItemsJson = JsonSerializer.Serialize(items);
        cr.LinkedRemovalsJson = JsonSerializer.Serialize(removals);
        cr.BuiltInSandboxAt ??= DateTime.UtcNow;
        cr.Status = ChangeRequestStatus.BuiltInSandbox;

        // Re-issue the approval link every time the covered items change —
        // an outstanding link for the PRIOR selection must not go on to
        // approve a different set of changes (mirrors InviteTokenService's
        // "re-inviting must never leave a second working link in
        // circulation", one link at a time here too).
        var raw = InviteTokenService.GenerateRawToken();
        cr.ApprovalTokenHash = InviteTokenService.HashToken(raw);
        cr.ApprovalTokenExpiresAt = DateTime.UtcNow.AddDays(ApprovalTokenLifetimeDays);
        cr.ApprovalTokenConsumedAt = null;

        await _store.SaveAsync(ct);
        return (null, ToDto(cr), raw);
    }

    /// <summary>§5.4/§10 owner answer 4: "two requests touching the same
    /// item → the second must resolve." Scans every OTHER request currently
    /// built-in-sandbox or customer-approved (i.e. not yet promoted/rejected)
    /// for an overlapping (kind, stable key) — whichever call reaches here
    /// SECOND with the overlap is the one refused.</summary>
    private async Task<Refusal?> FindConflictAsync(Guid excludeId, HashSet<(string Kind, string StableKey)> keys, CancellationToken ct)
    {
        foreach (var other in await _store.OtherActiveAsync(excludeId, ct))
        {
            var overlap = TouchedKeys(other).Where(keys.Contains).Select(k => k.StableKey).ToList();
            if (overlap.Count > 0)
                return new Refusal(
                    $"'{other.Title}' already covers {overlap.Count} of these item(s) and hasn't been promoted or rejected yet.",
                    Conflict: true, ConflictingStableKeys: overlap,
                    ConflictingChangeRequestId: other.Id, ConflictingChangeRequestTitle: other.Title);
        }
        return null;
    }

    // --- BuiltInSandbox → CustomerApproved | Rejected (§5.5) --------------------

    /// <summary>The authenticated path — a customer org admin (or, for now,
    /// any caller with ManageSettings in this org; see
    /// ChangeRequestsController's own comment on the StudioAssignment seam)
    /// deciding from inside the app rather than the emailed link.</summary>
    public async Task<(Refusal? Refusal, ChangeRequestDto? Dto)> DecideAsync(
        Guid id, Guid actorId, bool approve, CancellationToken ct = default)
    {
        var cr = await _store.FindAsync(id, ct);
        if (cr is null) return (new Refusal("Change request not found.", NotFound: true), null);
        var refusal = ApplyDecision(cr, approve, actorId);
        if (refusal is not null) return (refusal, null);
        await _store.SaveAsync(ct);
        return (null, ToDto(cr));
    }

    /// <summary>Shared by the authenticated path above and the public token
    /// path below, so the two can never disagree about which states allow a
    /// decision.
    ///
    /// Owner answer 2026-09-29: APPROVING still only makes sense from
    /// BuiltInSandbox — that is the transition the mock's own 4-step progress
    /// bar names (Built in sandbox → Customer approved), and there is nothing
    /// to approve before an implementation user has linked what was actually
    /// built. REJECTING is allowed from ANY state before Promoted — including
    /// Requested (the customer never wants this) and CustomerApproved
    /// (WITHDRAWING an approval before it ships; §0.1's own "reaches live
    /// only by promoting a package" means an approval alone never committed
    /// anything, so taking it back before promote is not undoing a write, it
    /// is simply not doing one). Once Promoted or already Rejected, neither
    /// decision is allowed — the request is settled.
    ///
    /// Burns the approval link on either outcome, from whichever state —
    /// an authenticated decision (including a withdrawal after approval)
    /// closes the emailed link's door too, so a stale link can't later flip
    /// an outcome the authenticated path already settled (§5.5's
    /// "single-use"). <see cref="ChangeRequest.CustomerApprovedAt"/>/
    /// <see cref="ChangeRequest.CustomerApprovedById"/> are left in place on a
    /// withdrawal rather than cleared — they are the historical record that
    /// an approval happened and was later withdrawn, which
    /// <see cref="ChangeRequest.RejectedAt"/>/<see cref="ChangeRequest.RejectedById"/>
    /// sitting alongside them already show without erasing anything.</summary>
    private static Refusal? ApplyDecision(ChangeRequest cr, bool approve, Guid? actorId)
    {
        if (approve)
        {
            if (cr.Status != ChangeRequestStatus.BuiltInSandbox)
                return new Refusal($"This request is '{cr.Status}' and cannot be approved right now.");
        }
        else
        {
            if (cr.Status is ChangeRequestStatus.Promoted)
                return new Refusal("This request has already been promoted and can no longer be rejected.");
            if (cr.Status is ChangeRequestStatus.Rejected)
                return new Refusal("This request has already been rejected.");
        }

        cr.ApprovalTokenConsumedAt ??= DateTime.UtcNow;
        if (approve)
        {
            cr.Status = ChangeRequestStatus.CustomerApproved;
            cr.CustomerApprovedAt = DateTime.UtcNow;
            cr.CustomerApprovedById = actorId;
        }
        else
        {
            cr.Status = ChangeRequestStatus.Rejected;
            cr.RejectedAt = DateTime.UtcNow;
            cr.RejectedById = actorId;
        }
        return null;
    }

    // --- Public token path (§5.5, mirrors QuoteProcess) -------------------------

    public enum PublicViewOutcome { NotFound, Viewable }
    public sealed record PublicView(PublicViewOutcome Outcome, PublicChangeRequestDto? ChangeRequest);

    private static PublicChangeRequestDto ToPublicDto(ChangeRequest c) =>
        new(c.Title, c.Description, c.Status, ParseItems(c.LinkedItemsJson), ParseRemovals(c.LinkedRemovalsJson));

    /// <summary>GET /change-requests/approve/{token}. An expired or already-
    /// consumed token is INDISTINGUISHABLE from one that never existed
    /// (story brief: "same not-found shape as an invalid quote token, no
    /// information leak") — all three collapse to <see cref="PublicViewOutcome.NotFound"/>
    /// here, never a differently-worded refusal that would tell a guesser
    /// which case they hit.</summary>
    public async Task<PublicView> ViewByTokenAsync(string? rawToken, CancellationToken ct = default)
    {
        var cr = await FindLiveByTokenAsync(rawToken, ct);
        return cr is null
            ? new PublicView(PublicViewOutcome.NotFound, null)
            : new PublicView(PublicViewOutcome.Viewable, ToPublicDto(cr));
    }

    public enum PublicDecisionOutcome { NotFound, Refused, Decided }
    public sealed record PublicDecisionResult(PublicDecisionOutcome Outcome, PublicChangeRequestDto? ChangeRequest, string? RefusalReason);

    /// <summary>POST /change-requests/approve/{token}. Re-validates the same
    /// state check <see cref="DecideAsync"/> makes — a POST can arrive from a
    /// stale tab or a replayed request without the GET page ever having been
    /// re-rendered, so the write path checks independently (same discipline
    /// as <c>QuoteProcess.AcceptAsync</c>'s own comment on this).</summary>
    public async Task<PublicDecisionResult> DecideByTokenAsync(string? rawToken, bool approve, CancellationToken ct = default)
    {
        var cr = await FindLiveByTokenAsync(rawToken, ct);
        if (cr is null) return new PublicDecisionResult(PublicDecisionOutcome.NotFound, null, null);

        _store.ScopeToChangeRequestOrg(cr);
        var refusal = ApplyDecision(cr, approve, actorId: null); // no signed-in caller on the public link
        if (refusal is not null) return new PublicDecisionResult(PublicDecisionOutcome.Refused, ToPublicDto(cr), refusal.Reason);

        await _store.SaveAsync(ct);
        return new PublicDecisionResult(PublicDecisionOutcome.Decided, ToPublicDto(cr), null);
    }

    private async Task<ChangeRequest?> FindLiveByTokenAsync(string? rawToken, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(rawToken)) return null;
        var hash = InviteTokenService.HashToken(rawToken);
        var cr = await _store.FindByTokenHashAsync(hash, ct);
        if (cr is null) return null;
        if (cr.ApprovalTokenConsumedAt is not null) return null; // single-use — already burned
        if (cr.ApprovalTokenExpiresAt is not DateTime exp || exp <= DateTime.UtcNow) return null;
        return cr;
    }

    // --- CustomerApproved → Promoted (§4.4/§5.4, per change request) -----------

    /// <summary>Replays exactly this request's saved item selection through
    /// <see cref="SandboxProcess.PromoteAsync"/> — the same server-enforced
    /// checks (unresolved conflicts, unacknowledged removals, a fresh
    /// re-export of the sandbox) any promote already makes, never
    /// re-implemented here. Re-checks the cross-request conflict rule too,
    /// in case another request claimed an overlapping item after this one
    /// linked its own (§10 owner answer 4).</summary>
    public async Task<(Refusal? Refusal, PackageApplyResultDto? Result)> PromoteAsync(
        Guid orgId, Guid actorId, Guid id, CancellationToken ct = default)
    {
        var cr = await _store.FindAsync(id, ct);
        if (cr is null) return (new Refusal("Change request not found.", NotFound: true), null);
        if (cr.Status != ChangeRequestStatus.CustomerApproved)
            return (new Refusal($"Cannot promote while the request is '{cr.Status}' — it needs customer approval first."), null);

        var items = ParseItems(cr.LinkedItemsJson);
        var removals = ParseRemovals(cr.LinkedRemovalsJson);
        var keys = items.Select(i => (i.Kind, i.StableKey)).Concat(removals.Select(r => (r.Kind, r.StableKey))).ToHashSet();
        var conflict = await FindConflictAsync(id, keys, ct);
        if (conflict is not null) return (conflict, null);

        var request = new SandboxPromoteRequestDto(
            items.Select(i => new SandboxPromoteItemSelectionDto(i.Kind, i.StableKey, i.Resolution)).ToList(),
            removals.Select(r => new SandboxPromoteRemovalSelectionDto(r.Kind, r.StableKey, r.Acknowledged)).ToList());

        var (result, sandboxRefusal) = await _sandbox.PromoteAsync(orgId, actorId, request, ct);
        if (sandboxRefusal is not null)
            return (new Refusal(sandboxRefusal.Reason, sandboxRefusal.NotFound,
                UnacknowledgedStableKeys: sandboxRefusal.UnresolvedStableKeys), null);

        cr.Status = ChangeRequestStatus.Promoted;
        cr.PromotedAt = DateTime.UtcNow;
        cr.PromotedById = actorId;
        cr.PackageApplyRecordId = result!.ApplyRecordId;
        await _store.SaveAsync(ct);
        return (null, result);
    }
}

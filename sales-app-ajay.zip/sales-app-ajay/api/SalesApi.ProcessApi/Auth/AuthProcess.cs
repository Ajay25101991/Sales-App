using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.Auth;

namespace SalesApi.ProcessLayer.Auth;

/// <summary>
/// Sign-up / sign-in / refresh / sign-out / activity / password-change / invite
/// redemption — the whole authentication surface, moved down from
/// <c>AuthController</c> verbatim. THE SECURITY SURFACE: every rule below is
/// the original controller code, reordered not at all, with the ONE change
/// every migrated domain makes — an authorization/identity FACT that used to
/// come from <c>User</c> (a <c>ClaimsPrincipal</c>) now arrives as a plain
/// value the controller already had to read to authenticate the request in
/// the first place. There is exactly one such fact on this whole surface:
/// <see cref="RecordActivityAsync"/>'s <c>userId</c>, taken from
/// <c>User.UserId()</c> at the controller (the token IS the identity fact
/// here — nothing to additionally resolve).
///
/// Nothing here takes or returns a <see cref="Profile"/>, an
/// <see cref="SalesApi.Models.Organization"/>, or a
/// <c>ResolvedOrganizationRole</c> in a PUBLIC signature — those are System
/// types (SalesApi.Tests/LayerBoundaryTests.cs). Every method holds them only
/// as local variables while it orchestrates <see cref="AuthStore"/> calls, and
/// returns <see cref="AuthResponse"/> (a contract, already exactly what the
/// wire sends) or a <see cref="Refusal"/>.
/// </summary>
public sealed class AuthProcess
{
    private readonly AuthStore _store;
    public AuthProcess(AuthStore store) => _store = store;

    /// <summary>Why a request could not proceed, plus the HTTP status the
    /// controller should answer with — unlike GoalProcess.Refusal (always 400
    /// or 404), auth's failure modes span 400/401/403/409, so the status rides
    /// along explicitly rather than being re-derived from the reason string.
    /// <paramref name="EmptyBody"/> preserves two original bare
    /// <c>Unauthorized()</c> responses (no <c>{ error }</c> payload) —
    /// <c>RecordActivity</c>/<c>ChangePassword</c>'s "the token is valid but
    /// the profile it names is gone" case — rather than silently adding a body
    /// where the wire never had one.</summary>
    public sealed record Refusal(string Reason, int StatusCode, bool EmptyBody = false);

    // Public/free email providers that must not be claimed as an organization
    // domain. Moved verbatim from AuthController.
    private static readonly HashSet<string> FreeEmailDomains = new(StringComparer.OrdinalIgnoreCase)
    {
        "gmail.com", "googlemail.com", "yahoo.com", "yahoo.co.uk", "yahoo.co.in",
        "hotmail.com", "hotmail.co.uk", "outlook.com", "live.com", "msn.com",
        "icloud.com", "me.com", "mac.com", "aol.com", "proton.me", "protonmail.com",
        "pm.me", "gmx.com", "gmx.net", "mail.com", "zoho.com", "yandex.com",
        "hey.com", "fastmail.com", "rediffmail.com",
    };

    /// <summary>
    /// Builds the sign-in/sign-up/refresh response — the ONE place that decides
    /// access-token lifetime, moved verbatim from <c>AuthController.BuildAuthResponse</c>.
    /// A refresh-capable client gets a short access token AND a refresh token;
    /// a client that did not say so gets today's 30-day token and nothing else.
    /// Does not save — the caller batches the issued refresh-token row with its
    /// own writes, exactly as before.
    /// </summary>
    private AuthResponse BuildAuthResponse(Profile profile, ResolvedOrganizationRole? role, bool supportsRefresh)
    {
        if (!supportsRefresh)
            return new AuthResponse(_store.AccessToken(profile, role, supportsRefresh: false), _store.ToProfileDto(profile, role));

        var refreshToken = _store.IssueRefreshToken(profile);
        return new AuthResponse(
            _store.AccessToken(profile, role, supportsRefresh: true),
            _store.ToProfileDto(profile, role),
            refreshToken);
    }

    public async Task<(Refusal? Refusal, AuthResponse? Response)> SignupAsync(SignupRequest req, CancellationToken ct = default)
    {
        var email = req.Email?.Trim().ToLowerInvariant();
        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(req.Password))
            return (new Refusal("email and password are required", 400), null);
        if (req.Password.Length < 6)
            return (new Refusal("password must be at least 6 characters", 400), null);

        var domain = email.Contains('@') ? email.Split('@')[^1] : "";
        if (string.IsNullOrEmpty(domain) || !domain.Contains('.'))
            return (new Refusal("A valid work email is required", 400), null);

        if (await _store.EmailTakenAsync(email, ct))
            return (new Refusal("An account with that email already exists", 409), null);

        // If an org already owns this email domain, join it. Otherwise the user
        // can create a new org for their domain and becomes its manager. Trust
        // model: they must sign up with an email on that domain.
        var org = await _store.OrgByDomainAsync(domain, ct);
        var role = "rep";
        if (org is null)
        {
            // Public/free email domains can't be claimed as an org (they'd let
            // unrelated people share a tenant).
            if (FreeEmailDomains.Contains(domain))
                return (new Refusal("Use your company email domain to create an organization — public email providers aren't allowed.", 400), null);
            // The domain must be pre-approved by an app admin (suntech-admin)
            // before its first user can register a new organization.
            var allowed = await _store.AllowedDomainAsync(domain, ct);
            if (allowed is null)
                return (new Refusal("Your organization isn't approved for registration yet. Please contact the administrator.", 403), null);
            // Use the admin's preset org name if they set one, else what the user entered.
            var orgName = !string.IsNullOrWhiteSpace(allowed.OrgName) ? allowed.OrgName!.Trim() : req.OrgName?.Trim();
            if (string.IsNullOrEmpty(orgName))
                return (new Refusal("Enter an organization name to finish creating your organization.", 403), null);
            org = _store.AddOrganization(orgName, domain);
            role = "manager"; // the first user of a new org owns/manages it
        }
        else
        {
            if (await _store.ActiveUserCapacityRefusalAsync(org.Id, ct) is { } full)
                return (new Refusal(full, 403), null);

            // ORG ALREADY EXISTS. Two shapes now:
            //
            // (a) LEGACY / self-registered org — DesignatedAdminEmail is null:
            // every seeded org, every org created by the old "first registrant
            // becomes its manager" flow this replaces, and Suntech Global. A new
            // joiner just joins as "rep", exactly as before.
            //
            // (b) EXPLICITLY-PROVISIONED org (AdminController.CreateOrganization)
            // — DesignatedAdminEmail is set by a platform admin at creation,
            // before anyone has registered. THE BOOTSTRAP DEADLOCK: the org
            // cannot have a registered admin before its first admin registers,
            // so "block signup until the org has an admin" can't apply
            // unconditionally. The resolution: the designated email is the one
            // exception — while the org has no admin, ONLY that exact address
            // may register, and its registration is what makes it one.
            //
            // This is a BOOTSTRAP gate, not a live one: it keys off whether the
            // org has EVER been bootstrapped (AdminBootstrappedAt), not whether
            // it currently has an active admin, so it cannot fire again for an
            // org it has already let through — including if that admin is later
            // deactivated or deleted. See AuthController's pre-migration comment
            // (git history) for the full incident this replaced.
            if (org.DesignatedAdminEmail is not null && org.AdminBootstrappedAt is null)
            {
                if (!string.Equals(email, org.DesignatedAdminEmail, StringComparison.OrdinalIgnoreCase))
                    return (new Refusal("This organization is awaiting its designated administrator to register first. Ask them to sign up, then try again.", 403), null);
                role = "admin";
                _store.MarkOrgBootstrapped(org);
            }
        }

        var passwordHash = AuthStore.HashPassword(req.Password);
        var profile = _store.AddProfile(email, passwordHash, string.IsNullOrWhiteSpace(req.FullName) ? email : req.FullName, role, org);
        await _store.SaveChangesAsync(ct);
        // Registration no longer auto-joins a "default" team (numbers-audit-decisions.md
        // #18, stage 3) — see AuthController's original comment (git history) for
        // the full reasoning; nothing about that behaviour changed here.

        var resolvedRole = await _store.ResolveRoleAsync(profile, ct);
        var response = BuildAuthResponse(profile, resolvedRole, req.SupportsRefresh == true);
        await _store.SaveChangesAsync(ct); // persists the refresh-token row, if one was issued
        return (null, response);
    }

    public async Task<(Refusal? Refusal, AuthResponse? Response)> SigninAsync(SigninRequest req, CancellationToken ct = default)
    {
        var email = req.Email?.Trim().ToLowerInvariant();
        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(req.Password))
            return (new Refusal("email and password are required", 400), null);

        var profile = await _store.ProfileByEmailWithOrgAsync(email, ct);
        if (profile is null || !AuthStore.VerifyPassword(req.Password, profile.PasswordHash))
            return (new Refusal("Invalid email or password", 401), null);
        if (!profile.IsActive)
            return (new Refusal("Your account has been deactivated. Contact your manager.", 403), null);

        // E7.7 (brief Part S item 4) — under org policy "microsoft_only",
        // password sign-in is refused for everyone EXCEPT an org admin: org
        // admins keep the password fallback so a broken SSO setup can never
        // lock every admin out of their own org. Checked AFTER the password/
        // active checks above so a wrong password still reports "Invalid
        // email or password" first (this gate is about WHICH credential is
        // allowed, not a reason to short-circuit the ordinary checks that
        // already ran).
        var ssoPolicy = await _store.GetSsoPasswordPolicyAsync(profile.OrgId, ct);
        if (ssoPolicy == SalesApi.Models.SsoPasswordPolicy.MicrosoftOnly && profile.Role is not ("admin" or "suntech-admin"))
            return (new Refusal("Password sign-in is turned off for your organization — sign in with Microsoft instead. Contact your admin if you need help.", 403), null);

        // Password authentication is the first activity for this new session.
        await _store.RecordAuthenticationAsync(profile, req.Platform, ct, method: "password");

        var resolvedRole = await _store.ResolveRoleAsync(profile, ct);
        var response = BuildAuthResponse(profile, resolvedRole, req.SupportsRefresh == true);
        await _store.SaveChangesAsync(ct); // persists the refresh-token row, if one was issued
        return (null, response);
    }

    // --- Session handoff (control panel to CRM, owner 2026-11-17) ---

    public const string HandoffExpiredMessage = "This link has expired. Switch in again from the control panel.";

    /// <summary>
    /// POST /auth/handoff. The CALLER's authority (suntech-admin) is checked at the
    /// controller; here the two tokens are checked against each other: the access token
    /// must be one we issued and still valid, and the refresh token must be a LIVE
    /// session of that same user. The refresh token is only read, never rotated or
    /// stored, so the control panel's own session is untouched and nothing replayable
    /// is parked. Returns the one-time code and when it lapses.
    /// </summary>
    public async Task<(Refusal? Refusal, HandoffCodeResponse? Response)> CreateHandoffAsync(
        HandoffRequest req, CancellationToken ct = default)
    {
        var facts = _store.ReadValidToken(req.AccessToken);
        if (facts is null)
            return (new Refusal("That session is not valid.", 400), null);
        // A studio / sandbox session (the control panel's switch-in) has no refresh token of its own, so one is optional; when one IS sent it
        // must be a live session of the same user.
        if (!string.IsNullOrWhiteSpace(req.RefreshToken))
        {
            var owner = await _store.LiveRefreshOwnerAsync(req.RefreshToken);
            if (owner is null || owner != facts.UserId)
                return (new Refusal("That session is not valid.", 400), null);
        }

        var (code, expiresAt) = _store.MintHandoff(req.AccessToken!, facts.UserId);
        return (null, new HandoffCodeResponse(code, expiresAt.ToString("o")));
    }

    /// <summary>
    /// POST /auth/handoff/redeem. Consumes the code and answers with the same
    /// <see cref="AuthResponse"/> sign-in does: the handed-over access token (it carries
    /// the studio scoping, which a refresh would drop) plus a refresh token from a NEW
    /// session family, so the control panel's own session is not rotated or shared.
    /// Records a sign-in event (method "handoff"). Every failure is one refusal.
    /// <see cref="HandoffRedeemed"/> also names the acting org / studio kind the token
    /// carries so the Experience layer can show the acting org's profile.
    /// </summary>
    public async Task<(Refusal? Refusal, HandoffRedeemed? Result)> RedeemHandoffAsync(
        string? code, CancellationToken ct = default)
    {
        var expired = new Refusal(HandoffExpiredMessage, 400);
        var entry = _store.RedeemHandoff(code);
        if (entry is null) return (expired, null);

        // The token may have lapsed in the minute it sat here (a 15-minute studio token
        // handed over at minute 14.5), so verify it again rather than trust the parking.
        var facts = _store.ReadValidToken(entry.AccessToken);
        var profile = await _store.ProfileByIdWithOrgAsync(entry.UserId, ct);
        if (facts is null || facts.UserId != entry.UserId || profile is null || !profile.IsActive)
            return (expired, null);

        await _store.RecordAuthenticationAsync(profile, null, ct, method: "handoff");
        var role = await _store.ResolveRoleAsync(profile, ct);
        var response = new AuthResponse(entry.AccessToken, _store.ToProfileDto(profile, role), _store.IssueRefreshToken(profile));
        await _store.SaveChangesAsync(ct); // persists the refresh-token row and the sign-in event
        Console.WriteLine("[auth] session handoff redeemed");
        return (null, new HandoffRedeemed(response, facts.OrgId, facts.StudioKind));
    }

    /// <summary>
    /// Exchanges a refresh token for a fresh access token and a fresh refresh
    /// token. Every failure returns null — the controller answers the same flat
    /// 401 for all of them, deliberately (see AuthController.Refresh's doc
    /// comment): distinguishing "unknown", "expired" and "reused" in the
    /// response would tell an attacker holding a stolen token which of those
    /// happened, and when their theft had been noticed.
    /// </summary>
    public async Task<AuthResponse?> RefreshAsync(string? rawToken, CancellationToken ct = default)
    {
        var result = await _store.RotateRefreshAsync(rawToken ?? "", ct);
        if (result.Outcome != RefreshOutcome.Rotated || result.Profile is null || result.RawToken is null)
            return null;

        var role = await _store.ResolveRoleAsync(result.Profile, ct);
        // Rotation already issued and saved the successor, so this response
        // carries it rather than minting another.
        return new AuthResponse(
            _store.AccessToken(result.Profile, role, supportsRefresh: true),
            _store.ToProfileDto(result.Profile, role),
            result.RawToken);
    }

    /// <summary>
    /// Ends a session server-side. With a refresh token, exactly that session's
    /// family is revoked; without one, every session for the caller is revoked
    /// — the fail-closed choice for a client too old to name its session. The
    /// controller always answers 204 regardless of the outcome here, so this
    /// cannot be used to probe whether a token string exists.
    /// </summary>
    public async Task SignOutAsync(Guid userId, string? refreshToken, CancellationToken ct = default)
    {
        if (!string.IsNullOrWhiteSpace(refreshToken))
            await _store.RevokeSessionAsync(refreshToken!, userId, ct);
        else
            await _store.RevokeAllForUserAsync(userId, RefreshRevocationReasons.SignedOut, ct);
    }

    /// <summary>Biometric authentication happens locally against a stored,
    /// valid session; once it succeeds, the client reports it here so it
    /// updates the same latest-activity timestamp/history password sign-in
    /// does. <paramref name="userId"/> is the one identity fact this whole
    /// surface takes as data — <c>User.UserId()</c> at the controller, the
    /// token's own claim, nothing left to additionally resolve.</summary>
    public async Task<Refusal?> RecordActivityAsync(Guid userId, string? platform, CancellationToken ct = default)
    {
        var profile = await _store.ProfileByIdAsync(userId, ct);
        if (profile is null) return new Refusal("Unauthorized", 401, EmptyBody: true);
        if (!profile.IsActive)
            return new Refusal("Your account has been deactivated. Contact your manager.", 403);

        await _store.RecordAuthenticationAsync(profile, platform, ct, method: "biometric");
        return null;
    }

    /// <summary>
    /// The signed-in user changes their own password. Every session is
    /// revoked — the caller's included — because a changed password is how
    /// someone reacts to "I think my account is compromised", and singling the
    /// caller's session out would let a stolen session that happens to be the
    /// one changing the password survive. The caller is then immediately
    /// re-issued a session (when they asked for refresh support) so the logout
    /// this would otherwise cause does not land silently, up to a token
    /// lifetime later, on some unrelated screen.
    /// </summary>
    public async Task<(Refusal? Refusal, AuthResponse? Response, bool NoContent)> ChangePasswordAsync(
        Guid userId, ChangePasswordRequest req, CancellationToken ct = default)
    {
        if (string.IsNullOrEmpty(req.NewPassword) || req.NewPassword.Length < 6)
            return (new Refusal("New password must be at least 6 characters", 400), null, false);
        var profile = await _store.ProfileByIdAsync(userId, ct);
        if (profile is null) return (new Refusal("Unauthorized", 401, EmptyBody: true), null, false);
        if (!AuthStore.VerifyPassword(req.CurrentPassword ?? "", profile.PasswordHash))
            return (new Refusal("Current password is incorrect", 400), null, false);

        profile.PasswordHash = AuthStore.HashPassword(req.NewPassword);
        profile.MustChangePassword = false; // clears the forced-change gate, if any
        await _store.SaveChangesAsync(ct);
        await _store.RevokeAllForUserAsync(profile.Id, RefreshRevocationReasons.PasswordChanged, ct);

        // 200-with-a-body only for a client that asked for it; everyone else
        // still gets the 204 they parse today.
        if (req.SupportsRefresh != true) return (null, null, true);

        var role = await _store.ResolveRoleAsync(profile, ct);
        var reissued = BuildAuthResponse(profile, role, supportsRefresh: true);
        await _store.SaveChangesAsync(ct);
        return (null, reissued, false);
    }

    /// <summary>
    /// Redeems a teammate-invite link. Every failure is reported to the caller
    /// as the SAME generic refusal — see AuthController.AcceptInvite's doc
    /// comment for why distinguishing them would leak information to an
    /// anonymous, token-gated endpoint — but the real reason is still returned
    /// separately so the controller can log it server-side, exactly as before.
    /// </summary>
    public async Task<(Refusal? Refusal, AuthResponse? Response, string OutcomeLabel)> AcceptInviteAsync(
        AcceptInviteRequest req, CancellationToken ct = default)
    {
        const string genericFailure = "This invite link is no longer valid. Ask your manager to send a new one.";

        if (string.IsNullOrWhiteSpace(req.Token) || string.IsNullOrEmpty(req.Password))
            return (new Refusal("token and password are required", 400), null, nameof(InviteOutcome.Unknown));
        if (req.Password.Length < 6)
            return (new Refusal("Password must be at least 6 characters", 400), null, nameof(InviteOutcome.Unknown));

        // Hashed through the SAME BCrypt call every other password path uses —
        // there is exactly one way password_hash is ever written. Computed
        // before the token is touched so the token is not claimed if hashing
        // somehow throws.
        var passwordHash = AuthStore.HashPassword(req.Password);

        var result = await _store.RedeemInviteAsync(req.Token, passwordHash, ct);
        // The real reason (InviteOutcome, a System enum) is deliberately not
        // returned as itself — Process's public surface may not name a System
        // type (SalesApi.Tests/LayerBoundaryTests.cs) — but the controller still
        // needs it for the server-side log line, so it travels as its own name.
        if (result.Outcome != InviteOutcome.Redeemed || result.Profile is null)
            return (new Refusal(genericFailure, 401), null, result.Outcome.ToString());

        var profile = await _store.ProfileByIdWithOrgAsync(result.Profile.Id, ct)
            ?? throw new InvalidOperationException("Redeemed invite's profile vanished mid-request.");
        // First activity on the new account, same as a fresh sign-in.
        await _store.RecordAuthenticationAsync(profile, null, ct, method: "invite");

        var role = await _store.ResolveRoleAsync(profile, ct);
        var response = BuildAuthResponse(profile, role, req.SupportsRefresh == true);
        await _store.SaveChangesAsync(ct);
        return (null, response, nameof(InviteOutcome.Redeemed));
    }
}

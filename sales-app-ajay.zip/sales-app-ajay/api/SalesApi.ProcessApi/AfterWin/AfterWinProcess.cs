using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.Amcs;
using SalesApi.SystemLayer.EngagementLetters;
using SalesApi.SystemLayer.Invoices;
using SalesApi.SystemLayer.Leads;
using SalesApi.SystemLayer.Tasks;

namespace SalesApi.ProcessLayer.AfterWin;

/// <summary>
/// E13 F2 - the "After the win" read of one deal (GET /leads/{id}/after-win): what was sold, what has been billed and collected,
/// what is still owed, and what comes next. It computes nothing the rest of the app does not already define:
///
///  - invoiced / paid / outstanding / overdue are the account rollup's and the Collections page's own rules
///    (<c>AccountProcess.RollupAsync</c>): a draft or void invoice is never counted, <see cref="Invoice.IsReceivable"/> says what
///    is owed, <see cref="Invoice.BalanceOf(Invoice)"/> says how much, and <see cref="ReportingCalendar.IsOverdue"/> says what is
///    overdue (owner answer 2). Drafts are listed and not added to anything.
///  - the invoices are the caller's own view of them (<see cref="InvoiceStore.ListScopedAsync"/>, the list GET /invoices serves).
///  - masking is the rollup's: invoice money is null unless the caller may see it (<c>canViewMoney</c>, a fact about the caller
///    passed down), and the closed value follows the lead's own deal-value level.
///  - the deal's recurring-contract offer and payment terms read the deal's workflow overrides through
///    <see cref="PlaybookPostWinReader"/>, falling back to the org setting field by field.
/// </summary>
public sealed class AfterWinProcess
{
    private readonly LeadStore _leads;
    private readonly InvoiceStore _invoices;
    private readonly AmcStore _amcs;
    private readonly EngagementLetterStore _letters;
    private readonly PeopleScopeReader _peopleScope;
    private readonly PipelineStages _stages;
    private readonly PaymentWorkflowReader _paymentWorkflow;
    private readonly PlaybookPostWinReader _postWin;
    private readonly ReportingCalendarService _calendar;
    private readonly MoneyFormatService _money;
    private readonly TaskStore _tasks;
    private readonly PostWinSource? _postWinSource;

    /// <param name="postWinSource">Where the deal's workflow overrides come from; null = <paramref name="postWin"/> (tests pass their own).</param>
    public AfterWinProcess(
        LeadStore leads, InvoiceStore invoices, AmcStore amcs, EngagementLetterStore letters, PeopleScopeReader peopleScope,
        PipelineStages stages, PaymentWorkflowReader paymentWorkflow, PlaybookPostWinReader postWin,
        ReportingCalendarService calendar, MoneyFormatService money, TaskStore tasks, PostWinSource? postWinSource = null)
    {
        _leads = leads;
        _invoices = invoices;
        _amcs = amcs;
        _letters = letters;
        _peopleScope = peopleScope;
        _stages = stages;
        _paymentWorkflow = paymentWorkflow;
        _postWin = postWin;
        _calendar = calendar;
        _money = money;
        _tasks = tasks;
        _postWinSource = postWinSource;
    }

    public sealed record Refusal(string Reason, bool NotFound = false, bool Forbidden = false);

    public sealed record Outcome(Refusal? Refusal, AfterWinDto? Dto);

    /// <summary>
    /// POST /leads/{id}/after-win/dismiss-offer - "Not needed" on the recurring-contract offer. Recorded ON THE DEAL (who + when), so it
    /// hides the offer for everyone; reopening the deal clears it (<see cref="StageService.SyncCloseDates"/>). Same gate as creating the
    /// contract (<c>AmcProcess.CreateAsync</c>): the caller manages the deal; the HTTP layer holds financials.view. Idempotent.
    /// </summary>
    public async Task<Refusal?> DismissRecurringOfferAsync(RecordAccessContext ctx, Guid leadId, Guid actorId, DateTime now, CancellationToken ct = default)
    {
        var lead = await _leads.TrackedByIdAsync(leadId);
        if (lead is null) return new Refusal("Lead not found", NotFound: true);
        if (!RecordAccess.CanManage(ctx, lead.OwnerId, lead.TeamId))
            return new Refusal("Not allowed to change this deal", Forbidden: true);

        var stages = await _stages.GetAllAsync(ct, lead.PlaybookId);
        var current = stages.FirstOrDefault(s => string.Equals(s.Key, lead.Status, StringComparison.OrdinalIgnoreCase));
        if (current is null || (current.Phase ?? StagePhase.Fallback(current.Key)) is not (StagePhase.Won or StagePhase.PostClose))
            return new Refusal("Only a won deal has a recurring contract to set up.");

        if (lead.RecurringOfferDismissedAt is not null) return null;
        lead.RecurringOfferDismissedAt = now;
        lead.RecurringOfferDismissedById = actorId;
        await _leads.SaveChangesAsync(ct);
        return null;
    }

    /// <param name="canViewMoney">The caller may see invoice money: financials.view (invoice access) AND account_financials.view (the
    /// rollup's masking permission). A fact about the caller, resolved at the HTTP layer.</param>
    /// <param name="canChangeSettings">The caller holds post_win.manage.</param>
    public async Task<Outcome> GetAsync(
        RecordAccessContext ctx, LeadView view, Guid leadId, bool canViewMoney, bool canChangeSettings, DateTime now, CancellationToken ct = default)
    {
        var lead = await _leads.NoTrackingByIdAsync(leadId);
        if (lead is null) return new(new Refusal("Lead not found", NotFound: true), null);
        // The same rule as reading the lead (LeadReadProcess.GetAsync).
        if (!RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId))
            return new(new Refusal("Not allowed to access this lead", Forbidden: true), null);

        var stages = await _stages.GetAllAsync(ct, lead.PlaybookId);
        string PhaseOf(StageDefDto s) => s.Phase ?? StagePhase.Fallback(s.Key);
        var current = stages.FirstOrDefault(s => string.Equals(s.Key, lead.Status, StringComparison.OrdinalIgnoreCase));
        var sold = current is not null && (PhaseOf(current) is StagePhase.Won or StagePhase.PostClose);

        // Closed value: the lead's own deal-value masking (LeadMapping.ToDto), not a second rule.
        var access = (view.Sensitive ?? SensitiveAccess.FromLegacyFlags(view.CanSeeContactDetails, view.CanSeeValues)).ForRecord("lead", lead.Id);
        var canSeeClosed = SensitiveLevels.CanReadRaw(access.RoleLevel(SensitiveCategories.DealValues));
        var closedValue = sold && canSeeClosed ? lead.ClosedValue ?? lead.EstimatedValue : (decimal?)null;

        var cal = await _calendar.ForAsync();
        decimal? vat = null, invoiced = null, paid = null, discounts = null, outstanding = null, overdue = null, notYet = null;
        List<AfterWinDraftDto>? drafts = null;
        if (canViewMoney)
        {
            var rows = await _invoices.ListScopedAsync(ctx, null, null, leadId, null, ct);
            // Issued = not a draft and not void (RollupAsync's "won value" rule).
            var issued = rows.Where(i => i.Status != "void" && i.Status != "draft").ToList();
            // Card basis (owner, 2026-10-17): Invoiced and Not yet invoiced are BEFORE VAT so they add up to the closed value; Paid, Outstanding and
            // Overdue are amounts owed INCL. VAT (Collections definitions), and the VAT sits on one line of its own.
            invoiced = issued.Sum(i => i.Subtotal);
            vat = issued.Sum(i => i.TaxAmount);
            paid = issued.Sum(i => i.AmountPaid);
            discounts = issued.Sum(i => i.DiscountTaken);
            outstanding = issued.Where(i => Invoice.IsReceivable(i.Status)).Sum(Invoice.BalanceOf);
            overdue = issued.Where(i => Invoice.IsReceivable(i.Status) && ReportingCalendar.IsOverdue(cal, i.DueDate, now)).Sum(Invoice.BalanceOf);
            // Closed value minus invoiced (owner answer 2); unknown when the closed value itself is masked.
            // F2: the closed value is BEFORE VAT, so it is compared with the issued invoices' subtotals (before VAT), never their gross amounts.
            notYet = closedValue is decimal cv ? cv - issued.Sum(i => i.Subtotal) : null;
            drafts = rows.Where(i => i.Status == "draft").OrderBy(i => i.CreatedAt)
                .Select(i => new AfterWinDraftDto(i.Id, i.Number, i.Amount)).ToList();
        }

        // Payment term: the key the deal carries, labelled by the terms in force for ITS workflow.
        AfterWinTermDto? term = null;
        if (lead.PaymentTermKey is { Length: > 0 } termKey)
        {
            var cfg = await _paymentWorkflow.GetConfigAsync(lead.PlaybookId, ct);
            term = new(termKey, cfg.Terms.FirstOrDefault(t => t.Key == termKey)?.Label ?? termKey);
        }

        var people = await _peopleScope.VisibleIdsAsync(ctx, ct);
        var contracts = (await _amcs.ListAsync(people, null, ct, leadId))
            .Select(a => new AfterWinContractDto(a.Id, a.Title, a.Label ?? RecurringContractService.DefaultLabel,
                canViewMoney ? a.ContractValue : null, a.RenewalDate, a.Status)).ToList();

        // The newest letter that is not superseded; a signed copy on file reads as "signed".
        var letters = await _letters.ForLeadAsync(leadId, ct);
        // With several agreements the deal reads "signed" as the requirement does (EngagementLetterRequirement.IsMet - one place for the rule);
        // otherwise the status of the newest live one.
        var liveLetters = letters.Where(l => l.Status != EngagementLetter.Statuses.Superseded).ToList();
        var live = liveLetters.FirstOrDefault();
        var signed = EngagementLetterRequirement.IsMet(
            [.. liveLetters.Select(l => new EngagementLetterRequirement.LetterFacts(l.Status, l.SentAt, l.SignedAt))],
            await _postWin.SignedRuleAsync(lead?.PlaybookId, ct));
        AfterWinLetterDto? letter = live is null ? null : new(signed ? "signed" : live.Status);

        // The next post-close stage on this workflow, after the deal's current one (the first when it is at Won).
        AfterWinStageDto? next = null;
        if (sold && current is not null)
        {
            var after = stages.Where(s => PhaseOf(s) == StagePhase.PostClose && s.Order > current.Order).OrderBy(s => s.Order).FirstOrDefault();
            if (after is not null) next = new(after.Key, after.Label);
        }

        // Recurring contract offer (F3): the workflow says "offer" and the deal has no contract yet. Also read on an OPEN deal, where it is
        // what Mark won would offer (the Mark won dialog's "Set up the <label> now" tick box); the client confirms through the existing
        // POST /amcs from the read it makes AFTER the win, so the closed value the rep types in that dialog is what the contract carries.
        RecurringOfferDto? offer = null;
        // "Not needed" (owner, 2026-10-17): once somebody dismissed the offer on this deal it stays hidden for everyone until the deal is reopened.
        if (contracts.Count == 0 && canViewMoney && canSeeClosed && lead.RecurringOfferDismissedAt is null)
        {
            var post = _postWinSource is not null
                ? await _postWinSource(lead.PlaybookId, ct)
                : await _postWin.ForPlaybookAsync(lead.PlaybookId, ct);
            if (RecurringContractService.ModeOf(post?.Recurring) == RecurringContractService.ModeOffer)
                offer = RecurringContractService.PlanFor(lead, post!.Recurring, now);
        }

        // Handover tasks: legacy handover-keyed tasks plus the entry tasks its workflow's Won and after-the-win stages made, including unclaimed role-queue ones.
        var afterWinKeys = stages.Where(s => PhaseOf(s) is StagePhase.Won or StagePhase.PostClose).Select(s => s.Key).ToList();
        var handover = await _tasks.HandoverForLeadAsync(leadId, lead.PlaybookId, afterWinKeys, ct);

        // before_invoice: the first invoice cannot be issued until the letter is signed (a draft can exist meanwhile).
        var waitingOnLetter = sold && await _invoices.EngagementLetterBlockAsync(leadId, ct) is not null;

        return new(null, new AfterWinDto(
            closedValue, invoiced, paid, discounts, outstanding, overdue, notYet, drafts, await _money.CurrencyAsync(ct: ct),
            term, contracts, letter,
            handover,
            next, offer, canViewMoney, canChangeSettings, waitingOnLetter, vat));
    }
}

using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.Collections;

namespace SalesApi.ProcessLayer.Collections;

/// <summary>
/// Collections: outstanding vs overdue receivables, an aging breakdown, and
/// the per-rep / per-customer rollups built from the same figures, so no two
/// screens can silently disagree about what "outstanding" or "overdue" means.
///
/// Layering round 4 (owner decision 2026-09-30): now fully <c>AppDbContext</c>-free —
/// the store owns collections' own queries over invoices/payments/accounts,
/// and the org-wide System services this class needs (<see cref="ReportingCalendarService"/>,
/// <see cref="PeopleScopeReader"/>, <see cref="CollectionReminderReader"/>) are
/// each reached through their own injectable front.
/// </summary>
public sealed class CollectionProcess
{
    private readonly CollectionStore _store;
    private readonly PeopleScopeReader _peopleScope;


    private readonly ReportingCalendarService _reportingCalendar;
    private readonly CollectionReminderReader _reminders;
    public CollectionProcess(
        CollectionStore store,
        ReportingCalendarService reportingCalendar,
        PeopleScopeReader peopleScope,
        CollectionReminderReader reminders)
    {
        _store = store;
        _peopleScope = peopleScope;
        _reportingCalendar = reportingCalendar;
        _reminders = reminders;
    }

    /// <summary>The dashboard's window: the org's current calendar month, to now.</summary>
    public async Task<CollectionsDto> DashboardAsync(
        RecordAccessContext ctx, DateTime now, bool canSeeFinancials = true, CancellationToken ct = default)
    {
        var cal = await _reportingCalendar.ForAsync();
        var (year, month) = ReportingCalendar.MonthOf(cal, now);
        var monthStart = ReportingCalendar.StartOfMonthUtc(cal, year, month);
        return await ComputeAsync(ctx, monthStart, now, canSeeFinancials, ct);
    }

    /// <summary>
    /// Shared AR aging + collected-cash computation. GET /collections/dashboard
    /// and GET /reports/md-pack (the MD monthly pack) both read this so the
    /// outstanding/overdue/aging figures cannot drift apart into two
    /// calculations that quietly disagree; only the "cash collected" window is
    /// a parameter. Aging itself is always an as-of-now snapshot — there is no
    /// historical aging store — so it is intentionally NOT bound to
    /// fromCollected/toCollected.
    ///
    /// <paramref name="canSeeFinancials"/> (ViewAccountFinancials,
    /// invoice-money-masking 2026-09-28) masks every money figure to null;
    /// OpenCount/OverdueCount (counts) stay visible. Defaults to `true`
    /// (no-op) for the same reason every other masking flag in this migration
    /// does — GET /reports/md-pack's own MdPackProcess call passes it through
    /// explicitly.
    /// </summary>
    public async Task<CollectionsDto> ComputeAsync(
        RecordAccessContext ctx, DateTime fromCollected, DateTime toCollected, bool canSeeFinancials = true, CancellationToken ct = default)
    {
        // Q9: the figures are folded from the stored receivables rows (ReceivablesStats), kept current by every invoice / payment /
        // installment / credit write. Aging buckets and the overdue split come from the stored DUE DAYS against today in the org's
        // timezone (ReceivablesStatsService.Fold -> ReportingCalendar.AgingIndex), the same boundaries ByCustomerAsync below uses.
        var rows = await _store.ReceivablesAsync(ctx, ct);
        var collected = await _store.CollectedAsync(ctx, fromCollected, toCollected, ct);
        var cal = await _reportingCalendar.ForAsync();
        var t = ReceivablesStatsService.Fold(rows, cal, DateTime.UtcNow);

        return new CollectionsDto
        {
            Outstanding = canSeeFinancials ? t.Outstanding : null,
            Overdue = canSeeFinancials ? t.Overdue : null,
            OpenCount = t.OpenCount,
            OverdueCount = t.OverdueCount,
            CollectedThisMonth = canSeeFinancials ? collected : null,
            UnappliedCredit = canSeeFinancials ? t.UnappliedCredit : null,
            Aging = t.Buckets.Select(b => new AgingBucket(b.Key, b.Label, b.Count, canSeeFinancials ? b.Amount : null)).ToList(),
        };
    }

    /// <summary>Receivables per rep (manager=team, rep=self, via <paramref name="ctx"/>/<paramref name="orgId"/>).
    /// Outstanding/Overdue/CollectedThisMonth masked (null) without <paramref name="canSeeFinancials"/>
    /// (ViewAccountFinancials, invoice-money-masking); OpenCount/OverdueCount/AvgDaysOverdue stay visible.</summary>
    public async Task<List<CollectionsLeaderboardRowDto>> LeaderboardAsync(
        RecordAccessContext ctx, Guid? orgId, bool canSeeFinancials = true, CancellationToken ct = default)
    {
        var people = await _peopleScope.VisibleIdsAsync(ctx);
        var profiles = await _store.ProfilesAsync(orgId, people, ct);

        // The rows are per rep, but the invoices behind them are scoped by the
        // record predicate — otherwise a manager's own row would count
        // receivables on invoices they cannot open from the list beside it.
        var stored = (await _store.ReceivablesAsync(ctx, ct)).Where(r => r.Kind == ReceivablesStats.ReceivableKind).ToList();
        var payments = await _store.OwnerPaymentsAsync(ctx, ct);

        var now = DateTime.UtcNow;
        var cal = await _reportingCalendar.ForAsync();
        var today = ReportingCalendar.DayOf(cal, now);
        var (lbYear, lbMonth) = ReportingCalendar.MonthOf(cal, now);
        var monthStart = ReportingCalendar.StartOfMonthUtc(cal, lbYear, lbMonth);

        // Ranked/filtered on the REAL (unmasked) figures first — same
        // "compute for real, mask only what's emitted" order AccountProcess.
        // ListAsync's sort keeps — so a masked caller still sees the same rows
        // in the same order a caller with the permission would, not a
        // differently-ranked list.
        return profiles.Select(p =>
        {
            // The rep's stored due-day rows. One overdue definition, shared with the dashboard and by-customer: whole calendar days in
            // the org's timezone (a due day strictly before today).
            var own = stored.Where(r => r.UserId == p.Id).ToList();
            var overdue = own.Where(r => today.DayNumber - r.DueDay.DayNumber > 0).ToList();
            var collected = payments.Where(x => x.OwnerId == p.Id && x.PaidAt >= monthStart).Sum(x => x.Amount);
            var overdueInvoices = overdue.Sum(r => r.InvoiceCount);
            int? avgDaysOverdue = overdueInvoices > 0
                ? (int)Math.Round(overdue.Sum(r => (double)r.InvoiceCount * (today.DayNumber - r.DueDay.DayNumber)) / overdueInvoices)
                : null;
            return (
                UserId: p.Id, FullName: p.FullName,
                Outstanding: own.Sum(r => r.Amount), Overdue: overdue.Sum(r => r.Amount), CollectedThisMonth: collected,
                OpenCount: own.Sum(r => r.InvoiceCount), OverdueCount: overdueInvoices, AvgDaysOverdue: avgDaysOverdue);
        })
        .Where(r => r.Outstanding > 0 || r.CollectedThisMonth > 0)
        .OrderByDescending(r => r.Overdue)
        .ThenByDescending(r => r.Outstanding)
        .Select(r => new CollectionsLeaderboardRowDto(
            r.UserId, r.FullName,
            canSeeFinancials ? r.Outstanding : null, canSeeFinancials ? r.Overdue : null,
            canSeeFinancials ? r.CollectedThisMonth : null,
            r.OpenCount, r.OverdueCount, r.AvgDaysOverdue))
        .ToList();
    }

    /// <summary>
    /// Receivables grouped by account ("you collect from customers, not
    /// invoices"). One row per account that has at least one open invoice,
    /// scoped like the leaderboard. Outstanding/Overdue/NextPromisedDate
    /// masked (null) without <paramref name="canSeeFinancials"/>
    /// (ViewAccountFinancials, invoice-money-masking) — ranked on the real
    /// figures first, same as LeaderboardAsync.
    /// </summary>
    public async Task<List<CollectionsByCustomerRowDto>> ByCustomerAsync(
        RecordAccessContext ctx, bool canSeeFinancials = true, CancellationToken ct = default)
    {
        var now = DateTime.UtcNow;
        var cal = await _reportingCalendar.ForAsync();

        var invoices = await _store.AccountInvoicesAsync(ctx, ct);
        if (invoices.Count == 0) return new List<CollectionsByCustomerRowDto>();

        var accountIds = invoices.Select(i => i.AccountId!.Value).ToHashSet();
        var accounts = await _store.AccountsByIdsAsync(accountIds, ct);

        var openInvoiceIds = invoices.Where(i => Invoice.IsReceivable(i.Status))
            .Select(i => i.Id).ToHashSet();
        var promises = await _store.OpenInvoicePromisesAsync(openInvoiceIds, now, ct);
        var invoiceToAccount = invoices.ToDictionary(i => i.Id, i => i.AccountId!.Value);
        var nextPromisedByAccount = new Dictionary<Guid, DateTime>();
        foreach (var p in promises)
        {
            var accId = invoiceToAccount[p.InvoiceId];
            var d = p.PromisedDate;
            if (!nextPromisedByAccount.TryGetValue(accId, out var existing) || d < existing) nextPromisedByAccount[accId] = d;
        }

        var rows = new List<(Guid AccountId, string AccountName, Guid? OwnerId, string? OwnerName,
            decimal Outstanding, decimal Overdue, string BucketKey, string BucketLabel, int? OldestDays,
            DateTime? NextPromisedDate, int OpenCount, int OverdueCount)>();
        foreach (var group in invoices.GroupBy(i => i.AccountId!.Value))
        {
            var account = accounts.FirstOrDefault(a => a.Id == group.Key);
            if (account is null) continue; // orphaned invoice.account_id; nothing to display
            // F18: an invoice owes what its slices say, each on its own due date (installment dates for a plan) - the same
            // ReceivablesStatsService.SlicesOf the stored aggregate is built from.
            var open = group.Where(i => Invoice.IsReceivable(i.Status))
                .Select(i => ReceivablesStatsService.SlicesOf(i, i.Installments))
                .Where(s => s.Count > 0)
                .ToList();
            if (open.Count == 0) continue; // fully settled account — nothing to chase
            var overdueSlices = open.SelectMany(s => s).Where(s => ReportingCalendar.IsOverdue(cal, s.Due, now)).ToList();
            var oldestDays = overdueSlices.Count > 0
                ? overdueSlices.Max(s => ReportingCalendar.DaysOverdue(cal, s.Due, now))
                : (int?)null;
            // The SAME call the dashboard makes — not a second copy of the
            // boundaries with a comment asserting they agree.
            var (bucketKey, bucketLabel) = ReportingCalendar.AgingBucket(oldestDays ?? 0);
            rows.Add((
                account.Id, account.Name, account.OwnerId, account.Owner?.FullName,
                open.Sum(s => s.Sum(x => x.Amount)), overdueSlices.Sum(s => s.Amount),
                bucketKey, bucketLabel, oldestDays,
                nextPromisedByAccount.TryGetValue(account.Id, out var np) ? np : null,
                open.Count, open.Count(s => s.Any(x => ReportingCalendar.IsOverdue(cal, x.Due, now)))));
        }

        // Ranked on the REAL (unmasked) Outstanding/Overdue first — same
        // "rank for real, mask only what's emitted" rule LeaderboardAsync
        // follows — then mapped to the (possibly masked) wire DTO.
        return rows.OrderByDescending(r => r.Overdue).ThenByDescending(r => r.Outstanding)
            .Select(r => new CollectionsByCustomerRowDto(
                r.AccountId, r.AccountName, r.OwnerId, r.OwnerName,
                canSeeFinancials ? r.Outstanding : null, canSeeFinancials ? r.Overdue : null,
                r.BucketKey, r.BucketLabel, r.OldestDays,
                canSeeFinancials ? r.NextPromisedDate : null,
                r.OpenCount, r.OverdueCount))
            .ToList();
    }

    // --- Auto payment-reminder config/generation (unchanged rules, moved off the controller) ---

    public Task<CollectionReminderConfigDto> ReminderConfigAsync(CancellationToken ct = default) =>
        _reminders.GetConfigAsync();

    /// <summary>Merge a partial update over the current schedule, then persist the merged (normalised) result.</summary>
    public async Task<CollectionReminderConfigDto> SetReminderConfigAsync(CollectionReminderConfigInput input, CancellationToken ct = default)
    {
        var current = await _reminders.GetConfigAsync();
        var merged = input.ApplyTo(current);
        return await _reminders.SaveConfigAsync(merged);
    }

    public Task<int> GenerateRemindersAsync(CancellationToken ct = default) =>
        _reminders.GenerateAsync();
}

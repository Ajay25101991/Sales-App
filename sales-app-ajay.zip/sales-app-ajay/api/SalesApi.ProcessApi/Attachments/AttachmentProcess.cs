using SalesApi.Dtos;
using SalesApi.Services;
using SalesApi.SystemLayer.Attachments;
using SalesApi.SystemLayer.Microsoft365;

namespace SalesApi.ProcessLayer.Attachments;

/// <summary>
/// Record-scoped access to attachments (lead, account, quote, invoice, AMC), the business-card discard
/// rule, and the tag vocabulary — separated from the HTTP request that triggers them.
///
/// <see cref="RecordAccessContext"/> is a Contracts value (see CallerScope.cs),
/// so it is fine on every public method here; <c>SalesApi.Services.RecordAccess</c>
/// (the System-layer gate functions) and the <c>Lead</c>/<c>Attachment</c>
/// entities are used INSIDE this class but never returned or taken as a
/// parameter — only Contract DTOs and plain values cross the line to Experience.
/// </summary>
public sealed class AttachmentProcess
{
    private readonly AttachmentStore _store;
    private readonly PeopleScopeReader _peopleScope;
    private readonly SharePointBrowseAccess? _browse;
    private readonly IGraphSharePointBrowseClient? _graph;
    // The last two are only needed to LINK SharePoint files (they read the item with the caller's own token); every other
    // member works without them, so existing hand-wired chains keep compiling. Program.cs supplies both.
    private readonly OrgSettingsReader? _orgSettings;
    // Task files: a file linked to a task is ALSO reachable (download, delete one's own upload) by whoever can see that task. Optional
    // like the two above: a chain built without it simply has no task route in.
    private readonly SalesApi.ProcessLayer.Tasks.TaskProcess? _tasks;
    public AttachmentProcess(AttachmentStore store, PeopleScopeReader peopleScope,
        SharePointBrowseAccess? browse = null, IGraphSharePointBrowseClient? graph = null, OrgSettingsReader? orgSettings = null,
        SalesApi.ProcessLayer.Tasks.TaskProcess? tasks = null)
    {
        _tasks = tasks;
        _orgSettings = orgSettings;
        _store = store;
        _peopleScope = peopleScope;
        _browse = browse;
        _graph = graph;
    }

    /// <summary>Owner 2026-11-16: the org's company-document types (no ID or bank data). Unwired chains (tests) and an unset org get the built-in default.</summary>
    public async Task<IReadOnlyCollection<string>> CompanyDocumentTypesAsync() =>
        _orgSettings is null ? IdBankDocuments.CompanyDocumentTypes : await _orgSettings.GetCompanyDocumentTypesAsync();

    // Only these classification tags are accepted; anything else is treated as
    // a general (untagged) attachment — unchanged from the controller.
    private static readonly HashSet<string> ValidTags = new() { "signed_proposal", "voice_note", "business_card", AttachmentTags.PartnerInvoice };
    // "doctype:{key}" is a client's own document (trade licence, VAT certificate...): see AttachmentTags. It is read by
    // ClientDocumentProcess and may sit on a deal OR an account.
    public static bool IsValidTag(string tag) =>
        ValidTags.Contains(tag) || (tag.StartsWith("workflow:", StringComparison.Ordinal) && tag.Length <= 160)
        || AttachmentTags.IsValidClientDocument(tag) || AttachmentTags.IsValidScreening(tag);

    // E15.1: the file-type allow-list for the DOCUMENT REGISTER's uploads (PDF, JPG, PNG). It is NOT applied to attachments in general:
    // proposals, spreadsheets, Word files and the rest keep uploading through POST /attachments as before. Judged on the extension, the
    // declared content type (when the client gave a specific one) and the file's own first bytes, so a renamed file does not pass.
    public const string RegisterFileTypesMessage = "Only PDF, JPG or PNG files can be added to the document register.";

    private static readonly Dictionary<string, string> RegisterExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        [".pdf"] = "application/pdf", [".jpg"] = "image/jpeg", [".jpeg"] = "image/jpeg", [".png"] = "image/png",
    };

    /// <summary>Null when the file may go in the register, else the plain reason. Rewinds <paramref name="content"/> when it can seek.</summary>
    public static async Task<string?> CheckRegisterFileAsync(string? filename, string? contentType, Stream content, CancellationToken ct = default)
    {
        if (!RegisterExtensions.TryGetValue(Path.GetExtension(filename ?? ""), out var expected)) return RegisterFileTypesMessage;
        var declared = contentType?.Split(';')[0].Trim().ToLowerInvariant();
        if (!string.IsNullOrEmpty(declared) && declared != "application/octet-stream" && declared != expected) return RegisterFileTypesMessage;
        if (!content.CanSeek) return null;   // cannot look without consuming: the extension and declared type have to do
        var start = content.Position;
        var head = new byte[8];
        var read = 0;
        while (read < head.Length)
        {
            var n = await content.ReadAsync(head.AsMemory(read, head.Length - read), ct);
            if (n == 0) break;
            read += n;
        }
        content.Position = start;
        var ok = expected switch
        {
            "application/pdf" => read >= 4 && head[0] == 0x25 && head[1] == 0x50 && head[2] == 0x44 && head[3] == 0x46,   // %PDF
            "image/jpeg" => read >= 3 && head[0] == 0xFF && head[1] == 0xD8 && head[2] == 0xFF,
            _ => read >= 8 && head[0] == 0x89 && head[1] == 0x50 && head[2] == 0x4E && head[3] == 0x47 && head[4] == 0x0D && head[5] == 0x0A && head[6] == 0x1A && head[7] == 0x0A,
        };
        return ok ? null : RegisterFileTypesMessage;
    }

    // Every classified kind (the stage-gate documents, voice notes, card photos, workflow files, WhatsApp media) is
    // a LEAD thing: gates, retention sweeps and the WhatsApp writer all look for it on the lead. A client document is the exception:
    // it also goes on an account (see UploadAsync for where it may NOT go).
    private static bool IsLeadOnlyTag(string tag) => (IsValidTag(tag) && !AttachmentTags.IsKycFile(tag) && tag != AttachmentTags.PartnerInvoice) || tag == "whatsapp_media";

    /// <summary>Why a request could not be carried out, or null when it can. Same shape as
    /// <c>InvoiceProcess.Refusal</c> / <c>AmcProcess.Refusal</c>: not-found (404), forbidden (403), else a bad
    /// request (400) — the controller only picks the status code.</summary>
    public sealed record Refusal(string Reason, bool NotFound = false, bool Forbidden = false, bool Upstream = false);

    /// <summary>A record the caller may view, plus whether they may also manage it (the delete rule).</summary>
    private sealed record Resolved(string Type, Guid Id, Guid? LeadId, bool CanManage);

    private static Refusal NotFoundOf(string type) => new($"{AttachmentRecordType.Label(type)} not found", NotFound: true);
    private static Refusal NotAllowedOf(string type) =>
        new($"Not allowed to access this {AttachmentRecordType.Label(type).ToLowerInvariant()}", Forbidden: true);
    private static Refusal LacksPermission(string permission) =>
        new($"Your role does not have the '{permission}' permission.", Forbidden: true);

    /// <summary>
    /// The one place "may the caller view this record" is decided for a file — and it REUSES each record type's own
    /// detail rule rather than writing a new one:
    ///  - lead: <c>RecordAccess.CanView</c> on the lead (as before); not visible is 403.
    ///  - account: AccountProcess.GetAsync — the account's own <c>CanView</c>, 404 / 403; the whole accounts
    ///    controller sits behind <c>contact_details.view</c>, so that permission is required here too.
    ///  - quote: a quote has no rule of its own — it is read through its lead (GET /leads/{id}/proposals), so the
    ///    lead's <c>CanView</c>; 404 / 403.
    ///  - invoice: InvoiceProcess.GetAsync — <c>financials.view</c>, then the invoice is looked up through
    ///    <c>WhereViewable</c>; an invoice outside the caller's scope is simply "not found" (404), as there.
    ///  - AMC: AmcProcess.GetAsync — <c>financials.view</c>, then the AMC is looked up inside the caller's people
    ///    scope; outside it is "not found" (404), as there.
    /// </summary>
    private async Task<(Resolved? Record, Refusal? Refusal)> ResolveAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, string type, Guid id, CancellationToken ct)
    {
        switch (type)
        {
            case AttachmentRecordType.Lead:
            {
                var lead = await _store.FindLeadAsync(id, ct);
                if (lead is null) return (null, NotFoundOf(type));
                if (!RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId)) return (null, NotAllowedOf(type));
                return (new Resolved(type, id, id, RecordAccess.CanManage(ctx, lead.OwnerId, lead.TeamId)), null);
            }
            case AttachmentRecordType.Account:
            {
                if (!perms.ViewContactDetails) return (null, LacksPermission(OrganizationPermissions.ViewContactDetails));
                var account = await _store.FindAccountAsync(id, ct);
                if (account is null) return (null, NotFoundOf(type));
                if (!RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return (null, NotAllowedOf(type));
                return (new Resolved(type, id, null, RecordAccess.CanManage(ctx, account.OwnerId, account.TeamId)), null);
            }
            case AttachmentRecordType.Quote:
            {
                var quote = await _store.FindQuoteAsync(id, ct);
                if (quote is null) return (null, NotFoundOf(type));
                var lead = await _store.FindLeadAsync(quote.LeadId, ct);
                if (lead is null) return (null, NotFoundOf(type));
                if (!RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId)) return (null, NotAllowedOf(type));
                return (new Resolved(type, id, quote.LeadId, RecordAccess.CanManage(ctx, lead.OwnerId, lead.TeamId)), null);
            }
            case AttachmentRecordType.Invoice:
            {
                if (!perms.ViewFinancials) return (null, LacksPermission(OrganizationPermissions.ViewFinancials));
                var invoice = await _store.FindInvoiceViewableAsync(ctx, id, ct);
                if (invoice is null) return (null, NotFoundOf(type));
                return (new Resolved(type, id, invoice.LeadId, RecordAccess.CanManageInvoice(ctx, invoice.OwnerId, invoice.TeamId)), null);
            }
            case AttachmentRecordType.Amc:
            {
                if (!perms.ViewFinancials) return (null, LacksPermission(OrganizationPermissions.ViewFinancials));
                var people = await _peopleScope.VisibleIdsAsync(ctx, ct);
                var amc = await _store.FindAmcScopedAsync(people, id, ct);
                if (amc is null) return (null, NotFoundOf(type));
                // AMCs carry no team column, so manage is the people scope too (AmcProcess.CanManage).
                return (new Resolved(type, id, amc.LeadId, people is null || people.Contains(amc.OwnerId)), null);
            }
            default:
                return (null, new Refusal($"record_type must be one of: {string.Join(", ", AttachmentRecordType.All)}"));
        }
    }

    /// <summary>The legacy <c>leadId</c> parameter means <c>record_type=lead</c>; an explicit record_type needs a record_id.</summary>
    public static (string Type, Guid Id, Refusal? Refusal) NormaliseTarget(Guid legacyLeadId, string? recordType, Guid? recordId)
    {
        if (string.IsNullOrWhiteSpace(recordType)) return (AttachmentRecordType.Lead, recordId ?? legacyLeadId, null);
        var type = recordType.Trim().ToLowerInvariant();
        if (!AttachmentRecordType.IsKnown(type))
            return (type, Guid.Empty, new Refusal($"record_type must be one of: {string.Join(", ", AttachmentRecordType.All)}"));
        if (recordId is null || recordId == Guid.Empty)
            return (type, Guid.Empty, new Refusal("record_id is required"));
        return (type, recordId.Value, null);
    }

    /// <param name="includeQuotes">E13, lead lists only: also return the files on the deal's quotes (record_type "quote", labelled with their
    /// version) so a gate-link picker can offer a generated proposal's PDF. Off by default, so GET /attachments?leadId= is still lead files only.</param>
    public async Task<(Refusal? Refusal, List<AttachmentDto>? Files)> ListAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, string type, Guid id, CancellationToken ct = default, bool includeQuotes = false)
    {
        var (_, refusal) = await ResolveAsync(ctx, perms, type, id, ct);
        if (refusal is not null) return (refusal, null);

        var files = await _store.ListForRecordAsync(type, id, ct);
        if (includeQuotes && type == AttachmentRecordType.Lead)
            files = files.Concat(await _store.ListQuoteFilesOfLeadAsync(id, ct)).OrderByDescending(f => f.CreatedAt).ToList();
        if (type == AttachmentRecordType.Invoice)
            files = files.Concat(await _store.ListInvoiceProofsAsync(id, ct)).OrderByDescending(f => f.CreatedAt).ToList();
        return (null, await FilterForCallerAsync(ctx, perms, files));
    }

    /// <summary>What a caller may see of a list of files: no partner commercials, no KYC document without kyc.access, and identity / bank documents
    /// listed but not openable below a raw ID &amp; bank read. The one rule for a record's Files list AND a task's.</summary>
    public async Task<List<AttachmentDto>> FilterForCallerAsync(RecordAccessContext ctx, AttachmentPermissions perms, List<AttachmentDto> files)
    {
        // A partner's tax invoice is partner commercials: it does not appear in the list of a caller who can't read them.
        if (!ProcessLayer.ChannelPartners.Cp.CanReadCommercials(ctx)) files = files.Where(f => f.Tag != AttachmentTags.PartnerInvoice).ToList();
        // E15.1: a client's KYC document is invisible to a caller without kyc.access.
        if (!perms.ViewKyc) files = files.Where(f => !AttachmentTags.IsKycFile(f.Tag)).ToList();
        // Owner 2026-11-16: an identity / bank document is still LISTED (type, name, dates) but cannot be opened below a raw ID & bank read: no address, can_open false.
        var companyTypes = await CompanyDocumentTypesAsync();
        files = files.Select(f => !IdBankDocuments.MayOpenFile(f.Tag, ctx.Sensitive, companyTypes)
            ? f with { WebUrl = null, CanOpen = false } : f).ToList();
        return files;
    }

    public enum UploadOutcome { Refused, DiscardedByPolicy, Saved }

    public sealed record UploadResult(UploadOutcome Outcome, AttachmentDto? Attachment = null, Refusal? Refusal = null);

    /// <summary>
    /// Business-card photos are the one attachment kind an org can opt out of
    /// storing altogether (owner decision §45's "does NOT keep the image"
    /// option). Enforced HERE, not just by the client choosing not to call
    /// this endpoint, because a setting an org relies on for a privacy
    /// decision has to hold even against a client that never checked it. The
    /// parsed lead FIELDS are unaffected — they were already saved as normal
    /// lead columns before this request; only the photo is declined.
    /// </summary>
    public async Task<UploadResult> UploadAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, string type, Guid id, Guid uploaderId, Guid? orgId,
        string filename, string? contentType, long length, Stream content, string? tag,
        CancellationToken ct = default)
    {
        var (record, refusal) = await ResolveAsync(ctx, perms, type, id, ct);
        if (refusal is not null) return new UploadResult(UploadOutcome.Refused, Refusal: refusal);
        return await SaveUploadAsync(ctx, perms, type, id, record!.LeadId, uploaderId, orgId, filename, contentType, length, content, tag, ct);
    }

    /// <summary>
    /// A file added FROM A TASK to the task's own deal or account (to-do/task-files-design.md). The access decision was already made by the
    /// caller as "can see the task" - this method skips the record check (<see cref="ResolveAsync"/>) and nothing else: the same storage folder,
    /// provider stamp, size/type and tag rules as <see cref="UploadAsync"/> run in the one shared <see cref="SaveUploadAsync"/>. Only a deal or an
    /// account can own a task file. Never tagged (a task upload is an ordinary file, not a stage-gate document).
    /// </summary>
    public Task<UploadResult> UploadForTaskAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, string type, Guid id, Guid uploaderId, Guid? orgId,
        string filename, string? contentType, long length, Stream content, CancellationToken ct = default) =>
        type is AttachmentRecordType.Lead or AttachmentRecordType.Account
            ? SaveUploadAsync(ctx, perms, type, id, type == AttachmentRecordType.Lead ? id : null, uploaderId, orgId, filename, contentType, length, content, null, ct)
            : Task.FromResult(new UploadResult(UploadOutcome.Refused, Refusal: new Refusal("A task's files go on a deal or an account.")));

    /// <summary>Everything after "may the caller use this record": tag rules, the business-card policy and the store write.</summary>
    private async Task<UploadResult> SaveUploadAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, string type, Guid id, Guid? leadId, Guid uploaderId, Guid? orgId,
        string filename, string? contentType, long length, Stream content, string? tag, CancellationToken ct)
    {
        // Classified kinds stay lead-only — said plainly rather than quietly dropping the tag.
        if (type != AttachmentRecordType.Lead && tag is not null && IsLeadOnlyTag(tag))
            return new UploadResult(UploadOutcome.Refused,
                Refusal: new Refusal("That kind of file can only be added to a lead."));

        if (tag is not null && AttachmentTags.IsKycFile(tag) && type is not (AttachmentRecordType.Lead or AttachmentRecordType.Account))
            return new UploadResult(UploadOutcome.Refused,
                Refusal: new Refusal("A client document can only be added to a deal or an account."));

        if (tag is not null && AttachmentTags.IsKycFile(tag) && !perms.ViewKyc)
            return new UploadResult(UploadOutcome.Refused, Refusal: LacksPermission(OrganizationPermissions.KycAccess));

        // Channel partners: the partner's tax invoice is an account file, and adding it is a Partner commercials write.
        if (tag == AttachmentTags.PartnerInvoice)
        {
            if (type != AttachmentRecordType.Account)
                return new UploadResult(UploadOutcome.Refused, Refusal: new Refusal("A partner invoice can only be added to the partner's account."));
            if (!ProcessLayer.ChannelPartners.Cp.CanWriteCommercials(ctx))
                return new UploadResult(UploadOutcome.Refused, Refusal: new Refusal(ProcessLayer.ChannelPartners.Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), Forbidden: true));
        }

        var normalizedTag = tag is not null && IsValidTag(tag) ? tag : null;
        if (normalizedTag == "business_card" && (await _store.CardScanRetentionAsync(ct)).Mode == CardScanService.Discard)
            return new UploadResult(UploadOutcome.DiscardedByPolicy);

        var saved = await _store.UploadAsync(type, id, leadId, uploaderId, orgId, filename, contentType, length, content, normalizedTag, ct);
        return new UploadResult(UploadOutcome.Saved, saved);
    }

    public sealed record LinkResult(Refusal? Refusal, List<AttachmentDto>? Files = null, string? NotReadyState = null, string? NotReadyMessage = null);

    private const int MaxLinksPerCall = 50;

    /// <summary>
    /// POST /attachments/links (SharePoint program, Phase 4): link files that already live in SharePoint to a record. Same
    /// record access rule as an upload (<see cref="ResolveAsync"/>). Every item is RE-READ with the caller's own delegated token,
    /// so a person can only link what SharePoint lets them read, and the name, size, type and web address stored are
    /// SharePoint's, not the client's. All or nothing: one unreadable item, a folder or a duplicate refuses the whole call and
    /// stores nothing. Nothing is copied; the row has no bytes and no storage provider.
    /// </summary>
    public async Task<LinkResult> LinkAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, string? recordType, Guid? recordId, IReadOnlyList<(string? DriveId, string? ItemId)>? items,
        Guid callerId, CancellationToken ct = default)
    {
        var (type, id, bad) = NormaliseTarget(Guid.Empty, recordType ?? "", recordId);
        if (bad is not null) return new LinkResult(bad);
        if (items is null || items.Count == 0) return new LinkResult(new Refusal("Choose at least one file to link."));
        if (items.Count > MaxLinksPerCall) return new LinkResult(new Refusal($"Link at most {MaxLinksPerCall} files at a time."));
        foreach (var (d, i) in items)
            if (!SharePointIdRules.IsValid(d) || !SharePointIdRules.IsValid(i))
                return new LinkResult(new Refusal("One of the files is not valid. Choose it again from the list."));
        if (items.Select(x => (x.DriveId, x.ItemId)).Distinct().Count() != items.Count)
            return new LinkResult(new Refusal("The same file is chosen twice."));

        var (record, refusal) = await ResolveAsync(ctx, perms, type, id, ct);
        if (refusal is not null) return new LinkResult(refusal);

        if (_browse is null || _graph is null)
            return new LinkResult(new Refusal("Linking SharePoint files is not available.", Upstream: true));
        var access = await _browse.GetTokenAsync(callerId, ct);
        if (!access.State.Ready)
            return new LinkResult(null, null, access.State.State, access.State.Message);
        if (access.AccessToken is null)
            return new LinkResult(new Refusal(access.TokenProblem ?? "Microsoft did not give access just now. Try again in a moment.", Upstream: true));

        var rows = new List<AttachmentStore.LinkRow>();
        foreach (var (driveId, itemId) in items)
        {
            if (await _store.LinkExistsAsync(type, id, driveId!, itemId!, ct))
                return new LinkResult(new Refusal($"That file is already linked to this {AttachmentRecordType.Label(type).ToLowerInvariant()}."));

            var read = await _graph.GetItemAsync(access.AccessToken, driveId!, itemId!, ct);
            if (!read.Success)
            {
                var m = SharePointBrowseProcessMap(read);
                return new LinkResult(m);
            }
            var item = read.Value!;
            if (item.Kind != SharePointBrowseKinds.File)
                return new LinkResult(new Refusal("A folder cannot be linked. Choose the files inside it."));
            rows.Add(new AttachmentStore.LinkRow(driveId!, itemId!, item.Name, item.MimeType, item.SizeBytes ?? 0, item.WebUrl));
        }

        var saved = await _store.AddLinksAsync(type, id, record!.LeadId, callerId, rows, ct);
        return new LinkResult(null, saved);
    }

    private static Refusal SharePointBrowseProcessMap<T>(GraphCallResult<T> r) =>
        r.NotFound || r.Forbidden || r.ErrorCode == "invalid_id"
            ? new Refusal("You cannot link that item: it is not a file you can read in SharePoint.", Forbidden: true)
            : r.Throttled
                ? new Refusal("Microsoft is busy right now. Try again in a moment.", Upstream: true)
                : new Refusal("SharePoint did not answer just now. Try again in a moment.", Upstream: true);

    public sealed record DownloadResult(Refusal? Refusal = null, bool FileMissing = false, Stream? Stream = null, string? MimeType = null, string? Filename = null, bool IsSharePointLink = false);

    public async Task<DownloadResult> DownloadAsync(RecordAccessContext ctx, AttachmentPermissions perms, Guid attachmentId, CancellationToken ct = default)
    {
        var att = await _store.FindAsync(attachmentId, ct);
        if (att is null) return new DownloadResult(new Refusal("Attachment not found", NotFound: true));

        var (_, refusal) = await ResolveAsync(ctx, perms, att.RecordType, att.RecordId, ct);
        // A file linked to a task is also open to whoever can see that task, even with no access to the record (task files design).
        if (refusal is not null && !await SeenThroughTaskAsync(ctx, att.Id, ct)) return new DownloadResult(refusal);
        // Hidden like not found, so a file's existence isn't confirmed to a caller without the Partner commercials category.
        if (att.Tag == AttachmentTags.PartnerInvoice && !ProcessLayer.ChannelPartners.Cp.CanReadCommercials(ctx))
            return new DownloadResult(new Refusal("Attachment not found", NotFound: true));
        // E15.1: the same for a KYC document without kyc.access.
        if (AttachmentTags.IsKycFile(att.Tag) && !perms.ViewKyc)
            return new DownloadResult(new Refusal("Attachment not found", NotFound: true));
        // Owner 2026-11-16: opening an identity or bank document also needs a raw ID & bank level. 403 (not 404): the caller already sees the row in the list.
        var companyTypes = await CompanyDocumentTypesAsync();
        if (!IdBankDocuments.MayOpenFile(att.Tag, ctx.Sensitive, companyTypes))
            return new DownloadResult(new Refusal(IdBankDocuments.RefusalMessage, Forbidden: true));

        // A link has no bytes here: the client opens its web address instead (409, never a storage read).
        if (att.Kind == AttachmentKind.SharePointLink) return new DownloadResult(IsSharePointLink: true);

        var file = await _store.DownloadAsync(att, ct);
        if (file is null) return new DownloadResult(FileMissing: true);
        return new DownloadResult(null, false, file.Value.Stream, file.Value.MimeType, file.Value.Filename);
    }

    private async Task<bool> SeenThroughTaskAsync(RecordAccessContext ctx, Guid attachmentId, CancellationToken ct) =>
        _tasks is not null && await _tasks.CanSeeTaskLinkedToFileAsync(ctx, attachmentId, ct);

    /// <summary>Viewing the record is proven by ResolveAsync; deleting someone else's file additionally needs
    /// manage rights on the record, or to be the uploader. Null means deleted.</summary>
    public async Task<Refusal?> DeleteAsync(RecordAccessContext ctx, AttachmentPermissions perms, Guid attachmentId, Guid callerId, CancellationToken ct = default)
    {
        var att = await _store.FindAsync(attachmentId, ct);
        if (att is null) return new Refusal("Attachment not found", NotFound: true);

        var (record, refusal) = await ResolveAsync(ctx, perms, att.RecordType, att.RecordId, ct);
        // Task files: the uploader may still delete their own file when they only reach it through a task they can see.
        if (refusal is not null && !(att.UploaderId == callerId && await SeenThroughTaskAsync(ctx, att.Id, ct))) return refusal;
        if (AttachmentTags.IsKycFile(att.Tag) && !perms.ViewKyc) return new Refusal("Attachment not found", NotFound: true);

        var allowed = att.UploaderId == callerId || record!.CanManage;
        if (!allowed) return new Refusal("Not allowed to delete this attachment", Forbidden: true);

        await _store.DeleteAsync(att, ct);
        return null;
    }

    /// <summary>
    /// A file already on a deal can meet one of its stage's file gates (owner decision: LINK it - the file keeps its own tag
    /// and folder, one file may meet several gates). Same access rule as uploading to the deal (<see cref="ResolveAsync"/>);
    /// a deal the caller cannot see is "not found" here, never "forbidden". Only files on the LEAD record or on one of its QUOTES qualify, and only
    /// for a (stage, requirement) the deal's playbook really gates on a file. A SharePoint link row has no file of its own
    /// (see <see cref="AttachmentStore.AddLinksAsync"/>: it can never satisfy a gate) and is refused for the same reason.
    /// </summary>
    public async Task<(Refusal? Refusal, AttachmentDto? File)> LinkGateAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, Guid attachmentId, string? stage, string? requirementKey,
        Guid callerId, CancellationToken ct = default)
    {
        var (att, dealId, refusal) = await GateLinkTargetAsync(ctx, perms, attachmentId, ct);
        if (refusal is not null) return (refusal, null);
        if (string.IsNullOrWhiteSpace(stage) || string.IsNullOrWhiteSpace(requirementKey))
            return (new Refusal("stage and requirement_key are required"), null);

        var gate = await _store.FindFileGateAsync(dealId!.Value, stage, requirementKey, ct);
        if (gate is null) return (new Refusal("That stage does not ask for a file with that requirement."), null);

        return (null, await _store.LinkGateAsync(att, gate.Value.Stage, gate.Value.RequirementKey, callerId, ct));
    }

    /// <summary>Removes a gate link; the file stays. Idempotent. Stage / key are matched as given (case-insensitively resolved like a link).</summary>
    public async Task<Refusal?> UnlinkGateAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, Guid attachmentId, string? stage, string? requirementKey, CancellationToken ct = default)
    {
        var (att, dealId, refusal) = await GateLinkTargetAsync(ctx, perms, attachmentId, ct);
        if (refusal is not null) return refusal;
        if (string.IsNullOrWhiteSpace(stage) || string.IsNullOrWhiteSpace(requirementKey))
            return new Refusal("stage and requirement_key are required");

        // The stored spelling is the playbook's own; if the gate no longer exists the link is removed as typed.
        var gate = await _store.FindFileGateAsync(dealId!.Value, stage, requirementKey, ct);
        await _store.UnlinkGateAsync(att.Id, gate?.Stage ?? stage.Trim(), gate?.RequirementKey ?? requirementKey.Trim(), ct);
        return null;
    }

    /// <summary>The file, and the DEAL whose gates it may meet: the lead itself for a file on the lead record, or the quote's own lead for
    /// a file on one of that deal's quotes (E13: a generated proposal's PDF is a quote file). Any other record's files stay refused.</summary>
    private async Task<(SalesApi.Models.Attachment? Att, Guid? DealId, Refusal? Refusal)> GateLinkTargetAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, Guid attachmentId, CancellationToken ct)
    {
        var notFound = new Refusal("Attachment not found", NotFound: true);
        var att = await _store.FindAsync(attachmentId, ct);
        if (att is null) return (null, null, notFound);
        var (resolved, refusal) = await ResolveAsync(ctx, perms, att.RecordType, att.RecordId, ct);
        if (refusal is not null) return (null, null, notFound);
        if (att.RecordType is not (AttachmentRecordType.Lead or AttachmentRecordType.Quote) || resolved!.LeadId is not Guid dealId)
            return (null, null, new Refusal("Only a file on a deal or on one of its quotes can meet a deal's file requirement."));
        if (att.Kind == AttachmentKind.SharePointLink)
            return (null, null, new Refusal("A SharePoint link cannot meet a file requirement: upload the file instead."));
        return (att, dealId, null);
    }

    public IReadOnlyList<string> AvailableStorageProviders => _store.AvailableStorageProviders;

    public Task<AttachmentStorageProviderDto> CurrentStorageProviderAsync(Guid? orgId, CancellationToken ct = default) =>
        StorageProviderDtoAsync(orgId, ct);

    private async Task<AttachmentStorageProviderDto> StorageProviderDtoAsync(Guid? orgId, CancellationToken ct) =>
        new(await _store.CurrentStorageProviderAsync(orgId, ct), _store.AvailableStorageProviders);

    public sealed record SetStorageProviderResult(bool Valid, AttachmentStorageProviderDto? Dto = null);

    public async Task<SetStorageProviderResult> SetStorageProviderAsync(Guid? orgId, string? provider, CancellationToken ct = default)
    {
        if (!_store.IsKnownStorageProvider(provider)) return new SetStorageProviderResult(false);
        var saved = await _store.SetStorageProviderAsync(orgId, provider, ct);
        return new SetStorageProviderResult(true, new AttachmentStorageProviderDto(saved, _store.AvailableStorageProviders));
    }

    public Task<CardScanRetentionDto> GetCardScanRetentionAsync(CancellationToken ct = default) =>
        _store.GetCardScanRetentionAsync(ct);

    public async Task<CardScanRetentionDto> SetCardScanRetentionAsync(string? mode, int? retentionDays, CancellationToken ct = default)
    {
        var current = await _store.GetCardScanRetentionAsync(ct);
        return await _store.SaveCardScanRetentionAsync(
            new CardScanRetentionDto(mode ?? current.Mode, retentionDays ?? current.RetentionDays), ct);
    }

    // What happens to a record's files when the record is deleted — same Get / merge-over-current Set as the card-scan setting.
    public Task<DeletedRecordRetentionDto> GetDeletedRecordRetentionAsync(CancellationToken ct = default) =>
        _store.GetDeletedRecordRetentionAsync(ct);

    public async Task<DeletedRecordRetentionDto> SetDeletedRecordRetentionAsync(string? mode, int? retentionDays, CancellationToken ct = default)
    {
        var current = await _store.GetDeletedRecordRetentionAsync(ct);
        return await _store.SaveDeletedRecordRetentionAsync(
            new DeletedRecordRetentionDto(mode ?? current.Mode, retentionDays ?? current.RetentionDays), ct);
    }
}

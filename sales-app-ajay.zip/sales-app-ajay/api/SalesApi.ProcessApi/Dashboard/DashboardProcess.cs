using Microsoft.EntityFrameworkCore;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.Dashboard;

namespace SalesApi.ProcessLayer.Dashboard;

/// <summary>
/// The dashboard payload: the pipeline tiles, the month panel, the live
/// overdue/idle counts and the monthly target.
///
/// It reads PRE-AGGREGATED facts (`PipelineStats`, `MonthlyDealStats`) rather
/// than counting leads, which is why the whole thing is a handful of queries
/// instead of a scan. Two properties in here are easy to destroy and hard to
/// notice:
///
///  - **Every aggregate carries a TEAM dimension**, so a key is no longer
///    unique: several rows can share one (owner, stage). Every reader here
///    `Sum`s or `GroupBy`s rather than assuming one row — reintroducing a
///    `Single`/`First` would throw for any org with more than one team, and
///    only for those orgs.
///  - **`PipelineStats.TeamId` is sentinel-keyed to `Guid.Empty` for "no
///    team"**, which is exactly the value the `teamId` filter carries when a
///    user picks "No team". That is why one `== teamId` comparison serves both
///    a real team and the sentinel with no special case.
///
/// The month panel deliberately does NOT re-scope to the selected range: it is
/// always the current calendar month, and the client hides it under Year and
/// All-time rather than letting the figure pretend to follow the picker.
///
/// Takes the caller's scope as DATA (`people`, `statsPeople`, `teamId`,
/// `valuesVisible`) — the controller resolves those, because who may see which
/// rows is an authorization question.
/// </summary>
public sealed class DashboardProcess
{
    private readonly MeasureCalculator _measures;
    private readonly ForecastReader _forecast;
    private readonly DashboardStore _store;
    private readonly PipelineStages _stages;
    private readonly PlaybookPhaseLoader _phaseLoader;
    private readonly PeopleScopeReader _peopleScope;
    private readonly LeadWorkStatusReader _workStatus;
    // Layering round 3 (owner decision 2026-09-30): the only remaining _db uses
    // in this class were ForecastService.GetAsync/MeasureRegistry reads — once
    // those moved behind MeasureCalculator/ForecastReader, AppDbContext had no
    // other job here, so it is dropped and every other collaborator (which
    // still hold their OWN AppDbContext internally) becomes required, same as
    // round 2's rule for a class whose last _db use disappears.
    public DashboardProcess(
        MeasureCalculator measures, ForecastReader forecast, DashboardStore store,
        PipelineStages stages, PlaybookPhaseLoader phaseLoader, PeopleScopeReader peopleScope,
        LeadWorkStatusReader workStatus)
    {
        _measures = measures;
        _forecast = forecast;
        _store = store;
        _stages = stages;
        _phaseLoader = phaseLoader;
        _peopleScope = peopleScope;
        _workStatus = workStatus;
    }

    /// <summary>
    /// E18.1: the raw stored pipeline-snapshot rows, one per (owner, team, playbook, stage, account-field value), in the caller's scope - the SAME
    /// <see cref="DashboardStore.PipelineStatsAsync"/> read the dashboard's tiles fold over, with the dimension left unfolded. Values are masked here, at
    /// the edge, after the rows were read with real values (counts are never masked).
    /// </summary>
    public async Task<PipelineByAccountFieldDto> PipelineByAccountFieldAsync(List<Guid>? statsPeople, Guid? teamId, bool valuesVisible)
    {
        var rows = await _store.PipelineStatsAsync(statsPeople, teamId);
        return new PipelineByAccountFieldDto(
            await _store.AccountDimensionAsync(), valuesVisible,
            rows.OrderBy(r => r.Status, StringComparer.Ordinal).ThenBy(r => r.AccountDim, StringComparer.Ordinal).ThenBy(r => r.UserId)
                .Select(r => new PipelineByAccountFieldRowDto(
                    r.UserId, r.TeamId, r.PlaybookId, r.Status, r.AccountDim, r.LeadCount, valuesVisible ? r.LeadValue : 0))
                .ToList());
    }

    /// <summary>
    /// E18.1: the raw stored stage-entry rows for the org-local months covering <paramref name="fromDay"/>..<paramref name="toDay"/> (dates are already the
    /// org's local days; each is widened to its month), in the caller's scope. Counts only, so nothing to mask.
    /// </summary>
    public async Task<StageEntriesDto> StageEntriesAsync(DateOnly fromDay, DateOnly toDay, List<Guid>? statsPeople, Guid? teamId)
    {
        var rows = await _store.StageEntriesAsync((fromDay.Year, fromDay.Month), (toDay.Year, toDay.Month), statsPeople, teamId);
        return new StageEntriesDto(
            await _store.AccountDimensionAsync(), $"{fromDay.Year:0000}-{fromDay.Month:00}", $"{toDay.Year:0000}-{toDay.Month:00}",
            rows.Select(r => new StageEntryRowDto(r.Year, r.Month, r.UserId, r.TeamId, r.PlaybookId, r.Status, r.AccountDim, r.EntryCount)).ToList());
    }

    /// <summary>
    /// E18.1 part 3: the raw stored AMC-renewal rows for the months covering <paramref name="fromDay"/>..<paramref name="toDay"/> (the org's local days),
    /// in the caller's scope. A month after <paramref name="today"/>'s month is flagged <c>Partial</c>. Both values are zeroed HERE, at the edge, for a
    /// caller without the money permission - the rows were read with real values and the counts are never masked.
    /// </summary>
    public async Task<AmcRenewalsDto> AmcRenewalsAsync(
        DateOnly fromDay, DateOnly toDay, DateOnly today, List<Guid>? statsPeople, Guid? teamId, bool valuesVisible)
    {
        var rows = await _store.AmcRenewalsAsync((fromDay.Year, fromDay.Month), (toDay.Year, toDay.Month), statsPeople, teamId);
        var thisMonth = today.Year * 12 + today.Month;
        return new AmcRenewalsDto(
            $"{fromDay.Year:0000}-{fromDay.Month:00}", $"{toDay.Year:0000}-{toDay.Month:00}", valuesVisible,
            rows.Select(r => new AmcRenewalRowDto(
                r.Year, r.Month, r.UserId, r.TeamId, r.PlaybookId, r.DueCount, r.RenewedCount,
                valuesVisible ? r.DueValue : 0, valuesVisible ? r.RenewedValue : 0, r.Year * 12 + r.Month > thisMonth)).ToList());
    }

    public async Task<DashboardDto> AggregatedAsync(
        List<Guid>? people, List<Guid>? statsPeople, string period,
        CalendarDto cal, DateTime now, int idleDays, bool valuesVisible, Guid? teamId = null)
    {
        // Owner decision C4 (2026-09-25 follow-up, to-do/numbers-audit-decisions.md):
        // "month" means the calendar month here, not the old rolling 30 days —
        // see ReportPeriod's own class comment. `week`/`year` are likewise
        // calendar; `last_7_days`/`last_30_days` are the two NEW names for the
        // rolling windows "week"/"month" used to mean.
        var periodKind = ReportPeriod.Parse(period);
        var probs = await _forecast.GetAsync();

        // Current pipeline state: one row per (owner, stage, team). A rep sees
        // their own rows; a manager sees the org's and sums across reps.
        // PipelineStats.TeamId is the lead's LIVE team (unlike the closed-deal
        // grains below) and already sentinel-keyed to Guid.Empty for "no
        // team" — the exact value `teamId` carries when "No team" is
        // selected — so the same `== teamId` filter serves both a real team
        // and that sentinel with no translation.
        var pipe = await _store.PipelineStatsAsync(statsPeople, teamId);

        var counts = pipe
            .GroupBy(r => r.Status)
            .ToDictionary(g => g.Key, g => (
                count: g.Sum(r => r.LeadCount),
                value: g.Sum(r => r.LeadValue),
                playbooks: PlaybooksOf(g.Where(r => r.LeadCount > 0).Select(r => (Guid?)r.PlaybookId))));
        // D5: "open" belongs to a lead's OWN playbook, not to the org's stage
        // list. This used to be one flat StageService.OpenKeysAsync(_db) set
        // tested against every row — which silently dropped any lead whose
        // playbook names its open stages something the org list has never heard
        // of. Found in production: a team tile read ~200 open leads while one
        // owner on that team had 252, because 307 leads on `proposal_sent` and
        // `demo_scheduled` matched nothing in an org list that only knows
        // `proposal` and `demo`. PipelineStats is keyed by PlaybookId precisely
        // so a reader can tell those apart — this is that reader finally doing
        // it. Same fix shape as ScorecardProcess/ReportsProcess/Leaderboard.
        var openByPlaybook = await _stages.OpenKeysByPlaybookAsync(
            pipe.Select(r => (Guid?)r.PlaybookId));
        bool IsOpenStatus(Guid playbookId, string status) =>
            openByPlaybook.TryGetValue(playbookId, out var keys) && keys.Contains(status);

        var openRows = pipe.Where(r => IsOpenStatus(r.PlaybookId, r.Status)).ToList();
        var totalLeads = pipe.Sum(r => r.LeadCount);
        var openLeads = openRows.Sum(r => r.LeadCount);
        var openValue = openRows.Sum(r => r.LeadValue);
        var weightedForecast = openRows.Sum(r => r.LeadValue * (decimal)probs.GetValueOrDefault(r.Status, 0));
        // Time-crossing counts, computed LIVE. There is no stored counterpart to
        // read: PipelineStats used to carry OverdueCount/IdleCount and no longer
        // does (batch 6 dropped them — see Models/PipelineStats.cs).
        //
        // These two move with the clock, not with a write, so a stored column
        // could only ever be as fresh as that owner's last lead write or the
        // nightly roll. The tag-filtered path below has no aggregate to read and
        // has always counted live — so applying a tag that EVERY lead carries,
        // which should change nothing at all, moved these two tiles. Two indexed
        // counts over the open stages is the price of the two paths agreeing, and
        // it is the same work the tag path was already doing.
        var (overdue, idle) = await LiveOverdueIdleAsync(statsPeople, now, idleDays, teamId);

        var today = ReportingCalendar.Today(cal);
        var (thisYear, thisMonth) = ReportingCalendar.MonthOf(cal, now);

        int wonLeads; decimal wonValue; int lostLeads; double winRate;
        if (periodKind == ReportPeriod.Kind.All)
        {
            // The exact grain/fix GET /reports/leaderboard's "all" branch and
            // MeasureRegistry.AllTimeTotalsAsync already carry: PipelineStats
            // summed over every SOLD status, not just one — answerable from the
            // existing snapshot aggregate, no scan of `leads` at all.
            var allTimeScope = MeasureScope.AllTime(statsPeople, teamId);
            wonLeads = (int)((await _measures.ComputeAsync(MeasureRegistry.Keys.WonCount, allTimeScope)) ?? 0);
            wonValue = (await _measures.ComputeAsync(MeasureRegistry.Keys.WonValue, allTimeScope)) ?? 0;
            lostLeads = (int)((await _measures.ComputeAsync(MeasureRegistry.Keys.LostCount, allTimeScope)) ?? 0);
            winRate = (double?)await _measures.ComputeAsync(MeasureRegistry.Keys.WinRate, allTimeScope) ?? 0;
        }
        else
        {
            // Every other Kind — Week/Month/Year (CALENDAR, owner decision C4)
            // and Last7Days/Last30Days (ROLLING, what "week"/"month" used to
            // mean here) — is just a [start, end) range through the SAME
            // measure registry read. The registry (Services/MeasureRegistry.cs)
            // is the one place that knows a whole-calendar-month-or-year range
            // reads MonthlyDealStats/MonthlyDealStatsOrg
            // (MatchingMonthlyWindowAsync) and a rolling 7/30-day range ending
            // today reads RollingDealStats (MatchingRollingWindowDaysAsync);
            // this method never names either table. A calendar WEEK matches
            // neither stored grain (it isn't month-aligned and its start isn't
            // `today - 6/29`), so it falls through to
            // DealStatsService.LiveTotalsAsync — correct, and the only grain
            // choice for a window this codebase doesn't pre-aggregate.
            // MeasureRegistryParityTests/DashboardRangeTests pin the Year/
            // rolling cases; DashboardMonthCalendarTests (this change) pins
            // the new Month/Week calendar cases, including a still-open
            // (month-to-date) window.
            var window = ReportPeriod.WindowFor(periodKind, cal, now)!.Value;
            var scope = MeasureScope.Window(window.Start, window.End, statsPeople, teamId);
            wonLeads = (int)((await _measures.ComputeAsync(MeasureRegistry.Keys.WonCount, scope)) ?? 0);
            wonValue = (await _measures.ComputeAsync(MeasureRegistry.Keys.WonValue, scope)) ?? 0;
            lostLeads = (int)((await _measures.ComputeAsync(MeasureRegistry.Keys.LostCount, scope)) ?? 0);
            winRate = (double?)await _measures.ComputeAsync(MeasureRegistry.Keys.WinRate, scope) ?? 0;
        }

        // The monthly goal stays on the calendar month (that's what a target
        // is), read from the monthly grain rather than the rolling windows —
        // UNCHANGED: still today's calendar month regardless of which range the
        // caller selected. The Year/All-time tiles above re-scope; this panel
        // does not, and the frontend hides it under those two ranges instead
        // (see dashboard.tsx) rather than this figure pretending to re-scope.
        var monthlyWon = await _store.MonthlyWonAsync(thisYear, thisMonth, statsPeople, teamId);
        var monthlyTarget = await MonthlyTargetAsync(people, cal, now, teamId);

        // E3.10 — same scope/team filter and masking as the tiles above,
        // through the SAME MeasureRegistry keys; see ComparisonAsync's own
        // comment for exactly what "comparable" means.
        var comparison = await ComparisonAsync(periodKind, cal, now, statsPeople, teamId, valuesVisible);

        return new DashboardDto
        {
            TotalLeads = totalLeads,
            OpenLeads = openLeads,
            WonLeads = wonLeads,
            LostLeads = lostLeads,
            ValuesVisible = valuesVisible,
            OpenValue = valuesVisible ? openValue : 0,
            WonValue = valuesVisible ? wonValue : 0,
            WinRate = winRate,
            OverdueFollowUps = overdue,
            IdleLeads = idle,
            IdleDays = idleDays,
            MonthlyTarget = valuesVisible ? monthlyTarget : 0,
            MonthlyWon = valuesVisible ? monthlyWon : 0,
            WeightedForecast = valuesVisible ? weightedForecast : 0,
            ByStatus = counts.Select(kv => new StatusBucket(kv.Key, kv.Value.count, valuesVisible ? kv.Value.value : 0, kv.Value.playbooks)).ToList(),
            Comparison = comparison,
        };
    }

    // E3.10 — the prior-period comparison for the four closed-deal tiles
    // (won/lost count+value) plus win rate. Null for period=all: there is no
    // "the window before all time". Every prior value is read through the
    // SAME MeasureRegistry key, grain-selection and scope the CURRENT tile
    // used above — this asks the registry for a different [start, end), never
    // a second, independently-computed figure.
    private async Task<DashboardComparisonDto?> ComparisonAsync(
        ReportPeriod.Kind periodKind, CalendarDto cal, DateTime now, List<Guid>? statsPeople, Guid? teamId, bool valuesVisible)
    {
        if (periodKind == ReportPeriod.Kind.All) return null;

        // The org's own floor: a prior window that ends before the first lead
        // was ever created has nothing to compare against, not a real zero —
        // decision #2's "no baseline -> no change shown". Null (no leads at
        // all, ever) makes every prior window incomparable, which is correct:
        // an empty org has no earlier data by definition.
        var firstDataAt = await _store.FirstLeadCreatedAtAsync();

        async Task<KpiComparisonValue> ValueAsync(string key, ReportPeriod.ComparisonMode mode, bool masked)
        {
            if (masked) return new KpiComparisonValue(null, false);
            var window = ReportPeriod.PriorWindowFor(periodKind, cal, now, mode);
            if (window is null) return new KpiComparisonValue(null, false);
            if (firstDataAt is null || window.Value.End <= firstDataAt) return new KpiComparisonValue(null, false);

            var scope = MeasureScope.Window(window.Value.Start, window.Value.End, statsPeople, teamId);
            var v = await _measures.ComputeAsync(key, scope);
            // v is null for win_rate with nothing closed in that window — no
            // baseline, same reading as the "predates first data" case above.
            // v == 0 is a REAL zero (something closed, nothing won/lost/whatever
            // this key counts) — still "not comparable" per decision #2, so a
            // client never has to divide by it and produce +Inf% or a
            // misleading +100%.
            if (v is null || v == 0) return new KpiComparisonValue(v, false);
            return new KpiComparisonValue(v, true);
        }

        async Task<KpiComparisonDto> PairAsync(string key, bool masked = false) => new(
            await ValueAsync(key, ReportPeriod.ComparisonMode.Previous, masked),
            await ValueAsync(key, ReportPeriod.ComparisonMode.LastYear, masked));

        return new DashboardComparisonDto(
            WonCount: await PairAsync(MeasureRegistry.Keys.WonCount),
            WonValue: await PairAsync(MeasureRegistry.Keys.WonValue, masked: !valuesVisible),
            LostCount: await PairAsync(MeasureRegistry.Keys.LostCount),
            LostValue: await PairAsync(MeasureRegistry.Keys.LostValue, masked: !valuesVisible),
            WinRate: await PairAsync(MeasureRegistry.Keys.WinRate));
    }

    // The tag-filtered path: computed live from Leads/LeadTags rather than the
    // aggregate tables, because none of those tables carry a tag dimension.
    // Every figure the aggregated path reports is derivable from Lead's own
    // columns (Status, EstimatedValue, WonAt, LostAt, NextFollowUpAt,
    // UpdatedAt) EXCEPT ONE: MonthlyTarget is a person's assigned revenue goal
    // for the period (Target.Amount) — a fixed number that does not decompose
    // by which leads happen to carry a tag. Scoping it "by tag" would mean
    // inventing a fraction of a quota the org never set, so it is deliberately
    // left UNFILTERED here, same value as the aggregated path returns. Every
    // other figure is a real count/sum over exactly the tagged, visible leads.
    public async Task<DashboardDto> TagFilteredAsync(
        List<Guid>? people, List<Guid>? statsPeople, List<Guid> tagIds, string period,
        CalendarDto cal, DateTime now, int idleDays, bool valuesVisible, Guid? teamId = null)
    {
        // Same Kind vocabulary as AggregatedAsync above — see ReportPeriod's
        // class comment and that method's own comment for why "month" is now
        // calendar (owner decision C4) and last_7_days/last_30_days are the
        // new names for the rolling windows it used to mean.
        var periodKind = ReportPeriod.Parse(period);

        var probs = await _forecast.GetAsync();
        var idleCutoff = now.AddDays(-idleDays);

        // wonFrom/wonTo bound the SAME `InWindow` fold below for every Kind —
        // this path is already a live scan (no aggregate here carries a tag
        // dimension), so a calendar week/month/year is just a wider or
        // differently-anchored half-open range on that identical fold, and
        // "all time" is that range with no floor and no ceiling. It used to be
        // `now.AddDays(-30)` for "month" — a rolling INSTANT, so a deal closed
        // 30 days ago at 09:00 was inside one path's window and outside the
        // other's for nine hours every day, and the org's midnight was ignored
        // entirely; ReportPeriod.WindowFor fixes both at once.
        var (tagYear, tagMonth) = ReportingCalendar.MonthOf(cal, now);
        DateTime wonFrom, wonTo;
        if (periodKind == ReportPeriod.Kind.All)
        {
            wonFrom = DateTime.MinValue;
            wonTo = DateTime.MaxValue;
        }
        else
        {
            (wonFrom, wonTo) = ReportPeriod.WindowFor(periodKind, cal, now)!.Value;
        }
        var monthStart = ReportingCalendar.StartOfMonthUtc(cal, tagYear, tagMonth);
        var monthEnd = ReportingCalendar.EndOfMonthUtc(cal, tagYear, tagMonth);

        // Own leads plus everything the caller's team scope opens up — the same
        // owner set the aggregated path reads, including the unassigned queue
        // where the caller may see it. `statsPeople` carries the sentinel; on
        // `leads` that means a NULL owner_id.
        // Same frozen-team key DealStatsService.TeamKey/MeasureRegistry.ScopedLeads
        // use: ClosedTeamId once a deal has closed, falling back to the lead's
        // current TeamId for everything still open (which has no ClosedTeamId
        // yet). The sentinel (Guid.Empty, "No team") translates to a null check
        // since Lead's own columns are nullable, unlike the aggregate tables'.
        var leads = await _store.TagFilteredLeadsAsync(statsPeople, teamId, tagIds, AggregateOwner.Unassigned);

        // D5 (latent half): won/lost/sold here used to be a single org-wide
        // StagePhases tested against every lead's status — correct only while
        // every playbook reuses the org's "won"/"lost" keys. Resolve each
        // lead's own playbook now that the fetch has PlaybookId in hand.
        var phases = await _phaseLoader.LoadAsync(leads.Select(l => (Guid?)l.PlaybookId));

        var totalLeads = leads.Count;
        // Built-in Closed value: a status bucket's value is the won figure for
        // the leads in it that are currently sold (per THEIR OWN playbook —
        // two leads sharing a literal status string can still differ there)
        // and the plain estimate for everything else, same split every other
        // won-value site in this file makes.
        var byStatus = leads.GroupBy(l => l.Status)
            .ToDictionary(g => g.Key, g => (
                count: g.Count(),
                value: g.Sum(l => phases.IsSold(l.PlaybookId, l.Status) ? Lead.WonValue(l.ClosedValue, l.EstimatedValue) : l.EstimatedValue),
                playbooks: PlaybooksOf(g.Select(l => l.PlaybookId))));
        // The SAME per-playbook resolution the aggregated path above does. Both
        // paths have to move together: they were wrong in the SAME way, so
        // DashboardTagParityTests kept passing while both under-counted, and
        // fixing one alone would break that parity for a genuine reason.
        var openByPlaybook = await _stages.OpenKeysByPlaybookAsync(leads.Select(l => l.PlaybookId));
        bool IsOpenStatus(Guid? playbookId, string status) =>
            openByPlaybook.TryGetValue(playbookId ?? Guid.Empty, out var keys) && keys.Contains(status);

        var openRows = leads.Where(l => IsOpenStatus(l.PlaybookId, l.Status)).ToList();
        var openLeads = openRows.Count;
        var openValue = openRows.Sum(l => l.EstimatedValue);
        var weightedForecast = openRows.Sum(l => l.EstimatedValue * (decimal)probs.GetValueOrDefault(l.Status, 0));
        var overdue = openRows.Count(l => l.NextFollowUpAt != null && l.NextFollowUpAt < now);
        // S5 — a lead nobody has ever worked (no logged activity, no recorded
        // stage change) is never idle, however old — see LeadWorkStatusService.
        // L1 (accounts rework): idle is measured from the lead's last CONTACT (the shared rule, incl. synced mail and
        // meetings), never-contacted from CreatedAt - no longer from UpdatedAt ("not edited").
        // 2026-10-15 (B): one COUNT in SQL over the same tag/owner/team scope (LeadAttention.Idle) instead of a contact
        // lookup over every open lead id. The tag path already holds these rows for its OTHER figures, so overdue stays a
        // free in-memory count over them.
        var idle = await _store.TagFilteredIdleCountAsync(
            statsPeople, teamId, tagIds, AggregateOwner.Unassigned,
            await _phaseLoader.LoadAllAsync(), now, idleCutoff);

        // Dated and classified exactly as DealStatsService.CloseKey does it, so
        // the two paths agree on WHICH deals closed and WHEN.
        //
        // This used to be `WonAt != null` with the status ignored entirely, wrong
        // twice over: a REOPENED deal keeps its WonAt (see H6) and counted as won
        // here while the aggregate, which asks SoldKeys, correctly did not; and
        // any sold deal whose WonAt is NULL — every one this batch's C7 backfill
        // exists to date — reached the aggregate through `WonAt ?? UpdatedAt` and
        // was invisible here.
        DateTime CloseOf(Guid? playbookId, string status, DateTime? wonAt, DateTime? lostAt, DateTime updatedAt) =>
            phases.IsSold(playbookId, status) ? (wonAt ?? updatedAt) : (lostAt ?? updatedAt);
        bool InWindow(DateTime at, DateTime from, DateTime to) => at >= from && at < to;

        var wonInWindow = leads
            .Where(l => phases.IsSold(l.PlaybookId, l.Status)
                && InWindow(CloseOf(l.PlaybookId, l.Status, l.WonAt, l.LostAt, l.UpdatedAt), wonFrom, wonTo))
            .ToList();
        var lostInWindow = leads
            .Count(l => phases.IsLost(l.PlaybookId, l.Status)
                && InWindow(CloseOf(l.PlaybookId, l.Status, l.WonAt, l.LostAt, l.UpdatedAt), wonFrom, wonTo));
        var wonLeads = wonInWindow.Count;
        var wonValue = wonInWindow.Sum(l => Lead.WonValue(l.ClosedValue, l.EstimatedValue));
        var lostLeads = lostInWindow;
        var closed = wonLeads + lostLeads;

        // The calendar month, bounded at BOTH ends like the monthly grain is. The
        // open end used to let a deal dated into a future month (a corrected close
        // date, a clock skew) into this month's total on one path only.
        var monthlyWon = leads
            .Where(l => phases.IsSold(l.PlaybookId, l.Status)
                && InWindow(CloseOf(l.PlaybookId, l.Status, l.WonAt, l.LostAt, l.UpdatedAt), monthStart, monthEnd))
            .Sum(l => Lead.WonValue(l.ClosedValue, l.EstimatedValue));
        // Deliberately NOT tag-filtered — see this method's own comment. (It
        // IS team-filtered, same as the aggregated path — a target is still a
        // real per-person quota, just summed over a team's roster instead of
        // everyone the caller can see.)
        var monthlyTarget = await MonthlyTargetAsync(people, cal, now, teamId);

        return new DashboardDto
        {
            TotalLeads = totalLeads,
            OpenLeads = openLeads,
            WonLeads = wonLeads,
            LostLeads = lostLeads,
            ValuesVisible = valuesVisible,
            OpenValue = valuesVisible ? openValue : 0,
            WonValue = valuesVisible ? wonValue : 0,
            WinRate = closed > 0 ? (double)wonLeads / closed : 0,
            OverdueFollowUps = overdue,
            IdleLeads = idle,
            IdleDays = idleDays,
            MonthlyTarget = valuesVisible ? monthlyTarget : 0,
            MonthlyWon = valuesVisible ? monthlyWon : 0,
            WeightedForecast = valuesVisible ? weightedForecast : 0,
            ByStatus = byStatus.Select(kv => new StatusBucket(kv.Key, kv.Value.count, valuesVisible ? kv.Value.value : 0, kv.Value.playbooks)).ToList(),
        };
    }

    // The playbooks a status bucket's leads belong to, for StatusBucket.PlaybookIds.
    // PipelineStats keys "no playbook" as Guid.Empty; the wire says null, the same
    // value a lead's own playbook_id carries and the client's org-list bucket is keyed by.
    // Ordered so the payload is stable between identical reads.
    private static List<Guid?> PlaybooksOf(IEnumerable<Guid?> playbookIds) =>
        playbookIds
            .Select(p => p == Guid.Empty ? null : p)
            .Distinct()
            .OrderBy(p => p ?? Guid.Empty)
            .ToList();

    /// <summary>
    /// Overdue follow-ups and idle leads over the open stages, counted live for
    /// the same owner set the rest of the aggregated path reads. See the call
    /// site for why these are no longer read off PipelineStats.
    /// </summary>
    private async Task<(int Overdue, int Idle)> LiveOverdueIdleAsync(
        List<Guid>? statsPeople, DateTime now, int idleDays, Guid? teamId = null)
    {
        var idleCutoff = now.AddDays(-idleDays);
        // 2026-10-15 aggregate audit (B): TWO COUNTs in SQL. This used to load every
        // lead in scope, then ask for the last-contact of every OPEN lead id (an
        // ANY(@ids) list the size of the pipeline) and fold in memory.
        //
        // D5: open-ness is per playbook (a lead's status resolves against ITS OWN
        // playbook's stage list), carried by PlaybookPhases.Matching - a predicate
        // that translates to SQL. Every playbook is loaded because the scan can reach
        // any of them (MovementProcess's reasoning). A lead that is still OPEN has no
        // ClosedTeamId yet, so the store's team filter reads its current TeamId.
        // Idle = last CONTACT (LastContactService, the shared rule) older than the
        // cutoff, never-contacted measured from CreatedAt, and only leads somebody has
        // ever worked (S5): see LeadAttention.
        var phases = await _phaseLoader.LoadAllAsync();
        return await _store.LiveOverdueIdleCountsAsync(
            statsPeople, teamId, AggregateOwner.Unassigned, phases, now, idleCutoff);
    }

    private async Task<decimal> MonthlyTargetAsync(List<Guid>? people, CalendarDto cal, DateTime now, Guid? teamId = null)
    {
        // Same period key TargetsController.CurrentPeriod produces, from the same
        // calendar — a target set for "2026-09" must not be read a month early
        // because the server happened to ask at 21:00 UTC on the 31st.
        var targetPeriod = ReportingCalendar.PeriodOf(cal, now);
        // `targets` carries no team column — it is a per-person quota, not a
        // per-record one — so "this team's target" can only mean "summed over
        // this team's ROSTER", the one dimension Target does have (UserId).
        // That is a genuinely different scoping mechanism from every other
        // figure on this page (PeopleScope.MembersOfTeamAsync, membership, not
        // AggregateOwner.WidenScope/Lead.TeamId, assignment) — the only one
        // available for this table, not a second reading of "team" smuggled in
        // beside the assignment-based one every other figure here uses (see
        // PipelineStatsService.TeamKey; that reading is about closed-deal
        // attribution, unrelated to this table). A team with no members (or
        // the "No team" sentinel, which names no roster) sums to zero, which
        // is the honest answer — this org has no per-team quota concept.
        var scopedPeople = people;
        if (teamId is Guid tid && tid != AggregateOwner.Unassigned)
        {
            var members = await _peopleScope.MembersOfTeamAsync(tid);
            scopedPeople = people is null ? members : [.. people.Intersect(members)];
        }
        else if (teamId == AggregateOwner.Unassigned)
        {
            scopedPeople = [];
        }
        return await _store.TargetsSumAsync(targetPeriod, scopedPeople);
    }

    // GET/PUT /dashboard/forecast-config — FORWARDER. Per-stage win probability now
    // lives on the stage itself (StageDefDto.WinProbability, edited via
    // /settings/stages — see ForecastService's header comment for why and how
    // existing manager-entered values keep reading correctly across the merge).
    // This route is kept working, unchanged shape, for every existing caller —
    // the dashboard forecast weighting above and the shared forecast-config
    // screens (mobile/web/desktop) all still read/write it exactly as before.
}

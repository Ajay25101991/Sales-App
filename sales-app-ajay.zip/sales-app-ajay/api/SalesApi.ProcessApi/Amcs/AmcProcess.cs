using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.PricingModels;
using SalesApi.ProcessLayer.Proposals;
using SalesApi.Services;
using SalesApi.SystemLayer.Amcs;

namespace SalesApi.ProcessLayer.Amcs;

/// <summary>
/// Annual Maintenance Contracts: the business rules that used to live inline
/// in <c>AmcsController</c> — H15's value-change-vs-current-term policy, the
/// term open/close on renewal, the loyalty write, and people-scoping (AMCs
/// carry no team column, so they are scoped by the owners the caller can see,
/// same as <c>CollectionProcess</c> scopes by <c>RecordAccessContext</c>).
///
/// Layering round 4 (owner decision 2026-09-30): now fully <c>AppDbContext</c>-free
/// — <see cref="AmcStore"/> owns AMC/AmcTerm's own queries and writes, and the
/// org-wide System services this class needs (<see cref="ReportingCalendarService"/>,
/// <see cref="PeopleScopeReader"/>, <see cref="AmcServiceReader"/>, the loyalty
/// readers/writer) are each reached through their own injectable front rather
/// than a shared raw context.
/// </summary>
public sealed class AmcProcess
{
    private readonly AmcStore _store;
    private readonly ILogger<AmcProcess> _logger;
    private readonly PeopleScopeReader _peopleScope;


    private readonly ReportingCalendarService _reportingCalendar;

    private readonly DomainEventWriter _events;
    private readonly AmcServiceReader _amcService;
    private readonly LoyaltyPolicyReader _loyaltyPolicy;
    private readonly LoyaltyLedgerWriter _loyaltyLedger;
    // Null in the hand-built test call sites that never wire it: the deleted record's files are then not stamped.
    private readonly RecordFileRetention? _recordFiles;
    // E14.7: null in hand-built call sites that never wire it - a renewal then cannot be re-priced and says so in pricing_note.
    private readonly PricingModelProcess? _pricing;

    // Layering round 4 (owner decision 2026-09-30): the last remaining _db
    // uses here were AmcService.*/LoyaltyPolicyService/LoyaltyEarnRules/
    // LoyaltyLedgerService reads called straight through — once each moved
    // behind its own injectable front (AmcServiceReader/LoyaltyPolicyReader/
    // LoyaltyLedgerWriter), AppDbContext had no other job in this class, so
    // it is dropped and PeopleScopeReader (already registered in Program.cs)
    // becomes required, same as round 2/3's rule for a class whose last _db
    // use disappears.
    public AmcProcess(
        AmcStore store,
        ILogger<AmcProcess> logger,
        ReportingCalendarService reportingCalendar,
        DomainEventWriter events,
        PeopleScopeReader peopleScope,
        AmcServiceReader amcService,
        LoyaltyPolicyReader loyaltyPolicy,
        LoyaltyLedgerWriter loyaltyLedger,
        RecordFileRetention? recordFiles = null,
        PricingModelProcess? pricing = null)
    {
        _pricing = pricing;
        _store = store;
        _logger = logger;
        _peopleScope = peopleScope;
        _reportingCalendar = reportingCalendar;
        _events = events;
        _amcService = amcService;
        _loyaltyPolicy = loyaltyPolicy;
        _loyaltyLedger = loyaltyLedger;
        _recordFiles = recordFiles;
    }

    /// <summary>Why a request could not be carried out, or null when it can. A
    /// RESULT rather than an exception, same as <c>CollectionTaskProcess.Refusal</c>:
    /// an ordinary "not found" or "not allowed" must not become a 500.
    /// <paramref name="Forbidden"/> distinguishes AMCs' record-level "not allowed
    /// to manage THIS one" refusals (403) from an ordinary bad request (400) —
    /// the one case this domain's controller had that earlier ports didn't.</summary>
    public sealed record Refusal(string Reason, bool NotFound = false, bool Forbidden = false);

    public sealed record AmcOutcome(Refusal? Refusal, AmcDto? Amc)
    {
        public static AmcOutcome Refused(Refusal r) => new(r, null);
        public static AmcOutcome Ok(AmcDto a) => new(null, a);
    }

    public sealed record AmcTermOutcome(Refusal? Refusal, AmcTermDto? Term)
    {
        public static AmcTermOutcome Refused(Refusal r) => new(r, null);
        public static AmcTermOutcome Ok(AmcTermDto t) => new(null, t);
    }

    public sealed record AmcTermsOutcome(Refusal? Refusal, List<AmcTermDto>? Terms)
    {
        public static AmcTermsOutcome Refused(Refusal r) => new(r, null);
        public static AmcTermsOutcome Ok(List<AmcTermDto> t) => new(null, t);
    }

    public sealed record DeleteOutcome(Refusal? Refusal)
    {
        public static DeleteOutcome Refused(Refusal r) => new(r);
        public static readonly DeleteOutcome Ok = new((Refusal?)null);
    }

    // "Days to renewal" is whole calendar days in the ORG's timezone, not UTC's:
    // a renewal is "in 3 days" for everyone in the office all day, and does not
    // tick over at 04:00 local.
    private static AmcDto ToDto(Amc a, CalendarDto cal) =>
        new(a.Id, a.LeadId, a.Lead?.Name, a.Lead?.Company, a.Lead?.Email,
            a.OwnerId, a.Owner?.FullName, a.Title, a.ContractValue,
            a.StartDate, a.RenewalDate, ReportingCalendar.DaysUntilDate(cal, a.RenewalDate),
            a.Status, a.Notes, a.CreatedAt, a.UpdatedAt, a.AccountId, Label: a.Label);

    private static AmcTermDto TermToDto(AmcTerm t) =>
        new(t.Id, t.AmcId, t.StartDate, t.EndDate, t.ContractValue, t.InvoiceId, t.CreatedAt, t.PricingModelVersion);

    // "Raised", not "invoiced" (H15) — see Invoice.RaisedAt and
    // PaymentSettlement.SyncStatus: a still-DRAFT invoice's RaisedAt is null
    // forever, and a draft has never been billed to the customer, so it must
    // not count as history that blocks a price correction reaching the term.
    private static bool IsRaised(AmcTerm t) => t.Invoice?.RaisedAt != null;

    // AMCs carry no team column of their own, so they are scoped by PEOPLE — the
    // owners this caller can see (PeopleScope). An approximation of the record
    // predicate, and the honest one available: leaving them org-wide after leads
    // were scoped would expose another team's contracts.
    private Task<List<Guid>?> PeopleAsync(RecordAccessContext ctx, CancellationToken ct) =>
        _peopleScope.VisibleIdsAsync(ctx, ct);

    private static bool CanManage(Guid ownerId, List<Guid>? people) => people is null || people.Contains(ownerId);

    public async Task<List<AmcDto>> ListAsync(RecordAccessContext ctx, string? status, CancellationToken ct = default, Guid? leadId = null)
    {
        var people = await PeopleAsync(ctx, ct);
        var rows = await _store.ListAsync(people, status, ct, leadId);
        // Resolved once for the whole list, not once per row.
        var cal = await _reportingCalendar.ForAsync();
        return rows.Select(a => ToDto(a, cal)).ToList();
    }

    public Task<AmcReminderConfigDto> GetReminderConfigAsync(CancellationToken ct = default) =>
        _amcService.GetRemindersAsync();

    public async Task<AmcReminderConfigDto> SetReminderConfigAsync(AmcReminderConfigInput input, CancellationToken ct = default)
    {
        var cur = await _amcService.GetRemindersAsync();
        return await _amcService.SaveRemindersAsync(input.ApplyTo(cur));
    }

    public Task<AmcEmailTemplateDto> GetEmailTemplateAsync(CancellationToken ct = default) =>
        _amcService.GetEmailAsync();

    public Task<AmcEmailTemplateDto> SetEmailTemplateAsync(AmcEmailTemplateInput input, CancellationToken ct = default) =>
        _amcService.SaveEmailAsync(new AmcEmailTemplateDto(input.Subject ?? "", EmailBody.SanitizeIfHtml(input.Body)));

    public Task<int> GenerateAsync(CancellationToken ct = default) => _amcService.GenerateAsync();

    public async Task<AmcOutcome> GetAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default)
    {
        var people = await PeopleAsync(ctx, ct);
        var a = await _store.GetScopedAsync(people, id, ct);
        if (a is null) return AmcOutcome.Refused(new Refusal("AMC not found", NotFound: true));
        return AmcOutcome.Ok(ToDto(a, await _reportingCalendar.ForAsync()));
    }

    public async Task<AmcOutcome> CreateAsync(RecordAccessContext ctx, AmcInput input, CancellationToken ct = default)
    {
        if (input.LeadId is null) return AmcOutcome.Refused(new Refusal("lead_id is required"));
        var lead = await _store.LeadByIdAsync(input.LeadId.Value, ct);
        if (lead is null) return AmcOutcome.Refused(new Refusal("Customer not found", NotFound: true));
        if (!RecordAccess.CanManage(ctx, lead.OwnerId, lead.TeamId))
            return AmcOutcome.Refused(new Refusal("Not allowed to add an AMC for this customer", Forbidden: true));
        if (input.ContractValue is null or <= 0) return AmcOutcome.Refused(new Refusal("contract value is required"));
        // A support contract needs somebody accountable for it — claim the lead
        // out of the unassigned queue (POST /leads/{id}/assign) first.
        if (lead.OwnerId is not Guid amcOwnerId)
            return AmcOutcome.Refused(new Refusal("Assign an owner to this lead before adding an AMC."));

        var start = (input.StartDate ?? DateTime.UtcNow).ToUniversalTime();
        var renewal = (input.RenewalDate ?? start.AddYears(1)).ToUniversalTime();
        // The contract and its first term (D1) are shaped by AmcService.NewContract - the same builder the contract opened on a win uses.
        var (amc, firstTerm) = AmcService.NewContract(lead, amcOwnerId, input.Title, input.Label, input.ContractValue.Value, start, renewal, input.Notes, firstTermCoversDeal: input.CoversDeal == true);
        _store.AddAmc(amc);
        _store.AddTerm(firstTerm);
        await _store.SaveChangesAsync(ct);
        await _store.LoadLeadAndOwnerAsync(amc, ct);
        return AmcOutcome.Ok(ToDto(amc, await _reportingCalendar.ForAsync()));
    }

    public async Task<AmcTermsOutcome> TermsAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default)
    {
        var people = await PeopleAsync(ctx, ct);
        var a = await _store.GetScopedAsync(people, id, ct);
        if (a is null) return AmcTermsOutcome.Refused(new Refusal("AMC not found", NotFound: true));
        var terms = await _store.TermsForAmcAsync(id, ct);
        return AmcTermsOutcome.Ok(terms.Select(TermToDto).ToList());
    }

    public async Task<AmcOutcome> UpdateAsync(RecordAccessContext ctx, Guid id, AmcInput input, CancellationToken ct = default)
    {
        var a = await _store.GetWithLeadAndOwnerAsync(id, ct);
        if (a is null) return AmcOutcome.Refused(new Refusal("AMC not found", NotFound: true));
        var people = await PeopleAsync(ctx, ct);
        if (!CanManage(a.OwnerId, people))
            return AmcOutcome.Refused(new Refusal("Not allowed to edit this AMC", Forbidden: true));

        // H15: a value change must be decided against the term that's current
        // BEFORE any of today's other edits (e.g. a RenewalDate change in the
        // same request) move what "current" means.
        bool valueChanged = input.ContractValue is > 0 && input.ContractValue.Value != a.ContractValue;
        bool? reachedCurrentTerm = null;
        string? valueChangeNote = null;
        AmcTerm? currentTerm = valueChanged ? await _store.CurrentTermAsync(a, ct) : null;

        var titleBefore = a.Title; // the AMC's SharePoint folder is named for it
        if (input.Title != null) a.Title = input.Title.Trim().Length == 0 ? null : input.Title.Trim();
        if (input.Label != null) a.Label = input.Label.Trim().Length == 0 ? null : input.Label.Trim();
        _events.AmcTitleChanged(a.Id, ctx.UserId, titleBefore, a.Title);
        if (input.StartDate != null) a.StartDate = input.StartDate.Value.ToUniversalTime();
        if (input.RenewalDate != null) a.RenewalDate = input.RenewalDate.Value.ToUniversalTime();
        if (input.Notes != null) a.Notes = input.Notes;
        if (input.Status is "active" or "expired" or "cancelled") a.Status = input.Status;

        if (valueChanged)
        {
            var newValue = input.ContractValue!.Value;
            // Amc.ContractValue is always the number a manager just entered —
            // it's the headline figure AND the default the NEXT Renew() copies
            // onto its new term (see RenewAsync), so every policy updates it.
            // What the three policies disagree about is only whether the row
            // for the term that's open RIGHT NOW also moves.
            a.ContractValue = newValue;

            var policy = await _amcService.GetValueChangePolicyAsync();
            var raised = currentTerm != null && IsRaised(currentTerm);
            switch (policy)
            {
                case AmcService.AlwaysCurrentTerm:
                    currentTerm!.ContractValue = newValue;
                    reachedCurrentTerm = true;
                    break;
                case AmcService.NextRenewalOnly:
                    reachedCurrentTerm = false;
                    valueChangeNote = "The new value applies from the next renewal — org policy defers every value change, so the current term is unchanged.";
                    break;
                default: // CurrentUnlessRaised
                    if (!raised)
                    {
                        currentTerm!.ContractValue = newValue;
                        reachedCurrentTerm = true;
                    }
                    else
                    {
                        reachedCurrentTerm = false;
                        valueChangeNote = "This term's invoice has already been raised, so the new value applies from the next renewal instead.";
                    }
                    break;
            }
        }

        a.UpdatedAt = DateTime.UtcNow;
        await _store.SaveChangesAsync(ct);
        return AmcOutcome.Ok(ToDto(a, await _reportingCalendar.ForAsync()) with
        {
            ValueChangeReachedCurrentTerm = reachedCurrentTerm,
            ValueChangeNote = valueChangeNote,
        });
    }

    // PATCH /amcs/{id}/terms/{termId} — per-term value editor (H15). Lets a
    // negotiated/escalating schedule be expressed directly on the term history,
    // separate from the "does a value change on the AMC reach this term" policy
    // above. A term whose invoice has already been RAISED can't be edited here —
    // that invoice is the billed record of what the term cost; see IsRaised.
    public async Task<AmcTermOutcome> UpdateTermAsync(
        RecordAccessContext ctx, Guid id, Guid termId, AmcTermInput input, CancellationToken ct = default)
    {
        var a = await _store.GetByIdAsync(id, ct);
        if (a is null) return AmcTermOutcome.Refused(new Refusal("AMC not found", NotFound: true));
        var people = await PeopleAsync(ctx, ct);
        if (!CanManage(a.OwnerId, people))
            return AmcTermOutcome.Refused(new Refusal("Not allowed to edit this AMC", Forbidden: true));
        var term = await _store.GetTermAsync(id, termId, ct);
        if (term is null) return AmcTermOutcome.Refused(new Refusal("Term not found", NotFound: true));
        if (input.ContractValue is not > 0) return AmcTermOutcome.Refused(new Refusal("contract value is required"));
        if (IsRaised(term))
            return AmcTermOutcome.Refused(new Refusal("This term's invoice has already been raised and can't be changed here."));

        term.ContractValue = input.ContractValue.Value;
        // The current term also backs Amc.ContractValue, the field every
        // dashboard/reminder/report actually reads — keep them in sync so
        // editing the current term's row here shows up everywhere else too.
        if (term.EndDate == a.RenewalDate)
        {
            a.ContractValue = term.ContractValue;
            a.UpdatedAt = DateTime.UtcNow;
        }
        await _store.SaveChangesAsync(ct);
        return AmcTermOutcome.Ok(TermToDto(term));
    }

    public async Task<AmcValueChangePolicyDto> GetValueChangePolicyAsync(CancellationToken ct = default) =>
        new(await _amcService.GetValueChangePolicyAsync(), await _amcService.GetRenewalRepriceAsync());

    public async Task<AmcValueChangePolicyDto> SetValueChangePolicyAsync(AmcValueChangePolicyInput input, CancellationToken ct = default)
    {
        // Each half is saved only when sent, so the E14.7 toggle can be flipped without restating the policy (and the reverse). A body
        // with neither saves the policy as before (an unknown or missing value normalises to the default).
        if (input.Policy is not null || input.RenewalReprice is null) await _amcService.SaveValueChangePolicyAsync(input.Policy);
        if (input.RenewalReprice is bool on) await _amcService.SaveRenewalRepriceAsync(on);
        return await GetValueChangePolicyAsync(ct);
    }

    /// <summary>E14.7: the price the renewal term would carry from the latest PUBLISHED version of the pricing model that priced this
    /// contract's deal, or null with a Note saying why it could not be priced. Never throws for an ordinary failure (missing input, no
    /// published version, no priced proposal): the renewal goes ahead without it. The inputs are the ones a new quote version would use
    /// (<see cref="ProposalGenerateProcess.SuppliedInputsAsync"/>): the accepted proposal's frozen inputs, the deal's and the account's
    /// current values (child_count included). The pricing engine takes no date, so "on the renewal date" is simply now.</summary>
    private async Task<(decimal? Value, Guid? CatalogItemId, int? Version, string? Note)> RepriceAsync(RecordAccessContext ctx, Amc a, CancellationToken ct)
    {
        const string carried = "The previous term's value was carried over.";
        if (_pricing is null) return (null, null, null, $"Pricing is not available. {carried}");
        var snapshot = ProposalSnapshotJson.Read(await _store.AcceptedProposalSnapshotAsync(a.LeadId, ct));
        if (snapshot is null || snapshot.Services.Count == 0)
            return (null, null, null, $"This contract's deal has no accepted priced proposal, so there is no price list to follow. {carried}");
        if (snapshot.Services.Count > 1)
            return (null, null, null, $"This deal's proposal priced {snapshot.Services.Count} services, so the renewal cannot be priced from one price list. {carried}");

        var priced = snapshot.Services[0];
        var model = await _pricing.GetAsync(priced.CatalogItemId, ct);
        if (model.Value?.PublishedVersion is not int latest)
            return (null, null, null, $"{priced.Name} has no published pricing model. {carried}");
        var content = await _pricing.GetVersionAsync(priced.CatalogItemId, latest, ct);
        if (content.Value is null) return (null, null, null, $"{priced.Name}: pricing model version {latest} was not found. {carried}");

        var supplied = await ProposalGenerateProcess.SuppliedInputsAsync(
            _pricing, ctx, a.LeadId, a.Lead?.Custom, content.Value.Content.Inputs, priced, null, ct);
        var run = await _pricing.EvaluateVersionAsync(priced.CatalogItemId, latest, new PricingEvaluateInput(supplied, a.LeadId), ctx, ct);
        if (run.Outcome != PricingModelProcess.Outcome.Ok || run.Value is null)
            return (null, null, null, $"{priced.Name} could not be priced: {run.Error ?? "the pricing run failed."} {carried}");
        if (!run.Value.Ok || run.Value.DealValue is not { } value || value <= 0)
            return (null, null, null,
                $"{priced.Name} could not be priced: {run.Value.Issues.FirstOrDefault()?.Message ?? "the pricing model gave no value."} {carried}");
        return (value, priced.CatalogItemId, latest, null);
    }

    // POST /amcs/{id}/renew — close the current term and open a new one (D1),
    // then advance Amc.StartDate/RenewalDate to match the new term (unchanged
    // behavior for every existing reader of those two fields).
    //
    // E14.7: the new term's value is, in order: the value the rep sent in <paramref name="input"/>; else, when the org setting
    // "Renewals use the latest price list" is ON, the deal value of the latest published version of the pricing model that priced the
    // deal's proposal; else the contract's current value (today's behaviour, and the only one while the setting is off). A re-price that
    // cannot be done falls back to the last and says why in AmcDto.PricingNote - it never blocks the renewal. The H15 value-change policy
    // is about an EDIT reaching the term that is already open; a renewal opens a new, unbilled term, so the new value always lands on it
    // and the closing term is never touched, whichever policy is set.
    public async Task<AmcOutcome> RenewAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default, AmcRenewInput? input = null)
    {
        var a = await _store.GetWithLeadAndOwnerAsync(id, ct);
        if (a is null) return AmcOutcome.Refused(new Refusal("AMC not found", NotFound: true));
        var people = await PeopleAsync(ctx, ct);
        if (!CanManage(a.OwnerId, people))
            return AmcOutcome.Refused(new Refusal("Not allowed to renew this AMC", Forbidden: true));
        if (input?.ContractValue is <= 0) return AmcOutcome.Refused(new Refusal("contract value must be greater than zero"));

        var newValue = a.ContractValue;
        Guid? pricedItem = null;
        int? pricedVersion = null;
        string? pricingNote = null;
        if (input?.ContractValue is > 0) newValue = input.ContractValue.Value; // the rep's value wins
        else if (await _amcService.GetRenewalRepriceAsync())
        {
            var repriced = await RepriceAsync(ctx, a, ct);
            if (repriced.Value is { } v) (newValue, pricedItem, pricedVersion) = (v, repriced.CatalogItemId, repriced.Version);
            else pricingNote = repriced.Note;
        }

        // Ensures the closing term exists (see AmcStore.CurrentTermAsync) — its
        // return value isn't otherwise used here; RenewAsync doesn't edit the
        // outgoing term, only closes it and opens the next one.
        _ = await _store.CurrentTermAsync(a, ct);

        // Advance from the later of the current renewal date or today — today
        // in the ORG's timezone, so a renewal processed at 02:00 local on the 5th
        // does not restart the term on the 4th.
        // kind-safe: todayLocal is only ever compared in memory (line below) and
        // used to build newFrom/newRenewal, which are SpecifyKind'ed before
        // anything is written — it never itself binds into a query.
        var todayLocal = ReportingCalendar.Today(await _reportingCalendar.ForAsync())
            .ToDateTime(TimeOnly.MinValue);
        var from = a.RenewalDate.Date < todayLocal ? todayLocal : a.RenewalDate.Date;
        var newRenewal = DateTime.SpecifyKind(from.AddYears(1), DateTimeKind.Utc);
        var newFrom = DateTime.SpecifyKind(from, DateTimeKind.Utc);

        // The new term — this is what makes the renewal billable (D1): it
        // starts life with InvoiceId == null, so InvoicesController.BillableLeads
        // picks it up immediately. Kept as a local (not just added to the
        // tracker) so its DB-generated Id is available after SaveChanges below,
        // for the loyalty ledger's AmcTermId reference.
        var newTerm = new AmcTerm { AmcId = a.Id, StartDate = newFrom, EndDate = newRenewal, ContractValue = newValue,
            PricingCatalogItemId = pricedItem, PricingModelVersion = pricedVersion };
        _store.AddTerm(newTerm);

        // Amc.ContractValue backs the open term (see its remarks), so it follows the new term's value.
        a.ContractValue = newValue;
        a.StartDate = newFrom;
        a.RenewalDate = newRenewal;
        a.Status = "active";
        a.UpdatedAt = DateTime.UtcNow;

        // E1 step 3 (to-do/e1-event-backbone-design.md §5/§8): the inline
        // WebhookEvents.Keys.AmcRenewed enqueue that used to live here is
        // GONE — WebhookDomainEventHandler now reacts to the event below (off
        // the request thread) and rebuilds the same webhook payload from the
        // AMC's current row state.
        // E1.2 (to-do/e1-event-backbone-design.md §4) — every successful
        // renewal, unconditionally (unlike lead.won/invoice.paid there is no
        // "already renewed" state to guard against: reaching this line always
        // means one just happened).
        _events.Raise(DomainEventTypes.Keys.AmcRenewed, DomainEventTypes.AggregateTypes.Amc, a.Id, ctx.UserId,
            new DomainEventPayloads.AmcRenewed(a.Id, a.RenewalDate));

        await _store.SaveChangesAsync(ct);

        // Loyalty (P0-2). AFTER the line above, and NOT wrapped in the same
        // unit of work: the renewal is already committed (newTerm.Id is now
        // populated), and TryWriteAsync is its own isolated unit of work that
        // swallows any failure — see LoyaltyLedgerService's own remarks. A
        // bookkeeping row must never be able to undo a renewal the customer
        // already has. Unlike RecordPayment/Collect there is no "already
        // renewed" transition to guard: WebhookEvents.Keys.AmcRenewed's own
        // comment applies equally here — reaching this line always means one
        // renewal just happened, so it always qualifies. The earn rule is
        // resolved first, same order as before the move.
        var loyaltyPolicy = await _loyaltyPolicy.GetAsync(ct);
        var (_, amcRule) = await _loyaltyLedger.ResolveEarnRuleAsync(a.AccountId, loyaltyPolicy, ct);
        await _loyaltyLedger.TryWriteAsync(
            LoyaltyLedgerService.BuildFromAmcRenewal(loyaltyPolicy, a, newTerm, amcRule), _logger, ct);

        return AmcOutcome.Ok(ToDto(a, await _reportingCalendar.ForAsync()) with { PricingNote = pricingNote });
    }

    public async Task<DeleteOutcome> DeleteAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default)
    {
        var a = await _store.GetByIdAsync(id, ct);
        if (a is null) return DeleteOutcome.Refused(new Refusal("AMC not found", NotFound: true));
        var people = await PeopleAsync(ctx, ct);
        if (!CanManage(a.OwnerId, people))
            return DeleteOutcome.Refused(new Refusal("Not allowed to delete this AMC", Forbidden: true));
        var markedFiles = _recordFiles is null ? new List<Guid>() : await _recordFiles.MarkRecordsAsync(AttachmentRecordType.Amc, new[] { a.Id }, ct: ct);
        _store.RemoveAmc(a);
        await _store.SaveChangesAsync(ct);
        if (_recordFiles is not null) await _recordFiles.SettleAsync(markedFiles, ct);
        return DeleteOutcome.Ok;
    }
}

using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.DataAccessLog;

namespace SalesApi.ProcessLayer.DataAccessLog;

/// <summary>
/// The data access log's rules (E12.7): the filtered read, the one write path, and the device-launch check (E12.6, owner
/// decisions 11 and 13). Does NOT decide who may read the log or open WhatsApp on a device: both arrive as facts from the HTTP
/// layer (<c>data_access_log.view</c> is checked by the controller; <c>whatsapp.open_external</c> arrives as a bool).
///
/// Other Process classes that need to log (the E12.5 reveal steps, the E12.6 sends) call <see cref="RecordAsync"/> - one write
/// path, so the "never a value" rule has one home.
/// </summary>
public sealed class DataAccessLogProcess
{
    private readonly DataAccessLogStore _store;
    public DataAccessLogProcess(DataAccessLogStore store) => _store = store;

    public sealed record Refusal(string Reason, bool NotFound = false, bool Forbidden = false, string? Code = null);

    public const string ChannelNotPermittedCode = "channel_not_permitted";

    public async Task<(PagedResult<DataAccessLogEntryDto>? Page, Refusal? Refusal)> ListAsync(
        Guid? userId, string? action, string? recordType, Guid? recordId, DateTime? from, DateTime? to,
        string? cursor, int? limit, CancellationToken ct = default)
    {
        if (!string.IsNullOrWhiteSpace(action) && !DataAccessActions.IsValid(action))
            return (null, new Refusal($"action must be one of: {string.Join(", ", DataAccessActions.All)}"));
        if (!string.IsNullOrWhiteSpace(recordType) && !DataAccessRecordTypes.IsValid(recordType))
            return (null, new Refusal($"record_type must be one of: {string.Join(", ", DataAccessRecordTypes.All)}"));

        var page = await _store.ListPageAsync(userId, action, recordType, recordId, from, to, cursor, limit, ct);
        return (new PagedResult<DataAccessLogEntryDto>([.. page.Items.Select(ToDto)], page.NextCursor), null);
    }

    private static DataAccessLogEntryDto ToDto(DataAccessLogStore.Row r) => new(
        r.Entry.Id, r.Entry.OccurredAt, r.Entry.UserId, r.UserName, r.Entry.Action, r.Entry.RecordType, r.Entry.RecordId,
        r.Entry.Field, r.Entry.Category, r.Entry.RowCount, r.Entry.Detail);

    /// <summary>
    /// The one write. Validates the vocabulary so a typo cannot create a row the list endpoint then refuses to filter on. There
    /// is deliberately no parameter that could carry a value.
    /// </summary>
    public async Task RecordAsync(
        Guid userId, string action, string recordType, Guid? recordId, string? field = null, string? category = null,
        int? rowCount = null, string? detail = null, CancellationToken ct = default)
    {
        if (!DataAccessActions.IsValid(action)) throw new ArgumentException($"Unknown data access action '{action}'.", nameof(action));
        if (!DataAccessRecordTypes.IsValid(recordType)) throw new ArgumentException($"Unknown data access record type '{recordType}'.", nameof(recordType));
        if (category is not null && !SensitiveCategories.IsValid(category)) throw new ArgumentException($"Unknown category '{category}'.", nameof(category));
        await _store.AddAsync(new DataAccessLogEntry
        {
            UserId = userId,
            Action = action,
            RecordType = recordType,
            RecordId = recordId,
            Field = field,
            Category = category,
            RowCount = rowCount is { } n ? Math.Max(0, n) : null,
            Detail = detail,
        }, ct);
    }

    /// <summary>One export (decision 14): who, what kind, how many rows, in what format. Never the rows.</summary>
    public Task RecordExportAsync(Guid userId, string recordType, int rowCount, string format, CancellationToken ct = default) =>
        RecordAsync(userId, DataAccessActions.Export, recordType, null, rowCount: rowCount, detail: format, ct: ct);

    /// <summary>
    /// POST /data-access/launch: the person tapped Call (tel:) or "Open in WhatsApp" (wa.me) and the client asks the server to
    /// log it. Allowed only when the caller may actually USE the number: the record exists and is visible to them, their
    /// contact-details level for THAT record is full or view only (the assigned scope already narrows it to masked outside
    /// their records), and for WhatsApp the role also holds whatsapp.open_external. Writes the entry on success; the client
    /// opens the device app only after the 204.
    /// </summary>
    public async Task<Refusal?> LaunchAsync(
        RecordAccessContext ctx, bool mayOpenWhatsAppExternal, DataAccessLaunchInput input, CancellationToken ct = default)
    {
        if (!DataAccessRecordTypes.IsValid(input.RecordType)
            || input.RecordType is DataAccessRecordTypes.Report or DataAccessRecordTypes.Team)
            return new Refusal("record_type must be one of: lead, account, contact");
        if (input.RecordId is not { } recordId || recordId == Guid.Empty) return new Refusal("record_id is required.");
        if (input.Channel is not (DataAccessChannels.Call or DataAccessChannels.Sms or DataAccessChannels.WhatsApp))
            return new Refusal("channel must be one of: call, sms, whatsapp");

        var facts = await _store.RecordFactsAsync(input.RecordType!, recordId, ct);
        // Not visible reads exactly like not found: a caller cannot probe for records outside their reach.
        if (facts is null || !RecordAccess.CanView(ctx, facts.OwnerId, facts.TeamId))
            return new Refusal("That record was not found.", NotFound: true);

        var level = (ctx.Sensitive ?? SensitiveAccess.Unrestricted).LevelFor(SensitiveCategories.ContactDetails, facts.OwnerId, facts.TeamId);
        if (!SensitiveLevels.CanReadRaw(level))
            return new Refusal("You cannot use this contact's details.", Forbidden: true, Code: ChannelNotPermittedCode);
        if (input.Channel == DataAccessChannels.WhatsApp && !mayOpenWhatsAppExternal)
            return new Refusal("Your role cannot open WhatsApp on the device. Use the message composer.", Forbidden: true, Code: ChannelNotPermittedCode);

        await RecordAsync(
            ctx.UserId,
            input.Channel switch
            {
                DataAccessChannels.Call => DataAccessActions.CallLaunched,
                DataAccessChannels.Sms => DataAccessActions.SmsLaunched,
                _ => DataAccessActions.WhatsAppOpened,
            },
            input.RecordType!, recordId, category: SensitiveCategories.ContactDetails, detail: input.Channel, ct: ct);
        return null;
    }
}

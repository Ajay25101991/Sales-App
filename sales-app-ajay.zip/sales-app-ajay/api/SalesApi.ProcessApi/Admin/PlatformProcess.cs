using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.Admin;

namespace SalesApi.ProcessLayer.Admin;

/// <summary>
/// The rules of PLATFORM administration: what counts as a valid domain, what a
/// designated org admin's address has to satisfy, and which of those failures is
/// a 400 and which a 409 — assembled from System reads and writes, knowing no
/// screen.
///
/// Every rule here was inline in `AdminController`. None of them changed; only
/// where they run did. Two are worth calling out because they look like
/// arbitrary strictness and are not:
///
///  - the designated admin's email must be on the ORG'S OWN domain. Without it,
///    a platform admin could hand org-admin authority over acme.com to an
///    address at an unrelated company. This is the same trust model
///    `AuthController.Signup` enforces for self-registration.
///  - creating the org does NOT create the admin's account. The row only
///    DESIGNATES them; `Signup` is what enforces the designation, by allowing
///    only that address to register while the org has no admin yet. Splitting
///    those two is what lets an org be provisioned before anyone signs up.
///
/// The refusals are RESULTS, not exceptions — same shape as
/// <c>GoalProcess.Refusal</c> — so the endpoint picks a status code without
/// re-deriving the reason from a message string.
/// </summary>
public sealed class PlatformProcess
{
    private readonly PlatformStore _store;
    public PlatformProcess(PlatformStore store) => _store = store;

    /// <summary>Why a request could not be carried out. <c>Conflict</c>
    /// distinguishes "you asked for something impossible" (400) from "you asked
    /// for something that already exists" (409).</summary>
    public sealed record Refusal(string Reason, bool NotFound = false, bool Conflict = false);

    private static AllowedDomainDto ToDto(AllowedDomain a) => new(a.Id, a.Domain, a.OrgName, a.CreatedAt);
    private static OrganizationDto ToDto(Organization o) => new(o.Id, o.Name, o.Domain, o.Currency, o.CreatedAt);

    /// <summary>
    /// The one definition of a well-formed domain, shared by the allowlist and by
    /// org provisioning. It was written out twice in the controller, character
    /// for character; two copies of a validation rule are a divergence with a
    /// deadline, so there is one now.
    /// </summary>
    private static bool IsValidDomain(string? domain) =>
        !string.IsNullOrEmpty(domain) && domain.Contains('.')
        && !domain.Contains('@') && !domain.Any(char.IsWhiteSpace);

    // --- The self-registration allowlist ---

    public async Task<List<AllowedDomainDto>> AllowedDomainsAsync(CancellationToken ct = default) =>
        [.. (await _store.AllowedDomainsAsync(ct)).Select(ToDto)];

    public async Task<(AllowedDomainDto? Domain, Refusal? Refusal)> AddAllowedDomainAsync(
        AllowedDomainInput input, Guid actorId, CancellationToken ct = default)
    {
        var domain = input.Domain?.Trim().ToLowerInvariant();
        if (!IsValidDomain(domain))
            return (null, new Refusal("Enter a valid domain, e.g. acme.com"));
        if (await _store.DomainAllowedAsync(domain!, ct))
            return (null, new Refusal("That domain is already approved.", Conflict: true));

        var row = await _store.AddAllowedDomainAsync(new AllowedDomain
        {
            Domain = domain!,
            OrgName = string.IsNullOrWhiteSpace(input.OrgName) ? null : input.OrgName!.Trim(),
            AddedBy = actorId,
        }, ct);
        return (ToDto(row), null);
    }

    /// <summary>Revoke an approval. Existing orgs on that domain keep working;
    /// this only blocks future first-time registrations.</summary>
    public async Task<Refusal?> RemoveAllowedDomainAsync(Guid id, CancellationToken ct = default) =>
        await _store.RemoveAllowedDomainAsync(id, ct) ? null : new Refusal("Not found", NotFound: true);

    // --- The organization register ---

    public async Task<List<OrganizationDto>> OrganizationsAsync(CancellationToken ct = default)
    {
        var orgs = await _store.OrganizationsAsync(ct);
        var planNames = await _store.PlanNamesAsync(ct);
        return [.. orgs.Select(o => ToDto(o) with
        {
            PlanId = o.PlanId,
            PlanName = o.PlanId is Guid id && planNames.TryGetValue(id, out var n) ? n : null,
        })];
    }

    /// <summary>
    /// Explicit tenant provisioning: name the org, its domain and currency, and
    /// DESIGNATE its first org admin by email, before anyone has signed up.
    ///
    /// This is a second, independent way for an org to come into existence —
    /// self-registration through <c>AuthController.Signup</c>'s allowlist path is
    /// untouched and still governs that flow. The difference is who chooses: here
    /// a platform admin does, up front, rather than whoever registers first.
    ///
    /// <c>HasAdmin: false</c> in the response is a fact, not a placeholder — the
    /// designated admin has no account yet, and saying so is the point of the
    /// field.
    /// </summary>
    public async Task<(AdminOrganizationDto? Org, Refusal? Refusal)> CreateOrganizationAsync(
        CreateOrganizationInput input, CancellationToken ct = default)
    {
        var name = input.Name?.Trim();
        if (string.IsNullOrEmpty(name)) return (null, new Refusal("A name is required"));

        var domain = input.Domain?.Trim().ToLowerInvariant();
        if (!IsValidDomain(domain))
            return (null, new Refusal("Enter a valid domain, e.g. acme.com"));
        if (await _store.OrgDomainTakenAsync(domain!, ct))
            return (null, new Refusal("An organization already exists for that domain.", Conflict: true));

        var currency = string.IsNullOrWhiteSpace(input.Currency) ? "USD" : input.Currency.Trim().ToUpperInvariant();
        if (!OrgCurrencies.Supported.Contains(currency))
            return (null, new Refusal("Unsupported currency"));

        var adminEmail = input.AdminEmail?.Trim().ToLowerInvariant();
        if (string.IsNullOrEmpty(adminEmail) || !adminEmail.Contains('@'))
            return (null, new Refusal("A valid admin email is required"));
        // Same trust model as self-registration (AuthController.Signup): the
        // designated admin must be reachable on the org's own domain, or this
        // would let a platform admin hand org-admin authority for acme.com to an
        // address at an unrelated company.
        if (adminEmail.Split('@')[^1] != domain)
            return (null, new Refusal("The designated admin's email must be on the organization's own domain."));
        if (await _store.EmailRegisteredAsync(adminEmail, ct))
            return (null, new Refusal("That email is already registered to an existing account.", Conflict: true));

        var org = await _store.AddOrganizationAsync(new Organization
        {
            Name = name,
            Domain = domain!,
            Currency = currency,
            DesignatedAdminEmail = adminEmail,
        }, ct);
        return (new AdminOrganizationDto(
            org.Id, org.Name, org.Domain, org.Currency, org.DesignatedAdminEmail, HasAdmin: false, org.CreatedAt), null);
    }

    /// <summary>E7.2 — clone-from-org needs to know both the source and the
    /// target org actually exist before it does any cross-tenant work; this
    /// is the same existence check <see cref="DeleteOrgLeadsAsync"/> already
    /// does, exposed so <c>AdminExperience</c> can run it for two org ids
    /// instead of one.</summary>
    public Task<bool> OrgExistsAsync(Guid orgId, CancellationToken ct = default) => _store.OrgExistsAsync(orgId, ct);

    /// <summary>Permanently delete every lead in an organization — its
    /// activities, invoices, proposals and reminders cascade away with it.
    /// Irreversible; the count is what was removed.</summary>
    public async Task<(int Deleted, Refusal? Refusal)> DeleteOrgLeadsAsync(Guid orgId, CancellationToken ct = default)
    {
        if (!await _store.OrgExistsAsync(orgId, ct))
            return (0, new Refusal("Organization not found", NotFound: true));
        return (await _store.DeleteOrgLeadsAsync(orgId, ct), null);
    }

    // --- Aggregate health ---
    //
    // The human end of "detect and REPORT". The nightly check never corrects
    // anything (see Services/AggregateDrift for why); this is where someone reads
    // what it found, and the resync below is where they act on it once they
    // understand the cause.

    public Task<List<AggregateHealthDto>> AggregateHealthAsync(bool live, CancellationToken ct = default) =>
        _store.AggregateHealthAsync(live, ct);

    /// <summary>
    /// The DELIBERATE repair, and deliberate is the design (audit C9): the drift
    /// check reports a disagreement and stops there, so a bug in the checker can
    /// never rewrite good aggregates on its own. A person reads the finding,
    /// decides the aggregates are the wrong side of it, and calls this.
    ///
    /// Distinct from the automatic retry queue, which needs no decision: a queued
    /// bucket is one the database itself recorded as never having been
    /// recomputed.
    /// </summary>
    public async Task<(AggregateDriftReport? Report, Refusal? Refusal)> ResyncAggregatesAsync(
        Guid orgId, CancellationToken ct = default)
    {
        if (!await _store.OrgExistsAsync(orgId, ct))
            return (null, new Refusal("Organization not found", NotFound: true));
        return (await _store.ResyncAggregatesAsync(orgId, ct), null);
    }
}

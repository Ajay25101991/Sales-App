using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.CollectionTasks;

namespace SalesApi.ProcessLayer.CollectionTasks;

/// <summary>
/// Field collection: a manager assigns an invoice's outstanding amount to be
/// collected, it is broadcast to every collector, and whoever collects records
/// the payment and gets a receipt back-linked to the invoice.
///
/// This is the business logic that used to live inline in
/// <c>CollectionTasksController</c>. What stayed at the controller: HTTP
/// authorization ("only a manager may assign", "only a collector or manager may
/// view") — those are request-shaped facts, not domain rules, and every rule
/// here is enforced again by a second caller that is not an HTTP request (a
/// background job, a script) exactly the way <c>GoalProcess</c> and
/// <c>LoyaltyStatusProcess</c> already are.
/// </summary>
public sealed class CollectionTaskProcess
{
    private readonly CollectionTaskStore _store;
    private readonly NotificationDispatcher _notify;
    private readonly ILogger<CollectionTaskProcess> _logger;
    private readonly ReportingCalendarService _reportingCalendar;
    private readonly MoneyFormatService _moneyFormat;
    private readonly CollectionTaskCreator _taskCreator;
    private readonly PaymentWorkflowReader _paymentWorkflow;
    private readonly PaymentSettlementService _settlement;
    private readonly LoyaltyPolicyReader _loyaltyPolicy;
    private readonly LoyaltyLedgerWriter _loyaltyLedger;
    private readonly OrgSettingsReader? _orgSettings;

    // Layering round 4 (owner decision 2026-09-30): the last remaining _db
    // uses here were CollectionTaskCreation/PaymentWorkflowService/
    // PaymentSettlement.CreditExcess/the loyalty statics called straight
    // through — once each moved behind its own injectable front, AppDbContext
    // had no other job in this class, so it is dropped.
    public CollectionTaskProcess(
        CollectionTaskStore store, NotificationDispatcher notify, ILogger<CollectionTaskProcess> logger,
        ReportingCalendarService reportingCalendar, MoneyFormatService moneyFormat,
        CollectionTaskCreator taskCreator, PaymentWorkflowReader paymentWorkflow, PaymentSettlementService settlement,
        LoyaltyPolicyReader loyaltyPolicy, LoyaltyLedgerWriter loyaltyLedger,
        // E17.1: the receipt PDF's legal header. Optional (null in the hand-built test call sites that never wire it): the
        // receipt then prints without a legal name / TRN.
        OrgSettingsReader? orgSettings = null)
    {
        _orgSettings = orgSettings;
        _store = store;
        _notify = notify;
        _logger = logger;
        _reportingCalendar = reportingCalendar;
        _moneyFormat = moneyFormat;
        _taskCreator = taskCreator;
        _paymentWorkflow = paymentWorkflow;
        _settlement = settlement;
        _loyaltyPolicy = loyaltyPolicy;
        _loyaltyLedger = loyaltyLedger;
    }

    /// <summary>Why a request could not be carried out, or null when it can. A
    /// RESULT rather than an exception — see <c>GoalProcess.Refusal</c> for why:
    /// an ordinary "not found" or "already collected" must not become a 500.</summary>
    public sealed record Refusal(string Reason, bool NotFound = false);

    /// <summary>A task write's outcome: either a refusal, or the task as it now stands.</summary>
    public sealed record TaskOutcome(Refusal? Refusal, CollectionTaskDto? Task)
    {
        public static TaskOutcome Refused(Refusal r) => new(r, null);
        public static TaskOutcome Ok(CollectionTaskDto t) => new(null, t);
    }

    /// <summary>Amount/CollectedAmount masked (null) without
    /// <paramref name="canSeeFinancials"/> (ViewAccountFinancials,
    /// invoice-money-masking, owner decision 2026-09-28). Defaults to `true`
    /// (no-op) for the same reason every other masking flag in this migration
    /// does.</summary>
    private static CollectionTaskDto Map(
        CollectionTask t, Invoice? inv, IReadOnlyDictionary<Guid, string?> names, bool canSeeFinancials = true) => new(
        t.Id, t.InvoiceId, inv?.Number, inv?.Lead?.Name, inv?.Lead?.Company,
        canSeeFinancials ? t.Amount : null, canSeeFinancials ? t.CollectedAmount : null, t.Method, t.Notes, t.Status,
        t.AssignedById, names.GetValueOrDefault(t.AssignedById),
        t.CollectedById, t.CollectedById is Guid c ? names.GetValueOrDefault(c) : null,
        t.CollectedAt, t.PaymentId, t.ReceiptNumber, t.Modules, t.CreatedAt, t.Source, t.Priority);

    private async Task<CollectionTaskDto> ToDtoAsync(CollectionTask t, bool canSeeFinancials, CancellationToken ct)
    {
        var inv = await _store.InvoiceWithLeadAsync(t.InvoiceId, ct);
        var ids = new List<Guid> { t.AssignedById };
        if (t.CollectedById is Guid c) ids.Add(c);
        var names = await _store.ProfileNamesAsync(ids, ct);
        return Map(t, inv, names, canSeeFinancials);
    }

    /// <summary>Managers see every task; a collector sees the open pool plus
    /// whatever they personally collected — for their own receipts.</summary>
    public async Task<List<CollectionTaskDto>> ListAsync(
        bool restrictToCollector, Guid collectorId, string? status, bool canSeeFinancials = true, CancellationToken ct = default)
    {
        var tasks = await _store.ListAsync(restrictToCollector, collectorId, status, ct);
        var invIds = tasks.Select(t => t.InvoiceId).Distinct().ToList();
        var invoices = await _store.InvoicesWithLeadAsync(invIds, ct);
        var userIds = tasks.SelectMany(t => new[] { (Guid?)t.AssignedById, t.CollectedById })
            .Where(x => x != null).Select(x => x!.Value).Distinct().ToList();
        var names = await _store.ProfileNamesAsync(userIds, ct);
        return tasks.Select(t => Map(t, invoices.GetValueOrDefault(t.InvoiceId), names, canSeeFinancials)).ToList();
    }

    public async Task<CollectionTaskDto?> GetAsync(Guid id, bool canSeeFinancials = true, CancellationToken ct = default)
    {
        var t = await _store.GetAsync(id, ct);
        return t is null ? null : await ToDtoAsync(t, canSeeFinancials, ct);
    }

    /// <summary>A rendered receipt: the PDF bytes and its download name, or a refusal.</summary>
    public sealed record PdfOutcome(Refusal? Refusal, byte[]? Bytes, string? FileName);

    /// <summary>
    /// E17.1: the payment receipt of a COLLECTED task as a PDF (a task only has a receipt number once it is collected). Built from
    /// <see cref="GetAsync"/>'s own DTO, so the amount is "Hidden" for a caller without <c>account_financials.view</c> exactly as the
    /// JSON read masks it. Who may read a task (manager or collector) is the controller's check, the same as the JSON read's.
    /// </summary>
    public async Task<PdfOutcome> ReceiptPdfAsync(Guid id, bool canSeeFinancials = true, CancellationToken ct = default)
    {
        var task = await GetAsync(id, canSeeFinancials, ct);
        if (task is null) return new PdfOutcome(new Refusal("Task not found", NotFound: true), null, null);
        if (task.ReceiptNumber is null) return new PdfOutcome(new Refusal("This collection has no receipt yet - it has not been collected."), null, null);

        var profile = _orgSettings is null ? null : await _orgSettings.GetInvoiceProfileAsync();
        var currency = await _moneyFormat.CurrencyAsync(ct: ct);
        var bytes = DocumentPdf.Render(DocumentPdf.ReceiptContent(task, profile, currency));
        return new PdfOutcome(null, bytes, DocumentPdf.FileNameFor("Receipt", task.ReceiptNumber));
    }

    /// <summary>Distinct module names across every proposal on the task's
    /// invoice's lead — the services the customer has purchased. Null means the
    /// task itself was not found.</summary>
    public async Task<List<string>?> CustomerModulesAsync(Guid id, CancellationToken ct = default)
    {
        var task = await _store.GetAsync(id, ct);
        if (task is null) return null;
        var leadId = await _store.LeadIdForInvoiceAsync(task.InvoiceId, ct);
        var names = new List<string>();
        if (leadId is null) return names;
        var proposalModules = await _store.ProposalModulesJsonForLeadAsync(leadId.Value, ct);
        foreach (var json in proposalModules)
        {
            try
            {
                using var doc = System.Text.Json.JsonDocument.Parse(string.IsNullOrEmpty(json) ? "[]" : json);
                foreach (var m in doc.RootElement.EnumerateArray())
                    if (m.TryGetProperty("name", out var n) && n.GetString() is { Length: > 0 } s && !names.Contains(s))
                        names.Add(s);
            }
            catch { }
        }
        return names;
    }

    /// <summary>A manager assigns collection of an invoice's balance (or a
    /// stated amount) to whichever collector picks it up first.</summary>
    public async Task<TaskOutcome> CreateAsync(
        Guid? invoiceId, decimal? amount, string? method, string? notes, Guid assignedById,
        bool canSeeFinancials = true, CancellationToken ct = default)
    {
        if (invoiceId is null) return TaskOutcome.Refused(new Refusal("invoice_id is required"));
        var inv = await _store.InvoiceWithLeadAsync(invoiceId.Value, ct);
        if (inv is null) return TaskOutcome.Refused(new Refusal("Invoice not found", NotFound: true));
        // A draft has nothing to collect yet either — it hasn't been raised (no
        // real number, the customer has never seen it) — same as
        // paid/void/written_off: Invoice.IsReceivable is exactly "still owed".
        if (!Invoice.IsReceivable(inv.Status))
            return TaskOutcome.Refused(new Refusal("This invoice has no balance to collect"));
        var resolvedAmount = amount ?? Invoice.BalanceOf(inv);
        if (resolvedAmount <= 0) return TaskOutcome.Refused(new Refusal("amount must be greater than zero"));

        var task = await _taskCreator.CreateAndBroadcastAsync(
            inv, assignedById, resolvedAmount, method, notes, source: null, notify: _notify, ct: ct);
        return TaskOutcome.Ok(await ToDtoAsync(task, canSeeFinancials, ct));
    }

    /// <summary>A collector (or a manager) records the payment against a
    /// pending task and generates its receipt.</summary>
    public async Task<TaskOutcome> CollectAsync(
        Guid id, decimal? amount, string? method, string? reference, DateTime? paidAt, string? note,
        List<string>? modules, Guid? proofAttachmentId, List<Guid>? proofInvoiceIds, Guid collectedById,
        bool canSeeFinancials = true, CancellationToken ct = default)
    {
        var task = await _store.GetAsync(id, ct);
        if (task is null) return TaskOutcome.Refused(new Refusal("Task not found", NotFound: true));
        if (task.Status != "pending") return TaskOutcome.Refused(new Refusal("This task is already " + task.Status));

        var inv = await _store.InvoiceWithLeadAsync(task.InvoiceId, ct);
        if (inv is null) return TaskOutcome.Refused(new Refusal("Invoice not found", NotFound: true));
        if (proofAttachmentId is Guid linkCheck && await _store.IsSharePointLinkAsync(linkCheck, ct))
            return TaskOutcome.Refused(new Refusal(SalesApi.Dtos.AttachmentRules.LinkIsNotProof));
        if (inv.Status is "draft" or "void" or "written_off")
            return TaskOutcome.Refused(new Refusal("Cannot collect on a closed invoice"));

        // The collected amount can differ from what was assigned; default to it.
        var resolvedAmount = amount ?? task.Amount;
        if (resolvedAmount <= 0) return TaskOutcome.Refused(new Refusal("amount must be greater than zero"));
        var resolvedMethod = string.IsNullOrWhiteSpace(method) ? task.Method : method!.Trim();

        // Settlement goes through the one definition both InvoicesController and
        // this path share, so a discounted payment taken in the field closes the
        // invoice exactly as the same payment typed on the invoice screen would.
        var resolvedPaidAt = (paidAt ?? DateTime.UtcNow).ToUniversalTime();
        var calendar = await _reportingCalendar.ForAsync();
        var workflow = await _paymentWorkflow.GetConfigForLeadAsync(inv.LeadId, ct);
        var settlement = PaymentSettlement.Decide(inv, resolvedAmount, resolvedPaidAt, calendar, workflow.OverpaymentPolicy);
        if (settlement.Refused) return TaskOutcome.Refused(new Refusal(settlement.Error!));
        // The receipt the customer is handed states the money actually taken.
        resolvedAmount = settlement.Recorded;

        var payment = new Payment
        {
            Invoice = inv,
            RecordedById = collectedById,
            Amount = resolvedAmount,
            Method = resolvedMethod,
            Reference = reference,
            PaidAt = resolvedPaidAt,
            Note = note,
            // Payment proof (an attachment) — tags this proof to the invoice via
            // the payment, so each invoice's payment carries its own proof.
            ProofAttachmentId = proofAttachmentId,
        };
        _store.AddPayment(payment);

        // Tag the proof to every invoice it covers (many-to-many). Always covers
        // this task's invoice; the collector may also tick other invoices for the
        // same customer. Restricted to that customer's invoices for safety.
        if (proofAttachmentId is Guid proofId)
        {
            var wanted = new HashSet<Guid>(proofInvoiceIds ?? new()) { task.InvoiceId };
            var validIds = await _store.InvoiceIdsForLeadAsync(wanted, inv.LeadId, ct);
            var already = await _store.InvoiceIdsAlreadyTaggedAsync(proofId, validIds, ct);
            foreach (var iid in validIds.Except(already))
                _store.TagAttachment(iid, proofId);
        }

        // Captured BEFORE Commit — the same wasPaid transition guard
        // InvoicesController.RecordPayment uses, so a field collection that
        // finally clears an invoice earns loyalty exactly like the same payment
        // typed on the invoice screen would, and a second field collection on an
        // already-paid invoice does not re-earn it.
        var wasPaid = inv.Status == "paid";
        PaymentSettlement.Commit(inv, settlement);

        var collectorName = await _store.ProfileFullNameAsync(collectedById, ct);
        // F22: a sequence number (per org and year), never a random suffix.
        var receipt = await _store.NextReceiptNumberAsync(ct);
        var forModules = modules is { Count: > 0 } ? $" for {string.Join(", ", modules)}" : "";
        // The collected amount appears on the receipt the customer is handed
        // (packages/core/src/lib/receipt.ts, cent-exact since batch 3), so this
        // note and that receipt must state one figure.
        var currency = await _moneyFormat.CurrencyAsync(ct: ct);
        if (settlement.ExcessCredit > 0)
            _settlement.CreditExcess(inv, payment, settlement.ExcessCredit, collectedById);
        _store.AddInvoiceActivity(new InvoiceActivity
        {
            Invoice = inv,
            AuthorId = collectedById,
            Type = "payment",
            Body = $"Collected {MoneyFormat.Exact(resolvedAmount, currency)} ({resolvedMethod}){forModules} by {collectorName ?? "collector"} — receipt {receipt}"
                   + PaymentSettlement.ActivityNote(settlement, currency),
        });
        await _store.SaveChangesAsync(ct);

        // Loyalty (P0-2). AFTER the line above: the payment is already committed,
        // and TryWriteAsync is its own isolated unit of work that swallows any
        // failure — see LoyaltyLedgerService's own remarks.
        var loyaltyPolicy = await _loyaltyPolicy.GetAsync(ct);
        var (invoiceRule, _) = await _loyaltyLedger.ResolveEarnRuleAsync(inv.AccountId, loyaltyPolicy, ct);
        await _loyaltyLedger.TryWriteAsync(
            LoyaltyLedgerService.BuildFromInvoicePayment(
                loyaltyPolicy, inv, payment, !wasPaid && inv.Status == "paid", invoiceRule),
            _logger, ct);

        task.Status = "collected";
        task.CollectedAmount = resolvedAmount;
        if (modules is { Count: > 0 }) task.Modules = modules;
        task.CollectedById = collectedById;
        task.CollectedAt = DateTime.UtcNow;
        task.PaymentId = payment.Id;
        task.ReceiptNumber = receipt;
        await _store.SaveChangesAsync(ct);

        // The invoice owner, not the collector who just recorded it — a field
        // collection is the one payment path where the person who takes the money
        // is usually not the person waiting on it.
        if (inv.OwnerId != collectedById)
            await _notify.NotifyAsync(new NotifyRequest(
                [inv.OwnerId], NotificationEvents.Keys.PaymentReceived,
                $"{MoneyFormat.Exact(resolvedAmount, currency)} collected on {inv.Number}",
                $"{collectorName ?? "A collector"} collected {MoneyFormat.Exact(resolvedAmount, currency)} ({resolvedMethod}) — receipt {receipt}.")
            {
                InvoiceId = inv.Id,
                AttachInvoicePdfOf = inv.Id, // E17.1
                LeadId = inv.LeadId,
                TeamId = inv.TeamId,
                InvolvedUserIds = [inv.OwnerId],
                EmailDetails = [("Invoice", inv.Number ?? ""), ("Amount", MoneyFormat.Exact(resolvedAmount, currency)), ("Receipt", receipt)],
            }, ct);

        return TaskOutcome.Ok(await ToDtoAsync(task, canSeeFinancials, ct));
    }

    /// <summary>A read's outcome: either a refusal, or the rows.</summary>
    public sealed record InvoicesOutcome(Refusal? Refusal, List<TaskInvoiceDto>? Invoices)
    {
        public static InvoicesOutcome Refused(Refusal r) => new(r, null);
        public static InvoicesOutcome Ok(List<TaskInvoiceDto> rows) => new(null, rows);
    }

    /// <summary>The task customer's open invoices, for ticking which ones a
    /// single payment proof covers. Amount/Balance masked (null) without
    /// <paramref name="canSeeFinancials"/> (invoice-money-masking).</summary>
    public async Task<InvoicesOutcome> CustomerInvoicesAsync(Guid id, bool canSeeFinancials = true, CancellationToken ct = default)
    {
        var task = await _store.GetAsync(id, ct);
        if (task is null) return InvoicesOutcome.Refused(new Refusal("Task not found", NotFound: true));
        var inv = await _store.InvoiceWithLeadAsync(task.InvoiceId, ct);
        if (inv is null) return InvoicesOutcome.Refused(new Refusal("Invoice not found", NotFound: true));
        // Balance is clamped and now has three inputs, so it is computed in
        // memory through the one definition rather than subtracted in a SELECT.
        var rows = await _store.CustomerInvoicesAsync(inv.LeadId, ct);
        return InvoicesOutcome.Ok(rows
            .Select(i => new TaskInvoiceDto(
                i.Id, i.Number, canSeeFinancials ? i.Amount : null,
                canSeeFinancials ? Invoice.BalanceOf(i) : null, i.Status, i.DueDate))
            .ToList());
    }

    public async Task<TaskOutcome> CancelAsync(Guid id, bool canSeeFinancials = true, CancellationToken ct = default)
    {
        var task = await _store.GetAsync(id, ct);
        if (task is null) return TaskOutcome.Refused(new Refusal("Task not found", NotFound: true));
        if (task.Status != "pending") return TaskOutcome.Refused(new Refusal("This task is already " + task.Status));
        task.Status = "cancelled";
        await _store.SaveChangesAsync(ct);
        return TaskOutcome.Ok(await ToDtoAsync(task, canSeeFinancials, ct));
    }
}

namespace SalesApi.ProcessLayer.Capture;

/// <summary>
/// The vendor-neutral validation of a capture connector's question -> lead-field mapping, extracted from
/// <c>LinkedInFieldMappingProcess.SaveAsync</c> so the Meta mapping save runs the SAME rule.
///
/// Every target is either a known standard field ("name", "company", "email", "phone") or "custom.&lt;key&gt;" - validated as a
/// SHAPE only (non-empty, no embedded whitespace), never against the live custom-field list: an admin may map a question to a
/// custom field defined moments later, and an unmapped-but-shape-valid target still lands the answer on the lead's note rather
/// than being refused outright.
/// </summary>
public static class CaptureFieldMapping
{
    /// <summary>The trimmed mapping, or a human-readable refusal for the first invalid target. Blank keys / targets are dropped.</summary>
    public static (Dictionary<string, string>? Mapping, string? Refusal) Normalize(Dictionary<string, string>? input)
    {
        var mapping = new Dictionary<string, string>();
        foreach (var (key, target) in input ?? new Dictionary<string, string>())
        {
            if (string.IsNullOrWhiteSpace(key) || string.IsNullOrWhiteSpace(target)) continue;
            var trimmedTarget = target.Trim();
            if (trimmedTarget.Contains(' ')) return (null, $"\"{target}\" is not a valid lead field key.");
            mapping[key.Trim()] = trimmedTarget;
        }
        return (mapping, null);
    }
}

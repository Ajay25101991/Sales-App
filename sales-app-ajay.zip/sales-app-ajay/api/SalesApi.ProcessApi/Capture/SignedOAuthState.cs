using System.Security.Cryptography;
using System.Text.Json;

namespace SalesApi.ProcessLayer.Capture;

/// <summary>
/// The signed, expiring `state` parameter of an OAuth redirect flow - extracted from <c>LinkedInOAuthProcess</c> (which had it
/// private) so the Meta connector signs and validates state with the SAME code instead of a second copy.
///
/// State is the entire security model of an OAuth callback here: the API has no server-side session to remember who started
/// the flow, and the callback is a full-page browser redirect with no Authorization header, so the HMAC-signed payload IS the
/// record of who asked. Wire format is unchanged from what LinkedIn already issued: base64url(json).base64url(hmacsha256(json)).
/// </summary>
public static class SignedOAuthState
{
    public static string Sign<T>(T payload, byte[] key)
    {
        var json = JsonSerializer.SerializeToUtf8Bytes(payload);
        using var hmac = new HMACSHA256(key);
        var signature = hmac.ComputeHash(json);
        return $"{Base64UrlEncode(json)}.{Base64UrlEncode(signature)}";
    }

    /// <summary>False for anything malformed, tampered with, or past <paramref name="expiresAtUnix"/>.</summary>
    public static bool TryValidate<T>(string? state, byte[] key, Func<T, long> expiresAtUnix, out T payload) where T : class
    {
        payload = default!;
        if (string.IsNullOrWhiteSpace(state)) return false;
        var parts = state.Split('.', 2);
        if (parts.Length != 2) return false;

        try
        {
            var json = Base64UrlDecode(parts[0]);
            var signature = Base64UrlDecode(parts[1]);
            using var hmac = new HMACSHA256(key);
            var expected = hmac.ComputeHash(json);
            if (!CryptographicOperations.FixedTimeEquals(signature, expected)) return false;

            var decoded = JsonSerializer.Deserialize<T>(json);
            if (decoded is null) return false;
            if (DateTimeOffset.UtcNow.ToUnixTimeSeconds() > expiresAtUnix(decoded)) return false;

            payload = decoded;
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static string Base64UrlEncode(byte[] value) =>
        Convert.ToBase64String(value).TrimEnd('=').Replace('+', '-').Replace('/', '_');

    private static byte[] Base64UrlDecode(string value)
    {
        var padded = value.Replace('-', '+').Replace('_', '/');
        padded += (padded.Length % 4) switch { 2 => "==", 3 => "=", _ => "" };
        return Convert.FromBase64String(padded);
    }
}

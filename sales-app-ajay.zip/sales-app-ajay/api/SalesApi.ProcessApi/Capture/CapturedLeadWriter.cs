using SalesApi.Dtos;
using SalesApi.SystemLayer.Public;

namespace SalesApi.ProcessLayer.Capture;

/// <summary>How a vendor lead arrived. <see cref="Live"/> is a push or a poll of a fresh submission; <see cref="Backfill"/> is the
/// one-time import of what the vendor still holds, where a lead the CRM already knows is skipped outright.</summary>
public enum CaptureMode { Live, Backfill }

public enum CaptureOutcome { Created, NoteAdded, Skipped }

/// <summary>One answer from a vendor lead form. <paramref name="Key"/> is what the field mapping is keyed on (LinkedIn's question
/// URN, Meta's question key); <paramref name="Label"/> is what the capture note shows when the question is unmapped.</summary>
public sealed record CaptureAnswer(string Key, string Label, string Text);

/// <summary>Everything the vendor-neutral intake needs about one submission. The vendor Process builds this; it never touches
/// routing, dedupe or lead creation itself.</summary>
public sealed record CaptureRequest(
    string Source,                       // the lead's source string ("LinkedIn", "Meta Ads") - a literal, routed by the org's own source rules
    string ActivitySource,               // LeadActivitySources.* - labels the unattended notes on the timeline
    string VendorLabel,                  // wording in the capture note: "Submitted via {VendorLabel}: ..."
    string FallbackName,                 // lead name when the form gave no name/company/email
    IReadOnlyList<CaptureAnswer> Answers,
    IReadOnlyDictionary<string, string> Mapping,
    string DuplicateMode,                // LinkedInDuplicateMode.* - the org's one duplicate-handling setting
    CaptureMode Mode,
    string DomainEventType,
    Func<Guid, string?, object> EventPayload,   // (new lead id, routing reason) -> the event's payload record
    Guid? LeadFormId = null,
    IReadOnlyDictionary<string, string>? ExtraCustom = null);

public sealed record CaptureResult(CaptureOutcome Outcome, Guid? LeadId);

/// <summary>
/// The vendor-neutral half of a lead-capture connector: answers + field mapping -> lead fields, duplicate handling, routing,
/// lead creation, domain event. EXTRACTED from <c>LinkedInLeadSyncProcess.SyncOneAsync</c> (owner 2026-11-14: Meta Lead Ads is a
/// sibling of LinkedIn, "a second way is a defect") so both connectors run one implementation of the E3.11 rules; LinkedIn's
/// behaviour is unchanged (it always passes <see cref="CaptureMode.Live"/> and no form id).
///
/// NEVER reads a ClaimsPrincipal or HttpRequest - it runs from a worker or a public webhook with no signed-in caller.
/// Reuses <see cref="PublicIntakeStore"/> for matching, owner pick, team resolution and the lead insert; nothing here
/// reimplements any of it.
/// </summary>
public sealed class CapturedLeadWriter
{
    private readonly PublicIntakeStore _intake;
    public CapturedLeadWriter(PublicIntakeStore intake) => _intake = intake;

    public async Task<CaptureResult> ApplyAsync(CaptureRequest req, CancellationToken ct = default)
    {
        string? name = null, company = null, email = null, phone = null;
        var custom = new Dictionary<string, string>();
        var noteLines = new List<string>();
        foreach (var answer in req.Answers)
        {
            var target = req.Mapping.GetValueOrDefault(answer.Key);
            noteLines.Add($"{target ?? answer.Label}: {answer.Text}");
            switch (target)
            {
                case "name": name = answer.Text; break;
                case "company": company = answer.Text; break;
                case "email": email = answer.Text; break;
                case "phone": phone = answer.Text; break;
                case string t when t.StartsWith("custom.", StringComparison.Ordinal):
                    custom[t["custom.".Length..]] = answer.Text;
                    break;
                // Unmapped, or mapped to a target this app doesn't apply as a typed field - the answer still lands in the
                // note above, never silently dropped.
            }
        }
        if (req.ExtraCustom is not null)
            foreach (var (key, value) in req.ExtraCustom) custom[key] = value;

        var noteBody = $"Submitted via {req.VendorLabel}: " + string.Join("; ", noteLines);
        if (string.IsNullOrEmpty(name)) name = company ?? email ?? req.FallbackName;

        // BACKFILL: the CRM already knowing this person (an open OR a closed deal, by the same DuplicateMatchService every
        // other intake path uses) means nothing is written at all - no lead, no note (owner 2026-11-14). Whatever the org's
        // duplicate mode says only governs LIVE arrivals.
        if (req.Mode == CaptureMode.Backfill)
        {
            var openMatch = await _intake.FindMostRecentOpenMatchAsync(email, phone, phoneCountryCode: null, ct: ct);
            if (openMatch is not null) return new CaptureResult(CaptureOutcome.Skipped, openMatch);
            var closedMatchForBackfill = await _intake.FindMostRecentClosedMatchAsync(email, phone, phoneCountryCode: null, ct: ct);
            if (closedMatchForBackfill is not null) return new CaptureResult(CaptureOutcome.Skipped, closedMatchForBackfill.LeadId);
        }

        // LIVE - exactly LinkedInLeadSyncProcess's long-standing rules (design e6-connectors §11 answer 6). "website_rule" and
        // "add_note" both look for the same OPEN match (a match against a CLOSED lead never blocks) and append a note to it;
        // "new_lead" never looks, so an open deal for the same person never suppresses a second lead.
        var openMatchLeadId = req.Mode == CaptureMode.Live && req.DuplicateMode != LinkedInDuplicateMode.NewLead
            ? await _intake.FindMostRecentOpenMatchAsync(email, phone, phoneCountryCode: null, ct: ct)
            : null;
        if (openMatchLeadId is { } matchedLeadId)
        {
            await _intake.AddIntakeNoteAsync(matchedLeadId, noteBody, ct, source: req.ActivitySource);
            return new CaptureResult(CaptureOutcome.NoteAdded, matchedLeadId);
        }

        // Owner answer 2026-09-29: a CLOSED-only match is "a new opportunity" - a new lead linked to the same account/contact,
        // deal-type hinted "renewal" when the earlier deal was WON, with a timeline note naming the earlier deal.
        var closedMatch = req.DuplicateMode == LinkedInDuplicateMode.NewLead
            ? null
            : await _intake.FindMostRecentClosedMatchAsync(email, phone, phoneCountryCode: null, ct: ct);

        var decision = await _intake.PickOwnerAsync(req.Source, ct);
        var teamId = decision.TeamForced
            ? decision.ForcedTeamId
            : decision.Owner?.OrgId is Guid ownerOrgId
                ? await _intake.ResolveLeadTeamAsync(ownerOrgId, decision.Owner!.Id, ct)
                : null;

        var leadId = await _intake.CreateLeadAsync(
            decision.Owner?.Id, name, company, email, phone, req.Source, message: null, teamId,
            decision.Owner, decision, ct, custom,
            req.DomainEventType,
            newLeadId => req.EventPayload(newLeadId, decision.Reason),
            domainEventActorId: null,
            captureNoteBody: noteBody,
            accountId: closedMatch?.AccountId,
            contactId: closedMatch?.ContactId,
            dealType: closedMatch is { IsWon: true } ? "renewal" : null,
            leadFormId: req.LeadFormId);

        if (closedMatch is not null)
        {
            // Separate from the capture note (and AuthorId-null like every unattended note) so it still lands when the org has
            // no owner to fall back to.
            await _intake.AddIntakeNoteAsync(
                leadId, $"New opportunity — related to the earlier deal \"{closedMatch.LeadName}\".",
                ct, source: req.ActivitySource);
        }
        return new CaptureResult(CaptureOutcome.Created, leadId);
    }
}

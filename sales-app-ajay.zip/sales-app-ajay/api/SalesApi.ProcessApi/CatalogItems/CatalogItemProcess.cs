using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.CatalogItems;

namespace SalesApi.ProcessLayer.CatalogItems;

/// <summary>
/// The rules behind the catalogue of what an account can OWN: the closed
/// `Kind` vocabulary, slug derivation from a label, and the (org, key)
/// uniqueness + archive/restore rules — assembled from System reads and
/// writes, knowing no screen.
///
/// Ninth/tenth domain migrated. Everything here used to live inline in
/// `CatalogItemsController`; the rules did not change, only where they run.
/// </summary>
public sealed class CatalogItemProcess
{
    // Closed vocabulary, validated server-side — see the Kind property comment
    // on CatalogItem. Kept as an explicit list, the same shape as
    // CustomFieldsController.ValidTypes, so the next kind is one addition here.
    private static readonly string[] ValidKinds = { "product", "service" };

    private readonly CatalogItemStore _store;
    public CatalogItemProcess(CatalogItemStore store) => _store = store;

    private static CatalogItemDto ToDto(CatalogItem c) =>
        new(c.Id, c.Key, c.Name, c.Kind, c.Description, c.SortOrder, c.CreatedAt, c.UpdatedAt, c.ArchivedAt, c.Price, c.ScopedTeamIds);

    private static string? PriceError(decimal? price) =>
        price is < 0 ? "price cannot be negative" : null;

    /// <summary>
    /// E10.2 - may a caller with this team scope generate a proposal for a service carrying these scoped team
    /// ids? The knowledge-collection rule verbatim (KnowledgeStore.CandidateChunksAsync): everyone-in-scope
    /// (org admin / AllTeams) always; an empty list = whole org; otherwise the caller must belong to at least
    /// one listed team.
    /// </summary>
    public static bool AllowsTeamScope(IReadOnlyCollection<string> scopedTeamIds, TeamScope caller) =>
        caller.AllTeams
        || scopedTeamIds.Count == 0
        || (caller.TeamIds is { Length: > 0 } ids && ids.Any(id => scopedTeamIds.Contains(id.ToString())));

    /// <summary>Validates and stores a service's team scope. Returns an error, or null when applied.</summary>
    private async Task<string?> ApplyScopeAsync(CatalogItem item, List<string>? requested, CancellationToken ct)
    {
        if (requested is null) return null;
        var ids = new List<Guid>();
        foreach (var raw in requested)
        {
            if (!Guid.TryParse(raw, out var id)) return $"\"{raw}\" is not a team id";
            if (!ids.Contains(id)) ids.Add(id);
        }
        if (ids.Count > 0 && item.Kind != "service")
            return "Only a service can be limited to teams";
        var live = await _store.ActiveTeamIdsAsync(ids, ct);
        foreach (var id in ids)
            if (!live.Contains(id)) return $"Team {id} was not found";
        item.ScopedTeamIds = ids.Select(id => id.ToString()).ToList();
        return null;
    }

    /// <summary>
    /// E10.2 - the active SERVICES this caller may generate a proposal for, optionally for one deal: the
    /// precedent (knowledge collections) scopes by the CALLER's teams, so that is what is applied; the deal
    /// only adds nothing but its visibility (a deal the caller cannot see is NotFound) and the keys it
    /// carries (so a client can sort "already on the deal" first). Archived services are never offered.
    /// </summary>
    public async Task<(List<CatalogItemDto>? Items, string? NotFound)> ListProposableAsync(
        RecordAccessContext caller, Guid? dealId, CancellationToken ct = default)
    {
        if (dealId is { } id && await _store.VisibleDealProductsAsync(id, caller, ct) is null)
            return (null, "Deal not found");
        var scope = caller.IsOrgAdmin ? TeamScope.Everything : caller.Scope;
        var items = (await _store.ListAsync(false, ct))
            .Where(c => c.Kind == "service" && AllowsTeamScope(c.ScopedTeamIds, scope))
            .Select(ToDto).ToList();
        return (items, null);
    }

    /// <summary>E10.2 - enforcement for the generator: is this service (active) open to the caller's teams?</summary>
    public async Task<bool> CanProposeAsync(Guid catalogItemId, RecordAccessContext caller, CancellationToken ct = default)
    {
        var item = await _store.FindActiveAsync(catalogItemId, ct);
        return item is { Kind: "service" }
            && AllowsTeamScope(item.ScopedTeamIds, caller.IsOrgAdmin ? TeamScope.Everything : caller.Scope);
    }

    /// <summary>Why a write could not be made, or the outcome of one that could.
    /// A RESULT rather than an exception — see GoalProcess.Refusal for the same
    /// reasoning — so the endpoint can pick a status without re-deriving the
    /// reason from a string.</summary>
    public enum Outcome { Ok, Invalid, Conflict, NotFound }
    public sealed record Result(Outcome Outcome, CatalogItemDto? Item, string? Error);
    public enum DeleteOutcome { NotFound, Ok }

    public async Task<List<CatalogItemDto>> ListAsync(bool includeArchived, CancellationToken ct = default) =>
        (await _store.ListAsync(includeArchived, ct)).Select(ToDto).ToList();

    public async Task<Result> CreateAsync(CatalogItemInput input, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(input.Name)) return new(Outcome.Invalid, null, "name is required");

        var kind = string.IsNullOrEmpty(input.Kind) ? "product" : input.Kind;
        if (!ValidKinds.Contains(kind))
            return new(Outcome.Invalid, null, $"kind must be one of: {string.Join(", ", ValidKinds)}");

        if (PriceError(input.Price) is { } createPriceError) return new(Outcome.Invalid, null, createPriceError);

        var key = string.IsNullOrWhiteSpace(input.Key) ? CatalogItemKeys.FromLabel(input.Name!) : CatalogItemKeys.FromLabel(input.Key!);
        if (string.IsNullOrEmpty(key)) return new(Outcome.Invalid, null, "name must contain letters or numbers");
        if (await _store.KeyTakenAsync(key, null, ct))
            return new(Outcome.Conflict, null, "An item with a similar name already exists");

        var item = new CatalogItem
        {
            Key = key,
            Name = input.Name!.Trim(),
            Kind = kind,
            Description = string.IsNullOrWhiteSpace(input.Description) ? null : input.Description!.Trim(),
            SortOrder = input.SortOrder ?? 0,
            Price = input.Price,
        };
        if (await ApplyScopeAsync(item, input.ScopedTeamIds, ct) is { } scopeError) return new(Outcome.Invalid, null, scopeError);
        await _store.AddAsync(item, ct);
        return new(Outcome.Ok, ToDto(item), null);
    }

    public async Task<Result> UpdateAsync(Guid id, CatalogItemInput input, CancellationToken ct = default)
    {
        var item = await _store.FindActiveAsync(id, ct);
        if (item is null) return new(Outcome.NotFound, null, "Item not found");

        if (input.Kind is { } kind)
        {
            if (!ValidKinds.Contains(kind))
                return new(Outcome.Invalid, null, $"kind must be one of: {string.Join(", ", ValidKinds)}");
            item.Kind = kind;
        }
        if (input.Name is { } name)
        {
            if (string.IsNullOrWhiteSpace(name)) return new(Outcome.Invalid, null, "name is required");
            item.Name = name.Trim();
        }
        if (input.Description is not null)
            item.Description = string.IsNullOrWhiteSpace(input.Description) ? null : input.Description.Trim();
        if (input.SortOrder is { } sortOrder) item.SortOrder = sortOrder;
        if (PriceError(input.Price) is { } updatePriceError) return new(Outcome.Invalid, null, updatePriceError);
        if (input.ClearPrice == true) item.Price = null;
        else if (input.Price is { } price) item.Price = price;

        if (await ApplyScopeAsync(item, input.ScopedTeamIds, ct) is { } scopeError) return new(Outcome.Invalid, null, scopeError);

        var oldKey = item.Key;
        var newKey = input.Key is null ? oldKey : CatalogItemKeys.FromLabel(input.Key);
        if (newKey != oldKey)
        {
            if (string.IsNullOrEmpty(newKey)) return new(Outcome.Invalid, null, "key must contain letters or numbers");
            if (await _store.KeyTakenAsync(newKey, id, ct))
                return new(Outcome.Conflict, null, "Another item already uses that key");
            // Deals store this key (Lead.Products), so changing it under a deal
            // would orphan the deal's product. Rename the item (Name) instead -
            // that needs no propagation.
            if (await _store.DealsUsingKeyAsync(oldKey, ct) > 0)
                return new(Outcome.Invalid, null, "Deals already use this item, so its key cannot change. Rename the item instead.");
            item.Key = newKey;
        }

        await _store.SaveChangesAsync(ct);
        return new(Outcome.Ok, ToDto(item), null);
    }

    public async Task<List<CatalogItemDto>> ReorderAsync(List<Guid> ids, CancellationToken ct = default)
    {
        var items = await _store.FindManyActiveAsync(ids, ct);
        foreach (var item in items) item.SortOrder = ids.IndexOf(item.Id);
        await _store.SaveChangesAsync(ct);
        return items.OrderBy(c => c.SortOrder).Select(ToDto).ToList();
    }

    public async Task<DeleteOutcome> DeleteAsync(Guid id, CancellationToken ct = default)
    {
        var item = await _store.FindAnyAsync(id, ct);
        if (item is null) return DeleteOutcome.NotFound;
        if (item.ArchivedAt is not null) return DeleteOutcome.Ok;

        item.ArchivedAt = DateTime.UtcNow;
        await _store.SaveChangesAsync(ct);
        return DeleteOutcome.Ok;
    }

    public async Task<Result> RestoreAsync(Guid id, CancellationToken ct = default)
    {
        var item = await _store.FindAnyAsync(id, ct);
        if (item is null) return new(Outcome.NotFound, null, "Item not found");
        if (item.ArchivedAt is null) return new(Outcome.Ok, ToDto(item), null);

        if (await _store.KeyTakenAsync(item.Key, id, ct))
            return new(Outcome.Conflict, null,
                $"Another item already uses the key \"{item.Key}\" — rename one before restoring.");

        item.ArchivedAt = null;
        await _store.SaveChangesAsync(ct);
        return new(Outcome.Ok, ToDto(item), null);
    }
}

using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// What a partner is owed and why: the append-only ledger (read here, written by <c>PartnerCapture</c> inside the payment's own save), the clawbacks that fell OUTSIDE
/// the plan's window and wait for a manager (Q14), manual corrections, frozen period statements, and the stored aggregate (<see cref="PartnerStats"/>).
///
/// Every figure here is ex VAT and sits behind the Partner commercials category: the controller needs partners.* and this class refuses a caller below a raw read. Nothing
/// here can edit or delete a ledger row - a correction is a new entry that names what it reverses.
/// </summary>
public sealed class PartnerLedgerProcess
{
    private readonly PartnerLedgerStore _ledger;
    private readonly ChannelPartnerStore _partners;
    private readonly OrgSettingsReader _settings;
    private readonly ProcessLayer.Approvals.ApprovalChainProcess _chains;
    public PartnerLedgerProcess(PartnerLedgerStore ledger, ChannelPartnerStore partners, OrgSettingsReader settings, ProcessLayer.Approvals.ApprovalChainProcess chains)
    {
        _ledger = ledger;
        _partners = partners;
        _settings = settings;
        _chains = chains;
    }

    public const int MaxPageSize = 200;

    private static CpResult<T> NeedsCommercials<T>() =>
        Cp.Forbidden<T>("Your role can't see partner commercials.", "partner_commercials_hidden");

    private async Task<CpResult<ChannelPartnerStore.AccountFacts>> VisiblePartnerAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct)
    {
        var account = await _partners.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<ChannelPartnerStore.AccountFacts>("Account not found");
        return Cp.Ok(account);
    }

    // ---- ledger ------------------------------------------------------------------------------------

    // internal, not private: the partner-costs list (PartnerMilestoneProcess) returns the SAME entry shape.
    internal static PartnerLedgerEntryDto ToDto(PartnerLedgerEntry e, IReadOnlyDictionary<Guid, string> leads, ISet<Guid> settled) =>
        new(e.Id, e.PartnerAccountId, e.LeadId, e.LeadId is Guid l ? leads.GetValueOrDefault(l) : null, e.DealPartnerId, e.Direction, e.Kind, e.Amount, e.Currency,
            e.PaymentId, e.InvoiceId, e.ReverseOfEntryId, e.PayoutId, e.PlanVersionId, e.RuleKey, e.RuleScope,
            e.BaseAmount, e.BaseDelta, e.Rate, e.EarnedAt, e.PayableOn, e.ReversibleUntil, e.PaymentTermsDays,
            e.Reason, e.CreatedById, e.CreatedAt, settled.Contains(e.Id), e.MilestoneId, e.RemittanceId);

    /// <summary>A partner's ledger, or one deal's. Newest first. A page of rows plus the header totals of the whole filtered set.</summary>
    public async Task<CpResult<PartnerLedgerPageDto>> PageAsync(
        RecordAccessContext ctx, Guid? partnerAccountId, Guid? leadId, Guid? dealPartnerId, string? kind,
        DateTime? from, DateTime? to, bool? settled, int skip, int take, string? direction = null, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<PartnerLedgerPageDto>();
        // ONE direction per page and per header total: payable (the default, exactly what Phase 1 returned), cost, or receivable. They are never summed together.
        direction = string.IsNullOrWhiteSpace(direction) ? ChannelPartnerVocab.Direction.Payable : direction.Trim();
        if (!ChannelPartnerVocab.Direction.IsValid(direction))
            return Cp.Invalid<PartnerLedgerPageDto>("direction must be payable, cost or receivable.", "bad_direction");
        if (partnerAccountId is null && leadId is null && dealPartnerId is null)
            return Cp.Invalid<PartnerLedgerPageDto>("Pick a partner or a deal.", "filter_required");
        if (!string.IsNullOrWhiteSpace(kind) && Array.IndexOf(ChannelPartnerVocab.EntryKind.All, kind) < 0)
            return Cp.Invalid<PartnerLedgerPageDto>("kind must be accrual, clawback, adjustment or payout.", "bad_kind");

        if (partnerAccountId is Guid p)
        {
            var partner = await VisiblePartnerAsync(ctx, p, ct);
            if (!partner.IsOk) return Cp.As<PartnerLedgerPageDto, ChannelPartnerStore.AccountFacts>(partner);
        }
        if (leadId is Guid l)
        {
            var lead = await _partners.LeadFactsAsync(l, ct);
            if (lead is null || !RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId)) return Cp.NotFound<PartnerLedgerPageDto>("Deal not found");
        }
        if (dealPartnerId is Guid d)
        {
            var dp = await _ledger.FindDealPartnerAsync(d, ct);
            var lead = dp is null ? null : await _partners.LeadFactsAsync(dp.LeadId, ct);
            if (dp is null || lead is null || !RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId)) return Cp.NotFound<PartnerLedgerPageDto>("Deal partner not found");
        }

        var filter = new PartnerLedgerStore.Filter(partnerAccountId, leadId, dealPartnerId, string.IsNullOrWhiteSpace(kind) ? null : kind, from, to, settled, direction);
        var (rows, total) = await _ledger.PageAsync(filter, Math.Max(0, skip), Math.Clamp(take <= 0 ? 50 : take, 1, MaxPageSize), ct);
        var totals = await _ledger.FilteredTotalsAsync(filter, ct);
        var leadNames = await _ledger.LeadNamesAsync(rows.Where(r => r.LeadId != null).Select(r => r.LeadId!.Value).Distinct().ToList(), ct);
        var settledIds = await _ledger.SettledAsync(rows.Select(r => r.Id).ToList(), ct);
        return Cp.Ok(new PartnerLedgerPageDto(
            rows.Select(r => ToDto(r, leadNames, settledIds)).ToList(), totals.Accrued, totals.Clawed, totals.Paid, totals.Accrued - totals.Clawed - totals.Paid, total));
    }

    /// <summary>
    /// A manager's manual correction: a NEW signed entry (never an edit) with a reason, optionally naming the entry it reverses. It sits outside the plan's formula (reconciliation
    /// never "corrects" it back) and counts in the balance and the aggregate like any other entry.
    /// </summary>
    public async Task<CpResult<PartnerAdjustmentResultDto>> AdjustAsync(
        RecordAccessContext ctx, Guid partnerAccountId, PartnerLedgerAdjustInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return Cp.Invalid<PartnerAdjustmentResultDto>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);
        var partner = await VisiblePartnerAsync(ctx, partnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<PartnerAdjustmentResultDto, ChannelPartnerStore.AccountFacts>(partner);
        var reason = input.Reason?.Trim();
        if (string.IsNullOrEmpty(reason)) return Cp.Invalid<PartnerAdjustmentResultDto>("A reason is required for a ledger correction.", "reason_required");
        if (reason.Length > 1000) return Cp.Invalid<PartnerAdjustmentResultDto>("The reason is at most 1000 characters.", "reason_too_long");
        var amount = PartnerPlanEngine.Money(input.Amount);
        if (amount == 0m || Math.Abs(amount) > 100_000_000m) return Cp.Invalid<PartnerAdjustmentResultDto>("Enter a non-zero amount (ex VAT).", "bad_amount");

        DealPartner? dp = null;
        if (input.DealPartnerId is Guid dpId)
        {
            dp = await _ledger.FindDealPartnerAsync(dpId, ct);
            if (dp is null || dp.PartnerAccountId != partnerAccountId) return Cp.NotFound<PartnerAdjustmentResultDto>("Deal partner not found");
        }
        if (input.ReverseOfEntryId is Guid rev)
        {
            var original = await _ledger.FindEntryAsync(rev, ct);
            if (original is null || original.PartnerAccountId != partnerAccountId) return Cp.NotFound<PartnerAdjustmentResultDto>("The entry to reverse was not found");
        }

        // F9 (owner 2026-10-19): managers adjust with a reason; ABOVE the org's limit the adjustment goes through the approval chains. Nothing is written to the ledger until
        // the chain approves (ApprovalProcess.ApplyDecisionAsync -> PartnerAdjustments), so a pending request moves no money.
        var limit = (await _settings.GetChannelPartnerSettingsAsync()).AdjustmentApprovalLimit;
        if (limit is { } max && Math.Abs(amount) > max)
        {
            var requestId = Guid.NewGuid();
            var approvalId = Guid.NewGuid();
            var adjustment = new PartnerAdjustmentRequest
            {
                Id = requestId, PartnerAccountId = partnerAccountId, DealPartnerId = dp?.Id, ReverseOfEntryId = input.ReverseOfEntryId,
                Amount = amount, Reason = reason, RequestedById = actorId, ApprovalRequestId = approvalId,
            };
            var approval = new ApprovalRequest
            {
                Id = approvalId, RequesterId = actorId, Type = ApprovalTypes.PartnerAdjustment, LeadId = Guid.Empty, Amount = amount,
                Reason = $"{partner.Value!.Name}: {reason}", RecordType = "partner_adjustment", RecordId = requestId,
            };
            _ledger.AddAdjustmentRequest(adjustment);
            _ledger.AddApprovalRequest(approval);
            await _ledger.SaveChangesAsync(ct);
            var instance = await _chains.ResolveAndStartAsync(approval, null, ct);
            if (instance is null)
            {
                _ledger.RemoveApprovalRequest(approval);
                _ledger.RemoveAdjustmentRequest(adjustment);
                await _ledger.SaveChangesAsync(ct);
                return Cp.Conflict<PartnerAdjustmentResultDto>("No one is set up to approve partner adjustments. Ask an admin.", "no_approver");
            }
            return Cp.Ok(new PartnerAdjustmentResultDto(null, true, requestId, approvalId, instance.Id));
        }

        var now = DateTime.UtcNow;
        var entry = new PartnerLedgerEntry
        {
            Id = Guid.NewGuid(),
            PartnerAccountId = partnerAccountId,
            LeadId = dp?.LeadId,
            DealPartnerId = dp?.Id,
            Direction = ChannelPartnerVocab.Direction.Payable,
            Kind = ChannelPartnerVocab.EntryKind.Adjustment,
            Amount = amount,
            Currency = await _ledger.OrgCurrencyAsync(ct),
            ReverseOfEntryId = input.ReverseOfEntryId,
            SourceKey = $"manual:{Guid.NewGuid():N}",
            PlanVersionId = dp?.PlanVersionId,
            RuleKey = "manual",
            RuleScope = dp?.RuleScope ?? ChannelPartnerVocab.RuleScope.Plan,
            EarnedAt = now,
            PayableOn = now,
            Reason = reason,
            CreatedById = actorId,
        };
        _ledger.AddEntry(entry);
        await _ledger.SaveChangesAsync(ct);
        return Cp.Ok(new PartnerAdjustmentResultDto(ToDto(entry, new Dictionary<Guid, string>(), new HashSet<Guid>()), false, null, null, null));
    }

    // ---- clawback decisions (Q14) -----------------------------------------------------------------------

    private async Task<List<PartnerClawbackDecisionDto>> ToDtosAsync(List<PartnerClawbackDecision> rows, CancellationToken ct)
    {
        var names = await _partners.AccountNamesAsync(rows.Select(r => r.PartnerAccountId).Distinct().ToList(), ct);
        return rows.Select(d => new PartnerClawbackDecisionDto(
            d.Id, d.PartnerAccountId, names.GetValueOrDefault(d.PartnerAccountId), d.LeadId, d.DealPartnerId, d.Amount, d.Status, d.Reason,
            d.InvoiceId, d.TaskId, d.DecidedById, d.DecidedAt, d.DecisionNote, d.CreatedAt)).ToList();
    }

    public async Task<CpResult<List<PartnerClawbackDecisionDto>>> ListDecisionsAsync(
        RecordAccessContext ctx, Guid? partnerAccountId, string? status, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<List<PartnerClawbackDecisionDto>>();
        if (partnerAccountId is Guid p)
        {
            var partner = await VisiblePartnerAsync(ctx, p, ct);
            if (!partner.IsOk) return Cp.As<List<PartnerClawbackDecisionDto>, ChannelPartnerStore.AccountFacts>(partner);
        }
        var rows = await _ledger.ListDecisionsAsync(partnerAccountId, status, ct);
        if (partnerAccountId is null)
        {
            var facts = await _partners.AccountFactsManyAsync(rows.Select(r => r.PartnerAccountId).Distinct().ToList(), ct);
            rows = rows.Where(r => facts.TryGetValue(r.PartnerAccountId, out var f) && RecordAccess.CanView(ctx, f.OwnerId, f.TeamId)).ToList();
        }
        return Cp.Ok(await ToDtosAsync(rows, ct));
    }

    /// <summary>
    /// Approve writes the negative clawback entry (position and balance both fall by the amount) and waive lets the partner keep it; either way the decision and its
    /// task are closed in one save. A decision already decided - or cancelled because the money was collected again - is a 409.
    /// </summary>
    public async Task<CpResult<PartnerClawbackDecisionDto>> DecideAsync(
        RecordAccessContext ctx, Guid decisionId, PartnerClawbackDecideInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return Cp.Invalid<PartnerClawbackDecisionDto>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);
        var decision = await _ledger.FindDecisionAsync(decisionId, ct);
        if (decision is null) return Cp.NotFound<PartnerClawbackDecisionDto>("Decision not found");
        var partner = await VisiblePartnerAsync(ctx, decision.PartnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<PartnerClawbackDecisionDto, ChannelPartnerStore.AccountFacts>(partner);
        if (decision.Status != ChannelPartnerVocab.DecisionStatus.Pending)
            return Cp.Conflict<PartnerClawbackDecisionDto>("This decision has already been made.", "already_decided");

        var now = DateTime.UtcNow;
        if (input.Approve)
        {
            var dp = await _ledger.FindDealPartnerAsync(decision.DealPartnerId, ct);
            var entry = new PartnerLedgerEntry
            {
                Id = Guid.NewGuid(),
                PartnerAccountId = decision.PartnerAccountId,
                LeadId = decision.LeadId,
                DealPartnerId = decision.DealPartnerId,
                Direction = ChannelPartnerVocab.Direction.Payable,
                // A clawback, not an adjustment: it brings the ledger back in line with the plan's target, so reconciliation counts it in the formula position.
                Kind = ChannelPartnerVocab.EntryKind.Clawback,
                Amount = -decision.Amount,
                Currency = await _ledger.OrgCurrencyAsync(ct),
                InvoiceId = decision.InvoiceId,
                SourceKey = $"decision:{decision.Id:N}",
                PlanVersionId = dp?.PlanVersionId,
                RuleKey = "decision",
                RuleScope = dp?.RuleScope ?? ChannelPartnerVocab.RuleScope.Plan,
                EarnedAt = now,
                PayableOn = now,
                Reason = $"Clawback approved outside the window. {input.Note}".Trim(),
                CreatedById = actorId,
            };
            _ledger.AddEntry(entry);
            decision.LedgerEntryId = entry.Id;
            decision.Status = ChannelPartnerVocab.DecisionStatus.Approved;
        }
        else decision.Status = ChannelPartnerVocab.DecisionStatus.Waived;

        decision.DecidedById = actorId;
        decision.DecidedAt = now;
        decision.DecisionNote = string.IsNullOrWhiteSpace(input.Note) ? null : input.Note.Trim();
        if (decision.TaskId is Guid taskId && await _ledger.FindTaskAsync(taskId, ct) is { } task && task.Status == TaskStatuses.Open)
        {
            task.Status = TaskStatuses.Done;
            task.CompletedAt = now;
            task.CompletedById = actorId;
            task.UpdatedAt = now;
        }
        await _ledger.SaveChangesAsync(ct);
        return Cp.Ok((await ToDtosAsync([decision], ct))[0]);
    }

    // ---- statements --------------------------------------------------------------------------------------

    /// <summary>The default period: the previous full calendar month in the org's own calendar.</summary>
    private static (DateOnly Start, DateOnly End) DefaultPeriod(CalendarDto cal)
    {
        var today = ReportingCalendar.Today(cal);
        var firstThisMonth = new DateOnly(today.Year, today.Month, 1);
        return (firstThisMonth.AddMonths(-1), firstThisMonth.AddDays(-1));
    }

    private async Task<CpResult<PartnerStatementDto>> BuildAsync(
        RecordAccessContext ctx, Guid partnerAccountId, PartnerStatementInput input, CancellationToken ct)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<PartnerStatementDto>();
        var partner = await VisiblePartnerAsync(ctx, partnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<PartnerStatementDto, ChannelPartnerStore.AccountFacts>(partner);

        var cal = await _ledger.CalendarAsync();
        var (defStart, defEnd) = DefaultPeriod(cal);
        var start = input.PeriodStart ?? defStart;
        var end = input.PeriodEnd ?? defEnd;
        if (end < start) return Cp.Invalid<PartnerStatementDto>("The period ends before it starts.", "bad_period");
        if (end.DayNumber - start.DayNumber > 400) return Cp.Invalid<PartnerStatementDto>("A statement covers at most about a year.", "bad_period");

        var direction = string.IsNullOrWhiteSpace(input.Direction) ? ChannelPartnerVocab.Direction.Payable : input.Direction.Trim();
        if (!ChannelPartnerVocab.Direction.IsValid(direction))
            return Cp.Invalid<PartnerStatementDto>("direction must be payable, cost or receivable.", "bad_direction");
        var (opening, period) = await _ledger.StatementEntriesAsync(partnerAccountId,
            ReportingCalendar.StartOfDayUtc(cal, start), ReportingCalendar.EndOfDayUtc(cal, end), direction, ct);
        decimal accruals = 0m, clawbacks = 0m, payouts = 0m;
        foreach (var e in period)
        {
            var (a, c, p) = PartnerStatsService.Split(e.Kind, e.Amount);
            accruals += a; clawbacks += c; payouts += p;
        }
        var leadNames = await _ledger.LeadNamesAsync(period.Where(e => e.LeadId != null).Select(e => e.LeadId!.Value).Distinct().ToList(), ct);
        var lines = period.Select(e => new PartnerStatementLineDto(
            e.Id, e.LeadId, e.LeadId is Guid l ? leadNames.GetValueOrDefault(l) : null, e.Kind, e.Amount, e.EarnedAt, e.BaseDelta, e.Rate)).ToList();
        return Cp.Ok(new PartnerStatementDto(
            null, null, partnerAccountId, partner.Value!.Name, start, end, ChannelPartnerVocab.StatementStatus.Preview,
            opening, accruals, clawbacks, payouts, opening + accruals - clawbacks - payouts, lines, null, null, direction));
    }

    /// <summary>A statement for the period, computed now and not stored: opening balance, accruals, clawbacks, payouts, closing, with a line per ledger entry.</summary>
    public Task<CpResult<PartnerStatementDto>> PreviewStatementAsync(RecordAccessContext ctx, Guid partnerAccountId, PartnerStatementInput input, CancellationToken ct = default) =>
        BuildAsync(ctx, partnerAccountId, input, ct);

    /// <summary>Freezes the period's statement under the next STM number. The lines are snapshotted, so a later correction does not rewrite what the partner was sent.</summary>
    public async Task<CpResult<PartnerStatementDto>> IssueStatementAsync(
        RecordAccessContext ctx, Guid partnerAccountId, PartnerStatementInput input, Guid actorId, CancellationToken ct = default)
    {
        var built = await BuildAsync(ctx, partnerAccountId, input, ct);
        if (!built.IsOk) return built;
        var s = built.Value!;
        for (var attempt = 0; attempt < 3; attempt++)
        {
            var row = new PartnerStatement
            {
                Id = Guid.NewGuid(),
                PartnerAccountId = partnerAccountId,
                Number = await _ledger.NextStatementNumberAsync(DateTime.UtcNow.Year, ct),
                PeriodStart = s.PeriodStart, PeriodEnd = s.PeriodEnd,
                OpeningBalance = s.OpeningBalance, Accruals = s.Accruals, Clawbacks = s.Clawbacks, Payouts = s.Payouts, ClosingBalance = s.ClosingBalance,
                Direction = s.Direction,
                LinesJson = System.Text.Json.JsonSerializer.Serialize(s.Lines, ChannelPartnerJson.Options),
                IssuedAt = DateTime.UtcNow,
                IssuedById = actorId,
            };
            if (await _ledger.TryAddStatementAsync(row, ct)) return Cp.Ok(ToDto(row, s.PartnerName));
        }
        return Cp.Conflict<PartnerStatementDto>("Other statements were issued at the same moment. Try again.", "number_race");
    }

    internal static PartnerStatementDto ToDto(PartnerStatement s, string partnerName) =>
        new(s.Id, s.Number, s.PartnerAccountId, partnerName, s.PeriodStart, s.PeriodEnd, ChannelPartnerVocab.StatementStatus.Issued,
            s.OpeningBalance, s.Accruals, s.Clawbacks, s.Payouts, s.ClosingBalance,
            System.Text.Json.JsonSerializer.Deserialize<List<PartnerStatementLineDto>>(s.LinesJson, ChannelPartnerJson.Options) ?? [], s.IssuedAt, s.IssuedById, s.Direction);

    /// <param name="direction">null = every direction (each statement carries its own); payable / cost / receivable narrows the list.</param>
    public async Task<CpResult<List<PartnerStatementDto>>> ListStatementsAsync(RecordAccessContext ctx, Guid partnerAccountId, string? direction = null, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<List<PartnerStatementDto>>();
        var partner = await VisiblePartnerAsync(ctx, partnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<List<PartnerStatementDto>, ChannelPartnerStore.AccountFacts>(partner);
        if (!string.IsNullOrWhiteSpace(direction) && !ChannelPartnerVocab.Direction.IsValid(direction.Trim()))
            return Cp.Invalid<List<PartnerStatementDto>>("direction must be payable, cost or receivable.", "bad_direction");
        // The list carries totals only; open one for its lines.
        return Cp.Ok((await _ledger.ListStatementsAsync(partnerAccountId, string.IsNullOrWhiteSpace(direction) ? null : direction.Trim(), ct))
            .Select(s => ToDto(s, partner.Value!.Name) with { Lines = [] }).ToList());
    }

    public async Task<CpResult<PartnerStatementDto>> GetStatementAsync(RecordAccessContext ctx, Guid statementId, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<PartnerStatementDto>();
        var s = await _ledger.FindStatementAsync(statementId, ct);
        if (s is null) return Cp.NotFound<PartnerStatementDto>("Statement not found");
        var partner = await VisiblePartnerAsync(ctx, s.PartnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<PartnerStatementDto, ChannelPartnerStore.AccountFacts>(partner);
        return Cp.Ok(ToDto(s, partner.Value!.Name));
    }

    /// <summary>The statement as a PDF, on the SAME renderer the scheduled reports use (SimpleReportPdf) - no second document engine. Q7: Phase 1 sends PDF statements.</summary>
    public async Task<CpResult<(string FileName, byte[] Pdf)>> StatementPdfAsync(RecordAccessContext ctx, Guid statementId, CancellationToken ct = default)
    {
        var got = await GetStatementAsync(ctx, statementId, ct);
        if (!got.IsOk) return Cp.As<(string FileName, byte[] Pdf), PartnerStatementDto>(got);
        return Cp.Ok(await RenderStatementPdfAsync(got.Value!, ct));
    }

    /// <summary>
    /// The one statement renderer: the staff download and the partner portal's both call it, so a partner's PDF is byte-for-byte what the channel team would send. The caller has
    /// already decided who may see the statement (staff: the Partner commercials level; portal: it is the caller's own partner's).
    /// </summary>
    public async Task<(string FileName, byte[] Pdf)> RenderStatementPdfAsync(PartnerStatementDto s, CancellationToken ct = default)
    {
        var currency = await _ledger.OrgCurrencyAsync(ct);
        var cal = await _ledger.CalendarAsync();
        string M(decimal v) => MoneyFormat.Exact(v, currency);

        // One PDF renderer for all three directions; only the words change. A receivable statement is what the partner owes US; a cost statement is what we owe an integrator.
        var (earned, reversed, settled, title) = s.Direction switch
        {
            ChannelPartnerVocab.Direction.Receivable => ("Billed to the partner in the period", "Credited in the period", "Remitted by the partner in the period", "Partner receivable statement"),
            ChannelPartnerVocab.Direction.Cost => ("Partner cost accepted in the period", "Reversed in the period", "Paid in the period", "Partner cost statement"),
            _ => ("Earned in the period", "Reversed in the period", "Paid in the period", "Partner statement"),
        };
        var sections = new List<SimpleReportPdf.Section>
        {
            new("Summary (all amounts before VAT)",
            [
                new("Opening balance", M(s.OpeningBalance)),
                new(earned, M(s.Accruals)),
                new(reversed, M(-s.Clawbacks)),
                new(settled, M(-s.Payouts)),
                new("Closing balance", M(s.ClosingBalance)),
            ]),
        };
        if (s.Lines.Count > 0)
            sections.Add(new("Entries", s.Lines.Select(l => new SimpleReportPdf.Row(
                $"{ReportingCalendar.DayOf(cal, l.EarnedAt):yyyy-MM-dd}  {l.Kind}  {l.LeadName}".Trim(), M(l.Amount))).ToList()));

        var pdf = SimpleReportPdf.Render($"{title} {s.Number}", $"{s.PartnerName} - {s.PeriodStart:yyyy-MM-dd} to {s.PeriodEnd:yyyy-MM-dd}",
            sections, s.IssuedAt ?? DateTime.UtcNow, cal.TimeZoneId);
        return ($"{s.Number}.pdf", pdf);
    }

    // ---- the stored aggregate -------------------------------------------------------------------------------

    /// <summary>Per partner per month, from the stored PartnerStats rows only (never the live ledger). Rows of partners the caller can't see are left out.</summary>
    public async Task<CpResult<PartnerStatsDto>> StatsAsync(
        RecordAccessContext ctx, Guid? partnerAccountId, DateOnly? from, DateOnly? to, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<PartnerStatsDto>();
        if (partnerAccountId is Guid p)
        {
            var partner = await VisiblePartnerAsync(ctx, p, ct);
            if (!partner.IsOk) return Cp.As<PartnerStatsDto, ChannelPartnerStore.AccountFacts>(partner);
        }
        var rows = await _ledger.StatsAsync(new PartnerLedgerStore.StatsFilter(partnerAccountId, from, to), ct);
        var ids = rows.Select(r => r.PartnerAccountId).Distinct().ToList();
        var facts = await _partners.AccountFactsManyAsync(ids, ct);
        rows = rows.Where(r => facts.TryGetValue(r.PartnerAccountId, out var f) && RecordAccess.CanView(ctx, f.OwnerId, f.TeamId)).ToList();
        var dtos = rows.Select(r => new PartnerStatsRowDto(
            r.PartnerAccountId, facts.GetValueOrDefault(r.PartnerAccountId)?.Name, r.Month, r.SourcedCount, r.SourcedValue, r.WonCount, r.WonValue,
            r.CollectedBase, r.Accrued, r.Clawed, r.Paid, r.CostAccrued, r.CostPaid, r.ReceivableBilled, r.ReceivableRemitted,
            new PartnerStockStatsDto(r.WholesaleValue, r.StockUnitsBought, r.StockUnitsUsed, r.StockUnitsExpired, r.StockValueBought, r.StockValueDrawn, r.StockValueForfeited), r.FspShare)).ToList();
        return Cp.Ok(new PartnerStatsDto(
            dtos, dtos.Sum(r => r.SourcedCount), dtos.Sum(r => r.SourcedValue), dtos.Sum(r => r.WonCount), dtos.Sum(r => r.WonValue),
            dtos.Sum(r => r.CollectedBase), dtos.Sum(r => r.Accrued), dtos.Sum(r => r.Clawed), dtos.Sum(r => r.Paid),
            dtos.Sum(r => r.Accrued - r.Clawed - r.Paid),
            // Their own totals: what we owe integrators, and what financial-service partners owe us. Never netted against each other or against Owed above.
            dtos.Sum(r => r.CostAccrued), dtos.Sum(r => r.CostPaid), dtos.Sum(r => r.CostAccrued - r.CostPaid),
            dtos.Sum(r => r.ReceivableBilled), dtos.Sum(r => r.ReceivableRemitted), dtos.Sum(r => r.ReceivableBilled - r.ReceivableRemitted),
            new PartnerStockStatsDto(
                dtos.Sum(r => r.Stock!.WholesaleValue), dtos.Sum(r => r.Stock!.UnitsBought), dtos.Sum(r => r.Stock!.UnitsUsed), dtos.Sum(r => r.Stock!.UnitsExpired),
                dtos.Sum(r => r.Stock!.ValueBought), dtos.Sum(r => r.Stock!.ValueDrawn), dtos.Sum(r => r.Stock!.ValueForfeited)),
            dtos.Sum(r => r.FspShare)));
    }

    /// <summary>Re-derives a partner's (or every partner's) stored figures from the ledger - the deliberate resync, never run by the drift check.</summary>
    public async Task<CpResult<bool>> ResyncStatsAsync(Guid? partnerAccountId, CancellationToken ct = default)
    {
        await _ledger.ResyncStatsAsync(partnerAccountId, ct);
        return Cp.Ok(true);
    }
}

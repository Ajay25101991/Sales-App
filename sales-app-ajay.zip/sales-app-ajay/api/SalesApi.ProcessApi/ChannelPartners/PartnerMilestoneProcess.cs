using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// An SI's milestones (Phase 2; owner decisions 2.5, 2.7, 2.8, 2026-10-19). An integrator is a COST, never a share of client money:
///
///  - The plan says who bills the client (<c>si_billing</c>, per plan). <c>we_bill_pay_si</c>: accepting a milestone writes ONE cost ledger entry payable to the SI, in the SAME
///    save, with the plan's payment terms and hold - and from there it travels the EXISTING payout pipeline (a cost payout, prepared from cost entries, approved on the chains,
///    marked paid). <c>si_bills_client</c>: the acceptance is recorded and NO money is - the SI invoices the client itself.
///  - Accepted by the DEAL OWNER or a partner manager (a rep with hidden partner commercials can accept; they simply never see the amount). Reopening an accepted milestone adds a
///    REVERSING cost entry (the ledger is append-only) and is refused while a payout holds the entry.
///  - The cost is shown as "Partner cost" beside the deal and is NEVER subtracted from any deal figure: nothing here touches a lead.
///
/// Reuse: milestone rows are added through ChannelPartnerStore.AddMilestone (also used by the plan snapshot at attribution); the cost entry is an ordinary PartnerLedgerEntry
/// in the cost direction, so PartnerCapture, PartnerStats, statements, payouts and the drift check all carry it with no new code path; PartnerLedgerProcess shapes the entry DTO.
/// </summary>
public sealed class PartnerMilestoneProcess
{
    private readonly PartnerMilestoneStore _store;
    private readonly ChannelPartnerStore _partners;

    public PartnerMilestoneProcess(PartnerMilestoneStore store, ChannelPartnerStore partners)
    {
        _store = store;
        _partners = partners;
    }

    private static CpResult<T> NeedsCommercials<T>() => Cp.Forbidden<T>("Your role can't see partner commercials.", "partner_commercials_hidden");
    private static CpResult<T> NeedsWrite<T>() => Cp.Invalid<T>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);

    // ---- loading / shaping ---------------------------------------------------------------------------

    /// <summary>The deal partner (tracked, with its plan) and its deal when both are visible to the caller; otherwise a refusal that reads like "not found".</summary>
    private async Task<(DealPartner? Dp, ChannelPartnerStore.LeadFacts? Lead, CpResult<T>? Refusal)> LoadDealPartnerAsync<T>(RecordAccessContext ctx, Guid dealPartnerId, CancellationToken ct)
    {
        var dp = await _partners.FindDealPartnerAsync(dealPartnerId, ct);
        if (dp is null) return (null, null, Cp.NotFound<T>("Deal partner not found"));
        var lead = await _partners.LeadFactsAsync(dp.LeadId, ct);
        if (lead is null || !RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId)) return (null, null, Cp.NotFound<T>("Deal partner not found"));
        return (dp, lead, null);
    }

    private async Task<List<DealPartnerMilestoneDto>> ToDtosAsync(RecordAccessContext ctx, List<DealPartnerMilestone> rows, CancellationToken ct)
    {
        var commercials = Cp.CanReadCommercials(ctx);
        var entryIds = rows.Where(r => r.LedgerEntryId != null).Select(r => r.LedgerEntryId!.Value).ToList();
        var paid = commercials ? await _store.PaidAsync(entryIds, ct) : [];
        var people = await _store.ProfileNamesAsync(rows.Where(r => r.AcceptedById != null).Select(r => r.AcceptedById!.Value).Distinct().ToList(), ct);
        return rows.Select(m => new DealPartnerMilestoneDto(
            m.Id, m.DealPartnerId, m.LeadId, m.Seq, m.Label, commercials ? m.Amount : null, m.Due, m.Status,
            m.AcceptedAt, m.AcceptedById, m.AcceptedById is Guid a ? people.GetValueOrDefault(a) : null, commercials ? m.Note : null,
            commercials ? m.LedgerEntryId : null, m.LedgerEntryId != null, m.LedgerEntryId is Guid e && paid.Contains(e))).ToList();
    }

    // ---- reads ----------------------------------------------------------------------------------------

    /// <summary>The milestones of one SI on a deal, in order. Anyone who sees the deal sees them; amounts come back null below a raw Partner commercials read.</summary>
    public async Task<CpResult<List<DealPartnerMilestoneDto>>> ListAsync(RecordAccessContext ctx, Guid dealPartnerId, CancellationToken ct = default)
    {
        var (dp, _, refusal) = await LoadDealPartnerAsync<List<DealPartnerMilestoneDto>>(ctx, dealPartnerId, ct);
        if (refusal is not null) return refusal;
        return Cp.Ok(await ToDtosAsync(ctx, await _store.ListAsync(dp!.Id, ct), ct));
    }

    /// <summary>Cost entries awaiting a payout (every integrator, oldest first) - the "Partner costs" list. Raw Partner commercials only; each row follows its partner's visibility.</summary>
    public async Task<CpResult<List<PartnerLedgerEntryDto>>> CostsAsync(RecordAccessContext ctx, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<List<PartnerLedgerEntryDto>>();
        var rows = await _store.UnsettledCostAsync(ct);
        var facts = await _partners.AccountFactsManyAsync(rows.Select(r => r.PartnerAccountId).Distinct().ToList(), ct);
        rows = rows.Where(r => facts.TryGetValue(r.PartnerAccountId, out var f) && RecordAccess.CanView(ctx, f.OwnerId, f.TeamId)).ToList();
        var leadNames = await _store.LeadNamesAsync(rows.Where(r => r.LeadId != null).Select(r => r.LeadId!.Value).Distinct().ToList(), ct);
        return Cp.Ok(rows.Select(r => PartnerLedgerProcess.ToDto(r, leadNames, new HashSet<Guid>())).ToList());
    }

    // ---- writes by a partner manager: the milestone list -------------------------------------------------

    private static string? Validate(string? label, decimal? amount)
    {
        if (label is not null && (label.Trim().Length == 0 || label.Trim().Length > 200)) return "A milestone needs a name of at most 200 characters.";
        if (amount is { } a && (a <= 0m || a > 100_000_000m)) return "A milestone amount is above 0 (ex VAT).";
        return null;
    }

    /// <summary>Adds a milestone to an SI on a deal (the plan's template milestones are copied when the SI is attached; this is for one typed on the deal). Amount is frozen here.</summary>
    public async Task<CpResult<DealPartnerMilestoneDto>> CreateAsync(
        RecordAccessContext ctx, Guid dealPartnerId, DealPartnerMilestoneInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<DealPartnerMilestoneDto>();
        var (dp, _, refusal) = await LoadDealPartnerAsync<DealPartnerMilestoneDto>(ctx, dealPartnerId, ct);
        if (refusal is not null) return refusal;
        if (dp!.Role != ChannelPartnerVocab.Role.Integrator) return Cp.Invalid<DealPartnerMilestoneDto>("Milestones belong to an integrator.", "not_an_integrator");
        if (dp.EndedAt != null) return Cp.Conflict<DealPartnerMilestoneDto>("This attribution has ended.", "already_ended");
        if (string.IsNullOrWhiteSpace(input.Label) || input.Amount is null) return Cp.Invalid<DealPartnerMilestoneDto>("A milestone needs a name and an amount.", "label_and_amount_required");
        var bad = Validate(input.Label, input.Amount);
        if (bad is not null) return Cp.Invalid<DealPartnerMilestoneDto>(bad, "bad_milestone");

        var milestone = new DealPartnerMilestone
        {
            Id = Guid.NewGuid(), DealPartnerId = dp.Id, LeadId = dp.LeadId, PartnerAccountId = dp.PartnerAccountId,
            Seq = await _store.NextSeqAsync(dp.Id, ct), Label = input.Label.Trim(), Amount = PartnerPlanEngine.Money(input.Amount.Value), Due = input.Due, CreatedById = actorId,
        };
        _partners.AddMilestone(milestone);
        await _store.SaveChangesAsync(ct);
        return Cp.Ok((await ToDtosAsync(ctx, [milestone], ct))[0]);
    }

    /// <summary>Changes a PLANNED milestone (name, amount, due date). Once accepted or rejected it is a record: reopen it first.</summary>
    public async Task<CpResult<DealPartnerMilestoneDto>> UpdateAsync(
        RecordAccessContext ctx, Guid milestoneId, DealPartnerMilestoneInput input, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<DealPartnerMilestoneDto>();
        var m = await _store.FindAsync(milestoneId, ct);
        if (m is null) return Cp.NotFound<DealPartnerMilestoneDto>("Milestone not found");
        var (_, _, refusal) = await LoadDealPartnerAsync<DealPartnerMilestoneDto>(ctx, m.DealPartnerId, ct);
        if (refusal is not null) return refusal;
        if (m.Status != ChannelPartnerVocab.MilestoneStatus.Planned) return Cp.Conflict<DealPartnerMilestoneDto>("Only a planned milestone can be changed. Reopen it first.", "not_planned");
        var bad = Validate(input.Label, input.Amount);
        if (bad is not null) return Cp.Invalid<DealPartnerMilestoneDto>(bad, "bad_milestone");
        if (input.Label is not null) m.Label = input.Label.Trim();
        if (input.Amount is { } amount) m.Amount = PartnerPlanEngine.Money(amount);
        if (input.Due is not null) m.Due = input.Due;
        m.UpdatedAt = DateTime.UtcNow;
        await _store.SaveChangesAsync(ct);
        return Cp.Ok((await ToDtosAsync(ctx, [m], ct))[0]);
    }

    /// <summary>Removes a PLANNED milestone that nothing has been recorded against.</summary>
    public async Task<CpResult<bool>> DeleteAsync(RecordAccessContext ctx, Guid milestoneId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<bool>();
        var m = await _store.FindAsync(milestoneId, ct);
        if (m is null) return Cp.NotFound<bool>("Milestone not found");
        var (_, _, refusal) = await LoadDealPartnerAsync<bool>(ctx, m.DealPartnerId, ct);
        if (refusal is not null) return refusal;
        if (m.Status != ChannelPartnerVocab.MilestoneStatus.Planned || m.LedgerEntryId != null || await _store.EntryCountAsync(m.Id, ct) > 0)
            return Cp.Conflict<bool>("Only a planned milestone with nothing recorded against it can be removed.", "not_removable");
        _store.Remove(m);
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(true);
    }

    // ---- the decisions: the deal owner OR a partner manager ---------------------------------------------------

    private async Task<(DealPartnerMilestone? M, DealPartner? Dp, CpResult<DealPartnerMilestoneDto>? Refusal)> LoadForDecisionAsync(
        RecordAccessContext ctx, Guid milestoneId, bool isPartnerManager, CancellationToken ct)
    {
        var m = await _store.FindAsync(milestoneId, ct);
        if (m is null) return (null, null, Cp.NotFound<DealPartnerMilestoneDto>("Milestone not found"));
        var (dp, lead, refusal) = await LoadDealPartnerAsync<DealPartnerMilestoneDto>(ctx, m.DealPartnerId, ct);
        if (refusal is not null) return (null, null, refusal);
        if (!isPartnerManager && lead!.OwnerId != ctx.UserId)
            return (null, null, Cp.Forbidden<DealPartnerMilestoneDto>("Only the deal owner or a partner manager can accept an integrator's milestone.", "not_deal_owner"));
        return (m, dp, null);
    }

    /// <summary>The plan this SI was attributed on, read from its frozen version (never the live plan).</summary>
    private static PartnerPlanContentDto PlanOf(DealPartner dp) => PartnerPlanEngine.Read(dp.PlanVersion?.Content);

    /// <summary>
    /// Accepts a milestone. Under <c>we_bill_pay_si</c> it writes the cost entry in the same save (idempotent through the entry's SourceKey: a double click cannot pay twice).
    /// Needs the SI to be on a cost plan; the "legacy, no terms" plan can hold milestones but cannot turn one into money.
    /// </summary>
    public async Task<CpResult<DealPartnerMilestoneDto>> AcceptAsync(
        RecordAccessContext ctx, Guid milestoneId, MilestoneDecisionInput input, Guid actorId, bool isPartnerManager, CancellationToken ct = default)
    {
        var (m, dp, refusal) = await LoadForDecisionAsync(ctx, milestoneId, isPartnerManager, ct);
        if (refusal is not null) return refusal;
        if (m!.Status != ChannelPartnerVocab.MilestoneStatus.Planned) return Cp.Conflict<DealPartnerMilestoneDto>($"This milestone is already {m.Status}.", "not_planned");
        if (dp!.EndedAt != null) return Cp.Conflict<DealPartnerMilestoneDto>("This attribution has ended, so no further milestone can be accepted.", "already_ended");
        var plan = PlanOf(dp);
        var note = input.Note?.Trim();
        if (note is { Length: > 1000 }) return Cp.Invalid<DealPartnerMilestoneDto>("The note is at most 1000 characters.", "note_too_long");

        var now = DateTime.UtcNow;
        PartnerLedgerEntry? entry = null;
        if (plan.Direction == ChannelPartnerVocab.Direction.Cost && plan.SiBilling == ChannelPartnerVocab.SiBilling.WeBillPaySi)
        {
            var rule = PartnerPlanEngine.Effective(plan, dp.OverridePercent, dp.OverrideFlatAmount, dp.OverrideCap, dp.OverrideClawbackWindowDays, dp.OverridePaymentTermsDays);
            var position = await _store.EntryCountAsync(m.Id, ct) + 1;
            entry = new PartnerLedgerEntry
            {
                Id = Guid.NewGuid(),
                PartnerAccountId = dp.PartnerAccountId,
                LeadId = dp.LeadId,
                DealPartnerId = dp.Id,
                MilestoneId = m.Id,
                Direction = ChannelPartnerVocab.Direction.Cost,
                Kind = ChannelPartnerVocab.EntryKind.Accrual,
                Amount = m.Amount,
                Currency = await _store.OrgCurrencyAsync(ct),
                // One key per (milestone, accept): a reopened and re-accepted milestone writes a fresh entry; a double click collides on this index and writes nothing twice.
                SourceKey = $"milestone:{m.Id:N}:{position}",
                PlanVersionId = dp.PlanVersionId,
                RuleKey = dp.PlanVersion?.Plan?.Key,
                RuleScope = dp.RuleScope,
                EarnedAt = now,
                PayableOn = rule.PayableOn(now),
                PaymentTermsDays = rule.PaymentTermsDays,
                Reason = $"Milestone accepted: {m.Label}",
                CreatedById = actorId,
            };
            _store.AddEntry(entry);
        }
        else if (plan.Direction != ChannelPartnerVocab.Direction.Cost && dp.PlanVersion?.Plan?.IsSystem != true)
            return Cp.Conflict<DealPartnerMilestoneDto>("This integrator isn't on a cost plan, so accepting a milestone can't record a cost.", "not_a_cost_plan");

        m.Status = ChannelPartnerVocab.MilestoneStatus.Accepted;
        m.AcceptedAt = now;
        m.AcceptedById = actorId;
        m.Note = string.IsNullOrEmpty(note) ? null : note;
        m.LedgerEntryId = entry?.Id;
        m.UpdatedAt = now;
        try { await _store.SaveChangesAsync(ct); }
        catch (Microsoft.EntityFrameworkCore.DbUpdateException)
        {
            return Cp.Conflict<DealPartnerMilestoneDto>("This milestone was just accepted by someone else.", "already_accepted");
        }
        return Cp.Ok((await ToDtosAsync(ctx, [m], ct))[0]);
    }

    /// <summary>Rejects a PLANNED milestone (the work was not delivered). A reason is required; no money moves.</summary>
    public async Task<CpResult<DealPartnerMilestoneDto>> RejectAsync(
        RecordAccessContext ctx, Guid milestoneId, MilestoneDecisionInput input, Guid actorId, bool isPartnerManager, CancellationToken ct = default)
    {
        var (m, _, refusal) = await LoadForDecisionAsync(ctx, milestoneId, isPartnerManager, ct);
        if (refusal is not null) return refusal;
        if (m!.Status != ChannelPartnerVocab.MilestoneStatus.Planned) return Cp.Conflict<DealPartnerMilestoneDto>($"This milestone is already {m.Status}.", "not_planned");
        var note = input.Note?.Trim();
        if (string.IsNullOrEmpty(note)) return Cp.Invalid<DealPartnerMilestoneDto>("A reason is required to reject a milestone.", "reason_required");
        if (note.Length > 1000) return Cp.Invalid<DealPartnerMilestoneDto>("The reason is at most 1000 characters.", "note_too_long");

        var now = DateTime.UtcNow;
        m.Status = ChannelPartnerVocab.MilestoneStatus.Rejected;
        m.AcceptedAt = now;
        m.AcceptedById = actorId;
        m.Note = note;
        m.UpdatedAt = now;
        await _store.SaveChangesAsync(ct);
        return Cp.Ok((await ToDtosAsync(ctx, [m], ct))[0]);
    }

    /// <summary>
    /// Puts an accepted or rejected milestone back to planned. An accepted one with a cost entry gets a REVERSING cost entry in the same save (the ledger is append-only), and is
    /// refused while a payout still holds the cost (cancel that payout first; a PAID cost is corrected by a manual adjustment, not a reopen).
    /// </summary>
    public async Task<CpResult<DealPartnerMilestoneDto>> ReopenAsync(
        RecordAccessContext ctx, Guid milestoneId, MilestoneDecisionInput input, Guid actorId, bool isPartnerManager, CancellationToken ct = default)
    {
        var (m, dp, refusal) = await LoadForDecisionAsync(ctx, milestoneId, isPartnerManager, ct);
        if (refusal is not null) return refusal;
        if (m!.Status == ChannelPartnerVocab.MilestoneStatus.Planned) return Cp.Conflict<DealPartnerMilestoneDto>("This milestone is already planned.", "already_planned");
        var note = input.Note?.Trim();
        if (note is { Length: > 1000 }) return Cp.Invalid<DealPartnerMilestoneDto>("The note is at most 1000 characters.", "note_too_long");

        var now = DateTime.UtcNow;
        if (m.LedgerEntryId is Guid entryId)
        {
            var original = await _store.FindEntryAsync(entryId, ct);
            if (original is not null)
            {
                if ((await _store.HeldByPayoutAsync([entryId], ct)).Count > 0)
                    return Cp.Conflict<DealPartnerMilestoneDto>("A payout already holds this milestone's cost. Cancel that payout before reopening the milestone.", "held_by_payout");
                var position = await _store.EntryCountAsync(m.Id, ct) + 1;
                _store.AddEntry(new PartnerLedgerEntry
                {
                    Id = Guid.NewGuid(),
                    PartnerAccountId = original.PartnerAccountId,
                    LeadId = original.LeadId,
                    DealPartnerId = original.DealPartnerId,
                    MilestoneId = m.Id,
                    Direction = ChannelPartnerVocab.Direction.Cost,
                    Kind = ChannelPartnerVocab.EntryKind.Adjustment,
                    Amount = -original.Amount,
                    Currency = original.Currency,
                    ReverseOfEntryId = original.Id,
                    SourceKey = $"milestone:{m.Id:N}:{position}",
                    PlanVersionId = original.PlanVersionId,
                    RuleKey = original.RuleKey,
                    RuleScope = original.RuleScope,
                    EarnedAt = now,
                    PayableOn = now,
                    PaymentTermsDays = original.PaymentTermsDays,
                    Reason = $"Milestone reopened: {m.Label}" + (string.IsNullOrEmpty(note) ? "" : $" - {note}"),
                    CreatedById = actorId,
                });
            }
        }
        _ = dp;
        m.Status = ChannelPartnerVocab.MilestoneStatus.Planned;
        m.AcceptedAt = null;
        m.AcceptedById = null;
        m.LedgerEntryId = null;
        m.Note = string.IsNullOrEmpty(note) ? null : note;
        m.UpdatedAt = now;
        try { await _store.SaveChangesAsync(ct); }
        catch (Microsoft.EntityFrameworkCore.DbUpdateException)
        {
            return Cp.Conflict<DealPartnerMilestoneDto>("This milestone was just changed by someone else. Reload and try again.", "changed_elsewhere");
        }
        return Cp.Ok((await ToDtosAsync(ctx, [m], ct))[0]);
    }
}

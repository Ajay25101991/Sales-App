using System.Text.RegularExpressions;
using SalesApi.Dtos;
using SalesApi.ProcessLayer.Accounts;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// The bulk partner upload (to-do/partner-management-design.md section 11, owner decisions 2026-10-20): the PARTNERS file and the CLIENT sheet, each previewed then committed.
///
/// REUSE, not parallel. The flow is the lead import's (<c>LeadImportProcess</c>): the CSV and a field -> header mapping travel with both calls, preview and commit are ONE code path
/// (the preview is the commit minus the writes, so it can never describe something else), rows are numbered from the header (first data row = 2), a bad row is SKIPPED and listed
/// and a commit with no good row is refused. Like the lead import - and unlike the usage import - nothing is stored between the two calls: the commit repeats the file, so it acts on the
/// CRM as it is now. That is also what makes a re-run idempotent: every step below first asks "is this already so?".
/// Every write goes through the existing path that owns its rules, audit and aggregates - this class creates NOTHING itself:
///   account            <see cref="AccountProcess.CreateAsync"/> (duplicate-name rule, tracked save, account.created event); matched with the bulk matcher
///                      <see cref="AccountProcess.MatchBulkAsync"/> (<see cref="AccountLinkService.CompanyKey"/>, the one definition of "the same company name")
///   owner              <see cref="AccountProcess.AssignAsync"/> (manager-only, team check, activity, event)
///   contact            <see cref="AccountProcess.AddContactAsync"/>
///   partner profile    <see cref="ChannelPartnerProcess.CreateAsync"/> / <see cref="ChannelPartnerProcess.UpdateAsync"/>
///   partner_of edge    <see cref="AccountProcess.AddRelationshipAsync"/> (a present edge answers duplicate_relationship, which counts as "already there")
///   deal partner       <see cref="ChannelPartnerProcess.AttributeAsync"/> with <c>noTerms</c> (the "legacy, no terms" plan: records the attribution, earns nothing)
/// New here: the CSV reading of the two shapes, the POC split, the channel-name suggestion (<see cref="PartnerNameMatch"/>) and the deal choice - none of which exists elsewhere.
///
/// Authorization is the controller's (partners.manage); the caller's facts arrive as data (<see cref="RecordAccessContext"/>, <see cref="PartnerImportActor"/>).
/// </summary>
public sealed class PartnerBulkImportProcess
{
    private readonly PartnerBulkStore _store;
    private readonly AccountProcess _accounts;
    private readonly ChannelPartnerProcess _partners;
    private readonly OrgSettingsReader _settings;

    public PartnerBulkImportProcess(PartnerBulkStore store, AccountProcess accounts, ChannelPartnerProcess partners, OrgSettingsReader settings)
    {
        _store = store;
        _accounts = accounts;
        _partners = partners;
        _settings = settings;
    }

    private const int MaxName = 200;
    private static readonly Regex PocSeparator = new(@"[,;\r\n]+", RegexOptions.Compiled | RegexOptions.CultureInvariant);

    // Header names tried when the caller sends no mapping (the owner's own file headers first).
    private static readonly Dictionary<string, string[]> PartnerFileHeaders = new()
    {
        [PartnerBulkVocab.PartnerFileField.Partner] = ["partner", "partner name", "company", "company name", "name"],
        [PartnerBulkVocab.PartnerFileField.Pocs] = ["poc(s)", "pocs", "poc", "point of contact", "points of contact", "contacts", "contact"],
        [PartnerBulkVocab.PartnerFileField.AssignedManager] = ["assigned manager", "manager", "account manager", "owner"],
    };

    private static readonly Dictionary<string, string[]> ClientSheetHeaders = new()
    {
        [PartnerBulkVocab.ClientSheetField.Channel] = ["lead channel", "channel", "partner"],
        [PartnerBulkVocab.ClientSheetField.Client] = ["client / company name", "client name", "client", "company name", "company", "customer name", "customer", "account name", "account"],
        [PartnerBulkVocab.ClientSheetField.DealId] = ["deal id", "deal", "lead id"],
        [PartnerBulkVocab.ClientSheetField.Owner] = ["owner", "lead owner", "assigned to", "assigned manager", "managed by"],
    };

    // ---- reading the file ---------------------------------------------------------------------------------

    private sealed class Sheet
    {
        public List<string> Headers { get; init; } = [];
        public List<string> Normalised { get; init; } = [];
        public List<(int Row, List<string> Cells)> Rows { get; init; } = [];
    }

    private static string NormHeader(string h) => Regex.Replace(h.Replace('_', ' ').Replace('-', ' ').Trim().ToLowerInvariant(), @"\s+", " ");

    private static string NormText(string? s) => Regex.Replace((s ?? "").Trim().ToLowerInvariant(), @"\s+", " ");

    private static (Sheet? Sheet, string? Problem) Read(string? csv)
    {
        if (string.IsNullOrWhiteSpace(csv)) return (null, "Choose a CSV file.");
        var table = CsvUtil.Parse(csv).Where(r => r.Any(c => c.Trim() != "")).ToList();
        if (table.Count < 2) return (null, "The file has no rows below the header.");
        if (table.Count - 1 > PartnerBulkVocab.MaxRows) return (null, $"A file can hold at most {PartnerBulkVocab.MaxRows:N0} rows. Split it.");
        var headers = table[0].Select(h => h.Trim()).ToList();
        return (new Sheet
        {
            Headers = headers,
            Normalised = headers.Select(NormHeader).ToList(),
            Rows = table.Skip(1).Select((r, i) => (i + 2, r)).ToList(),   // row 1 is the header, as in the lead import
        }, null);
    }

    /// <summary>The column a field is read from: the mapping's header when the caller named one, else the first default name present. -1 = none.</summary>
    private static int Column(Sheet sheet, Dictionary<string, string>? mapping, string field, string[] defaults, Dictionary<string, string?> used)
    {
        var index = -1;
        if (mapping is not null && mapping.TryGetValue(field, out var named) && !string.IsNullOrWhiteSpace(named))
            index = sheet.Normalised.IndexOf(NormHeader(named));
        else
            foreach (var d in defaults)
            {
                index = sheet.Normalised.IndexOf(d);
                if (index >= 0) break;
            }
        used[field] = index >= 0 ? sheet.Headers[index] : null;
        return index;
    }

    private static string Cell(List<string> cells, int index) => index >= 0 && index < cells.Count ? cells[index].Trim() : "";

    private static CpResult<T> BadFile<T>(string problem) => Cp.Invalid<T>(problem, "bad_file");

    private static AccountProcess.AccountActor AccountActorOf(PartnerImportActor a) =>
        new(a.UserId, a.OrgId, a.Name, a.IsManager, a.Visibility, a.CanCreateTags, a.Role);

    private static string Describe(AccountProcess.Refusal r) => r.Reason;

    private static void Issue(List<BulkRowIssueDto> list, int row, string reason)
    {
        if (list.Count < PartnerBulkVocab.MaxMessages) list.Add(new BulkRowIssueDto(row, reason));
    }

    /// <summary>The accounts matching these names by company key (the bulk matcher, in the chunks it accepts), by lower-cased typed name.</summary>
    private async Task<Dictionary<string, MatchedAccountDto>> MatchAccountsAsync(RecordAccessContext ctx, IEnumerable<string> names, CancellationToken ct)
    {
        var result = new Dictionary<string, MatchedAccountDto>(StringComparer.Ordinal);
        foreach (var chunk in names.Where(n => n.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).Chunk(2000))
        {
            var matched = await _accounts.MatchBulkAsync(ctx, [.. chunk], ct);
            foreach (var m in matched.Matched) result.TryAdd(NormText(m.Company), m);
        }
        return result;
    }

    // =============================================================================================================
    // The partners file
    // =============================================================================================================

    private sealed class PartnerRowPlan
    {
        public int Row { get; init; }
        public string PartnerName { get; init; } = "";
        public Guid? AccountId { get; set; }
        public string? AccountName { get; set; }
        public Guid? AccountOwnerId { get; set; }
        public bool WillCreateAccount { get; set; }
        public PartnerBulkStore.ProfileFacts? Profile { get; set; }
        public List<PartnerPocDto> Pocs { get; } = [];
        public List<Guid> InternalIds { get; } = [];
        public List<string> ContactNames { get; } = [];
        public PartnerManagerDto? Manager { get; set; }
    }

    public async Task<CpResult<PartnerFileResultDto>> PartnersAsync(
        RecordAccessContext ctx, PartnerImportActor actor, PartnerFileInput input, bool commit, CancellationToken ct = default)
    {
        var (sheet, problem) = Read(input.Csv);
        if (sheet is null) return BadFile<PartnerFileResultDto>(problem!);
        var used = new Dictionary<string, string?>();
        var partnerCol = Column(sheet, input.Mapping, PartnerBulkVocab.PartnerFileField.Partner, PartnerFileHeaders[PartnerBulkVocab.PartnerFileField.Partner], used);
        var pocCol = Column(sheet, input.Mapping, PartnerBulkVocab.PartnerFileField.Pocs, PartnerFileHeaders[PartnerBulkVocab.PartnerFileField.Pocs], used);
        var managerCol = Column(sheet, input.Mapping, PartnerBulkVocab.PartnerFileField.AssignedManager, PartnerFileHeaders[PartnerBulkVocab.PartnerFileField.AssignedManager], used);
        if (partnerCol < 0) return Cp.Invalid<PartnerFileResultDto>("The file needs a Partner column (map it to one of the file's headers).", "missing_column");

        var staff = await _store.StaffAsync(ct);
        var staffByEmail = staff.Where(s => s.Email.Length > 0).GroupBy(s => NormText(s.Email)).ToDictionary(g => g.Key, g => g.First());
        var staffByName = staff.Where(s => !string.IsNullOrWhiteSpace(s.FullName)).GroupBy(s => NormText(s.FullName)).ToDictionary(g => g.Key, g => g.ToList());
        var staffById = staff.ToDictionary(s => s.Id);

        // Matches a typed name or email to ONE CRM user: Exactly one -> the user; none -> null with matches 0; several -> null with matches > 1.
        (PartnerBulkStore.Staff? User, int Matches) FindUser(string text)
        {
            var key = NormText(text);
            if (key.Length == 0) return (null, 0);
            if (staffByEmail.TryGetValue(key, out var byMail)) return (byMail, 1);
            if (staffByName.TryGetValue(key, out var byName)) return byName.Count == 1 ? (byName[0], 1) : (null, byName.Count);
            return (null, 0);
        }

        var errors = new List<BulkRowIssueDto>();
        var warnings = new List<BulkRowIssueDto>();
        var edits = (input.RowEdits ?? []).GroupBy(e => e.Row).ToDictionary(g => g.Key, g => g.Last());

        // 1. Read every row; match the partner names to accounts in one go.
        var typed = sheet.Rows.Select(r => (r.Row, Name: Regex.Replace(Cell(r.Cells, partnerCol), @"\s+", " "), Cells: r.Cells)).ToList();
        var matches = await MatchAccountsAsync(ctx, typed.Select(t => t.Name), ct);
        var matchedIds = matches.Values.Select(m => m.AccountId).Distinct().ToList();
        var profiles = await _store.ProfileFactsAsync(matchedIds, ct);
        var accountFacts = await _store.AccountsAsync(matchedIds, ct);
        var contactNamesByAccount = new Dictionary<Guid, HashSet<string>>();
        foreach (var id in matchedIds)
        {
            var existing = await _accounts.ContactsAsync(ctx, id, actor.Role, ct);
            contactNamesByAccount[id] = existing.Contacts?.Select(c => NormText(c.Name)).ToHashSet() ?? [];
        }

        var plans = new List<PartnerRowPlan>();
        var seenKeys = new Dictionary<string, int>(StringComparer.Ordinal);
        foreach (var (row, name, cells) in typed)
        {
            if (edits.TryGetValue(row, out var edit0) && edit0.Skip) { Issue(warnings, row, "Skipped on the preview."); continue; }
            if (name.Length == 0) { Issue(errors, row, "The partner name is blank."); continue; }
            if (name.Length > MaxName) { Issue(errors, row, $"The partner name is over {MaxName} characters."); continue; }
            var key = AccountLinkService.CompanyKey(name);
            if (key.Length == 0) { Issue(errors, row, $"\"{name}\" has no letters or digits to name a company by."); continue; }
            if (seenKeys.TryGetValue(key, out var first)) { Issue(errors, row, $"This partner is already on row {first}."); continue; }
            seenKeys[key] = row;

            var plan = new PartnerRowPlan { Row = row, PartnerName = name };
            if (matches.TryGetValue(NormText(name), out var match))
            {
                plan.AccountId = match.AccountId;
                plan.AccountName = match.AccountName;
                plan.Profile = profiles.GetValueOrDefault(match.AccountId);
                plan.AccountOwnerId = accountFacts.GetValueOrDefault(match.AccountId)?.OwnerId;
            }
            else plan.WillCreateAccount = true;

            // POC(s): a name that is a CRM user is "our contact"; every other name is a contact on the partner's account.
            var existingContacts = plan.AccountId is Guid aid ? contactNamesByAccount.GetValueOrDefault(aid) ?? new HashSet<string>() : new HashSet<string>();
            var ourAlready = plan.Profile is null ? new HashSet<Guid>() : ChannelPartnerProcess.ReadInternalContactIds(plan.Profile.InternalContactIds).ToHashSet();
            edits.TryGetValue(row, out var edit);
            if (edit is not null && (edit.InternalContactIds is not null || edit.ContactNames is not null))
            {
                foreach (var uid in edit.InternalContactIds ?? [])
                {
                    if (!staffById.TryGetValue(uid, out var u)) { Issue(warnings, row, "A corrected contact is not an active CRM user and was ignored."); continue; }
                    plan.InternalIds.Add(uid);
                    plan.Pocs.Add(new PartnerPocDto(u.FullName ?? u.Email, PartnerBulkVocab.PocKind.Internal, u.Id, u.FullName, false, ourAlready.Contains(u.Id)));
                }
                foreach (var contact in (edit.ContactNames ?? []).Select(c => Regex.Replace(c.Trim(), @"\s+", " ")).Where(c => c.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase))
                {
                    plan.ContactNames.Add(contact);
                    plan.Pocs.Add(new PartnerPocDto(contact, PartnerBulkVocab.PocKind.Contact, null, null, existingContacts.Contains(NormText(contact)), false));
                }
            }
            else if (pocCol >= 0)
            {
                foreach (var token in PocSeparator.Split(Cell(cells, pocCol)).Select(t => Regex.Replace(t.Trim(), @"\s+", " ")).Where(t => t.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase))
                {
                    var (user, count) = FindUser(token);
                    if (user is not null)
                    {
                        if (plan.InternalIds.Contains(user.Id)) continue;
                        plan.InternalIds.Add(user.Id);
                        plan.Pocs.Add(new PartnerPocDto(token, PartnerBulkVocab.PocKind.Internal, user.Id, user.FullName, false, ourAlready.Contains(user.Id)));
                    }
                    else if (count > 1)
                    {
                        plan.Pocs.Add(new PartnerPocDto(token, PartnerBulkVocab.PocKind.Ambiguous, null, null, false, false));
                        Issue(warnings, row, $"\"{token}\" matches more than one CRM user, so nothing was imported for it. Correct the split on the preview.");
                    }
                    else
                    {
                        plan.ContactNames.Add(token);
                        plan.Pocs.Add(new PartnerPocDto(token, PartnerBulkVocab.PocKind.Contact, null, null, existingContacts.Contains(NormText(token)), false));
                    }
                }
            }

            // Assigned Manager = the account's owner. Blank = no change; unmatched or ambiguous = listed, owner unchanged.
            string managerText = Cell(cells, managerCol);
            if (edit?.AssignedManagerId is Guid managerId)
            {
                if (staffById.TryGetValue(managerId, out var m)) plan.Manager = new PartnerManagerDto(m.FullName ?? m.Email, m.Id, m.FullName, plan.AccountOwnerId == m.Id);
                else Issue(warnings, row, "The corrected assigned manager is not an active CRM user; the owner is unchanged.");
            }
            else if (managerText.Length > 0)
            {
                var (user, count) = FindUser(managerText);
                if (user is not null) plan.Manager = new PartnerManagerDto(managerText, user.Id, user.FullName, plan.AccountOwnerId == user.Id);
                else
                {
                    plan.Manager = new PartnerManagerDto(managerText, null, null, false);
                    Issue(warnings, row, count > 1
                        ? $"The assigned manager \"{managerText}\" matches more than one CRM user; the owner is unchanged."
                        : $"No CRM user is called \"{managerText}\"; the owner is unchanged.");
                }
            }
            plans.Add(plan);
        }

        var rows = plans.Select(p => new PartnerFileRowDto(
            p.Row, p.PartnerName, p.AccountId, p.AccountName, p.WillCreateAccount, p.Profile is not null, p.Profile is null, p.Pocs, p.Manager)).ToList();
        PartnerFileResultDto Result(PartnerFileCommitDto? done) => new(
            done is not null, sheet.Headers, used, sheet.Rows.Count, plans.Count, plans.Count(p => p.WillCreateAccount), plans.Count(p => p.Profile is not null),
            errors.Count, rows, errors, warnings, done);

        if (!commit) return Cp.Ok(Result(null));
        if (plans.Count == 0) return Cp.Invalid<PartnerFileResultDto>("This file has no rows to import.", "no_rows");

        // 2. Commit, row by row: each step first asks whether it is already so (a re-run changes nothing).
        var cp = await _settings.GetChannelPartnerSettingsAsync();
        var outcomes = new List<PartnerFileRowOutcomeDto>();
        int accountsCreated = 0, profilesCreated = 0, internalAdded = 0, contactsCreated = 0, ownersChanged = 0, unchanged = 0, failed = 0;
        foreach (var plan in plans)
        {
            var changed = false;
            var created = false;
            string? failure = null;
            var accountId = plan.AccountId;
            try
            {
                if (accountId is null)
                {
                    var owner = plan.Manager?.UserId ?? actor.UserId;
                    var made = await _accounts.CreateAsync(owner, actor.OrgId, new AccountInput(plan.PartnerName, null, null, null, null, null, null, null, null, null),
                        actor.Role, canCreateTags: actor.CanCreateTags, sensitive: actor.Sensitive, ct: ct);
                    if (made.Refusal is not null) { failure = Describe(made.Refusal); }
                    else { accountId = made.Account!.Id; accountsCreated++; created = true; changed = true; }
                }
                else if (plan.Manager?.UserId is Guid managerId && plan.AccountOwnerId != managerId)
                {
                    var assigned = await _accounts.AssignAsync(ctx, AccountActorOf(actor), accountId.Value, new AccountAssignInput(managerId), ct: ct);
                    if (assigned.Refusal is not null) Issue(warnings, plan.Row, $"The owner of \"{plan.PartnerName}\" was not changed: {Describe(assigned.Refusal)}");
                    else { ownersChanged++; changed = true; }
                }

                if (failure is null && accountId is Guid id)
                {
                    var profile = plan.Profile;
                    var current = profile is null ? new List<Guid>() : ChannelPartnerProcess.ReadInternalContactIds(profile.InternalContactIds);
                    var wanted = current.Concat(plan.InternalIds).Distinct().ToList();
                    if (profile is null)
                    {
                        var made = await _partners.CreateAsync(ctx, id, ProfileInput(ChannelPartnerVocab.ToBeSetType, cp.PayoutsNeedSignedAgreementDefault, wanted), actor.UserId, ct);
                        if (!made.IsOk) failure = made.Error;
                        else { profilesCreated++; internalAdded += wanted.Count; created = true; changed = true; }
                    }
                    else if (wanted.Count != current.Count)
                    {
                        var saved = await _partners.UpdateAsync(ctx, id, ProfileInput(null, null, wanted), ct);
                        if (!saved.IsOk) failure = saved.Error;
                        else { internalAdded += wanted.Count - current.Count; changed = true; }
                    }

                    // Contacts on the partner's account: deduped by name (an existing contact, or an earlier one in this same row, is not added again).
                    if (failure is null)
                    {
                        var have = plan.AccountId is Guid known ? contactNamesByAccount.GetValueOrDefault(known) ?? new HashSet<string>() : new HashSet<string>();
                        foreach (var name in plan.ContactNames)
                        {
                            if (!have.Add(NormText(name))) continue;
                            var added = await _accounts.AddContactAsync(ctx, id, new ContactInput(name, null, null, null, null), actor.Role, ct);
                            if (added.Refusal is not null) Issue(warnings, plan.Row, $"The contact \"{name}\" was not added: {Describe(added.Refusal)}");
                            else { contactsCreated++; changed = true; }
                        }
                    }
                }
            }
            catch (Exception e) when (e is Microsoft.EntityFrameworkCore.DbUpdateException or InvalidOperationException)
            {
                failure = "The row could not be saved: " + e.Message;
            }

            if (failure is not null) { failed++; outcomes.Add(new PartnerFileRowOutcomeDto(plan.Row, plan.PartnerName, accountId, PartnerBulkVocab.Outcome.Failed, failure)); Issue(errors, plan.Row, failure); }
            else if (created) outcomes.Add(new PartnerFileRowOutcomeDto(plan.Row, plan.PartnerName, accountId, PartnerBulkVocab.Outcome.Created));
            else if (changed) outcomes.Add(new PartnerFileRowOutcomeDto(plan.Row, plan.PartnerName, accountId, PartnerBulkVocab.Outcome.Updated));
            else { unchanged++; outcomes.Add(new PartnerFileRowOutcomeDto(plan.Row, plan.PartnerName, accountId, PartnerBulkVocab.Outcome.Unchanged)); }
        }
        return Cp.Ok(Result(new PartnerFileCommitDto(accountsCreated, profilesCreated, internalAdded, contactsCreated, ownersChanged, unchanged, failed, outcomes)));
    }

    /// <summary>A profile input that sets only what it names (everything else null = leave). On create the signed-agreement choice is the ORG DEFAULT, never asked row by row.</summary>
    private static PartnerProfileInput ProfileInput(string? type, bool? payoutsNeedSignedAgreement, List<Guid> internalContacts) => new(
        Type: type, Status: null, Tier: null, DefaultPlanId: null, ClearDefaultPlan: false,
        AgreementEngagementLetterId: null, AgreementAttachmentId: null, ClearAgreement: false,
        PayoutsNeedSignedAgreement: payoutsNeedSignedAgreement, RepCredit: null, ClearRepCredit: false,
        VatRegistered: null, Trn: null, Territory: null, ExclusivityNote: null, OnboardedAt: null, TerminatedAt: null,
        PayoutAccountHolder: null, PayoutBankName: null, PayoutIban: null, InternalContactIds: internalContacts);

    // =============================================================================================================
    // The client sheet
    // =============================================================================================================

    private sealed class ClientRowPlan
    {
        public int Row { get; init; }
        public string Client { get; init; } = "";
        public string Channel { get; init; } = "";
        public Guid? PartnerAccountId { get; set; }
        public string? PartnerName { get; set; }
        public Guid? AccountId { get; set; }
        public string? AccountName { get; set; }
        public bool RelationshipExists { get; set; }
        public Guid? Primary { get; set; }
        public bool Ambiguous { get; set; }
        public List<PartnerBulkStore.Deal> Deals { get; set; } = [];
        public List<Guid> Ticked { get; } = [];
    }

    public async Task<CpResult<ClientSheetResultDto>> ClientsAsync(
        RecordAccessContext ctx, PartnerImportActor actor, ClientSheetInput input, bool commit, CancellationToken ct = default)
    {
        var (sheet, problem) = Read(input.Csv);
        if (sheet is null) return BadFile<ClientSheetResultDto>(problem!);
        var used = new Dictionary<string, string?>();
        var channelCol = Column(sheet, input.Mapping, PartnerBulkVocab.ClientSheetField.Channel, ClientSheetHeaders[PartnerBulkVocab.ClientSheetField.Channel], used);
        var clientCol = Column(sheet, input.Mapping, PartnerBulkVocab.ClientSheetField.Client, ClientSheetHeaders[PartnerBulkVocab.ClientSheetField.Client], used);
        var dealCol = Column(sheet, input.Mapping, PartnerBulkVocab.ClientSheetField.DealId, ClientSheetHeaders[PartnerBulkVocab.ClientSheetField.DealId], used);
        var ownerCol = Column(sheet, input.Mapping, PartnerBulkVocab.ClientSheetField.Owner, ClientSheetHeaders[PartnerBulkVocab.ClientSheetField.Owner], used);
        if (channelCol < 0) return Cp.Invalid<ClientSheetResultDto>("The sheet needs a Lead Channel column (map it to one of the file's headers).", "missing_column");
        if (clientCol < 0 && dealCol < 0) return Cp.Invalid<ClientSheetResultDto>("The sheet needs a client (company) name column or a deal id column.", "missing_column");

        var errors = new List<BulkRowIssueDto>();
        var excluded = new List<ClientRowExcludedDto>();
        var partnerAccounts = await _store.PartnerAccountsAsync(ct);
        var partnerById = partnerAccounts.ToDictionary(p => p.AccountId);

        // The owner's confirmed channel map (value -> partner account | null), keyed the way a value is compared: trimmed, case-insensitive.
        var channelMap = new Dictionary<string, Guid?>(StringComparer.Ordinal);
        foreach (var (value, partner) in input.ChannelMap ?? []) channelMap[NormText(value)] = partner;
        if (commit)
        {
            var unknown = channelMap.Where(kv => kv.Value is Guid g && !partnerById.ContainsKey(g)).Select(kv => kv.Key).ToList();
            if (unknown.Count > 0)
                return Cp.Invalid<ClientSheetResultDto>($"These channel values are mapped to an account that is not a channel partner: {string.Join(", ", unknown)}.", "bad_channel_map");
        }

        // 1. Read the rows; set aside what is not partner business.
        var channels = new Dictionary<string, (string Display, int Count)>(StringComparer.Ordinal);
        var rows = new List<(int Row, string Client, string Channel, string DealText)>();
        var managedChannel = 0;
        foreach (var (row, cells) in sheet.Rows)
        {
            var channel = Regex.Replace(Cell(cells, channelCol), @"\s+", " ");
            var client = Regex.Replace(Cell(cells, clientCol), @"\s+", " ");
            var dealText = Cell(cells, dealCol);
            var owner = Cell(cells, ownerCol);
            var label = client.Length > 0 ? client : dealText;
            if (NormText(owner) == PartnerBulkVocab.ManagedByPartner || NormText(channel) == PartnerBulkVocab.ManagedByPartner)
            {
                if (NormText(channel) == PartnerBulkVocab.ManagedByPartner) managedChannel++;
                excluded.Add(new ClientRowExcludedDto(row, label, "Managed by Partner: the client manages itself, so this is not partner business and is not linked."));
                continue;
            }
            if (client.Length == 0 && dealText.Length == 0) { Issue(errors, row, "The client is blank."); continue; }
            if (channel.Length == 0) { excluded.Add(new ClientRowExcludedDto(row, label, "No Lead Channel, so no partner to link.")); continue; }
            var ck = NormText(channel);
            channels[ck] = channels.TryGetValue(ck, out var seen) ? (seen.Display, seen.Count + 1) : (channel, 1);
            rows.Add((row, client, channel, dealText));
        }

        // 2. The distinct channel values, each with the closest partner by name ("not a partner" below the threshold).
        var channelDtos = channels.OrderByDescending(c => c.Value.Count).ThenBy(c => c.Value.Display, StringComparer.OrdinalIgnoreCase).Select(c =>
        {
            var scored = partnerAccounts.Select(p => (p, Score: PartnerNameMatch.Score(c.Value.Display, p.Name))).Where(s => s.Score > 0d)
                .OrderByDescending(s => s.Score).ThenBy(s => s.p.Name, StringComparer.OrdinalIgnoreCase).Take(3).ToList();
            var top = scored.FirstOrDefault();
            var suggest = top.p is not null && top.Score >= PartnerBulkVocab.SuggestThreshold ? top : default;
            var mapped = channelMap.TryGetValue(c.Key, out var mappedTo);
            return new ClientChannelDto(
                c.Value.Display, c.Value.Count, false, suggest.p?.AccountId, suggest.p?.Name, suggest.p is null ? null : suggest.Score,
                scored.Select(s => new ClientChannelCandidateDto(s.p.AccountId, s.p.Name, s.Score)).ToList(), mapped, mappedTo);
        }).ToList();
        // "Managed by Partner" as a Lead Channel value is listed too, flagged: it is never mapped (the client manages itself).
        if (managedChannel > 0)
            channelDtos.Add(new ClientChannelDto("Managed by Partner", managedChannel, true, null, null, null, [], false, null));

        // 3. Each row -> its CRM account (a deal id names it; otherwise the company key) -> that account's deals.
        var dealIds = rows.Select(r => Guid.TryParse(r.DealText, out var g) ? g : (Guid?)null).Where(g => g is not null).Select(g => g!.Value).Distinct().ToList();
        var givenDeals = (await _store.DealsByIdsAsync(dealIds, ct)).ToDictionary(d => d.Id);
        var byName = await MatchAccountsAsync(ctx, rows.Where(r => r.DealText.Length == 0 || !Guid.TryParse(r.DealText, out _)).Select(r => r.Client), ct);
        var accountIds = byName.Values.Select(m => m.AccountId).Concat(givenDeals.Values.Where(d => d.AccountId != null).Select(d => d.AccountId!.Value)).Distinct().ToList();
        var accountFacts = await _store.AccountsAsync(accountIds, ct);
        var dealsByAccount = (await _store.DealsOfAccountsAsync(accountIds, ct)).GroupBy(d => d.AccountId!.Value).ToDictionary(g => g.Key, g => g.ToList());
        var partnerIds = channelMap.Values.Where(v => v is not null).Select(v => v!.Value).Distinct().ToList();
        var edges = await _store.RelationshipsAsync(partnerIds, accountIds, "partner_of", ct);
        var profileFacts = await _store.ProfileFactsAsync(partnerIds, ct);
        var excludedDeals = (input.ExcludedDealIds ?? []).ToHashSet();

        var plans = new List<ClientRowPlan>();
        var clientOwner = new Dictionary<Guid, (int Row, Guid Partner)>();
        foreach (var (row, client, channel, dealText) in rows)
        {
            var ck = NormText(channel);
            Guid? partnerId = null;
            if (channelMap.TryGetValue(ck, out var mappedPartner))
            {
                if (mappedPartner is null) { excluded.Add(new ClientRowExcludedDto(row, client.Length > 0 ? client : dealText, $"The channel \"{channel}\" is not a partner.")); continue; }
                partnerId = mappedPartner;
            }
            else if (commit) { excluded.Add(new ClientRowExcludedDto(row, client.Length > 0 ? client : dealText, $"The channel \"{channel}\" has not been mapped to a partner.")); continue; }

            var plan = new ClientRowPlan { Row = row, Client = client.Length > 0 ? client : dealText, Channel = channel };
            if (partnerId is Guid pid)
            {
                plan.PartnerAccountId = pid;
                plan.PartnerName = partnerById.GetValueOrDefault(pid)?.Name;
            }

            // The client's account.
            PartnerBulkStore.Deal? given = null;
            if (Guid.TryParse(dealText, out var givenId))
            {
                if (!givenDeals.TryGetValue(givenId, out given)) { Issue(errors, row, $"No deal with the id \"{dealText}\"."); continue; }
                if (given.AccountId is not Guid dealAccount) { Issue(errors, row, "That deal is not linked to a client account."); continue; }
                plan.AccountId = dealAccount;
            }
            else if (byName.TryGetValue(NormText(client), out var account)) plan.AccountId = account.AccountId;
            else { Issue(errors, row, $"No CRM account is called \"{client}\"."); continue; }
            plan.AccountName = accountFacts.GetValueOrDefault(plan.AccountId.Value)?.Name;

            // Its deals (the ones the caller may see): open and won can take a partner, lost are listed for information.
            var deals = (dealsByAccount.GetValueOrDefault(plan.AccountId.Value) ?? [])
                .Where(d => RecordAccess.CanView(ctx, d.OwnerId, d.TeamId)).OrderByDescending(d => d.CreatedAt).ToList();
            plan.Deals = deals;
            var eligible = deals.Where(d => d.Phase != "lost").ToList();
            if (eligible.Count == 0) { Issue(errors, row, "The client has no open or won deal to link the partner to."); continue; }

            // Which deal is the row about: the deal id, else a pick, else the only one, else the one the September import marked (its lead source), else the one whose NAME is the client (a lead's Company is the client on every deal, so only the name tells them apart).
            if (given is not null) plan.Primary = given.Id;
            else if (input.DealPick is not null && input.DealPick.TryGetValue(row, out var picked) && eligible.Any(d => d.Id == picked)) plan.Primary = picked;
            else if (eligible.Count == 1) plan.Primary = eligible[0].Id;
            else
            {
                var preferred = string.IsNullOrWhiteSpace(input.PreferredSource) ? []
                    : eligible.Where(d => string.Equals(d.Source?.Trim(), input.PreferredSource.Trim(), StringComparison.OrdinalIgnoreCase)).ToList();
                var clientKey = AccountLinkService.CompanyKey(client);
                var named = eligible.Where(d => AccountLinkService.CompanyKey(d.Name) == clientKey).ToList();
                var bySheetChannel = eligible.Where(d => !string.IsNullOrWhiteSpace(d.Source) && NormText(d.Source) == NormText(channel)).ToList();   // the September import set each lead's source = the row's Lead Channel
                if (preferred.Count == 1) plan.Primary = preferred[0].Id;
                else if (bySheetChannel.Count == 1) plan.Primary = bySheetChannel[0].Id;
                else if (named.Count == 1) plan.Primary = named[0].Id;
                else plan.Ambiguous = true;
            }
            if (plan.Ambiguous && commit) { Issue(errors, row, $"{eligible.Count} deals match \"{client}\" and the file does not say which: pick one and commit again."); continue; }

            foreach (var d in eligible) if (!excludedDeals.Contains(d.Id)) plan.Ticked.Add(d.Id);
            if (partnerId is Guid p && edges.Contains((p, plan.AccountId.Value))) plan.RelationshipExists = true;

            if (partnerId is Guid owner)
            {
                var status = profileFacts.GetValueOrDefault(owner)?.Status;
                if (status is not null && !ChannelPartnerVocab.Status.CanAttribute(status)) { Issue(errors, row, $"\"{plan.PartnerName}\" is {status}, so it can't be linked to new deals."); continue; }
                if (clientOwner.TryGetValue(plan.AccountId.Value, out var earlier))
                {
                    Issue(errors, row, earlier.Partner == owner
                        ? $"This client is already on row {earlier.Row}."
                        : $"This client is already on row {earlier.Row} with a different partner.");
                    continue;
                }
                clientOwner[plan.AccountId.Value] = (row, owner);
            }
            plans.Add(plan);
        }

        var referrerLeads = new Dictionary<Guid, HashSet<Guid>>();
        foreach (var partner in plans.Where(p => p.PartnerAccountId is not null).Select(p => p.PartnerAccountId!.Value).Distinct())
            referrerLeads[partner] = await _store.DealsWithPartnerAsync(partner, ChannelPartnerVocab.Role.Referrer,
                plans.Where(p => p.PartnerAccountId == partner).SelectMany(p => p.Deals.Select(d => d.Id)).ToList(), ct);

        var rowDtos = plans.Select(p => new ClientRowDto(
            p.Row, p.Client, p.Channel, p.PartnerAccountId, p.PartnerName, p.AccountId, p.AccountName, p.RelationshipExists, p.Primary, p.Ambiguous,
            p.Deals.Select(d => new ClientDealDto(
                d.Id, d.Name, d.Phase, d.CreatedAt, d.Source, d.OwnerName, p.Ticked.Contains(d.Id), p.Primary == d.Id,
                p.PartnerAccountId is Guid pa && referrerLeads.GetValueOrDefault(pa)?.Contains(d.Id) == true)).ToList())).ToList();
        var ready = plans.Count(p => p.PartnerAccountId is not null && !p.Ambiguous);
        ClientSheetResultDto Result(ClientSheetCommitDto? done) => new(
            done is not null, sheet.Headers, used, sheet.Rows.Count, ready, excluded.Count, errors.Count, plans.Count(p => p.Ambiguous),
            channelDtos, rowDtos, excluded, errors, done);

        if (!commit) return Cp.Ok(Result(null));
        var toDo = plans.Where(p => p.PartnerAccountId is not null).ToList();
        if (toDo.Count == 0) return Cp.Invalid<ClientSheetResultDto>("This sheet has no rows to link.", "no_rows");

        // 4. Commit: the partner_of edge, then a no-terms referrer on every ticked deal. Each step first asks whether it is already so.
        var outcomes = new List<ClientRowOutcomeDto>();
        int edgesMade = 0, edgesThere = 0, attributed = 0, there = 0, failedRows = 0;
        foreach (var plan in toDo)
        {
            var partnerId = plan.PartnerAccountId!.Value;
            var problems = new List<BulkRowIssueDto>();
            var edgeMade = false;
            if (plan.RelationshipExists) edgesThere++;
            else
            {
                var (refusal, _) = await _accounts.AddRelationshipAsync(ctx, partnerId, new AccountRelationshipInput(plan.AccountId, "partner_of"), actor.UserId, ct);
                if (refusal is null) { edgesMade++; edgeMade = true; }
                else if (refusal.Code == "duplicate_relationship") edgesThere++;
                else Issue(problems, plan.Row, $"The partner link was not added: {Describe(refusal)}");
            }

            int rowAttributed = 0, rowThere = 0;
            foreach (var leadId in plan.Ticked)
            {
                if (referrerLeads.GetValueOrDefault(partnerId)?.Contains(leadId) == true) { rowThere++; continue; }
                var made = await _partners.AttributeAsync(ctx, leadId,
                    new DealPartnerInput(partnerId, ChannelPartnerVocab.Role.Referrer, ChannelPartnerVocab.Origin.Sourced, null, null, null, null, null, null, null),
                    actor.UserId, ct, noTerms: true, historic: true);
                var dealName = plan.Deals.FirstOrDefault(d => d.Id == leadId)?.Name ?? leadId.ToString();
                if (made.IsOk) rowAttributed++;
                else if (made.Code == "already_attributed") rowThere++;
                else Issue(problems, plan.Row, $"\"{dealName}\": {made.Error}");
            }
            attributed += rowAttributed;
            there += rowThere;
            if (problems.Count > 0) failedRows++;
            outcomes.Add(new ClientRowOutcomeDto(plan.Row, plan.Client, edgeMade, rowAttributed, rowThere, problems));
        }
        return Cp.Ok(Result(new ClientSheetCommitDto(edgesMade, edgesThere, attributed, there, failedRows, outcomes)));
    }
}

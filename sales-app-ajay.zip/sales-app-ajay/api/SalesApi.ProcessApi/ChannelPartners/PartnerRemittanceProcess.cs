using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// What a financial-service partner (FSP) owes US (Phase 2; owner decisions 2.6 and 2.9, 2026-10-19). The FSP bills the end client itself and remits our platform fee; we RECORD:
///
///  - the BILLING DEAL: a deal on the FSP's account that our invoice to the FSP is raised on - ONE per end-client deal (a filtered unique index; linking is explicit, the CRM
///    does not invent a deal). Linking it creates the remittance, the one record per end-client deal.
///  - the dates, as staff read them from the partner's statement: the end user's due date and when the FSP collected. The remittance falls due the plan's days after collection
///    (30 by default, a plan setting); an unreported collection never makes a remittance "due".
///  - OUR invoice to the FSP (an ordinary CRM invoice on the billing deal, so aging, collection tasks and receivables carry it - no duplicate AR). The receivable ledger follows it
///    to the cent (PartnerReceivables, written by PartnerCapture in the invoice's own save).
///  - the status, DERIVED on read (expected | invoiced | remitted | overdue | waived), and the late-interest wording the agreement names: SHOWN, NEVER charged.
///
/// NO NETTING: what the partner owes us and what we owe it are read side by side (PartnerBalancesDto) and never offset.
///
/// Authorization stays at the HTTP layer (partners.manage); the amounts sit behind raw Partner commercials, and writes need Full.
/// </summary>
public sealed class PartnerRemittanceProcess
{
    private readonly PartnerRemittanceStore _store;
    private readonly ChannelPartnerStore _partners;
    private readonly PartnerLedgerStore _ledger;
    private readonly OrgSettingsReader _settings;

    private readonly SalesApi.ProcessLayer.Leads.LeadWriteProcess? _leadWrite;

    public PartnerRemittanceProcess(
        PartnerRemittanceStore store, ChannelPartnerStore partners, PartnerLedgerStore ledger, OrgSettingsReader settings,
        SalesApi.ProcessLayer.Leads.LeadWriteProcess? leadWrite = null)
    {
        _leadWrite = leadWrite;
        _store = store;
        _partners = partners;
        _ledger = ledger;
        _settings = settings;
    }

    private static CpResult<T> NeedsCommercials<T>() => Cp.Forbidden<T>("Your role can't see partner commercials.", "partner_commercials_hidden");
    private static CpResult<T> NeedsWrite<T>() => Cp.Invalid<T>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);
    private const string NoRemittance = "Remittance not found";

    // ---- shaping ----------------------------------------------------------------------------------

    private async Task<List<PartnerRemittanceDto>> ToDtosAsync(List<PartnerRemittance> rows, CancellationToken ct)
    {
        if (rows.Count == 0) return [];
        var accounts = await _store.AccountNamesAsync(rows.Select(r => r.PartnerAccountId).Distinct().ToList(), ct);
        var leads = await _store.LeadNamesAsync(rows.SelectMany(r => new[] { r.EndClientLeadId, r.BillingLeadId }).Distinct().ToList(), ct);
        var invoices = await _store.InvoicesAsync(rows.Where(r => r.InvoiceId != null).Select(r => r.InvoiceId!.Value).Distinct().ToList(), ct);
        var plans = await _store.PlanContentsAsync(rows.Select(r => r.DealPartnerId).Distinct().ToList(), ct);
        var today = ReportingCalendar.Today(await _store.CalendarAsync());
        var currency = await _store.OrgCurrencyAsync(ct);
        var prime = (await _settings.GetChannelPartnerSettingsAsync()).PrimeRatePercent;

        return rows.Select(r =>
        {
            invoices.TryGetValue(r.InvoiceId ?? Guid.Empty, out var inv);
            var fact = inv is null ? null : new PartnerAccrual.InvoiceFact(inv.Id, inv.Status, inv.Amount, inv.Subtotal, inv.AmountPaid, false, inv.IssuedAt, inv.CreatedAt);
            var targets = PartnerReceivables.TargetsOf(fact);
            var raised = inv is not null && inv.Status is not ("draft" or "void");
            var status = PartnerReceivables.StatusOf(r, targets, raised, today);
            var days = PartnerReceivables.DaysOverdue(r, status, today);
            decimal? margin = plans.TryGetValue(r.DealPartnerId, out var content) ? PartnerPlanEngine.Read(content).OverdueInterestMarginPct : null;
            // Only a remittance that is actually late carries the interest wording.
            var (wording, estimate) = status == ChannelPartnerVocab.RemittanceStatus.Overdue
                ? PartnerReceivables.LateInterest(margin, prime, targets.Owed, days, currency)
                : (null, null);
            return new PartnerRemittanceDto(
                r.Id, r.DealPartnerId, r.PartnerAccountId, accounts.GetValueOrDefault(r.PartnerAccountId), r.EndClientLeadId, leads.GetValueOrDefault(r.EndClientLeadId),
                r.BillingLeadId, leads.GetValueOrDefault(r.BillingLeadId), r.InvoiceId, inv?.Number,
                inv is null ? null : targets.Billed, inv is null ? null : targets.Remitted, inv is null ? null : targets.Owed, status,
                r.EndUserDueOn, r.PartnerCollectedOn, r.RemitDueOn, days, wording, estimate, r.WaiveReason, r.WaivedAt, r.CreatedAt);
        }).ToList();
    }

    private async Task<CpResult<ChannelPartnerStore.AccountFacts>> VisiblePartnerAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct)
    {
        var account = await _partners.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<ChannelPartnerStore.AccountFacts>("Account not found");
        return Cp.Ok(account);
    }

    private async Task<(PartnerRemittance? R, CpResult<PartnerRemittanceDto>? Refusal)> LoadAsync(RecordAccessContext ctx, Guid id, CancellationToken ct)
    {
        var r = await _store.FindAsync(id, ct);
        if (r is null) return (null, Cp.NotFound<PartnerRemittanceDto>(NoRemittance));
        var partner = await VisiblePartnerAsync(ctx, r.PartnerAccountId, ct);
        if (!partner.IsOk) return (null, Cp.NotFound<PartnerRemittanceDto>(NoRemittance));
        return (r, null);
    }

    private async Task<CpResult<PartnerRemittanceDto>> DtoAsync(PartnerRemittance r, CancellationToken ct) => Cp.Ok((await ToDtosAsync([r], ct))[0]);

    // ---- reads ---------------------------------------------------------------------------------------

    /// <summary>The remittances (optionally one partner's, or one deal partner's), filtered by derived status. Raw Partner commercials only.</summary>
    public async Task<CpResult<List<PartnerRemittanceDto>>> ListAsync(
        RecordAccessContext ctx, Guid? partnerAccountId, Guid? dealPartnerId, string? status, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<List<PartnerRemittanceDto>>();
        if (partnerAccountId is Guid p)
        {
            var partner = await VisiblePartnerAsync(ctx, p, ct);
            if (!partner.IsOk) return Cp.As<List<PartnerRemittanceDto>, ChannelPartnerStore.AccountFacts>(partner);
        }
        var rows = await _store.ListAsync(partnerAccountId, dealPartnerId, ct);
        if (partnerAccountId is null)
        {
            var facts = await _partners.AccountFactsManyAsync(rows.Select(r => r.PartnerAccountId).Distinct().ToList(), ct);
            rows = rows.Where(r => facts.TryGetValue(r.PartnerAccountId, out var f) && RecordAccess.CanView(ctx, f.OwnerId, f.TeamId)).ToList();
        }
        var dtos = await ToDtosAsync(rows, ct);
        if (!string.IsNullOrWhiteSpace(status)) dtos = dtos.Where(d => d.Status == status).ToList();
        return Cp.Ok(dtos);
    }

    /// <summary>
    /// One partner's money side by side - what we owe it (payable), what we owe it as an integrator (cost) and what it owes us (receivable) - plus its remittances. Three separate
    /// figures from the stored aggregate; NEVER a net.
    /// </summary>
    public async Task<CpResult<PartnerBalancesDto>> BalancesAsync(RecordAccessContext ctx, Guid partnerAccountId, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<PartnerBalancesDto>();
        var partner = await VisiblePartnerAsync(ctx, partnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<PartnerBalancesDto, ChannelPartnerStore.AccountFacts>(partner);
        var payable = (await _ledger.StatsTotalsByPartnerAsync(ct)).GetValueOrDefault(partnerAccountId);
        var direction = await _ledger.StatsDirectionTotalsAsync(partnerAccountId, ct);
        var remittances = await ToDtosAsync(await _store.ListAsync(partnerAccountId, null, ct), ct);
        return Cp.Ok(new PartnerBalancesDto(
            partnerAccountId, payable.Accrued - payable.Clawed - payable.Paid, direction.CostAccrued - direction.CostPaid,
            direction.ReceivableBilled - direction.ReceivableRemitted, remittances));
    }

    // ---- writes ---------------------------------------------------------------------------------------

    /// <summary>
    /// Links the deal on the FSP's account that our platform-fee invoice is raised on, and creates the remittance (one per end-client deal). The deal must be on the FSP's own account,
    /// must not be the end-client deal, and must not already serve another end-client deal. Refused once an invoice is linked (the invoice names its deal).
    /// </summary>
    public async Task<CpResult<PartnerRemittanceDto>> LinkBillingDealAsync(
        RecordAccessContext ctx, Guid dealPartnerId, DealPartnerBillingDealInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerRemittanceDto>();
        var dp = await _partners.FindDealPartnerAsync(dealPartnerId, ct);
        var endClient = dp is null ? null : await _partners.LeadFactsAsync(dp.LeadId, ct);
        if (dp is null || endClient is null || !RecordAccess.CanView(ctx, endClient.OwnerId, endClient.TeamId)) return Cp.NotFound<PartnerRemittanceDto>("Deal partner not found");
        if (dp.Role != ChannelPartnerVocab.Role.Fsp) return Cp.Invalid<PartnerRemittanceDto>("Only a financial-service partner has a billing deal.", "not_an_fsp");
        if (dp.EndedAt != null) return Cp.Conflict<PartnerRemittanceDto>("This attribution has ended.", "already_ended");
        if (!dp.BillsEndClient) return Cp.Conflict<PartnerRemittanceDto>("This partner's plan doesn't say it bills the end client.", "not_billing_the_client");
        if (input.LeadId is not Guid billingId) return Cp.Invalid<PartnerRemittanceDto>("Pick the deal on the partner's account that our invoice is raised on.", "lead_required");
        if (billingId == dp.LeadId) return Cp.Invalid<PartnerRemittanceDto>("The billing deal is a different deal from the end client's.", "same_deal");
        var billing = await _partners.LeadFactsAsync(billingId, ct);
        if (billing is null || !RecordAccess.CanView(ctx, billing.OwnerId, billing.TeamId)) return Cp.NotFound<PartnerRemittanceDto>("Deal not found");
        if (billing.AccountId != dp.PartnerAccountId) return Cp.Invalid<PartnerRemittanceDto>("The billing deal must be a deal on the partner's own account.", "wrong_account");

        var existing = await _store.FindForDealPartnerAsync(dp.Id, ct);
        if (existing is { InvoiceId: not null } && existing.BillingLeadId != billingId)
            return Cp.Conflict<PartnerRemittanceDto>("An invoice is already linked on the current billing deal, so it can't change.", "invoice_linked");
        if (existing is { WaivedAt: not null }) return Cp.Conflict<PartnerRemittanceDto>("This remittance was waived.", "waived");

        dp.BillingLeadId = billingId;
        dp.UpdatedAt = DateTime.UtcNow;
        var remittance = existing;
        if (remittance is null)
        {
            var due = await _store.PaymentDueDateAsync(dp.LeadId, ct);
            remittance = new PartnerRemittance
            {
                Id = Guid.NewGuid(), DealPartnerId = dp.Id, PartnerAccountId = dp.PartnerAccountId, EndClientLeadId = dp.LeadId, BillingLeadId = billingId,
                EndUserDueOn = due is { } d ? DateOnly.FromDateTime(d) : null, CreatedById = actorId,
            };
            _store.Add(remittance);
        }
        else
        {
            remittance.BillingLeadId = billingId;
            remittance.UpdatedAt = DateTime.UtcNow;
        }
        try { await _store.SaveChangesAsync(ct); }
        catch (Microsoft.EntityFrameworkCore.DbUpdateException)
        {
            return Cp.Conflict<PartnerRemittanceDto>("That deal already serves another end-client deal. A billing deal is for one.", "billing_deal_taken");
        }
        return await DtoAsync(remittance, ct);
    }

    /// <summary>
    /// Owner Q5: attaching an FSP that bills the end client CREATES its billing deal - "FSP platform fees - &lt;client&gt;" on the FSP's account - through the ordinary lead-create path
    /// (<c>LeadWriteProcess.CreateAsync</c>: tracked, FieldAudit, aggregates, team follows the owner, the workflow's first open stage), owned by the END-CLIENT deal's owner, value 0 until our
    /// invoice, then links it and creates the remittance exactly as the manual link does. Best effort by design: no owner on the end-client deal, no write access to partner commercials, or a
    /// refusal from the lead path simply leaves the billing deal for a person to link by hand (the manual endpoint stays); the attribution itself is never undone. Returns null in those cases.
    /// </summary>
    public async Task<PartnerRemittanceDto?> EnsureBillingDealAsync(RecordAccessContext ctx, Guid dealPartnerId, Guid actorId, CancellationToken ct = default)
    {
        if (_leadWrite is null || !Cp.CanWriteCommercials(ctx)) return null;
        var dp = await _partners.FindDealPartnerAsync(dealPartnerId, ct);
        if (dp is null || dp.Role != ChannelPartnerVocab.Role.Fsp || !dp.BillsEndClient || dp.EndedAt != null || dp.BillingLeadId != null) return null;
        var endClient = await _partners.LeadFactsAsync(dp.LeadId, ct);
        if (endClient?.OwnerId is not Guid ownerId) return null;

        var (ownerName, clientName) = await _store.BillingDealNamesAsync(dp.LeadId, ownerId, ct);
        var input = new LeadInput(
            Name: $"FSP platform fees - {clientName}", Company: null, Email: null, Phone: null, Status: null, Priority: null, Source: "Channel billing", EstimatedValue: 0m,
            Notes: "Made automatically when the financial-service partner was attached. Our platform-fee invoice to the partner is raised on this deal.",
            NextFollowUpAt: null, Reason: null, Custom: null, AccountId: dp.PartnerAccountId, CloseReason: null, Products: null, Address: null, City: null, State: null,
            PostalCode: null, Country: null, Nationality: null, ExpectedCloseDate: null);
        // The deal is made AS the end-client deal's owner (the lead path stamps the actor as owner and creator); the caller who attached the partner is named in the note above's audit trail
        // by the dealpartner row itself.
        var owner = new RecordAccessContext(ownerId, true, true, TeamScope.Everything, "manage", null);
        var (refusal, created) = await _leadWrite.CreateAsync(
            owner, new LeadView(true, true, "admin", null), new SalesApi.ProcessLayer.Leads.LeadActor(ownerId, _store.OrgId, ownerName ?? "Owner", true, "manage", false), input, skipFormRequirements: true);
        if (refusal is not null || created is null)
        {
            Console.Error.WriteLine($"[partner-billing-deal] deal partner {dealPartnerId}: the billing deal was not created ({refusal?.Reason}); link one by hand.");
            return null;
        }
        var linked = await LinkBillingDealAsync(ctx, dealPartnerId, new DealPartnerBillingDealInput(created.Id), actorId, ct);
        return linked.IsOk ? linked.Value : null;
    }

    /// <summary>
    /// The dates, as staff read them from the partner's statement. The remittance falls due the plan's days after the collection date (frozen on the deal partner); clearing the
    /// collection date clears the due date. Nothing here moves money.
    /// </summary>
    public async Task<CpResult<PartnerRemittanceDto>> UpdateAsync(RecordAccessContext ctx, Guid id, PartnerRemittanceUpdateInput input, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerRemittanceDto>();
        var (r, refusal) = await LoadAsync(ctx, id, ct);
        if (refusal is not null) return refusal;
        if (r!.WaivedAt != null) return Cp.Conflict<PartnerRemittanceDto>("This remittance was waived.", "waived");
        if (input.EndUserDueOn is { } due && (due.Year < 2000 || due.Year > 2100)) return Cp.Invalid<PartnerRemittanceDto>("That due date isn't right.", "bad_date");
        if (input.PartnerCollectedOn is { } collected && (collected.Year < 2000 || collected.Year > 2100)) return Cp.Invalid<PartnerRemittanceDto>("That collection date isn't right.", "bad_date");

        if (input.EndUserDueOn is not null) r.EndUserDueOn = input.EndUserDueOn;
        if (input.ClearPartnerCollectedOn) r.PartnerCollectedOn = null;
        else if (input.PartnerCollectedOn is not null) r.PartnerCollectedOn = input.PartnerCollectedOn;
        var days = (await _store.PlanContentsAsync([r.DealPartnerId], ct)).TryGetValue(r.DealPartnerId, out var content)
            ? PartnerPlanEngine.Read(content).RemitDaysAfterCollection : 30;
        r.RemitDueOn = PartnerReceivables.RemitDueOn(r.PartnerCollectedOn, days);
        r.UpdatedAt = DateTime.UtcNow;
        await _store.SaveChangesAsync(ct);
        return await DtoAsync(r, ct);
    }

    /// <summary>
    /// Links OUR invoice to the FSP (it must be on the billing deal, and not settle another remittance). The receivable ledger entries are written in THIS save by PartnerCapture.
    /// Linking another invoice later is allowed: the ledger follows the new one through adjustments, and nothing is lost.
    /// </summary>
    public async Task<CpResult<PartnerRemittanceDto>> LinkInvoiceAsync(RecordAccessContext ctx, Guid id, PartnerRemittanceLinkInvoiceInput input, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerRemittanceDto>();
        var (r, refusal) = await LoadAsync(ctx, id, ct);
        if (refusal is not null) return refusal;
        if (r!.WaivedAt != null) return Cp.Conflict<PartnerRemittanceDto>("This remittance was waived.", "waived");
        if (input.InvoiceId is not Guid invoiceId) return Cp.Invalid<PartnerRemittanceDto>("Pick our invoice to the partner.", "invoice_required");
        var invoice = await _store.InvoiceAsync(invoiceId, ct);
        if (invoice is null) return Cp.NotFound<PartnerRemittanceDto>("Invoice not found");
        if (invoice.LeadId != r.BillingLeadId) return Cp.Invalid<PartnerRemittanceDto>("That invoice isn't on the billing deal.", "wrong_deal");
        if (await _store.InvoiceTakenAsync(invoiceId, r.Id, ct)) return Cp.Conflict<PartnerRemittanceDto>("That invoice already settles another remittance.", "invoice_taken");

        r.InvoiceId = invoiceId;
        r.UpdatedAt = DateTime.UtcNow;
        try { await _store.SaveChangesAsync(ct); }
        catch (Microsoft.EntityFrameworkCore.DbUpdateException)
        {
            return Cp.Conflict<PartnerRemittanceDto>("That invoice was just linked elsewhere. Reload and try again.", "invoice_taken");
        }
        return await DtoAsync(r, ct);
    }

    /// <summary>
    /// Forgives what the partner still owes. A reason is required. The waiver writes ONE balancing credit (negative, receivable direction) for the remaining balance in the same
    /// save, so the partner's receivable falls to zero; the remittance is then frozen. The CRM does not invoice or charge the late interest it displays, waived or not.
    /// </summary>
    public async Task<CpResult<PartnerRemittanceDto>> WaiveAsync(RecordAccessContext ctx, Guid id, PartnerRemittanceWaiveInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerRemittanceDto>();
        var (r, refusal) = await LoadAsync(ctx, id, ct);
        if (refusal is not null) return refusal;
        if (r!.WaivedAt != null) return Cp.Conflict<PartnerRemittanceDto>("This remittance was already waived.", "waived");
        var reason = input.Reason?.Trim();
        if (string.IsNullOrEmpty(reason)) return Cp.Invalid<PartnerRemittanceDto>("A reason is required to waive a remittance.", "reason_required");
        if (reason.Length > 1000) return Cp.Invalid<PartnerRemittanceDto>("The reason is at most 1000 characters.", "reason_too_long");

        await _store.WriteWaiverCreditAsync(r, reason, actorId, ct);
        r.WaivedAt = DateTime.UtcNow;
        r.WaivedById = actorId;
        r.WaiveReason = reason;
        r.UpdatedAt = DateTime.UtcNow;
        await _store.SaveChangesAsync(ct);
        return await DtoAsync(r, ct);
    }
}

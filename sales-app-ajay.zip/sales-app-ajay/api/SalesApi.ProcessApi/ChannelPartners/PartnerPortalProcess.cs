using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// What a signed-in PARTNER PORTAL user sees: their own partner's deals, earnings, statements (and the PDF), payouts and the usage reported through them. Read-only, nothing here
/// writes, and nothing here reads a principal: the partner arrives as a <see cref="PartnerPortalScope"/> built at the controller (design 9.3.2).
///
/// ISOLATION. Every read goes through <see cref="PartnerPortalStore"/> (or a CRM store method) with the scope's partner id, and an id taken from the URL is looked up WITH that
/// partner, so another partner's statement / payout / deal answers NotFound - not Forbidden, which would confirm the id exists.
///
/// REUSE. The figures are the staff figures: totals from the stored PartnerStats rows, per-deal earned / paid from <see cref="ChannelPartnerStore.EarnedAndPaidByDealPartnerAsync"/>,
/// "settled" from <see cref="PartnerLedgerStore.SettledAsync"/>, the statement DTO from <see cref="PartnerLedgerProcess.ToDto(PartnerStatement, string)"/> and the PDF from
/// <see cref="PartnerLedgerProcess.RenderStatementPdfAsync"/> - so the portal and the channel team can never read a different number. What is NEW is only the shaping into the
/// portal's own DTOs (<c>PartnerPortal.cs</c>), which leave out everything internal by having no field for it.
/// </summary>
public sealed class PartnerPortalProcess
{
    private readonly PartnerPortalStore _portal;
    private readonly PartnerLedgerStore _ledger;
    private readonly ChannelPartnerStore _partners;
    private readonly PartnerLedgerProcess _statements;

    private readonly SalesApi.SystemLayer.Usage.UsageStore _quotes;

    public PartnerPortalProcess(
        PartnerPortalStore portal, PartnerLedgerStore ledger, ChannelPartnerStore partners, PartnerLedgerProcess statements, SalesApi.SystemLayer.Usage.UsageStore quotes)
    {
        _quotes = quotes;
        _portal = portal;
        _ledger = ledger;
        _partners = partners;
        _statements = statements;
    }

    public const int MaxPageSize = 200;

    private static string PhaseOf(PartnerPortalStore.DealRow d) => d.WonAt != null ? "won" : d.LostAt != null ? "lost" : "open";

    // ---- me / overview ---------------------------------------------------------------------------------

    public async Task<CpResult<PartnerPortalMeDto>> MeAsync(PartnerPortalScope scope, CancellationToken ct = default)
    {
        var user = await _portal.UserAsync(scope.UserId, ct);
        var partner = await _portal.PartnerAsync(scope.PartnerAccountId, ct);
        if (user is null || partner is null || user.PortalAccountId != scope.PartnerAccountId || user.PortalKind != PortalKinds.Partner) return Cp.NotFound<PartnerPortalMeDto>("Partner not found");
        return Cp.Ok(new PartnerPortalMeDto(
            user.Id, user.Email, user.FullName, scope.PartnerAccountId, partner.Name, partner.Type, partner.Status, partner.Tier,
            user.OrganizationName, await _portal.OrgCurrencyAsync(ct), user.MustChangePassword));
    }

    public async Task<CpResult<PartnerPortalOverviewDto>> OverviewAsync(PartnerPortalScope scope, CancellationToken ct = default)
    {
        if (await _portal.PartnerAsync(scope.PartnerAccountId, ct) is null) return Cp.NotFound<PartnerPortalOverviewDto>("Partner not found");
        var stats = await _ledger.StatsAsync(new PartnerLedgerStore.StatsFilter(scope.PartnerAccountId, null, null), ct);
        var accrued = stats.Sum(s => s.Accrued);
        var clawed = stats.Sum(s => s.Clawed);
        var paid = stats.Sum(s => s.Paid);
        var deals = await _portal.DealsAsync(scope.PartnerAccountId, ct);
        var active = deals.Where(d => d.EndedAt == null).ToList();
        var years = await YearsAsync(active, ct);
        var latest = (await _portal.StatementsAsync(scope.PartnerAccountId, ct)).FirstOrDefault();
        return Cp.Ok(new PartnerPortalOverviewDto(
            await _portal.OrgCurrencyAsync(ct), accrued, clawed, paid, accrued - clawed - paid,
            deals.Count, deals.Count(d => PhaseOf(d) == "open"), deals.Count(d => PhaseOf(d) == "won"), deals.Count(d => PhaseOf(d) == "lost"),
            latest is null ? null : new PartnerPortalLatestStatementDto(latest.Id, latest.Number, latest.PeriodStart, latest.PeriodEnd, latest.ClosingBalance, latest.IssuedAt),
            await _portal.OpenPayoutCountAsync(scope.PartnerAccountId, ct),
            EndClients: active.Select(d => d.ClientAccountId).Where(a => a != null).Distinct().Count(),
            Year1Total: Sum(active, years, 0), Year2Total: Sum(active, years, 1)));
    }

    /// <summary>Year 1 / Year 2 of each deal (by lead) from its accepted, else newest live, quote: the models' marked results summed across services. Absent = the deal has no quote or the quote marks none.</summary>
    private async Task<Dictionary<Guid, (decimal? Year1, decimal? Year2)>> YearsAsync(IReadOnlyCollection<PartnerPortalStore.DealRow> rows, CancellationToken ct)
    {
        var quotes = await _quotes.FrozenQuotesAsync(rows.Select(r => r.LeadId).Distinct().ToList(), ct);
        var result = new Dictionary<Guid, (decimal?, decimal?)>();
        foreach (var (leadId, quote) in quotes)
        {
            var services = ProposalSnapshotJson.Read(quote.Snapshot)?.Services ?? [];
            decimal? Total(IEnumerable<decimal?> v) { var x = v.Where(n => n != null).ToList(); return x.Count == 0 ? null : x.Sum(n => n!.Value); }
            result[leadId] = (Total(services.Select(s => s.Year1)), Total(services.Select(s => s.Year2)));
        }
        return result;
    }

    /// <summary>Sum of one year over the DISTINCT deals (a partner on a deal twice does not double it); null when none has a mark.</summary>
    private static decimal? Sum(IEnumerable<PartnerPortalStore.DealRow> rows, Dictionary<Guid, (decimal? Year1, decimal? Year2)> years, int which)
    {
        var values = rows.Select(r => r.LeadId).Distinct().Select(l => years.TryGetValue(l, out var y) ? (which == 0 ? y.Year1 : y.Year2) : null).Where(v => v != null).ToList();
        return values.Count == 0 ? null : values.Sum(v => v!.Value);
    }

    // ---- deals -----------------------------------------------------------------------------------------

    private async Task<List<PartnerPortalDealDto>> ToDealDtosAsync(List<PartnerPortalStore.DealRow> rows, CancellationToken ct)
    {
        var ids = rows.Select(r => r.Id).ToList();
        var money = await _partners.EarnedAndPaidByDealPartnerAsync(ids, ct);
        var collected = await _partners.LedgerByDealPartnerAsync(ids, ct);
        var years = await YearsAsync(rows, ct);
        return rows.Select(r =>
        {
            var (earned, paid) = money.GetValueOrDefault(r.Id);
            var (_, baseDelta) = collected.GetValueOrDefault(r.Id);
            var (year1, year2) = years.GetValueOrDefault(r.LeadId);
            return new PartnerPortalDealDto(
                r.Id, r.Company ?? r.LeadName, r.ClientName ?? r.Company, r.Role, PhaseOf(r), r.StartedAt, r.EndedAt, earned, paid, earned - paid, baseDelta, year1, year2);
        }).ToList();
    }

    public async Task<CpResult<List<PartnerPortalDealDto>>> DealsAsync(PartnerPortalScope scope, CancellationToken ct = default) =>
        Cp.Ok(await ToDealDtosAsync(await _portal.DealsAsync(scope.PartnerAccountId, ct), ct));

    public async Task<CpResult<PartnerPortalDealDetailDto>> DealAsync(PartnerPortalScope scope, Guid dealPartnerId, CancellationToken ct = default)
    {
        var row = await _portal.DealAsync(scope.PartnerAccountId, dealPartnerId, ct);
        if (row is null) return Cp.NotFound<PartnerPortalDealDetailDto>("Deal not found");
        var deal = (await ToDealDtosAsync([row], ct))[0];
        var entries = await EntriesCoreAsync(scope, dealPartnerId, 0, MaxPageSize, ct);
        return Cp.Ok(new PartnerPortalDealDetailDto(deal, entries.Entries));
    }

    // ---- entries ---------------------------------------------------------------------------------------

    private async Task<PartnerPortalEntriesPageDto> EntriesCoreAsync(PartnerPortalScope scope, Guid? dealPartnerId, int skip, int take, CancellationToken ct)
    {
        var (rows, total) = await _portal.EntriesAsync(scope.PartnerAccountId, dealPartnerId, Math.Max(0, skip), Math.Clamp(take <= 0 ? 50 : take, 1, MaxPageSize), ct);
        var names = await _portal.LeadNamesAsync(rows.Where(r => r.LeadId != null).Select(r => r.LeadId!.Value).Distinct().ToList(), ct);
        var settled = await _ledger.SettledAsync(rows.Select(r => r.Id).ToList(), ct);
        return new PartnerPortalEntriesPageDto(
            rows.Select(e => new PartnerPortalEntryDto(
                e.Id, e.Kind, e.Amount, e.Currency, e.EarnedAt, e.LeadId is Guid l ? names.GetValueOrDefault(l) : null, e.BaseDelta, e.Rate, settled.Contains(e.Id))).ToList(),
            total);
    }

    public async Task<CpResult<PartnerPortalEntriesPageDto>> EntriesAsync(PartnerPortalScope scope, int skip, int take, CancellationToken ct = default) =>
        Cp.Ok(await EntriesCoreAsync(scope, null, skip, take, ct));

    // ---- statements ------------------------------------------------------------------------------------

    private static PartnerPortalStatementDto ToStatement(PartnerStatement s, string partnerName, bool withLines)
    {
        var dto = PartnerLedgerProcess.ToDto(s, partnerName);
        return new PartnerPortalStatementDto(
            s.Id, s.Number, partnerName, s.PeriodStart, s.PeriodEnd, s.OpeningBalance, s.Accruals, s.Clawbacks, s.Payouts, s.ClosingBalance,
            withLines ? dto.Lines.Select(l => new PartnerPortalStatementLineDto(l.LeadName, l.Kind, l.Amount, l.EarnedAt, l.BaseDelta, l.Rate)).ToList() : [],
            s.IssuedAt);
    }

    public async Task<CpResult<List<PartnerPortalStatementDto>>> StatementsAsync(PartnerPortalScope scope, CancellationToken ct = default)
    {
        var partner = await _portal.PartnerAsync(scope.PartnerAccountId, ct);
        if (partner is null) return Cp.NotFound<List<PartnerPortalStatementDto>>("Partner not found");
        var rows = await _portal.StatementsAsync(scope.PartnerAccountId, ct);
        var list = new List<PartnerPortalStatementDto>();
        foreach (var s in rows) list.Add(ToStatement(s, partner.Name, withLines: false));
        return Cp.Ok(list);
    }

    public async Task<CpResult<PartnerPortalStatementDto>> StatementAsync(PartnerPortalScope scope, Guid statementId, CancellationToken ct = default)
    {
        var partner = await _portal.PartnerAsync(scope.PartnerAccountId, ct);
        var s = await _portal.StatementAsync(scope.PartnerAccountId, statementId, ct);
        if (partner is null || s is null) return Cp.NotFound<PartnerPortalStatementDto>("Statement not found");
        return Cp.Ok(ToStatement(s, partner.Name, withLines: true));
    }

    /// <summary>The emailed statement PDF - the SAME renderer the channel team's download uses, so the portal discloses nothing the PDF did not.</summary>
    public async Task<CpResult<(string FileName, byte[] Pdf)>> StatementPdfAsync(PartnerPortalScope scope, Guid statementId, CancellationToken ct = default)
    {
        var partner = await _portal.PartnerAsync(scope.PartnerAccountId, ct);
        var s = await _portal.StatementAsync(scope.PartnerAccountId, statementId, ct);
        if (partner is null || s is null) return Cp.NotFound<(string FileName, byte[] Pdf)>("Statement not found");
        return Cp.Ok(await _statements.RenderStatementPdfAsync(PartnerLedgerProcess.ToDto(s, partner.Name), ct));
    }

    // ---- payouts ---------------------------------------------------------------------------------------

    private static PartnerPortalPayoutDto ToPayoutDto(PartnerPayout p) =>
        new(p.Id, p.Number, p.Status, p.NetAmount, p.VatRate, p.VatAmount, p.GrossAmount, p.Currency,
            p.PartnerInvoiceNumber, p.PartnerInvoiceDate, p.DueDate, p.PaidAt, p.Method, p.Reference, p.Items.Count);

    public async Task<CpResult<List<PartnerPortalPayoutDto>>> PayoutsAsync(PartnerPortalScope scope, CancellationToken ct = default) =>
        Cp.Ok((await _portal.PayoutsAsync(scope.PartnerAccountId, ct)).Select(ToPayoutDto).ToList());

    public async Task<CpResult<PartnerPortalPayoutDto>> PayoutAsync(PartnerPortalScope scope, Guid payoutId, CancellationToken ct = default)
    {
        var p = await _portal.PayoutAsync(scope.PartnerAccountId, payoutId, ct);
        return p is null ? Cp.NotFound<PartnerPortalPayoutDto>("Payout not found") : Cp.Ok(ToPayoutDto(p));
    }

    // ---- usage reported through this partner -------------------------------------------------------------

    public async Task<CpResult<PartnerPortalUsageDto>> UsageAsync(PartnerPortalScope scope, DateOnly? from, DateOnly? to, CancellationToken ct = default)
    {
        var rows = await _portal.UsageAsync(scope.PartnerAccountId, from is DateOnly f ? new DateOnly(f.Year, f.Month, 1) : null, to is DateOnly t ? new DateOnly(t.Year, t.Month, 1) : null, ct);
        var names = await _portal.AccountNamesAsync(rows.Select(r => r.AccountId).Distinct().ToList(), ct);
        var grouped = rows.GroupBy(r => (r.AccountId, r.Month))
            .Select(g => new PartnerPortalUsageRowDto(
                g.Key.AccountId, names.GetValueOrDefault(g.Key.AccountId) ?? "", g.Key.Month,
                g.Where(r => r.Metric == UsageVocab.Metric.InvoicesIssued).Sum(r => r.Count),
                g.Where(r => r.Metric == UsageVocab.Metric.InvoicesReceived).Sum(r => r.Count),
                g.Where(r => r.Metric == UsageVocab.Metric.ApiCalls).Sum(r => r.Count)))
            .OrderByDescending(r => r.Month).ThenBy(r => r.ClientName, StringComparer.OrdinalIgnoreCase).ToList();
        return Cp.Ok(new PartnerPortalUsageDto(grouped, grouped.Sum(r => r.InvoicesIssued), grouped.Sum(r => r.InvoicesReceived), grouped.Sum(r => r.ApiCalls)));
    }
}

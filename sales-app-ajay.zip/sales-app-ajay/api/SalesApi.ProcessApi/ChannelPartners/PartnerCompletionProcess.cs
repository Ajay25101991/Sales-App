using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// Retrospective terms (to-do/partner-management-design.md section 11, owner decisions 2026-10-20): the "Partners to complete" list - what the bulk uploads left without terms - and
/// attaching a plan later, with a BACK-PAY PREVIEW of what the partner would earn on everything collected so far (owner F2) before anything is written.
///
/// REUSE, not parallel. The preview is the reconciliation's own arithmetic (<see cref="PartnerAccrual.TargetForAsync"/> via <see cref="PartnerAccrual.PreviewBackPayAsync"/>), so it
/// cannot disagree with the accrual that follows; the confirm is <see cref="ChannelPartnerProcess.RepointAsync"/> - its rules (terms frozen once the first earning is written,
/// a reason, Partner commercials write) and its <c>AccrueNow</c> run unchanged. Terms are not frozen until the first earning (F1), and a deal partner attributed with no terms has none,
/// so attaching works on exactly these rows. This class writes nothing itself.
///
/// MASKING. Every figure here is Partner commercials: the back-pay preview needs a RAW read and the attach a FULL write; below that the caller is told so, never shown a masked number.
/// The "to complete" list carries no amount.
/// </summary>
public sealed class PartnerCompletionProcess
{
    private readonly PartnerBulkStore _bulk;
    private readonly ChannelPartnerStore _store;
    private readonly PartnerLedgerStore _ledger;
    private readonly ChannelPartnerProcess _partners;

    public PartnerCompletionProcess(PartnerBulkStore bulk, ChannelPartnerStore store, PartnerLedgerStore ledger, ChannelPartnerProcess partners)
    {
        _bulk = bulk;
        _store = store;
        _ledger = ledger;
        _partners = partners;
    }

    public const string DefaultReason = "Terms attached after the bulk upload";

    // ---- the list -----------------------------------------------------------------------------------------------

    public async Task<PartnersToCompleteDto> ToCompleteAsync(RecordAccessContext ctx, CancellationToken ct = default)
    {
        var profiles = await _store.ListProfilesAsync(null, null, ct);
        var facts = await _store.AccountFactsManyAsync(profiles.Select(p => p.AccountId).ToList(), ct);
        var visible = profiles.Where(p => facts.TryGetValue(p.AccountId, out var f) && RecordAccess.CanView(ctx, f.OwnerId, f.TeamId)).ToList();
        var signed = await _store.SignedAgreementAccountsAsync(visible, ct);
        var planless = await _bulk.PlanlessCountsAsync(ct);
        var settings = await _partners.GetSettingsAsync();

        var partners = new List<PartnerToCompleteDto>();
        foreach (var p in visible)
        {
            // The ONE completeness rule (also the profile DTO's `missing` and the Active / new-deal enforcement): type_to_be_set, then the partner type's required fields.
            var missing = await _partners.MissingAsync(p, settings, signed.Contains(p.AccountId), ct);
            var count = planless.GetValueOrDefault(p.AccountId);
            if (missing.Count == 0 && count == 0) continue;
            partners.Add(new PartnerToCompleteDto(p.AccountId, facts[p.AccountId].Name, p.Type, p.Status, missing, count));
        }

        var dealPartners = (await _bulk.PlanlessDealPartnersAsync(null, null, ct))
            .Where(d => d.Lead is not null && RecordAccess.CanView(ctx, d.Lead.OwnerId, d.Lead.TeamId))
            .Select(d => new DealPartnerToCompleteDto(d.Id, d.LeadId, d.Lead?.Name, d.PartnerAccountId, d.PartnerAccount?.Name ?? "", d.Role, d.StartedAt)).ToList();
        return new PartnersToCompleteDto(partners, dealPartners);
    }

    // ---- the back-pay preview and the attach ------------------------------------------------------------------------

    private sealed record Prepared(
        Guid PlanId, string PlanName, int Version, PartnerPlanContentDto Content, string RawContent, PartnerRuleSummaryDto Rule, string Currency, List<Line> Lines);

    private sealed record Line(DealPartner Dp, decimal Collected, decimal BackPay, string? Code, string? Refusal)
    {
        public bool CanAttach => Code is null;
    }

    /// <param name="partnerAccountId">Bulk: every planless deal partner of this partner (or the ids in the input). Null with ids: those deal partners.</param>
    private async Task<CpResult<Prepared>> PrepareAsync(RecordAccessContext ctx, Guid? partnerAccountId, AttachPlanInput input, CancellationToken ct)
    {
        if (!Cp.CanReadCommercials(ctx))
            return Cp.Forbidden<Prepared>("Seeing what a partner would earn needs a Partner commercials read.", "partner_commercials_required");
        if (input.PlanId is not Guid planId) return Cp.Invalid<Prepared>("Pick the plan.", "plan_required");
        var plan = await _store.FindPlanAsync(planId, ct);
        if (plan is null || plan.ArchivedAt != null || plan.IsSystem) return Cp.Invalid<Prepared>("Pick one of your commission plans.", "bad_plan");
        var version = await _store.LatestVersionAsync(planId, ct);
        if (version is null) return Cp.Invalid<Prepared>("That plan has no published version yet. Publish it first.", "plan_not_published");
        var content = PartnerPlanEngine.Read(version.Content);
        var rule = PartnerPlanEngine.Effective(content, null, null, null, null, null).Summary();

        var ids = input.DealPartnerIds?.Distinct().ToList();
        var rows = await _bulk.PlanlessDealPartnersAsync(partnerAccountId, ids, ct);
        rows = rows.Where(d => d.Lead is not null && RecordAccess.CanView(ctx, d.Lead.OwnerId, d.Lead.TeamId)).ToList();

        var lines = new List<Line>();
        foreach (var dp in rows)
        {
            if (content.Direction != ChannelPartnerProcess.WantedDirection(dp.Role))
            { lines.Add(new Line(dp, 0m, 0m, "plan_role_mismatch", "That plan is not the kind this partner's role on the deal needs.")); continue; }
            if (await _ledger.EntryCountAsync(dp.Id, ct) > 0)
            { lines.Add(new Line(dp, 0m, 0m, "terms_frozen", "This attribution has already accrued, so its terms are frozen.")); continue; }
            var (collected, backPay, problem) = await _bulk.BackPayAsync(dp, version.Content, ct);
            lines.Add(problem is null
                ? new Line(dp, collected, backPay, null, null)
                : new Line(dp, 0m, 0m, "plan_unevaluable", "This plan can't be worked out for the deal: " + problem));
        }

        // A deal partner the caller named but that is not in the list is either not theirs to see, gone, ended or already has terms.
        if (ids is not null)
        {
            var found = rows.Select(r => r.Id).ToHashSet();
            foreach (var id in ids.Where(i => !found.Contains(i)))
            {
                var other = await _bulk.DealPartnerAsync(id, ct);
                if (other?.Lead is null || !RecordAccess.CanView(ctx, other.Lead.OwnerId, other.Lead.TeamId)) return Cp.NotFound<Prepared>("Deal partner not found");
                lines.Add(new Line(other, 0m, 0m, other.EndedAt != null ? "already_ended" : "has_terms",
                    other.EndedAt != null ? "This attribution has ended." : "This deal partner already has a plan."));
            }
        }
        return Cp.Ok(new Prepared(planId, plan.Name, version.Version, content, version.Content, rule, await _bulk.OrgCurrencyAsync(ct), lines));
    }

    private static BackPayLineDto ToDto(Line l) => new(
        l.Dp.Id, l.Dp.LeadId, l.Dp.Lead?.Name, l.Dp.PartnerAccountId, l.Dp.PartnerAccount?.Name ?? "", l.Dp.Role, l.Collected, l.BackPay, l.CanAttach, l.Code, l.Refusal);

    /// <summary>What the plan would pay on everything collected so far, per deal. Writes nothing.</summary>
    public async Task<CpResult<BackPayPreviewDto>> PreviewAsync(RecordAccessContext ctx, Guid? partnerAccountId, AttachPlanInput input, CancellationToken ct = default)
    {
        var prepared = await PrepareAsync(ctx, partnerAccountId, input, ct);
        if (!prepared.IsOk) return Cp.As<BackPayPreviewDto, Prepared>(prepared);
        var p = prepared.Value!;
        var lines = p.Lines.Select(ToDto).ToList();
        return Cp.Ok(new BackPayPreviewDto(
            p.PlanId, p.PlanName, p.Version, p.Rule, p.Currency, lines, lines.Where(l => l.CanAttach).Sum(l => l.BackPay),
            lines.Count(l => l.CanAttach), lines.Count(l => !l.CanAttach)));
    }

    /// <summary>
    /// Confirm: each attachable deal partner is re-pointed at the plan (the existing re-point, so its rules run) and accrues at once. A deal partner that is refused - or whose
    /// terms froze since the preview - is reported with its reason and the rest still go through.
    /// </summary>
    public async Task<CpResult<AttachPlanResultDto>> AttachAsync(
        RecordAccessContext ctx, Guid? partnerAccountId, AttachPlanInput input, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx))
            return Cp.Invalid<AttachPlanResultDto>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);
        var prepared = await PrepareAsync(ctx, partnerAccountId, input, ct);
        if (!prepared.IsOk) return Cp.As<AttachPlanResultDto, Prepared>(prepared);
        var p = prepared.Value!;
        var reason = string.IsNullOrWhiteSpace(input.Reason) ? DefaultReason : input.Reason.Trim();

        var lines = new List<AttachPlanLineDto>();
        foreach (var line in p.Lines)
        {
            var dp = line.Dp;
            if (!line.CanAttach) { lines.Add(new AttachPlanLineDto(dp.Id, dp.LeadId, dp.Lead?.Name, false, null, line.Code, line.Refusal)); continue; }
            var done = await _partners.RepointAsync(ctx, dp.Id, new DealPartnerRepointInput(p.PlanId, reason), ct);
            if (!done.IsOk) { lines.Add(new AttachPlanLineDto(dp.Id, dp.LeadId, dp.Lead?.Name, false, null, done.Code, done.Error)); continue; }
            var accrued = (await _store.LedgerByDealPartnerAsync([dp.Id], ct)).GetValueOrDefault(dp.Id).Accrued;
            lines.Add(new AttachPlanLineDto(dp.Id, dp.LeadId, dp.Lead?.Name, true, accrued));
        }
        return Cp.Ok(new AttachPlanResultDto(
            p.PlanId, p.PlanName, p.Currency, lines, lines.Where(l => l.Attached).Sum(l => l.Accrued ?? 0m), lines.Count(l => l.Attached), lines.Count(l => !l.Attached)));
    }
}

using System.Text;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Approvals;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// Paying a partner (owner decisions 2026-10-19): a payout is a RECORD that finance paid the partner outside the CRM (Q8) - prepared from the partner's payable ledger entries,
/// carrying the PARTNER's tax invoice (Q12: number, date, net, VAT, gross; the ledger itself stays ex VAT), approved on the EXISTING approval chains with amount thresholds
/// (Q13: the request's Amount is the net, so a chain condition on `amount` is the limit; the preparer can never approve - ApprovalChainProcess.DecideStepAsync), due on the
/// plan's payment terms from the invoice date (Q15), and exported as a bank CSV once approved. Marking it paid writes the one ledger entry that settles it.
///
/// Q17: a partner whose profile says "payouts need a signed agreement" cannot have a payout submitted or paid while none is on file - the block is also shown on the
/// payout (BlockedReason) so the screen can say why before anyone tries.
///
/// Reuse: <see cref="ApprovalChainProcess.ResolveAndStartAsync"/> starts the chain exactly as it does for a discount or a reveal; <see cref="PartnerPayoutRules"/> holds the status
/// moves the approval decision shares; <see cref="CsvUtil.ToCsvSafe"/> is the export writer. Authorization stays at the HTTP layer; the caller's Partner commercials and
/// ID &amp; bank levels arrive in the <see cref="RecordAccessContext"/>.
/// </summary>
public sealed class PartnerPayoutProcess
{
    private readonly PartnerPayoutStore _store;
    private readonly PartnerLedgerStore _ledger;
    private readonly ChannelPartnerStore _partners;
    private readonly ApprovalChainProcess _chains;

    public PartnerPayoutProcess(PartnerPayoutStore store, PartnerLedgerStore ledger, ChannelPartnerStore partners, ApprovalChainProcess chains)
    {
        _store = store;
        _ledger = ledger;
        _partners = partners;
        _chains = chains;
    }

    public const string NoAgreementCode = "no_signed_agreement";
    private const string NoPayout = "Payout not found";

    private static CpResult<T> NeedsCommercials<T>() => Cp.Forbidden<T>("Your role can't see partner commercials.", "partner_commercials_hidden");
    private static CpResult<T> NeedsWrite<T>() => Cp.Invalid<T>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);

    // ---- shaping ----------------------------------------------------------------------------------

    /// <summary>Why this payout can't move on right now (Q17), or null. Cheap enough to compute for every row of a list.</summary>
    private async Task<string?> BlockedReasonAsync(PartnerPayout p, PartnerProfile? profile, CancellationToken ct)
    {
        if (p.Status is ChannelPartnerVocab.PayoutStatus.Paid or ChannelPartnerVocab.PayoutStatus.Cancelled or ChannelPartnerVocab.PayoutStatus.Rejected) return null;
        if (profile is null) return "This account is no longer a channel partner.";
        if (profile.PayoutsNeedSignedAgreement && !await _store.SignedAgreementOnFileAsync(profile, ct))
            return "This partner needs a signed agreement on file before any payout. Link the signed agreement to the partner.";
        return null;
    }

    private async Task<List<PartnerPayoutDto>> ToDtosAsync(List<PartnerPayout> rows, CancellationToken ct)
    {
        if (rows.Count == 0) return [];
        var partnerIds = rows.Select(r => r.PartnerAccountId).Distinct().ToList();
        var names = await _store.AccountNamesAsync(partnerIds, ct);
        var profiles = await _store.ProfilesAsync(partnerIds, ct);
        var people = await _store.ProfileNamesAsync(rows.SelectMany(r => new[] { r.PreparedById }).Distinct().ToList(), ct);
        var instances = await _store.ChainInstanceIdsAsync(rows.Where(r => r.ApprovalRequestId != null).Select(r => r.ApprovalRequestId!.Value).ToList(), ct);
        var files = await _store.AttachmentNamesAsync(rows.Where(r => r.PartnerInvoiceAttachmentId != null).Select(r => r.PartnerInvoiceAttachmentId!.Value).ToList(), ct);
        var result = new List<PartnerPayoutDto>(rows.Count);
        foreach (var p in rows)
        {
            profiles.TryGetValue(p.PartnerAccountId, out var profile);
            result.Add(new PartnerPayoutDto(
                p.Id, p.Number, p.PartnerAccountId, names.GetValueOrDefault(p.PartnerAccountId, ""), p.Status,
                p.NetAmount, p.VatRate, p.VatAmount, p.GrossAmount, p.Currency,
                p.PartnerInvoiceNumber, p.PartnerInvoiceDate, p.PartnerInvoiceAttachmentId, p.DueDate,
                p.PreparedById, people.GetValueOrDefault(p.PreparedById), p.PreparedAt, p.SubmittedAt, p.ApprovalRequestId,
                p.ApprovalRequestId is Guid r ? instances.GetValueOrDefault(r) : null,
                p.ApprovedById, p.ApprovedAt, p.DecisionNote, p.PaidAt, p.PaidById, p.Method, p.Reference, p.ProofAttachmentId, p.ExportedAt,
                p.Items.Count, p.Items.Select(i => i.LedgerEntryId).ToList(), await BlockedReasonAsync(p, profile, ct),
                p.PartnerInvoiceAttachmentId is Guid inv ? files.GetValueOrDefault(inv) : null,
                p.PartnerInvoiceAttachmentId is Guid inv2 ? $"/attachments/{inv2}/file" : null, p.Direction));
        }
        return result;
    }

    private async Task<CpResult<ChannelPartnerStore.AccountFacts>> VisiblePartnerAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct)
    {
        var account = await _partners.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<ChannelPartnerStore.AccountFacts>("Account not found");
        return Cp.Ok(account);
    }

    private async Task<(PartnerPayout? Payout, CpResult<PartnerPayoutDto>? Refusal)> LoadAsync(RecordAccessContext ctx, Guid id, CancellationToken ct)
    {
        var payout = await _store.FindAsync(id, ct);
        if (payout is null) return (null, Cp.NotFound<PartnerPayoutDto>(NoPayout));
        var partner = await VisiblePartnerAsync(ctx, payout.PartnerAccountId, ct);
        if (!partner.IsOk) return (null, Cp.NotFound<PartnerPayoutDto>(NoPayout));
        return (payout, null);
    }

    private async Task<CpResult<PartnerPayoutDto>> DtoAsync(PartnerPayout p, CancellationToken ct) => Cp.Ok((await ToDtosAsync([p], ct))[0]);

    // ---- reads ---------------------------------------------------------------------------------------

    public async Task<CpResult<List<PartnerPayoutDto>>> ListAsync(RecordAccessContext ctx, Guid? partnerAccountId, string? status, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<List<PartnerPayoutDto>>();
        if (partnerAccountId is Guid p)
        {
            var partner = await VisiblePartnerAsync(ctx, p, ct);
            if (!partner.IsOk) return Cp.As<List<PartnerPayoutDto>, ChannelPartnerStore.AccountFacts>(partner);
        }
        var rows = await _store.ListAsync(partnerAccountId, status, ct);
        if (partnerAccountId is null)
        {
            var facts = await _partners.AccountFactsManyAsync(rows.Select(r => r.PartnerAccountId).Distinct().ToList(), ct);
            rows = rows.Where(r => facts.TryGetValue(r.PartnerAccountId, out var f) && RecordAccess.CanView(ctx, f.OwnerId, f.TeamId)).ToList();
        }
        return Cp.Ok(await ToDtosAsync(rows, ct));
    }

    public async Task<CpResult<PartnerPayoutDto>> GetAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<PartnerPayoutDto>();
        var (payout, refusal) = await LoadAsync(ctx, id, ct);
        return refusal ?? await DtoAsync(payout!, ct);
    }

    // ---- prepare -------------------------------------------------------------------------------------

    /// <summary>
    /// Builds a DRAFT payout from the partner's payable ledger entries (all of them, or the ids given). The net is the sum of the entries (clawbacks reduce it) and must be
    /// positive: a partner whose reversals exceed what is payable is simply carried forward, nothing is paid. The partner's tax invoice may be entered now or before submitting.
    /// </summary>
    public async Task<CpResult<PartnerPayoutDto>> PrepareAsync(RecordAccessContext ctx, PartnerPayoutPrepareInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerPayoutDto>();
        if (input.PartnerAccountId is not Guid partnerId) return Cp.Invalid<PartnerPayoutDto>("Pick the partner.", "partner_required");
        var partner = await VisiblePartnerAsync(ctx, partnerId, ct);
        if (!partner.IsOk) return Cp.As<PartnerPayoutDto, ChannelPartnerStore.AccountFacts>(partner);
        var profile = await _store.ProfileAsync(partnerId, ct);
        if (profile is null) return Cp.Invalid<PartnerPayoutDto>("That account isn't a channel partner.", "not_a_partner");

        // ONE direction per payout: payable (a share we owe, the default) or cost (an integrator's accepted milestones). A receivable is the partner paying US, so it can
        // never be prepared into a payout, and entries of another direction named in EntryIds are "not payable" below.
        var direction = string.IsNullOrWhiteSpace(input.Direction) ? ChannelPartnerVocab.Direction.Payable : input.Direction.Trim();
        if (!ChannelPartnerVocab.Direction.IsPayable(direction))
            return Cp.Invalid<PartnerPayoutDto>("A payout is for a share we owe (payable) or an integrator's cost (cost). A receivable is paid to us, not by us.", "bad_direction");
        var entries = await _ledger.UnsettledEarningsAsync(partnerId, input.EntryIds is { Count: > 0 } ? input.EntryIds : null, direction, ct);
        var now = DateTime.UtcNow;
        entries = entries.Where(e => e.PayableOn <= now).ToList();
        if (input.EntryIds is { Count: > 0 } wanted && entries.Select(e => e.Id).Distinct().Count() != wanted.Distinct().Count())
            return Cp.Invalid<PartnerPayoutDto>("Some of those entries aren't payable (already in a payout, not this partner's, or not yet payable).", "entries_unavailable");
        if (entries.Count == 0) return Cp.Invalid<PartnerPayoutDto>("Nothing is payable to this partner right now.", "nothing_payable");
        var net = PartnerPlanEngine.Money(entries.Sum(e => e.Amount));
        if (net <= 0m)
            return Cp.Invalid<PartnerPayoutDto>($"These entries total {net:0.00}, so there is nothing to pay. Reversals are carried forward against the next accruals.", "nothing_payable");

        var bad = ValidateInvoice(input.PartnerInvoiceNumber, input.VatRate, input.VatAmount);
        if (bad is not null) return Cp.Invalid<PartnerPayoutDto>(bad, "bad_invoice");
        if (input.PartnerInvoiceAttachmentId is Guid file && !await _store.PartnerInvoiceFileExistsAsync(file, partnerId, ct))
            return Cp.Invalid<PartnerPayoutDto>("The invoice must be a file added to the partner's account as a partner invoice.", "bad_invoice_file");

        var (vatRate, vat, gross) = PartnerPayoutRules.Vat(net, input.VatRate, input.VatAmount);
        for (var attempt = 0; attempt < 3; attempt++)
        {
            var payout = new PartnerPayout
            {
                Id = Guid.NewGuid(),
                PartnerAccountId = partnerId,
                Number = await _store.NextNumberAsync(now.Year, ct),
                Status = ChannelPartnerVocab.PayoutStatus.Draft,
                Direction = direction,
                NetAmount = net, VatRate = vatRate, VatAmount = vat, GrossAmount = gross,
                Currency = await _store.OrgCurrencyAsync(ct),
                PartnerInvoiceNumber = Clean(input.PartnerInvoiceNumber),
                PartnerInvoiceDate = input.PartnerInvoiceDate,
                PartnerInvoiceAttachmentId = input.PartnerInvoiceAttachmentId,
                DueDate = PartnerPayoutRules.DueDate(input.PartnerInvoiceDate, entries.Select(e => e.PaymentTermsDays)),
                PreparedById = actorId,
                PreparedAt = now,
                UpdatedAt = now,
            };
            foreach (var e in entries) payout.Items.Add(new PartnerPayoutItem { Id = Guid.NewGuid(), PayoutId = payout.Id, LedgerEntryId = e.Id });
            _store.Add(payout);
            if (await _store.TrySaveNewAsync(payout, ct)) return await DtoAsync(payout, ct);
        }
        return Cp.Conflict<PartnerPayoutDto>("Other payouts were prepared at the same moment, or some of those entries were just taken. Reload and try again.", "number_race");
    }

    private static string? Clean(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    private static string? ValidateInvoice(string? number, decimal? vatRate, decimal? vatAmount)
    {
        if (number is { Length: > 80 }) return "The invoice number is at most 80 characters.";
        if (vatRate is { } r && (r < 0m || r > 100m)) return "The VAT rate is 0 to 100.";
        if (vatAmount is { } a && a < 0m) return "The VAT amount cannot be negative.";
        return null;
    }

    /// <summary>Edits a DRAFT payout's partner-invoice details (number, date, file, VAT). Net does not change here: it is what the entries add up to.</summary>
    public async Task<CpResult<PartnerPayoutDto>> UpdateAsync(RecordAccessContext ctx, Guid id, PartnerPayoutUpdateInput input, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerPayoutDto>();
        var (payout, refusal) = await LoadAsync(ctx, id, ct);
        if (refusal is not null) return refusal;
        if (payout!.Status != ChannelPartnerVocab.PayoutStatus.Draft)
            return Cp.Conflict<PartnerPayoutDto>("Only a draft payout can be edited.", "not_draft");
        var bad = ValidateInvoice(input.PartnerInvoiceNumber, input.VatRate, input.VatAmount);
        if (bad is not null) return Cp.Invalid<PartnerPayoutDto>(bad, "bad_invoice");
        if (input.PartnerInvoiceAttachmentId is Guid file && !await _store.PartnerInvoiceFileExistsAsync(file, payout.PartnerAccountId, ct))
            return Cp.Invalid<PartnerPayoutDto>("The invoice must be a file added to the partner's account as a partner invoice.", "bad_invoice_file");

        if (input.PartnerInvoiceNumber is not null) payout.PartnerInvoiceNumber = Clean(input.PartnerInvoiceNumber);
        if (input.PartnerInvoiceDate is not null) payout.PartnerInvoiceDate = input.PartnerInvoiceDate;
        if (input.PartnerInvoiceAttachmentId is not null) payout.PartnerInvoiceAttachmentId = input.PartnerInvoiceAttachmentId;
        if (input.Note is not null) payout.Note = Clean(input.Note);
        if (input.VatRate is not null || input.VatAmount is not null)
        {
            var (rate, vat, gross) = PartnerPayoutRules.Vat(payout.NetAmount, input.VatRate ?? payout.VatRate, input.VatAmount);
            payout.VatRate = rate; payout.VatAmount = vat; payout.GrossAmount = gross;
        }
        var entries = await _store.EntriesAsync(payout.Items.Select(i => i.LedgerEntryId).ToList(), ct);
        payout.DueDate = PartnerPayoutRules.DueDate(payout.PartnerInvoiceDate, entries.Select(e => e.PaymentTermsDays));
        payout.UpdatedAt = DateTime.UtcNow;
        await _store.SaveChangesAsync(ct);
        return await DtoAsync(payout, ct);
    }

    // ---- submit / cancel -------------------------------------------------------------------------------

    /// <summary>
    /// Sends the payout for approval. Needs the partner's tax invoice number and date (the record the CRM keeps of what the partner billed), a signed agreement where the
    /// partner's profile requires one, and an approver: the request goes to the first matching approval chain, else to the org admins (never to the preparer).
    /// </summary>
    public async Task<CpResult<PartnerPayoutDto>> SubmitAsync(RecordAccessContext ctx, Guid id, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerPayoutDto>();
        var (payout, refusal) = await LoadAsync(ctx, id, ct);
        if (refusal is not null) return refusal;
        if (payout!.Status != ChannelPartnerVocab.PayoutStatus.Draft) return Cp.Conflict<PartnerPayoutDto>("Only a draft payout can be submitted.", "not_draft");
        if (string.IsNullOrWhiteSpace(payout.PartnerInvoiceNumber) || payout.PartnerInvoiceDate is null)
            return Cp.Invalid<PartnerPayoutDto>("Record the partner's tax invoice number and date before submitting.", "invoice_required");
        if (payout.NetAmount <= 0m) return Cp.Invalid<PartnerPayoutDto>("There is nothing to pay.", "nothing_payable");

        var profile = await _store.ProfileAsync(payout.PartnerAccountId, ct);
        if (await BlockedReasonAsync(payout, profile, ct) is { } blocked) return Cp.Conflict<PartnerPayoutDto>(blocked, NoAgreementCode);

        var names = await _store.AccountNamesAsync([payout.PartnerAccountId], ct);
        var request = new ApprovalRequest
        {
            // Explicit Id: the chain instance below is keyed on it before the row is re-read (Postgres defaults are server-side).
            Id = Guid.NewGuid(),
            RequesterId = actorId,
            Type = ApprovalTypes.PartnerPayout,
            LeadId = Guid.Empty, // no deal: the payout is named by RecordType / RecordId
            Amount = payout.NetAmount,
            Reason = $"{payout.Number} - {names.GetValueOrDefault(payout.PartnerAccountId, "partner")}",
            RecordType = "partner_payout",
            RecordId = payout.Id,
        };
        _store.AddApprovalRequest(request);
        await _store.SaveChangesAsync(ct);

        var instance = await _chains.ResolveAndStartAsync(request, null, ct);
        if (instance is null)
        {
            // The org switched its default payout chain off and no other chain covers payouts: nobody could ever decide this.
            _store.RemoveApprovalRequest(request);
            await _store.SaveChangesAsync(ct);
            return Cp.Conflict<PartnerPayoutDto>("No one is set up to approve partner payouts. Ask an admin.", "no_approver");
        }

        payout.Status = ChannelPartnerVocab.PayoutStatus.Submitted;
        payout.SubmittedAt = DateTime.UtcNow;
        payout.ApprovalRequestId = request.Id;
        payout.UpdatedAt = DateTime.UtcNow;
        await _store.SaveChangesAsync(ct);
        return await DtoAsync(payout, ct);
    }

    /// <summary>Cancels a payout that has not been paid. Its entries are released (the items go) so they can join another payout; an open approval is closed.</summary>
    public async Task<CpResult<PartnerPayoutDto>> CancelAsync(RecordAccessContext ctx, Guid id, PartnerPayoutCancelInput input, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerPayoutDto>();
        var (payout, refusal) = await LoadAsync(ctx, id, ct);
        if (refusal is not null) return refusal;
        if (payout!.Status is ChannelPartnerVocab.PayoutStatus.Paid or ChannelPartnerVocab.PayoutStatus.Cancelled)
            return Cp.Conflict<PartnerPayoutDto>("This payout is already " + payout.Status + ".", "not_cancellable");
        if (string.IsNullOrWhiteSpace(input.Reason)) return Cp.Invalid<PartnerPayoutDto>("A reason is required to cancel a payout.", "reason_required");

        if (payout.ApprovalRequestId is Guid requestId) await _store.CloseApprovalAsync(requestId, $"Payout cancelled: {input.Reason.Trim()}", ct);
        _store.RemoveItems(payout.Items.ToList());
        payout.Status = ChannelPartnerVocab.PayoutStatus.Cancelled;
        payout.Note = input.Reason.Trim();
        payout.UpdatedAt = DateTime.UtcNow;
        await _store.SaveChangesAsync(ct);
        payout.Items.Clear();
        return await DtoAsync(payout, ct);
    }

    // ---- pay -----------------------------------------------------------------------------------------------

    /// <summary>
    /// Records that finance paid an APPROVED payout outside the CRM (Q8) and writes the ledger entry that settles it (negative, ex VAT, pointing at the payout). Re-checks
    /// the signed-agreement rule: the agreement could have been unlinked since approval.
    /// </summary>
    public async Task<CpResult<PartnerPayoutDto>> MarkPaidAsync(RecordAccessContext ctx, Guid id, PartnerPayoutMarkPaidInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerPayoutDto>();
        var (payout, refusal) = await LoadAsync(ctx, id, ct);
        if (refusal is not null) return refusal;
        if (payout!.Status != ChannelPartnerVocab.PayoutStatus.Approved)
            return Cp.Conflict<PartnerPayoutDto>("Only an approved payout can be marked paid.", "not_approved");
        var profile = await _store.ProfileAsync(payout.PartnerAccountId, ct);
        if (await BlockedReasonAsync(payout, profile, ct) is { } blocked) return Cp.Conflict<PartnerPayoutDto>(blocked, NoAgreementCode);
        if (input.ProofAttachmentId is Guid proof && !await _store.AttachmentExistsAsync(proof, ct))
            return Cp.Invalid<PartnerPayoutDto>("That proof file wasn't found.", "bad_proof_file");
        if (input.Method is { Length: > 40 } || input.Reference is { Length: > 200 })
            return Cp.Invalid<PartnerPayoutDto>("The method or reference is too long.", "bad_payment");

        var paidAt = (input.PaidAt ?? DateTime.UtcNow).ToUniversalTime();
        payout.Status = ChannelPartnerVocab.PayoutStatus.Paid;
        payout.PaidAt = paidAt;
        payout.PaidById = actorId;
        payout.Method = Clean(input.Method);
        payout.Reference = Clean(input.Reference);
        payout.ProofAttachmentId = input.ProofAttachmentId;
        payout.UpdatedAt = DateTime.UtcNow;
        _store.AddEntry(new PartnerLedgerEntry
        {
            Id = Guid.NewGuid(),
            PartnerAccountId = payout.PartnerAccountId,
            // The settling entry is in the payout's own direction, so a cost payout settles cost (and never a payable balance) and the other way round.
            Direction = payout.Direction,
            Kind = ChannelPartnerVocab.EntryKind.Payout,
            Amount = -payout.NetAmount,
            Currency = payout.Currency,
            PayoutId = payout.Id,
            SourceKey = $"payout:{payout.Id:N}",
            RuleKey = "payout",
            RuleScope = ChannelPartnerVocab.RuleScope.Plan,
            EarnedAt = paidAt,
            PayableOn = paidAt,
            Reason = $"Paid under {payout.Number}" + (payout.PartnerInvoiceNumber is null ? "" : $" (partner invoice {payout.PartnerInvoiceNumber})"),
            CreatedById = actorId,
        });
        await _store.SaveChangesAsync(ct);
        return await DtoAsync(payout, ct);
    }

    // ---- the bank CSV (Q8) ------------------------------------------------------------------------------------

    /// <summary>
    /// The bank file for APPROVED payouts: one row each - what to pay (the partner's invoice GROSS), to whom (account holder, bank, IBAN), under what reference. Needs a raw
    /// read of ID &amp; bank (the IBAN is in it). A payout with no bank details stops the export and is named - a bank file with a blank IBAN is worse than no file. The first
    /// export of a payout stamps ExportedAt.
    /// </summary>
    public async Task<CpResult<(string FileName, byte[] Content)>> ExportAsync(RecordAccessContext ctx, IReadOnlyCollection<Guid>? ids, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<(string, byte[])>();
        if (!Cp.CanReadBank(ctx)) return Cp.Forbidden<(string, byte[])>("Your role can't see partner bank details, so it can't export them.", "bank_details_hidden");

        List<PartnerPayout> payouts;
        if (ids is { Count: > 0 })
        {
            payouts = await _store.FindManyAsync(ids, ct);
            if (payouts.Count != ids.Distinct().Count()) return Cp.NotFound<(string, byte[])>(NoPayout);
            if (payouts.Any(p => p.Status != ChannelPartnerVocab.PayoutStatus.Approved))
                return Cp.Invalid<(string, byte[])>("Only approved payouts go in the bank file.", "not_approved");
        }
        else
        {
            // The listing is untracked; load the same payouts tracked, so stamping ExportedAt below is actually saved.
            var approvedIds = (await _store.ListAsync(null, ChannelPartnerVocab.PayoutStatus.Approved, ct)).Select(p => p.Id).ToList();
            payouts = await _store.FindManyAsync(approvedIds, ct);
        }

        var facts = await _partners.AccountFactsManyAsync(payouts.Select(p => p.PartnerAccountId).Distinct().ToList(), ct);
        payouts = payouts.Where(p => facts.TryGetValue(p.PartnerAccountId, out var f) && RecordAccess.CanView(ctx, f.OwnerId, f.TeamId)).ToList();
        if (payouts.Count == 0) return Cp.Invalid<(string, byte[])>("There are no approved payouts to export.", "nothing_to_export");

        var profiles = await _store.ProfilesAsync(payouts.Select(p => p.PartnerAccountId).Distinct().ToList(), ct);
        var missing = payouts.Where(p => !profiles.TryGetValue(p.PartnerAccountId, out var pr) || string.IsNullOrWhiteSpace(pr.PayoutIban) || string.IsNullOrWhiteSpace(pr.PayoutAccountHolder)).ToList();
        if (missing.Count > 0)
            return Cp.Invalid<(string, byte[])>($"These payouts have no bank details on the partner: {string.Join(", ", missing.Select(m => m.Number))}.", "missing_bank_details");

        var rows = new List<IEnumerable<string?>>
        {
            new[] { "Payout", "Partner", "Account holder", "Bank", "IBAN", "Currency", "Amount", "Partner invoice", "Invoice date", "Due date", "Reference" },
        };
        foreach (var p in payouts.OrderBy(p => p.Number))
        {
            var pr = profiles[p.PartnerAccountId];
            rows.Add(new[]
            {
                p.Number, facts[p.PartnerAccountId].Name, pr.PayoutAccountHolder, pr.PayoutBankName, pr.PayoutIban, p.Currency,
                p.GrossAmount.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture),
                p.PartnerInvoiceNumber, p.PartnerInvoiceDate?.ToString("yyyy-MM-dd"), p.DueDate?.ToString("yyyy-MM-dd"), p.Number,
            });
            p.ExportedAt ??= DateTime.UtcNow;
        }
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(($"partner-payouts-{DateTime.UtcNow:yyyyMMdd-HHmm}.csv", Encoding.UTF8.GetBytes(CsvUtil.ToCsvSafe(rows))));
    }
}

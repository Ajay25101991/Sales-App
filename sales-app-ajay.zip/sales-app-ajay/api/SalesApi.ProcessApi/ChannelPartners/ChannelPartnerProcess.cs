using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;
using SalesApi.SystemLayer.DocumentTemplates;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// Channel partners: who is a partner (an account plus a confidential <see cref="PartnerProfile"/>) and which partners sit on which deal
/// (<see cref="DealPartner"/>, many per deal with a role, at most one referrer, terms frozen when attributed).
///
/// REUSE, not parallel: a partner IS an account (identity, contacts, owner, team, documents all stay where they are); access follows the account's own
/// <see cref="RecordAccess"/>; the document partner (<see cref="Lead.PartnerAccountId"/>) is kept in step with the tri_party deal partner (written here before the
/// save so FieldAudit records it, and followed by <c>PartnerCapture</c> in the other direction); the partner types, tiers and defaults are org settings
/// (<see cref="OrgSettingsReader"/>), never literals. Authorization stays at the HTTP layer (partners.manage); the facts about the caller that decide what is MASKED
/// - their Partner commercials and ID &amp; bank levels - arrive in the <see cref="RecordAccessContext"/>.
/// </summary>
public sealed class ChannelPartnerProcess
{
    private readonly ChannelPartnerStore _store;
    private readonly PartnerLedgerStore _ledger;
    private readonly OrgSettingsReader _settings;

    private readonly PartnerPortalStore? _portal;
    private readonly ProcessLayer.People.PeopleProcess? _people;

    /// <param name="portal">Phase 4: with <paramref name="people"/>, terminating a partner switches off its portal users (owner 2026-10-20). Optional so callers that build this class without the portal are unchanged.</param>
    public ChannelPartnerProcess(
        ChannelPartnerStore store, PartnerLedgerStore ledger, OrgSettingsReader settings,
        PartnerPortalStore? portal = null, ProcessLayer.People.PeopleProcess? people = null)
    {
        _store = store;
        _ledger = ledger;
        _settings = settings;
        _portal = portal;
        _people = people;
    }

    private const int MaxText = 200;
    private static readonly System.Text.RegularExpressions.Regex KeyShape = new("^[a-z][a-z0-9_]{0,39}$");

    // ---- settings ------------------------------------------------------------------------------

    public Task<ChannelPartnerSettingsDto> GetSettingsAsync() => _settings.GetChannelPartnerSettingsAsync();

    public async Task<CpResult<ChannelPartnerSettingsDto>> SaveSettingsAsync(ChannelPartnerSettingsInput input)
    {
        var current = await _settings.GetChannelPartnerSettingsAsync();
        List<string>? Clean(List<string>? list, string what, out string? problem)
        {
            problem = null;
            if (list is null) return null;
            var cleaned = list.Select(s => (s ?? "").Trim().ToLowerInvariant()).Where(s => s.Length > 0).Distinct().ToList();
            if (cleaned.Count == 0) { problem = $"Keep at least one {what}."; return null; }
            if (cleaned.Any(s => !KeyShape.IsMatch(s))) { problem = $"A {what} is lowercase letters, digits and underscores, starting with a letter."; return null; }
            return cleaned;
        }
        var types = Clean(input.Types, "partner type", out var p1);
        if (p1 is not null) return Cp.Invalid<ChannelPartnerSettingsDto>(p1, "bad_types");
        var tiers = Clean(input.Tiers, "partner tier", out var p2);
        if (p2 is not null) return Cp.Invalid<ChannelPartnerSettingsDto>(p2, "bad_tiers");
        if (input.RepCredit is not null && Array.IndexOf(ChannelPartnerVocab.RepCredit.All, input.RepCredit) < 0)
            return Cp.Invalid<ChannelPartnerSettingsDto>("Rep credit is full or none.", "bad_rep_credit");

        if (input.AdjustmentApprovalLimit is <= 0m)
            return Cp.Invalid<ChannelPartnerSettingsDto>("The adjustment approval limit is above 0 (clear it to remove the limit).", "bad_limit");

        if (input.PrimeRatePercent is < 0m or > 100m)
            return Cp.Invalid<ChannelPartnerSettingsDto>("The prime rate is 0 to 100 percent a year (clear it to stop showing late-interest figures).", "bad_prime_rate");
        if (input.MaxChannelDepth is < 1 or > ChannelPartnerVocab.MaxChannelDepthLimit)
            return Cp.Invalid<ChannelPartnerSettingsDto>($"A distributor chain has 1 to {ChannelPartnerVocab.MaxChannelDepthLimit} levels.", "bad_depth");

        Dictionary<string, PartnerTypeRequirementDto>? requirements = null;
        if (input.TypeRequirements is { } rawRequirements)
        {
            try { requirements = PartnerRequirements.Normalise(rawRequirements); }
            catch (ArgumentException) { return Cp.Invalid<ChannelPartnerSettingsDto>("A partner type is listed twice.", "bad_requirements"); }
            if (PartnerRequirements.Problem(requirements, types ?? current.Types) is { } problem) return Cp.Invalid<ChannelPartnerSettingsDto>(problem, "bad_requirements");
            foreach (var rule in requirements.Values)
                if (rule.Defaults is { } d && d.TryGetValue(PartnerRequirementCatalogue.DefaultPlan, out var planValue) && Guid.TryParse(planValue.GetString(), out var planId)
                    && await _store.FindPlanAsync(planId) is not { ArchivedAt: null, IsSystem: false })
                    return Cp.Invalid<ChannelPartnerSettingsDto>("A default plan must be one of your commission plans.", "bad_plan");
        }

        var saved = new ChannelPartnerSettingsDto(
            types ?? current.Types, tiers ?? current.Tiers, input.RepCredit ?? current.RepCredit,
            input.PayoutsNeedSignedAgreementDefault ?? current.PayoutsNeedSignedAgreementDefault,
            input.ClearAdjustmentApprovalLimit ? null : input.AdjustmentApprovalLimit is { } lim ? PartnerPlanEngine.Money(lim) : current.AdjustmentApprovalLimit,
            input.MaxChannelDepth ?? current.MaxChannelDepth,
            input.ClearPrimeRate ? null : input.PrimeRatePercent ?? current.PrimeRatePercent,
            requirements ?? current.TypeRequirements, current.RequirementFields, current.DefaultFields);
        await _settings.SaveChannelPartnerSettingsAsync(saved);
        // F5: the org-wide rep-credit mode decides whose goal / leaderboard a partner-sourced deal counts for; the stored grains are re-derived.
        if (saved.RepCredit != current.RepCredit) await _store.ResyncDealStatsAsync();
        return Cp.Ok(saved);
    }

    // ---- profiles --------------------------------------------------------------------------------

    private PartnerProfileDto ToDto(
        PartnerProfile p, string accountName, string? planName, bool signed, ChannelPartnerSettingsDto settings, RecordAccessContext ctx)
    {
        var bank = Cp.CanReadBank(ctx);
        var terms = Cp.CanReadCommercials(ctx);   // the partner's own terms are Partner commercials, like the deal partner's resale / wholesale amounts
        return new PartnerProfileDto(
            p.Id, p.AccountId, accountName, p.Type, p.Status, p.Tier,
            p.DefaultPlanId, planName,
            p.AgreementEngagementLetterId, p.AgreementAttachmentId, signed,
            p.PayoutsNeedSignedAgreement, p.RepCredit, p.RepCredit ?? settings.RepCredit,
            p.VatRegistered, p.Trn, p.Territory, p.ExclusivityNote, p.OnboardedAt, p.TerminatedAt,
            bank ? new PartnerPayoutDetailsDto(p.PayoutAccountHolder, p.PayoutBankName, p.PayoutIban) : null, !bank,
            p.CreatedAt, p.UpdatedAt,
            WhiteLabelEnabled: p.WhiteLabelEnabled, WhiteLabelName: p.WhiteLabelName, WhiteLabelVariant: p.WhiteLabelVariant, LogoAttachmentId: p.LogoAttachmentId,
            ResalePrice: terms ? p.ResalePrice : null, WholesaleAmount: terms ? p.WholesaleAmount : null, WholesalePercent: terms ? p.WholesalePercent : null,
            ExtraEntityFee: terms ? p.ExtraEntityFee : null, ExtraEntitySharePercent: terms ? p.ExtraEntitySharePercent : null, PaymentTermsDays: terms ? p.PaymentTermsDays : null,
            MinimumCommitmentQuantity: terms ? p.MinimumCommitmentQuantity : null, MinimumCommitmentUnit: terms ? p.MinimumCommitmentUnit : null, TermsHidden: !terms,
            MouTerms: terms && p.MouTerms != "{}" ? PartnerMouCalculator.ParseTerms(p.MouTerms) : null);
    }

    /// <summary>
    /// THE completeness rule (D4-D7): the requirement keys this partner lacks under its type's rules, plus type_to_be_set. The profile DTO, the Active / new-deal enforcement and
    /// "Partners to complete" all call this - nothing else decides it. Looks the signed agreement / plan up only when the type requires them (<paramref name="signed"/>
    /// lets a list that already loaded every partner's signed state pass it in).
    /// </summary>
    internal async Task<List<string>> MissingAsync(PartnerProfile p, ChannelPartnerSettingsDto settings, bool? signed = null, CancellationToken ct = default)
    {
        var needsAgreement = PartnerRequirements.Requires(settings, p.Type, PartnerRequirementCatalogue.Agreement);
        var isSigned = !needsAgreement || (signed ?? (await _store.SignedAgreementAccountsAsync([p], ct)).Contains(p.AccountId));
        var needsPlan = PartnerRequirements.Requires(settings, p.Type, PartnerRequirementCatalogue.DefaultPlan);
        // "No plan" = no default plan AND no per-partner assignment in force (an assignment is a plan too).
        var hasPlan = !needsPlan || p.DefaultPlanId is not null || await _store.CurrentAssignmentAsync(p.AccountId, DateTime.UtcNow, ct) is not null;
        return PartnerRequirements.Missing(p, settings, isSigned, hasPlan);
    }

    /// <summary>
    /// What ENFORCEMENT acts on: <see cref="MissingAsync"/> without type_to_be_set. An unset type is listed in Partners to complete, but it is not a required FIELD - and a portal
    /// sign-up is approved (set Active) while its type is still unset, so blocking on it would block every approval.
    /// </summary>
    private async Task<List<string>> RequiredMissingAsync(PartnerProfile p, ChannelPartnerSettingsDto settings, CancellationToken ct) =>
        (await MissingAsync(p, settings, ct: ct)).Where(k => k != PartnerMissing.TypeToBeSet).ToList();

    /// <summary>Type changed from "to be set" (or a profile was created): fills the EMPTY fields from the type's defaults. Never overwrites a value already entered.</summary>
    private async Task ApplyTypeDefaultsAsync(PartnerProfile p, ChannelPartnerSettingsDto settings, CancellationToken ct)
    {
        PartnerRequirements.ApplyDefaults(p, settings);
        if (p.DefaultPlanId is null && PartnerRequirements.DefaultPlanId(settings, p.Type) is Guid planId
            && await _store.FindPlanAsync(planId, ct) is { ArchivedAt: null, IsSystem: false } && await _store.LatestVersionAsync(planId, ct) is not null)
            p.DefaultPlanId = planId;
    }

    private async Task<PartnerProfileDto> ToDtoAsync(PartnerProfile p, string accountName, RecordAccessContext ctx, CancellationToken ct)
    {
        var settings = await _settings.GetChannelPartnerSettingsAsync();
        var signed = (await _store.SignedAgreementAccountsAsync([p], ct)).Contains(p.AccountId);
        // A default plan's name can reveal its rate ("Referral 10%"), so it travels only with the commercials.
        // ... except for a plan the caller created themselves (owner 2026-11-06), so the add-partner form can show it.
        var planName = p.DefaultPlanId is Guid pid && (Cp.CanReadCommercials(ctx) || await _store.PlanCreatedByAsync(pid, ctx.UserId, ct)) ?(await _store.PlanNamesAsync([pid], ct)).GetValueOrDefault(pid) : null;
        var dto = ToDto(p, accountName, planName, signed, settings, ctx) with { Missing = await MissingAsync(p, settings, signed, ct) };
        var contactIds = ReadInternalContactIds(p.InternalContactIds);
        var names = contactIds.Count == 0 ? [] : await _store.ProfileNamesAsync(contactIds, ct);
        dto = dto with { InternalContacts = contactIds.Select(id => new PartnerInternalContactDto(id, names.GetValueOrDefault(id))).ToList() };
        return p.LogoAttachmentId is Guid logo ? dto with { LogoFilename = (await _store.LogoFileAsync(logo, p.AccountId, ct))?.Filename } : dto;
    }

    /// <summary>The CRM users who are "our contact for this partner" (a JSON list of profile ids on the profile). Tolerant: a malformed value reads as none.</summary>
    internal static List<Guid> ReadInternalContactIds(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return [];
        try { return System.Text.Json.JsonSerializer.Deserialize<List<Guid>>(json)?.Distinct().ToList() ?? []; }
        catch (System.Text.Json.JsonException) { return []; }
    }

    internal static string WriteInternalContactIds(IEnumerable<Guid> ids) => System.Text.Json.JsonSerializer.Serialize(ids.Distinct().ToList());

    /// <summary>The partners the caller can see (their account is in reach), newest name first-alphabetical. Aggregate-backed money columns, hidden below raw commercials.</summary>
    public async Task<List<PartnerListItemDto>> ListAsync(RecordAccessContext ctx, string? status, string? type, CancellationToken ct = default)
    {
        var profiles = await _store.ListProfilesAsync(status, type, ct);
        if (profiles.Count == 0) return [];
        var facts = await _store.AccountFactsManyAsync(profiles.Select(p => p.AccountId).ToList(), ct);
        var visible = profiles.Where(p => facts.TryGetValue(p.AccountId, out var f) && RecordAccess.CanView(ctx, f.OwnerId, f.TeamId)).ToList();
        var signed = await _store.SignedAgreementAccountsAsync(visible, ct);
        var commercials = Cp.CanReadCommercials(ctx);
        var totals = commercials ? await _ledger.StatsTotalsByPartnerAsync(ct) : [];
        return visible.Select(p =>
        {
            totals.TryGetValue(p.AccountId, out var t);
            return new PartnerListItemDto(
                p.AccountId, facts[p.AccountId].Name, p.Type, p.Status, p.Tier, signed.Contains(p.AccountId),
                commercials ? t.Accrued - t.Clawed : null, commercials ? t.Accrued - t.Clawed - t.Paid : null, commercials ? t.Paid : null);
        }).ToList();
    }

    public async Task<CpResult<PartnerProfileDto>> GetAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default)
    {
        var account = await _store.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<PartnerProfileDto>("Account not found");
        var profile = await _store.ReadProfileAsync(accountId, ct);
        if (profile is null) return Cp.NotFound<PartnerProfileDto>("This account is not a channel partner.");
        return Cp.Ok(await ToDtoAsync(profile, account.Name, ctx, ct));
    }

    /// <summary>The one-call payload of the account page's Partner tab: profile, balances (aggregate-backed), open decisions, deals, current assignment.</summary>
    public async Task<CpResult<PartnerOverviewDto>> OverviewAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default)
    {
        var got = await GetAsync(ctx, accountId, ct);
        if (!got.IsOk) return Cp.As<PartnerOverviewDto, PartnerProfileDto>(got);
        var commercials = Cp.CanReadCommercials(ctx);
        // "Open deals" = linked deals still in progress (not won, lost or after-the-win), each judged on its own playbook - not every active attribution.
        var openDeals = await _store.CountInProgressDealsAsync(await _store.ListDealsOfPartnerAsync(accountId, activeOnly: true, ct), ct);
        if (!commercials)
            return Cp.Ok(new PartnerOverviewDto(got.Value!, null, null, null, null, null, 0, openDeals, null, true));

        var totals = (await _ledger.StatsTotalsByPartnerAsync(ct)).GetValueOrDefault(accountId);
        // Payable only: this is "what we can pay the partner now". An SI's cost and an FSP's receivable have their own figures below and are never added in.
        var unsettled = (await _ledger.UnsettledEarningsAsync(accountId, null, ChannelPartnerVocab.Direction.Payable, ct)).Sum(e => e.Amount);
        var direction = await _ledger.StatsDirectionTotalsAsync(accountId, ct);
        // A reseller's "owed to us" is its unpaid invoice balance, shown beside two more separate figures (owner 2026-11-10). FSP/other types keep the ledger receivable.
        (decimal Wholesale, decimal Invoiced, decimal Owed)? reseller = got.Value!.Type == "reseller" ? await _ledger.ResellerFiguresAsync(accountId, ct) : null;
        var assignment = await _store.CurrentAssignmentAsync(accountId, DateTime.UtcNow, ct);
        PartnerPlanAssignmentDto? assignmentDto = null;
        if (assignment is not null)
        {
            var name = (await _store.PlanNamesAsync([assignment.PlanId], ct)).GetValueOrDefault(assignment.PlanId);
            assignmentDto = ToAssignmentDto(assignment, name);
        }
        return Cp.Ok(new PartnerOverviewDto(
            got.Value!, totals.Accrued, totals.Clawed, totals.Paid, totals.Accrued - totals.Clawed - totals.Paid, unsettled,
            await _ledger.PendingDecisionCountAsync(accountId, ct), openDeals, assignmentDto, false,
            direction.CostAccrued, direction.CostPaid, direction.CostAccrued - direction.CostPaid,
            direction.ReceivableBilled, direction.ReceivableRemitted, reseller is null ? direction.ReceivableBilled - direction.ReceivableRemitted : reseller.Value.Owed,
            reseller?.Wholesale, reseller?.Invoiced));
    }

    // internal, not public: a public Process surface may not name a System type (LayerBoundaryTests); PartnerPlanProcess shares it from the same assembly.
    internal static PartnerPlanAssignmentDto ToAssignmentDto(PartnerPlanAssignment a, string? planName) =>
        new(a.Id, a.PartnerAccountId, a.PlanId, planName, a.Percent, a.FlatAmount, a.Cap, a.ClawbackWindowDays, a.PaymentTermsDays,
            a.EffectiveFrom, a.EffectiveTo, a.Reason, a.CreatedById, a.CreatedAt);

    /// <summary>
    /// Makes an account a channel partner. Q17: whether payouts to this partner need a signed agreement is asked HERE and must be answered - it is not defaulted
    /// silently (the org setting only pre-fills the form).
    /// </summary>
    public async Task<CpResult<PartnerProfileDto>> CreateAsync(
        RecordAccessContext ctx, Guid accountId, PartnerProfileInput input, Guid actorId, CancellationToken ct = default)
    {
        var account = await _store.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<PartnerProfileDto>("Account not found");
        if (await _store.ReadProfileAsync(accountId, ct) is not null)
            return Cp.Conflict<PartnerProfileDto>("This account is already a channel partner.", "already_partner");
        // Q17: asked here. D6: a type that carries a default for it stands in for the answer (the org already made that choice for the type).
        var createSettings = await _settings.GetChannelPartnerSettingsAsync();
        var payoutsAnswer = input.PayoutsNeedSignedAgreement ?? PartnerRequirements.DefaultPayoutsNeedSigned(createSettings, (input.Type ?? "").Trim().ToLowerInvariant());
        if (payoutsAnswer is null)
            return Cp.Invalid<PartnerProfileDto>("Say whether payouts to this partner need a signed agreement on file.", "payouts_need_signed_agreement_required");
        input = input with { PayoutsNeedSignedAgreement = payoutsAnswer };

        var profile = new PartnerProfile
        {
            Id = Guid.NewGuid(),
            AccountId = accountId,
            Status = ChannelPartnerVocab.Status.Prospect,
            CreatedById = actorId,
        };
        var refusal = await ApplyAsync(profile, input, ctx, create: true, ct);
        if (refusal is not null) return Cp.As<PartnerProfileDto, PartnerProfileDto>(refusal);
        await ApplyTypeDefaultsAsync(profile, createSettings, ct);   // D6: a new partner of the type is pre-filled; what the caller entered stays
        if (profile.Status == ChannelPartnerVocab.Status.Active && await ActivationRefusalAsync(profile, createSettings, ct) is { } incomplete) return incomplete;
        _store.AddProfile(profile);
        await _store.SaveChangesAsync(ct);
        if (profile.RepCredit is not null) await _store.ResyncDealStatsAsync(ct);
        return Cp.Ok(await ToDtoAsync(profile, account.Name, ctx, ct));
    }

    public async Task<CpResult<PartnerProfileDto>> UpdateAsync(
        RecordAccessContext ctx, Guid accountId, PartnerProfileInput input, CancellationToken ct = default)
    {
        var account = await _store.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<PartnerProfileDto>("Account not found");
        var profile = await _store.FindProfileAsync(accountId, ct);
        if (profile is null) return Cp.NotFound<PartnerProfileDto>("This account is not a channel partner.");
        var creditBefore = profile.RepCredit;
        var statusBefore = profile.Status;
        var typeBefore = profile.Type;
        var refusal = await ApplyAsync(profile, input, ctx, create: false, ct);
        if (refusal is not null) return Cp.As<PartnerProfileDto, PartnerProfileDto>(refusal);
        var updateSettings = await _settings.GetChannelPartnerSettingsAsync();
        if (typeBefore == ChannelPartnerVocab.ToBeSetType && profile.Type != ChannelPartnerVocab.ToBeSetType) await ApplyTypeDefaultsAsync(profile, updateSettings, ct);   // D6
        // D5: becoming Active needs the type's required fields. A partner that is ALREADY Active is never demoted by a rule it now fails; it is listed in Partners to complete.
        if (profile.Status == ChannelPartnerVocab.Status.Active && statusBefore != ChannelPartnerVocab.Status.Active
            && await ActivationRefusalAsync(profile, updateSettings, ct) is { } incomplete) return incomplete;
        profile.UpdatedAt = DateTime.UtcNow;
        await _store.SaveChangesAsync(ct);
        // Owner 2026-10-20: terminating a partner switches off its existing portal users, through the existing deactivation path (role-version bump, so live tokens die).
        if (statusBefore != ChannelPartnerVocab.Status.Terminated && profile.Status == ChannelPartnerVocab.Status.Terminated && _portal is not null && _people is not null)
            foreach (var user in (await _portal.UsersAsync(accountId, ct)).Where(u => u.IsActive))
                await _people.ApplyUpdateAsync(user.Id, null, null, false, ctx.UserId, ct);
        // F5: a partner's own rep-credit override moves its sourced deals in or out of the reps' goal / leaderboard grains.
        if (creditBefore != profile.RepCredit) await _store.ResyncDealStatsAsync(ct);
        return Cp.Ok(await ToDtoAsync(profile, account.Name, ctx, ct));
    }

    private async Task<CpResult<PartnerProfileDto>?> ActivationRefusalAsync(PartnerProfile p, ChannelPartnerSettingsDto settings, CancellationToken ct)
    {
        var missing = await RequiredMissingAsync(p, settings, ct);
        return missing.Count == 0 ? null : Cp.Incomplete<PartnerProfileDto>("This partner is missing required details, so it can't be set to active yet.", missing);
    }

    // ---- partner terms: the "also update open deals?" prompt (D3) -------------------------------------------------------

    /// <summary>How many in-progress reseller deals of this partner a terms change would reach (each deal judged on its own playbook; won / lost / after-the-win never).</summary>
    public async Task<CpResult<PartnerTermsOpenDealsDto>> TermsOpenDealsAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default)
    {
        var account = await _store.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<PartnerTermsOpenDealsDto>("Account not found");
        if (await _store.ReadProfileAsync(accountId, ct) is null) return Cp.NotFound<PartnerTermsOpenDealsDto>("This account is not a channel partner.");
        return Cp.Ok(new PartnerTermsOpenDealsDto((await _store.InProgressResellerDealPartnersAsync(accountId, ct)).Count));
    }

    /// <summary>
    /// Rewrites resale price and wholesale amount on exactly the in-progress reseller deals from the partner's CURRENT terms (the same figures a new deal is pre-filled with). A
    /// term the partner has not set is left alone on the deal rather than erased. Needs a Full Partner commercials write, like editing the terms.
    /// </summary>
    public async Task<CpResult<PartnerTermsAppliedDto>> ApplyTermsToOpenDealsAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx))
            return Cp.Invalid<PartnerTermsAppliedDto>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);
        var account = await _store.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<PartnerTermsAppliedDto>("Account not found");
        var profile = await _store.ReadProfileAsync(accountId, ct);
        if (profile is null) return Cp.NotFound<PartnerTermsAppliedDto>("This account is not a channel partner.");
        var (resale, wholesale) = PartnerRequirements.Terms(profile);
        if (resale is null && wholesale is null) return Cp.Ok(new PartnerTermsAppliedDto(0));
        var rows = await _store.InProgressResellerDealPartnersAsync(accountId, ct);
        foreach (var dp in rows)
        {
            if (resale is not null) dp.ResalePrice = resale;
            if (wholesale is not null) dp.WholesaleAmount = wholesale;
            dp.UpdatedAt = DateTime.UtcNow;
        }
        if (rows.Count > 0) await _store.SaveChangesAsync(ct);
        return Cp.Ok(new PartnerTermsAppliedDto(rows.Count));
    }

    /// <summary>Removes the profile. Refused once the partner has deal partners or any money history - those are records, not drafts.</summary>
    public async Task<CpResult<bool>> DeleteAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default)
    {
        var account = await _store.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<bool>("Account not found");
        var profile = await _store.FindProfileAsync(accountId, ct);
        if (profile is null) return Cp.NotFound<bool>("This account is not a channel partner.");
        if ((await _store.ListDealsOfPartnerAsync(accountId, activeOnly: false, ct)).Count > 0
            || await _ledger.HasAnyEntryAsync(accountId, ct))   // any direction: a cost or receivable entry is money history too
            return Cp.Conflict<bool>("This partner has deals or money history, so it can't be removed. Set it to terminated instead.", "partner_in_use");
        _store.RemoveProfile(profile);
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(true);
    }

    private async Task<CpResult<PartnerProfileDto>?> ApplyAsync(PartnerProfile p, PartnerProfileInput i, RecordAccessContext ctx, bool create, CancellationToken ct)
    {
        CpResult<PartnerProfileDto> Bad(string msg, string? code = null) => Cp.Invalid<PartnerProfileDto>(msg, code);
        var settings = await _settings.GetChannelPartnerSettingsAsync();

        if (create || i.Type is not null)
        {
            var type = (i.Type ?? "").Trim().ToLowerInvariant();
            if (type.Length == 0) return Bad("Pick the partner type.", "type_required");
            if (!settings.Types.Contains(type)) return Bad("That partner type isn't in your organization's list.", "bad_type");
            p.Type = type;
        }
        if (i.Status is not null)
        {
            if (Array.IndexOf(ChannelPartnerVocab.Status.All, i.Status) < 0) return Bad("Status is prospect, active, suspended or terminated.", "bad_status");
            if (i.Status != p.Status)
            {
                if (i.Status == ChannelPartnerVocab.Status.Active) p.OnboardedAt ??= DateTime.UtcNow;
                if (i.Status == ChannelPartnerVocab.Status.Terminated) p.TerminatedAt ??= i.TerminatedAt ?? DateTime.UtcNow;
                else p.TerminatedAt = null;
                p.Status = i.Status;
            }
        }
        if (i.Tier is not null)
        {
            var tier = i.Tier.Trim().ToLowerInvariant();
            if (tier.Length == 0) p.Tier = null;
            else if (!settings.Tiers.Contains(tier)) return Bad("That tier isn't in your organization's list.", "bad_tier");
            else p.Tier = tier;
        }
        if (i.OnboardedAt is not null) p.OnboardedAt = i.OnboardedAt;
        if (i.TerminatedAt is not null && p.Status == ChannelPartnerVocab.Status.Terminated) p.TerminatedAt = i.TerminatedAt;

        if (i.ClearDefaultPlan) p.DefaultPlanId = null;
        else if (i.DefaultPlanId is Guid planId)
        {
            // Owner 2026-11-06: a caller without Partner commercials may still default the partner to a plan they created themselves.
            if (!Cp.CanReadCommercials(ctx) && !await _store.PlanCreatedByAsync(planId, ctx.UserId, ct))
                return Bad(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);
            var plan = await _store.FindPlanAsync(planId, ct);
            if (plan is null || plan.ArchivedAt != null || plan.IsSystem) return Bad("Pick one of your commission plans.", "bad_plan");
            if (await _store.LatestVersionAsync(planId, ct) is null) return Bad("That plan has no published version yet. Publish it first.", "plan_not_published");
            p.DefaultPlanId = planId;
        }

        if (i.ClearAgreement) { p.AgreementEngagementLetterId = null; p.AgreementAttachmentId = null; }
        if (i.AgreementEngagementLetterId is Guid letter)
        {
            if (!await _store.LetterBelongsToAsync(letter, p.AccountId, ct)) return Bad("That agreement isn't for this partner.", "bad_agreement");
            p.AgreementEngagementLetterId = letter;
        }
        if (i.AgreementAttachmentId is Guid file)
        {
            if (!await _store.AccountFileAsync(file, p.AccountId, ct)) return Bad("That file isn't one of this partner account's files.", "bad_agreement");
            p.AgreementAttachmentId = file;
        }

        if (i.PayoutsNeedSignedAgreement is bool needs) p.PayoutsNeedSignedAgreement = needs;
        if (i.ClearRepCredit) p.RepCredit = null;
        else if (i.RepCredit is not null)
        {
            if (Array.IndexOf(ChannelPartnerVocab.RepCredit.All, i.RepCredit) < 0) return Bad("Rep credit is full or none.", "bad_rep_credit");
            p.RepCredit = i.RepCredit;
        }

        // Bulk upload: "our contact for this partner". A list replaces; each must be an active CRM user of this organization.
        if (i.InternalContactIds is { } contacts)
        {
            var wanted = contacts.Distinct().ToList();
            var live = await _store.ActiveStaffNamesAsync(wanted, ct);
            if (wanted.Any(id => !live.ContainsKey(id))) return Bad("Our contact for a partner must be an active user of this organization.", "bad_internal_contact");
            p.InternalContactIds = WriteInternalContactIds(wanted);
        }

        if (i.VatRegistered is bool vat) p.VatRegistered = vat;
        if (i.Trn is not null) { var trn = i.Trn.Trim(); if (trn.Length > 40) return Bad("The TRN is at most 40 characters."); p.Trn = trn.Length == 0 ? null : trn; }
        if (i.Territory is not null) { var t = i.Territory.Trim(); if (t.Length > MaxText) return Bad($"Territory is at most {MaxText} characters."); p.Territory = t.Length == 0 ? null : t; }
        if (i.ExclusivityNote is not null) { var t = i.ExclusivityNote.Trim(); if (t.Length > 1000) return Bad("The exclusivity note is at most 1000 characters."); p.ExclusivityNote = t.Length == 0 ? null : t; }

        // Partner terms (D1/D2): Partner commercials, so a Full write. Null = leave; a Clear flag clears (the precedent of ClearDefaultPlan / ClearRepCredit). An amount and a percent
        // are one choice: sending both is refused, setting one clears the other.
        if (i.ResalePrice != null || i.WholesaleAmount != null || i.WholesalePercent != null || i.ExtraEntityFee != null || i.ExtraEntitySharePercent != null
            || i.PaymentTermsDays != null || i.MinimumCommitmentQuantity != null || i.MinimumCommitmentUnit != null
            || i.ClearResalePrice || i.ClearWholesaleAmount || i.ClearWholesalePercent || i.ClearExtraEntityFee || i.ClearExtraEntitySharePercent
            || i.ClearPaymentTermsDays || i.ClearMinimumCommitmentQuantity || i.ClearMinimumCommitmentUnit)
        {
            if (!Cp.CanWriteCommercials(ctx)) return Bad(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);
            if (i.WholesaleAmount != null && i.WholesalePercent != null)
                return Bad("Wholesale is an amount or a percent of the resale price, not both.", PartnerRequirements.WholesaleOneWayCode);
            if (i.ResalePrice is < 0m || i.WholesaleAmount is < 0m || i.ExtraEntityFee is < 0m || i.MinimumCommitmentQuantity is < 0m)
                return Bad("Prices, fees and the minimum commitment cannot be negative.", "bad_term");
            if (i.WholesalePercent is < 0m or > 100m || i.ExtraEntitySharePercent is < 0m or > 100m) return Bad("A percent is 0 to 100.", "bad_term");
            if (i.PaymentTermsDays is < 0 or > MaxDays) return Bad($"Payment terms are 0 to {MaxDays} days.", "bad_term");
            if (i.MinimumCommitmentUnit is { } unit && unit.Trim().Length > 100) return Bad("The commitment unit is at most 100 characters.", "bad_term");

            if (i.ClearResalePrice) p.ResalePrice = null;
            if (i.ClearWholesaleAmount) p.WholesaleAmount = null;
            if (i.ClearWholesalePercent) p.WholesalePercent = null;
            if (i.ClearExtraEntityFee) p.ExtraEntityFee = null;
            if (i.ClearExtraEntitySharePercent) p.ExtraEntitySharePercent = null;
            if (i.ClearPaymentTermsDays) p.PaymentTermsDays = null;
            if (i.ClearMinimumCommitmentQuantity) p.MinimumCommitmentQuantity = null;
            if (i.ClearMinimumCommitmentUnit) p.MinimumCommitmentUnit = null;

            if (i.ResalePrice is { } resale) p.ResalePrice = PartnerPlanEngine.Money(resale);
            if (i.WholesaleAmount is { } amount) { p.WholesaleAmount = PartnerPlanEngine.Money(amount); p.WholesalePercent = null; }
            if (i.WholesalePercent is { } percent) { p.WholesalePercent = PartnerPlanEngine.Money(percent); p.WholesaleAmount = null; }
            if (i.ExtraEntityFee is { } fee) p.ExtraEntityFee = PartnerPlanEngine.Money(fee);
            if (i.ExtraEntitySharePercent is { } share) p.ExtraEntitySharePercent = PartnerPlanEngine.Money(share);
            if (i.PaymentTermsDays is { } days) p.PaymentTermsDays = days;
            if (i.MinimumCommitmentQuantity is { } qty) p.MinimumCommitmentQuantity = PartnerPlanEngine.Money(qty);
            if (i.MinimumCommitmentUnit is { } unitText) p.MinimumCommitmentUnit = Trimmed(unitText, 100);
        }

        // MoU net-margin terms (owner 2026-11-12): Partner commercials, a Full write. A given object replaces the stored terms after the plain-words check.
        if (i.MouTerms is not null || i.ClearMouTerms)
        {
            if (!Cp.CanWriteCommercials(ctx)) return Bad(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);
            if (i.MouTerms is { } mou)
            {
                if (PartnerMouCalculator.Validate(mou) is { } mouProblem) return Bad(mouProblem, "bad_mou_terms");
                p.MouTerms = PartnerMouCalculator.SerializeTerms(mou with { Currency = mou.Currency?.Trim().ToUpperInvariant() });
            }
            else p.MouTerms = "{}";
            p.MouTermsUpdatedAt = DateTime.UtcNow;
            p.MouTermsUpdatedById = ctx.UserId;
        }

        // Payout bank details are the ID & bank category: writing them needs Full on it (a view-only role may read, not change).
        if (i.PayoutAccountHolder is not null || i.PayoutBankName is not null || i.PayoutIban is not null)
        {
            if (!Cp.CanWriteBank(ctx)) return Bad(Cp.ReadOnlyMessage(SensitiveCategories.IdBank), SensitiveWriteGuard.Code);
            if (i.PayoutAccountHolder is not null) p.PayoutAccountHolder = Trimmed(i.PayoutAccountHolder, MaxText);
            if (i.PayoutBankName is not null) p.PayoutBankName = Trimmed(i.PayoutBankName, MaxText);
            if (i.PayoutIban is not null) p.PayoutIban = Trimmed(i.PayoutIban, 50)?.Replace(" ", "").ToUpperInvariant();
        }

        // Phase 4 white-label (documents only; not money, so no commercial category): the partner's name, template variant and logo on its deals' proposals / agreements.
        if (i.WhiteLabelName is not null) p.WhiteLabelName = Trimmed(i.WhiteLabelName, MaxText);
        if (i.WhiteLabelVariant is not null)
            p.WhiteLabelVariant = Trimmed(DocumentTemplateStore.NormaliseVariant(i.WhiteLabelVariant) ?? "", DocumentTemplateStore.MaxVariantLength);
        if (i.ClearLogo) p.LogoAttachmentId = null;
        else if (i.LogoAttachmentId is Guid logoId)
        {
            var logoFile = await _store.LogoFileAsync(logoId, p.AccountId, ct);
            if (logoFile is null) return Bad("That logo isn't one of this partner account's files.", "bad_logo");
            var type = (logoFile.Value.MimeType ?? "").ToLowerInvariant();
            var ext = Path.GetExtension(logoFile.Value.Filename).ToLowerInvariant();
            if (!(type is "image/png" or "image/jpeg" || (type.Length == 0 || type == "application/octet-stream") && ext is ".png" or ".jpg" or ".jpeg"))
                return Bad("The logo must be a PNG or a JPEG image.", "bad_logo");
            if (logoFile.Value.SizeBytes > PartnerWhiteLabelStore.MaxLogoBytes) return Bad("The logo is over 2 MB. Choose a smaller file.", "bad_logo");
            p.LogoAttachmentId = logoId;
        }
        if (i.WhiteLabelEnabled is bool whiteLabel) p.WhiteLabelEnabled = whiteLabel;
        if (p.WhiteLabelEnabled && string.IsNullOrWhiteSpace(p.WhiteLabelVariant))
            return Bad("White-label needs the name of the template variant that carries this partner's branding (the proposal / agreement templates are uploaded under that name).", "white_label_variant_required");
        return null;
    }

    private static string? Trimmed(string v, int max)
    {
        var t = v.Trim();
        if (t.Length == 0) return null;
        return t.Length > max ? t[..max] : t;
    }

    // ---- deal partners ------------------------------------------------------------------------------

    private async Task<CpResult<QuickLead>> VisibleLeadAsync(RecordAccessContext ctx, Guid leadId, CancellationToken ct)
    {
        var lead = await _store.LeadFactsAsync(leadId, ct);
        // Not visible reads exactly like not found: a caller cannot probe for deals outside their reach.
        if (lead is null || !RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId)) return Cp.NotFound<QuickLead>("Deal not found");
        return Cp.Ok(new QuickLead(lead));
    }

    private sealed record QuickLead(ChannelPartnerStore.LeadFacts Facts);

    public async Task<CpResult<List<DealPartnerDto>>> ListDealPartnersAsync(RecordAccessContext ctx, Guid leadId, bool includeEnded, CancellationToken ct = default)
    {
        var lead = await VisibleLeadAsync(ctx, leadId, ct);
        if (!lead.IsOk) return Cp.As<List<DealPartnerDto>, QuickLead>(lead);
        var rows = await _store.ListDealPartnersAsync(leadId, includeEnded, ct);
        return Cp.Ok(await ToDtosAsync(rows, ctx, ct));
    }

    // internal, not private: the registrations queue (PartnerRegistrationProcess) lists the SAME deal-partner shape, so one shaper serves both (no parallel DTO assembly).
    internal async Task<List<DealPartnerDto>> ToDtosAsync(List<DealPartner> rows, RecordAccessContext ctx, CancellationToken ct)
    {
        if (rows.Count == 0) return [];
        var commercials = Cp.CanReadCommercials(ctx);
        var reach = Cp.CanReachCommercials(ctx);
        var ids = rows.Select(r => r.Id).ToList();
        // PAYABLE money only (the store filters Direction); an SI's cost and an FSP's receivable arrive as their own figures below.
        var ledger = commercials ? await _store.LedgerByDealPartnerAsync(ids, ct) : [];
        var settled = commercials ? await _store.EarnedAndPaidByDealPartnerAsync(ids, ct) : [];
        var costs = commercials ? await _store.CostByDealPartnerAsync(ids, ct) : [];
        var conflicts = commercials ? await _store.OpenConflictCountsAsync(ids, ct) : [];
        var fspFigures = commercials ? await _store.FspFiguresAsync(rows, ct) : [];
        var ourRevenue = commercials ? await _store.ResellerOurRevenueAsync(rows, ct) : [];
        var people = reach ? await _store.ProfileNamesAsync(rows.Where(r => r.RegisteredById != null).Select(r => r.RegisteredById!.Value).Distinct().ToList(), ct) : [];

        // The matched deals behind a pipeline flag: every deal the CALLER may see is listed; the rest are only counted ("a deal may already exist - ask your manager").
        var matchIds = rows.Where(r => r.PipelineStatus != null).SelectMany(r => PartnerRegistrations.ReadMatchedLeadIds(r.PipelineMatchLeadIds)).Distinct().ToList();
        var briefs = (await _store.LeadBriefsAsync(matchIds, ct)).ToDictionary(b => b.Id);
        var billingNames = commercials
            ? await _store.LeadNamesAsync(rows.Where(r => r.BillingLeadId != null).Select(r => r.BillingLeadId!.Value).Distinct().ToList(), ct)
            : [];

        return rows.Select(d =>
        {
            ledger.TryGetValue(d.Id, out var money);
            settled.TryGetValue(d.Id, out var sums);
            costs.TryGetValue(d.Id, out var cost);
            PartnerRuleSummaryDto? rule = null;
            var hasTerms = false;
            var direction = ChannelPartnerVocab.Direction.Payable;
            string? siBilling = null;
            if (d.PlanVersion is not null)
            {
                var content = PartnerPlanEngine.Read(d.PlanVersion.Content);
                var r = PartnerPlanEngine.Effective(content,
                    d.OverridePercent, d.OverrideFlatAmount, d.OverrideCap, d.OverrideClawbackWindowDays, d.OverridePaymentTermsDays);
                direction = r.Direction;
                // An SI's or an FSP's plan has no rate, but it IS terms: the card says "has terms" for any direction a plan was really chosen.
                hasTerms = r.HasTerms || (d.PlanVersion.Plan?.IsSystem != true && r.Direction != ChannelPartnerVocab.Direction.Payable);
                siBilling = commercials ? content.SiBilling : null;
                if (commercials) rule = r.Summary();
            }

            // REGISTRATION is a record. Raw readers get all of it; masked readers its status only; hidden readers only the fact that the client is protected.
            DealPartnerRegistrationDto? registration = null;
            if (d.RegistrationStatus != ChannelPartnerVocab.Registration.None && reach)
                registration = commercials
                    ? new DealPartnerRegistrationDto(d.RegistrationStatus, d.RegisteredOn, d.RegisteredById,
                        d.RegisteredById is Guid rb ? people.GetValueOrDefault(rb) : null, d.RegistrationNotes, d.RegistrationDecidedAt, d.RegistrationDecidedById)
                    : new DealPartnerRegistrationDto(d.RegistrationStatus, null, null, null, null, null, null);

            // The pipeline flag is NOT commercial: the deal owner must see it to decide it.
            DealPartnerPipelineFlagDto? flag = null;
            if (d.PipelineStatus is not null)
            {
                var matched = PartnerRegistrations.ReadMatchedLeadIds(d.PipelineMatchLeadIds);
                var visible = matched.Where(briefs.ContainsKey).Select(id => briefs[id]).Where(b => RecordAccess.CanView(ctx, b.OwnerId, b.TeamId)).ToList();
                flag = new DealPartnerPipelineFlagDto(
                    d.PipelineStatus,
                    visible.Select(b => new OpenDealDto(b.Id, b.Name, b.StageLabel, b.OwnerName, b.Company)).ToList(),
                    visible.Count < matched.Count, d.PipelineDecisionReason, d.PipelineDecidedAt, d.PipelineDecidedById);
            }

            return new DealPartnerDto(
                d.Id, d.LeadId, d.Lead?.Name, d.PartnerAccountId, d.PartnerAccount?.Name ?? "", d.Role, d.Origin,
                d.PlanVersionId, commercials ? d.PlanVersion?.Plan?.Name : null, commercials ? d.PlanVersion?.Version : null,
                d.Legacy, hasTerms, d.RuleScope, commercials ? d.OverrideReason : null,
                rule, d.StartedAt, d.EndedAt, d.EndReason,
                commercials ? money.Accrued : null, commercials ? money.Base : null,
                commercials ? sums.Paid : null, commercials ? sums.Earned - sums.Paid : null,
                direction, registration, ChannelPartnerVocab.Registration.Protects(d.RegistrationStatus), flag,
                commercials ? conflicts.GetValueOrDefault(d.Id) : 0,
                d.BillsEndClient, commercials ? d.BillingLeadId : null, d.BillingLeadId is Guid bl ? billingNames.GetValueOrDefault(bl) : null,
                siBilling, commercials ? cost.Cost : null, commercials ? cost.Paid : null,
                fspFigures.TryGetValue(d.Id, out var fsp) ? fsp.Price : (decimal?)null,
                fspFigures.TryGetValue(d.Id, out var fsp2) && fsp2.Billed > 0m ? fsp2.Billed : (decimal?)null,
                fspFigures.TryGetValue(d.Id, out var fsp3) && fsp3.Billed > 0m ? PartnerReceivables.FspShareOf(fsp3.Price, fsp3.Billed) : (decimal?)null,
                commercials ? d.ResalePrice : null, commercials ? d.WholesaleAmount : null, ourRevenue.GetValueOrDefault(d.Id), d.Lead?.WonAt);
        }).ToList();
    }

    private const int MaxDays = PartnerPlanEngine.MaxDays;

    /// <summary>The plan direction a role needs: an integrator earns a COST, an FSP owes us a receivable, every other role earns a share we pay. Shared with the retrospective "attach a plan" check.</summary>
    internal static string WantedDirection(string role) => role switch
    {
        ChannelPartnerVocab.Role.Integrator => ChannelPartnerVocab.Direction.Cost,
        ChannelPartnerVocab.Role.Fsp => ChannelPartnerVocab.Direction.Receivable,
        _ => ChannelPartnerVocab.Direction.Payable,
    };

    /// <summary>
    /// The refusal for a partner pick, or null when the account may be attributed in <paramref name="role"/>: it is in this organisation, it is a channel partner (has a
    /// profile) and its status allows NEW attributions. The document partner of a tri-party agreement may be any account (the existing pick). ONE check, shared by
    /// <see cref="AttributeAsync"/> and the lead form's "Partner" field, so the two cannot drift.
    /// </summary>
    private async Task<CpResult<T>?> PartnerRefusalAsync<T>(Guid partnerId, string role, CancellationToken ct, bool enforceComplete = true)
    {
        var account = await _store.AccountFactsAsync(partnerId, ct);
        if (account is null) return Cp.Invalid<T>("That partner account isn't in this organization.", "bad_partner");
        var profile = await _store.ReadProfileAsync(partnerId, ct);
        if (profile is null && role != ChannelPartnerVocab.Role.TriParty)
            return Cp.Invalid<T>("That account isn't a channel partner yet. Make it one first.", "not_a_partner");
        if (profile is not null && !ChannelPartnerVocab.Status.CanAttribute(profile.Status))
            return Cp.Conflict<T>($"This partner is {profile.Status}, so it can't be attributed to new deals.", "partner_not_attributable");
        // D5: a partner still missing what its type requires cannot be picked on a NEW deal (an existing attribution is untouched).
        if (enforceComplete && profile is not null
            && await RequiredMissingAsync(profile, await _settings.GetChannelPartnerSettingsAsync(), ct) is { Count: > 0 } missing)
            return Cp.Incomplete<T>("This partner is missing required details, so it can't be attributed to new deals.", missing);
        return null;
    }

    /// <summary>
    /// The lead form's "Partner" picker: the org's partner accounts the form could accept, id and name only. The same rule as <see cref="CheckPickableAsync"/> (a profile and
    /// a status that allows NEW attributions), so the list never offers a pick the server will refuse. No access filter beyond that rule: the pick does not read the account.
    /// </summary>
    public async Task<List<PartnerPickDto>> PickerAsync(CancellationToken ct = default) =>
        (await _store.PickerRowsAsync(ct)).Where(r => ChannelPartnerVocab.Status.CanAttribute(r.Status)).Select(r => new PartnerPickDto(r.AccountId, r.Name, r.Type)).ToList();

    /// <summary>The lead form's "Partner" field, validation half: may this account be picked as a deal partner (any of the three roles)? Reads only.</summary>
    public async Task<CpResult<bool>> CheckPickableAsync(Guid partnerId, CancellationToken ct = default) =>
        await PartnerRefusalAsync<bool>(partnerId, ChannelPartnerVocab.Role.Referrer, ct) ?? Cp.Ok(true);

    /// <summary>
    /// The lead form's "Partner" field, write half for the sourced roles (referrer, reseller): makes <paramref name="partnerId"/> the deal's sourced partner in
    /// <paramref name="role"/> through <see cref="AttributeAsync"/> whole (origin sourced, the partner's own plan else the no-terms plan, terms frozen, pipeline flag, claim
    /// conflicts). Ok(false) = already the active partner in that role, nothing written (so an edit never touches a resale price, wholesale amount or term already on the row).
    /// A deal has at most one of these: a DIFFERENT active partner in the role refuses (referrer_exists / reseller_exists), and so does the OTHER role being active
    /// (deal_has_referrer / deal_has_reseller) - changing either is "end the attribution on the Partners screen, then attribute". A reseller pick is only for a
    /// reseller-type partner (not_a_reseller). A reseller whose own default plan does not fit the role falls back to the no-terms plan instead of refusing.
    /// </summary>
    public async Task<CpResult<bool>> EnsureSourcedPartnerAsync(RecordAccessContext ctx, Guid leadId, Guid partnerId, string role, Guid actorId, CancellationToken ct = default)
    {
        var other = role == ChannelPartnerVocab.Role.Reseller ? ChannelPartnerVocab.Role.Referrer : ChannelPartnerVocab.Role.Reseller;
        if (role == ChannelPartnerVocab.Role.Reseller && !ChannelPartnerVocab.IsResellerType((await _store.ReadProfileAsync(partnerId, ct))?.Type))
            return Cp.Invalid<bool>("Only a reseller partner can be set as the deal's reseller.", "not_a_reseller");
        if (await _store.ActiveOfRoleAsync(leadId, role, ct) is { } active)
            return active.PartnerAccountId == partnerId
                ? Cp.Ok(false)
                : Cp.Conflict<bool>($"This deal already has a {role}. A deal has at most one. End that attribution on the Partners screen to change it.", $"{role}_exists");
        if (await _store.ActiveOfRoleAsync(leadId, other, ct) is not null)
            return Cp.Conflict<bool>($"This deal already has a {other}. End that attribution on the Partners screen before setting a {role}.", $"deal_has_{other}");
        var noTerms = false;
        if (role == ChannelPartnerVocab.Role.Reseller)
        {
            var resolved = await _store.ResolveAttributionAsync(partnerId, null, ct);
            var version = resolved is null ? null : await _store.PlanVersionAsync(resolved.PlanVersionId, ct);
            noTerms = version is not null && version.Plan?.IsSystem != true && PartnerPlanEngine.Read(version.Content).Direction != WantedDirection(role);
        }
        var added = await AttributeAsync(ctx, leadId,
            new DealPartnerInput(partnerId, role, ChannelPartnerVocab.Origin.Sourced, null, null, null, null, null, null, null), actorId, ct, noTerms: noTerms);
        return added.IsOk ? Cp.Ok(true) : Cp.As<bool, DealPartnerDto>(added);
    }

    /// <summary>Attaches a partner to a deal with a role and FROZEN terms (the plan version, any override, the collected base so far).</summary>
    /// <param name="noTerms">Bulk upload: attribute on the "legacy, no terms" plan whatever the partner's default plan or assignment is (earns nothing until terms are attached).</param>
    /// <param name="historic">Bulk upload: this records who ALREADY referred an existing client, so the "client already in the pipeline" flag (which asks the deal owner whether a NEW referral is welcome) is not raised.</param>
    public async Task<CpResult<DealPartnerDto>> AttributeAsync(
        RecordAccessContext ctx, Guid leadId, DealPartnerInput input, Guid actorId, CancellationToken ct = default,
        bool noTerms = false, bool historic = false)
    {
        var lead = await VisibleLeadAsync(ctx, leadId, ct);
        if (!lead.IsOk) return Cp.As<DealPartnerDto, QuickLead>(lead);
        if (input.PartnerAccountId is not Guid partnerId) return Cp.Invalid<DealPartnerDto>("Pick the partner.", "partner_required");
        if (!ChannelPartnerVocab.Role.IsValid(input.Role)) return Cp.Invalid<DealPartnerDto>("Pick the partner's role on this deal.", "bad_role");
        var role = input.Role!;
        var origin = input.Origin ?? (role is ChannelPartnerVocab.Role.Referrer or ChannelPartnerVocab.Role.Affiliate
            ? ChannelPartnerVocab.Origin.Sourced : ChannelPartnerVocab.Origin.Assigned);
        if (Array.IndexOf(ChannelPartnerVocab.Origin.All, origin) < 0) return Cp.Invalid<DealPartnerDto>("Origin is sourced or assigned.", "bad_origin");

        // The bulk upload records who ALREADY referred an existing client (noTerms / historic), so the completeness check does not hold it back.
        if (await PartnerRefusalAsync<DealPartnerDto>(partnerId, role, ct, enforceComplete: !noTerms && !historic) is { } partnerRefusal) return partnerRefusal;

        var overridesGiven = input.OverridePercent is not null || input.OverrideFlatAmount is not null || input.OverrideCap is not null
                             || input.OverrideClawbackWindowDays is not null || input.OverridePaymentTermsDays is not null;
        var bad = ValidateOverrides(input.OverridePercent, input.OverrideFlatAmount, input.OverrideCap, input.OverrideClawbackWindowDays, input.OverridePaymentTermsDays);
        if (bad is not null) return Cp.Invalid<DealPartnerDto>(bad, "bad_override");
        if (overridesGiven && string.IsNullOrWhiteSpace(input.OverrideReason))
            return Cp.Invalid<DealPartnerDto>("A reason is required when this deal's terms differ from the plan.", "override_reason_required");
        if ((overridesGiven || input.PlanId is not null) && !Cp.CanWriteCommercials(ctx))
            return Cp.Invalid<DealPartnerDto>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);

        if (role == ChannelPartnerVocab.Role.Referrer && await _store.ActiveOfRoleAsync(leadId, role, ct) is { } existingReferrer
            && existingReferrer.PartnerAccountId != partnerId)
            return Cp.Conflict<DealPartnerDto>("This deal already has a referrer. A deal has at most one.", "referrer_exists");

        var existing = await _store.FindDealPartnerAsync(leadId, partnerId, role, ct);
        if (existing is { EndedAt: null }) return Cp.Conflict<DealPartnerDto>("That partner is already on this deal in that role.", "already_attributed");
        if (existing is not null && await _ledger.EntryCountAsync(existing.Id, ct) > 0)
            return Cp.Conflict<DealPartnerDto>("This partner was on the deal before and earned money, so the attribution can't be reopened. Ask a manager.", "reattribution_blocked");

        var resolved = noTerms ? await _store.ResolveNoTermsAsync(ct) : await _store.ResolveAttributionAsync(partnerId, input.PlanId, ct);
        if (resolved is null) return Cp.Invalid<DealPartnerDto>("That plan has no published version yet. Publish it first.", "plan_not_published");

        // Phase 2: a plan's direction must fit the role. An integrator earns a COST (an accepted milestone), an FSP owes US a fee (a receivable), every other role earns a
        // share we pay. The "legacy, no terms" plan fits any role (it records the attribution and nothing else).
        var planVersion = await _store.PlanVersionAsync(resolved.PlanVersionId, ct);
        var planContent = PartnerPlanEngine.Read(planVersion?.Content);
        if (planVersion?.Plan?.IsSystem != true)
        {
            var wanted = WantedDirection(role);
            if (planContent.Direction != wanted)
                return Cp.Invalid<DealPartnerDto>(
                    wanted == ChannelPartnerVocab.Direction.Payable
                        ? "That plan is for an integrator's cost or a financial-service partner's fee, not a share we pay. Pick a share plan for this role."
                        : $"A {role} needs a {(wanted == ChannelPartnerVocab.Direction.Cost ? "cost (integrator)" : "receivable (financial-service partner)")} plan.",
                    "plan_role_mismatch");
        }

        // The document slot moves to a different partner: end the old tri_party first (its own save), so the one-active-document-partner index is never the arbiter.
        var leadRow = role == ChannelPartnerVocab.Role.TriParty ? await _store.FindLeadForUpdateAsync(leadId, ct) : null;
        if (role == ChannelPartnerVocab.Role.TriParty)
        {
            if (leadRow is null) return Cp.NotFound<DealPartnerDto>("Deal not found");
            if (await _store.ActiveOfRoleAsync(leadId, role, ct) is { } oldTri && oldTri.PartnerAccountId != partnerId)
            {
                if (await _store.DocumentPartnerHasEarningsAsync(leadId, ct))
                    return Cp.Conflict<DealPartnerDto>("The document partner has earned money on this deal. End that attribution (reversing its earnings) before changing it.", "earned_money");
                oldTri.EndedAt = DateTime.UtcNow;
                oldTri.EndReason = "The deal's document partner was changed.";
                oldTri.UpdatedAt = DateTime.UtcNow;
                await _store.SaveChangesAsync(ct);
            }
        }

        var dp = existing ?? new DealPartner { Id = Guid.NewGuid(), LeadId = leadId, PartnerAccountId = partnerId, Role = role };
        dp.Origin = origin;
        dp.PlanVersionId = resolved.PlanVersionId;
        dp.RuleScope = overridesGiven ? ChannelPartnerVocab.RuleScope.Deal : resolved.RuleScope;
        dp.OverridePercent = input.OverridePercent ?? resolved.Percent;
        dp.OverrideFlatAmount = input.OverrideFlatAmount ?? resolved.FlatAmount;
        dp.OverrideCap = input.OverrideCap ?? resolved.Cap;
        dp.OverrideClawbackWindowDays = input.OverrideClawbackWindowDays ?? resolved.ClawbackWindowDays;
        dp.OverridePaymentTermsDays = input.OverridePaymentTermsDays ?? resolved.PaymentTermsDays;
        dp.OverrideReason = overridesGiven ? input.OverrideReason!.Trim() : resolved.Reason;
        dp.BaseAtStart = 0m;   // F2: a partner earns on ALL money collected on the deal, including before it was added
        dp.Legacy = false;
        dp.StartedAt = DateTime.UtcNow;
        dp.EndedAt = null;
        dp.EndReason = null;
        dp.CreatedById = actorId;
        dp.UpdatedAt = DateTime.UtcNow;
        // Phase 2. FSP: the partner bills the end client (a snapshot of the plan - DealBilling.IsBilledByPartner reads it).
        dp.BillsEndClient = role == ChannelPartnerVocab.Role.Fsp && planContent.Direction == ChannelPartnerVocab.Direction.Receivable && planContent.PartnerBillsEndClient;
        if (existing is null)
        {
            // D1/D2: a NEW reseller deal partner takes the partner's terms (resale price; wholesale = the amount, else the percent of resale worked out). An existing row keeps its own.
            if (role == ChannelPartnerVocab.Role.Reseller && await _store.ReadProfileAsync(partnerId, ct) is { } terms)
                (dp.ResalePrice, dp.WholesaleAmount) = PartnerRequirements.Terms(terms);
            _store.AddDealPartner(dp);
        }

        // Phase 2. A referral for a client already in the pipeline is FLAGGED here (decided on this row by the deal owner or partners.manage); another partner's claim on the
        // same client becomes a conflict for a manager. Both are questions for a person - neither refuses the attribution.
        if (PartnerRegistrations.IsClaimRole(role))
        {
            if (!historic) _store.ApplyPipelineFlag(dp, await _store.MatchedOpenLeadIdsAsync(leadId, ct));
            await _store.RaiseClaimConflictsAsync(dp, actorId, ct);
        }

        // An integrator on a cost plan gets the plan's milestones copied onto the deal (amounts frozen here, not read live from the plan later).
        if (role == ChannelPartnerVocab.Role.Integrator && planContent.Direction == ChannelPartnerVocab.Direction.Cost && existing is null)
        {
            var seq = 0;
            foreach (var template in planContent.Milestones ?? [])
                _store.AddMilestone(new DealPartnerMilestone
                {
                    Id = Guid.NewGuid(), DealPartnerId = dp.Id, LeadId = leadId, PartnerAccountId = partnerId, Seq = ++seq,
                    Label = template.Label, Amount = PartnerPlanEngine.Money(template.Amount), CreatedById = actorId,
                });
        }

        // The document slot, written here (tracked) so FieldAudit records it; PartnerCapture finds the deal partner already in this save and adds nothing.
        if (leadRow is not null && leadRow.PartnerAccountId != partnerId) leadRow.PartnerAccountId = partnerId;
        await _store.SaveChangesAsync(ct);
        await _store.AccrueNowAsync(leadId, actorId, ct);   // F2: money already collected on the deal counts at once
        // Phase 3 (distributor, model T2): a sub-reseller's deal gets its distributor(s) on a drawdown plan as derived rows (Origin assigned), never typed by a rep.
        if (role == ChannelPartnerVocab.Role.Reseller) await AttachDistributorsAsync(ctx, leadId, partnerId, drawdownPlans: true, actorId, ct);
        return Cp.Ok((await ToDtosAsync(await _store.ListDealPartnersAsync(leadId, includeEnded: true, ct), ctx, ct)).First(d => d.Id == dp.Id));
    }

    /// <summary>
    /// Phase 3: attaches the distributor(s) above <paramref name="subResellerAccountId"/> (AccountRelationship distributor_for) to the deal as role `distributor`, Origin
    /// assigned, on the distributor's own plan. The two earning models are chosen BY THE PLAN: a drawdown-trigger plan (T2, share of the wholesale value drawn from the
    /// distributor's lots) attaches to the sub-reseller's END-CLIENT deals (<paramref name="drawdownPlans"/> true); any other plan (T1, share of the money collected on the
    /// sub-reseller's own purchase) attaches to the PURCHASE deal (false). Reuses <see cref="AttributeAsync"/> whole, so every rule (status, terms frozen, one row per role)
    /// holds; a refusal leaves the deal exactly as it was.
    /// </summary>
    public async Task AttachDistributorsAsync(RecordAccessContext ctx, Guid leadId, Guid subResellerAccountId, bool drawdownPlans, Guid actorId, CancellationToken ct = default)
    {
        foreach (var distributorId in await _store.DistributorsOfAsync(subResellerAccountId, ct))
        {
            if (await _store.FindDealPartnerAsync(leadId, distributorId, ChannelPartnerVocab.Role.Distributor, ct) is { EndedAt: null }) continue;
            var profile = await _store.ReadProfileAsync(distributorId, ct);
            if (profile is null || !ChannelPartnerVocab.Status.CanAttribute(profile.Status)) continue;
            var resolved = await _store.ResolveAttributionAsync(distributorId, null, ct);
            if (resolved is null) continue;
            var content = await _store.PlanContentAsync(resolved.PlanVersionId, ct);
            if ((content?.Trigger == ChannelPartnerVocab.Trigger.Drawdown) != drawdownPlans) continue;
            await AttributeAsync(ctx, leadId,
                new DealPartnerInput(distributorId, ChannelPartnerVocab.Role.Distributor, ChannelPartnerVocab.Origin.Assigned, null, null, null, null, null, null, null), actorId, ct);
        }
    }

    private static string? ValidateOverrides(decimal? percent, decimal? flat, decimal? cap, int? clawback, int? terms)
    {
        if (percent is { } p && (p <= 0m || p > 100m)) return "A percent share is above 0 and at most 100.";
        if (flat is { } f && f <= 0m) return "A flat fee is above 0.";
        if (cap is { } c && c < 0m) return "A cap cannot be negative.";
        if (clawback is { } w && (w < 0 || w > MaxDays)) return $"The clawback window is 0 to {MaxDays} days.";
        if (terms is { } t && (t < 0 || t > MaxDays)) return $"The payment terms are 0 to {MaxDays} days.";
        return null;
    }

    /// <summary>
    /// Ends an attribution. A deal partner that has earned money (net of clawbacks and adjustments) cannot just be ended (design 3.8): pass
    /// <c>reverse_earned</c> to write the reversing adjustment in the same save, or settle it first. An ended document partner clears the deal's slot.
    /// </summary>
    public async Task<CpResult<DealPartnerDto>> EndAsync(
        RecordAccessContext ctx, Guid dealPartnerId, DealPartnerEndInput input, Guid actorId, CancellationToken ct = default)
    {
        var dp = await _store.FindDealPartnerAsync(dealPartnerId, ct);
        if (dp is null) return Cp.NotFound<DealPartnerDto>("Deal partner not found");
        var lead = await VisibleLeadAsync(ctx, dp.LeadId, ct);
        if (!lead.IsOk) return Cp.As<DealPartnerDto, QuickLead>(lead);
        if (dp.EndedAt != null) return Cp.Conflict<DealPartnerDto>("This attribution has already ended.", "already_ended");
        var reason = input.Reason?.Trim();
        if (string.IsNullOrEmpty(reason)) return Cp.Invalid<DealPartnerDto>("A reason is required to end an attribution.", "reason_required");

        var earned = await _store.EarnedNetAsync(dp.Id, ct);
        if (earned != 0m)
        {
            if (!input.ReverseEarned)
                return Cp.Conflict<DealPartnerDto>($"This partner has earned {earned:0.00} on this deal. Reverse the earnings to end it.", "earned_money");
            if (!Cp.CanWriteCommercials(ctx)) return Cp.Invalid<DealPartnerDto>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);
            _ledger.AddEntry(new PartnerLedgerEntry
            {
                Id = Guid.NewGuid(),
                PartnerAccountId = dp.PartnerAccountId,
                LeadId = dp.LeadId,
                DealPartnerId = dp.Id,
                Kind = ChannelPartnerVocab.EntryKind.Adjustment,
                Amount = -earned,
                Currency = await _ledger.OrgCurrencyAsync(ct),
                SourceKey = $"manual:end:{dp.Id}:{await _ledger.EntryCountAsync(dp.Id, ct) + 1}",
                PlanVersionId = dp.PlanVersionId,
                RuleKey = "manual",
                RuleScope = dp.RuleScope,
                EarnedAt = DateTime.UtcNow,
                PayableOn = DateTime.UtcNow,
                Reason = $"Attribution ended - earnings reversed. {reason}",
                CreatedById = actorId,
            });
        }

        dp.EndedAt = DateTime.UtcNow;
        dp.EndReason = reason;
        dp.UpdatedAt = DateTime.UtcNow;
        if (dp.Role == ChannelPartnerVocab.Role.TriParty && await _store.FindLeadForUpdateAsync(dp.LeadId, ct) is { } row && row.PartnerAccountId == dp.PartnerAccountId)
            row.PartnerAccountId = null;
        await _store.SaveChangesAsync(ct);
        return Cp.Ok((await ToDtosAsync(await _store.ListDealPartnersAsync(dp.LeadId, includeEnded: true, ct), ctx, ct)).First(d => d.Id == dp.Id));
    }

    /// <summary>
    /// Points an attribution at another plan's current version - allowed only BEFORE it has accrued anything. Once money has been written the terms are frozen
    /// (re-pointing would re-price every past payment); end the attribution and attribute again.
    /// </summary>
    public async Task<CpResult<DealPartnerDto>> RepointAsync(
        RecordAccessContext ctx, Guid dealPartnerId, DealPartnerRepointInput input, CancellationToken ct = default)
    {
        var dp = await _store.FindDealPartnerAsync(dealPartnerId, ct);
        if (dp is null) return Cp.NotFound<DealPartnerDto>("Deal partner not found");
        var lead = await VisibleLeadAsync(ctx, dp.LeadId, ct);
        if (!lead.IsOk) return Cp.As<DealPartnerDto, QuickLead>(lead);
        if (!Cp.CanWriteCommercials(ctx)) return Cp.Invalid<DealPartnerDto>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);
        if (dp.EndedAt != null) return Cp.Conflict<DealPartnerDto>("This attribution has ended.", "already_ended");
        if (input.PlanId is not Guid planId) return Cp.Invalid<DealPartnerDto>("Pick the plan.", "plan_required");
        if (string.IsNullOrWhiteSpace(input.Reason)) return Cp.Invalid<DealPartnerDto>("A reason is required to change a deal partner's terms.", "reason_required");
        if (await _ledger.EntryCountAsync(dp.Id, ct) > 0)
            return Cp.Conflict<DealPartnerDto>("This attribution has already accrued, so its terms are frozen. End it (reversing the earnings) and attribute the partner again.", "terms_frozen");

        var resolved = await _store.ResolveAttributionAsync(dp.PartnerAccountId, planId, ct);
        if (resolved is null) return Cp.Invalid<DealPartnerDto>("That plan has no published version yet.", "plan_not_published");
        dp.PlanVersionId = resolved.PlanVersionId;
        dp.RuleScope = ChannelPartnerVocab.RuleScope.Plan;
        dp.OverridePercent = dp.OverrideFlatAmount = dp.OverrideCap = null;
        dp.OverrideClawbackWindowDays = dp.OverridePaymentTermsDays = null;
        dp.OverrideReason = $"Re-pointed: {input.Reason.Trim()}";
        dp.Legacy = false;
        dp.BaseAtStart = 0m;
        dp.UpdatedAt = DateTime.UtcNow;
        await _store.SaveChangesAsync(ct);
        await _store.AccrueNowAsync(dp.LeadId, dp.CreatedById, ct);
        return Cp.Ok((await ToDtosAsync(await _store.ListDealPartnersAsync(dp.LeadId, includeEnded: true, ct), ctx, ct)).First(d => d.Id == dp.Id));
    }

    /// <summary>The deals one partner is on (active by default), for the Partner tab. Visibility follows each deal.</summary>
    public async Task<CpResult<List<DealPartnerDto>>> DealsOfPartnerAsync(RecordAccessContext ctx, Guid accountId, bool activeOnly, CancellationToken ct = default)
    {
        var account = await _store.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<List<DealPartnerDto>>("Account not found");
        var rows = (await _store.ListDealsOfPartnerAsync(accountId, activeOnly, ct))
            .Where(d => d.Lead is not null && RecordAccess.CanView(ctx, d.Lead.OwnerId, d.Lead.TeamId)).ToList();
        return Cp.Ok(await ToDtosAsync(rows, ctx, ct));
    }
}

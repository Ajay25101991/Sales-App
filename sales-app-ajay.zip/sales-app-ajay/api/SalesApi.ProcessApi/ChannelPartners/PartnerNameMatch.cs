using SalesApi.Services;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// How alike two company names are (0..1), for suggesting which partner a client sheet's Lead Channel value means. Pure and in memory: the existing fuzzy matching in this codebase is
/// Postgres pg_trgm inside the search queries, which cannot score a handful of strings against each other, so this builds on the ONE normalisation the CRM already has
/// (<see cref="AccountLinkService.CompanyKey"/> - lower case, legal suffixes and punctuation stripped) and adds a score on top. A score is a QUESTION for the owner, never an answer:
/// the owner confirms every mapping.
/// </summary>
public static class PartnerNameMatch
{
    public static double Score(string? a, string? b)
    {
        var ka = AccountLinkService.CompanyKey(a);
        var kb = AccountLinkService.CompanyKey(b);
        if (ka.Length == 0 || kb.Length == 0) return 0d;
        if (ka == kb) return 1d;

        var ta = ka.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToHashSet();
        var tb = kb.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToHashSet();
        var shared = ta.Intersect(tb).Count();
        var jaccard = (double)shared / ta.Union(tb).Count();

        // Every word of the shorter name is a word of the longer ("mashreq" in "mashreq bank"): a near-certain reference to the same company.
        var (small, big) = ta.Count <= tb.Count ? (ta, tb) : (tb, ta);
        var contained = small.All(big.Contains) && small.Sum(t => t.Length) >= 3 ? 0.8d + 0.15d * small.Count / big.Count : 0d;

        // A typo or a one-letter spelling difference ("ahmad" / "ahmed").
        var distance = Levenshtein(ka, kb);
        var typo = 1d - (double)distance / Math.Max(ka.Length, kb.Length);

        return Math.Round(Math.Max(Math.Max(jaccard, contained), typo), 3);
    }

    private static int Levenshtein(string a, string b)
    {
        var prev = new int[b.Length + 1];
        var cur = new int[b.Length + 1];
        for (var j = 0; j <= b.Length; j++) prev[j] = j;
        for (var i = 1; i <= a.Length; i++)
        {
            cur[0] = i;
            for (var j = 1; j <= b.Length; j++)
                cur[j] = Math.Min(Math.Min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1));
            (prev, cur) = (cur, prev);
        }
        return prev[b.Length];
    }
}

using System.Text.RegularExpressions;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// Commission plans: an org-level named rule with a DRAFT and immutable numbered VERSIONS, exactly the way a pricing model works (<see cref="PricingModel"/> /
/// <c>PricingModelProcess</c> is the precedent followed method for method: drafts save even half-finished, publishing demands a clean rule, every published version is a
/// frozen row, restoring copies an old version back into the draft). The rule maths is <see cref="PartnerPlanEngine"/> (pure; formula plans run on the shared
/// PricingExpression engine) - nothing here evaluates anything.
///
/// A per-partner assignment (<see cref="PartnerPlanAssignment"/>) is the LoyaltyAccountRule shape: nullable override fields that follow the plan when null, a reason, history as
/// rows. Neither a new version nor a new assignment touches a deal that already has a partner: terms are frozen on the <see cref="DealPartner"/> when it is attributed.
///
/// Authorization stays at the HTTP layer (partners.manage + a raw/full Partner commercials level); this class reads no principal.
/// </summary>
public sealed class PartnerPlanProcess
{
    private readonly ChannelPartnerStore _store;
    public PartnerPlanProcess(ChannelPartnerStore store) => _store = store;

    private static readonly Regex NotKey = new("[^a-z0-9]+", RegexOptions.Compiled);
    private const string NoPlan = "Plan not found";

    // ---- shaping ------------------------------------------------------------------------------

    private static PartnerPlanDto ToDto(PartnerPlan p, PartnerPlanVersion? latest)
    {
        var draft = PartnerPlanEngine.Read(p.DraftContent);
        var changed = latest is null ? true : PartnerPlanEngine.Serialise(draft) != PartnerPlanEngine.Serialise(PartnerPlanEngine.Read(latest.Content));
        return new(p.Id, p.Key, p.Name, p.PartnerType, p.IsSystem, p.ArchivedAt, draft, p.DraftUpdatedAt, latest?.Version, latest?.PublishedAt, changed);
    }

    private static PartnerPlanVersionDto ToDto(PartnerPlanVersion v) =>
        new(v.Id, v.PlanId, v.Version, v.PublishedAt, v.PublishedById, PartnerPlanEngine.Read(v.Content));

    private static string KeyFrom(string name)
    {
        var key = NotKey.Replace(name.Trim().ToLowerInvariant(), "_").Trim('_');
        if (key.Length == 0) key = "plan";
        return key.Length > 70 ? key[..70] : key;
    }

    // ---- reads --------------------------------------------------------------------------------

    public async Task<List<PartnerPlanDto>> ListAsync(bool includeArchived, CancellationToken ct = default)
    {
        var plans = await _store.ListPlansAsync(includeArchived, ct);
        var latest = await _store.LatestVersionsAsync(plans.Select(p => p.Id).ToList(), ct);
        return plans.Select(p => ToDto(p, latest.GetValueOrDefault(p.Id))).ToList();
    }

    /// <summary>Did this user create the plan? The controller's "own plan" allowance for a caller without Partner commercials (owner 2026-11-06).</summary>
    public Task<bool> CreatedByAsync(Guid planId, Guid userId, CancellationToken ct = default) => _store.PlanCreatedByAsync(planId, userId, ct);

    public async Task<CpResult<PartnerPlanDto>> GetAsync(Guid planId, CancellationToken ct = default)
    {
        var plan = await _store.FindPlanAsync(planId, ct);
        if (plan is null) return Cp.NotFound<PartnerPlanDto>(NoPlan);
        return Cp.Ok(ToDto(plan, await _store.LatestVersionAsync(planId, ct)));
    }

    public async Task<CpResult<List<PartnerPlanVersionDto>>> ListVersionsAsync(Guid planId, CancellationToken ct = default)
    {
        if (await _store.FindPlanAsync(planId, ct) is null) return Cp.NotFound<List<PartnerPlanVersionDto>>(NoPlan);
        return Cp.Ok((await _store.ListVersionsAsync(planId, ct)).Select(ToDto).ToList());
    }

    public async Task<CpResult<PartnerPlanVersionDto>> GetVersionAsync(Guid planId, int version, CancellationToken ct = default)
    {
        var v = await _store.FindVersionAsync(planId, version, ct);
        return v is null ? Cp.NotFound<PartnerPlanVersionDto>("Version not found") : Cp.Ok(ToDto(v));
    }

    // ---- draft --------------------------------------------------------------------------------

    public async Task<CpResult<PartnerPlanSavedDto>> CreateAsync(PartnerPlanCreateInput input, Guid? userId, CancellationToken ct = default)
    {
        var name = input.Name?.Trim();
        if (string.IsNullOrEmpty(name)) return Cp.Invalid<PartnerPlanSavedDto>("Give the plan a name.", "name_required");
        if (name.Length > 200) return Cp.Invalid<PartnerPlanSavedDto>("The name is at most 200 characters.", "name_too_long");

        var baseKey = KeyFrom(name);
        var key = baseKey;
        for (var n = 2; await _store.PlanKeyTakenAsync(key, ct); n++) key = $"{baseKey}_{n}";

        var content = PartnerPlanEngine.Clean(input.Content ?? PartnerPlanEngine.Empty());
        // Owner Q10: a NEW integrator (cost) plan pays 30 days after the SI's tax invoice unless the author chose otherwise (the record's own default, 90, is the share-plan default).
        if (content.Direction == ChannelPartnerVocab.Direction.Cost && content.PaymentTermsDays == 90) content = content with { PaymentTermsDays = 30 };
        var plan = new PartnerPlan
        {
            Id = Guid.NewGuid(),
            Key = key,
            Name = name,
            PartnerType = string.IsNullOrWhiteSpace(input.PartnerType) ? null : input.PartnerType.Trim().ToLowerInvariant(),
            DraftContent = PartnerPlanEngine.Serialise(content),
            DraftUpdatedAt = DateTime.UtcNow,
            DraftUpdatedById = userId,
            CreatedById = userId,
        };
        _store.AddPlan(plan);
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(Saved(plan, null, content));
    }

    /// <summary>Saves the draft. Rule problems do NOT refuse the save (an author must be able to keep work in progress); they come back in <c>validation</c>.</summary>
    public async Task<CpResult<PartnerPlanSavedDto>> SaveDraftAsync(Guid planId, PartnerPlanDraftInput input, Guid? userId, CancellationToken ct = default)
    {
        var plan = await _store.FindPlanAsync(planId, ct);
        if (plan is null) return Cp.NotFound<PartnerPlanSavedDto>(NoPlan);
        if (plan.IsSystem) return Cp.Conflict<PartnerPlanSavedDto>("This is the system plan for deals that had a partner before terms existed. It can't be edited.", "system_plan");
        if (plan.ArchivedAt != null) return Cp.Conflict<PartnerPlanSavedDto>("This plan is archived. Restore it before editing.", "archived");

        if (input.Name is not null)
        {
            var name = input.Name.Trim();
            if (name.Length == 0) return Cp.Invalid<PartnerPlanSavedDto>("Give the plan a name.", "name_required");
            if (name.Length > 200) return Cp.Invalid<PartnerPlanSavedDto>("The name is at most 200 characters.", "name_too_long");
            plan.Name = name;
        }
        if (input.PartnerType is not null) plan.PartnerType = string.IsNullOrWhiteSpace(input.PartnerType) ? null : input.PartnerType.Trim().ToLowerInvariant();
        var content = input.Content is null ? PartnerPlanEngine.Read(plan.DraftContent) : PartnerPlanEngine.Clean(input.Content);
        plan.DraftContent = PartnerPlanEngine.Serialise(content);
        plan.DraftUpdatedAt = DateTime.UtcNow;
        plan.DraftUpdatedById = userId;
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(Saved(plan, await _store.LatestVersionAsync(planId, ct), content));
    }

    private static PartnerPlanSavedDto Saved(PartnerPlan plan, PartnerPlanVersion? latest, PartnerPlanContentDto content)
    {
        var issues = PartnerPlanEngine.Validate(content, forPublish: false, plan.IsSystem);
        return new PartnerPlanSavedDto(ToDto(plan, latest), new PricingValidationDto(issues.Count == 0, issues));
    }

    /// <summary>Checks a body, or the stored draft when none is given. <paramref name="forPublish"/> adds the publish-only rules.</summary>
    public async Task<CpResult<PricingValidationDto>> ValidateAsync(Guid planId, PartnerPlanContentDto? body, bool forPublish, CancellationToken ct = default)
    {
        var plan = await _store.FindPlanAsync(planId, ct);
        if (plan is null) return Cp.NotFound<PricingValidationDto>(NoPlan);
        var content = body is not null ? PartnerPlanEngine.Clean(body) : PartnerPlanEngine.Read(plan.DraftContent);
        var issues = PartnerPlanEngine.Validate(content, forPublish, plan.IsSystem);
        return Cp.Ok(new PricingValidationDto(issues.Count == 0, issues));
    }

    /// <summary>What a rule would earn on the given collected money - the plan editor's live preview. Runs the SAME engine a real accrual does.</summary>
    public async Task<CpResult<decimal>> PreviewAsync(Guid planId, PartnerPlanContentDto? body, decimal collected, decimal dealBase, CancellationToken ct = default)
    {
        var plan = await _store.FindPlanAsync(planId, ct);
        if (plan is null) return Cp.NotFound<decimal>(NoPlan);
        var content = body is not null ? PartnerPlanEngine.Clean(body) : PartnerPlanEngine.Read(plan.DraftContent);
        var issues = PartnerPlanEngine.Validate(content, forPublish: false, plan.IsSystem);
        if (issues.Count > 0) return Cp.Invalid<decimal>("The rule has problems to fix first.", "invalid_rule", issues);
        try { return Cp.Ok(PartnerPlanEngine.Target(PartnerPlanEngine.Effective(content), Math.Max(0m, collected), Math.Max(0m, collected), dealBase)); }
        catch (InvalidOperationException e) { return Cp.Invalid<decimal>(e.Message, "unevaluable"); }
    }

    // ---- publish / restore / archive ----------------------------------------------------------------

    public async Task<CpResult<PartnerPlanVersionDto>> PublishAsync(Guid planId, Guid? userId, CancellationToken ct = default)
    {
        var plan = await _store.FindPlanAsync(planId, ct);
        if (plan is null) return Cp.NotFound<PartnerPlanVersionDto>(NoPlan);
        if (plan.IsSystem) return Cp.Conflict<PartnerPlanVersionDto>("The system plan can't be republished.", "system_plan");
        if (plan.ArchivedAt != null) return Cp.Conflict<PartnerPlanVersionDto>("This plan is archived.", "archived");

        var content = PartnerPlanEngine.Read(plan.DraftContent);
        var issues = PartnerPlanEngine.Validate(content, forPublish: true);
        if (issues.Count > 0) return Cp.Invalid<PartnerPlanVersionDto>("The plan has problems to fix before it can be published.", "invalid_rule", issues);

        var latest = await _store.LatestVersionAsync(planId, ct);
        if (latest is not null && PartnerPlanEngine.Serialise(PartnerPlanEngine.Read(latest.Content)) == PartnerPlanEngine.Serialise(content))
            return Cp.Conflict<PartnerPlanVersionDto>($"The draft is the same as version {latest.Version}; there is nothing new to publish.", "unchanged");

        var version = new PartnerPlanVersion
        {
            Id = Guid.NewGuid(),
            PlanId = plan.Id,
            Version = (latest?.Version ?? 0) + 1,
            Content = PartnerPlanEngine.Serialise(content),
            PublishedAt = DateTime.UtcNow,
            PublishedById = userId,
        };
        if (!await _store.TryAddVersionAsync(version, ct))
            return Cp.Conflict<PartnerPlanVersionDto>("Someone else published at the same moment. Reload and try again.", "publish_race");
        return Cp.Ok(ToDto(version));
    }

    /// <summary>Copies a published version into the draft (the version itself is untouched). Refuses to throw away unpublished draft work unless told to.</summary>
    public async Task<CpResult<PartnerPlanDto>> RestoreVersionAsync(Guid planId, int version, bool replaceDraft, Guid? userId, CancellationToken ct = default)
    {
        var plan = await _store.FindPlanAsync(planId, ct);
        if (plan is null) return Cp.NotFound<PartnerPlanDto>(NoPlan);
        if (plan.IsSystem || plan.ArchivedAt != null) return Cp.Conflict<PartnerPlanDto>("This plan can't be edited.", "not_editable");
        var target = await _store.FindVersionAsync(planId, version, ct);
        if (target is null) return Cp.NotFound<PartnerPlanDto>("Version not found");

        var latest = await _store.LatestVersionAsync(planId, ct);
        var current = ToDto(plan, latest);
        var targetContent = PartnerPlanEngine.Read(target.Content);
        if (current.HasUnpublishedChanges && !replaceDraft
            && PartnerPlanEngine.Serialise(current.Draft) != PartnerPlanEngine.Serialise(targetContent))
            return Cp.Conflict<PartnerPlanDto>("The draft has changes that are not published. Restoring would replace them; confirm to continue.", "draft_changed");

        plan.DraftContent = target.Content;
        plan.DraftUpdatedAt = DateTime.UtcNow;
        plan.DraftUpdatedById = userId;
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(ToDto(plan, latest));
    }

    /// <summary>Archives (or restores) a plan. An archived plan can't be picked for new partners or attributions; deals already on it keep their frozen version.</summary>
    public async Task<CpResult<PartnerPlanDto>> SetArchivedAsync(Guid planId, bool archived, CancellationToken ct = default)
    {
        var plan = await _store.FindPlanAsync(planId, ct);
        if (plan is null) return Cp.NotFound<PartnerPlanDto>(NoPlan);
        if (plan.IsSystem) return Cp.Conflict<PartnerPlanDto>("The system plan can't be archived.", "system_plan");
        plan.ArchivedAt = archived ? plan.ArchivedAt ?? DateTime.UtcNow : null;
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(ToDto(plan, await _store.LatestVersionAsync(planId, ct)));
    }

    // ---- per-partner assignment -----------------------------------------------------------------------

    public async Task<CpResult<List<PartnerPlanAssignmentDto>>> ListAssignmentsAsync(Guid partnerAccountId, CancellationToken ct = default)
    {
        if (await _store.AccountFactsAsync(partnerAccountId, ct) is null) return Cp.NotFound<List<PartnerPlanAssignmentDto>>("Account not found");
        var rows = await _store.ListAssignmentsAsync(partnerAccountId, ct);
        var names = await _store.PlanNamesAsync(rows.Select(r => r.PlanId).Distinct().ToList(), ct);
        return Cp.Ok(rows.Select(r => ChannelPartnerProcess.ToAssignmentDto(r, names.GetValueOrDefault(r.PlanId))).ToList());
    }

    /// <summary>
    /// Assigns the partner a plan, optionally with its own override of the rate, cap, window or terms. The override needs a reason (why does this partner earn
    /// more?). The previous open assignment is closed, never edited. Existing deal partners keep the terms they were attributed on.
    /// </summary>
    public async Task<CpResult<PartnerPlanAssignmentDto>> AssignAsync(Guid partnerAccountId, PartnerPlanAssignmentInput input, Guid? userId, CancellationToken ct = default)
    {
        if (await _store.AccountFactsAsync(partnerAccountId, ct) is null) return Cp.NotFound<PartnerPlanAssignmentDto>("Account not found");
        if (await _store.ReadProfileAsync(partnerAccountId, ct) is null) return Cp.Invalid<PartnerPlanAssignmentDto>("This account isn't a channel partner yet.", "not_a_partner");
        if (input.PlanId is not Guid planId) return Cp.Invalid<PartnerPlanAssignmentDto>("Pick the plan.", "plan_required");
        var plan = await _store.FindPlanAsync(planId, ct);
        if (plan is null || plan.ArchivedAt != null || plan.IsSystem) return Cp.Invalid<PartnerPlanAssignmentDto>("Pick one of your commission plans.", "bad_plan");
        if (await _store.LatestVersionAsync(planId, ct) is null) return Cp.Invalid<PartnerPlanAssignmentDto>("That plan has no published version yet. Publish it first.", "plan_not_published");

        if (input.Percent is { } p && (p <= 0m || p > 100m)) return Cp.Invalid<PartnerPlanAssignmentDto>("A percent share is above 0 and at most 100.", "bad_override");
        if (input.FlatAmount is { } f && f <= 0m) return Cp.Invalid<PartnerPlanAssignmentDto>("A flat fee is above 0.", "bad_override");
        if (input.Cap is { } c && c < 0m) return Cp.Invalid<PartnerPlanAssignmentDto>("A cap cannot be negative.", "bad_override");
        if (input.ClawbackWindowDays is { } w && (w < 0 || w > PartnerPlanEngine.MaxDays)) return Cp.Invalid<PartnerPlanAssignmentDto>("The clawback window is 0 to 3650 days.", "bad_override");
        if (input.PaymentTermsDays is { } t && (t < 0 || t > PartnerPlanEngine.MaxDays)) return Cp.Invalid<PartnerPlanAssignmentDto>("The payment terms are 0 to 3650 days.", "bad_override");

        var overrides = input.Percent is not null || input.FlatAmount is not null || input.Cap is not null || input.ClawbackWindowDays is not null || input.PaymentTermsDays is not null;
        var reason = input.Reason?.Trim();
        if (overrides && string.IsNullOrEmpty(reason)) return Cp.Invalid<PartnerPlanAssignmentDto>("A reason is required when this partner's terms differ from the plan.", "reason_required");
        if (reason is { Length: > 1000 }) return Cp.Invalid<PartnerPlanAssignmentDto>("The reason is at most 1000 characters.", "reason_too_long");

        var from = (input.EffectiveFrom ?? DateTime.UtcNow).ToUniversalTime();
        var open = await _store.OpenAssignmentsAsync(partnerAccountId, ct);
        if (open.Any(o => o.EffectiveFrom > from)) return Cp.Invalid<PartnerPlanAssignmentDto>("A new assignment can't start before the current one.", "bad_effective_from");
        foreach (var o in open) o.EffectiveTo = from;

        var row = new PartnerPlanAssignment
        {
            Id = Guid.NewGuid(),
            PartnerAccountId = partnerAccountId,
            PlanId = planId,
            Percent = input.Percent, FlatAmount = input.FlatAmount, Cap = input.Cap,
            ClawbackWindowDays = input.ClawbackWindowDays, PaymentTermsDays = input.PaymentTermsDays,
            EffectiveFrom = from,
            Reason = string.IsNullOrEmpty(reason) ? $"Assigned {plan.Name}" : reason,
            CreatedById = userId,
        };
        _store.AddAssignment(row);
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(ChannelPartnerProcess.ToAssignmentDto(row, plan.Name));
    }
}

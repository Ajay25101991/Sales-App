using SalesApi.Dtos;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>How a channel-partner Process call ended. A RESULT rather than an exception (the PricingModelProcess shape), so the endpoint picks a status without parsing prose.</summary>
public enum CpOutcome { Ok, NotFound, Invalid, Conflict, Forbidden, Unavailable }

/// <param name="Code">A stable machine code a client may switch on (e.g. "no_signed_agreement"); prose is in <paramref name="Error"/>.</param>
/// <param name="Issues">Plan problems behind an Invalid, for the editor to show in place.</param>
/// <param name="MissingKeys">Partner terms (2026-11-10): the requirement field keys behind a refused activation or attribution (code <c>partner_incomplete</c>), on a 400.</param>
/// <param name="Missing">E19.5: the KYC checklist items behind a refused sign-up Submit (code <c>kyc_incomplete</c>), so the screen can list them. Null for every other result.</param>
public sealed record CpResult<T>(CpOutcome Outcome, T? Value, string? Error = null, string? Code = null, List<PricingIssueDto>? Issues = null, List<KycChecklistItemDto>? Missing = null, List<string>? MissingKeys = null)
{
    public bool IsOk => Outcome == CpOutcome.Ok;
}

public static class Cp
{
    public static CpResult<T> Ok<T>(T value) => new(CpOutcome.Ok, value);
    public static CpResult<T> NotFound<T>(string error) => new(CpOutcome.NotFound, default, error);
    public static CpResult<T> Invalid<T>(string error, string? code = null, List<PricingIssueDto>? issues = null) => new(CpOutcome.Invalid, default, error, code, issues);
    public static CpResult<T> Conflict<T>(string error, string? code = null) => new(CpOutcome.Conflict, default, error, code);
    public static CpResult<T> Forbidden<T>(string error, string? code = null) => new(CpOutcome.Forbidden, default, error, code);
    /// <summary>The service behind the call is not available (no payment gateway connected, no public address): 503.</summary>
    public static CpResult<T> Unavailable<T>(string error, string? code = null) => new(CpOutcome.Unavailable, default, error, code);

    /// <summary>E19.5: a 409 that carries the checklist items still missing.</summary>
    public static CpResult<T> Incomplete<T>(string error, string code, List<KycChecklistItemDto> missing) => new(CpOutcome.Conflict, default, error, code, null, missing);

    /// <summary>A 400 that carries the requirement keys a partner still lacks (code <c>partner_incomplete</c>).</summary>
    public static CpResult<T> Incomplete<T>(string error, List<string> missingKeys) =>
        new(CpOutcome.Invalid, default, error, SalesApi.Services.PartnerRequirements.IncompleteCode, null, null, missingKeys);

    /// <summary>Carries a refusal across result types.</summary>
    public static CpResult<T> As<T, U>(CpResult<U> refusal) => new(refusal.Outcome, default, refusal.Error, refusal.Code, refusal.Issues, null, refusal.MissingKeys);

    /// <summary>Partner terms, ledger amounts, statements and payouts: the caller reads them raw only at full or view-only.</summary>
    public static bool CanReadCommercials(SalesApi.Services.RecordAccessContext ctx) =>
        SensitiveLevels.CanReadRaw((ctx.Sensitive ?? SalesApi.Services.SensitiveAccess.Unrestricted).RoleLevel(SensitiveCategories.PartnerCommercials));

    /// <summary>Phase 2: masked-or-better. A caller at this level may be told that a registration / cost / receivable EXISTS and its status, but not an amount, a note or a rate. Hidden: nothing.</summary>
    public static bool CanReachCommercials(SalesApi.Services.RecordAccessContext ctx) =>
        SensitiveLevels.CanReach((ctx.Sensitive ?? SalesApi.Services.SensitiveAccess.Unrestricted).RoleLevel(SensitiveCategories.PartnerCommercials));

    public static bool CanWriteCommercials(SalesApi.Services.RecordAccessContext ctx) =>
        SensitiveLevels.CanWrite((ctx.Sensitive ?? SalesApi.Services.SensitiveAccess.Unrestricted).RoleLevel(SensitiveCategories.PartnerCommercials));

    public static bool CanReadBank(SalesApi.Services.RecordAccessContext ctx) =>
        SensitiveLevels.CanReadRaw((ctx.Sensitive ?? SalesApi.Services.SensitiveAccess.Unrestricted).RoleLevel(SensitiveCategories.IdBank));

    public static bool CanWriteBank(SalesApi.Services.RecordAccessContext ctx) =>
        SensitiveLevels.CanWrite((ctx.Sensitive ?? SalesApi.Services.SensitiveAccess.Unrestricted).RoleLevel(SensitiveCategories.IdBank));

    /// <summary>The 400 message for a write the caller's level forbids (same wording family as the other categories).</summary>
    public static string ReadOnlyMessage(string category) =>
        $"You can view {SensitiveCategories.Label(category)} but not change it.";
}

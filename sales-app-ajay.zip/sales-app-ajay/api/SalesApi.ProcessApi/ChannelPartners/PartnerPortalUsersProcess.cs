using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// The channel team's side of the portal: inviting, listing, resending to and switching off the NAMED PEOPLE at a partner who may sign in to the partner portal (owner decision 4.8:
/// several per partner, all with the same read-only view). The authority is partners.manage, checked by the controller; the facts about the caller travel in as data.
///
/// REUSE, not a second sign-in system. A portal user is a normal <see cref="Profile"/> created by the SAME path as a teammate - <see cref="ProcessLayer.People.PeopleProcess"/> (email
/// validation, one-email-one-profile, role resolution, capacity check, BCrypt'd temporary password, forced change) - with <c>PortalKind</c> + <c>PortalAccountId</c> set (E19.1: kind "partner" or "customer") and the ready-made
/// <c>external_partner</c> role (no permissions, every sensitive category Hidden). The invite is the existing one-time link (<c>InviteTokenService</c>); sign-in is the existing
/// <c>/auth/signin</c>; deactivating is the existing <c>ApplyUpdateAsync</c> (role-version bump, so a live token dies on its next request).
///
/// WHAT WAS FOUND ABOUT THE ALLOWED-DOMAINS SCREEN AND EMAIL UNIQUENESS (the brief asked to report, not assume): the allowed-domains list gates only SELF-SIGNUP that would create a
/// NEW organisation (<c>AuthProcess.SignupAsync</c>); an invite never reads it, so a partner at any email domain can be invited with no bypass and no loosened setting. Email is
/// unique across the WHOLE platform (<c>profiles.email</c> unique index, <c>EmailInUseAsync</c> not org-scoped), so a person who already has a CRM login anywhere cannot also be a
/// portal user on that email; they are refused with a plain message and need another address.
/// </summary>
public sealed class PartnerPortalUsersProcess
{
    private readonly PartnerPortalStore _portal;
    private readonly ChannelPartnerStore _partners;
    private readonly ProcessLayer.People.PeopleProcess _people;

    private readonly PartnerPortalProcess? _portalReads;

    /// <param name="portalReads">For the staff view of usage reported through a partner: the SAME rollup the portal shows that partner, so the two cannot differ.</param>
    public PartnerPortalUsersProcess(
        PartnerPortalStore portal, ChannelPartnerStore partners, ProcessLayer.People.PeopleProcess people, PartnerPortalProcess? portalReads = null)
    {
        _portalReads = portalReads;
        _portal = portal;
        _partners = partners;
        _people = people;
    }

    private static PartnerPortalUserDto ToDto(Profile p) =>
        new(p.Id, p.Email, p.FullName, p.IsActive, p.MustChangePassword, p.CreatedAt, p.LastLoginAt, p.PortalKind ?? PortalKinds.Partner, p.PortalIncludeChildren);

    /// <summary>
    /// The account the caller may see, for either portal kind (E19.1). A PARTNER portal user's account must also be a channel partner; a CUSTOMER portal user's account is any account the
    /// caller can see. An unknown kind is refused (400 <c>unknown_kind</c>) rather than treated as partner.
    /// </summary>
    private async Task<CpResult<ChannelPartnerStore.AccountFacts>> VisibleAccountAsync(RecordAccessContext ctx, Guid accountId, string kind, CancellationToken ct)
    {
        if (!PortalKinds.IsKnown(kind)) return Cp.Invalid<ChannelPartnerStore.AccountFacts>("Unknown portal kind.", "unknown_kind");
        var account = await _partners.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<ChannelPartnerStore.AccountFacts>("Account not found");
        if (kind == PortalKinds.Partner && await _partners.ReadProfileAsync(accountId, ct) is null) return Cp.NotFound<ChannelPartnerStore.AccountFacts>("This account is not a channel partner.");
        return Cp.Ok(account);
    }

    /// <summary>Owner 2026-10-20: a terminated or suspended partner gets no new portal users and none switched back on (409 <c>partner_not_active</c>). Partner kind only - a customer account has no partner status.</summary>
    private async Task<CpResult<T>?> NotActiveAsync<T>(Guid partnerAccountId, CancellationToken ct, string kind = PortalKinds.Partner)
    {
        if (kind != PortalKinds.Partner) return null;
        var status = (await _partners.ReadProfileAsync(partnerAccountId, ct))?.Status;
        return status is ChannelPartnerVocab.Status.Terminated or ChannelPartnerVocab.Status.Suspended
            ? Cp.Conflict<T>($"This partner is {status}, so its portal users can't be added or switched on.", "partner_not_active")
            : null;
    }

    /// <summary>Usage counts reported through this partner, by client and month (live rows). Counts only - no charge - so it follows the partner account's visibility.</summary>
    public async Task<CpResult<PartnerPortalUsageDto>> UsageAsync(RecordAccessContext ctx, Guid partnerAccountId, DateOnly? from, DateOnly? to, CancellationToken ct = default)
    {
        var partner = await VisibleAccountAsync(ctx, partnerAccountId, PortalKinds.Partner, ct);
        if (!partner.IsOk || _portalReads is null) return partner.IsOk ? Cp.NotFound<PartnerPortalUsageDto>("Not available") : Cp.As<PartnerPortalUsageDto, ChannelPartnerStore.AccountFacts>(partner);
        return await _portalReads.UsageAsync(new PartnerPortalScope(partnerAccountId, ctx.UserId), from, to, ct);
    }

    /// <param name="kind">E19.1: <see cref="PortalKinds.Partner"/> (default) or <see cref="PortalKinds.Customer"/>. <paramref name="partnerAccountId"/> is the portal ACCOUNT of either kind.</param>
    public async Task<CpResult<List<PartnerPortalUserDto>>> ListAsync(RecordAccessContext ctx, Guid partnerAccountId, CancellationToken ct = default, string kind = PortalKinds.Partner)
    {
        var partner = await VisibleAccountAsync(ctx, partnerAccountId, kind, ct);
        if (!partner.IsOk) return Cp.As<List<PartnerPortalUserDto>, ChannelPartnerStore.AccountFacts>(partner);
        return Cp.Ok((await _portal.UsersAsync(partnerAccountId, ct, kind)).Select(ToDto).ToList());
    }

    /// <param name="buildUrl">Builds the absolute accept-invite link from the raw token (needs the request's host, which this layer never sees).</param>
    /// <param name="kind">E19.1: <see cref="PortalKinds.Partner"/> (default) or <see cref="PortalKinds.Customer"/>. A customer is invited from a contact on the CLIENT account the same way.</param>
    public async Task<CpResult<PartnerPortalUserInvitedDto>> InviteAsync(
        RecordAccessContext ctx, Guid partnerAccountId, PartnerPortalUserInviteInput input, Guid actorId, Func<string, string> buildUrl, CancellationToken ct = default,
        string kind = PortalKinds.Partner)
    {
        var partner = await VisibleAccountAsync(ctx, partnerAccountId, kind, ct);
        if (!partner.IsOk) return Cp.As<PartnerPortalUserInvitedDto, ChannelPartnerStore.AccountFacts>(partner);

        if (await NotActiveAsync<PartnerPortalUserInvitedDto>(partnerAccountId, ct, kind) is { } inactive) return inactive;
        var email = input.Email?.Trim();
        var name = input.FullName?.Trim();
        if (input.ContactId is Guid contactId)
        {
            var contact = await _portal.ContactAsync(partnerAccountId, contactId, ct);
            if (contact is null) return Cp.NotFound<PartnerPortalUserInvitedDto>(kind == PortalKinds.Partner ? "That contact is not on this partner's account." : "That contact is not on this account.");
            if (string.IsNullOrWhiteSpace(contact.Email)) return Cp.Invalid<PartnerPortalUserInvitedDto>("That contact has no email address. Add one to the contact first.", "contact_no_email");
            email = contact.Email.Trim();
            name = string.IsNullOrWhiteSpace(name) ? contact.Name : name;
        }
        if (string.IsNullOrWhiteSpace(email) || !email.Contains('@')) return Cp.Invalid<PartnerPortalUserInvitedDto>("Enter the person's email address.", "email_required");
        if (string.IsNullOrWhiteSpace(name)) return Cp.Invalid<PartnerPortalUserInvitedDto>("Enter the person's name.", "name_required");
        if (name.Length > 200 || email.Length > 254) return Cp.Invalid<PartnerPortalUserInvitedDto>("That name or email is too long.", "too_long");

        var prep = await _people.PrepareCreateAsync(
            new CreateUserInput(email, name, ReadyMadeRoles.PortalRoleKey(kind), null, null), actorIsSuntechAdmin: false, actorId, ct, (kind, partnerAccountId, kind == PortalKinds.Customer && input.IncludeChildren));
        if (prep.Refusal is { } refusal)
        {
            if (refusal.Reason.StartsWith("Select a role defined", StringComparison.Ordinal))
                return Cp.Conflict<PartnerPortalUserInvitedDto>($"Your organisation has no \"{ReadyMadeRoles.PortalRoleLabel(kind)}\" role yet. Add it on Roles & access first.", "portal_role_missing");
            return refusal.Conflict
                ? Cp.Conflict<PartnerPortalUserInvitedDto>(refusal.Reason, "email_in_use")
                : Cp.Invalid<PartnerPortalUserInvitedDto>(refusal.Reason, "invite_refused");
        }

        var (_, newId) = await _people.CommitCreateAsync(prep, ct);
        string? inviteUrl = null;   // returned ONCE on this response, like the temporary password; never stored readable or listed later
        var (sent, error) = await _people.SendInviteEmailAsync(newId, buildUrl, ct, partner.Value!.Name, u => inviteUrl = u);
        var created = await _portal.FindUserAsync(partnerAccountId, newId, ct, kind);
        return Cp.Ok(new PartnerPortalUserInvitedDto(ToDto(created!), prep.TempPassword, sent, error, buildUrl(""), inviteUrl));
    }

    public async Task<CpResult<bool>> SetActiveAsync(RecordAccessContext ctx, Guid partnerAccountId, Guid userId, bool active, Guid actorId, CancellationToken ct = default, string kind = PortalKinds.Partner)
    {
        var partner = await VisibleAccountAsync(ctx, partnerAccountId, kind, ct);
        if (!partner.IsOk) return Cp.As<bool, ChannelPartnerStore.AccountFacts>(partner);
        var user = await _portal.FindUserAsync(partnerAccountId, userId, ct, kind);
        if (user is null) return Cp.NotFound<bool>("User not found");
        if (user.IsActive == active) return Cp.Ok(true);
        // A portal user is not a seat (owner 2026-10-20), so no plan-limit check; but a terminated or suspended partner's users stay off.
        if (active && await NotActiveAsync<bool>(partnerAccountId, ct, kind) is { } inactive) return inactive;
        await _people.ApplyUpdateAsync(userId, null, null, active, actorId, ct);
        return Cp.Ok(true);
    }

    /// <summary>Sends a fresh invite link (invalidating any outstanding one). Only before the person has set their own password.</summary>
    public async Task<CpResult<PartnerPortalUserInvitedDto>> ResendInviteAsync(
        RecordAccessContext ctx, Guid partnerAccountId, Guid userId, Func<string, string> buildUrl, CancellationToken ct = default, string kind = PortalKinds.Partner)
    {
        var partner = await VisibleAccountAsync(ctx, partnerAccountId, kind, ct);
        if (!partner.IsOk) return Cp.As<PartnerPortalUserInvitedDto, ChannelPartnerStore.AccountFacts>(partner);
        var user = await _portal.FindUserAsync(partnerAccountId, userId, ct, kind);
        if (user is null) return Cp.NotFound<PartnerPortalUserInvitedDto>("User not found");
        if (!user.MustChangePassword) return Cp.Conflict<PartnerPortalUserInvitedDto>("This person has already signed in and set their own password.", "already_signed_in");
        string? inviteUrl = null;   // the fresh link, once (the previous one is already revoked)
        var (sent, error) = await _people.SendInviteEmailAsync(userId, buildUrl, ct, partner.Value!.Name, u => inviteUrl = u);
        return Cp.Ok(new PartnerPortalUserInvitedDto(ToDto(user), null, sent, error, buildUrl(""), inviteUrl));
    }
}

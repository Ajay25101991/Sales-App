using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// Bulk stock for resellers and distributors (Phase 3, to-do/partner-management-design.md 9.2; owner decisions section 10): a pack is an ordinary deal on the partner's account
/// plus a LOT (quantity, price snapshot, expiry); a win draws units from the partner's lots first-expiry-first-out (the draw itself is <c>PartnerCapture</c> job 4, in the
/// win's own save); expiry applies forfeit / credit / refund; a manager may override ONE pack's expiry or policy, correct its units, or spend a stock credit - each with a
/// reason, each a new movement, nothing edited. The two named figures of a deal and the distributor tree are read here too.
///
/// A WIN IS NEVER BLOCKED BY STOCK (owner 3.5): there is no refusal, no override-to-win and no chase task. A pack may go negative; it shows as such.
///
/// REUSE: partners and deals are <see cref="ChannelPartnerProcess"/>'s (visibility, attribution, the derived distributor rows); the figures come from the ONE resolver
/// (<see cref="PartnerRevenueView"/>); the masking is <see cref="Cp"/>'s Partner commercials level. A caller below a raw read sees "available / low / out" and never a count,
/// a price, a resale price or a credit.
/// </summary>
public sealed class PartnerStockProcess
{
    private readonly PartnerStockStore _stock;
    private readonly ChannelPartnerStore _partners;
    private readonly PartnerLedgerStore _ledger;
    private readonly ChannelPartnerProcess _channel;
    private readonly OrgSettingsReader _settings;
    private readonly PartnerRevenueView _revenue;

    public PartnerStockProcess(
        PartnerStockStore stock, ChannelPartnerStore partners, PartnerLedgerStore ledger, ChannelPartnerProcess channel, OrgSettingsReader settings, PartnerRevenueView revenue)
    {
        _stock = stock;
        _partners = partners;
        _ledger = ledger;
        _channel = channel;
        _settings = settings;
        _revenue = revenue;
    }

    public const int MaxPageSize = 200;
    public const int ExpiringSoonDays = 30;
    private const string EndClientPriceLabel = "End-client price";
    private const string OurRevenueLabel = "Our revenue (wholesale)";

    // ---- shared ------------------------------------------------------------------------------------

    private async Task<CpResult<ChannelPartnerStore.AccountFacts>> VisiblePartnerAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct)
    {
        var account = await _partners.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<ChannelPartnerStore.AccountFacts>("Account not found");
        return Cp.Ok(account);
    }

    private async Task<CpResult<ChannelPartnerStore.LeadFacts>> VisibleLeadAsync(RecordAccessContext ctx, Guid leadId, CancellationToken ct)
    {
        var lead = await _partners.LeadFactsAsync(leadId, ct);
        if (lead is null || !RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId)) return Cp.NotFound<ChannelPartnerStore.LeadFacts>("Deal not found");
        return Cp.Ok(lead);
    }

    private static CpResult<T> NeedsWrite<T>() => Cp.Invalid<T>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);

    /// <summary>available / low / out from a balance and the pack's optional low-stock threshold.</summary>
    public static string AvailabilityOf(decimal balance, decimal? threshold) =>
        balance <= 0m ? StockAvailability.Out : threshold is { } t && balance <= t ? StockAvailability.Low : StockAvailability.Available;

    private static string Clean(string? s, int max)
    {
        var t = (s ?? "").Trim();
        return t.Length > max ? t[..max] : t;
    }

    // ---- lots -------------------------------------------------------------------------------------

    private async Task<List<PartnerStockLotDto>> LotDtosAsync(List<PartnerStockLot> lots, bool commercials, CancellationToken ct)
    {
        if (lots.Count == 0) return [];
        var balances = await _stock.BalancesAsync(lots, ct);
        var totals = await _stock.MovementTotalsAsync(lots.Select(l => l.Id).ToList(), ct);
        var names = await _partners.AccountNamesAsync(lots.Select(l => l.PartnerAccountId).Distinct().ToList(), ct);
        var leadNames = await _ledger.LeadNamesAsync(lots.Select(l => l.PurchaseLeadId).Distinct().ToList(), ct);
        var now = DateTime.UtcNow;
        return lots.Select(l =>
        {
            var balance = balances.GetValueOrDefault(l.Id);
            var t = totals.GetValueOrDefault(l.Id);
            decimal? Show(decimal v) => commercials ? v : null;
            return new PartnerStockLotDto(
                l.Id, l.PartnerAccountId, names.GetValueOrDefault(l.PartnerAccountId), l.PurchaseLeadId, leadNames.GetValueOrDefault(l.PurchaseLeadId), l.PurchaseInvoiceId, l.CatalogItemId,
                l.UnitLabel, Show(l.QuantityBought), Show(l.UnitWholesalePrice), Show(balance), Show(t?.Drawn ?? 0m), Show(t?.Expired ?? 0m),
                Show(PartnerStockMath.Value(l.QuantityBought, l.UnitWholesalePrice)),
                l.PurchasedAt, commercials ? l.ActivatesOn : null, commercials ? l.ExpiresAt : null, l.ExpiryPolicy, l.PlanVersionId, commercials ? l.LowStockThreshold : null,
                l.ExpiresAt is { } e && e <= now, t?.HasOverdrawn ?? false, AvailabilityOf(balance, l.LowStockThreshold), commercials ? l.Note : null, l.CreatedAt);
        }).ToList();
    }

    /// <summary>A partner's stock tab: lots and the totals over them. Below a raw Partner commercials read, only the availability.</summary>
    public async Task<CpResult<PartnerStockSummaryDto>> SummaryAsync(RecordAccessContext ctx, Guid partnerAccountId, CancellationToken ct = default)
    {
        var partner = await VisiblePartnerAsync(ctx, partnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<PartnerStockSummaryDto, ChannelPartnerStore.AccountFacts>(partner);
        var commercials = Cp.CanReadCommercials(ctx);
        var lots = await _stock.ListLotsAsync(partnerAccountId, ct);
        var dtos = await LotDtosAsync(lots, commercials, ct);

        var balances = await _stock.BalancesAsync(lots, ct);
        var totals = await _stock.MovementTotalsAsync(lots.Select(l => l.Id).ToList(), ct);
        var live = lots.Where(l => l.ExpiresAt is null || l.ExpiresAt > DateTime.UtcNow).ToList();
        var balance = live.Sum(l => balances.GetValueOrDefault(l.Id));
        var threshold = live.Sum(l => l.LowStockThreshold ?? 0m);
        var availability = lots.Count == 0 ? StockAvailability.Out : AvailabilityOf(balance, threshold > 0m ? threshold : null);
        decimal? Show(decimal v) => commercials ? v : null;
        return Cp.Ok(new PartnerStockSummaryDto(
            partnerAccountId, partner.Value!.Name, dtos,
            Show(lots.Sum(l => l.QuantityBought)), Show(totals.Values.Sum(t => t.Drawn)), Show(totals.Values.Sum(t => t.Expired)), Show(balance),
            Show(lots.Sum(l => PartnerStockMath.Value(l.QuantityBought, l.UnitWholesalePrice))), Show(totals.Values.Sum(t => t.ValueDrawn)),
            Show(lots.Where(l => l.ExpiryPolicy == ChannelPartnerVocab.StockExpiryPolicy.Forfeit).Sum(l => totals.GetValueOrDefault(l.Id)?.ExpiredValue ?? 0m)),
            commercials ? await _stock.CreditBalanceAsync(partnerAccountId, ct) : null,
            availability, !commercials));
    }

    /// <summary>One lot's (or the partner's) movements, newest first.</summary>
    public async Task<CpResult<PartnerStockMovementPageDto>> MovementsAsync(
        RecordAccessContext ctx, Guid partnerAccountId, Guid? lotId, string? kind, int skip, int take, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return Cp.Forbidden<PartnerStockMovementPageDto>("Your role can't see partner commercials.", "partner_commercials_hidden");
        var partner = await VisiblePartnerAsync(ctx, partnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<PartnerStockMovementPageDto, ChannelPartnerStore.AccountFacts>(partner);
        if (!string.IsNullOrWhiteSpace(kind) && Array.IndexOf(ChannelPartnerVocab.StockKind.All, kind) < 0)
            return Cp.Invalid<PartnerStockMovementPageDto>("kind must be drawdown, return, expiry, adjustment, override, credit_issued or credit_applied.", "bad_kind");
        var (rows, total) = await _stock.MovementPageAsync(partnerAccountId, lotId, string.IsNullOrWhiteSpace(kind) ? null : kind, Math.Max(0, skip), Math.Clamp(take <= 0 ? 50 : take, 1, MaxPageSize), ct);
        var leadNames = await _ledger.LeadNamesAsync(rows.Where(r => r.LeadId != null).Select(r => r.LeadId!.Value).Distinct().ToList(), ct);
        return Cp.Ok(new PartnerStockMovementPageDto(
            rows.Select(m => new PartnerStockMovementDto(
                m.Id, m.LotId, m.Kind, m.Delta, m.Value, m.LeadId, m.LeadId is Guid l ? leadNames.GetValueOrDefault(l) : null, m.DealPartnerId, m.Reason, m.Overdrawn, m.At, m.ById)).ToList(),
            total));
    }

    /// <summary>
    /// Records a pack: the lot for a purchase deal that is ALREADY an ordinary deal on the partner's account (its invoices and payments, receivables, aging and loyalty are the
    /// existing ones). Expiry, its policy and when the clock starts follow the partner's plan unless the manager states otherwise. Deals the partner already won are then drawn
    /// against it, and a distributor on a non-drawdown plan (model T1) is attached to the purchase deal.
    /// </summary>
    public async Task<CpResult<PartnerStockLotDto>> RecordLotAsync(RecordAccessContext ctx, Guid partnerAccountId, PartnerStockLotInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerStockLotDto>();
        var partner = await VisiblePartnerAsync(ctx, partnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<PartnerStockLotDto, ChannelPartnerStore.AccountFacts>(partner);
        if (await _partners.ReadProfileAsync(partnerAccountId, ct) is null)
            return Cp.Invalid<PartnerStockLotDto>("That account isn't a channel partner yet. Make it one first.", "not_a_partner");
        if (input.PurchaseLeadId is not Guid leadId) return Cp.Invalid<PartnerStockLotDto>("Pick the deal the partner bought the pack on.", "purchase_deal_required");
        var lead = await VisibleLeadAsync(ctx, leadId, ct);
        if (!lead.IsOk) return Cp.As<PartnerStockLotDto, ChannelPartnerStore.LeadFacts>(lead);
        if (lead.Value!.AccountId != partnerAccountId)
            return Cp.Invalid<PartnerStockLotDto>("The pack's deal must be a deal on the partner's own account.", "purchase_deal_not_on_partner");
        if (input.Quantity is not > 0m) return Cp.Invalid<PartnerStockLotDto>("Enter how many units the partner bought.", "quantity_required");
        if (input.UnitWholesalePrice is not > 0m) return Cp.Invalid<PartnerStockLotDto>("Enter the wholesale price of one unit (ex VAT).", "price_required");
        if (input.LowStockThreshold is < 0m) return Cp.Invalid<PartnerStockLotDto>("The low-stock level cannot be negative.", "bad_threshold");
        if (input.ExpiryPolicy is not null && Array.IndexOf(ChannelPartnerVocab.StockExpiryPolicy.All, input.ExpiryPolicy) < 0)
            return Cp.Invalid<PartnerStockLotDto>("Expiry is forfeit, credit or refund.", "bad_expiry_policy");
        if (input.PurchaseInvoiceId is Guid invoiceId && !await _stock.InvoiceBelongsToLeadAsync(invoiceId, leadId, ct))
            return Cp.Invalid<PartnerStockLotDto>("That invoice isn't an invoice of the pack's deal.", "bad_invoice");

        // The partner's plan decides the defaults (policy, lifetime, when the clock starts): a setting, not a rule in code.
        var resolved = await _partners.ResolveAttributionAsync(partnerAccountId, null, ct);
        var plan = resolved is null ? null : await _partners.PlanContentAsync(resolved.PlanVersionId, ct);
        var now = DateTime.UtcNow;
        var (wonAt, invoicedAt, paidAt, _) = await _stock.PurchaseMilestonesAsync(leadId, ct);
        var activatesOn = (plan?.StockActivatesOn ?? ChannelPartnerVocab.StockActivatesOn.Signed) switch
        {
            ChannelPartnerVocab.StockActivatesOn.Invoiced => invoicedAt ?? now,
            ChannelPartnerVocab.StockActivatesOn.Paid => paidAt ?? now,
            _ => wonAt ?? now,
        };
        var expiresAt = input.ExpiresAt ?? (plan?.StockExpiryMonths is int months ? activatesOn.AddMonths(months) : null);

        var lot = new PartnerStockLot
        {
            Id = Guid.NewGuid(),
            PartnerAccountId = partnerAccountId,
            PurchaseLeadId = leadId,
            PurchaseInvoiceId = input.PurchaseInvoiceId,
            CatalogItemId = input.CatalogItemId,
            UnitLabel = string.IsNullOrWhiteSpace(input.UnitLabel) ? "unit" : Clean(input.UnitLabel, 60),
            QuantityBought = input.Quantity.Value,
            UnitWholesalePrice = input.UnitWholesalePrice.Value,
            PurchasedAt = input.PurchasedAt ?? now,
            ActivatesOn = activatesOn,
            ExpiresAt = expiresAt,
            ExpiryPolicy = input.ExpiryPolicy ?? plan?.StockExpiryPolicy ?? ChannelPartnerVocab.StockExpiryPolicy.Forfeit,
            PlanVersionId = resolved?.PlanVersionId,
            LowStockThreshold = input.LowStockThreshold,
            Note = string.IsNullOrWhiteSpace(input.Note) ? null : Clean(input.Note, 1000),
            CreatedById = actorId,
        };
        _stock.AddLot(lot);
        await _stock.SaveChangesAsync(ct);

        // Wins that came before the pack are drawn now, and the distributor above a sub-reseller earns on its purchase (model T1, when its plan says so).
        await _stock.DrawForPartnerAsync(partnerAccountId, actorId, ct);
        await _channel.AttachDistributorsAsync(ctx, leadId, partnerAccountId, drawdownPlans: false, actorId, ct);

        var fresh = await _stock.FindLotAsync(lot.Id, ct);
        return Cp.Ok((await LotDtosAsync([fresh!], true, ct))[0]);
    }

    /// <summary>
    /// A manager changes ONE pack's expiry date and / or policy before it has expired, with a reason. Written as a zero-delta `override` movement whose reason carries the old and
    /// new values, so there is no separate override table and the change is on the pack's own history.
    /// </summary>
    public async Task<CpResult<PartnerStockLotDto>> OverrideLotAsync(RecordAccessContext ctx, Guid lotId, PartnerStockOverrideInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerStockLotDto>();
        var lot = await _stock.FindLotAsync(lotId, ct);
        if (lot is null) return Cp.NotFound<PartnerStockLotDto>("Pack not found");
        var partner = await VisiblePartnerAsync(ctx, lot.PartnerAccountId, ct);
        if (!partner.IsOk) return Cp.NotFound<PartnerStockLotDto>("Pack not found");
        var reason = input.Reason?.Trim();
        if (string.IsNullOrEmpty(reason)) return Cp.Invalid<PartnerStockLotDto>("A reason is required to change a pack.", "reason_required");
        if (input.ExpiresAt is null && !input.ClearExpiry && input.ExpiryPolicy is null) return Cp.Invalid<PartnerStockLotDto>("Change the expiry date or the policy.", "nothing_to_change");
        if (input.ExpiryPolicy is not null && Array.IndexOf(ChannelPartnerVocab.StockExpiryPolicy.All, input.ExpiryPolicy) < 0)
            return Cp.Invalid<PartnerStockLotDto>("Expiry is forfeit, credit or refund.", "bad_expiry_policy");
        if (await _stock.MovementCountAsync(lot.Id, ChannelPartnerVocab.StockKind.Expiry, ct) > 0)
            return Cp.Conflict<PartnerStockLotDto>("This pack has already expired. Correct the units with an adjustment instead.", "already_expired");

        var changes = new List<string>();
        if (input.ClearExpiry && lot.ExpiresAt != null) { changes.Add($"expires {lot.ExpiresAt:yyyy-MM-dd} -> never"); lot.ExpiresAt = null; }
        else if (input.ExpiresAt is { } to && lot.ExpiresAt != to) { changes.Add($"expires {(lot.ExpiresAt is { } o ? o.ToString("yyyy-MM-dd") : "never")} -> {to:yyyy-MM-dd}"); lot.ExpiresAt = to; }
        if (input.ExpiryPolicy is { } policy && lot.ExpiryPolicy != policy) { changes.Add($"policy {lot.ExpiryPolicy} -> {policy}"); lot.ExpiryPolicy = policy; }
        if (changes.Count == 0) return Cp.Invalid<PartnerStockLotDto>("That is already how the pack is set.", "nothing_to_change");

        _stock.AddMovement(new PartnerStockMovement
        {
            Id = Guid.NewGuid(), LotId = lot.Id, Kind = ChannelPartnerVocab.StockKind.Override, Delta = 0m,
            SourceKey = $"manual:override:{Guid.NewGuid()}", Reason = Clean($"{reason} ({string.Join("; ", changes)})", 1000), At = DateTime.UtcNow, ById = actorId,
        });
        await _stock.SaveChangesAsync(ct);
        return Cp.Ok((await LotDtosAsync([lot], true, ct))[0]);
    }

    /// <summary>A manager corrects the units on a pack (add or remove), with a reason. It never takes a pack below zero (that is what a win does, not a correction).</summary>
    public async Task<CpResult<PartnerStockLotDto>> AdjustLotAsync(RecordAccessContext ctx, Guid lotId, PartnerStockAdjustInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerStockLotDto>();
        var lot = await _stock.FindLotAsync(lotId, ct);
        if (lot is null) return Cp.NotFound<PartnerStockLotDto>("Pack not found");
        var partner = await VisiblePartnerAsync(ctx, lot.PartnerAccountId, ct);
        if (!partner.IsOk) return Cp.NotFound<PartnerStockLotDto>("Pack not found");
        var reason = input.Reason?.Trim();
        if (string.IsNullOrEmpty(reason)) return Cp.Invalid<PartnerStockLotDto>("A reason is required to correct a pack.", "reason_required");
        if (input.Delta is not { } delta || delta == 0m) return Cp.Invalid<PartnerStockLotDto>("Enter how many units to add or remove.", "delta_required");
        var balance = (await _stock.BalancesAsync([lot], ct)).GetValueOrDefault(lot.Id);
        if (balance + delta < 0m) return Cp.Conflict<PartnerStockLotDto>($"That would take the pack below zero (it holds {balance:0.####}).", "below_zero");

        _stock.AddMovement(new PartnerStockMovement
        {
            Id = Guid.NewGuid(), LotId = lot.Id, Kind = ChannelPartnerVocab.StockKind.Adjustment, Delta = delta,
            SourceKey = $"manual:adjustment:{Guid.NewGuid()}", Reason = Clean(reason, 1000), At = DateTime.UtcNow, ById = actorId,
        });
        await _stock.SaveChangesAsync(ct);
        return Cp.Ok((await LotDtosAsync([lot], true, ct))[0]);
    }

    /// <summary>Spends (part of) a partner's stock credit against a new pack. The new invoice is external; this records that the credit was used, as a movement.</summary>
    public async Task<CpResult<PartnerStockLotDto>> ApplyCreditAsync(RecordAccessContext ctx, PartnerStockCreditApplyInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerStockLotDto>();
        if (input.PartnerAccountId is not Guid partnerId) return Cp.Invalid<PartnerStockLotDto>("Pick the partner.", "partner_required");
        var partner = await VisiblePartnerAsync(ctx, partnerId, ct);
        if (!partner.IsOk) return Cp.As<PartnerStockLotDto, ChannelPartnerStore.AccountFacts>(partner);
        if (input.LotId is not Guid lotId || await _stock.FindLotAsync(lotId, ct) is not { } lot || lot.PartnerAccountId != partnerId)
            return Cp.Invalid<PartnerStockLotDto>("Pick the partner's new pack to apply the credit to.", "lot_required");
        var reason = input.Reason?.Trim();
        if (string.IsNullOrEmpty(reason)) return Cp.Invalid<PartnerStockLotDto>("A reason is required.", "reason_required");
        if (input.Amount is not > 0m) return Cp.Invalid<PartnerStockLotDto>("Enter the credit to apply.", "amount_required");
        var amount = PartnerPlanEngine.Money(input.Amount.Value);
        var credit = await _stock.CreditBalanceAsync(partnerId, ct);
        if (amount > credit) return Cp.Conflict<PartnerStockLotDto>($"The partner holds {credit:0.00} of credit.", "not_enough_credit");

        _stock.AddMovement(new PartnerStockMovement
        {
            Id = Guid.NewGuid(), LotId = lot.Id, Kind = ChannelPartnerVocab.StockKind.CreditApplied, Delta = 0m, Value = -amount,
            SourceKey = $"manual:credit_applied:{Guid.NewGuid()}", Reason = Clean(reason, 1000), At = DateTime.UtcNow, ById = actorId,
        });
        await _stock.SaveChangesAsync(ct);
        return Cp.Ok((await LotDtosAsync([lot], true, ct))[0]);
    }

    /// <summary>The cross-partner stock page: one row per partner holding stock; expiring soon, low and negative packs counted. Rows follow each partner's visibility.</summary>
    public async Task<CpResult<PartnerStockOverviewDto>> OverviewAsync(RecordAccessContext ctx, int expiringWithinDays, CancellationToken ct = default)
    {
        var commercials = Cp.CanReadCommercials(ctx);
        var days = Math.Clamp(expiringWithinDays <= 0 ? ExpiringSoonDays : expiringWithinDays, 1, 3650);
        var lots = await _stock.ListLotsAsync(null, ct);
        var ids = lots.Select(l => l.PartnerAccountId).Distinct().ToList();
        var facts = await _partners.AccountFactsManyAsync(ids, ct);
        lots = lots.Where(l => facts.TryGetValue(l.PartnerAccountId, out var f) && RecordAccess.CanView(ctx, f.OwnerId, f.TeamId)).ToList();
        var balances = await _stock.BalancesAsync(lots, ct);
        var totals = await _stock.MovementTotalsAsync(lots.Select(l => l.Id).ToList(), ct);
        var now = DateTime.UtcNow;
        var horizon = now.AddDays(days);
        var tiers = new Dictionary<Guid, string?>();
        foreach (var id in lots.Select(l => l.PartnerAccountId).Distinct()) tiers[id] = (await _partners.ReadProfileAsync(id, ct))?.Tier;

        var rows = new List<PartnerStockOverviewRowDto>();
        foreach (var g in lots.GroupBy(l => l.PartnerAccountId))
        {
            var live = g.Where(l => l.ExpiresAt is null || l.ExpiresAt > now).ToList();
            var balance = live.Sum(l => balances.GetValueOrDefault(l.Id));
            var threshold = live.Sum(l => l.LowStockThreshold ?? 0m);
            decimal? Show(decimal v) => commercials ? v : null;
            rows.Add(new PartnerStockOverviewRowDto(
                g.Key, facts[g.Key].Name, tiers.GetValueOrDefault(g.Key), Show(balance),
                Show(g.Sum(l => PartnerStockMath.Value(l.QuantityBought, l.UnitWholesalePrice))), Show(g.Sum(l => totals.GetValueOrDefault(l.Id)?.ValueDrawn ?? 0m)),
                commercials ? await _stock.CreditBalanceAsync(g.Key, ct) : null,
                g.Count(), live.Count(l => l.ExpiresAt is { } e && e <= horizon && balances.GetValueOrDefault(l.Id) > 0m),
                live.Count(l => AvailabilityOf(balances.GetValueOrDefault(l.Id), l.LowStockThreshold) == StockAvailability.Low),
                g.Count(l => balances.GetValueOrDefault(l.Id) < 0m),
                live.Where(l => l.ExpiresAt != null && balances.GetValueOrDefault(l.Id) > 0m).Select(l => l.ExpiresAt).Min(),
                AvailabilityOf(balance, threshold > 0m ? threshold : null)));
        }
        return Cp.Ok(new PartnerStockOverviewDto(rows.OrderBy(r => r.PartnerName).ToList(), days, !commercials));
    }

    // ---- a deal partner's stock facts ---------------------------------------------------------------

    private async Task<CpResult<DealPartnerStockDto>> StockDtoAsync(RecordAccessContext ctx, DealPartner dp, ChannelPartnerStore.LeadFacts lead, CancellationToken ct)
    {
        var commercials = Cp.CanReadCommercials(ctx);
        var plan = dp.PlanVersionId is Guid vid ? await _partners.PlanContentAsync(vid, ct) : null;
        var suggested = await _stock.SuggestedUnitsAsync(lead.Id, plan?.DrawdownUnitsInput, ct);
        var available = await _stock.AvailableAsync(dp.PartnerAccountId, plan?.SubResellersDrawFromParent ?? false, ct);
        var sold = (await _stock.PurchaseMilestonesAsync(lead.Id, ct)).Sold;
        var renewalDraws = plan?.RenewalDrawsStock ?? true;
        var renewals = renewalDraws ? await _stock.RenewalTermsStartedAsync(lead.Id, ct) : 0;
        var drawn = await _stock.DrawnUnitsAsync(dp.Id, ct);
        decimal? Show(decimal? v) => commercials ? v : null;
        var availability = available is null ? StockAvailability.Out : AvailabilityOf(available.Value.Available, available.Value.ThresholdSum > 0m ? available.Value.ThresholdSum : null);
        return Cp.Ok(new DealPartnerStockDto(
            dp.Id, lead.Id, dp.PartnerAccountId, dp.Role, plan?.DrawdownUnitsInput,
            Show(dp.StockUnits), Show(suggested), Show(drawn), Show(dp.ResalePrice), Show(dp.WholesaleAmount),
            Show(available?.Available), availability, !sold && dp.EndedAt == null, renewalDraws, renewals));
    }

    public async Task<CpResult<DealPartnerStockDto>> DealPartnerStockAsync(RecordAccessContext ctx, Guid leadId, Guid dealPartnerId, CancellationToken ct = default)
    {
        var lead = await VisibleLeadAsync(ctx, leadId, ct);
        if (!lead.IsOk) return Cp.As<DealPartnerStockDto, ChannelPartnerStore.LeadFacts>(lead);
        var dp = await _partners.FindDealPartnerAsync(dealPartnerId, ct);
        if (dp is null || dp.LeadId != leadId) return Cp.NotFound<DealPartnerStockDto>("Deal partner not found");
        return await StockDtoAsync(ctx, dp, lead.Value!, ct);
    }

    /// <summary>
    /// Sets the stock facts of a RESELLER deal partner: the units the deal draws (prefilled from the accepted proposal; editable only until the deal is won - owner 3.2), the
    /// partner's resale price (informational, the only price a white-label document may print) and the wholesale amount we expect when no stock is drawn.
    /// </summary>
    public async Task<CpResult<DealPartnerStockDto>> SetDealPartnerStockAsync(
        RecordAccessContext ctx, Guid leadId, Guid dealPartnerId, DealPartnerStockInput input, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<DealPartnerStockDto>();
        var lead = await VisibleLeadAsync(ctx, leadId, ct);
        if (!lead.IsOk) return Cp.As<DealPartnerStockDto, ChannelPartnerStore.LeadFacts>(lead);
        var dp = await _partners.FindDealPartnerAsync(dealPartnerId, ct);
        if (dp is null || dp.LeadId != leadId) return Cp.NotFound<DealPartnerStockDto>("Deal partner not found");
        if (dp.Role != ChannelPartnerVocab.Role.Reseller) return Cp.Invalid<DealPartnerStockDto>("Stock applies to a reseller on the deal.", "not_a_reseller");
        if (dp.EndedAt != null) return Cp.Conflict<DealPartnerStockDto>("This attribution has ended.", "already_ended");
        if (input.StockUnits is < 0m || input.ResalePrice is < 0m || input.WholesaleAmount is < 0m)
            return Cp.Invalid<DealPartnerStockDto>("Units and prices cannot be negative.", "bad_amount");

        var unitsChange = input.ClearStockUnits ? dp.StockUnits != null : input.StockUnits is { } u && u != dp.StockUnits;
        if (unitsChange && (await _stock.PurchaseMilestonesAsync(leadId, ct)).Sold)
            return Cp.Conflict<DealPartnerStockDto>("The deal is won, so the units it drew are fixed. Reopen the deal to change them.", "units_locked");

        if (input.ClearStockUnits) dp.StockUnits = null; else if (input.StockUnits is { } units) dp.StockUnits = units;
        if (input.ClearResalePrice) dp.ResalePrice = null; else if (input.ResalePrice is { } resale) dp.ResalePrice = PartnerPlanEngine.Money(resale);
        if (input.ClearWholesaleAmount) dp.WholesaleAmount = null; else if (input.WholesaleAmount is { } wholesale) dp.WholesaleAmount = PartnerPlanEngine.Money(wholesale);
        dp.UpdatedAt = DateTime.UtcNow;
        await _stock.SaveChangesAsync(ct);
        return await StockDtoAsync(ctx, dp, lead.Value!, ct);
    }

    // ---- the two named figures ---------------------------------------------------------------------

    /// <summary>A deal's two named figures from the ONE resolver. The end-client price is the deal's own and always visible to a viewer of the deal; our revenue and the resale price are Partner commercials.</summary>
    public async Task<CpResult<DealRevenueDto>> DealRevenueAsync(RecordAccessContext ctx, Guid leadId, CancellationToken ct = default)
    {
        var lead = await VisibleLeadAsync(ctx, leadId, ct);
        if (!lead.IsOk) return Cp.As<DealRevenueDto, ChannelPartnerStore.LeadFacts>(lead);
        var figure = await _revenue.ResolveAsync(leadId, ct);
        if (figure is null) return Cp.NotFound<DealRevenueDto>("Deal not found");
        var commercials = Cp.CanReadCommercials(ctx);
        return Cp.Ok(new DealRevenueDto(
            leadId, figure.EndClientPrice, EndClientPriceLabel,
            commercials ? figure.OurRevenue : null, OurRevenueLabel, figure.Kind, figure.IsAllocation,
            commercials ? figure.TotalledOurRevenue : null, commercials ? figure.ResalePrice : null, !commercials));
    }

    // ---- distributor tiers --------------------------------------------------------------------------

    /// <summary>The distributor and its sub-resellers (AccountRelationship distributor_for), to the org's MaxChannelDepth, with stock volumes and the override earned.</summary>
    public async Task<CpResult<DistributorTreeDto>> TreeAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default)
    {
        var root = await VisiblePartnerAsync(ctx, accountId, ct);
        if (!root.IsOk) return Cp.As<DistributorTreeDto, ChannelPartnerStore.AccountFacts>(root);
        var commercials = Cp.CanReadCommercials(ctx);
        var maxDepth = (await _settings.GetChannelPartnerSettingsAsync()).MaxChannelDepth;
        var edges = await _stock.DistributorEdgesAsync(ct);

        // Breadth-first from the root, bounded by the org's depth; a visited set makes a cycle in the data harmless.
        var levels = new Dictionary<Guid, (int Depth, Guid? Parent)> { [accountId] = (1, null) };
        var queue = new Queue<Guid>([accountId]);
        while (queue.Count > 0)
        {
            var node = queue.Dequeue();
            var depth = levels[node].Depth;
            if (depth >= maxDepth) continue;
            foreach (var sub in edges.Where(e => e.Distributor == node).Select(e => e.SubReseller))
                if (levels.TryAdd(sub, (depth + 1, node))) queue.Enqueue(sub);
        }
        var ids = levels.Keys.ToList();
        var names = await _partners.AccountNamesAsync(ids, ct);
        var stock = await _stock.StockByPartnerAsync(ids, ct);
        var earned = new Dictionary<Guid, Dictionary<Guid, decimal>>();
        if (commercials)
            foreach (var parent in levels.Where(kv => edges.Any(e => e.Distributor == kv.Key)).Select(kv => kv.Key))
                earned[parent] = await _stock.OverrideEarnedBySubResellerAsync(parent, ct);
        var profiles = new Dictionary<Guid, PartnerProfile?>();
        foreach (var id in ids) profiles[id] = await _partners.ReadProfileAsync(id, ct);

        DistributorNodeDto Build(Guid id)
        {
            var (depth, parent) = levels[id];
            var s = stock.GetValueOrDefault(id);
            var children = levels.Where(kv => kv.Value.Parent == id).Select(kv => Build(kv.Key)).OrderBy(c => c.Name).ToList();
            decimal? Show(decimal v) => commercials ? v : null;
            return new DistributorNodeDto(
                id, names.GetValueOrDefault(id) ?? "", depth, parent, profiles[id]?.Status, profiles[id]?.Tier,
                Show(s.Bought), Show(s.Drawn), Show(s.ValueDrawn),
                commercials && parent is Guid p && earned.TryGetValue(p, out var byChild) ? byChild.GetValueOrDefault(id) : null,
                s.Deals, children);
        }
        return Cp.Ok(new DistributorTreeDto(Build(accountId), maxDepth, !commercials));
    }

    /// <summary>
    /// May <paramref name="subResellerId"/> be added under <paramref name="distributorId"/>? Both must be channel partners, the edge must be new, must not close a cycle, and the
    /// chain must stay within the org's MaxChannelDepth (counting the distributor's own ancestors and the sub-reseller's own subtree). The edge itself is then added by the
    /// existing AccountProcess.AddRelationshipAsync - the Experience layer composes the two, so there is one way to add a relationship.
    /// </summary>
    public async Task<CpResult<bool>> CheckSubResellerAsync(RecordAccessContext ctx, Guid distributorId, Guid? subResellerId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<bool>();
        var distributor = await VisiblePartnerAsync(ctx, distributorId, ct);
        if (!distributor.IsOk) return Cp.As<bool, ChannelPartnerStore.AccountFacts>(distributor);
        if (subResellerId is not Guid subId) return Cp.Invalid<bool>("Pick the sub-reseller.", "sub_reseller_required");
        if (subId == distributorId) return Cp.Invalid<bool>("A partner cannot be its own sub-reseller.", "same_account");
        var sub = await VisiblePartnerAsync(ctx, subId, ct);
        if (!sub.IsOk) return Cp.As<bool, ChannelPartnerStore.AccountFacts>(sub);
        if (await _partners.ReadProfileAsync(distributorId, ct) is null || await _partners.ReadProfileAsync(subId, ct) is null)
            return Cp.Invalid<bool>("Both accounts must be channel partners first.", "not_a_partner");
        if (await _stock.RelationshipExistsAsync(distributorId, subId, ct)) return Cp.Conflict<bool>("That sub-reseller is already under this distributor.", "duplicate_relationship");

        var edges = await _stock.DistributorEdgesAsync(ct);
        // Longest chain above / below a node; a path set keeps a cycle in the data from looping.
        int Up(Guid id, HashSet<Guid> path) =>
            edges.Where(e => e.SubReseller == id && !path.Contains(e.Distributor)).Select(e => 1 + Up(e.Distributor, [.. path, e.Distributor])).DefaultIfEmpty(0).Max();
        int Down(Guid id, HashSet<Guid> path) =>
            edges.Where(e => e.Distributor == id && !path.Contains(e.SubReseller)).Select(e => 1 + Down(e.SubReseller, [.. path, e.SubReseller])).DefaultIfEmpty(0).Max();
        if (IsAncestor(edges, subId, distributorId)) return Cp.Conflict<bool>("That would put a partner under itself.", "cycle");
        var maxDepth = (await _settings.GetChannelPartnerSettingsAsync()).MaxChannelDepth;
        // Levels in the chain once joined: the distributor's own level (its ancestors + itself), then the sub-reseller and everything below it.
        var levels = Up(distributorId, [distributorId]) + 1 + 1 + Down(subId, [subId]);
        if (levels > maxDepth)
            return Cp.Conflict<bool>($"Your organization allows {maxDepth} level(s) of distributors. Raise the limit in channel-partner settings to go deeper.", "too_deep");
        return Cp.Ok(true);
    }

    private static bool IsAncestor(List<(Guid Distributor, Guid SubReseller)> edges, Guid candidate, Guid of)
    {
        var seen = new HashSet<Guid> { of };
        var stack = new Stack<Guid>([of]);
        while (stack.Count > 0)
        {
            var node = stack.Pop();
            foreach (var d in edges.Where(e => e.SubReseller == node).Select(e => e.Distributor))
            {
                if (d == candidate) return true;
                if (seen.Add(d)) stack.Push(d);
            }
        }
        return false;
    }
}

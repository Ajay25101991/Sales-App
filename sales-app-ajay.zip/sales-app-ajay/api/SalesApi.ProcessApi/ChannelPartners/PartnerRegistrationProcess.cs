using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// Registration, the pipeline flag and claim conflicts (Phase 2; owner decisions 2026-10-19):
///
///  - REGISTRATION IS A RECORD ("none - just record"). A person records the date, the status (registered | accepted | declined) and notes on a deal partner; the CRM starts no
///    timer, expires nothing, blocks nothing and pays nothing differently because of it. Raw Partner commercials readers see all of it, masked readers the status, hidden
///    readers only that the client is "protected by a partner registration".
///  - A REFERRAL FOR A CLIENT ALREADY IN THE PIPELINE is flagged on its deal partner row when attributed (see ChannelPartnerProcess.AttributeAsync) with the matched open deals,
///    and DECIDED THERE (accept / decline + a reason to decline) by the deal owner or a partner manager. The decision is a record; it moves no money.
///  - TWO PARTNERS CLAIMING ONE CLIENT is ALWAYS a manager decision: a PartnerRegistrationConflict plus an admin-queue task. The manager records whose claim stands (or both) and
///    why; nothing changes automatically - the manager then sets each registration status.
///
/// Reuse: ChannelPartnerProcess.ToDtosAsync shapes the queue rows (one deal-partner shape, one masking); DuplicateMatchService (extended with an account level) finds the
/// matches; TaskItems shapes the task. Authorization stays at the HTTP layer; the caller's Partner commercials level arrives in the access context.
/// </summary>
public sealed class PartnerRegistrationProcess
{
    private readonly PartnerRegistrationStore _store;
    private readonly ChannelPartnerStore _partners;
    private readonly ChannelPartnerProcess _dealPartners;

    public PartnerRegistrationProcess(PartnerRegistrationStore store, ChannelPartnerStore partners, ChannelPartnerProcess dealPartners)
    {
        _store = store;
        _partners = partners;
        _dealPartners = dealPartners;
    }

    private const int MaxNotes = 2000;

    private static CpResult<T> NeedsCommercials<T>() => Cp.Forbidden<T>("Your role can't see partner commercials.", "partner_commercials_hidden");
    private static CpResult<T> NeedsWrite<T>() => Cp.Invalid<T>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);

    /// <summary>The deal partner (tracked) and its deal, visible to the caller; a deal they cannot see reads exactly like a missing one.</summary>
    private async Task<(DealPartner? Dp, ChannelPartnerStore.LeadFacts? Lead, CpResult<DealPartnerDto>? Refusal)> LoadAsync(RecordAccessContext ctx, Guid dealPartnerId, CancellationToken ct)
    {
        var dp = await _partners.FindDealPartnerAsync(dealPartnerId, ct);
        if (dp is null) return (null, null, Cp.NotFound<DealPartnerDto>("Deal partner not found"));
        var lead = await _partners.LeadFactsAsync(dp.LeadId, ct);
        if (lead is null || !RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId)) return (null, null, Cp.NotFound<DealPartnerDto>("Deal partner not found"));
        return (dp, lead, null);
    }

    private async Task<CpResult<DealPartnerDto>> DtoAsync(RecordAccessContext ctx, DealPartner dp, CancellationToken ct)
    {
        var rows = await _partners.ListDealPartnersAsync(dp.LeadId, includeEnded: true, ct);
        return Cp.Ok((await _dealPartners.ToDtosAsync(rows, ctx, ct)).First(d => d.Id == dp.Id));
    }

    // ---- the queue ---------------------------------------------------------------------------------

    /// <summary>
    /// Deal partners that carry a registration (<paramref name="registrationStatus"/> narrows to one status), or - with <paramref name="pipelinePending"/> - referrals flagged
    /// against the pipeline and not yet decided. Each row follows its deal's visibility and the caller's masking.
    /// </summary>
    public async Task<CpResult<List<DealPartnerDto>>> ListAsync(RecordAccessContext ctx, string? registrationStatus, bool pipelinePending, CancellationToken ct = default)
    {
        if (!string.IsNullOrWhiteSpace(registrationStatus) && Array.IndexOf(ChannelPartnerVocab.Registration.Settable, registrationStatus) < 0)
            return Cp.Invalid<List<DealPartnerDto>>("status must be registered, accepted or declined.", "bad_status");
        var rows = (await _store.ListAsync(string.IsNullOrWhiteSpace(registrationStatus) ? null : registrationStatus, pipelinePending, ct))
            .Where(d => d.Lead is not null && RecordAccess.CanView(ctx, d.Lead.OwnerId, d.Lead.TeamId)).ToList();
        return Cp.Ok(await _dealPartners.ToDtosAsync(rows, ctx, ct));
    }

    // ---- registration: a record ------------------------------------------------------------------------

    /// <summary>
    /// Records (or changes) a partner's registration of the client on this deal. Nothing else happens because of it: no deadline, no block, no accrual change. A person sets the
    /// status every time; <c>none</c> clears the record. Recording a protecting status re-checks for another partner's claim on the same client.
    /// </summary>
    public async Task<CpResult<DealPartnerDto>> RecordAsync(
        RecordAccessContext ctx, Guid dealPartnerId, DealPartnerRegistrationInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<DealPartnerDto>();
        var (dp, _, refusal) = await LoadAsync(ctx, dealPartnerId, ct);
        if (refusal is not null) return refusal;
        if (dp!.EndedAt != null) return Cp.Conflict<DealPartnerDto>("This attribution has ended.", "already_ended");

        var status = input.Status?.Trim().ToLowerInvariant();
        if (status is not null && Array.IndexOf(ChannelPartnerVocab.Registration.All, status) < 0)
            return Cp.Invalid<DealPartnerDto>("Registration status is registered, accepted or declined (none clears it).", "bad_status");
        if (status is null && dp.RegistrationStatus == ChannelPartnerVocab.Registration.None)
            return Cp.Invalid<DealPartnerDto>("Say whether the partner has registered this client.", "status_required");
        var notes = input.Notes?.Trim();
        if (notes is { Length: > MaxNotes }) return Cp.Invalid<DealPartnerDto>($"Notes are at most {MaxNotes} characters.", "notes_too_long");
        if (input.RegisteredOn is { } on && (on.Year < 2000 || on.Year > 2100)) return Cp.Invalid<DealPartnerDto>("That registration date isn't right.", "bad_date");

        var now = DateTime.UtcNow;
        var next = status ?? dp.RegistrationStatus;
        if (next == ChannelPartnerVocab.Registration.None)
        {
            dp.RegistrationStatus = ChannelPartnerVocab.Registration.None;
            dp.RegisteredOn = null; dp.RegisteredById = null; dp.RegistrationNotes = null;
            dp.RegistrationDecidedAt = null; dp.RegistrationDecidedById = null;
        }
        else
        {
            var first = dp.RegistrationStatus == ChannelPartnerVocab.Registration.None;
            dp.RegistrationStatus = next;
            if (first)
            {
                dp.RegisteredById = actorId;
                dp.RegisteredOn = input.RegisteredOn ?? ReportingCalendar.Today(await _store.CalendarAsync());
            }
            else if (input.RegisteredOn is { } changed) dp.RegisteredOn = changed;
            if (notes is not null) dp.RegistrationNotes = notes.Length == 0 ? null : notes;
            if (next is ChannelPartnerVocab.Registration.Accepted or ChannelPartnerVocab.Registration.Declined)
            {
                dp.RegistrationDecidedAt = now;
                dp.RegistrationDecidedById = actorId;
            }
            else { dp.RegistrationDecidedAt = null; dp.RegistrationDecidedById = null; }
        }
        dp.UpdatedAt = now;

        if (ChannelPartnerVocab.Registration.Protects(dp.RegistrationStatus)) await _partners.RaiseClaimConflictsAsync(dp, actorId, ct);
        await _store.SaveChangesAsync(ct);
        return await DtoAsync(ctx, dp, ct);
    }

    // ---- a referral for a client already in the pipeline: decided on the deal -----------------------------

    /// <summary>
    /// Accept or decline a flagged referral. Only the deal owner or a partner manager (<paramref name="isPartnerManager"/>, from partners.manage at the HTTP layer); a decline needs a
    /// reason. The decision is recorded on the deal partner row and nothing else changes - ending the attribution, if the owner wants it, is the existing end action.
    /// </summary>
    public async Task<CpResult<DealPartnerDto>> DecidePipelineAsync(
        RecordAccessContext ctx, Guid dealPartnerId, PipelineDecisionInput input, Guid actorId, bool isPartnerManager, CancellationToken ct = default)
    {
        // Owner Q3: the owner of THIS deal, the owner of any MATCHED open deal, or a partner manager. The owner of a matched deal may not see this deal at all, so visibility of
        // this deal is not required of them (the response is shaped for their own access).
        var dp = await _partners.FindDealPartnerAsync(dealPartnerId, ct);
        var lead = dp is null ? null : await _partners.LeadFactsAsync(dp.LeadId, ct);
        if (dp is null || lead is null) return Cp.NotFound<DealPartnerDto>("Deal partner not found");
        var matchedOwners = dp.PipelineStatus is null ? []
            : (await _store.LeadFactsManyAsync(PartnerRegistrations.ReadMatchedLeadIds(dp.PipelineMatchLeadIds), ct)).Values.Where(l => l.OwnerId == ctx.UserId).ToList();
        if (!isPartnerManager && matchedOwners.Count == 0 && !RecordAccess.CanView(ctx, lead.OwnerId, lead.TeamId))
            return Cp.NotFound<DealPartnerDto>("Deal partner not found");
        if (dp.PipelineStatus is null) return Cp.Conflict<DealPartnerDto>("This referral isn't flagged against the pipeline.", "no_pipeline_flag");
        // A decision may be CHANGED (owner Q2: a declined referral can be accepted later and then back-accrues); repeating the same answer is the only refusal.
        var answer = input.Accept ? ChannelPartnerVocab.PipelineDecision.Accepted : ChannelPartnerVocab.PipelineDecision.Declined;
        if (dp.PipelineStatus == answer)
            return Cp.Conflict<DealPartnerDto>("This referral has already been decided that way.", "already_decided");
        if (!isPartnerManager && lead.OwnerId != ctx.UserId && matchedOwners.Count == 0)
            return Cp.Forbidden<DealPartnerDto>("Only the owner of this deal or of a matching open deal, or a partner manager, can decide this referral.", "not_deal_owner");
        var reason = input.Reason?.Trim();
        if (!input.Accept && string.IsNullOrEmpty(reason)) return Cp.Invalid<DealPartnerDto>("A reason is required to decline a referral.", "reason_required");
        if (reason is { Length: > 1000 }) return Cp.Invalid<DealPartnerDto>("The reason is at most 1000 characters.", "reason_too_long");

        dp.PipelineStatus = answer;
        dp.PipelineDecisionReason = string.IsNullOrEmpty(reason) ? null : reason;
        dp.PipelineDecidedAt = DateTime.UtcNow;
        dp.PipelineDecidedById = actorId;
        dp.UpdatedAt = DateTime.UtcNow;
        await _store.SaveChangesAsync(ct);
        // Owner Q2: a declined referral earns nothing (target 0, an earlier accrual is clawed back by the existing path) and an accepted one back-accrues (F2): reconcile the deal now.
        await _partners.AccrueNowAsync(dp.LeadId, actorId, ct);
        return await DtoAsync(ctx, dp, ct);
    }

    // ---- two partners, one client: a manager decision -------------------------------------------------------

    private async Task<List<PartnerRegistrationConflictDto>> ToDtosAsync(RecordAccessContext ctx, List<PartnerRegistrationConflict> rows, CancellationToken ct)
    {
        var accountIds = rows.SelectMany(r => new[] { r.PartnerAccountId, r.AgainstPartnerAccountId })
            .Concat(rows.Where(r => r.ClientAccountId != null).Select(r => r.ClientAccountId!.Value)).Distinct().ToList();
        var accounts = await _store.AccountNamesAsync(accountIds, ct);
        var leads = await _store.LeadFactsManyAsync(rows.SelectMany(r => new[] { r.LeadId, r.AgainstLeadId }).Distinct().ToList(), ct);
        // The earlier claim's deal may be outside the caller's reach: its name is then withheld (a manager decides with what they may see).
        string? Name(Guid id) => leads.TryGetValue(id, out var l) && RecordAccess.CanView(ctx, l.OwnerId, l.TeamId) ? l.Name : null;
        return rows.Select(c => new PartnerRegistrationConflictDto(
            c.Id, c.LeadId, Name(c.LeadId), c.DealPartnerId, c.PartnerAccountId, accounts.GetValueOrDefault(c.PartnerAccountId),
            c.AgainstDealPartnerId, c.AgainstLeadId, Name(c.AgainstLeadId), c.AgainstPartnerAccountId, accounts.GetValueOrDefault(c.AgainstPartnerAccountId),
            c.ClientAccountId, c.ClientAccountId is Guid a ? accounts.GetValueOrDefault(a) : null, c.MatchedBy, c.Status, c.Decision, c.DecisionReason,
            c.TaskId, c.DecidedById, c.DecidedAt, c.CreatedAt)).ToList();
    }

    public async Task<CpResult<List<PartnerRegistrationConflictDto>>> ConflictsAsync(
        RecordAccessContext ctx, string? status, Guid? partnerAccountId, Guid? leadId, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<List<PartnerRegistrationConflictDto>>();
        if (!string.IsNullOrWhiteSpace(status) && Array.IndexOf(ChannelPartnerVocab.ConflictStatus.All, status) < 0)
            return Cp.Invalid<List<PartnerRegistrationConflictDto>>("status is open or decided.", "bad_status");
        var rows = await _store.ListConflictsAsync(string.IsNullOrWhiteSpace(status) ? null : status, partnerAccountId, leadId, ct);
        var leads = await _store.LeadFactsManyAsync(rows.Select(r => r.LeadId).Distinct().ToList(), ct);
        rows = rows.Where(r => leads.TryGetValue(r.LeadId, out var l) && RecordAccess.CanView(ctx, l.OwnerId, l.TeamId)).ToList();
        return Cp.Ok(await ToDtosAsync(ctx, rows, ct));
    }

    /// <summary>
    /// A manager records whose claim stands (new_claim | existing_claim | both) and why. A RECORD: it changes no registration status and no money - the manager sets each
    /// registration separately - and it closes the admin-queue task. Decided once; a second attempt is a 409.
    /// </summary>
    public async Task<CpResult<PartnerRegistrationConflictDto>> DecideConflictAsync(
        RecordAccessContext ctx, Guid conflictId, PartnerConflictDecideInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsCommercials<PartnerRegistrationConflictDto>();
        var conflict = await _store.FindConflictAsync(conflictId, ct);
        var leadFacts = conflict is null ? null : await _partners.LeadFactsAsync(conflict.LeadId, ct);
        if (conflict is null || leadFacts is null || !RecordAccess.CanView(ctx, leadFacts.OwnerId, leadFacts.TeamId))
            return Cp.NotFound<PartnerRegistrationConflictDto>("Conflict not found");
        if (conflict.Status != ChannelPartnerVocab.ConflictStatus.Open)
            return Cp.Conflict<PartnerRegistrationConflictDto>("This conflict has already been decided.", "already_decided");
        var decision = input.Decision?.Trim().ToLowerInvariant();
        if (decision is null || Array.IndexOf(ChannelPartnerVocab.ConflictDecision.All, decision) < 0)
            return Cp.Invalid<PartnerRegistrationConflictDto>("Decide for the new claim, the existing claim, or both.", "bad_decision");
        var reason = input.Reason?.Trim();
        if (string.IsNullOrEmpty(reason)) return Cp.Invalid<PartnerRegistrationConflictDto>("A reason is required to decide a conflict.", "reason_required");
        if (reason.Length > 1000) return Cp.Invalid<PartnerRegistrationConflictDto>("The reason is at most 1000 characters.", "reason_too_long");

        var now = DateTime.UtcNow;
        conflict.Status = ChannelPartnerVocab.ConflictStatus.Decided;
        conflict.Decision = decision;
        conflict.DecisionReason = reason;
        conflict.DecidedById = actorId;
        conflict.DecidedAt = now;
        // Owner Q1: deciding the conflict ALSO sets the two registrations, in this same save - the favoured claim accepted, the other declined (both: both accepted) - with the reason
        // recorded on each. Money is not touched here; a declined registration is a record and earns exactly what it did.
        var (newStatus, existingStatus) = decision switch
        {
            ChannelPartnerVocab.ConflictDecision.NewClaim => (ChannelPartnerVocab.Registration.Accepted, ChannelPartnerVocab.Registration.Declined),
            ChannelPartnerVocab.ConflictDecision.ExistingClaim => (ChannelPartnerVocab.Registration.Declined, ChannelPartnerVocab.Registration.Accepted),
            _ => (ChannelPartnerVocab.Registration.Accepted, ChannelPartnerVocab.Registration.Accepted),
        };
        var today = ReportingCalendar.Today(await _store.CalendarAsync());
        foreach (var (dpId, status) in new[] { (conflict.DealPartnerId, newStatus), (conflict.AgainstDealPartnerId, existingStatus) })
        {
            var dp = await _partners.FindDealPartnerAsync(dpId, ct);
            if (dp is null) continue;
            if (dp.RegistrationStatus == ChannelPartnerVocab.Registration.None)
            {
                dp.RegisteredById = actorId;
                dp.RegisteredOn = today;
            }
            dp.RegistrationStatus = status;
            dp.RegistrationDecidedAt = now;
            dp.RegistrationDecidedById = actorId;
            var line = $"Conflict decision ({decision.Replace('_', ' ')}): {reason}";
            var notes = string.IsNullOrEmpty(dp.RegistrationNotes) ? line : dp.RegistrationNotes + "\n" + line;
            dp.RegistrationNotes = notes.Length > MaxNotes ? notes[^MaxNotes..] : notes;
            dp.UpdatedAt = now;
        }
        if (conflict.TaskId is Guid taskId && await _store.FindTaskAsync(taskId, ct) is { } task && task.Status == TaskStatuses.Open)
        {
            task.Status = TaskStatuses.Done;
            task.CompletedAt = now;
            task.CompletedById = actorId;
            task.UpdatedAt = now;
        }
        await _store.SaveChangesAsync(ct);
        return Cp.Ok((await ToDtosAsync(ctx, [conflict], ct))[0]);
    }
}

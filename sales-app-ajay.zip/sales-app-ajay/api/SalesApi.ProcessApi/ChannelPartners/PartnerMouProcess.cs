using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.ChannelPartners;
using SalesApi.SystemLayer.Usage;

namespace SalesApi.ProcessLayer.ChannelPartners;

/// <summary>
/// The partner MoU net-margin model (to-do/partner-mou-net-margin-design.md, owner decisions 1-9): consumption in, the monthly statement ("Run month"), approval that posts ONE ledger
/// entry, void, and the report. The arithmetic is <see cref="PartnerMouCalculator"/> (pure); this class assembles its inputs and owns the life of the statement.
///
/// REUSED, not rebuilt: the partner profile and its masking (<see cref="Cp.CanReadCommercials"/> / <see cref="Cp.CanWriteCommercials"/>, the partner_commercials category); the ledger path
/// (<see cref="PartnerLedgerStore.AddEntry"/> - PartnerCapture then dirties PartnerStats inside the same tracked save, so the aggregate is current with no ExecuteUpdate); the settled-by-a-payout test
/// (<see cref="PartnerLedgerStore.SettledAsync"/>); the CSV reader and client lookup of the usage upload (<c>CsvUtil.Parse</c>, <see cref="UsageStore.FindAccountsAsync"/>, <see cref="UsageRowErrorDto"/>);
/// the won-deal test (<see cref="PlaybookPhases"/>) and the reporting-calendar month (<see cref="PartnerStatsService.MonthKey"/>).
/// Authorization (who may run / approve) is the controller's; the caller's Partner commercials level arrives in the <see cref="RecordAccessContext"/>.
/// </summary>
public sealed class PartnerMouProcess
{
    private readonly PartnerMouStore _store;
    private readonly ChannelPartnerStore _partners;
    private readonly PartnerLedgerStore _ledger;
    private readonly UsageStore _usage;
    private readonly Func<DateTime> _clock;

    public PartnerMouProcess(PartnerMouStore store, ChannelPartnerStore partners, PartnerLedgerStore ledger, UsageStore usage, Func<DateTime>? clock = null)
    {
        _store = store;
        _partners = partners;
        _ledger = ledger;
        _usage = usage;
        _clock = clock ?? (() => DateTime.UtcNow);
    }

    private static readonly Regex MonthShape = new(@"^\d{4}-(0[1-9]|1[0-2])$", RegexOptions.Compiled | RegexOptions.CultureInvariant);
    private const int MaxText = 120;
    private const int MaxCount = 1_000_000_000;
    private const decimal MaxAmount = 1_000_000_000m;

    private static CpResult<T> NeedsRead<T>() => Cp.Forbidden<T>("Your role can't see partner commercials.", "partner_commercials_hidden");
    private static CpResult<T> NeedsWrite<T>() => Cp.Invalid<T>(Cp.ReadOnlyMessage(SensitiveCategories.PartnerCommercials), SensitiveWriteGuard.Code);

    private static DateOnly? ParseMonth(string? text) =>
        text is not null && MonthShape.IsMatch(text.Trim()) ? new DateOnly(int.Parse(text.Trim()[..4], CultureInfo.InvariantCulture), int.Parse(text.Trim()[5..], CultureInfo.InvariantCulture), 1) : null;

    private static string MonthText(DateOnly m) => m.ToString("yyyy-MM", CultureInfo.InvariantCulture);

    private async Task<DateOnly> ThisMonthAsync()
    {
        var today = ReportingCalendar.DayOf(await _store.CalendarAsync(), _clock());
        return new DateOnly(today.Year, today.Month, 1);
    }

    private async Task<CpResult<ChannelPartnerStore.AccountFacts>> VisiblePartnerAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct)
    {
        var account = await _partners.AccountFactsAsync(accountId, ct);
        if (account is null || !RecordAccess.CanView(ctx, account.OwnerId, account.TeamId)) return Cp.NotFound<ChannelPartnerStore.AccountFacts>("Account not found");
        if (await _partners.ReadProfileAsync(accountId, ct) is null) return Cp.NotFound<ChannelPartnerStore.AccountFacts>("This account is not a channel partner.");
        return Cp.Ok(account);
    }

    // ---- consumption ----------------------------------------------------------------------------------------

    private static List<PartnerOneTimeItemDto> ItemsOf(string json)
    {
        try { return JsonSerializer.Deserialize<List<PartnerOneTimeItemDto>>(json, ChannelPartnerJson.Options) ?? []; }
        catch (JsonException) { return []; }
    }

    private static PartnerConsumptionDto ToDto(PartnerConsumption c, string clientName) =>
        new(c.Id, c.PartnerAccountId, c.ClientAccountId, clientName, MonthText(c.Month), c.InvoicesCount, c.ActiveTrns, ItemsOf(c.OneTimeItems), c.Source, c.EnteredById, c.EnteredAt);

    public async Task<CpResult<List<PartnerConsumptionDto>>> ConsumptionAsync(RecordAccessContext ctx, Guid partnerAccountId, string? month, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsRead<List<PartnerConsumptionDto>>();
        var partner = await VisiblePartnerAsync(ctx, partnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<List<PartnerConsumptionDto>, ChannelPartnerStore.AccountFacts>(partner);
        var m = ParseMonth(month);
        if (m is null) return Cp.Invalid<List<PartnerConsumptionDto>>("Choose a month, written YYYY-MM.", "bad_month");
        var rows = await _store.ConsumptionAsync(partnerAccountId, m.Value, ct);
        var names = await _store.AccountNamesAsync(rows.Select(r => r.ClientAccountId).Distinct().ToList(), ct);
        return Cp.Ok(rows.Select(r => ToDto(r, names.GetValueOrDefault(r.ClientAccountId) ?? "")).ToList());
    }

    /// <summary>Plain-words check of one-time items (shared by the manual save and the upload). Null when fine.</summary>
    private static string? ItemsProblem(List<PartnerOneTimeItemDto> items)
    {
        if (items.Count > PartnerMouVocab.MaxOneTimeItems) return $"At most {PartnerMouVocab.MaxOneTimeItems} one-time items a client a month.";
        foreach (var i in items)
        {
            if (string.IsNullOrWhiteSpace(i.Label)) return "Each one-time item needs a label.";
            if (i.Label.Trim().Length > MaxText) return $"A one-time label is at most {MaxText} characters.";
            if (i.Amount <= 0m || i.Amount > MaxAmount) return "A one-time amount is above 0.";
        }
        return null;
    }

    private static string ItemsJson(IEnumerable<PartnerOneTimeItemDto> items) =>
        JsonSerializer.Serialize(items.Select(i => new PartnerOneTimeItemDto(i.Label.Trim(), PartnerPlanEngine.Money(i.Amount))), ChannelPartnerJson.Options);

    /// <summary>One client + month by hand. Saving the same client and month again replaces the row.</summary>
    public async Task<CpResult<PartnerConsumptionDto>> SaveConsumptionAsync(
        RecordAccessContext ctx, Guid partnerAccountId, PartnerConsumptionInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerConsumptionDto>();
        var partner = await VisiblePartnerAsync(ctx, partnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<PartnerConsumptionDto, ChannelPartnerStore.AccountFacts>(partner);
        var month = ParseMonth(input.Month);
        if (month is null) return Cp.Invalid<PartnerConsumptionDto>("Choose a month, written YYYY-MM.", "bad_month");
        if (month > await ThisMonthAsync()) return Cp.Invalid<PartnerConsumptionDto>("That month is in the future.", "future_month");
        if (input.ClientAccountId is not Guid clientId || clientId == partnerAccountId) return Cp.Invalid<PartnerConsumptionDto>("Choose the partner's client.", "client_required");
        var clientName = (await _store.AccountNamesAsync([clientId], ct)).GetValueOrDefault(clientId);
        if (clientName is null) return Cp.NotFound<PartnerConsumptionDto>("Client not found");
        if (input.InvoicesCount is not (>= 0 and <= MaxCount) || input.ActiveTrns is not (>= 0 and <= MaxCount))
            return Cp.Invalid<PartnerConsumptionDto>("Invoices and active TRNs are whole numbers, 0 or more.", "bad_count");
        var items = input.OneTimeItems ?? [];
        if (ItemsProblem(items) is { } itemProblem) return Cp.Invalid<PartnerConsumptionDto>(itemProblem, "bad_item");

        var existing = (await _store.TrackedConsumptionAsync(partnerAccountId, [month.Value], ct)).FirstOrDefault(c => c.ClientAccountId == clientId);
        var row = existing ?? new PartnerConsumption { Id = Guid.NewGuid(), PartnerAccountId = partnerAccountId, ClientAccountId = clientId, Month = month.Value };
        row.InvoicesCount = input.InvoicesCount.Value;
        row.ActiveTrns = input.ActiveTrns.Value;
        row.OneTimeItems = ItemsJson(items);
        row.Source = PartnerMouVocab.ConsumptionSource.Manual;
        row.EnteredById = actorId;
        row.EnteredAt = _clock();
        if (existing is null) _store.AddConsumption(row);
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(ToDto(row, clientName));
    }

    private static readonly string[] ClientHeaders = ["client", "client_name", "account", "account_name", "client_id", "account_id"];
    private static readonly string[] MonthHeaders = ["month", "period"];
    private static readonly string[] InvoiceHeaders = ["invoices", "invoices_count", "invoice_count", "invoices_issued"];
    private static readonly string[] TrnHeaders = ["active_trns", "active_trn", "trns", "active_trn_count"];
    private static readonly string[] LabelHeaders = ["one_time_label", "one_time_item", "item", "label"];
    private static readonly string[] AmountHeaders = ["one_time_amount", "amount", "item_amount"];

    private static int Col(List<string> header, string[] names) => header.FindIndex(h => Array.IndexOf(names, h) >= 0);

    private sealed record UploadRow(int Row, string Client, DateOnly Month, int? Invoices, int? Trns, PartnerOneTimeItemDto? Item);

    /// <summary>
    /// Upload (CSV text; the desktop converts an XLSX first). One row per client and month, plus extra rows of the same client and month for further one-time items. Bad rows are SKIPPED with a plain
    /// reason and the good ones saved; <c>DryRun</c> saves nothing. Idempotent: a client and month already on file is REPLACED, so uploading the same file twice leaves the same rows.
    /// </summary>
    public async Task<CpResult<PartnerConsumptionUploadResultDto>> UploadAsync(
        RecordAccessContext ctx, Guid partnerAccountId, PartnerConsumptionUploadInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerConsumptionUploadResultDto>();
        var partner = await VisiblePartnerAsync(ctx, partnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<PartnerConsumptionUploadResultDto, ChannelPartnerStore.AccountFacts>(partner);
        if (string.IsNullOrWhiteSpace(input.Csv)) return Cp.Invalid<PartnerConsumptionUploadResultDto>("Choose a file.", "bad_file");
        var table = CsvUtil.Parse(input.Csv).Where(r => r.Any(c => c.Trim() != "")).ToList();
        if (table.Count < 2) return Cp.Invalid<PartnerConsumptionUploadResultDto>("The file has no rows below the header.", "bad_file");
        if (table.Count - 1 > PartnerMouVocab.MaxRows) return Cp.Invalid<PartnerConsumptionUploadResultDto>($"A file can hold at most {PartnerMouVocab.MaxRows:N0} rows. Split it by month.", "bad_file");
        var header = table[0].Select(h => h.Trim().ToLowerInvariant().Replace(' ', '_')).ToList();
        int client = Col(header, ClientHeaders), month = Col(header, MonthHeaders), inv = Col(header, InvoiceHeaders), trn = Col(header, TrnHeaders), label = Col(header, LabelHeaders), amount = Col(header, AmountHeaders);
        var missing = new[] { (client, "client"), (month, "month"), (inv, "invoices"), (trn, "active_trns") }.Where(c => c.Item1 < 0).Select(c => c.Item2).ToList();
        if (missing.Count > 0)
            return Cp.Invalid<PartnerConsumptionUploadResultDto>($"The header is missing: {string.Join(", ", missing)}. The columns are client, month, invoices, active_trns, one_time_label, one_time_amount.", "bad_file");

        var errors = new List<UsageRowErrorDto>();
        var thisMonth = await ThisMonthAsync();
        string Cell(List<string> r, int i) => i >= 0 && i < r.Count ? r[i].Trim() : "";

        // Resolve every client in one query (an id, or a case-insensitive exact name).
        var refs = table.Skip(1).Select(r => Cell(r, client)).Where(v => v.Length > 0).Distinct().ToList();
        var ids = refs.Where(v => Guid.TryParse(v, out _)).Select(Guid.Parse).ToList();
        var names = refs.Where(v => !Guid.TryParse(v, out _)).Select(v => v.ToLowerInvariant()).Distinct().ToList();
        var accounts = await _usage.FindAccountsAsync(ids, names, ct);
        var byId = accounts.ToDictionary(a => a.Id);
        var byName = accounts.GroupBy(a => a.Name.Trim().ToLowerInvariant()).ToDictionary(g => g.Key, g => g.ToList());

        var parsed = new List<(UploadRow Row, Guid ClientId, string ClientName)>();
        for (var i = 1; i < table.Count; i++)
        {
            var r = table[i];
            var rowNo = i + 1;
            var before = errors.Count;
            void Err(string reason) => errors.Add(new UsageRowErrorDto(rowNo, reason));

            var clientText = Cell(r, client);
            UsageStore.AccountRef? account = null;
            if (clientText.Length == 0) Err("The client is blank.");
            else if (Guid.TryParse(clientText, out var gid)) { account = byId.GetValueOrDefault(gid); if (account is null) Err($"No client with the id \"{clientText}\" in this organisation."); }
            else
            {
                var hits = byName.GetValueOrDefault(clientText.ToLowerInvariant());
                if (hits is null) Err($"No client called \"{clientText}\" in this organisation.");
                else if (hits.Count > 1) Err($"More than one account is called \"{clientText}\". Use the client's id.");
                else account = hits[0];
            }
            if (account?.Id == partnerAccountId) { Err("The partner itself cannot be its own client."); account = null; }

            var monthValue = ParseMonth(Cell(r, month));
            if (monthValue is null) Err($"The month \"{Cell(r, month)}\" is not written YYYY-MM.");
            else if (monthValue > thisMonth) Err($"The month {Cell(r, month)} is in the future.");

            int? Whole(int col, string what)
            {
                var text = Cell(r, col).Replace(",", "").Replace(" ", "");
                if (text.Length == 0) return null;
                if (!int.TryParse(text, NumberStyles.None, CultureInfo.InvariantCulture, out var n) || n > MaxCount) { Err($"{what} must be a whole number, 0 or more."); return null; }
                return n;
            }
            var invoices = Whole(inv, "Invoices");
            var trns = Whole(trn, "Active TRNs");

            PartnerOneTimeItemDto? item = null;
            var labelText = Cell(r, label);
            var amountText = Cell(r, amount).Replace(",", "").Replace(" ", "");
            if (labelText.Length > 0 || amountText.Length > 0)
            {
                if (labelText.Length == 0) Err("A one-time amount needs a label.");
                else if (!decimal.TryParse(amountText, NumberStyles.Number, CultureInfo.InvariantCulture, out var a) || a <= 0m || a > MaxAmount) Err("A one-time amount is a number above 0.");
                else item = new PartnerOneTimeItemDto(labelText, a);
                if (item is not null && ItemsProblem([item]) is { } p) { Err(p); item = null; }
            }

            if (errors.Count > before || account is null || monthValue is null) continue;
            parsed.Add((new UploadRow(rowNo, clientText, monthValue.Value, invoices, trns, item), account.Id, account.Name));
        }

        // Group by client and month: the first row with figures defines them; a later row may only add an item or repeat the same figures.
        var groups = new Dictionary<(Guid, DateOnly), (int Row, string Name, int? Invoices, int? Trns, List<PartnerOneTimeItemDto> Items)>();
        foreach (var (row, clientId, clientName) in parsed)
        {
            var key = (clientId, row.Month);
            if (!groups.TryGetValue(key, out var g)) { groups[key] = (row.Row, clientName, row.Invoices, row.Trns, row.Item is null ? [] : [row.Item]); continue; }
            if ((row.Invoices is not null && g.Invoices is not null && row.Invoices != g.Invoices) || (row.Trns is not null && g.Trns is not null && row.Trns != g.Trns))
            { errors.Add(new UsageRowErrorDto(row.Row, $"This client and month already appear on row {g.Row} with different figures.")); continue; }
            if (row.Item is not null) g.Items.Add(row.Item);
            groups[key] = (g.Row, g.Name, g.Invoices ?? row.Invoices, g.Trns ?? row.Trns, g.Items);
        }
        foreach (var (key, g) in groups.ToList())
        {
            if (g.Invoices is null || g.Trns is null) { errors.Add(new UsageRowErrorDto(g.Row, "Invoices and active TRNs are both needed for a client and month.")); groups.Remove(key); continue; }
            if (ItemsProblem(g.Items) is { } p) { errors.Add(new UsageRowErrorDto(g.Row, p)); groups.Remove(key); }
        }
        errors.Sort((a, b) => a.Row.CompareTo(b.Row));

        var existing = groups.Count == 0 ? [] : await _store.TrackedConsumptionAsync(partnerAccountId, groups.Keys.Select(k => k.Item2).Distinct().ToList(), ct);
        var existingByKey = existing.ToDictionary(c => (c.ClientAccountId, c.Month));
        int created = 0, replaced = 0;
        foreach (var ((clientId, monthKey), g) in groups)
        {
            var found = existingByKey.GetValueOrDefault((clientId, monthKey));
            if (found is null) created++; else replaced++;
            if (input.DryRun) continue;
            var row = found ?? new PartnerConsumption { Id = Guid.NewGuid(), PartnerAccountId = partnerAccountId, ClientAccountId = clientId, Month = monthKey };
            row.InvoicesCount = g.Invoices!.Value;
            row.ActiveTrns = g.Trns!.Value;
            row.OneTimeItems = ItemsJson(g.Items);
            row.Source = PartnerMouVocab.ConsumptionSource.Upload;
            row.EnteredById = actorId;
            row.EnteredAt = _clock();
            if (found is null) _store.AddConsumption(row);
        }
        if (!input.DryRun && groups.Count > 0) await _store.SaveChangesAsync(ct);
        return Cp.Ok(new PartnerConsumptionUploadResultDto(table.Count - 1, groups.Count, created, replaced, input.DryRun, errors));
    }

    // ---- run a month -----------------------------------------------------------------------------------------

    private static List<T> ReadList<T>(string json) { try { return JsonSerializer.Deserialize<List<T>>(json, ChannelPartnerJson.Options) ?? []; } catch (JsonException) { return []; } }

    /// <summary>What approval posts for this statement: its direction and amount, the opposite direction when the owner chose post_reverse, or nothing (null) for zero, carry_forward and settle_zero.</summary>
    private static (string Direction, decimal Amount)? Posted(PartnerMouStatement s)
    {
        if (s.SettleAmount > 0m) return (s.Direction, s.SettleAmount);
        if (s.SettleAmount < 0m && s.ShortfallChoice == PartnerMouVocab.ShortfallChoice.PostReverse)
            return (s.Direction == ChannelPartnerVocab.Direction.Receivable ? ChannelPartnerVocab.Direction.Payable : ChannelPartnerVocab.Direction.Receivable, -s.SettleAmount);
        return null;
    }

    /// <summary>Receivable status, derived on read (never stored): open | partly_received | received, and overdue = the credit days have passed with money still outstanding.</summary>
    private static (string Status, decimal Received, decimal Outstanding, bool Overdue, DateOnly? Due) ReceiptView(PartnerMouStatement s, DateTime now)
    {
        if (s.Status != PartnerMouVocab.StatementStatus.Approved || Posted(s) is not { } p || p.Direction != ChannelPartnerVocab.Direction.Receivable || s.ApprovedAt is not { } approved)
            return (PartnerMouVocab.ReceiptStatus.NotApplicable, 0m, 0m, false, null);
        var outstanding = p.Amount - s.ReceivedAmount;
        var due = DateOnly.FromDateTime(approved).AddDays(s.PaymentTermsDays);
        var status = outstanding <= 0m ? PartnerMouVocab.ReceiptStatus.Received : s.ReceivedAmount > 0m ? PartnerMouVocab.ReceiptStatus.PartlyReceived : PartnerMouVocab.ReceiptStatus.Open;
        return (status, s.ReceivedAmount, Math.Max(0m, outstanding), outstanding > 0m && DateOnly.FromDateTime(now) > due, due);
    }

    private async Task<PartnerMouStatementDto> DtoAsync(PartnerMouStatement s, ChannelPartnerStore.AccountFacts partner, CancellationToken ct)
    {
        // A negative statement names the partner account's owner, who must choose before approval.
        var negative = s.SettleAmount < 0m;
        string? ownerName = negative ? (await _partners.ProfileNamesAsync([partner.OwnerId], ct)).GetValueOrDefault(partner.OwnerId) : null;
        var receipt = ReceiptView(s, _clock());
        return new PartnerMouStatementDto(
            s.Id, s.PartnerAccountId, partner.Name, s.Number, MonthText(s.Month), s.Status, s.Revenue, s.PlatformCost, s.Subscription, s.InfraCost, s.TopUps, s.NetBase,
            s.FpAmount, s.SpAmount, s.Direction, s.SettleAmount, s.Currency, PartnerMouCalculator.ParseTerms(s.TermsJson), ReadList<PartnerMouLineDto>(s.LinesJson), ReadList<string>(s.WarningsJson),
            s.RunAt, s.RunById, s.ApprovedAt, s.ApprovedById, s.ApprovalNote, s.LedgerEntryId, s.VoidedAt, s.VoidedById, s.VoidReason, s.VoidEntryId,
            NeedsShortfallChoice: negative && s.Status == PartnerMouVocab.StatementStatus.Draft && s.ShortfallChoice is null,
            ShortfallOwnerId: negative ? partner.OwnerId : null, ShortfallOwnerName: ownerName,
            ShortfallChoice: s.ShortfallChoice, ShortfallChosenById: s.ShortfallChosenById, ShortfallChosenAt: s.ShortfallChosenAt,
            ReceiptStatus: receipt.Status, Received: receipt.Received, Outstanding: receipt.Outstanding, Overdue: receipt.Overdue, DueDate: receipt.Due,
            Receipts: ReadList<PartnerMouReceiptDto>(s.ReceiptsJson));
    }

    /// <summary>
    /// "Run month" (decision 9): computes the partner's month from its terms, its won deals and the consumption on file, and stores it as a DRAFT with every line frozen. Running again replaces a
    /// DRAFT (same number); an approved statement is never touched - void it first.
    /// </summary>
    public async Task<CpResult<PartnerMouStatementDto>> RunAsync(RecordAccessContext ctx, Guid partnerAccountId, PartnerMouRunInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerMouStatementDto>();
        var partner = await VisiblePartnerAsync(ctx, partnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<PartnerMouStatementDto, ChannelPartnerStore.AccountFacts>(partner);
        var month = ParseMonth(input.Month);
        if (month is null) return Cp.Invalid<PartnerMouStatementDto>("Choose a month, written YYYY-MM.", "bad_month");
        if (month > await ThisMonthAsync()) return Cp.Invalid<PartnerMouStatementDto>("That month is in the future.", "future_month");

        var profile = (await _partners.ReadProfileAsync(partnerAccountId, ct))!;
        var terms = PartnerMouCalculator.ParseTerms(profile.MouTerms);
        if (terms.Model is null or PartnerMouVocab.Model.None) return Cp.Invalid<PartnerMouStatementDto>("This partner has no MoU terms yet. Add them on the partner first.", "mou_not_set");
        if (terms.Model == PartnerMouVocab.Model.EndClientPriceList)
            return Cp.Conflict<PartnerMouStatementDto>("This partner's MoU uses an end-client price list. The monthly calculation is not run for it yet.", "mou_calculation_skipped");
        if (PartnerMouCalculator.ProblemForRun(terms) is { } problem) return Cp.Invalid<PartnerMouStatementDto>(problem, "mou_terms_incomplete");

        var live = await _store.LiveStatementAsync(partnerAccountId, month.Value, ct);
        if (live is { Status: PartnerMouVocab.StatementStatus.Approved })
            return Cp.Conflict<PartnerMouStatementDto>($"{live.Number} for {MonthText(month.Value)} is already approved. Void it first to run the month again.", "statement_approved");

        // ---- inputs ----
        var cal = await _store.CalendarAsync();
        var deals = (await _store.WonDealsAsync(partnerAccountId, ct)).Select(d => new PartnerMouCalculator.DealInput(
            d.LeadId, d.Name, d.ClientAccountId, d.ClientName, PartnerStatsService.MonthKey(cal, d.WonAt), d.Year1Fees, d.Year2Fees, d.OneTimeFees)).ToList();
        var rows = await _store.ConsumptionAsync(partnerAccountId, month.Value, ct);
        var prior = (await _store.ConsumptionAsync(partnerAccountId, month.Value.AddMonths(-1), ct)).ToDictionary(c => c.ClientAccountId, c => c.ActiveTrns);
        var names = await _store.AccountNamesAsync(rows.Select(r => r.ClientAccountId).Distinct().ToList(), ct);
        var clients = rows.Select(r => new PartnerMouCalculator.ClientInput(
            r.ClientAccountId, names.GetValueOrDefault(r.ClientAccountId) ?? "", r.InvoicesCount, r.ActiveTrns, prior.GetValueOrDefault(r.ClientAccountId), ItemsOf(r.OneTimeItems))).ToList();
        var yearStart = PartnerMouCalculator.ContractYearStart(terms.ContractStart, month.Value);
        var before = yearStart < month.Value ? await _store.InvoicesBetweenAsync(partnerAccountId, yearStart, month.Value, ct) : 0L;

        // A shortfall the owner chose to carry forward on the partner's latest earlier APPROVED statement is deducted from this month until used up.
        var previous = await _store.LatestApprovedBeforeAsync(partnerAccountId, month.Value, ct);
        var carried = previous is { ShortfallChoice: PartnerMouVocab.ShortfallChoice.CarryForward, NetBase: < 0m } ? -previous.NetBase : 0m;
        var result = PartnerMouCalculator.Calculate(new PartnerMouCalculator.Input(terms, month.Value, deals, clients, before, carried));
        var currency = string.IsNullOrWhiteSpace(terms.Currency) ? await _ledger.OrgCurrencyAsync(ct) : terms.Currency.Trim().ToUpperInvariant();
        var now = _clock();

        void Fill(PartnerMouStatement s)
        {
            s.Revenue = result.Revenue; s.PlatformCost = result.PlatformCost; s.Subscription = result.Subscription; s.InfraCost = result.InfraCost; s.TopUps = result.TopUps;
            s.NetBase = result.NetBase; s.FpAmount = result.FpAmount; s.SpAmount = result.SpAmount; s.Direction = result.Direction; s.SettleAmount = result.SettleAmount; s.Currency = currency;
            s.TermsJson = PartnerMouCalculator.SerializeTerms(terms);
            s.LinesJson = JsonSerializer.Serialize(result.Lines, ChannelPartnerJson.Options);
            s.WarningsJson = JsonSerializer.Serialize(result.Warnings, ChannelPartnerJson.Options);
            s.RunAt = now; s.RunById = actorId;
            s.ShortfallChoice = null; s.ShortfallChosenById = null; s.ShortfallChosenAt = null;   // the figures changed: the owner chooses again if it is still negative
        }

        if (live is not null)   // a draft: replaced in place, number kept
        {
            Fill(live);
            await _store.SaveChangesAsync(ct);
            return Cp.Ok(await DtoAsync(live, partner.Value!, ct));
        }

        for (var attempt = 0; attempt < 3; attempt++)
        {
            var statement = new PartnerMouStatement { Id = Guid.NewGuid(), PartnerAccountId = partnerAccountId, Month = month.Value, Number = await _store.NextNumberAsync(month.Value, ct), Status = PartnerMouVocab.StatementStatus.Draft };
            Fill(statement);
            _store.AddStatement(statement);
            if (await _store.TrySaveAsync(ct)) return Cp.Ok(await DtoAsync(statement, partner.Value!, ct));
            _store.DiscardPending();
            if (await _store.LiveStatementAsync(partnerAccountId, month.Value, ct) is not null)
                return Cp.Conflict<PartnerMouStatementDto>("Someone else just ran this month. Open it from the list.", "statement_exists");
        }
        return Cp.Conflict<PartnerMouStatementDto>("Could not number the statement. Try again.", "number_race");
    }

    // ---- reading ------------------------------------------------------------------------------------------------

    public async Task<CpResult<List<PartnerMouStatementSummaryDto>>> StatementsAsync(RecordAccessContext ctx, Guid partnerAccountId, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsRead<List<PartnerMouStatementSummaryDto>>();
        var partner = await VisiblePartnerAsync(ctx, partnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<List<PartnerMouStatementSummaryDto>, ChannelPartnerStore.AccountFacts>(partner);
        var rows = await _store.ListStatementsAsync(partnerAccountId, ct);
        var now = _clock();
        return Cp.Ok(rows.Select(s =>
        {
            var r = ReceiptView(s, now);
            return new PartnerMouStatementSummaryDto(
                s.Id, s.PartnerAccountId, partner.Value!.Name, s.Number, MonthText(s.Month), s.Status, s.NetBase, s.FpAmount, s.SpAmount, s.Direction, s.SettleAmount, s.Currency,
                s.RunAt, s.ApprovedAt, s.VoidedAt, r.Status, r.Received, r.Overdue, s.SettleAmount < 0m && s.Status == PartnerMouVocab.StatementStatus.Draft && s.ShortfallChoice is null);
        }).ToList());
    }

    private async Task<CpResult<(PartnerMouStatement Statement, ChannelPartnerStore.AccountFacts Partner)>> OpenAsync(RecordAccessContext ctx, Guid statementId, CancellationToken ct)
    {
        var s = await _store.FindStatementAsync(statementId, ct);
        if (s is null) return Cp.NotFound<(PartnerMouStatement, ChannelPartnerStore.AccountFacts)>("Statement not found");
        var partner = await VisiblePartnerAsync(ctx, s.PartnerAccountId, ct);
        if (!partner.IsOk) return Cp.As<(PartnerMouStatement, ChannelPartnerStore.AccountFacts), ChannelPartnerStore.AccountFacts>(partner);
        return Cp.Ok((s, partner.Value!));
    }

    /// <summary>
    /// One statement. Seen by a channel-role caller (<paramref name="inChannel"/>, a fact the controller passes down) who may read partner commercials, as before - OR by the partner account's OWNER,
    /// who may be a rep outside the channel team. Anyone else is refused (403). An owner without a partner_commercials read sees the figures only while the statement is awaiting THEIR shortfall
    /// choice (negative, draft, no choice yet) - exactly the numbers they must decide on; for any other statement that owner stays masked.
    /// </summary>
    public async Task<CpResult<PartnerMouStatementDto>> StatementAsync(RecordAccessContext ctx, Guid statementId, Guid? actorId = null, bool inChannel = true, CancellationToken ct = default)
    {
        var found = await _store.FindStatementAsync(statementId, ct);
        var account = found is null ? null : await _partners.AccountFactsAsync(found.PartnerAccountId, ct);
        var isOwner = actorId is { } id && account is not null && id == account.OwnerId;
        if (!Cp.CanReadCommercials(ctx) && !(isOwner && found is not null && AwaitingChoice(found))) return NeedsRead<PartnerMouStatementDto>();
        var open = await OpenAsync(ctx, statementId, ct);
        if (!open.IsOk) return Cp.As<PartnerMouStatementDto, (PartnerMouStatement, ChannelPartnerStore.AccountFacts)>(open);
        if (!inChannel && !isOwner) return Cp.Forbidden<PartnerMouStatementDto>("Your role cannot see MoU statements.", "not_in_channel");
        return Cp.Ok(await DtoAsync(open.Value.Statement, open.Value.Partner, ct));
    }

    private static bool AwaitingChoice(PartnerMouStatement s) =>
        s.SettleAmount < 0m && s.Status == PartnerMouVocab.StatementStatus.Draft && s.ShortfallChoice is null;

    /// <summary>
    /// The draft statements waiting for the CALLER's shortfall choice: those of partner accounts they own, plus - for a partners.manage holder (<paramref name="isPartnerManager"/>) who can read partner
    /// commercials and see the account - those whose owner is no longer active (the same stand-in rule as <see cref="ChooseShortfallAsync"/>). Any signed-in user; empty when none.
    /// </summary>
    public async Task<CpResult<List<PartnerMouStatementSummaryDto>>> AwaitingMyChoiceAsync(RecordAccessContext ctx, Guid actorId, bool isPartnerManager, CancellationToken ct = default)
    {
        var now = _clock();
        var canRead = Cp.CanReadCommercials(ctx);
        var rows = (await _store.AwaitingShortfallChoiceAsync(ct))
            .Where(r => r.OwnerId == actorId || (isPartnerManager && canRead && !r.OwnerActive && RecordAccess.CanView(ctx, r.OwnerId, r.TeamId)))
            .Select(r =>
            {
                var s = r.Statement;
                var rc = ReceiptView(s, now);
                return new PartnerMouStatementSummaryDto(
                    s.Id, s.PartnerAccountId, r.PartnerName, s.Number, MonthText(s.Month), s.Status, s.NetBase, s.FpAmount, s.SpAmount, s.Direction, s.SettleAmount, s.Currency,
                    s.RunAt, s.ApprovedAt, s.VoidedAt, rc.Status, rc.Received, rc.Overdue, true);
            }).ToList();
        return Cp.Ok(rows);
    }

    // ---- approve / void ------------------------------------------------------------------------------------------

    /// <summary>
    /// Approval (ApprovePartnerPayouts, checked by the controller) freezes the statement for good and posts ONE ledger entry: a RECEIVABLE when the partner owes Suntech, a PAYABLE when Suntech owes the
    /// partner (Kind accrual, SourceKey mou:{id} so a double click cannot post twice). Nothing is posted when there is nothing to settle. The statement and the entry commit in one tracked save, which is
    /// also what dirties the partner's PartnerStats row.
    /// </summary>
    public async Task<CpResult<PartnerMouStatementDto>> ApproveAsync(RecordAccessContext ctx, Guid statementId, PartnerMouApproveInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerMouStatementDto>();
        var open = await OpenAsync(ctx, statementId, ct);
        if (!open.IsOk) return Cp.As<PartnerMouStatementDto, (PartnerMouStatement, ChannelPartnerStore.AccountFacts)>(open);
        var (s, partner) = open.Value;
        if (s.Status != PartnerMouVocab.StatementStatus.Draft) return Cp.Conflict<PartnerMouStatementDto>($"{s.Number} is {s.Status}; only a draft can be approved.", "not_a_draft");
        var note = input.Note?.Trim();
        if (note is { Length: > 1000 }) return Cp.Invalid<PartnerMouStatementDto>("The note is at most 1000 characters.", "note_too_long");

        // A NEGATIVE statement waits for the partner account's owner (owner decision 2026-11-12).
        if (s.SettleAmount < 0m && s.ShortfallChoice is null)
        {
            var ownerName = (await _partners.ProfileNamesAsync([partner.OwnerId], ct)).GetValueOrDefault(partner.OwnerId);
            return Cp.Conflict<PartnerMouStatementDto>(
                $"{s.Number} has a negative net base. {(string.IsNullOrWhiteSpace(ownerName) ? "The partner account's owner" : ownerName + ", the partner account's owner,")} must choose carry forward, settle at zero or post the reverse amount before it can be approved.",
                "shortfall_choice_required");
        }

        var now = _clock();
        var profile = await _partners.ReadProfileAsync(s.PartnerAccountId, ct);
        var days = profile?.PaymentTermsDays ?? 0;
        s.PaymentTermsDays = days;
        if (Posted(s) is { } posted)
        {
            var terms = PartnerMouCalculator.ParseTerms(s.TermsJson);
            var earned = DateTime.SpecifyKind(new DateTime(s.Month.Year, s.Month.Month, 1), DateTimeKind.Utc).AddMonths(1).AddTicks(-1);
            var entry = new PartnerLedgerEntry
            {
                Id = Guid.NewGuid(), PartnerAccountId = s.PartnerAccountId, Direction = posted.Direction, Kind = ChannelPartnerVocab.EntryKind.Accrual, Amount = posted.Amount, Currency = s.Currency,
                SourceKey = $"mou:{s.Id:N}", RuleKey = "mou_net_margin", RuleScope = ChannelPartnerVocab.RuleScope.Plan,
                EarnedAt = earned, PayableOn = earned.AddDays(days), PaymentTermsDays = days,
                Reason = $"MoU statement {s.Number} ({MonthText(s.Month)}), net base {s.NetBase:0.00}" + (terms.BilledBy is null ? "" : $", end client billed by {terms.BilledBy}")
                         + (s.ShortfallChoice == PartnerMouVocab.ShortfallChoice.PostReverse ? ", negative: reverse amount posted" : ""),
                CreatedById = actorId,
            };
            _ledger.AddEntry(entry);
            s.LedgerEntryId = entry.Id;
        }
        s.Status = PartnerMouVocab.StatementStatus.Approved;
        s.ApprovedAt = now; s.ApprovedById = actorId; s.ApprovalNote = string.IsNullOrEmpty(note) ? null : note;
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(await DtoAsync(s, partner, ct));
    }

    /// <summary>Voids a statement with a reason. A draft just stops being live; an approved one posts the COUNTER-entry (the ledger is append-only) unless a payout already settled its entry.</summary>
    public async Task<CpResult<PartnerMouStatementDto>> VoidAsync(RecordAccessContext ctx, Guid statementId, PartnerMouVoidInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerMouStatementDto>();
        var open = await OpenAsync(ctx, statementId, ct);
        if (!open.IsOk) return Cp.As<PartnerMouStatementDto, (PartnerMouStatement, ChannelPartnerStore.AccountFacts)>(open);
        var (s, partner) = open.Value;
        var reason = input.Reason?.Trim();
        if (string.IsNullOrEmpty(reason)) return Cp.Invalid<PartnerMouStatementDto>("A reason is required to void a statement.", "reason_required");
        if (reason.Length > 1000) return Cp.Invalid<PartnerMouStatementDto>("The reason is at most 1000 characters.", "reason_too_long");
        if (s.Status == PartnerMouVocab.StatementStatus.Void) return Cp.Conflict<PartnerMouStatementDto>($"{s.Number} is already void.", "already_void");

        if (s.ReceivedAmount > 0m) return Cp.Conflict<PartnerMouStatementDto>($"Money has already been received against {s.Number}, so it can't be voided.", "has_receipts");

        var now = _clock();
        if (s.Status == PartnerMouVocab.StatementStatus.Approved && s.LedgerEntryId is Guid entryId)
        {
            var original = await _ledger.FindEntryAsync(entryId, ct);
            if (original is null) return Cp.Conflict<PartnerMouStatementDto>("The ledger entry this statement posted can't be found.", "entry_missing");
            if ((await _ledger.SettledAsync([entryId], ct)).Contains(entryId))
                return Cp.Conflict<PartnerMouStatementDto>("This statement's amount is already in a payout. Cancel the payout first.", "already_settled");
            var counter = new PartnerLedgerEntry
            {
                Id = Guid.NewGuid(), PartnerAccountId = s.PartnerAccountId, Direction = original.Direction, Kind = ChannelPartnerVocab.EntryKind.Adjustment, Amount = -original.Amount,
                Currency = original.Currency, ReverseOfEntryId = original.Id, SourceKey = $"mou:{s.Id:N}:void", RuleKey = "mou_net_margin", RuleScope = original.RuleScope,
                EarnedAt = now, PayableOn = now, PaymentTermsDays = original.PaymentTermsDays, Reason = $"Void of MoU statement {s.Number}: {reason}", CreatedById = actorId,
            };
            _ledger.AddEntry(counter);
            s.VoidEntryId = counter.Id;
        }
        s.Status = PartnerMouVocab.StatementStatus.Void;
        s.VoidedAt = now; s.VoidedById = actorId; s.VoidReason = reason;
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(await DtoAsync(s, partner, ct));
    }

    // ---- a negative statement: the account owner's choice ----------------------------------------------------------------

    /// <summary>
    /// Owner decision 2026-11-12: a zero-or-negative net base is not simply dropped. The PARTNER ACCOUNT'S OWNER chooses carry_forward (deducted from the next month until used up), settle_zero (written off)
    /// or post_reverse (the opposite direction for the absolute amount). Only the owner may choose; <paramref name="isPartnerManager"/> (partners.manage) may stand in only while the owner is inactive.
    /// Approval refuses a negative statement until this is made. Choosing again is allowed while it is a draft.
    /// </summary>
    public async Task<CpResult<PartnerMouStatementDto>> ChooseShortfallAsync(
        RecordAccessContext ctx, Guid statementId, PartnerMouShortfallInput input, Guid actorId, bool isPartnerManager, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerMouStatementDto>();
        var open = await OpenAsync(ctx, statementId, ct);
        if (!open.IsOk) return Cp.As<PartnerMouStatementDto, (PartnerMouStatement, ChannelPartnerStore.AccountFacts)>(open);
        var (s, partner) = open.Value;
        if (s.Status != PartnerMouVocab.StatementStatus.Draft) return Cp.Conflict<PartnerMouStatementDto>($"{s.Number} is {s.Status}; the choice is made on a draft.", "not_a_draft");
        if (s.SettleAmount >= 0m) return Cp.Conflict<PartnerMouStatementDto>($"{s.Number} is not negative, so there is nothing to choose.", "not_negative");
        var choice = input.Choice?.Trim().ToLowerInvariant();
        if (choice is null || Array.IndexOf(PartnerMouVocab.ShortfallChoice.All, choice) < 0)
            return Cp.Invalid<PartnerMouStatementDto>("Choose carry forward, settle at zero or post the reverse amount.", "bad_choice");

        var ownerNames = await _partners.ProfileNamesAsync([partner.OwnerId], ct);
        var ownerActive = (await _partners.ActiveStaffNamesAsync([partner.OwnerId], ct)).ContainsKey(partner.OwnerId);
        if (actorId != partner.OwnerId && !(isPartnerManager && !ownerActive))
        {
            var name = ownerNames.GetValueOrDefault(partner.OwnerId);
            return Cp.Forbidden<PartnerMouStatementDto>(
                $"Only {(string.IsNullOrWhiteSpace(name) ? "the partner account's owner" : name + ", the partner account's owner,")} can choose how to handle this shortfall."
                + (ownerActive ? "" : " The owner is no longer active, so a partner manager may choose instead."), "only_owner_chooses");
        }
        s.ShortfallChoice = choice;
        s.ShortfallChosenById = actorId;
        s.ShortfallChosenAt = _clock();
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(await DtoAsync(s, partner, ct));
    }

    // ---- mark received -----------------------------------------------------------------------------------------------------

    /// <summary>
    /// "Mark received" on an approved RECEIVABLE statement (what the partner owes Suntech): one payment with a date, amount and reference. Partial is allowed, more than is outstanding is refused. Each receipt
    /// posts a settling ledger entry (Kind payout, direction receivable, negative - exactly what an FSP remittance posts), so the receivable reads Billed less Remitted in PartnerStats, in the same tracked save.
    /// </summary>
    public async Task<CpResult<PartnerMouStatementDto>> RecordReceiptAsync(
        RecordAccessContext ctx, Guid statementId, PartnerMouReceiptInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!Cp.CanWriteCommercials(ctx)) return NeedsWrite<PartnerMouStatementDto>();
        var open = await OpenAsync(ctx, statementId, ct);
        if (!open.IsOk) return Cp.As<PartnerMouStatementDto, (PartnerMouStatement, ChannelPartnerStore.AccountFacts)>(open);
        var (s, partner) = open.Value;
        var now = _clock();
        var view = ReceiptView(s, now);
        if (view.Status == PartnerMouVocab.ReceiptStatus.NotApplicable)
            return Cp.Conflict<PartnerMouStatementDto>($"{s.Number} is not an approved receivable, so there is nothing to receive against it.", "not_a_receivable");
        if (input.Amount is not { } amount || amount <= 0m || amount > MaxAmount) return Cp.Invalid<PartnerMouStatementDto>("Enter the amount received, above 0.", "bad_amount");
        amount = PartnerPlanEngine.Money(amount);
        if (amount > view.Outstanding)
            return Cp.Invalid<PartnerMouStatementDto>($"That is more than the {s.Currency} {view.Outstanding:0.00} still outstanding on {s.Number}.", "overpaid");
        if (input.Date is not { } date) return Cp.Invalid<PartnerMouStatementDto>("Enter the date the money was received.", "date_required");
        var today = ReportingCalendar.DayOf(await _store.CalendarAsync(), now);
        if (date > today) return Cp.Invalid<PartnerMouStatementDto>("The date received can't be in the future.", "future_date");
        var reference = input.Reference?.Trim();
        if (reference is { Length: > 200 }) return Cp.Invalid<PartnerMouStatementDto>("The reference is at most 200 characters.", "reference_too_long");

        var receiptId = Guid.NewGuid();
        var at = DateTime.SpecifyKind(date.ToDateTime(TimeOnly.MinValue), DateTimeKind.Utc);
        var entry = new PartnerLedgerEntry
        {
            Id = Guid.NewGuid(), PartnerAccountId = s.PartnerAccountId, Direction = ChannelPartnerVocab.Direction.Receivable, Kind = ChannelPartnerVocab.EntryKind.Payout, Amount = -amount, Currency = s.Currency,
            SourceKey = $"mou:{s.Id:N}:receipt:{receiptId:N}", RuleKey = "mou_net_margin", RuleScope = ChannelPartnerVocab.RuleScope.Plan, EarnedAt = at, PayableOn = at, PaymentTermsDays = s.PaymentTermsDays,
            Reason = $"Received against MoU statement {s.Number}" + (string.IsNullOrEmpty(reference) ? "" : $" ({reference})"), CreatedById = actorId,
        };
        _ledger.AddEntry(entry);
        var receipts = ReadList<PartnerMouReceiptDto>(s.ReceiptsJson);
        receipts.Add(new PartnerMouReceiptDto(receiptId, date, amount, string.IsNullOrEmpty(reference) ? null : reference, actorId, now, entry.Id));
        s.ReceiptsJson = JsonSerializer.Serialize(receipts, ChannelPartnerJson.Options);
        s.ReceivedAmount += amount;
        await _store.SaveChangesAsync(ct);
        return Cp.Ok(await DtoAsync(s, partner, ct));
    }

    // ---- report ------------------------------------------------------------------------------------------------------

    /// <summary>Per partner per month: net base, FP and SP amounts, direction and statement status, from the live (draft or approved) statements. Default range: the last 12 months to this month.</summary>
    public async Task<CpResult<PartnerMouReportDto>> ReportAsync(RecordAccessContext ctx, string? from, string? to, CancellationToken ct = default)
    {
        if (!Cp.CanReadCommercials(ctx)) return NeedsRead<PartnerMouReportDto>();
        var thisMonth = await ThisMonthAsync();
        var toMonth = string.IsNullOrWhiteSpace(to) ? thisMonth : ParseMonth(to);
        var fromMonth = string.IsNullOrWhiteSpace(from) ? toMonth?.AddMonths(-11) : ParseMonth(from);
        if (fromMonth is null || toMonth is null) return Cp.Invalid<PartnerMouReportDto>("Months are written YYYY-MM.", "bad_month");
        if (fromMonth > toMonth) return Cp.Invalid<PartnerMouReportDto>("The start month is after the end month.", "bad_range");
        var statements = await _store.LiveStatementsBetweenAsync(fromMonth.Value, toMonth.Value, ct);
        var facts = await _partners.AccountFactsManyAsync(statements.Select(s => s.PartnerAccountId).Distinct().ToList(), ct);
        var rows = statements.Where(s => facts.TryGetValue(s.PartnerAccountId, out var f) && RecordAccess.CanView(ctx, f.OwnerId, f.TeamId))
            .Select(s => new PartnerMouReportRowDto(s.PartnerAccountId, facts[s.PartnerAccountId].Name, MonthText(s.Month), s.Id, s.Number, s.Status,
                s.NetBase, s.FpAmount, s.SpAmount, s.Direction, s.SettleAmount, s.Currency)).ToList();
        return Cp.Ok(new PartnerMouReportDto(MonthText(fromMonth.Value), MonthText(toMonth.Value), rows));
    }
}

using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.Automations;

namespace SalesApi.ProcessLayer.Automations;

/// <summary>
/// Automations (E2.2 slice 1): draft CRUD, publish, disable/enable, archive/
/// restore, typed-confirmation hard delete — no runtime.
///
/// PERMISSION IS DELIBERATELY NOT CHECKED HERE. Builder access is admins-only,
/// full stop (design doc §9: "same ctx.IsOrgAdmin gate every other admin-only
/// settings screen already uses" — <c>PlaybooksController.UnmatchedLeads</c>'s
/// bare <c>if (!User.IsOrgAdmin())</c> is the named precedent, not the
/// per-permission <c>OrganizationPermissions</c> list every other domain in
/// this file uses; automations have no team-scoped "can view, can't author"
/// middle tier the way playbooks do). A single caller-wide gate belongs at the
/// HTTP layer (<see cref="Controllers.AutomationsController"/>), the same
/// place every other controller keeps authorization, per root CLAUDE.md's
/// "Controllers route, check permission, and pick a status code — nothing
/// else" rule read the other way: nothing here needs a <c>ClaimsPrincipal</c>
/// because nothing here varies by caller once they are through the gate.
/// </summary>
public sealed class AutomationProcess
{
    private readonly AutomationStore _store;
    private readonly IWebHostEnvironment _env;
    public AutomationProcess(AutomationStore store, IWebHostEnvironment env)
    {
        _store = store;
        _env = env;
    }

    /// <summary>Why an ordinary request could not be honoured — a RESULT, not
    /// an exception, mirroring <c>PlaybookProcess.Refusal</c>.</summary>
    public sealed record Refusal(string Reason, bool NotFound = false, bool Conflict = false);

    private static readonly Refusal NotFoundRefusal = new("Automation not found.", NotFound: true);

    public async Task<List<AutomationSummaryDto>> ListAsync(bool includeArchived, CancellationToken ct = default)
    {
        var rows = await _store.ActiveAsync(ct);
        if (includeArchived) rows = rows.Concat(await _store.ArchivedAsync(ct)).ToList();
        var versions = await _store.VersionsForAsync(rows.Select(a => a.Id).ToList(), ct);
        return rows.Select(a => Shape(a, versions)).ToList();
    }

    public async Task<AutomationDetailDto?> GetAsync(Guid id, CancellationToken ct = default)
    {
        var automation = await _store.ByIdAsync(id, ct);
        if (automation is null) return null;

        var versions = await _store.VersionsOfAsync(id, ct);
        var draft = versions.Where(v => v.Status == AutomationVersionStatus.Draft).OrderByDescending(v => v.Version).FirstOrDefault();
        var live = versions.FirstOrDefault(v => v.Status == AutomationVersionStatus.Live);
        var editing = draft ?? live;

        return new AutomationDetailDto(
            automation.Id, automation.Name, automation.Description, automation.IsBuiltIn, automation.Enabled,
            live?.Version, draft?.Version, live?.PublishedAt, automation.ArchivedAt,
            ParseOrEmptyObject(editing?.TriggerJson),
            ParseOrEmptyObject(editing?.ConditionJson),
            ParseOrEmptyArray(editing?.ActionsJson),
            automation.Key);
    }

    public async Task<List<AutomationVersionDto>?> VersionsAsync(Guid id, CancellationToken ct = default)
    {
        if (await _store.ByIdAsync(id, ct) is null) return null;
        var rows = await _store.VersionsOfAsync(id, ct);
        // No cross-user name resolution in this slice (no controller passes a
        // Profiles lookup down) — Created/PublishedByName are left null, the
        // same "not wired yet" gap PlaybookVersionDto's own name resolution
        // would have before PlaybookStore.VersionHistoryAsync batched it in.
        return rows.Select(v => new AutomationVersionDto(
            v.Version, v.Status, v.CreatedAt, v.CreatedById, null, v.PublishedAt, v.PublishedById, null,
            ParseOrEmptyObject(v.TriggerJson), ParseOrEmptyObject(v.ConditionJson), ParseOrEmptyArray(v.ActionsJson)))
            .ToList();
    }

    public async Task<(AutomationSummaryDto? Created, Refusal? Refusal)> CreateAsync(
        string? name, string? description, Guid userId, CancellationToken ct = default) =>
        await CreateAsync(name, description, key: null, userId, ct);

    /// <summary>E7.1 (design doc §10 owner answer 5) — <paramref name="key"/>
    /// is the admin-supplied stable key, or null to pre-fill it from
    /// <paramref name="name"/>.</summary>
    public async Task<(AutomationSummaryDto? Created, Refusal? Refusal)> CreateAsync(
        string? name, string? description, string? key, Guid userId, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(name)) return (null, new Refusal("A name is required."));

        var automation = await _store.CreateAsync(name!, description, key, userId, ct);
        var versions = await _store.VersionsOfAsync(automation.Id, ct);
        return (Shape(automation, versions), null);
    }

    /// <summary>
    /// Rename (E2.2 slice 6, design doc §12 slice 6): name/description only —
    /// never touches trigger/condition/actions, so it works the same whether
    /// the automation currently has a draft, is live, or both.
    ///
    /// NOT REFUSED FOR A BUILT-IN. <see cref="ArchiveAsync"/>/<see cref="HardDeleteAsync"/>
    /// below DO refuse a built-in, but <see cref="SaveDraftAsync"/> (this
    /// class's own edit path for trigger/condition/actions) does not — design
    /// §7's own E2.5 text says an admin "can edit or disable that reaction
    /// through the automation builder" for a built-in, so this codebase
    /// already allows editing a built-in's DEFINITION. A rename is a smaller
    /// edit than that, so refusing it while allowing the bigger edit would be
    /// an inconsistent, invented rule; this method mirrors <see cref="SaveDraftAsync"/>'s
    /// precedent and does not check <see cref="Automation.IsBuiltIn"/> either.
    ///
    /// NAME UNIQUENESS is the SAME filtered population the database's own
    /// unique index enforces (<see cref="AutomationStore.NameTakenAsync"/>):
    /// active (non-archived) automations only, so a rename can freely reuse a
    /// retired name, same reasoning <see cref="Automation"/>'s own index
    /// comment gives for why archiving is "retirement, not a name reservation".
    /// </summary>
    public async Task<(AutomationSummaryDto? Result, Refusal? Refusal)> RenameAsync(
        Guid id, string? name, string? description, CancellationToken ct = default)
    {
        var automation = await _store.ByIdAsync(id, ct);
        if (automation is null) return (null, NotFoundRefusal);
        if (string.IsNullOrWhiteSpace(name)) return (null, new Refusal("A name is required."));

        var trimmed = name!.Trim();
        if (automation.ArchivedAt is null && await _store.NameTakenAsync(trimmed, id, ct))
            return (null, new Refusal($"An automation named \"{trimmed}\" already exists.", Conflict: true));

        await _store.RenameAsync(automation, trimmed, description?.Trim(), ct);
        var versions = await _store.VersionsOfAsync(id, ct);
        return (Shape(automation, versions), null);
    }

    /// <summary>
    /// Replaces the draft's trigger/condition/actions. Shape-validated
    /// (design doc's own instruction: "validate trigger/condition/action JSON
    /// shape on save") but NOT required to be publish-ready — E2.0 decision 9:
    /// an unfinished automation saves normally, only Publish is blocked.
    /// </summary>
    public async Task<(AutomationDraftResultDto? Result, Refusal? Refusal)> SaveDraftAsync(
        Guid id, JsonElement? trigger, JsonElement? condition, JsonElement? actions, Guid userId, CancellationToken ct = default)
    {
        if (await _store.ByIdAsync(id, ct) is null) return (null, NotFoundRefusal);

        var triggerProblems = trigger is null ? [] : AutomationRuleValidator.ValidateTrigger(trigger);
        if (triggerProblems.Count > 0) return (null, new Refusal($"That trigger isn't valid: {triggerProblems[0]}"));

        var conditionProblems = condition is null ? [] : RuleShapeValidator.Validate(condition);
        if (conditionProblems.Count > 0) return (null, new Refusal($"That condition isn't valid: {conditionProblems[0]}"));

        var actionProblems = actions is null ? [] : AutomationRuleValidator.ValidateActions(actions, allowInsecureHttp: _env.IsDevelopment());
        if (actionProblems.Count > 0) return (null, new Refusal($"That action list isn't valid: {actionProblems[0]}"));

        var triggerJson = trigger?.GetRawText() ?? "{}";
        // Custom-field spelling (owner decision 2026-09-28): every NEW save
        // normalises a legacy `custom:<key>` var reference to the canonical
        // `custom.<key>` — see AutomationConditionKeyNormalizer's own comment
        // for why a generic tree walk also reaches a branch action's nested
        // "if" inside actionsJson.
        var conditionJson = AutomationConditionKeyNormalizer.RewriteCustomKeys(condition?.GetRawText(), "{}");
        var actionsJson = SanitizeEmailBodies(AutomationConditionKeyNormalizer.RewriteCustomKeys(actions?.GetRawText(), "[]"));

        var draft = await _store.SaveDraftAsync(id, triggerJson, conditionJson, actionsJson, userId, ct);
        return (new AutomationDraftResultDto(draft.Version, draft.Status), null);
    }

    /// <summary>
    /// Publishes the draft. Refuses (design doc §12 story 1's own acceptance,
    /// and E2.0 decision 9) when: there is no draft; the draft has no actions
    /// (an automation that does nothing is not publishable); or publishing
    /// would put more than the org's <c>MaxLiveAutomations</c> setting live
    /// (design doc §14.2, binding — checked against the count AFTER this
    /// publish: an automation being REPUBLISHED does not consume an extra
    /// slot, since its own live version is being replaced, not added to).
    /// </summary>
    public async Task<(AutomationPublishResultDto? Result, Refusal? Refusal)> PublishAsync(
        Guid id, Guid userId, CancellationToken ct = default)
    {
        if (await _store.ByIdAsync(id, ct) is null) return (null, NotFoundRefusal);

        var draft = await _store.CurrentDraftAsync(id, ct);
        if (draft is null) return (null, new Refusal("There is no draft to publish."));

        // A draft saved before the watchable-field check existed (or edited
        // around it) must not go live and then never run.
        // Only the field_changed kind is re-checked here: publish has never
        // re-validated the other kinds' shape, and this must not start.
        if (AutomationTriggerMatcher.KindOf(draft.TriggerJson) == AutomationRuleValidator.TriggerKinds.FieldChanged)
        {
            var triggerProblems = AutomationRuleValidator.ValidateTrigger(ParseOrEmptyObject(draft.TriggerJson));
            if (triggerProblems.Count > 0) return (null, new Refusal($"That trigger isn't valid: {triggerProblems[0]}"));
        }

        var actions = ParseOrEmptyArray(draft.ActionsJson);
        if (actions.GetArrayLength() == 0)
            return (null, new Refusal("Add at least one action before publishing."));

        var alreadyLive = await _store.LiveVersionAsync(id, ct) is not null;
        if (!alreadyLive)
        {
            var limits = await _store.GetLimitsAsync(ct);
            var liveCount = await _store.LiveCountAsync(ct);
            if (liveCount >= limits.MaxLiveAutomations)
                return (null, new Refusal(
                    $"This org already has {liveCount} live automations, its configured limit " +
                    $"({limits.MaxLiveAutomations}). Disable one or raise the limit in Settings before publishing another.",
                    Conflict: true));
        }

        var published = await _store.PublishAsync(id, draft, userId, ct);
        return (new AutomationPublishResultDto(published.Version, published.Status, published.PublishedAt), null);
    }

    public async Task<(bool Ok, Refusal? Refusal)> SetEnabledAsync(Guid id, bool enabled, CancellationToken ct = default)
    {
        var automation = await _store.ByIdAsync(id, ct);
        if (automation is null) return (false, NotFoundRefusal);
        await _store.SetEnabledAsync(automation, enabled, ct);
        return (true, null);
    }

    /// <summary>Archives a custom automation — the "run at least once, retire
    /// rather than delete outright" default (design doc E2.0 decision 15).
    /// A built-in is never archived through this path; it only disables (its
    /// own toggle) and gets "Restore default" (E2.5, not built yet).</summary>
    public async Task<(bool Ok, Refusal? Refusal)> ArchiveAsync(Guid id, CancellationToken ct = default)
    {
        var automation = await _store.ByIdAsync(id, ct);
        if (automation is null) return (false, NotFoundRefusal);
        if (automation.IsBuiltIn) return (false, new Refusal("Built-in automations can't be archived — disable it instead."));

        await _store.ArchiveAsync(automation, ct);
        return (true, null);
    }

    public async Task<(bool Ok, Refusal? Refusal)> UnarchiveAsync(Guid id, CancellationToken ct = default)
    {
        var automation = await _store.ByIdAsync(id, ct);
        if (automation is null) return (false, NotFoundRefusal);
        if (automation.ArchivedAt is null) return (false, new Refusal("This automation isn't archived."));

        await _store.UnarchiveAsync(automation, ct);
        return (true, null);
    }

    /// <summary>
    /// "Restore default" (E2.5, design doc §12 slice 7 rule 3; E2.0 decision
    /// 7) — re-seeds a BUILT-IN's shipped definition (<see cref="AutomationBuiltIns"/>)
    /// as a new DRAFT version. Deliberately does NOT touch
    /// <see cref="Automation.Enabled"/> and does NOT publish it — "restore the
    /// definition" and "turn it back on" are different asks (design's own
    /// wording), so an admin who restores a disabled built-in's default still
    /// has to explicitly re-enable AND publish before it runs again.
    /// </summary>
    public async Task<(AutomationVersionDto? Result, Refusal? Refusal)> RestoreDefaultAsync(Guid id, Guid userId, CancellationToken ct = default)
    {
        var automation = await _store.ByIdAsync(id, ct);
        if (automation is null) return (null, NotFoundRefusal);
        if (!automation.IsBuiltIn) return (null, new Refusal("Only a built-in automation has a shipped default to restore."));

        var draft = await _store.RestoreDefaultDraftAsync(automation, userId, ct);
        if (draft is null) return (null, new Refusal("This build has no shipped definition for that built-in any more."));

        return (new AutomationVersionDto(
            draft.Version, draft.Status, draft.CreatedAt, draft.CreatedById, null, draft.PublishedAt, draft.PublishedById, null,
            ParseOrEmptyObject(draft.TriggerJson), ParseOrEmptyObject(draft.ConditionJson), ParseOrEmptyArray(draft.ActionsJson)), null);
    }

    /// <summary>
    /// Hard delete. Design doc E2.0 decision 15, binding: "a hard delete is
    /// allowed after a typed confirmation"; a built-in is "never deletable" —
    /// checked first and unconditionally, before the confirmation text is even
    /// looked at, so a built-in can never be talked into deleting itself by
    /// someone who happens to know its name.
    ///
    /// <paramref name="confirmation"/> must equal the automation's own
    /// <c>Name</c> (case-sensitive, exact) — the same "type the thing's name
    /// to remove it" pattern the offboarding flow's org-name confirmation
    /// uses, chosen over a bare "yes" because a typed name is the one
    /// confirmation that cannot be satisfied by a reflexive click.
    ///
    /// This slice has no <c>AutomationRun</c> table (no runtime yet), so
    /// "never run" cannot be distinguished from "has run" the way design doc
    /// §10's library-screen text does ("a never-run draft can be deleted [without
    /// confirmation]... once it has run it is archived by default, and a hard
    /// delete is allowed after a typed confirmation"). Rather than guess, this
    /// slice requires the typed confirmation for every hard delete, live or
    /// draft-only — the safer of the two available defaults, and one a later
    /// slice (once <c>AutomationRun</c> exists) can relax for a genuinely
    /// never-run draft without changing this method's contract for anything
    /// that HAS run.
    /// </summary>
    public async Task<(bool Ok, Refusal? Refusal)> HardDeleteAsync(Guid id, string? confirmation, CancellationToken ct = default)
    {
        var automation = await _store.ByIdAsync(id, ct);
        if (automation is null) return (false, NotFoundRefusal);
        if (automation.IsBuiltIn) return (false, new Refusal("Built-in automations can't be deleted."));

        if (!string.Equals(confirmation?.Trim(), automation.Name, StringComparison.Ordinal))
            return (false, new Refusal($"Type \"{automation.Name}\" to confirm deleting it."));

        await _store.HardDeleteAsync(automation, ct);
        return (true, null);
    }

    public Task<AutomationLimitsDto> GetLimitsAsync(CancellationToken ct = default) => _store.GetLimitsAsync(ct);

    /// <summary>Run preview (design doc §7, §12 slice 8, E2.0 decision 10:
    /// "updates on a Run preview button"). Previews the automation's current
    /// draft, falling back to its live version if there is no draft — the
    /// same "prefer the draft" rule <see cref="GetAsync"/> already uses, since
    /// this is what a builder open on the automation is editing right now.
    /// A PURE READ: nothing here writes an <see cref="Automation"/>/
    /// <see cref="AutomationVersion"/>/<see cref="AutomationRun"/> row, or
    /// anything an action would otherwise touch — see
    /// <see cref="SystemLayer.Automations.AutomationStore.PreviewAsync"/>'s
    /// own doc comment for how that is enforced structurally, not by
    /// discipline.</summary>
    public async Task<(AutomationPreviewResultDto? Result, Refusal? Refusal)> PreviewAsync(
        Guid id, int? sampleSize, CancellationToken ct = default)
    {
        if (await _store.ByIdAsync(id, ct) is null) return (null, NotFoundRefusal);

        var version = await _store.EditingVersionAsync(id, ct);
        if (version is null) return (null, new Refusal("This automation has no draft or live version to preview."));

        var result = await _store.PreviewAsync(version, sampleSize ?? AutomationPreviewer.DefaultSampleSize, ct);
        return (result, null);
    }

    /// <summary>Publish-narrowing warning (design doc §7, E2.0 decision 11:
    /// "warn and allow... the publish check names the leads that stop
    /// matching"). Compares the current draft against the current live
    /// version over the SAME sample of recent events — mirrors
    /// <c>PlaybookProcess.PublishPreviewAsync</c>'s own
    /// "what publishing would do" shape exactly: a read-only preview
    /// endpoint, separate from <see cref="PublishAsync"/> itself, which the
    /// builder calls first and shows before the admin confirms Publish.
    /// <see cref="PublishAsync"/> is UNCHANGED by this — publishing a
    /// narrowing draft still succeeds (decision 11's "warn AND ALLOW"), the
    /// same way a playbook publish that removes a stage still succeeds once
    /// any stranded leads are remapped.</summary>
    public async Task<(AutomationPublishPreviewDto? Result, Refusal? Refusal)> PublishPreviewAsync(
        Guid id, int? sampleSize, CancellationToken ct = default)
    {
        if (await _store.ByIdAsync(id, ct) is null) return (null, NotFoundRefusal);

        var draft = await _store.CurrentDraftAsync(id, ct);
        if (draft is null) return (null, new Refusal("There is no draft to publish."));

        var live = await _store.LiveVersionAsync(id, ct);
        var result = await _store.PublishNarrowingAsync(draft, live, sampleSize ?? AutomationPreviewer.DefaultSampleSize, ct);
        return (result, null);
    }

    /// <summary>The run log (E2.2 slice 2). Refuses with NotFound rather than
    /// an empty page for an id that doesn't exist, same as every other
    /// automation-scoped read in this class.</summary>
    public async Task<(PagedResult<AutomationRunDto>? Page, Refusal? Refusal)> RunsAsync(
        Guid id, string? cursor, int? limit, CancellationToken ct = default)
    {
        var page = await _store.RunsPageAsync(id, cursor, limit, ct);
        return page is null ? (null, NotFoundRefusal) : (page, null);
    }

    /// <summary>POST /automations/{id}/runs/{runId}/retry (design §10,
    /// 2026-09-27 "automation reach" follow-up) — see
    /// <see cref="AutomationStore.RetryRunAsync"/>/<see cref="Services.AutomationRunner.RetryFailedActionsAsync"/>
    /// for the actual re-execution logic; this method only translates the
    /// store's plain (result, error, notFound) shape into this class's own
    /// <see cref="Refusal"/> convention, same as every other method here.</summary>
    public async Task<(AutomationRunDto? Result, Refusal? Refusal)> RetryRunAsync(
        Guid id, Guid runId, CancellationToken ct = default)
    {
        var (result, error, notFound) = await _store.RetryRunAsync(id, runId, ct);
        if (notFound) return (null, new Refusal("Run not found.", NotFound: true));
        if (error is not null) return (null, new Refusal(error, Conflict: true));
        return (result, null);
    }

    /// <summary>The merge-field picker's one source (design doc §12 slice 4
    /// follow-up) — see <see cref="AutomationMergeFieldCatalog"/>.</summary>
    public Task<List<AutomationMergeFieldDto>> MergeFieldsAsync(string? entityType, CancellationToken ct = default) =>
        _store.MergeFieldsAsync(entityType, ct);

    /// <summary>Which fields a <c>field_changed</c> trigger can watch — read
    /// straight from the field-change audit's allow-list
    /// (<see cref="FieldAudit.WatchableFields"/>), never a second list.</summary>
    public AutomationWatchableFieldsDto WatchableFields() =>
        new(FieldAudit.WatchableFields()
            .Select(e => new AutomationWatchableEntityDto(e.EntityType, e.Fields, e.CustomFields))
            .ToList());

    private static AutomationSummaryDto Shape(Automation a, List<AutomationVersion> versions)
    {
        var mine = versions.Where(v => v.AutomationId == a.Id).ToList();
        var live = mine.FirstOrDefault(v => v.Status == AutomationVersionStatus.Live);
        var draft = mine.Where(v => v.Status == AutomationVersionStatus.Draft).OrderByDescending(v => v.Version).FirstOrDefault();
        return new AutomationSummaryDto(
            a.Id, a.Name, a.Description, a.IsBuiltIn, a.Enabled,
            live?.Version, draft?.Version, live?.PublishedAt, a.ArchivedAt, a.Key);
    }

    private static JsonElement ParseOrEmptyObject(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return JsonDocument.Parse("{}").RootElement.Clone();
        try { return JsonDocument.Parse(json).RootElement.Clone(); }
        catch { return JsonDocument.Parse("{}").RootElement.Clone(); }
    }

    /// <summary>Every send_template_email step's body that is HTML (the rich editor's) is sanitized before it is stored; plain-text bodies and every
    /// other step are left byte for byte. Walks nested steps (a branch's arms) too. Unparsable input is returned as it is: the shape validator ran first.</summary>
    internal static string SanitizeEmailBodies(string json)
    {
        JsonNode? root;
        try { root = JsonNode.Parse(json); }
        catch (JsonException) { return json; }
        var changed = false;
        void Walk(JsonNode? node)
        {
            switch (node)
            {
                case JsonObject obj:
                    if (obj["type"] is JsonValue type && type.TryGetValue<string>(out var kind) && kind == AutomationRuleValidator.ActionTypes.SendTemplateEmail
                        && obj["body"] is JsonValue body && body.TryGetValue<string>(out var text) && EmailBody.IsHtml(text))
                    {
                        var clean = EmailBody.Sanitize(text);
                        if (clean != text) { obj["body"] = clean; changed = true; }
                    }
                    foreach (var (_, value) in obj.ToList()) Walk(value);
                    break;
                case JsonArray array:
                    foreach (var item in array) Walk(item);
                    break;
            }
        }
        Walk(root);
        return changed ? root!.ToJsonString() : json;
    }

    private static JsonElement ParseOrEmptyArray(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return JsonDocument.Parse("[]").RootElement.Clone();
        try { return JsonDocument.Parse(json).RootElement.Clone(); }
        catch { return JsonDocument.Parse("[]").RootElement.Clone(); }
    }
}

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Accounts;
using SalesApi.ProcessLayer.Approvals;
using SalesApi.ProcessLayer.Contacts;
using SalesApi.ProcessLayer.Invoices;
using SalesApi.ProcessLayer.Leads;
using SalesApi.ProcessLayer.Reminders;
using SalesApi.ProcessLayer.Tasks;
using SalesApi.Services;
using SalesApi.SystemLayer.Webhooks;

namespace SalesApi.ProcessLayer.Automations;

/// <summary>
/// The concrete <see cref="IAutomationActionExecutor"/> — design doc
/// to-do/e2-automation-design.md §6, §12 slices 3-4 and 10: the eight actions
/// that execute HERE (<c>create_task</c>, <c>create_reminder</c>,
/// <c>assign_owner</c>/<c>assign_team</c>, <c>set_field</c>,
/// <c>request_approval</c>, <c>notify</c>, <c>call_webhook</c>,
/// <c>send_template_email</c>). <c>wait_n_days</c> and <c>branch</c> are
/// control flow over the action QUEUE itself (design §6: "splits the action
/// list into two segments" / "a condition node inside the action list"), so
/// <see cref="AutomationRunner"/> handles both directly and never calls into
/// this class for them — see that class's own comment.
/// <c>request_approval</c> is HALF control-flow, half a Process call (slice
/// 10): THIS class only creates the <c>ApprovalRequest</c> (below); the pause/
/// resume/branch-on-outcome part is <see cref="AutomationRunner"/>'s, exactly
/// mirroring the wait_n_days split — this class is never asked to decide
/// which of onApproved/onRejected runs.
///
/// Registered against <see cref="IAutomationActionExecutor"/> in
/// <c>Program.cs</c> — see that interface's own doc comment for why the
/// interface lives in SystemApi while this implementation lives here.
///
/// Constructor dependencies only (never a method parameter, so
/// <c>LayerBoundaryTests</c> never sees them — same discipline
/// <c>ReminderProcess</c>'s own class comment documents for
/// <see cref="NotificationDispatcher"/>): the real Process classes a manual
/// API call would use, plus <see cref="AutomationRunContext"/> (a SystemApi
/// type, fine as a constructor dependency) for stamping
/// <see cref="TaskItem.SourceRef"/> with the CURRENT run's id.
/// </summary>
public sealed class AutomationActionExecutor : IAutomationActionExecutor
{
    private readonly TaskProcess _tasks;
    private readonly ReminderProcess _reminders;
    private readonly LeadAssignProcess _leadAssign;
    private readonly LeadWriteProcess _leadWrite;
    private readonly LeadReadProcess _leadRead;
    private readonly NotificationDispatcher _notify;
    private readonly AutomationRunContext _runContext;
    private readonly WebhookStore _webhooks;
    private readonly IEmailSecretProtector _protector;
    private readonly OrganizationRoleService _roles;
    private readonly IWebHostEnvironment _env;
    private readonly ApprovalProcess _approvals;
    private readonly AccountProcess _accounts;
    private readonly ContactProcess _contacts;
    private readonly InvoiceProcess _invoices;
    private readonly PipelineStages _stages;

    public AutomationActionExecutor(
        TaskProcess tasks, ReminderProcess reminders, LeadAssignProcess leadAssign,
        LeadWriteProcess leadWrite, LeadReadProcess leadRead, NotificationDispatcher notify,
        AutomationRunContext runContext, WebhookStore webhooks, IEmailSecretProtector protector,
        OrganizationRoleService roles, IWebHostEnvironment env, ApprovalProcess approvals,
        AccountProcess accounts, ContactProcess contacts, InvoiceProcess invoices, PipelineStages stages)
    {
        _tasks = tasks;
        _reminders = reminders;
        _leadAssign = leadAssign;
        _leadWrite = leadWrite;
        _leadRead = leadRead;
        _notify = notify;
        _runContext = runContext;
        _webhooks = webhooks;
        _protector = protector;
        _roles = roles;
        _env = env;
        _approvals = approvals;
        _accounts = accounts;
        _contacts = contacts;
        _invoices = invoices;
        _stages = stages;
    }

    /// <summary>The reserved system actor (design §5/§9: "action execution
    /// runs with no ambient caller permission"). <see cref="Guid.Empty"/> —
    /// never a real <c>Profile.Id</c> (every profile row gets
    /// <c>Guid.NewGuid()</c>), the same "sentinel, not a real row" convention
    /// <c>AggregateOwner.Unassigned</c> already uses for "no owner"/"no team".
    /// Used only where a Process method's signature requires a non-nullable
    /// actor id (<c>LeadAssignProcess.AssignAsync</c>'s <c>actorId</c>,
    /// <c>LeadActor.Id</c>); the DOMAIN EVENT each of those raises is what a
    /// timeline reader actually sees, and THAT carries the real "who caused
    /// this" fact via <c>DomainEvent.CausedByAutomationRunId</c>/
    /// <c>CausedByAutomationId</c> stamped ambiently (see
    /// <see cref="AutomationRunContext"/>), not via this sentinel.</summary>
    public static readonly Guid SystemActorId = Guid.Empty;

    /// <summary>An elevated <see cref="RecordAccessContext"/> that bypasses
    /// every ownership/team gate — design §9's "the action catalogue itself
    /// is the permission boundary": an admin who could publish this
    /// automation already had the authority to configure what it does, so no
    /// second, caller-shaped permission check applies at execution time. Each
    /// action still goes through its Process method's OWN cross-cutting
    /// checks that are not about caller identity — an assignee must still
    /// belong to the org (<c>TaskStore.ProfileInOrgAsync</c>,
    /// <c>LeadAssignProcess</c>'s own org-membership check) — because those
    /// are correctness rules, not authority checks.</summary>
    public static readonly RecordAccessContext SystemAccess =
        new(SystemActorId, IsOrgAdmin: true, HasManagerAccess: true, TeamScope.Everything, Visibility: "manage");

    /// <summary>
    /// The view a `call_webhook` action's record snapshot renders under
    /// (2026-09-27 coordinator fix, design §12 slice 4 follow-up): "the
    /// org-admin view (webhooks are admin-configured)" — an admin who
    /// configured the automation already had authority to configure the
    /// webhook, so the payload carries what an admin would see, never masked
    /// down to some caller that does not exist for a server-to-server call.
    /// Contrast <see cref="SendTemplateEmailAsync"/>, which resolves a
    /// DIFFERENT, per-recipient view for the exact same reason in the other
    /// direction — "an email must never contain a value the recipient could
    /// not see in the app".
    /// </summary>
    private static readonly LeadView AdminView = new(true, true, "admin");

    public async Task<AutomationActionOutcome> ExecuteAsync(
        AppDbContext db, JsonElement action, string aggregateType, Guid aggregateId,
        IReadOnlyDictionary<string, object?> values, CancellationToken ct)
    {
        var type = GetString(action, "type") ?? "(unknown)";
        return type switch
        {
            AutomationRuleValidator.ActionTypes.CreateTask => await CreateTaskAsync(db, action, aggregateType, aggregateId, values, ct),
            AutomationRuleValidator.ActionTypes.CreateReminder => await CreateReminderAsync(db, action, aggregateType, aggregateId, values, ct),
            AutomationRuleValidator.ActionTypes.AssignOwner => await AssignOwnerAsync(db, action, aggregateType, aggregateId, ct),
            AutomationRuleValidator.ActionTypes.AssignTeam => await AssignTeamAsync(db, action, aggregateType, aggregateId, ct),
            AutomationRuleValidator.ActionTypes.SetField => await SetFieldAsync(db, action, aggregateType, aggregateId, ct),
            AutomationRuleValidator.ActionTypes.RequestApproval => await RequestApprovalAsync(db, action, aggregateType, aggregateId, ct),
            AutomationRuleValidator.ActionTypes.Notify => await NotifyAsync(db, action, aggregateType, aggregateId, values, ct),
            AutomationRuleValidator.ActionTypes.CallWebhook => await CallWebhookAsync(db, action, aggregateType, aggregateId, values, ct),
            AutomationRuleValidator.ActionTypes.SendTemplateEmail => await SendTemplateEmailAsync(db, action, aggregateType, aggregateId, values, ct),
            // E2.5 (design doc §12 slice 7, item 1/2): the two actions the
            // "deal won" billing chain needed that the v1 catalogue had no
            // equivalent for — each calls straight into the EXISTING
            // PaymentWorkflowService method a manual/inline call already used,
            // never a reimplementation.
            AutomationRuleValidator.ActionTypes.CreateInvoice => await CreateInvoiceAsync(db, aggregateType, aggregateId, ct),
            AutomationRuleValidator.ActionTypes.CreateCollectionTask => await CreateCollectionTaskAsync(db, aggregateType, aggregateId, ct),
            AutomationRuleValidator.ActionTypes.CreateDeal => await CreateDealAsync(db, action, aggregateType, aggregateId, values, ct),
            _ => new AutomationActionOutcome(type, "failed", "This action type isn't executed by this build yet."),
        };
    }

    /// <summary>
    /// E14.4: makes a deal on an account THROUGH <see cref="LeadWriteProcess.CreateAsync"/> - the same path <c>POST /leads</c> and the
    /// partner billing deal (<c>PartnerRemittanceProcess.EnsureBillingDealAsync</c>, the precedent for acting as a chosen owner) use - so the
    /// stage-start rule, the stage's entry requirements, team and playbook resolution, <c>lead.created</c>, FieldAudit and the aggregate
    /// dirty keys all behave as for a person. Works on any event that carries an account (account, lead, contact, invoice, quote, amc).
    ///
    /// The deal is owned by (and created AS) the account's owner, a fixed user, or whoever the org's lead routing picks. The name is
    /// <c>nameTemplate</c> rendered with <see cref="AutomationMergeFields"/> over the account's merge fields (the E16.3 merge helper is not
    /// in main yet; this is the existing token substitution). No email or phone is sent, so the open-deal duplicate check has nothing to
    /// match on, exactly as for a person who creates a deal from an account without contact details.
    ///
    /// IDEMPOTENT PER RUN: the lead.created event of a deal this run already made carries <c>CausedByAutomationRunId</c> (stamped by
    /// SaveChanges from <see cref="AutomationRunContext"/>); a re-execution of the same run finds it and reports "skipped" with the existing
    /// deal instead of making a second one.
    /// </summary>
    private async Task<AutomationActionOutcome> CreateDealAsync(
        AppDbContext db, JsonElement action, string aggregateType, Guid aggregateId,
        IReadOnlyDictionary<string, object?> values, CancellationToken ct)
    {
        const string T = AutomationRuleValidator.ActionTypes.CreateDeal;
        var accountId = await ResolveAccountIdAsync(db, aggregateType, aggregateId, ct);
        if (accountId is null)
            return new AutomationActionOutcome(T, "failed", "This record has no account to make a deal on.");
        var account = await db.Accounts.AsNoTracking().FirstOrDefaultAsync(a => a.Id == accountId, ct);
        if (account is null)
            return new AutomationActionOutcome(T, "failed", "Account not found.");
        var playbookId = GetGuid(action, "playbookId");
        if (playbookId is null)
            return new AutomationActionOutcome(T, "failed", "Missing \"playbookId\".");

        if (_runContext.RunId is Guid runId)
        {
            var madeByThisRun = await db.DomainEvents.AsNoTracking()
                .Where(e => e.Type == DomainEventTypes.Keys.LeadCreated && e.CausedByAutomationRunId == runId)
                .Select(e => e.AggregateId).ToListAsync(ct);
            if (madeByThisRun.Count > 0)
            {
                var existing = await db.Leads.AsNoTracking()
                    .Where(l => madeByThisRun.Contains(l.Id) && l.AccountId == accountId)
                    .Select(l => (Guid?)l.Id).FirstOrDefaultAsync(ct);
                if (existing is not null)
                    return new AutomationActionOutcome(T, "skipped", "This run already made the deal.", ResultRef: existing.Value.ToString());
            }
        }

        var source = GetString(action, "source");
        Guid? ownerId;
        Guid? teamId = GetGuid(action, "teamId");
        switch (GetString(action, "ownerKind") ?? "account_owner")
        {
            case "account_owner": ownerId = account.OwnerId; break;
            case "fixed_user": ownerId = GetGuid(action, "ownerUserId"); break;
            case "routing":
                var decision = await LeadRoutingService.PickOwnerAsync(db, source);
                ownerId = decision.Owner?.Id;
                if (teamId is null && decision.TeamForced) teamId = decision.ForcedTeamId;
                break;
            default: ownerId = null; break;
        }
        if (ownerId is not Guid owner)
            return new AutomationActionOutcome(T, "failed", "Could not resolve who should own the deal.");
        var ownerProfile = await db.Profiles.AsNoTracking().Where(p => p.Id == owner).Select(p => new { p.FullName, p.IsActive }).FirstOrDefaultAsync(ct);
        if (ownerProfile is null || !ownerProfile.IsActive)
            return new AutomationActionOutcome(T, "failed", "The deal's owner is not an active person in this organization.");

        // The account's team, when the owner is still in it; otherwise the lead path resolves the owner's own team (and refuses, as it does
        // for a person, when the owner is in several teams and none was named).
        teamId ??= account.TeamId;
        if (teamId is Guid wantedTeam && !await db.TeamMembers.AsNoTracking().AnyAsync(m => m.TeamId == wantedTeam && m.UserId == owner && m.LeftAt == null, ct))
            teamId = null;

        var snapshot = MergeValues(values, await BuildAccountSnapshotAsync(db, account.Id, AdminView, canSeeAccountFinancials: false, ct));
        var name = AutomationMergeFields.Render(GetString(action, "nameTemplate") ?? "{{account.name}}", snapshot).Trim();
        if (name.Length == 0) name = account.Name;

        decimal? value = action.TryGetProperty("estimatedValue", out var valueEl) && valueEl.ValueKind == JsonValueKind.Number && valueEl.TryGetDecimal(out var dv) ? dv : null;
        var input = new LeadInput(
            Name: name, Company: account.Name, Email: null, Phone: null, Status: GetString(action, "stage"), Priority: null, Source: source,
            EstimatedValue: value, Notes: null, NextFollowUpAt: null, Reason: null, Custom: null, AccountId: account.Id, CloseReason: null,
            Products: null, Address: null, City: null, State: null, PostalCode: null, Country: null, Nationality: null, ExpectedCloseDate: null,
            TeamId: teamId, PlaybookId: playbookId);
        var actor = new LeadActor(owner, db.CurrentOrgId, ownerProfile.FullName ?? "Owner", IsManager: true, Visibility: "manage", CanCreateTags: false, IsAutomation: true);
        // skipFormRequirements: nobody fills the lead form for an automation's deal (same reason as the partner billing deal).
        var (refusal, dto) = await _leadWrite.CreateAsync(SystemAccess, new LeadView(true, true, "automation"), actor, input, skipFormRequirements: true,
            // The step's "Notify the owner" switch (default off): the deal is created AS its owner, so without it nobody is told.
            notifyOwner: action.TryGetProperty("notifyOwner", out var notifyEl) && notifyEl.ValueKind == JsonValueKind.True);
        if (refusal is not null || dto is null)
            return new AutomationActionOutcome(T, "failed", refusal?.Reason ?? "The deal could not be created.");
        return new AutomationActionOutcome(T, "success", ResultRef: dto.Id.ToString());
    }

    /// <summary>The account a record belongs to, for actions that act on "the account" whatever event woke the rule.</summary>
    private static async Task<Guid?> ResolveAccountIdAsync(AppDbContext db, string aggregateType, Guid aggregateId, CancellationToken ct)
    {
        switch (aggregateType)
        {
            case DomainEventTypes.AggregateTypes.Account: return aggregateId;
            case DomainEventTypes.AggregateTypes.Lead:
                return await db.Leads.AsNoTracking().Where(l => l.Id == aggregateId).Select(l => l.AccountId).FirstOrDefaultAsync(ct);
            case DomainEventTypes.AggregateTypes.Contact:
                return await db.Contacts.AsNoTracking().Where(c => c.Id == aggregateId).Select(c => (Guid?)c.AccountId).FirstOrDefaultAsync(ct);
            case DomainEventTypes.AggregateTypes.Invoice:
                return await db.Invoices.AsNoTracking().Where(i => i.Id == aggregateId).Select(i => i.AccountId).FirstOrDefaultAsync(ct);
            case DomainEventTypes.AggregateTypes.Amc:
                return await db.Amcs.AsNoTracking().Where(a => a.Id == aggregateId).Select(a => a.AccountId).FirstOrDefaultAsync(ct);
            case DomainEventTypes.AggregateTypes.Quote:
                return await db.Proposals.AsNoTracking().Where(p => p.Id == aggregateId)
                    .Join(db.Leads.AsNoTracking(), p => p.LeadId, l => l.Id, (p, l) => l.AccountId).FirstOrDefaultAsync(ct);
            default: return null;
        }
    }

    /// <summary>
    /// E2.5 (design doc §12 slice 7): title/description/notes/body strings on
    /// every action that writes free text are ALWAYS run through
    /// <see cref="AutomationMergeFields.Render"/> against <paramref name="values"/>
    /// first — a template with no <c>{{...}}</c> token renders unchanged, so
    /// this is backward compatible with every automation authored before this
    /// slice, and is what lets a built-in's action carry <c>{{follow_up_note}}</c>/
    /// <c>{{title}}</c>/<c>{{notes}}</c> tokens that resolve to the EXACT
    /// strings the migrated scan used to write inline (see
    /// <see cref="DomainEventPayloads.LeadIdle"/>/<see cref="DomainEventPayloads.AmcExpiring"/>'s
    /// own comments for why those specific fields exist).
    /// </summary>
    private static string? RenderOptional(JsonElement action, string property, IReadOnlyDictionary<string, object?> values) =>
        GetString(action, property) is string s ? AutomationMergeFields.Render(s, values) : null;

    /// <summary>E12.2 (decision 16): the event's merge values as <paramref name="readerId"/> may see them. Used by every
    /// action that writes text a PERSON reads (task, reminder, notification, email to staff).</summary>
    private async Task<IReadOnlyDictionary<string, object?>> ValuesForReaderAsync(
        AppDbContext db, Guid readerId, Guid? ownerId, Guid? teamId,
        IReadOnlyDictionary<string, object?> values, CancellationToken ct)
    {
        var (view, _) = await RecipientViewAsync(db, readerId, ct);
        return AutomationEnvelopeMasking.ForReader(values, view.Sensitive, ownerId, teamId);
    }

    private async Task<AutomationActionOutcome> CreateTaskAsync(
        AppDbContext db, JsonElement action, string aggregateType, Guid aggregateId,
        IReadOnlyDictionary<string, object?> values, CancellationToken ct)
    {
        var (ownerId, recordTeamId) = await ResolveRecordOwnerAsync(db, aggregateType, aggregateId, ct);
        // E13: the handover list asks for a ROLE'S SHARED QUEUE with "assigneeRoleKey" (a published automation never carries it - the
        // validator's assigneeKind vocabulary is unchanged): one task, no assignee, on the deal's team, until someone claims it.
        var roleKey = GetString(action, "assigneeRoleKey");
        var assigneeId = roleKey is null ? ResolveAssignee(action, ownerId) : null;
        if (assigneeId is null && roleKey is null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateTask, "failed", "Could not resolve an assignee.");
        if (assigneeId is Guid reader) values = await ValuesForReaderAsync(db, reader, ownerId, recordTeamId, values, ct);
        var title = RenderOptional(action, "title", values);
        if (string.IsNullOrWhiteSpace(title))
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateTask, "failed", "Missing \"title\".");

        var linkedType = aggregateType == DomainEventTypes.AggregateTypes.Lead ? TaskLinkedRecordTypes.Lead
            : aggregateType == DomainEventTypes.AggregateTypes.Account ? TaskLinkedRecordTypes.Account
            : (string?)null;

        var dueInDays = GetInt(action, "dueInDays");
        DateTime? dueAt = dueInDays is int d ? DateTime.UtcNow.Date.AddDays(d) : null;
        // Item 6: a workflow stage's task is due N WORKING days out, counted on the org calendar (team override else org default).
        if (GetInt(action, "dueInWorkingDays") is int workingDays)
            dueAt = OrgCalendarService.AddWorkingDays(await OrgCalendarService.ResolveAsync(db, db.CurrentOrgId, recordTeamId), DateTime.UtcNow, workingDays);
        // Item 6: where a stage task came from (workflow, stage, definition id, enter/leave); a published automation never carries these.
        var origin = GetGuid(action, "originPlaybookId") is Guid originPlaybook && GetString(action, "originStage") is string originStage
            && GetString(action, "originKey") is string originKey
            ? new TaskOrigin(originPlaybook, originStage, originKey, GetString(action, "originTrigger") ?? StageTaskTriggers.Enter)
            : null;
        var input = new TaskInput(
            title, RenderOptional(action, "description", values), assigneeId,
            dueAt,
            GetString(action, "priority"), linkedType, linkedType is not null ? aggregateId : null,
            roleKey is not null ? recordTeamId : null, null);

        // Source/SourceRef (the reserved TaskItem columns E2.1 built for
        // exactly this — design §1) are set on the SAME create call, so the
        // TaskCreated event's own payload (built from `task.Source` before
        // that write's SaveChanges) agrees with the row — never patched onto
        // an already-saved, already-raised task afterward.
        var (dto, refusal) = await _tasks.CreateAsync(
            SystemAccess, db.CurrentOrgId, input, ct, TaskSources.Rule, _runContext.RunId,
            // E13: the stage-task list (and, before 2026-11-10, the handover list) creates its tasks through this same action (StageTaskDomainEventHandler, via the stage-task list); a published automation never
            // carries these two keys, so for it both are null and the call is unchanged.
            GetString(action, "handoverStage"), GetString(action, "handoverKey"), roleKey, origin);
        if (refusal is not null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateTask, "failed", refusal.Reason);

        return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateTask, "success", ResultRef: dto!.Id.ToString());
    }

    private async Task<AutomationActionOutcome> CreateReminderAsync(
        AppDbContext db, JsonElement action, string aggregateType, Guid aggregateId,
        IReadOnlyDictionary<string, object?> values, CancellationToken ct)
    {
        var (ownerId, reminderTeamId, leadId, amcId) = await ResolveReminderTargetAsync(db, aggregateType, aggregateId, ct);
        var assigneeId = ResolveAssignee(action, ownerId);
        if (assigneeId is null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateReminder, "failed", "Could not resolve who this reminder is for.");
        values = await ValuesForReaderAsync(db, assigneeId.Value, ownerId, reminderTeamId, values, ct);
        var title = RenderOptional(action, "title", values);
        if (string.IsNullOrWhiteSpace(title))
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateReminder, "failed", "Missing \"title\".");

        // E2.5 (design doc §12 slice 7): an EXACT instant — a
        // <c>{{token}}</c> template resolved against an ISO datetime string
        // already in `values` (e.g. AmcExpiring's `remind_at_utc`) — takes
        // priority over `remindInDays` (relative to NOW at action-run time),
        // which cannot express "scheduled ahead of when it fires". Every
        // automation authored before this addition has no `remindAt` field
        // and is unaffected.
        var remindAtTemplate = RenderOptional(action, "remindAt", values);
        DateTime remindAt;
        if (!string.IsNullOrWhiteSpace(remindAtTemplate) &&
            DateTime.TryParse(remindAtTemplate, null, System.Globalization.DateTimeStyles.RoundtripKind, out var exact))
        {
            remindAt = exact;
        }
        else
        {
            var inDays = GetInt(action, "remindInDays") ?? 0;
            remindAt = DateTime.UtcNow.AddDays(inDays);
        }

        var eventType = GetString(action, "eventType"); // e.g. NotificationEvents.Keys.LeadIdle/.AmcExpiring — builder-set, optional

        // E2.5: an org's own currently-configured delivery channels — read
        // from `values["channels"]` (a fact carried by the triggering event,
        // e.g. AmcExpiring's own `channels`, itself read from
        // AmcReminderConfigDto at scan time) when present, so an admin's
        // channel choice on that feature's OWN settings screen keeps applying
        // exactly as it did before this migration (design §12 slice 7 rule 4).
        // Falls back to the same push+in_app default create_reminder always
        // used before this addition — every automation authored earlier has
        // no such fact in scope and is unaffected.
        var channels = values.TryGetValue("channels", out var channelsValue) && channelsValue is List<object?> list && list.Count > 0
            ? list.OfType<string>().ToList()
            : new List<string> { "push", "in_app" };

        var input = new ReminderInput(
            leadId, title, RenderOptional(action, "notes", values), remindAt,
            channels, null, AmcId: amcId, EventType: eventType);

        var (dto, refusal) = await _reminders.CreateAsync(assigneeId.Value, input, ct);
        if (refusal is not null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateReminder, "failed", refusal.Reason);
        return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateReminder, "success", ResultRef: dto!.Id.ToString());
    }

    /// <summary>Owner/team/lead/AMC resolution for <c>create_reminder</c> —
    /// separate from <see cref="ResolveRecordOwnerAsync"/> (which only knows
    /// Lead/Account/Invoice) because an AMC-triggered reminder needs its
    /// LeadId (for <see cref="Reminder.LeadId"/>) AND its own id (for
    /// <see cref="Reminder.AmcId"/>) at once, neither of which the generic
    /// two-tuple resolver returns.</summary>
    private static async Task<(Guid? OwnerId, Guid? TeamId, Guid? LeadId, Guid? AmcId)> ResolveReminderTargetAsync(
        AppDbContext db, string aggregateType, Guid aggregateId, CancellationToken ct)
    {
        if (aggregateType == DomainEventTypes.AggregateTypes.Amc)
        {
            var amc = await db.Amcs.AsNoTracking().Where(a => a.Id == aggregateId)
                .Select(a => new { a.OwnerId, a.LeadId }).FirstOrDefaultAsync(ct);
            return amc is null ? (null, null, null, null) : (amc.OwnerId, null, amc.LeadId, aggregateId);
        }
        var (ownerId, teamId) = await ResolveRecordOwnerAsync(db, aggregateType, aggregateId, ct);
        var leadId = aggregateType == DomainEventTypes.AggregateTypes.Lead ? aggregateId : (Guid?)null;
        return (ownerId, teamId, leadId, null);
    }

    private async Task<AutomationActionOutcome> AssignOwnerAsync(AppDbContext db, JsonElement action, string aggregateType, Guid aggregateId, CancellationToken ct)
    {
        if (aggregateType != DomainEventTypes.AggregateTypes.Lead)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.AssignOwner, "failed", "assign_owner only supports leads today.");

        var newOwnerId = ResolveAssignee(action, currentOwnerId: null);
        if (newOwnerId is null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.AssignOwner, "failed", "Could not resolve the new owner.");

        var (refusal, dto) = await _leadAssign.AssignAsync(
            SystemAccess, new LeadView(true, true, "automation"), SystemActorId, "Automation", db.CurrentOrgId,
            callerIsManager: true, visibility: "manage", aggregateId, new AssignInput(newOwnerId));

        if (refusal is not null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.AssignOwner, "failed", refusal.Reason);
        return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.AssignOwner, "success", ResultRef: dto!.Id.ToString());
    }

    /// <summary>
    /// Owner decision (to-do/e2-automation-design.md §14.6, 2026-09-27):
    /// "assign to team" hands the lead to the org's OWN lead routing
    /// (round-robin/load/fixed, whichever the org has configured), limited to
    /// the named team — the same decision-picking path a new inbound lead
    /// takes (<see cref="LeadRoutingService.PickOwnerForTeamAsync"/>), never
    /// "the first/earliest member". The reassignment ITSELF still goes
    /// through the SAME <c>LeadAssignProcess.AssignAsync</c> <c>assign_owner</c>
    /// uses (no standalone "move to a different team" endpoint exists — see
    /// that action's own comment), so a manager reassigning within a team and
    /// this action produce an identical row shape; only WHO gets picked
    /// differs from a fixed single choice.
    /// </summary>
    private async Task<AutomationActionOutcome> AssignTeamAsync(AppDbContext db, JsonElement action, string aggregateType, Guid aggregateId, CancellationToken ct)
    {
        if (aggregateType != DomainEventTypes.AggregateTypes.Lead)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.AssignTeam, "failed", "assign_team only supports leads today.");

        var teamId = GetGuid(action, "teamId");
        if (teamId is null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.AssignTeam, "failed", "Missing \"teamId\".");

        var decision = await LeadRoutingService.PickOwnerForTeamAsync(db, teamId.Value);
        if (decision.Owner is null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.AssignTeam, "failed",
                "That team has no active member the org's routing could choose (no eligible member).");

        var (refusal, dto) = await _leadAssign.AssignAsync(
            SystemAccess, new LeadView(true, true, "automation"), SystemActorId, "Automation", db.CurrentOrgId,
            callerIsManager: true, visibility: "manage", aggregateId, new AssignInput(decision.Owner.Id));

        if (refusal is not null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.AssignTeam, "failed", refusal.Reason);
        return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.AssignTeam, "success", ResultRef: dto!.Id.ToString());
    }

    /// <summary>
    /// E2.5 (design doc §12 slice 7, item 1): the built-in "Deal won billing"
    /// automation's first action, reacting to <c>lead.closed_won</c>. Calls
    /// straight into <see cref="PaymentWorkflowService.CreateDraftInvoiceAndReminderIfEnabledAsync"/>
    /// — the exact invoice + "send the invoice" reminder logic
    /// <c>PaymentWorkflowService.OnDealWonAsync</c> used to run inline at
    /// every won-transition call site, unchanged. That method's own
    /// `cfg.Enabled`/`cfg.CreateDraftInvoice`/"already invoiced" checks are
    /// all still there — a "no-op, config says don't" or "already invoiced"
    /// outcome is reported as "skipped", not "failed" (nothing went wrong).
    /// </summary>
    private async Task<AutomationActionOutcome> CreateInvoiceAsync(AppDbContext db, string aggregateType, Guid aggregateId, CancellationToken ct)
    {
        if (aggregateType != DomainEventTypes.AggregateTypes.Lead)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateInvoice, "failed", "create_invoice only supports leads today.");

        var lead = await db.Leads.FirstOrDefaultAsync(l => l.Id == aggregateId, ct);
        if (lead is null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateInvoice, "failed", "Lead not found.");

        var invoice = await PaymentWorkflowService.CreateDraftInvoiceAndReminderIfEnabledAsync(db, lead, SystemActorId, ct: ct);
        return invoice is null
            ? new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateInvoice, "skipped", "Payment workflow is off, has no terms configured, or this lead is already invoiced.")
            : new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateInvoice, "success", ResultRef: invoice.Id.ToString());
    }

    /// <summary>
    /// E2.5 (design doc §12 slice 7, item 1): the built-in "Deal won billing"
    /// automation's second action, reacting to <c>invoice.raised</c>. Calls
    /// straight into <see cref="PaymentWorkflowService.CreateCollectionTaskIfEnabledAsync"/>
    /// — the exact collection-task logic <c>PaymentWorkflowService.OnInvoiceRaisedAsync</c>
    /// used to run inline, unchanged. Reacts to the SAME event a manually
    /// raised invoice also raises, so a manually created/raised invoice gets
    /// a collection task exactly the way it always did — the "automation" here
    /// is a relocation of the reaction, not a narrowing of which invoices
    /// qualify.
    /// </summary>
    private async Task<AutomationActionOutcome> CreateCollectionTaskAsync(AppDbContext db, string aggregateType, Guid aggregateId, CancellationToken ct)
    {
        if (aggregateType != DomainEventTypes.AggregateTypes.Invoice)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateCollectionTask, "failed", "create_collection_task only supports invoices today.");

        var invoice = await db.Invoices.FirstOrDefaultAsync(i => i.Id == aggregateId, ct);
        if (invoice is null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateCollectionTask, "failed", "Invoice not found.");

        var before = await db.CollectionTasks.CountAsync(t => t.InvoiceId == invoice.Id, ct);
        await PaymentWorkflowService.CreateCollectionTaskIfEnabledAsync(db, invoice, SystemActorId, _notify, ct);
        var after = await db.CollectionTasks.CountAsync(t => t.InvoiceId == invoice.Id, ct);
        return after > before
            ? new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateCollectionTask, "success")
            : new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CreateCollectionTask, "skipped", "Payment workflow is off, already has a collection task, or nothing is outstanding.");
    }

    /// <summary>
    /// Supports a curated set of Lead's own top-level scalar fields — the
    /// ones a "field_changed"/"set_field" rule realistically targets today.
    /// Anything else is refused by name rather than guessed at, the same
    /// "unreadable must refuse, not silently match/apply" discipline
    /// RuleEvaluator's own strict mode uses.
    /// </summary>
    private static readonly string[] SupportedSetFields = ["status", "priority", "source", "estimated_value", "notes"];

    private async Task<AutomationActionOutcome> SetFieldAsync(AppDbContext db, JsonElement action, string aggregateType, Guid aggregateId, CancellationToken ct)
    {
        // E10.8 - quote.sent / quote.accepted ("proposal sent / accepted") are quote-aggregate events, but a
        // stage move belongs to the quote's DEAL: act on it, through the same LeadWriteProcess.UpdateAsync below
        // (so the target stage's requirements still apply).
        if (aggregateType == DomainEventTypes.AggregateTypes.Quote)
        {
            var dealId = await db.Proposals.AsNoTracking().Where(p => p.Id == aggregateId).Select(p => (Guid?)p.LeadId).FirstOrDefaultAsync(ct);
            if (dealId is null)
                return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.SetField, "failed", "The quote no longer exists.");
            aggregateType = DomainEventTypes.AggregateTypes.Lead;
            aggregateId = dealId.Value;
        }
        if (aggregateType != DomainEventTypes.AggregateTypes.Lead)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.SetField, "failed", "set_field only supports leads today.");

        var field = GetString(action, "field");
        if (field is null || !SupportedSetFields.Contains(field))
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.SetField, "failed",
                $"\"{field}\" isn't a field this build can set (supported: {string.Join(", ", SupportedSetFields)}).");
        if (!action.TryGetProperty("value", out var value))
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.SetField, "failed", "Missing \"value\".");

        var input = BuildLeadInputForField(field, value);
        var actor = new LeadActor(SystemActorId, db.CurrentOrgId, "Automation", IsManager: true, Visibility: "manage", CanCreateTags: false, IsAutomation: true);
        var (refusal, dto) = await _leadWrite.UpdateAsync(SystemAccess, new LeadView(true, true, "automation"), actor, aggregateId, input);

        if (refusal is not null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.SetField, "failed", refusal.Reason);
        return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.SetField, "success", ResultRef: dto!.Id.ToString());
    }

    private static LeadInput BuildLeadInputForField(string field, JsonElement value) => new(
        Name: null, Company: null, Email: null, Phone: null,
        Status: field == "status" ? value.GetString() : null,
        Priority: field == "priority" ? value.GetString() : null,
        Source: field == "source" ? value.GetString() : null,
        EstimatedValue: field == "estimated_value" ? value.GetDecimal() : null,
        Notes: field == "notes" ? value.GetString() : null,
        NextFollowUpAt: null,
        Reason: "Set by automation",
        Custom: null, AccountId: null, CloseReason: null, Products: null,
        Address: null, City: null, State: null, PostalCode: null, Country: null, Nationality: null,
        ExpectedCloseDate: null);

    /// <summary>
    /// Design §12 slice 10 — creates the underlying <see cref="ApprovalRequest"/>
    /// through the SAME <see cref="ApprovalProcess.CreateAsync"/> a human's
    /// <c>POST /approvals</c> uses, so chain resolution (<c>ApprovalChainProcess
    /// .ResolveAndStartAsync</c>, called from inside CreateAsync), E0.1
    /// governance and the ApprovalRequested notification fan-out all apply
    /// completely unchanged — an automation is just one more caller, never a
    /// second approval-creation path.
    ///
    /// LEAD ONLY today, same restriction <c>set_field</c>/<c>assign_owner</c>
    /// already carry — <c>ApprovalRequest</c> itself is lead-scoped
    /// (<c>ApprovalRequest.LeadId</c> is non-nullable), so there is no shape to
    /// extend to an account yet.
    ///
    /// REQUESTER (owner decision, 2026-09-27, this brief item 1): the LEAD'S
    /// OWNER, never <see cref="SystemActorId"/> — E0.1's governance (team
    /// scope, self-decision policy) and every approver-facing "who asked for
    /// this" surface assume a real person raised the request; a sentinel actor
    /// would either be invisible to team-scoped visibility (nobody's
    /// team-mate) or, worse, satisfy a self-decision check for literally any
    /// decider. A lead with no owner cannot originate one — failed, not
    /// silently attributed to someone who didn't ask.
    /// </summary>
    private async Task<AutomationActionOutcome> RequestApprovalAsync(AppDbContext db, JsonElement action, string aggregateType, Guid aggregateId, CancellationToken ct)
    {
        if (aggregateType != DomainEventTypes.AggregateTypes.Lead)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.RequestApproval, "failed", "request_approval only supports leads today.");

        var reason = GetString(action, "reason");
        if (string.IsNullOrWhiteSpace(reason))
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.RequestApproval, "failed", "Missing \"reason\".");

        var (ownerId, _) = await ResolveRecordOwnerAsync(db, aggregateType, aggregateId, ct);
        if (ownerId is not Guid requesterId)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.RequestApproval, "failed",
                "This lead has no owner to request approval as.");

        var input = new ApprovalInput(ApprovalTypes.Automation, aggregateId, null, reason, null);
        // hasViewLeadValues: true — same AdminView reasoning CallWebhookAsync's
        // own comment gives: an automation is admin-configured, so the request
        // it raises is built from the admin view, never masked down to a
        // caller that does not exist for a server-to-server action.
        var outcome = await _approvals.CreateAsync(input, requesterId, hasViewLeadValues: true, ct);
        if (outcome.Refusal is not null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.RequestApproval, "failed", DescribeRefusal(outcome.Refusal));

        return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.RequestApproval, "success", ResultRef: outcome.Approval!.Id.ToString());
    }

    private static string DescribeRefusal(ApprovalProcess.Refusal refusal) =>
        refusal.Body is { } body ? JsonSerializer.Serialize(body) : refusal.Kind.ToString();

    private async Task<AutomationActionOutcome> NotifyAsync(
        AppDbContext db, JsonElement action, string aggregateType, Guid aggregateId,
        IReadOnlyDictionary<string, object?> values, CancellationToken ct)
    {
        var (ownerId, teamId) = await ResolveRecordOwnerAsync(db, aggregateType, aggregateId, ct);
        var recipients = await ResolveNotifyRecipientsAsync(db, action, ownerId, ct);
        if (recipients.Count == 0)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.Notify, "failed", "Could not resolve any recipient.");

        // E12.2 (decision 16): rendered ONCE PER RECIPIENT, like send_template_email - the text is read by that person, so
        // the event's sensitive facts (deal value, reason, phone) are masked at THEIR level.
        foreach (var recipientId in recipients)
        {
            var readerValues = await ValuesForReaderAsync(db, recipientId, ownerId, teamId, values, ct);
            var title = RenderOptional(action, "title", readerValues) ?? "Automation notification";
            var body = RenderOptional(action, "body", readerValues) ?? "";
            await _notify.NotifyAsync(new NotifyRequest(
                [recipientId], NotificationEvents.Keys.AutomationNotify, title, body)
            {
                LeadId = aggregateType == DomainEventTypes.AggregateTypes.Lead ? aggregateId : null,
                InvoiceId = aggregateType == DomainEventTypes.AggregateTypes.Invoice ? aggregateId : null,
                TeamId = teamId,
                InvolvedUserIds = [recipientId],
            }, ct);
        }

        return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.Notify, "success");
    }

    /// <summary>
    /// Design §6/§12 slice 4: an outbound call the rule builder configures
    /// directly (a URL + a payload template), distinct from the org's
    /// WebhookCatalog subscription list (see <see cref="WebhookSubscription.IsAutomationManaged"/>'s
    /// own comment) but delivered through the EXACT SAME durable queue —
    /// <see cref="WebhookDelivery"/> rows drained, signed and retried by
    /// <c>WebhookDispatchService.DrainAsync</c>, never a new HTTP client path
    /// here. <c>payload</c> (an optional JSON object action field) has every
    /// string VALUE merge-field rendered the same way <c>send_template_email</c>'s
    /// subject/body are; the run/record identity is always included so a
    /// receiver can correlate deliveries even with no custom payload configured.
    /// </summary>
    private async Task<AutomationActionOutcome> CallWebhookAsync(
        AppDbContext db, JsonElement action, string aggregateType, Guid aggregateId,
        IReadOnlyDictionary<string, object?> values, CancellationToken ct)
    {
        var url = GetString(action, "url");
        // Defence in depth against a run whose action list was saved before
        // AutomationRuleValidator carried this check, or written directly —
        // same reasoning as this class's own "no role targets" recheck.
        // WebhookDestinationGuard is the exact guard the connect-time
        // callback backstops (see that class's own doc comment); this stops
        // the delivery from ever being enqueued rather than only failing to
        // connect later.
        var urlProblem = WebhookDestinationGuard.ValidateUrl(url, allowInsecureHttp: _env.IsDevelopment());
        if (urlProblem is not null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CallWebhook, "failed", $"\"{urlProblem}\"");

        // Org-admin view (this class's own AdminView comment) — an automation's
        // webhook target is admin-configured, so its merge fields resolve as
        // an admin would see them, not masked down to a nonexistent caller.
        var recordSnapshot = await BuildRecordSnapshotAsync(db, aggregateType, aggregateId, AdminView, canSeeAccountFinancials: true, ct);
        var merged = MergeValues(values, recordSnapshot);

        var payload = new Dictionary<string, object?>
        {
            ["automation_run_id"] = _runContext.RunId,
            ["aggregate_type"] = aggregateType,
            ["aggregate_id"] = aggregateId,
        };
        if (action.TryGetProperty("payload", out var template) && template.ValueKind == JsonValueKind.Object)
            foreach (var prop in template.EnumerateObject())
                payload[prop.Name] = prop.Value.ValueKind == JsonValueKind.String
                    ? AutomationMergeFields.Render(prop.Value.GetString(), merged)
                    : ToPlainValue(prop.Value);

        var secretBytes = RandomNumberGenerator.GetBytes(32);
        var secret = "whsec_" + Convert.ToHexString(secretBytes).ToLowerInvariant();
        var subscription = await _webhooks.FindOrCreateAutomationManagedAsync(url!, _protector.Protect(secret), ct);

        var delivery = new WebhookDelivery
        {
            Id = Guid.NewGuid(), // assigned client-side, same reasoning as AutomationRunner's own run.Id
            OrgId = db.CurrentOrgId,
            SubscriptionId = subscription.Id,
            Event = subscription.Event,
            PayloadJson = JsonSerializer.Serialize(payload),
            NextAttemptAt = DateTime.UtcNow,
        };
        db.WebhookDeliveries.Add(delivery);
        await db.SaveChangesAsync(ct);

        return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.CallWebhook, "success", ResultRef: delivery.Id.ToString());
    }

    private static object? ToPlainValue(JsonElement el) => el.ValueKind switch
    {
        JsonValueKind.String => el.GetString(),
        JsonValueKind.Number => el.TryGetInt64(out var l) ? l : el.GetDecimal(),
        JsonValueKind.True => true,
        JsonValueKind.False => false,
        _ => null,
    };

    // --- record-snapshot merge fields (2026-09-27 coordinator fix) ----------

    /// <summary>
    /// A read-only snapshot of the triggering record's own merge-field values
    /// (<see cref="AutomationMergeFieldCatalog"/>'s vocabulary), loaded THROUGH
    /// <see cref="LeadReadProcess.GetAsync"/> — the same read path/DTO mapper
    /// (<c>LeadMapping.ToDto</c>) a manual <c>GET /leads/{id}</c> call uses —
    /// so <paramref name="view"/>'s masking (contact details, lead values,
    /// custom-field <see cref="CustomFieldMasking"/>) applies exactly as it
    /// would in the app. NEVER a raw entity read: that would bypass masking
    /// entirely, which is the one thing this fix exists to prevent.
    ///
    /// LOADED AT ACTION-EXECUTION TIME, not once per run — a <c>wait_n_days</c>
    /// resume calls this again with fresh data (design's own "so a resumed
    /// wait sees current values" requirement), because
    /// <see cref="ExecuteAsync"/> itself, not <c>AutomationRunner</c>, is what
    /// builds this snapshot.
    ///
    /// Lead, account, contact and invoice are supported (2026-09-27
    /// "automation reach" follow-up, design §15/§16) — any other aggregate
    /// type yields an empty snapshot (envelope-only merge fields still work),
    /// never an error. <paramref name="canSeeAccountFinancials"/> is a
    /// separate flag from <paramref name="view"/> because it gates a
    /// DIFFERENT permission (<c>ViewAccountFinancials</c>, not
    /// <c>ViewLeadValues</c>/<c>ViewContactDetails</c>) — see
    /// <see cref="AutomationMergeFieldCatalog.AccountFields"/>'s own comment.
    /// </summary>
    private async Task<Dictionary<string, object?>> BuildRecordSnapshotAsync(
        AppDbContext db, string aggregateType, Guid aggregateId, LeadView view, bool canSeeAccountFinancials, CancellationToken ct)
    {
        if (aggregateType == DomainEventTypes.AggregateTypes.Lead)
            return await BuildLeadSnapshotAsync(db, aggregateId, view, ct);
        if (aggregateType == DomainEventTypes.AggregateTypes.Account)
            return await BuildAccountSnapshotAsync(db, aggregateId, view, canSeeAccountFinancials, ct);
        if (aggregateType == DomainEventTypes.AggregateTypes.Contact)
            return await BuildContactSnapshotAsync(db, aggregateId, view, ct);
        if (aggregateType == DomainEventTypes.AggregateTypes.Invoice)
            return await BuildInvoiceSnapshotAsync(db, aggregateId, canSeeAccountFinancials, ct);
        return new Dictionary<string, object?>(StringComparer.Ordinal);
    }

    /// <summary>The system context a record is READ through, carrying the reader's sensitive-data access so the mappers
    /// mask for them. No access on the view (the admin view a webhook uses) = unmasked, as before.</summary>
    private static RecordAccessContext ReaderAccess(LeadView view) => SystemAccess with { Sensitive = view.Sensitive };

    private async Task<Dictionary<string, object?>> BuildLeadSnapshotAsync(
        AppDbContext db, Guid aggregateId, LeadView view, CancellationToken ct)
    {
        var snapshot = new Dictionary<string, object?>(StringComparer.Ordinal);
        var (_, dto) = await _leadRead.GetAsync(SystemAccess, view, aggregateId);
        if (dto is null) return snapshot; // deleted, or otherwise unreadable — merge fields render empty, not a failed action

        snapshot["lead.name"] = dto.Name;
        snapshot["lead.company"] = dto.Company;
        snapshot["lead.owner_name"] = dto.OwnerName;
        snapshot["lead.next_follow_up_at"] = dto.NextFollowUpAt?.ToString("yyyy-MM-dd");
        // Already null under !CanSeeContactDetails / !CanSeeValues — LeadMapping.ToDto
        // masked them before this DTO ever left the mapper (see class comment).
        snapshot["lead.email"] = dto.Email;
        snapshot["lead.phone"] = dto.Phone;
        if (dto.EstimatedValue is decimal estimatedValue)
        {
            var currency = await MoneyFormat.CurrencyAsync(db, db.CurrentOrgId, ct);
            snapshot["lead.estimated_value"] = MoneyFormat.Exact(estimatedValue, currency);
        }

        // Stage LABEL resolved against the lead's OWN playbook (memory:
        // "playbook stage resolution" — never the org-wide list), the same
        // StageService.LabelsAsync call DuplicateMatchService already uses for
        // an identical "which playbook is THIS lead on" question.
        var labels = await _stages.LabelsAsync(dto.PlaybookId);
        snapshot["lead.stage"] = labels.GetValueOrDefault(dto.Status, dto.Status);

        // custom.<key> — dto.Custom is ALREADY CustomFieldMasking-applied
        // (hidden values replaced with CustomFieldMasking.Hidden) by the same
        // mapper call above, so no second masking pass is needed here.
        AddCustom(snapshot, dto.Custom);
        return snapshot;
    }

    /// <summary>Loaded through <see cref="AccountProcess.GetAsync"/> — the
    /// same read path/DTO mapper <c>GET /accounts/{id}</c> uses — so
    /// <paramref name="canSeeValues"/>/<paramref name="canSeeAccountFinancials"/>'s
    /// masking (open value / outstanding, account-money-masking) applies
    /// exactly as it would in the app.</summary>
    private async Task<Dictionary<string, object?>> BuildAccountSnapshotAsync(
        AppDbContext db, Guid aggregateId, LeadView view, bool canSeeAccountFinancials, CancellationToken ct)
    {
        var snapshot = new Dictionary<string, object?>(StringComparer.Ordinal);
        var outcome = await _accounts.GetAsync(ReaderAccess(view), canSeeAccountFinancials, aggregateId, view.CallerRole, view.CanSeeValues, ct);
        if (outcome.Refusal is not null || outcome.Detail is null) return snapshot;

        var account = outcome.Detail.Account;
        snapshot["account.name"] = account.Name;
        snapshot["account.industry"] = account.Industry;
        snapshot["account.owner_name"] = account.OwnerName;
        var currency = await MoneyFormat.CurrencyAsync(db, db.CurrentOrgId, ct);
        if (account.OpenValue is decimal openValue)
            snapshot["account.open_value"] = MoneyFormat.Exact(openValue, currency);
        if (account.Outstanding is decimal outstanding)
            snapshot["account.outstanding"] = MoneyFormat.Exact(outstanding, currency);
        AddCustom(snapshot, account.Custom);
        return snapshot;
    }

    /// <summary>Loaded through <see cref="ContactProcess.GetAsync"/> — the same
    /// read path/DTO mapper <c>GET /contacts/{id}</c> uses. Email/phone are
    /// masked here (not by <c>ContactProcess</c> itself, which has no partial
    /// view of a contact — see that method's own doc comment) because a
    /// merge-field recipient is a DIFFERENT identity than whichever caller is
    /// executing this action.</summary>
    private async Task<Dictionary<string, object?>> BuildContactSnapshotAsync(
        AppDbContext db, Guid aggregateId, LeadView view, CancellationToken ct)
    {
        var snapshot = new Dictionary<string, object?>(StringComparer.Ordinal);
        var outcome = await _contacts.GetAsync(ReaderAccess(view), aggregateId, view.CallerRole, ct);
        if (outcome.Refusal is not null || outcome.Detail is null) return snapshot;

        var contact = outcome.Detail.Contact;
        snapshot["contact.name"] = contact.Name;
        snapshot["contact.title"] = contact.Title;
        snapshot["contact.account_name"] = outcome.Detail.AccountName;
        // The contact mapper already applied the reader's contact-details level (masked text, or null when hidden).
        snapshot["contact.email"] = contact.Email;
        snapshot["contact.phone"] = contact.Phone;
        AddCustom(snapshot, contact.Custom);
        return snapshot;
    }

    /// <summary>Loaded through <see cref="InvoiceProcess.GetAsync"/> — the
    /// same read path/DTO mapper <c>GET /invoices/{id}</c> uses, so
    /// <paramref name="canSeeAccountFinancials"/>'s masking (invoice-money-masking,
    /// owner decision 2026-09-28: invoice amount/balance follow
    /// ViewAccountFinancials everywhere, including automation merge fields)
    /// applies exactly as it would in the app. amount/balance are simply
    /// omitted from the snapshot when masked — same "absent key renders empty"
    /// convention <see cref="BuildAccountSnapshotAsync"/>'s own open_value/
    /// outstanding already use.</summary>
    private async Task<Dictionary<string, object?>> BuildInvoiceSnapshotAsync(
        AppDbContext db, Guid aggregateId, bool canSeeAccountFinancials, CancellationToken ct)
    {
        var snapshot = new Dictionary<string, object?>(StringComparer.Ordinal);
        var outcome = await _invoices.GetAsync(SystemAccess, aggregateId, canSeeAccountFinancials, ct);
        if (outcome.Refusal is not null || outcome.Detail is null) return snapshot;

        var invoice = outcome.Detail.Invoice;
        var currency = await MoneyFormat.CurrencyAsync(db, db.CurrentOrgId, ct);
        snapshot["invoice.number"] = invoice.Number;
        if (invoice.Amount is decimal amount) snapshot["invoice.amount"] = MoneyFormat.Exact(amount, currency);
        if (invoice.Balance is decimal balance) snapshot["invoice.balance"] = MoneyFormat.Exact(balance, currency);
        snapshot["invoice.due_date"] = invoice.DueDate.ToString("yyyy-MM-dd");
        snapshot["invoice.status"] = invoice.Status;
        snapshot["invoice.account_name"] = invoice.Company;
        return snapshot;
    }

    private static void AddCustom(Dictionary<string, object?> snapshot, JsonElement? custom)
    {
        if (custom is not { ValueKind: JsonValueKind.Object } obj) return;
        foreach (var prop in obj.EnumerateObject())
            snapshot[$"custom.{prop.Name}"] = prop.Value.ValueKind == JsonValueKind.String
                ? prop.Value.GetString()
                : ToPlainValue(prop.Value);
    }

    /// <summary>Record-snapshot fields OVERLAY the event envelope — no key
    /// collision is expected (the envelope's keys are bare event-payload
    /// names; every snapshot key is namespaced <c>lead.*</c>/<c>custom.*</c>),
    /// but overlay rather than a plain union in case a future entity's
    /// snapshot ever does need to win.</summary>
    private static Dictionary<string, object?> MergeValues(
        IReadOnlyDictionary<string, object?> envelope, IReadOnlyDictionary<string, object?> snapshot)
    {
        var merged = new Dictionary<string, object?>(envelope, StringComparer.Ordinal);
        foreach (var (key, value) in snapshot) merged[key] = value;
        return merged;
    }

    /// <summary>The recipient's OWN role/permissions (design's "the
    /// RECIPIENT's role for an email... a value the recipient could not see in
    /// the app"), resolved the same way <see cref="OrganizationRoleService.ResolveAsync"/>
    /// already resolves anyone's — never the calling automation's own
    /// (nonexistent) permissions. A recipient profile that no longer exists
    /// (deleted between resolution and send — rare, not impossible) falls back
    /// to the least-privileged view, never the most: an email to someone this
    /// build can no longer identify must not accidentally leak contact details
    /// or lead values.</summary>
    private async Task<(LeadView View, bool CanSeeAccountFinancials)> RecipientViewAsync(AppDbContext db, Guid recipientId, CancellationToken ct)
    {
        var profile = await db.Profiles.AsNoTracking().FirstOrDefaultAsync(p => p.Id == recipientId, ct);
        if (profile is null)
            return (new LeadView(false, false, "", new SensitiveAccess(
                SensitiveCategories.All.ToDictionary(c => c, _ => SensitiveLevels.Hidden),
                SensitiveAccess.ScopeOwn, recipientId, TeamScope.None)), false);

        var resolved = await _roles.ResolveAsync(profile, ct);
        // E12.2 (decision 16): the recipient's full sensitive-data access (levels, assigned scope, teams), not two booleans,
        // so text written for them is masked at THEIR level (a masked reader gets masked text, a hidden one nothing).
        var sensitive = await RecordAccessContexts.SensitiveForAsync(db, resolved, db.CurrentOrgId, profile.Id, ct);
        var view = new LeadView(
            resolved.Permissions.Contains(OrganizationPermissions.ViewContactDetails),
            resolved.Permissions.Contains(OrganizationPermissions.ViewLeadValues),
            profile.Role, sensitive);
        return (view, resolved.Permissions.Contains(OrganizationPermissions.ViewAccountFinancials));
    }

    /// <summary>
    /// Design §6/§14.3 (owner answer, binding): reuses the existing reminder/
    /// notification email rendering (<see cref="NotificationDispatcher"/> →
    /// <c>EmailTemplates.Generic</c> → <see cref="EmailProviderResolver"/>), not
    /// a new email pipeline — the ONLY difference from <see cref="NotifyAsync"/>
    /// is the event key (<see cref="NotificationEvents.Keys.AutomationEmail"/>,
    /// forced-email-by-default) and that subject/body run through
    /// <see cref="AutomationMergeFields"/> first. Recipients use the exact same
    /// <c>recipientKind</c> vocabulary <see cref="NotifyAsync"/> already
    /// resolves — no separate resolution logic to keep in sync.
    ///
    /// RENDERED ONCE PER RECIPIENT (2026-09-27 coordinator fix), not once for
    /// the whole batch: masking is per-CALLER, and two resolved recipients
    /// (e.g. two managers from <c>manager_of_owner</c>) can legitimately hold
    /// different permissions today or after a future per-user role override.
    /// "An email must never contain a value the recipient could not see in the
    /// app" only holds if EACH recipient's own view gates what THEIR copy
    /// contains — a single shared render could only use the least-permissive
    /// recipient's view for everyone, which would silently hide values a
    /// manager-only recipient is entitled to see. One <see cref="NotifyRequest"/>
    /// per recipient costs one extra email per fan-out recipient, which this
    /// codebase already accepts for the deferred-email path in
    /// <see cref="NotificationDispatcher"/> for the same reason (per-recipient
    /// preferences already forced one decision each).
    /// </summary>
    private async Task<AutomationActionOutcome> SendTemplateEmailAsync(
        AppDbContext db, JsonElement action, string aggregateType, Guid aggregateId,
        IReadOnlyDictionary<string, object?> values, CancellationToken ct)
    {
        var subjectTemplate = GetString(action, "subject");
        var bodyTemplate = GetString(action, "body");
        if (string.IsNullOrWhiteSpace(subjectTemplate) || bodyTemplate is null)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.SendTemplateEmail, "failed", "Missing \"subject\" or \"body\".");

        var (ownerId, teamId) = await ResolveRecordOwnerAsync(db, aggregateType, aggregateId, ct);
        var recipients = await ResolveNotifyRecipientsAsync(db, action, ownerId, ct);
        if (recipients.Count == 0)
            return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.SendTemplateEmail, "failed", "Could not resolve any recipient.");

        foreach (var recipientId in recipients)
        {
            var (view, canSeeAccountFinancials) = await RecipientViewAsync(db, recipientId, ct);
            var recordSnapshot = await BuildRecordSnapshotAsync(db, aggregateType, aggregateId, view, canSeeAccountFinancials, ct);
            var merged = MergeValues(await ValuesForReaderAsync(db, recipientId, ownerId, teamId, values, ct), recordSnapshot);
            var subject = AutomationMergeFields.Render(subjectTemplate, merged);
            var body = AutomationMergeFields.Render(bodyTemplate, merged);

            await _notify.NotifyAsync(new NotifyRequest(
                [recipientId], NotificationEvents.Keys.AutomationEmail, subject, body)
            {
                LeadId = aggregateType == DomainEventTypes.AggregateTypes.Lead ? aggregateId : null,
                TeamId = teamId,
                InvolvedUserIds = [recipientId],
                // This action's WHOLE POINT is an email — never fall back to
                // push/in-app the way a general "notify" would, so an admin who
                // built a "send_template_email" step gets exactly that channel or
                // an honest failure, never a silent substitution.
                Channels = new[] { "email" },
            }, ct);
        }

        return new AutomationActionOutcome(AutomationRuleValidator.ActionTypes.SendTemplateEmail, "success");
    }

    // --- assignee / recipient resolution ------------------------------------

    /// <summary>
    /// <c>assigneeKind</c>/<c>recipientKind</c> vocabulary (design §6: "owner,
    /// a fixed user, or a role"): "owner" (the record's current owner —
    /// <paramref name="currentOwnerId"/>), "fixed_user" (an explicit
    /// <c>assigneeUserId</c>). "role" is NOT supported by this slice — this
    /// codebase's role vocabulary is a per-org, admin-configurable list
    /// (<c>OrganizationRoleService</c>), and resolving "everyone with role X"
    /// to a single assignee (for create_task/create_reminder/assign_owner) is
    /// a genuinely separate design question (fan-out vs pick-one) the design
    /// doc does not answer for a SINGLE-assignee action — flagged in the build
    /// report rather than guessed at.
    /// </summary>
    private static Guid? ResolveAssignee(JsonElement action, Guid? currentOwnerId)
    {
        var kind = GetString(action, "assigneeKind") ?? "owner";
        return kind switch
        {
            "owner" => currentOwnerId,
            "fixed_user" => GetGuid(action, "assigneeUserId"),
            _ => null,
        };
    }

    /// <summary>Same vocabulary as <see cref="ResolveAssignee"/>, plus
    /// "manager_of_owner" (design §6's notify recipients: "owner, manager-of-
    /// owner, a fixed user/role") since notify is the one action that
    /// legitimately fans out to more than one person.</summary>
    private static async Task<List<Guid>> ResolveNotifyRecipientsAsync(AppDbContext db, JsonElement action, Guid? ownerId, CancellationToken ct)
    {
        var kind = GetString(action, "recipientKind") ?? "owner";
        switch (kind)
        {
            case "owner":
                return ownerId is Guid o ? [o] : [];
            case "fixed_user":
                var fixedUser = GetGuid(action, "recipientUserId");
                return fixedUser is Guid u ? [u] : [];
            case "manager_of_owner":
                if (ownerId is not Guid ownerForManagers) return [];
                var teamIds = await db.TeamMembers.AsNoTracking()
                    .Where(m => m.UserId == ownerForManagers && m.LeftAt == null)
                    .Select(m => m.TeamId).ToListAsync(ct);
                if (teamIds.Count == 0) return [];
                return await db.TeamMembers.AsNoTracking()
                    .Where(m => teamIds.Contains(m.TeamId) && m.LeftAt == null)
                    .Join(db.Profiles.Where(p => p.Role == "manager" || p.Role == "admin"),
                        m => m.UserId, p => p.Id, (m, p) => p.Id)
                    .Distinct().ToListAsync(ct);
            // E2.5 (design doc §12 slice 7): the exact recipient set
            // CollectionEscalationService's own (now-removed) inline notify
            // call used — "the owner is accountable for the debt; the
            // collectors are the people who can actually do something about it
            // today" (that class's own comment, preserved verbatim here). Only
            // meaningful for an invoice-aggregate trigger; org-admin
            // configured, so no role-target concern (design §14.7) applies —
            // this is a fixed, built-in recipient SET, not a builder-offered
            // "everyone with role X" pick.
            case "collectors_and_owner":
                var collectors = await NotificationService.ActiveCollectorIdsAsync(db, db.CurrentOrgId);
                return ownerId is Guid invoiceOwner ? collectors.Append(invoiceOwner).Distinct().ToList() : collectors;
            default:
                return [];
        }
    }

    private static async Task<(Guid? OwnerId, Guid? TeamId)> ResolveRecordOwnerAsync(
        AppDbContext db, string aggregateType, Guid aggregateId, CancellationToken ct)
    {
        if (aggregateType == DomainEventTypes.AggregateTypes.Lead)
        {
            var lead = await db.Leads.AsNoTracking().Where(l => l.Id == aggregateId)
                .Select(l => new { l.OwnerId, l.TeamId }).FirstOrDefaultAsync(ct);
            return (lead?.OwnerId, lead?.TeamId);
        }
        if (aggregateType == DomainEventTypes.AggregateTypes.Account)
        {
            var account = await db.Accounts.AsNoTracking().Where(a => a.Id == aggregateId)
                .Select(a => new { OwnerId = (Guid?)a.OwnerId, a.TeamId }).FirstOrDefaultAsync(ct);
            return (account?.OwnerId, account?.TeamId);
        }
        if (aggregateType == DomainEventTypes.AggregateTypes.Invoice)
        {
            var invoice = await db.Invoices.AsNoTracking().Where(i => i.Id == aggregateId)
                .Select(i => new { OwnerId = (Guid?)i.OwnerId, i.TeamId }).FirstOrDefaultAsync(ct);
            return (invoice?.OwnerId, invoice?.TeamId);
        }
        return (null, null);
    }

    private static string? GetString(JsonElement el, string property) =>
        el.TryGetProperty(property, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    private static int? GetInt(JsonElement el, string property) =>
        el.TryGetProperty(property, out var v) && v.ValueKind == JsonValueKind.Number && v.TryGetInt32(out var i) ? i : null;

    private static Guid? GetGuid(JsonElement el, string property) =>
        el.TryGetProperty(property, out var v) && v.ValueKind == JsonValueKind.String && Guid.TryParse(v.GetString(), out var g) ? g : null;
}

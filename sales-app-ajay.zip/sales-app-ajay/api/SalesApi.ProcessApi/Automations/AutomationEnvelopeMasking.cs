using SalesApi.Services;

namespace SalesApi.ProcessLayer.Automations;

/// <summary>
/// E12.2 (owner decision 16) - text an automation writes for a PERSON to read (a task, a reminder, a notification, an email
/// to staff) follows the READER's role. The record snapshot is already masked by the mapper that builds it; this covers the
/// other source of merge-field values, the triggering EVENT's own payload (the envelope), which carries a few sensitive
/// facts: the deal value, the stage-change / lost reason, a WhatsApp phone number.
///
/// One rule, expressed with the one masker (<see cref="CustomFieldMasking"/>): a key belongs to a category, and the reader's
/// level for that category decides whether the real value, the masked text, or nothing is put in the text. Customer-facing
/// sends do NOT go through here - they keep real values, filled in on the server.
/// </summary>
public static class AutomationEnvelopeMasking
{
    private static readonly Dictionary<string, (string Category, CustomFieldMasking.Kind Kind)> Keys = new(StringComparer.Ordinal)
    {
        ["value"] = (SensitiveCategories.DealValues, CustomFieldMasking.Kind.Text),
        ["old_value"] = (SensitiveCategories.DealValues, CustomFieldMasking.Kind.Text),
        ["new_value"] = (SensitiveCategories.DealValues, CustomFieldMasking.Kind.Text),
        ["reason"] = (SensitiveCategories.DealInsights, CustomFieldMasking.Kind.Text),
        ["to_phone"] = (SensitiveCategories.ContactDetails, CustomFieldMasking.Kind.Phone),
        ["from_phone"] = (SensitiveCategories.ContactDetails, CustomFieldMasking.Kind.Phone),
    };

    /// <summary>The envelope as <paramref name="reader"/> may see it. Null reader = unchanged (a legacy construction).</summary>
    public static IReadOnlyDictionary<string, object?> ForReader(
        IReadOnlyDictionary<string, object?> values, SensitiveAccess? reader, Guid? ownerId, Guid? teamId)
    {
        if (reader is null) return values;
        Dictionary<string, object?>? copy = null;
        foreach (var (key, (category, kind)) in Keys)
        {
            if (!values.TryGetValue(key, out var raw) || raw is null) continue;
            var level = reader.LevelFor(category, ownerId, teamId);
            if (SensitiveLevels.CanReadRaw(level)) continue;
            copy ??= new Dictionary<string, object?>(values, StringComparer.Ordinal);
            // A number or any non-text value has no masked form: it renders empty, like a hidden value.
            copy[key] = SensitiveLevels.IsMasked(level) && raw is string s ? CustomFieldMasking.MaskString(s, kind, level) : null;
        }
        return copy ?? values;
    }
}

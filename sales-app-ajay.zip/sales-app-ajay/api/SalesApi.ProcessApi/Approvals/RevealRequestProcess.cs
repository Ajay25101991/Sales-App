using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.DataAccessLog;
using SalesApi.Services;
using SalesApi.SystemLayer.Approvals;
using SalesApi.SystemLayer.DataAccessLog;

namespace SalesApi.ProcessLayer.Approvals;

/// <summary>
/// E12.5 (owner decision 10) - reveal requests. A person whose level for a sensitive category is MASKED on one record files a request
/// with a reason; it goes through the org's approval chains (default: their manager, then admins); once approved the value shows on that
/// ONE record for the org's time limit. Every step is logged and the value is never stored.
///
/// WHAT IS REUSED, not rebuilt: the request is an <see cref="ApprovalRequest"/> of type <c>reveal</c>, started on the SAME chain
/// machinery as a discount (<see cref="ApprovalChainProcess.ResolveAndStartAsync"/>), decided through the SAME
/// <c>POST /approval-chains/instances/{id}/decide</c>, applied by <see cref="ApprovalProcess.ApplyChainOutcomeAsync"/> (which stamps the
/// expiry and writes the reveal_approved / reveal_refused entry), notified through the same path, scoped by the same people-scope rule.
/// What is new here is only: the create rules (reveal on, reason, actually masked, no duplicate), the list shape, and the
/// once-per-grant "value revealed" claim. How a grant changes what a caller SEES lives in exactly one place:
/// <see cref="SensitiveAccess.ForRecord"/>.
///
/// Authorization stays at the HTTP layer (the controller only needs sign-in); facts about the caller travel down in the
/// <see cref="RecordAccessContext"/>.
/// </summary>
public sealed class RevealRequestProcess
{
    private readonly ApprovalStore _store;
    private readonly ApprovalChainStore _chainStore;
    private readonly ApprovalChainProcess _chains;
    private readonly DataAccessLogProcess _log;
    private readonly DataAccessLogStore _facts;
    private readonly OrgSettingsReader _settings;
    private readonly PeopleScopeReader _people;

    public RevealRequestProcess(
        ApprovalStore store, ApprovalChainStore chainStore, ApprovalChainProcess chains, DataAccessLogProcess log,
        DataAccessLogStore facts, OrgSettingsReader settings, PeopleScopeReader people)
    {
        _store = store;
        _chainStore = chainStore;
        _chains = chains;
        _log = log;
        _facts = facts;
        _settings = settings;
        _people = people;
    }

    public const string RevealDisabledCode = "reveal_disabled";
    public const string ReasonRequiredCode = "reason_required";
    public const string NotMaskedCode = "not_masked";
    public const string AlreadyGrantedCode = "reveal_already_granted";
    public const string DuplicatePendingCode = "duplicate_pending_request";
    public const string NoApproverCode = "reveal_no_approver";

    public const int MaxReasonLength = 1000;

    /// <summary>Same refusal shape the approvals endpoints use, so the controller maps it the same way.</summary>
    public sealed record Outcome(ApprovalProcess.Refusal? Refusal, RevealRequestDto? Request)
    {
        public static Outcome Refused(ApprovalProcess.Refusal r) => new(r, null);
        public static Outcome Ok(RevealRequestDto d) => new(null, d);
    }

    // ---- Create --------------------------------------------------------------------------------------------------------------

    public async Task<Outcome> CreateAsync(RecordAccessContext ctx, RevealRequestInput input, CancellationToken ct = default)
    {
        var (enabled, _) = await _settings.GetRevealSettingsAsync();
        if (!enabled)
            return Outcome.Refused(ApprovalProcess.Refusal.BadRequest(new
            {
                error = "Asking to reveal a value is not turned on for your organization.", code = RevealDisabledCode,
            }));

        if (input.RecordType is not (DataAccessRecordTypes.Lead or DataAccessRecordTypes.Account or DataAccessRecordTypes.Contact))
            return Outcome.Refused(ApprovalProcess.Refusal.BadRequest(new { error = "record_type must be one of: lead, account, contact" }));
        if (input.RecordId is not { } recordId || recordId == Guid.Empty)
            return Outcome.Refused(ApprovalProcess.Refusal.BadRequest(new { error = "record_id is required." }));
        if (!SensitiveCategories.IsValid(input.Category))
            return Outcome.Refused(ApprovalProcess.Refusal.BadRequest(new
            {
                error = "category must be one of: " + string.Join(", ", SensitiveCategories.All),
            }));
        var reason = input.Reason?.Trim();
        if (string.IsNullOrEmpty(reason))
            return Outcome.Refused(ApprovalProcess.Refusal.BadRequest(new
            {
                error = "A reason is required to ask for a value to be revealed.", code = ReasonRequiredCode,
            }));
        if (reason.Length > MaxReasonLength)
            return Outcome.Refused(ApprovalProcess.Refusal.BadRequest(new { error = $"The reason can be at most {MaxReasonLength} characters." }));

        var facts = await _facts.RecordFactsAsync(input.RecordType, recordId, ct);
        // Not visible reads exactly like not found: a caller cannot probe for records outside their reach.
        if (facts is null || !RecordAccess.CanView(ctx, facts.OwnerId, facts.TeamId))
            return Outcome.Refused(ApprovalProcess.Refusal.NotFound(new { error = "That record was not found." }));

        // The level that applies to THIS record for this caller, grants ignored on purpose (ForRecord is not applied): the question is
        // whether the value is masked FROM them. Hidden has nothing to reveal; full / view only already reads it.
        var level = (ctx.Sensitive ?? SensitiveAccess.Unrestricted).LevelFor(input.Category!, facts.OwnerId, facts.TeamId);
        if (!SensitiveLevels.IsMasked(level))
            return Outcome.Refused(ApprovalProcess.Refusal.BadRequest(new
            {
                error = "That value is not masked for you.", code = NotMaskedCode,
            }));

        var now = DateTime.UtcNow;
        if (await _store.FindActiveRevealGrantAsync(ctx.UserId, input.RecordType, recordId, input.Category!, now, ct) is not null)
            return Outcome.Refused(ApprovalProcess.Refusal.Conflict(new
            {
                error = "You can already see that value on this record.", code = AlreadyGrantedCode,
            }));
        if (await _store.FindPendingRevealAsync(ctx.UserId, input.RecordType, recordId, input.Category!, ct) is { } pending)
            return Outcome.Refused(ApprovalProcess.Refusal.Conflict(new
            {
                error = "You already have a pending request for this value.", code = DuplicatePendingCode, pending_request_id = pending.Id,
            }));

        var req = new ApprovalRequest
        {
            // Explicit Id: the chain instance below is keyed on it before the row is re-read (Postgres defaults are server-side).
            Id = Guid.NewGuid(),
            RequesterId = ctx.UserId,
            Type = ApprovalTypes.Reveal,
            LeadId = Guid.Empty, // no lead: the record is named by RecordType / RecordId
            Reason = reason,
            RecordType = input.RecordType,
            RecordId = recordId,
            Category = input.Category,
        };
        _store.Add(req);
        await _store.SaveChangesAsync(ct);

        var instance = await _chains.ResolveAndStartAsync(req, null, ct);
        if (instance is null)
        {
            // The org switched its default reveal chain off and no other chain covers reveals: nobody could ever decide this.
            _store.Remove(req);
            await _store.SaveChangesAsync(ct);
            return Outcome.Refused(ApprovalProcess.Refusal.Conflict(new
            {
                error = "No one is set up to approve reveal requests. Ask an admin.", code = NoApproverCode,
            }));
        }

        await _log.RecordAsync(ctx.UserId, DataAccessActions.RevealRequested, input.RecordType, recordId, category: input.Category, ct: ct);
        var dto = (await ToDtosAsync([req], ctx.UserId, ct))[0];
        return Outcome.Ok(dto);
    }

    // ---- List ----------------------------------------------------------------------------------------------------------------

    /// <summary>
    /// The caller's own requests (optionally by status), and the pending requests whose CURRENT step resolves to the caller. The second
    /// half is scoped by the same people-scope rule the chain decide uses (a request outside the caller's visible people is not theirs
    /// to decide), and never includes their own request.
    /// </summary>
    public async Task<(ApprovalProcess.Refusal? Refusal, RevealRequestListDto? Page)> ListAsync(
        RecordAccessContext ctx, string? status, CancellationToken ct = default)
    {
        if (!string.IsNullOrWhiteSpace(status) && status is not (RevealStatuses.Pending or RevealStatuses.Approved or RevealStatuses.Refused or RevealStatuses.Expired))
            return (ApprovalProcess.Refusal.BadRequest(new { error = "status must be one of: pending, approved, refused, expired" }), null);

        var mine = await _store.RevealRequestsOfAsync(ctx.UserId, ct);
        var mineDtos = await ToDtosAsync(mine, ctx.UserId, ct);
        if (!string.IsNullOrWhiteSpace(status)) mineDtos = mineDtos.Where(d => d.Status == status).ToList();

        var people = await _people.VisibleIdsAsync(ctx, ct);
        var governed = await _chainStore.PendingRevealGovernedAsync(people, ct);
        var toDecideRows = new List<ApprovalRequest>();
        var stepsByChain = new Dictionary<Guid, List<ApprovalChainStep>>();
        foreach (var (request, instance) in governed)
        {
            if (request.RequesterId == ctx.UserId) continue;
            if (!stepsByChain.TryGetValue(instance.ChainId, out var steps))
                stepsByChain[instance.ChainId] = steps = await _chainStore.StepsForChainAsync(instance.ChainId, ct);
            var step = steps.FirstOrDefault(s => s.Order == instance.CurrentStep);
            if (step is null) continue;
            var approvers = await _chainStore.ResolveApproverIdsAsync(step, null, request.RequesterId, ct);
            if (approvers.Contains(ctx.UserId)) toDecideRows.Add(request);
        }
        var toDecide = await ToDtosAsync(toDecideRows, ctx.UserId, ct);
        return (null, new RevealRequestListDto(mineDtos, toDecide));
    }

    // ---- Once per grant: the real value went out ----------------------------------------------------------------------------

    /// <summary>
    /// Called by the response filter after a request that used one or more of the caller's grants (a mapper lifted a level for them, see
    /// <see cref="SensitiveAccess.ForRecord"/>) and BEFORE the response is sent. For each grant, the first call claims it in the database
    /// (atomic) and writes ONE value_revealed entry; every later read of the same grant finds it already claimed and writes nothing.
    /// A failure here fails the request, so the value cannot leave without its log entry. Never writes the value.
    /// </summary>
    public async Task LogFirstReadsAsync(Guid userId, IEnumerable<RevealGrant> usedGrants, CancellationToken ct = default)
    {
        foreach (var g in usedGrants)
        {
            if (!await _store.ClaimRevealReadAsync(g.RequestId, DateTime.UtcNow, ct)) continue;
            await _log.RecordAsync(userId, DataAccessActions.ValueRevealed, g.RecordType, g.RecordId, category: g.Category, ct: ct);
        }
    }

    // ---- DTO assembly --------------------------------------------------------------------------------------------------------

    private async Task<List<RevealRequestDto>> ToDtosAsync(List<ApprovalRequest> rows, Guid callerId, CancellationToken ct)
    {
        if (rows.Count == 0) return [];
        var personIds = rows.Select(r => r.RequesterId)
            .Concat(rows.Where(r => r.DecidedById.HasValue).Select(r => r.DecidedById!.Value)).Distinct().ToList();
        var names = await _store.ProfileNamesAsync(personIds, ct);
        var recordNames = await _facts.RecordNamesAsync(
            rows.Where(r => r.RecordType != null && r.RecordId != null).Select(r => (r.RecordType!, r.RecordId!.Value)), ct);
        var instances = await _chainStore.InstancesForRequestsAsync(rows.Select(r => r.Id).ToList(), ct);

        var stepsByChain = new Dictionary<Guid, List<ApprovalChainStep>>();
        var result = new List<RevealRequestDto>(rows.Count);
        var now = DateTime.UtcNow;
        foreach (var r in rows)
        {
            instances.TryGetValue(r.Id, out var instance);
            int? current = null, total = null;
            var waitingIds = new List<Guid>();
            if (instance is not null)
            {
                if (!stepsByChain.TryGetValue(instance.ChainId, out var steps))
                    stepsByChain[instance.ChainId] = steps = await _chainStore.StepsForChainAsync(instance.ChainId, ct);
                total = steps.Count;
                if (r.Status == "pending" && instance.Status == ApprovalChainInstanceStatus.Pending)
                {
                    current = instance.CurrentStep;
                    var step = steps.FirstOrDefault(s => s.Order == instance.CurrentStep);
                    if (step is not null) waitingIds = await _chainStore.ResolveApproverIdsAsync(step, null, r.RequesterId, ct);
                }
            }
            var waitingNames = waitingIds.Count == 0 ? new Dictionary<Guid, string?>() : await _store.ProfileNamesAsync(waitingIds, ct);
            var status = r.Status switch
            {
                "pending" => RevealStatuses.Pending,
                "approved" => r.GrantExpiresAt is { } until && until <= now ? RevealStatuses.Expired : RevealStatuses.Approved,
                _ => RevealStatuses.Refused,
            };
            result.Add(new RevealRequestDto(
                r.Id, r.RequesterId, names.GetValueOrDefault(r.RequesterId), r.RecordType ?? "", r.RecordId ?? Guid.Empty,
                r.RecordType is not null && r.RecordId is { } rid ? recordNames.GetValueOrDefault((r.RecordType, rid)) : null,
                r.Category ?? "", r.Reason ?? "", status, r.CreatedAt, r.DecidedById,
                r.DecidedById is { } d ? names.GetValueOrDefault(d) : null, r.DecidedAt, r.DecisionNote,
                r.Status == "approved" ? r.GrantExpiresAt : null,
                current, total, waitingIds, [.. waitingIds.Select(id => waitingNames.GetValueOrDefault(id) ?? "Unknown")],
                CanDecide: status == RevealStatuses.Pending && waitingIds.Contains(callerId) && r.RequesterId != callerId,
                IsMine: r.RequesterId == callerId,
                ChainInstanceId: instance?.Id));
        }
        return result;
    }
}

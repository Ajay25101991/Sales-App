using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.Approvals;

namespace SalesApi.ProcessLayer.Approvals;

/// <summary>
/// Manager sign-off workflow: the business rules that used to live inline in
/// <c>ApprovalsController</c> — reps raise requests (reassign a lead to
/// themselves, approve a discount, reopen a closed deal, or request an
/// exception to a blocked stage gate); an approver decides. Approving a
/// reassignment performs it, and so does approving a reopen or a gate
/// exception.
///
/// WHAT STAYED AT THE CONTROLLER, and why: every permission check
/// (ViewFinancials/DecideApprovals, and the gate-exception approver-policy
/// check via <see cref="GateEscalationSettingsService"/>) is HTTP-shaped
/// authorization, resolved from the caller before this class is ever called —
/// same split as <c>CollectionTasksController</c>'s manual manager/collector
/// checks. This class receives the RESULT of those checks as plain booleans,
/// never a <c>ClaimsPrincipal</c> — a Process class should not need to know
/// how a caller was authenticated (see <c>PlaybookProcess</c>'s own note on
/// exactly this). The one exception is <see cref="DecideAsync"/>'s dispatch
/// on <c>req.Type</c>: which permission applies depends on data only this
/// class has read (the request itself), so the three permission FACTS travel
/// in as parameters and the DISPATCH on them happens here.
/// </summary>
public sealed class ApprovalProcess
{
    private readonly ApprovalStore _store;
    private readonly NotificationDispatcher _notify;
    private readonly OrgAuthorizationCache _authCache;
    // E2.6 slice 9 — resolves/starts an approval chain for a freshly-created
    // request (CreateAsync below) and, via ApplyChainOutcomeAsync at the
    // bottom of this class, applies a chain's FINAL outcome once one is
    // reached. See ApprovalChainProcess's own class comment for why this is a
    // one-directional dependency (this class calls into it; it never calls
    // back into this one), avoiding a Process/Process cycle.
    private readonly ApprovalChainProcess _chains;
    private readonly PeopleScopeReader _peopleScope;
    private readonly PipelineStages _stages;


    private readonly DomainEventWriter _events;
    private readonly OrgSettingsReader _orgSettings;
    private readonly StagePhasesLoader _phases;
    private readonly StageGateReader _stageGate;
    private readonly InvoiceOwnershipService _invoiceOwnership;
    private readonly ReopenSettingsReader _reopenSettings;
    private readonly PaymentWorkflowReader _paymentWorkflow;
    private readonly DomainEventPayloadReader _payloads;
    private readonly SalesApi.ProcessLayer.Proposals.ProposalGenerateProcess? _proposals;
    private readonly SalesApi.ProcessLayer.DataAccessLog.DataAccessLogProcess? _accessLog;
    private readonly SalesApi.ProcessLayer.Leads.LeadQuoteProcess? _quotes;

    // Layering round 4 (owner decision 2026-09-30): the last remaining _db
    // uses here were StagePhases/StageGateService/PaymentWorkflowService/
    // ReopenSettingsService/InvoiceOwnership/DomainEventPayloads.LeadWonAsync
    // reads called straight through — once each moved behind its own
    // injectable front, AppDbContext had no other job here, so it is dropped
    // and PeopleScopeReader/PipelineStages (already registered in Program.cs)
    // become required, same as round 2/3's rule for a class whose last _db
    // use disappears.
    public ApprovalProcess(
        ApprovalStore store,
        NotificationDispatcher notify,
        OrgAuthorizationCache authCache,
        ApprovalChainProcess chains,
        DomainEventWriter events,
        OrgSettingsReader orgSettings,
        PeopleScopeReader peopleScope,
        PipelineStages stages,
        StagePhasesLoader phases,
        StageGateReader stageGate,
        InvoiceOwnershipService invoiceOwnership,
        ReopenSettingsReader reopenSettings,
        PaymentWorkflowReader paymentWorkflow,
        DomainEventPayloadReader payloads,
        // E10.5: optional-by-construction like the other late additions - the hand-built test chains that never approve a discount on a
        // generated proposal omit it; production DI supplies it.
        SalesApi.ProcessLayer.Proposals.ProposalGenerateProcess? proposals = null,
        // E12.5: same optional-by-construction rule - only a reveal decision writes a log entry.
        SalesApi.ProcessLayer.DataAccessLog.DataAccessLogProcess? accessLog = null,
        // Q13: optional-by-construction as well - an approved discount on a SENT plain quote is made as a revision through the quote process.
        SalesApi.ProcessLayer.Leads.LeadQuoteProcess? quotes = null)
    {
        _quotes = quotes;
        _accessLog = accessLog;
        _proposals = proposals;
        _store = store;
        _notify = notify;
        _authCache = authCache;
        _chains = chains;
        _peopleScope = peopleScope;
        _stages = stages;
        _events = events;
        _orgSettings = orgSettings;
        _phases = phases;
        _stageGate = stageGate;
        _invoiceOwnership = invoiceOwnership;
        _reopenSettings = reopenSettings;
        _paymentWorkflow = paymentWorkflow;
        _payloads = payloads;
    }

    // ---- Refusal / outcome shapes ------------------------------------------------

    /// <summary>The HTTP shape a refusal maps to. The controller owns the actual
    /// status-code call (<c>FromRefusal</c>); this only names which family it's in,
    /// so nothing here has to import ASP.NET Core to describe an outcome.</summary>
    public enum RefusalKind { BadRequest, NotFound, Conflict, Forbidden }

    /// <summary>
    /// Why an ordinary request could not be honoured. <c>Body</c> is exactly the
    /// payload the endpoint used to construct inline (<c>{ error = "..." }</c>,
    /// sometimes with extra fields like <c>code</c>/<c>pending_request_id</c>) —
    /// carried as <c>object</c> rather than promoted to a typed record, because a
    /// typed record's wire shape has to be proven with a serialization test
    /// (PlaybookWireShapeTests' lesson) and the anonymous shape already IS the
    /// wire shape, unchanged.
    /// </summary>
    public sealed record Refusal(RefusalKind Kind, object Body)
    {
        public static Refusal BadRequest(object body) => new(RefusalKind.BadRequest, body);
        public static Refusal NotFound(object body) => new(RefusalKind.NotFound, body);
        public static Refusal Conflict(object body) => new(RefusalKind.Conflict, body);
        public static Refusal Forbidden(object body) => new(RefusalKind.Forbidden, body);
    }

    /// <summary>A create/decide outcome: either a refusal, or the request as it now stands.</summary>
    public sealed record ApprovalOutcome(Refusal? Refusal, ApprovalDto? Approval)
    {
        public static ApprovalOutcome Refused(Refusal r) => new(r, null);
        public static ApprovalOutcome Ok(ApprovalDto a) => new(null, a);
    }

    // ---- DTO assembly --------------------------------------------------------

    // D5's LeadMapping ("without lead_values.view, EstimatedValue is null") is
    // the precedent: money is masked to null, never a zeroed 0 (a zero reads as
    // "worth nothing" rather than "hidden"), for a caller lacking
    // OrganizationPermissions.ViewLeadValues. Masking happens here, in DTO
    // assembly, so every caller of ToDto(s)Async goes through it alike.
    private static ApprovalDto ToDto(
        ApprovalRequest a,
        IReadOnlyDictionary<Guid, string?> names,
        IReadOnlyDictionary<Guid, (string Name, string? Company, decimal? Value, string Status, Guid? PlaybookId)> leads,
        bool canSeeValues)
    {
        leads.TryGetValue(a.LeadId, out var lead);
        return new ApprovalDto(
            a.Id, a.RequesterId, names.GetValueOrDefault(a.RequesterId), a.Type, a.LeadId, lead.Name,
            a.Amount, a.Reason, a.Status, a.DecidedById,
            a.DecidedById is Guid d ? names.GetValueOrDefault(d) : null,
            a.DecidedAt, a.DecisionNote, a.CreatedAt,
            canSeeValues ? lead.Value : null, lead.Status, lead.Company, a.TargetStatus, lead.PlaybookId,
            QuoteId: a.Type == ApprovalTypes.Discount && a.RecordType == "quote" ? a.RecordId : null,
            RecordType: a.Type is ApprovalTypes.PartnerPayout or ApprovalTypes.PartnerAdjustment ? a.RecordType : null,
            RecordId: a.Type is ApprovalTypes.PartnerPayout or ApprovalTypes.PartnerAdjustment ? a.RecordId : null);
    }

    private async Task<ApprovalDto> ToDtoAsync(ApprovalRequest a, bool canSeeValues, CancellationToken ct) =>
        (await ToDtosAsync(new List<ApprovalRequest> { a }, canSeeValues, ct))[0];

    /// <summary>Resolves requester/decider names and lead facts for a whole page in
    /// TWO queries — replaces a per-row helper that ran two queries EACH.</summary>
    private async Task<List<ApprovalDto>> ToDtosAsync(List<ApprovalRequest> rows, bool canSeeValues, CancellationToken ct)
    {
        if (rows.Count == 0) return [];

        var personIds = rows.Select(a => a.RequesterId)
            .Concat(rows.Where(a => a.DecidedById.HasValue).Select(a => a.DecidedById!.Value))
            .Distinct().ToList();
        var names = await _store.ProfileNamesAsync(personIds, ct);

        var leadIds = rows.Select(a => a.LeadId).Distinct().ToList();
        var leads = await _store.LeadFactsAsync(leadIds, ct);

        var dtos = rows.Select(r => ToDto(r, names, leads, canSeeValues)).ToList();
        // Parked item 7: a pending gate exception to a Won stage that asks for deal values says which REQUIRED ones are still missing, so the approver's
        // card can offer inputs for them (sent back as win_values on decide). Only pending gate exceptions are looked at.
        for (var i = 0; i < rows.Count; i++)
        {
            var r = rows[i];
            if (r.Type != ApprovalTypes.GateException || r.Status != "pending" || string.IsNullOrEmpty(r.TargetStatus)) continue;
            var lead = await _store.GetLeadForDecisionAsync(r.LeadId, ct);
            if (lead is null) continue;
            var winMissing = (await _stageGate.MissingRequirementsAsync(lead, null, r.TargetStatus)).Where(m => m.Kind == WinAsk.Kind).ToList();
            if (winMissing.Count > 0) dtos[i] = dtos[i] with { MissingWinValues = winMissing };
        }
        return dtos;
    }

    // ---- List / count ---------------------------------------------------------

    /// <summary>
    /// Scoped by REQUESTER: an approval belongs to the person who raised it, and a
    /// manager approves for their own teams — <paramref name="ctx"/> resolves that
    /// the same way every other team-scoped read does. D9a #1 — a caller without
    /// ViewFinancials may still call this (so a rep can track a gate-exception
    /// request they raised), but sees only GateException rows.
    /// </summary>
    public async Task<List<ApprovalDto>> ListAsync(
        RecordAccessContext ctx, string? status, bool hasViewFinancials, bool hasViewLeadValues, CancellationToken ct = default)
    {
        var people = await _peopleScope.VisibleIdsAsync(ctx, ct);
        var rows = await _store.ListAsync(people, status, gateExceptionOnly: !hasViewFinancials, ct);
        return await ToDtosAsync(rows, hasViewLeadValues, ct);
    }

    /// <summary>D9a #1/#2's split count — see <see cref="ApprovalStore.PendingCountAsync"/>.
    /// E0.1 — <paramref name="selfDecisionPolicy"/> "blocked" excludes the
    /// caller's own pending requests: they cannot decide those, so they must
    /// not count as "waiting on you". The list itself (<see cref="ListAsync"/>)
    /// still shows them — a manager tracks their own requests there too.
    ///
    /// E2.6 — a SECOND half, added to the blanket type-based count above: a
    /// chain-governed pending request counts only for its CURRENT STEP's
    /// resolved approver, never the org's blanket
    /// DecideApprovals/ViewFinancials/gate-exception population — <see
    /// cref="ApprovalStore.PendingCountAsync"/> excludes every such row so the
    /// two halves never double-count the same request.</summary>
    public async Task<int> PendingCountAsync(
        RecordAccessContext ctx, bool hasFinancials, bool canDecideGateExceptions,
        string selfDecisionPolicy, CancellationToken ct = default)
    {
        var people = await _peopleScope.VisibleIdsAsync(ctx, ct);
        var excludeSelf = selfDecisionPolicy == Models.ApprovalSelfDecisionPolicy.Blocked ? ctx.UserId : (Guid?)null;
        var plainCount = await _store.PendingCountAsync(people, hasFinancials, canDecideGateExceptions, excludeSelf, ct);
        var chainCount = await _chains.PendingCountForApproverAsync(people, ctx.UserId, excludeSelf, ct);
        return plainCount + chainCount;
    }

    // ---- Create -----------------------------------------------------------------

    public async Task<ApprovalOutcome> CreateAsync(ApprovalInput input, Guid requesterId, bool hasViewLeadValues, CancellationToken ct = default)
    {
        if (input.Type is not (ApprovalTypes.Reassign or ApprovalTypes.Discount or ApprovalTypes.Reopen
            or ApprovalTypes.GateException or ApprovalTypes.Automation))
            return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "type must be reassign, discount, reopen, gate_exception, or automation" }));

        var lead0 = input.LeadId is Guid leadId ? await _store.GetLeadAsync(leadId, ct) : null;
        if (input.LeadId is null || lead0 is null)
            return ApprovalOutcome.Refused(Refusal.NotFound(new { error = "Lead not found" }));
        if (input.Type == ApprovalTypes.Discount && (input.Amount is null || input.Amount <= 0))
            return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "A discount amount is required" }));

        // Slice 10 — an automation's request_approval action always carries a
        // reason (the builder-configured description of what's being asked),
        // same "never a bare, unexplained request" discipline Reopen/GateException
        // already enforce below.
        if (input.Type == ApprovalTypes.Automation && string.IsNullOrWhiteSpace(input.Reason))
            return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "A reason is required to request approval." }));

        if (input.Type == ApprovalTypes.Reopen)
        {
            // H6 — the structured fields this request type needs: a reason (never
            // free text buried in an activity) and the OPEN stage the rep is asking
            // to go back to. Re-validated at decide time too, because the pipeline
            // can change in between.
            if (string.IsNullOrWhiteSpace(input.Reason))
                return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "A reason is required to request a reopen." }));
            if (string.IsNullOrWhiteSpace(input.TargetStatus))
                return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "target_status is required" }));
            var phases = await _phases.LoadAsync(lead0.PlaybookId, ct);
            if (!phases.IsClosed(lead0.Status))
                return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "This lead isn't in a closed stage — there's nothing to reopen." }));
            if (!phases.IsOpen(input.TargetStatus))
                return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "target_status must be an open pipeline stage." }));
            if (await _stages.ReopenPolicyAsync(lead0.PlaybookId, lead0.Status, ct) != StageReopenPolicy.ManagerApproval)
                return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "This stage doesn't require an approval request to reopen." }));
        }

        // D9/D9a — a gate-exception request needs a reason, a real forward target
        // stage, and an actual blocked gate to except: this asks the SAME question
        // LeadsController.Update's stageChanged branch asks (via the shared
        // StageGateService), it just refuses to move on a "no" instead of
        // returning it.
        if (input.Type == ApprovalTypes.GateException)
        {
            if (string.IsNullOrWhiteSpace(input.Reason))
                return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "A reason is required to request a gate exception." }));
            if (string.IsNullOrWhiteSpace(input.TargetStatus))
                return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "target_status is required" }));
            var target = input.TargetStatus.Trim();
            var phases = await _phases.LoadAsync(lead0.PlaybookId, ct);
            if (!phases.IsKnown(target))
                return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = $"\"{target}\" isn't a recognized stage." }));
            var ranks = await _stages.RanksAsync(lead0.PlaybookId);
            if (ranks.GetValueOrDefault(target, 0) < ranks.GetValueOrDefault(lead0.Status, 0))
                return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "target_status must be a forward move. Moving a lead backward uses a different approval path." }));
            var missing = await _stageGate.MissingRequirementsAsync(lead0, null, target);
            if (missing.Count == 0)
                return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "This move isn't blocked by any stage requirement — there's nothing to request an exception for." }));
        }

        // D9a #3 — a duplicate request refused while one is pending, keyed on
        // (lead, target stage), so a manager's queue never fills with copies of
        // the same ask.
        if (ApprovalTypes.KeyedByTargetStatus.Contains(input.Type))
        {
            var target = input.TargetStatus!.Trim();
            var pendingDuplicate = await _store.FindPendingDuplicateAsync(lead0.Id, input.Type!, target, ct);
            if (pendingDuplicate is not null)
                return ApprovalOutcome.Refused(Refusal.Conflict(new
                {
                    error = $"A {input.Type} request to \"{target}\" is already pending for this lead.",
                    code = "duplicate_pending_request",
                    pending_request_id = pendingDuplicate.Id,
                }));
        }

        // Q13: a discount request is tied to ONE quote (its id rides on the request as RecordType "quote" / RecordId - the columns the
        // reveal request already uses for "the record this is about"). Without an id it keeps the older meaning, "the latest open quote".
        if (input.Type == ApprovalTypes.Discount && input.QuoteId is Guid quoteId)
        {
            var tied = await _store.QuoteOnLeadAsync(quoteId, lead0.Id, ct);
            if (tied is null) return ApprovalOutcome.Refused(Refusal.NotFound(new { error = "Quote not found on this lead" }));
            if (tied.Status is not ("draft" or "sent"))
                return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = $"A {tied.Status} quote can't take a discount. Start from the quote that is still open." }));
        }

        var req = new ApprovalRequest
        {
            RecordType = input.Type == ApprovalTypes.Discount && input.QuoteId is not null ? "quote" : null,
            RecordId = input.Type == ApprovalTypes.Discount ? input.QuoteId : null,
            // Explicit Id — the ApprovalRequested raise below (same save) needs
            // the real id before SaveChanges; see LeadWriteProcess.CreateAsync's
            // identical comment on why a `gen_random_uuid()` default can't be.
            Id = Guid.NewGuid(),
            RequesterId = requesterId,
            Type = input.Type!,
            LeadId = lead0.Id,
            Amount = input.Amount,
            Reason = input.Reason,
            TargetStatus = ApprovalTypes.KeyedByTargetStatus.Contains(input.Type) ? input.TargetStatus!.Trim() : null,
        };
        _store.Add(req);
        // E1 step 4 (to-do/e1-event-backbone-design.md §4) — same save as the
        // request row above.
        _events.Raise(DomainEventTypes.Keys.ApprovalRequested, DomainEventTypes.AggregateTypes.Approval, req.Id, requesterId,
            new DomainEventPayloads.ApprovalRequested(req.Id, DomainEventTypes.AggregateTypes.Lead, req.LeadId, requesterId));
        await _store.SaveChangesAsync(ct);

        // E1 step 5 (to-do/e1-event-backbone-design.md §5/§8 step 5): the
        // inline decider fan-out that used to live here is GONE —
        // NotificationDomainEventHandler now reacts to the ApprovalRequested
        // event raised above (off the request thread, via the dispatch
        // worker) and rebuilds the same recipient set (deciders scoped to the
        // lead's team, narrowed to admins under the "admins" gate-exception
        // approver policy, minus the requester) from the request/lead's
        // current row state — UNLESS an approval chain claims this request
        // (below), in which case that handler skips its broad team fan-out
        // entirely (see its own guard) and the chain's own, narrower
        // per-step notification (ApprovalChainProcess.NotifyStepApproverAsync)
        // is the only one that fires.

        // E2.6 slice 9 (design §8, §14 item 5) — pick the first admin-priority
        // chain covering this type whose condition matches; a request with no
        // matching chain is byte-identical to before chains existed.
        await _chains.ResolveAndStartAsync(req, lead0, ct);

        return ApprovalOutcome.Ok(await ToDtoAsync(req, hasViewLeadValues, ct));
    }

    // ---- Decide -----------------------------------------------------------------

    /// <summary>
    /// Decides a pending request. Which permission gates it is dispatched here
    /// (not at the controller) because the answer depends on <c>req.Type</c>,
    /// which only this read knows — <paramref name="hasDecideApprovals"/>,
    /// <paramref name="hasViewFinancials"/> and <paramref name="canDecideGateExceptions"/>
    /// are the three FACTS the controller already resolved from the caller
    /// (D9a #1/#2), never re-derived here.
    ///
    /// E0.1 adds two gates, checked AFTER the type-specific permission checks
    /// above and BEFORE any mutation — a caller who fails a permission check
    /// gets that refusal first, not a 404/403 that leaks whether the id exists:
    ///
    /// 1. TEAM SCOPE (<paramref name="ctx"/>) — the decider may decide this
    ///    request only if its REQUESTER is among the people <paramref
    ///    name="ctx"/> makes visible, computed with the exact same
    ///    <c>PeopleScope.VisibleIdsAsync</c> call <see cref="ListAsync"/> and
    ///    <see cref="PendingCountAsync"/> already use — so a request hidden
    ///    from a manager's queue cannot be decided by guessing its id either.
    ///    Out of scope refuses NotFound, identical to a missing id.
    /// 2. SELF-DECISION (<paramref name="selfDecisionPolicy"/>) — an org
    ///    setting (<see cref="Models.ApprovalSelfDecisionPolicy"/>, default
    ///    <c>blocked</c>) refusing Forbidden when the decider IS the
    ///    requester. Applies to all four approval types alike.
    /// </summary>
    public async Task<ApprovalOutcome> DecideAsync(
        Guid id, ApprovalDecisionInput input, Guid deciderId,
        bool hasDecideApprovals, bool hasViewFinancials, bool canDecideGateExceptions,
        RecordAccessContext ctx, string selfDecisionPolicy, bool hasViewLeadValues,
        CancellationToken ct = default)
    {
        var req = await _store.GetAsync(id, ct);
        if (req is null) return ApprovalOutcome.Refused(Refusal.NotFound(new { error = "Request not found" }));

        // Channel partners (Q13): a payout is decided ONLY on its approval chain, where the approve-payouts permission and the
        // preparer-never-approves rule are enforced (ApprovalChainProcess.DecideStepAsync). This older endpoint carries neither, so it refuses.
        if (req.Type is ApprovalTypes.PartnerPayout or ApprovalTypes.PartnerAdjustment)
            return ApprovalOutcome.Refused(Refusal.Forbidden(new
            {
                error = "A partner payout is decided on its approval chain. Open the payout and decide it there.",
                code = "partner_payout_use_chain",
            }));

        // D9a #1/#2 — who may decide depends on the type. GateException follows
        // the org-configured approver policy; every other type keeps EXACTLY
        // today's dual gate — DecideApprovals AND ViewFinancials, preserved
        // rather than loosened.
        if (req.Type == ApprovalTypes.GateException)
        {
            if (!canDecideGateExceptions)
                return ApprovalOutcome.Refused(Refusal.Forbidden(new { error = "Your role cannot decide gate-exception requests." }));
        }
        else
        {
            if (!hasDecideApprovals)
                return ApprovalOutcome.Refused(Refusal.Forbidden(new { error = "Your role cannot decide approval requests." }));
            if (!hasViewFinancials)
                return ApprovalOutcome.Refused(Refusal.Forbidden(new { error = "Your role does not have the 'financials.view' permission." }));
        }

        // E0.1 #1 — team scope: the requester must be within the decider's
        // visible people. Same predicate as List/PendingCount; out-of-scope
        // 404s exactly like a missing id, so ids cannot be probed.
        var visiblePeople = await _peopleScope.VisibleIdsAsync(ctx, ct);
        if (visiblePeople is not null && !visiblePeople.Contains(req.RequesterId))
            return ApprovalOutcome.Refused(Refusal.NotFound(new { error = "Request not found" }));

        // E0.1 #2 — self-decision, org-configured (default: blocked).
        if (!GateEscalationSettingsService.CanSelfDecide(selfDecisionPolicy, deciderId, req.RequesterId))
            return ApprovalOutcome.Refused(Refusal.Forbidden(new
            {
                error = "You can't decide your own request. Another manager or an org admin must decide it.",
            }));

        // E2.6 slice 9 / compat follow-up (2026-09-27) — a request an approval
        // chain claims no longer refuses this OLD endpoint outright: an
        // installed phone build only ever calls POST /approvals/{id}/decide
        // (never the chain card's own instances/{id}/decide), so a blanket
        // refusal here silently broke deciding for anyone on that build once
        // any chain existed. Instead, route THIS decide call to the chain's
        // CURRENT STEP — same governance (team scope/self-decision, already
        // checked above) and the SAME per-step mutation
        // ApprovalChainsController.DecideStep uses — when the caller turns
        // out to be that step's resolved approver. A caller who is NOT that
        // approver is refused 403 naming who the request is waiting on, keeping the wire
        // `code: "governed_by_chain"` so the desktop's existing defensive
        // handling (a card that raced a chain appearing after its own
        // "no chain" read) still recognises it — see
        // ApprovalChainProcess.DecideCurrentStepForLegacyEndpointAsync's own
        // comment for the full shape.
        if (await _chains.HasActiveInstanceAsync(req.Id, ct))
        {
            var legacy = await _chains.DecideCurrentStepForLegacyEndpointAsync(req, deciderId, input.Approve == true, input.Note, ct);
            if (legacy.WaitingOnMessage is string waitingOn)
                return ApprovalOutcome.Refused(Refusal.Forbidden(new { error = waitingOn, code = "governed_by_chain" }));
            if (legacy.ConflictMessage is string conflict)
                return ApprovalOutcome.Refused(Refusal.Conflict(new { error = conflict, code = "governed_by_chain" }));
            // The chain reached a final outcome this call — apply it through
            // the SAME mutation ApplyChainOutcomeAsync/ApprovalChainsController.DecideStep
            // use, no further permission re-check (the chain already
            // validated this decider, per step, same as that path).
            if (legacy.FinalApproved is bool finalApproved)
                return await ApplyDecisionAsync(req, finalApproved, input.Note, deciderId, hasViewLeadValues, ct, input.WinValues);
            // Still pending a further step — the underlying request is
            // unchanged (same "request updated/still pending" shape the
            // chain-decide endpoint returns).
            return ApprovalOutcome.Ok(await ToDtoAsync(req, hasViewLeadValues, ct));
        }

        return await ApplyDecisionAsync(req, input.Approve == true, input.Note, deciderId, hasViewLeadValues, ct, input.WinValues);
    }

    /// <summary>
    /// The mutation a decision performs, shared by two entry points:
    /// <see cref="DecideAsync"/> (the ordinary, permission-gated HTTP path)
    /// and <see cref="ApplyChainOutcomeAsync"/> (called once an
    /// <c>ApprovalChainInstance</c> reaches a final outcome — see that
    /// method's own comment for why NO permission re-check happens here).
    /// Everything below this point is UNCHANGED from before the chain split:
    /// same status transition, same reassign/discount/reopen/gate-exception
    /// application, same events.
    /// </summary>
    private async Task<ApprovalOutcome> ApplyDecisionAsync(
        ApprovalRequest req, bool approve, string? note, Guid deciderId, bool hasViewLeadValues, CancellationToken ct, WinValuesInput? winValues = null)
    {
        if (req.Status != "pending")
            return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = "Already decided" }));

        req.Status = approve ? "approved" : "rejected";
        req.DecidedById = deciderId;
        req.DecidedAt = DateTime.UtcNow;
        req.DecisionNote = note;

        // ApprovalTypes.Automation deliberately matches NONE of the
        // type-specific branches below — a plain sign-off with no baked-in
        // effect. What happens next lives entirely in the automation's own
        // onApproved/onRejected action list, run once AutomationApprovalResumeHandler
        // reacts to the ApprovalDecided event raised at the bottom of this
        // method (design §12 slice 10).

        // Approving a reassignment performs it (to the requester).
        if (approve && req.Type == "reassign")
        {
            var lead = await _store.GetLeadForDecisionAsync(req.LeadId, ct);
            if (lead is not null)
            {
                // The same invariant POST /leads/{id}/assign enforces: a lead's owner
                // must be in the lead's team. Refusing here means the approval is not
                // silently half-applied: it stays pending, and the decider is told
                // what to fix.
                var requesterTeams = await _store.TeamIdsForUserAsync(req.RequesterId, ct);
                if (lead.TeamId is Guid leadTeam && !requesterTeams.Contains(leadTeam))
                    return ApprovalOutcome.Refused(Refusal.Conflict(new
                    {
                        error = "The requester isn't in this lead's team. Move the lead to one of their teams first.",
                        code = "owner_outside_team",
                        lead_team_id = leadTeam,
                        owner_team_ids = requesterTeams,
                    }));

                var previousOwnerId = lead.OwnerId;
                lead.OwnerId = req.RequesterId;
                lead.UpdatedAt = DateTime.UtcNow;
                // Same rule as the two direct assign paths — an approved reassign is
                // a reassignment, and must not quietly behave differently.
                await _invoiceOwnership.FollowLeadOwnerAsync(lead, previousOwnerId, ct);
                var who = await _store.ProfileFullNameAsync(req.RequesterId, ct);
                _store.AddLeadActivity(new LeadActivity
                {
                    LeadId = lead.Id,
                    AuthorId = deciderId,
                    Type = "note",
                    Body = $"Reassigned to {who ?? "requester"} (approved request)",
                });
            }
        }

        // Approving a discount writes it into the quote (C1 follow-on): the
        // approved amount becomes the quote's DiscountAmount and every derived
        // total is recomputed from the tracked line items, never just the old
        // total minus the discount. Targets the lead's most recent quote that
        // hasn't already been accepted/declined; if there is none, the approval
        // still records.
        if (approve && req.Type == "discount" && req.Amount is decimal discount)
        {
            // Q13: a request tied to a quote applies to THAT quote; an older, untied one keeps "the latest open quote".
            var tiedToQuote = req is { RecordType: "quote", RecordId: not null };
            var quote = tiedToQuote
                ? await _store.QuoteOnLeadAsync(req.RecordId!.Value, req.LeadId, ct)
                : await _store.LatestOpenQuoteAsync(req.LeadId, ct);
            if (tiedToQuote && (quote is null || quote.Status is not ("draft" or "sent")))
                return ApprovalOutcome.Refused(Refusal.Conflict(new { error = "The quote this discount was requested for is no longer open (it was accepted, declined or replaced). Ask the rep to request again on the current quote." }));
            if (quote is not null)
            {
                // Parsed through the SHARED Services.QuoteLineItems.Parse. This
                // was briefly a duplicate of QuotesController.ParseLineItems —
                // the layering made the old cross-controller call impossible,
                // and the parser moved to System where both callers can reach
                // it, rather than being copied and asked to stay in sync.
                // not a bare deserialize, so this reads the #83 {quantity,
                // unit_price} shape and the legacy {amount} shape identically to
                // every other reader.
                var items = SalesApi.Services.QuoteLineItems.Parse(quote.LineItems);
                // Base = the pre-discount charge total: sum of tracked line items
                // if there are any, else fall back to the quote's own pre-discount
                // amount (Subtotal + whatever discount it already carried) so a
                // second approval on the same quote doesn't compound.
                var baseAmount = items.Count > 0
                    ? QuoteNumbering.Sum(items.Select(i => (i.Quantity, i.UnitPrice)))
                    : quote.Subtotal + quote.DiscountAmount;
                // M12: the second entry point where a discount larger than the
                // lines is decided. Same one definition the quote builder uses.
                var overDiscountPolicy = QuoteDiscount.Normalise(
                    (await _orgSettings.GetInvoiceProfileAsync()).QuoteOverDiscountPolicy);
                if (overDiscountPolicy == QuoteDiscount.OverDiscountRefuse
                    && QuoteDiscount.IsOverDiscount(baseAmount, discount))
                    return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = QuoteDiscount.RefusalMessage(baseAmount, discount) }));
                // E10.5 (owner 2026-10-15): a discount approved on a GENERATED proposal is a new version, not an edit of the row - the
                // files the customer may hold carry the old figures. The normal generate path makes it (same services, inputs and
                // pinned versions, the approved discount; the previous version is superseded), so the new files, deal value and VAT come
                // from the one place that computes them. The over-discount refusal above already ran against the same pre-discount base.
                // If the version cannot be made the approval STANDS; a note tells the rep to generate it by hand.
                if (quote.GenerationSnapshot is not null && _proposals is not null)
                {
                    var admin = new RecordAccessContext(deciderId, IsOrgAdmin: true, HasManagerAccess: true, Scope: TeamScope.Everything, Visibility: "manage");
                    var made = await _proposals.GenerateAsync(admin, deciderId, req.LeadId,
                        new GenerateProposalVersionInput(null, quote.Id, null, discount), ct, discountApproved: true);
                    _store.AddLeadActivity(new LeadActivity
                    {
                        LeadId = req.LeadId, AuthorId = deciderId, Type = "note",
                        Body = made.Outcome == SalesApi.ProcessLayer.Proposals.ProposalGenerateProcess.Outcome.Ok
                            // D4 (owner 2026-11-09): an unsent draft is updated in place (same row and number), not followed by a new version.
                            ? made.Value!.Proposal.Id == quote.Id
                                ? $"Discount approved: proposal {made.Value.Proposal.Number} updated with the discount"
                                : $"Discount approved: new proposal version {made.Value.Proposal.Number} made"
                            : $"Discount approved, but the new proposal version could not be made ({made.Error}). Generate a new version with the discount.",
                    });
                }
                else if (quote.Status == "sent")
                {
                    // F10: the customer holds this numbered quote, so an approved discount is NEVER written into it. It becomes a new draft
                    // revision (the quote-revise path), which supersedes the sent one when the rep sends it.
                    string reviseNote;
                    if (_quotes is null)
                        reviseNote = "Discount approved, but this quote has already been sent, so it was not changed. Revise the quote and enter the approved discount.";
                    else
                    {
                        var admin = new RecordAccessContext(deciderId, IsOrgAdmin: true, HasManagerAccess: true, Scope: TeamScope.Everything, Visibility: "manage");
                        var (reviseRefusal, revision) = await _quotes.ReviseAsync(admin, deciderId, req.LeadId, quote.Id, discount);
                        reviseNote = reviseRefusal is null
                            ? $"Discount approved: a new draft revision of quote {quote.Number ?? quote.Title} carries it. The quote already sent is unchanged; send the revision to give the customer the new price."
                            : $"Discount approved, but the revision could not be made ({reviseRefusal.Reason}). The quote already sent is unchanged.";
                    }
                    _store.AddLeadActivity(new LeadActivity { LeadId = req.LeadId, AuthorId = deciderId, Type = "note", Body = reviseNote });
                }
                else
                {
                var (printedDiscount, newSubtotal) = QuoteDiscount.Resolve(baseAmount, discount, overDiscountPolicy);
                var newTax = Math.Round(newSubtotal * (quote.TaxRate / 100m), 2, MidpointRounding.AwayFromZero);
                quote.DiscountAmount = printedDiscount;
                quote.Subtotal = newSubtotal;
                quote.TaxAmount = newTax;
                quote.Total = newSubtotal + newTax;
                _store.AddLeadActivity(new LeadActivity
                {
                    LeadId = req.LeadId,
                    AuthorId = deciderId,
                    Type = "note",
                    // No amounts (owner 2026-10-15): an automatic deal note is readable by people without lead_values.view,
                    // so the figures live on the quote (masked there), not in this text.
                    Body = $"Discount approved and applied to quote “{quote.Title}”",
                });
                }
            }
        }

        // H6 — approving a reopen performs it: the whole point of a real
        // request/decide round trip is that the lead moves ONLY on approval,
        // never at request time. Re-validates everything Create() checked
        // because the pipeline can have been reshaped in the meantime.
        if (approve && req.Type == "reopen")
        {
            var lead = await _store.GetLeadForDecisionAsync(req.LeadId, ct);
            // `lead?.` because the null check is the line below, not above: a
            // missing lead resolves to the org-wide list and is then rejected on
            // its own terms rather than throwing here.
            var phases = await _phases.LoadAsync(lead?.PlaybookId, ct);
            if (lead is null || string.IsNullOrEmpty(req.TargetStatus))
                return ApprovalOutcome.Refused(Refusal.Conflict(new { error = "This reopen request no longer refers to a valid lead/stage." }));
            if (!phases.IsClosed(lead.Status))
                return ApprovalOutcome.Refused(Refusal.Conflict(new { error = "This lead is no longer in a closed stage — there's nothing left to reopen." }));
            if (!phases.IsOpen(req.TargetStatus))
                return ApprovalOutcome.Refused(Refusal.Conflict(new { error = "The requested stage is no longer an open pipeline stage. Ask the rep to request again." }));

            var oldStatus = lead.Status;
            var closeDatePolicy = await _reopenSettings.GetAsync(ct);
            var ranks = await _stages.RanksAsync(lead.PlaybookId);
            var labels = await _stages.LabelsAsync(lead.PlaybookId);
            lead.Status = req.TargetStatus;
            StageService.SyncCloseDates(phases, lead, closeDatePolicy.CloseDatePolicy);
            lead.UpdatedAt = DateTime.UtcNow;
            var label = labels.GetValueOrDefault(req.TargetStatus, req.TargetStatus);
            _store.AddLeadActivity(new LeadActivity
            {
                LeadId = lead.Id,
                AuthorId = deciderId,
                Type = "status_change",
                Body = $"Stage moved back to {label} — {req.Reason} (approved reopen request)",
            });
            // H6 — the structured reason on the queryable stage-event row, not only
            // the activity body above. AddStageEvent itself raises LeadStageChanged
            // in lockstep (see its own comment); LeadReopened is the narrower fact
            // specific to THIS branch (owner decision 2026-09-26, design §4/§9: a
            // reopen raises both, same call, same save).
            _stages.AddStageEvent(lead.Id, oldStatus, req.TargetStatus, deciderId, ranks, labels, reason: req.Reason);
            // Owner 2026-11-12 (deal values per stage): a reopen leaves a sold stage, so only a Proposal / Negotiation role stage could capture here; the same call keeps every move alike.
            await _stages.CaptureStageValuesAsync(lead, oldStatus, deciderId, ct);
            _events.Raise(DomainEventTypes.Keys.LeadReopened, DomainEventTypes.AggregateTypes.Lead, lead.Id, deciderId,
                new DomainEventPayloads.LeadReopened(lead.Id, oldStatus, req.TargetStatus, req.Reason));
        }

        // D9/D9a — approving a gate exception PERFORMS the move (Q7b's precedent,
        // same as reopen above): a rep must not get approval and then hit the same
        // gate again. Re-validates freshness the same way reopen does, but
        // deliberately does NOT re-run StageGateService — that would just re-apply
        // the gate this approval exists to get past. It DOES still run the other
        // gates a direct move would have to clear (owner assigned, payment terms) —
        // this adds a way past the stage-requirements gate only, not past every
        // gate a move can hit.
        if (approve && req.Type == ApprovalTypes.GateException)
        {
            var lead = await _store.GetLeadForDecisionAsync(req.LeadId, ct);
            if (lead is null || string.IsNullOrEmpty(req.TargetStatus))
                return ApprovalOutcome.Refused(Refusal.Conflict(new { error = "This request no longer refers to a valid lead/stage." }));
            var phases = await _phases.LoadAsync(lead.PlaybookId, ct);
            if (!phases.IsKnown(req.TargetStatus))
                return ApprovalOutcome.Refused(Refusal.Conflict(new { error = "The requested stage no longer exists. Ask the rep to request again." }));
            var ranks = await _stages.RanksAsync(lead.PlaybookId);
            if (ranks.GetValueOrDefault(req.TargetStatus, 0) < ranks.GetValueOrDefault(lead.Status, 0))
                return ApprovalOutcome.Refused(Refusal.Conflict(new { error = "This lead has already moved past the requested stage. Ask the rep to request again." }));

            var movingToWon = phases.IsWon(req.TargetStatus);
            if (movingToWon && await _stageGate.WinAskForMoveAsync(lead, req.TargetStatus) is { } winAsk)
            {
                // Parked item 7: the Won stage asks for deal values / the payment term and the deal has no accepted CRM proposal. The approving
                // gate exception does NOT excuse them: the approver (who can enter deal values) gives the missing ones on the decide call, they are
                // validated like a direct move's win_values and written with the move; a required value still missing refuses the approval.
                var win = winValues ?? new WinValuesInput();
                // Entering a value the deal does not hold yet is open to anyone (owner 2026-10-27); changing one it holds needs the values permission.
                if (!hasViewLeadValues && WinAsk.Overwrites(lead, win))
                    return ApprovalOutcome.Refused(Refusal.Forbidden(new { error = "Your role cannot change deal values.", code = "win_values_forbidden" }));
                var terms = (await _paymentWorkflow.GetConfigAsync(lead.PlaybookId)).Terms.Select(t => t.Key).ToList();
                var (winError, folded) = WinAsk.Fold(winAsk.Ask, winAsk.Defs, terms, WinAsk.Blank(), win);
                if (winError is not null)
                    return ApprovalOutcome.Refused(Refusal.BadRequest(new { error = winError, code = "win_values_invalid" }));
                if (folded!.ClosedValue is decimal closed) lead.ClosedValue = closed;
                if (!string.IsNullOrEmpty(folded.PaymentTermKey)) lead.PaymentTermKey = folded.PaymentTermKey;
                if (folded.Custom is { } winCustom)
                    lead.Custom = CustomFieldMasking.Overlay(StageGateService.ParseJson(lead.Custom), winCustom).GetRawText();
                var stillMissing = WinAsk.Missing(winAsk.Ask, winAsk.Defs, lead, null);
                if (stillMissing.Count > 0)
                    return ApprovalOutcome.Refused(Refusal.BadRequest(new
                    {
                        error = $"Enter the missing values to approve this win: {string.Join(", ", stillMissing.Select(m => m.Label))}.",
                        code = "stage_requirements", stage = req.TargetStatus, missing = stillMissing,
                    }));
            }
            if (movingToWon)
            {
                // Same guards LeadsController.Update applies to a direct move into
                // "won" — untouched, not narrowed or widened, by this feature.
                if (lead.OwnerId is null)
                    return ApprovalOutcome.Refused(Refusal.Conflict(new { error = "Assign an owner before marking this lead won." }));
                // E13: this deal's workflow may override require-terms / the term list.
                var paymentCfg = await _paymentWorkflow.GetConfigAsync(lead.PlaybookId);
                if (paymentCfg.Enabled && paymentCfg.RequireTerms && string.IsNullOrEmpty(lead.PaymentTermKey))
                    return ApprovalOutcome.Refused(Refusal.Conflict(new { error = "Pick a payment term before closing this deal as won.", code = "payment_terms_required" }));
            }

            var oldStatus = lead.Status;
            var closeDatePolicy = await _reopenSettings.GetAsync(ct);
            var labels = await _stages.LabelsAsync(lead.PlaybookId);
            lead.Status = req.TargetStatus;
            StageService.SyncCloseDates(phases, lead, closeDatePolicy.CloseDatePolicy);
            lead.UpdatedAt = DateTime.UtcNow;
            var label = labels.GetValueOrDefault(req.TargetStatus, req.TargetStatus);
            _store.AddLeadActivity(new LeadActivity
            {
                LeadId = lead.Id,
                AuthorId = deciderId,
                Type = "status_change",
                Body = $"Stage moved to {label} — {req.Reason} (approved gate exception)",
            });
            _stages.AddStageEvent(lead.Id, oldStatus, req.TargetStatus, deciderId, ranks, labels, reason: req.Reason);
            // Owner 2026-11-12 (deal values per stage): the approved move captures like a direct one (SyncCloseDates already ran above).
            await _stages.CaptureStageValuesAsync(lead, oldStatus, deciderId, ct);

            if (movingToWon)
            {
                // Commit the status change first — same ordering LeadsController.Update
                // uses — so the payment workflow and webhook see it durably saved
                // rather than racing an in-memory value.
                await _store.SaveChangesAsync(ct);
                await _paymentWorkflow.OnDealWonAsync(lead, deciderId, ct);
                // E1 step 3 (to-do/e1-event-backbone-design.md §8 step 3): the
                // inline WebhookEvents.Keys.LeadWon enqueue that used to live
                // here is GONE — WebhookDomainEventHandler now reacts to the
                // LeadClosedWon event below. Design §8 step 3 named this exact
                // call site as a gap ("raises no LeadClosedWon event") that had
                // to be closed BEFORE the inline call could be removed; the
                // Raise call below closed it, using the same shared payload
                // builder as LeadWriteProcess.UpdateAsync's own won branch
                // (DomainEventPayloads), not a copy.
                _events.Raise(DomainEventTypes.Keys.LeadClosedWon, DomainEventTypes.AggregateTypes.Lead, lead.Id, deciderId,
                    await _payloads.LeadWonAsync(lead, ct));
            }
        }

        // Channel partners (owner Q13): a decided partner_payout request moves the PAYOUT it names (submitted -> approved | rejected) in this same save. A
        // rejection releases the payout's ledger entries (its items are deleted) so they can join another payout.
        if (req.Type == ApprovalTypes.PartnerPayout && req.RecordId is Guid payoutId
            && await _store.FindPartnerPayoutAsync(payoutId, ct) is { } payout
            && SalesApi.Services.PartnerPayoutRules.ApplyDecision(payout, approve, deciderId, note, DateTime.UtcNow)
            && !approve)
            _store.RemovePayoutItems(payout.Items.ToList());
        // F9: a decided partner_adjustment request writes (approve) or drops (reject) the manual ledger adjustment it stands for, in this same save.
        if (req.Type == ApprovalTypes.PartnerAdjustment && req.RecordId is Guid adjustmentId)
            await _store.ApplyPartnerAdjustmentAsync(adjustmentId, approve, deciderId, note, ct);

        // E1 step 4 (to-do/e1-event-backbone-design.md §4) — one raise for every
        // decision, whichever of the four request types it is: the fact "this
        // request was decided" is the same shape regardless of what deciding it
        // went on to DO (perform a reassign/reopen/gate-exception, or nothing on
        // a rejection).
        _events.Raise(DomainEventTypes.Keys.ApprovalDecided, DomainEventTypes.AggregateTypes.Approval, req.Id, deciderId,
            new DomainEventPayloads.ApprovalDecided(req.Id, req.Status, deciderId));

        // E12.5 - a reveal decision: an approval fixes the grant's last instant NOW (decision time + the org's limit at this moment, so a
        // later settings change does not stretch or shrink a grant already given), and either outcome is logged. The log write goes through
        // the same DbContext, so it commits in the SAME save as the decision and the ApprovalDecided event above. Never the value.
        if (req.Type == ApprovalTypes.Reveal)
        {
            var minutes = (await _orgSettings.GetRevealSettingsAsync()).Minutes;
            if (approve) req.GrantExpiresAt = req.DecidedAt!.Value.AddMinutes(minutes);
            if (_accessLog is not null && req.RecordType is not null)
                await _accessLog.RecordAsync(
                    deciderId, approve ? DataAccessActions.RevealApproved : DataAccessActions.RevealRefused,
                    req.RecordType, req.RecordId, category: req.Category,
                    detail: approve ? $"requester:{req.RequesterId};minutes:{minutes}" : $"requester:{req.RequesterId}");
        }

        await _store.SaveChangesAsync(ct);

        // E1 step 5 (to-do/e1-event-backbone-design.md §5/§8 step 5): the
        // inline "tell the requester" call that used to live here is GONE —
        // NotificationDomainEventHandler now reacts to the ApprovalDecided
        // event raised above (off the request thread, via the dispatch
        // worker), including the "a rejection is private, never broadcast"
        // rule (silent when the requester decided their own request).

        return ApprovalOutcome.Ok(await ToDtoAsync(req, hasViewLeadValues, ct));
    }

    // ---- E2.6 slice 9: chain outcome application ------------------------------

    /// <summary>
    /// Applies a chain's FINAL outcome (approved once every step signed off,
    /// or rejected at any step) to the underlying <see cref="ApprovalRequest"/>
    /// — called by <c>Controllers.ApprovalChainsController</c> once
    /// <c>ApprovalChainProcess.DecideStepAsync</c> reports a final result,
    /// never from an HTTP endpoint of its own.
    ///
    /// DELIBERATELY NO PERMISSION RE-CHECK: unlike <see cref="DecideAsync"/>,
    /// this does not re-verify DecideApprovals/ViewFinancials/gate-exception
    /// policy, team scope, or self-decision — <c>DecideStepAsync</c> already
    /// applied the chain's OWN governance (its step's approver-kind, team
    /// scope and self-decision policy) to every step that led here, including
    /// the final one. Re-checking the ORIGINAL type-based permission here
    /// would wrongly refuse a legitimate named chain approver who simply
    /// doesn't hold the org's blanket DecideApprovals/ViewFinancials bits —
    /// the whole point of a chain is to name a DIFFERENT approver than that
    /// blanket gate would pick.
    /// </summary>
    public async Task<ApprovalOutcome> ApplyChainOutcomeAsync(
        Guid requestId, bool approve, Guid deciderId, string? note, bool hasViewLeadValues, CancellationToken ct = default)
    {
        var req = await _store.GetAsync(requestId, ct);
        if (req is null) return ApprovalOutcome.Refused(Refusal.NotFound(new { error = "Request not found" }));
        return await ApplyDecisionAsync(req, approve, note, deciderId, hasViewLeadValues, ct);
    }

    // ---- Line-item parsing ---------------------------------------------------

}

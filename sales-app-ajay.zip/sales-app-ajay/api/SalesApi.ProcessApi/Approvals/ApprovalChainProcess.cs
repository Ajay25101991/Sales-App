using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.Approvals;

namespace SalesApi.ProcessLayer.Approvals;

/// <summary>
/// Approval chains (E2.6 slice 9, to-do/e2-automation-design.md §8) — an
/// org-configurable layer ABOVE the fixed <see cref="ApprovalRequest"/> types
/// (reassign/discount/reopen/gate_exception), not a replacement for them.
///
/// RESOLUTION (owner decision 2026-09-27, design §14 item 5 — REPLACES E2.0
/// decision 13's "most specific wins" overlap policy): every enabled chain
/// covering the request's type is tried in ADMIN-SET PRIORITY order
/// (ascending); the FIRST whose condition matches wins, no combining, no
/// "most specific". A request that matches no chain behaves exactly as it did
/// before chains existed — <see cref="ApprovalProcess.CreateAsync"/> and
/// <see cref="ApprovalProcess.DecideAsync"/> are UNCHANGED for that request.
///
/// GOVERNANCE REUSE: once a chain governs a request, deciding a step still
/// goes through the SAME two E0.1 gates <see cref="ApprovalProcess.DecideAsync"/>
/// already enforces — team scope (<see cref="PeopleScope.VisibleIdsAsync"/>)
/// and the org's self-decision policy (<see
/// cref="GateEscalationSettingsService.CanSelfDecide"/>) — applied PER STEP,
/// not once for the whole chain, on top of the step's own approver-kind check.
///
/// NARROWED FROM THE FULL DESIGN (§8), STATED HERE ONCE: this slice builds
/// sequential steps only (no <c>Mode</c> "parallel"/"any_one") and no
/// per-step timeout/escalation — the slice-9 brief's own item list and test
/// list name neither. "Role" approver steps are likewise not built (owner
/// decision 2026-09-27 for automations, "no role targets for now", extended
/// here per the brief) — a chain step is only <c>manager_of_owner</c> or
/// <c>explicit_user</c>. See the story report for these as decisions, not
/// oversights.
///
/// WHY THIS DOES NOT CALL BACK INTO <see cref="ApprovalProcess"/> (avoiding a
/// Process/Process dependency cycle, since <see cref="ApprovalProcess"/> calls
/// INTO this class at create time): the mutation that actually performs an
/// approved reassign/discount/reopen/gate-exception stays exactly where it
/// already lives, in <see cref="ApprovalProcess"/>. This class only tracks
/// step decisions and reports when a chain reaches a FINAL outcome
/// (approved/rejected); <see cref="Controllers.ApprovalChainsController"/>
/// then calls <see cref="ApprovalProcess.ApplyChainOutcomeAsync"/> — a
/// SEPARATE public entry point on that class with no permission re-checks
/// (the chain already validated the decider), reusing the same mutation code
/// the direct decide path uses, never a second copy of it.
/// </summary>
public sealed class ApprovalChainProcess
{
    private readonly ApprovalChainStore _store;
    private readonly NotificationDispatcher _notify;
    // Layering round 4 (owner decision 2026-09-30): AppDbContext is kept ONLY
    // for the explicit transaction control in ApplyStepDecisionAsync below
    // (Database.CurrentTransaction/BeginTransactionAsync) — no store exposes
    // transaction control, and that method's own comment documents in detail
    // why the join-ambient-transaction-or-open-one behaviour is load-bearing;
    // reaching for one here would be exactly the "genuinely risky restructure"
    // the round-4 brief says to leave alone. GateEscalationSettingsService's
    // read below moved to its own injectable front (GateEscalationSettingsReader)
    // since that conversion carries no such risk, and PeopleScopeReader
    // (already registered in Program.cs) is now required rather than falling
    // back to `new PeopleScopeReader(db)` — round 2/3's rule for an optional
    // fallback once the service it falls back to is always provided by DI.
    private readonly AppDbContext _db;
    private readonly PeopleScopeReader _peopleScope;
    private readonly GateEscalationSettingsReader _gateEscalation;

    public ApprovalChainProcess(
        ApprovalChainStore store, NotificationDispatcher notify, AppDbContext db,
        PeopleScopeReader peopleScope, GateEscalationSettingsReader gateEscalation)
    {
        _store = store;
        _notify = notify;
        _db = db;
        _peopleScope = peopleScope;
        _gateEscalation = gateEscalation;
    }

    public sealed record Refusal(string Reason, bool NotFound = false, bool Conflict = false, bool Forbidden = false, string? Code = null);

    // ---- Admin CRUD ---------------------------------------------------------

    private static ApprovalChainDto ToDto(ApprovalChain c, IReadOnlyDictionary<Guid, string?> names)
    {
        var condition = JsonDocument.Parse(string.IsNullOrWhiteSpace(c.ConditionJson) ? "{}" : c.ConditionJson).RootElement.Clone();
        var types = ParseRequestTypes(c.RequestTypesJson);
        var steps = c.Steps.OrderBy(s => s.Order)
            .Select(s =>
            {
                var groupIds = ApprovalChainStep.ParseApproverUserIds(s.ApproverUserIdsJson);
                var groupNames = groupIds.Select(id => names.GetValueOrDefault(id) ?? "Unknown").ToList();
                return new ApprovalChainStepDto(
                    s.Id, s.Order, s.ApproverKind, s.ApproverUserId,
                    s.ApproverUserId is Guid u ? names.GetValueOrDefault(u) : null,
                    groupIds, groupNames);
            })
            .ToList();
        return new ApprovalChainDto(c.Id, c.Name, c.Priority, c.Enabled, condition, types, steps, c.CreatedAt);
    }

    private static List<string> ParseRequestTypes(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return [];
        try
        {
            using var doc = JsonDocument.Parse(json);
            return doc.RootElement.ValueKind == JsonValueKind.Array
                ? doc.RootElement.EnumerateArray().Select(e => e.GetString() ?? "").Where(s => s.Length > 0).ToList()
                : [];
        }
        catch (JsonException) { return []; }
    }

    public async Task<List<ApprovalChainDto>> ListAsync(CancellationToken ct = default)
    {
        var chains = await _store.ListAsync(ct);
        var names = await NamesForAsync(chains, ct);
        return chains.Select(c => ToDto(c, names)).ToList();
    }

    public async Task<ApprovalChainDto?> GetAsync(Guid id, CancellationToken ct = default)
    {
        var chain = await _store.GetAsync(id, ct);
        if (chain is null) return null;
        var names = await NamesForAsync([chain], ct);
        return ToDto(chain, names);
    }

    private async Task<Dictionary<Guid, string?>> NamesForAsync(IEnumerable<ApprovalChain> chains, CancellationToken ct)
    {
        var steps = chains.SelectMany(c => c.Steps).ToList();
        var ids = steps.Where(s => s.ApproverUserId.HasValue).Select(s => s.ApproverUserId!.Value)
            .Concat(steps.SelectMany(s => ApprovalChainStep.ParseApproverUserIds(s.ApproverUserIdsJson)))
            .Distinct().ToList();
        return ids.Count == 0 ? new() : await _store.ProfileNamesAsync(ids, ct);
    }

    /// <summary>Validates and applies an input onto a (possibly new) chain's
    /// scalar fields + step list. Shared by Create/Update so the two never
    /// drift on what a legal chain looks like. Async because an
    /// <c>any_of_users</c> step (design §17 item 12) needs a DB round trip to
    /// confirm its group members are real, active users in this org — the
    /// other two kinds need no such check (see <c>ApprovalChainStore.ResolveApproverIdsAsync</c>'s
    /// own comment on why they aren't re-validated dynamically either).</summary>
    private async Task<(Refusal? Refusal, string ConditionJson, string RequestTypesJson, List<ApprovalChainStep> Steps)> Validate(
        ApprovalChainInput input, Guid orgPlaceholder, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(input.Name))
            return (new Refusal("A name is required."), "{}", "[]", []);

        var conditionJson = input.Condition is JsonElement c && c.ValueKind != JsonValueKind.Undefined
            ? c.GetRawText() : "{}";
        // Fail-closed shape check only — full evaluation happens per-request via
        // AutomationConditionEvaluator, same "malformed -> never matches" rule.
        try
        {
            using var doc = JsonDocument.Parse(conditionJson);
            if (doc.RootElement.ValueKind != JsonValueKind.Object)
                return (new Refusal("Condition must be a JSON object."), "{}", "[]", []);
        }
        catch (JsonException) { return (new Refusal("Condition is not valid JSON."), "{}", "[]", []); }

        var types = input.RequestTypes ?? [];
        foreach (var t in types)
            if (!ApprovalTypes.All.Contains(t))
                return (new Refusal($"\"{t}\" isn't a recognized approval type."), "{}", "[]", []);
        var requestTypesJson = JsonSerializer.Serialize(types);

        var stepInputs = input.Steps ?? [];
        if (stepInputs.Count == 0)
            return (new Refusal("A chain needs at least one step."), "{}", "[]", []);

        var steps = new List<ApprovalChainStep>();
        var order = 1;
        foreach (var s in stepInputs)
        {
            if (!ApprovalChainApproverKind.IsValid(s.ApproverKind))
                return (new Refusal($"\"{s.ApproverKind}\" isn't a supported approver kind."), "{}", "[]", []);
            if (s.ApproverKind == ApprovalChainApproverKind.SpecificUser && s.ApproverUserId is null)
                return (new Refusal("A specific-user step needs an approver_user_id."), "{}", "[]", []);

            var approverUserIdsJson = "[]";
            if (s.ApproverKind == ApprovalChainApproverKind.AnyOfUsers)
            {
                // Design §17 item 12: "min 2, all in the org, active". Checked
                // HERE, at chain save time, so a step can never be created with
                // a group too small or containing someone who cannot decide —
                // see ApprovalChainStore.ResolveApproverIdsAsync's own comment
                // for why this static guarantee (at least one non-requester
                // member always survives the per-request self-decision check)
                // is enough, with no matching dynamic re-check needed later.
                var distinctIds = (s.ApproverUserIds ?? []).Distinct().ToList();
                if (distinctIds.Count < 2)
                    return (new Refusal("An \"any one of a group\" step needs at least two distinct approvers."), "{}", "[]", []);
                var activeIds = await _store.ActiveUserIdsInOrgAsync(distinctIds, ct);
                var missing = distinctIds.Except(activeIds).ToList();
                if (missing.Count > 0)
                    return (new Refusal(
                        "Every approver in an \"any one of a group\" step must be an active user in this org."), "{}", "[]", []);
                approverUserIdsJson = JsonSerializer.Serialize(distinctIds);
            }

            steps.Add(new ApprovalChainStep
            {
                Id = Guid.NewGuid(),
                Order = order++,
                ApproverKind = s.ApproverKind!,
                ApproverUserId = s.ApproverKind == ApprovalChainApproverKind.SpecificUser ? s.ApproverUserId : null,
                ApproverUserIdsJson = approverUserIdsJson,
            });
        }

        return (null, conditionJson, requestTypesJson, steps);
    }

    public async Task<(ApprovalChainDto? Created, Refusal? Refusal)> CreateAsync(
        ApprovalChainInput input, Guid createdById, CancellationToken ct = default)
    {
        var (refusal, conditionJson, requestTypesJson, steps) = await Validate(input, Guid.Empty, ct);
        if (refusal is not null) return (null, refusal);

        var nextPriority = await _store.NextPriorityAsync(ct);
        var chain = new ApprovalChain
        {
            Id = Guid.NewGuid(),
            Name = input.Name!.Trim(),
            Priority = nextPriority,
            Enabled = input.Enabled ?? true,
            ConditionJson = conditionJson,
            RequestTypesJson = requestTypesJson,
            CreatedById = createdById,
            Steps = steps,
        };
        _store.Add(chain);
        await _store.SaveChangesAsync(ct);
        return (await GetAsync(chain.Id, ct), null);
    }

    public async Task<(ApprovalChainDto? Updated, Refusal? Refusal)> UpdateAsync(
        Guid id, ApprovalChainInput input, CancellationToken ct = default)
    {
        var chain = await _store.GetAsync(id, ct);
        if (chain is null) return (null, new Refusal("Approval chain not found.", NotFound: true));

        var (refusal, conditionJson, requestTypesJson, steps) = await Validate(input, Guid.Empty, ct);
        if (refusal is not null) return (null, refusal);

        chain.Name = input.Name!.Trim();
        chain.Enabled = input.Enabled ?? chain.Enabled;
        chain.ConditionJson = conditionJson;
        chain.RequestTypesJson = requestTypesJson;
        chain.Steps.Clear();
        foreach (var s in steps) { s.ChainId = chain.Id; chain.Steps.Add(s); }

        await _store.SaveChangesAsync(ct);
        return (await GetAsync(chain.Id, ct), null);
    }

    public async Task<Refusal?> DeleteAsync(Guid id, CancellationToken ct = default)
    {
        var chain = await _store.GetAsync(id, ct);
        if (chain is null) return new Refusal("Approval chain not found.", NotFound: true);
        if (await _store.HasInstancesForChainAsync(id, ct))
            return new Refusal("This chain has decided or in-progress requests and can't be deleted. Disable it instead.", Conflict: true);
        _store.Remove(chain);
        await _store.SaveChangesAsync(ct);
        return null;
    }

    public async Task<(List<ApprovalChainDto>? Reordered, Refusal? Refusal)> ReorderAsync(
        List<Guid>? ids, CancellationToken ct = default)
    {
        var idList = ids ?? [];
        if (idList.Count == 0) return (null, new Refusal("ids is required"));
        var reordered = await _store.ReorderAsync(idList, ct);
        var names = await NamesForAsync(reordered, ct);
        return (reordered.Select(c => ToDto(c, names)).ToList(), null);
    }

    // ---- Runtime: resolution --------------------------------------------

    /// <summary>The value bag a chain's condition evaluates against: the
    /// request's own fields (type/amount/reason/target_status/requester_id)
    /// layered under the same lead-field values a stage gate rule or
    /// automation condition would see for this lead (<c>LeadFormService.ValuesOf</c>)
    /// — a chain scoped to "deal value over 50000" reads the SAME "estimated_value"
    /// key every other rule in this codebase does.</summary>
    internal static Dictionary<string, object?> BuildValues(ApprovalRequest req, Lead? lead)
    {
        var values = LeadFormService.ValuesOf(lead, null);
        values["type"] = req.Type;
        values["amount"] = req.Amount;
        values["reason"] = req.Reason;
        values["target_status"] = req.TargetStatus;
        values["requester_id"] = req.RequesterId.ToString();
        return values;
    }

    /// <summary>
    /// Called once, from <see cref="ApprovalProcess.CreateAsync"/>, right after
    /// a new <see cref="ApprovalRequest"/> is built (same save). Picks the
    /// first enabled chain (priority order) covering <c>req.Type</c> whose
    /// condition matches, creates its <see cref="ApprovalChainInstance"/> at
    /// step 1, and notifies step 1's approver(s). Returns null (no DB writes
    /// beyond the read) when nothing matches — the request then follows
    /// today's unchanged decide path.
    /// </summary>
    // internal, not public — LayerBoundaryTests forbids a public Process
    // surface from naming a System type (ApprovalChainInstance/ApprovalRequest/
    // Lead here). The only caller, ApprovalProcess.CreateAsync, lives in this
    // same assembly (SalesApi.ProcessApi), so internal is all it needs.
    internal async Task<ApprovalChainInstance?> ResolveAndStartAsync(ApprovalRequest req, Lead? lead, CancellationToken ct = default)
    {
        var chains = await _store.EnabledInPriorityOrderAsync(ct);
        var values = BuildValues(req, lead);

        foreach (var chain in chains)
        {
            var types = ParseRequestTypes(chain.RequestTypesJson);
            if (types.Count > 0 && !types.Contains(req.Type)) continue;
            if (!AutomationConditionEvaluator.EvaluateCondition(chain.ConditionJson, values)) continue;

            var instance = new ApprovalChainInstance
            {
                Id = Guid.NewGuid(),
                ChainId = chain.Id,
                ApprovalRequestId = req.Id,
                CurrentStep = 1,
                Status = ApprovalChainInstanceStatus.Pending,
            };
            _store.AddInstance(instance);
            await _store.SaveChangesAsync(ct);

            var firstStep = chain.Steps.OrderBy(s => s.Order).First();
            await NotifyStepApproverAsync(firstStep, req, lead, ct);
            return instance;
        }

        // E12.5 - no configured chain matched a reveal request: use the org's default reveal chain (manager, then admins), made on first
        // need so it shows up in the chain list and can be edited like any other. An admin who DISABLED it has chosen "no default
        // route": nothing is started and the caller (RevealRequestProcess) refuses the request.
        if (req.Type is ApprovalTypes.Reveal or ApprovalTypes.PartnerPayout or ApprovalTypes.PartnerAdjustment)
        {
            var isReveal = req.Type == ApprovalTypes.Reveal;
            var fallback = isReveal ? await _store.FindDefaultRevealChainAsync(ct) : await _store.FindDefaultPayoutChainAsync(ct);
            if (fallback is null)
            {
                // Channel partners (Q13): a payout with no configured chain goes to the org's admins - the preparer is still barred from deciding it
                // (DecideStepAsync), so a one-admin org must configure a second approver before it can pay a partner.
                fallback = new ApprovalChain
                {
                    Id = Guid.NewGuid(),
                    Name = isReveal ? ApprovalChain.DefaultRevealChainName : ApprovalChain.DefaultPartnerPayoutChainName,
                    Priority = await _store.NextPriorityAsync(ct),
                    Enabled = true,
                    ConditionJson = "{}",
                    RequestTypesJson = JsonSerializer.Serialize(isReveal ? new[] { req.Type } : new[] { ApprovalTypes.PartnerPayout, ApprovalTypes.PartnerAdjustment }),
                    Steps = isReveal
                        ?
                        [
                            new ApprovalChainStep { Id = Guid.NewGuid(), Order = 1, ApproverKind = ApprovalChainApproverKind.RequesterManager },
                            new ApprovalChainStep { Id = Guid.NewGuid(), Order = 2, ApproverKind = ApprovalChainApproverKind.OrgAdmins },
                        ]
                        :
                        [
                            new ApprovalChainStep { Id = Guid.NewGuid(), Order = 1, ApproverKind = ApprovalChainApproverKind.OrgAdmins },
                        ],
                };
                _store.Add(fallback);
            }
            if (!fallback.Enabled) return null;
            var revealInstance = new ApprovalChainInstance
            {
                Id = Guid.NewGuid(),
                ChainId = fallback.Id,
                ApprovalRequestId = req.Id,
                CurrentStep = 1,
                Status = ApprovalChainInstanceStatus.Pending,
            };
            _store.AddInstance(revealInstance);
            await _store.SaveChangesAsync(ct);
            await NotifyStepApproverAsync(fallback.Steps.OrderBy(s => s.Order).First(), req, lead, ct);
            return revealInstance;
        }

        return null;
    }

    public Task<bool> HasActiveInstanceAsync(Guid requestId, CancellationToken ct = default) =>
        _store.HasInstanceForRequestAsync(requestId, ct);

    /// <summary>
    /// The chain instance governing a request, scoped exactly like the
    /// request itself is visible today (coordinator review, 2026-09-27) —
    /// same <see cref="PeopleScope.VisibleIdsAsync"/> predicate
    /// <see cref="ApprovalProcess.ListAsync"/> and the team-scope half of
    /// <see cref="ApprovalProcess.DecideAsync"/>'s E0.1 gate both use: the
    /// caller sees this only if the REQUEST'S REQUESTER is among their
    /// visible people (an org admin, or the requester themselves via
    /// self-visibility, or a manager whose scope covers the requester).
    /// <paramref name="requestId"/> not existing and not being visible are
    /// deliberately the SAME outcome (<c>Visible: false</c>) — same "404, not
    /// 403, so an id can't be probed for existence" rule <c>DecideAsync</c>
    /// already follows, and the precedent <c>GET /leads/{id}/history</c> sets.
    /// </summary>
    public async Task<(bool Visible, ApprovalChainInstanceDto? Instance)> GetInstanceForRequestAsync(
        Guid requestId, RecordAccessContext ctx, CancellationToken ct = default)
    {
        var req = await _store.RequestAsync(requestId, ct);
        if (req is null) return (false, null);

        var visiblePeople = await _peopleScope.VisibleIdsAsync(ctx, ct);
        if (visiblePeople is not null && !visiblePeople.Contains(req.RequesterId)) return (false, null);

        var instance = await _store.InstanceForRequestAsync(requestId, ct);
        return (true, instance is null ? null : await ToInstanceDtoAsync(instance, ct));
    }

    private async Task<ApprovalChainInstanceDto> ToInstanceDtoAsync(ApprovalChainInstance instance, CancellationToken ct)
    {
        var chain = await _store.GetAsync(instance.ChainId, ct);
        var totalSteps = chain?.Steps.Count ?? instance.CurrentStep;

        // Compat/slice-17 follow-up — the CURRENT step's resolved approver(s),
        // so a client can say "Waiting on Sara Ahmed" instead of a generic
        // fallback. Only meaningful while the instance is still pending; a
        // terminal instance has nobody currently waited on.
        var currentApproverIds = new List<Guid>();
        if (instance.Status == ApprovalChainInstanceStatus.Pending && chain is not null)
        {
            var currentStep = chain.Steps.FirstOrDefault(s => s.Order == instance.CurrentStep);
            if (currentStep is not null)
            {
                var req = await _store.RequestAsync(instance.ApprovalRequestId, ct);
                var lead = req is not null ? await _store.LeadAsync(req.LeadId, ct) : null;
                currentApproverIds = await ResolveApproverIdsAsync(currentStep, lead, req?.RequesterId, ct);
            }
        }

        var personIds = instance.Decisions.SelectMany(d => new[] { d.DecidedById, d.DelegatedFromId })
            .Where(id => id.HasValue).Select(id => id!.Value)
            .Concat(currentApproverIds)
            .Distinct().ToList();
        var names = personIds.Count == 0 ? new() : await _store.ProfileNamesAsync(personIds, ct);
        var decisions = instance.Decisions.OrderBy(d => d.Step).Select(d => new ApprovalChainStepDecisionDto(
            d.Step, d.DecidedById, names.GetValueOrDefault(d.DecidedById),
            d.DelegatedFromId, d.DelegatedFromId is Guid df ? names.GetValueOrDefault(df) : null,
            d.Decision, d.Note, d.DecidedAt)).ToList();
        var currentApproverNames = currentApproverIds.Select(id => names.GetValueOrDefault(id) ?? "Unknown").ToList();
        return new ApprovalChainInstanceDto(
            instance.Id, instance.ChainId, chain?.Name ?? "", instance.ApprovalRequestId,
            instance.CurrentStep, totalSteps, instance.Status, instance.CreatedAt, instance.CompletedAt, decisions,
            currentApproverIds, currentApproverNames);
    }

    // ---- Runtime: per-step decision --------------------------------------

    public sealed record StepDecisionOutcome(
        Refusal? Refusal, ApprovalChainInstanceDto? Instance,
        // Null while the chain is still pending a further step; true/false once
        // the chain reaches a final outcome — the caller (ApprovalChainsController)
        // then applies it via ApprovalProcess.ApplyChainOutcomeAsync.
        bool? FinalApproved, Guid DeciderId = default, string? Note = null);

    /// <summary>
    /// Decides the CURRENT step of a pending instance.
    ///
    /// DELEGATION (E2.0 decision 14, design §8) IS REFUSED IN THIS SLICE.
    /// Coordinator review (2026-09-27) of the first version of this method
    /// found a real approval bypass: it let ANY caller claim
    /// <c>input.DelegatedFromId = &lt;a valid step approver&gt;</c> and decide
    /// in their place, because no delegation-roster table exists anywhere in
    /// this codebase to check who may actually stand in for whom — "decides
    /// as themselves, with provenance" only holds if something has already
    /// authorized the stand-in, and nothing does yet. Until that roster is
    /// built (design §8's own deferral to client slice 17, "who's next"/
    /// delegation UI), a decide call carrying <c>DelegatedFromId</c> is
    /// refused outright (403, <c>Code = "delegation_not_configured"</c>) —
    /// only the step's OWN resolved approver(s) may decide. The column stays
    /// on <see cref="ApprovalChainStepDecision.DelegatedFromId"/> for that
    /// future roster to write into; nothing here reads it as authorization.
    /// </summary>
    public async Task<StepDecisionOutcome> DecideStepAsync(
        Guid instanceId, ApprovalChainStepDecisionInput input, Guid deciderId,
        RecordAccessContext ctx, CancellationToken ct = default, bool? holdsApprovePartnerPayouts = null)
    {
        if (input.DelegatedFromId is not null)
            return new StepDecisionOutcome(new Refusal(
                "Delegated decisions aren't supported yet — the named approver must decide this step themselves.",
                Forbidden: true, Code: "delegation_not_configured"), null, null);

        var instance = await _store.GetInstanceAsync(instanceId, ct);
        if (instance is null) return new StepDecisionOutcome(new Refusal("Approval chain instance not found.", NotFound: true), null, null);
        if (instance.Status != ApprovalChainInstanceStatus.Pending)
            return new StepDecisionOutcome(new Refusal("This request has already been decided.", Conflict: true), null, null);

        var req = await _store.RequestAsync(instance.ApprovalRequestId, ct);
        if (req is null) return new StepDecisionOutcome(new Refusal("The underlying request no longer exists.", Conflict: true), null, null);

        // Channel partners (owner Q13): a payout's approval needs the approve-payouts permission, and the person who PREPARED the payout can never
        // approve it - whatever the org's self-decision policy says (the policy is about the requester; this is about segregation of duties).
        // F8 (owner 2026-10-19): the one exception - when the preparer is the ONLY person who can decide this step (a sole org admin), they may approve their own, and a note
        // saying so is recorded on the approval. If anyone else is eligible for the step, the rule stands.
        var soleApproverNote = (string?)null;
        if (req.Type is ApprovalTypes.PartnerPayout or ApprovalTypes.PartnerAdjustment)
        {
            var isPayout = req.Type == ApprovalTypes.PartnerPayout;
            if (holdsApprovePartnerPayouts != true)
                return new StepDecisionOutcome(new Refusal(isPayout ? "Your role cannot approve partner payouts." : "Your role cannot approve partner ledger adjustments.", Forbidden: true, Code: "partner_payout_permission"), null, null);
            var preparer = req.RecordId is Guid recordId
                ? (isPayout ? await _store.PayoutPreparerAsync(recordId, ct) : await _store.AdjustmentRequesterAsync(recordId, ct))
                : null;
            if (preparer == deciderId)
            {
                var currentStep = (await _store.StepsForChainAsync(instance.ChainId, ct)).FirstOrDefault(s => s.Order == instance.CurrentStep);
                var eligible = currentStep is null ? [] : await ResolveApproverIdsAsync(currentStep, null, req.RequesterId, ct);
                if (eligible.Any(id => id != deciderId))
                    return new StepDecisionOutcome(new Refusal(
                        $"You prepared this {(isPayout ? "payout" : "adjustment")}, so you can't approve it. Another approver must decide it.", Forbidden: true, Code: "partner_payout_preparer"), null, null);
                soleApproverNote = "Approved by the person who prepared it: no other eligible approver exists for this step.";
            }
        }

        // E0.1 #1 — team scope, per step: same predicate ApprovalProcess.DecideAsync
        // applies to the whole request.
        var visiblePeople = await _peopleScope.VisibleIdsAsync(ctx, ct);
        if (visiblePeople is not null && !visiblePeople.Contains(req.RequesterId))
            return new StepDecisionOutcome(new Refusal("Approval chain instance not found.", NotFound: true), null, null);

        // E0.1 #2 — self-decision, per step. Read here (Process already holds
        // AppDbContext, the same documented exemption as ApprovalProcess's own
        // _db field) rather than passed in from the controller, so
        // ApprovalChainsController never needs one of its own — see
        // ControllerDependencyTests' "this list must only shrink" ratchet.
        var selfDecisionPolicy = await _gateEscalation.GetSelfDecisionPolicyAsync(ct);
        if (soleApproverNote is null && !GateEscalationSettingsService.CanSelfDecide(selfDecisionPolicy, deciderId, req.RequesterId))
            return new StepDecisionOutcome(new Refusal(
                "You can't decide your own request. Another manager or an org admin must decide it.", Forbidden: true), null, null);

        var steps = await _store.StepsForChainAsync(instance.ChainId, ct);
        var step = steps.FirstOrDefault(s => s.Order == instance.CurrentStep);
        if (step is null) return new StepDecisionOutcome(new Refusal("This chain has no step at the current position.", Conflict: true), null, null);

        var lead = await _store.LeadAsync(req.LeadId, ct);
        var approverIds = await ResolveApproverIdsAsync(step, lead, req.RequesterId, ct);

        // Requester-cannot-decide-own-step (design §9, extended to chains) is
        // already covered by the self-decision check above when decider==requester;
        // this is the SEPARATE "are you even this step's approver" check. No
        // delegation substitution here (see this method's own class comment) —
        // the ACTUAL caller must be a resolved approver, full stop.
        if (!approverIds.Contains(deciderId))
            return new StepDecisionOutcome(new Refusal("You are not the approver for this step.", Forbidden: true), null, null);

        var approve = input.Approve == true;
        var note = soleApproverNote is null ? input.Note : string.IsNullOrWhiteSpace(input.Note) ? soleApproverNote : $"{input.Note.Trim()} - {soleApproverNote}";
        var applied = await ApplyStepDecisionAsync(instance, steps, step, approve, note, deciderId, req, lead, ct);
        if (applied.Raced)
            return new StepDecisionOutcome(new Refusal(
                "Someone else just decided this step first. Refresh to see the outcome.", Conflict: true), null, null);
        return new StepDecisionOutcome(null, await ToInstanceDtoAsync(instance, ct), applied.FinalApproved, deciderId, note);
    }

    /// <summary>Outcome of <see cref="ApplyStepDecisionAsync"/> — <see
    /// cref="Raced"/> true means a CONCURRENT decide on the same step won the
    /// race (see <see cref="ApprovalChainInstance"/>'s own class comment on
    /// the concurrency-token pair that catches this); <see cref="FinalApproved"/>
    /// is meaningless when <see cref="Raced"/> is true.</summary>
    private readonly record struct StepApplyResult(bool? FinalApproved, bool Raced);

    /// <summary>
    /// The mutation a step decision performs once every governance/approver
    /// check has already passed — shared by <see cref="DecideStepAsync"/> (the
    /// chain card's own decide endpoint) and <see
    /// cref="DecideCurrentStepForLegacyEndpointAsync"/> (compat/slice-17
    /// follow-up: the OLD <c>POST /approvals/{id}/decide</c> endpoint, routed
    /// here for a caller who turns out to be the current step's resolved
    /// approver). Records the decision, advances or finalises the instance,
    /// notifies the next step's approver(s), and saves — identical either way,
    /// so the two entry points can never drift on what deciding a step DOES.
    ///
    /// RACE GUARD (design §17 item 12): an <c>any_of_users</c> step's whole
    /// group can call this for the SAME instance at nearly the same moment —
    /// e.g. through <see cref="DecideStepAsync"/> and
    /// <see cref="DecideCurrentStepForLegacyEndpointAsync"/> at once, one per
    /// member. Both read the instance with the SAME original
    /// <see cref="ApprovalChainInstance.CurrentStep"/>/<see
    /// cref="ApprovalChainInstance.Status"/> values (both concurrency tokens —
    /// see that class's own comment); only the first write can still find
    /// them unchanged, so the second throws
    /// <see cref="DbUpdateConcurrencyException"/>, caught here and reported as
    /// <see cref="StepApplyResult.Raced"/> rather than a 500 — a clean "someone
    /// else got there first", not a silent double-decision.
    ///
    /// ONE TRANSACTION, TWO SAVES (coordinator review, 2026-09-27): the
    /// compare-and-set on the instance and the <see
    /// cref="ApprovalChainStepDecision"/> insert happen in SEPARATE
    /// <c>SaveChangesAsync</c> calls (so a losing decide's SaveChanges never
    /// even attempts the decision insert — see the loser's own early return
    /// below), but wrapped in ONE explicit transaction so the WINNER'S two
    /// writes commit or roll back TOGETHER. Without this, a process crash (or
    /// any failure) between the two saves would leave an instance that has
    /// already advanced/settled with NO decision row recording who decided it
    /// — an approval with no record of who approved it. <see
    /// cref="DecideStepAsync"/> and <see
    /// cref="DecideCurrentStepForLegacyEndpointAsync"/> are this method's only
    /// two callers and NEITHER opens a transaction of its own, but <see
    /// cref="Microsoft.EntityFrameworkCore.DatabaseFacade.CurrentTransaction"/>
    /// is checked rather than assumed, so a future caller running inside its
    /// own transaction (e.g. a domain-event handler's per-pass transaction —
    /// see <c>DomainEventDispatchService.DrainHandlerAsync</c>'s identical
    /// check) is joined instead of nested. The InMemory provider (this
    /// class's own unit tests) ignores transactions entirely — the earlier,
    /// untransacted version of this split already relied on
    /// <c>ConfigureWarnings(...InMemoryEventId.TransactionIgnoredWarning)</c>
    /// for that reason, so the concurrency unit tests are unaffected.
    /// </summary>
    private async Task<StepApplyResult> ApplyStepDecisionAsync(
        ApprovalChainInstance instance, List<ApprovalChainStep> steps, ApprovalChainStep step,
        bool approve, string? note, Guid deciderId, ApprovalRequest req, Lead? lead, CancellationToken ct)
    {
        bool? finalApproved = null;
        // Owner decision 34 (sensitive-data design): when the decider is ALSO an eligible approver of the next
        // step, that step is recorded as decided by them too ("same approver as step N"), repeating while it
        // holds. Approvals only - a refusal ends the chain at once. This is the one place steps advance.
        var carried = new List<ApprovalChainStep>();
        var lastDecided = step;
        if (approve)
        {
            var maxOrder = steps.Max(s => s.Order);
            while (lastDecided.Order < maxOrder)
            {
                var next = steps.First(s => s.Order == lastDecided.Order + 1);
                var nextApprovers = await ResolveApproverIdsAsync(next, lead, req.RequesterId, ct);
                if (!nextApprovers.Contains(deciderId)) break;
                carried.Add(next);
                lastDecided = next;
            }
        }
        if (!approve)
        {
            instance.Status = ApprovalChainInstanceStatus.Rejected;
            instance.CompletedAt = DateTime.UtcNow;
            finalApproved = false;
        }
        else if (lastDecided.Order >= steps.Max(s => s.Order))
        {
            instance.Status = ApprovalChainInstanceStatus.Approved;
            instance.CompletedAt = DateTime.UtcNow;
            finalApproved = true;
        }
        else
        {
            instance.CurrentStep = lastDecided.Order + 1;
        }

        // Join an ambient transaction if one is already open on this call
        // path (none of today's callers open one — see this method's own
        // comment); otherwise own a new one so the two saves below commit or
        // roll back as a single unit.
        var ownTransaction = _db.Database.CurrentTransaction is null;
        IDbContextTransaction? tx = ownTransaction ? await _db.Database.BeginTransactionAsync(ct) : null;
        try
        {
            // The concurrency-guarded compare-and-set happens ALONE in this
            // first SaveChangesAsync — no decision row queued alongside it
            // yet, so a LOSING decide's failed conditional UPDATE never even
            // attempts the decision insert (nothing to roll back, and nothing
            // for the transaction below to need to).
            try
            {
                await _store.SaveChangesAsync(ct);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (tx is not null) await tx.RollbackAsync(ct);
                return new StepApplyResult(null, Raced: true);
            }

            var decision = new ApprovalChainStepDecision
            {
                Id = Guid.NewGuid(),
                InstanceId = instance.Id,
                Step = step.Order,
                DecidedById = deciderId,
                // Always null in this slice — see DecideStepAsync's own comment on
                // the DelegatedFromId refusal. Column kept for the future
                // delegation-roster feature.
                DelegatedFromId = null,
                Decision = approve ? "approved" : "rejected",
                Note = note,
            };
            // Added to the DbSet only, not also to instance.Decisions — instance
            // is a TRACKED entity (loaded with .Include(i => i.Decisions)), so
            // appending to both the DbSet and the already-tracked navigation
            // collection double-inserted this row on SaveChanges the first time
            // this was written.
            _store.AddDecision(decision);
            foreach (var c in carried)
                _store.AddDecision(new ApprovalChainStepDecision
                {
                    Id = Guid.NewGuid(),
                    InstanceId = instance.Id,
                    Step = c.Order,
                    DecidedById = deciderId,
                    DelegatedFromId = null,
                    Decision = "approved",
                    Note = $"same approver as step {c.Order - 1}",
                });
            await _store.SaveChangesAsync(ct);

            if (tx is not null) await tx.CommitAsync(ct);
        }
        finally
        {
            if (tx is not null) await tx.DisposeAsync();
        }

        if (finalApproved is null)
        {
            var nextStep = steps.First(s => s.Order == instance.CurrentStep);
            await NotifyStepApproverAsync(nextStep, req, lead, ct);
        }

        return new StepApplyResult(finalApproved, Raced: false);
    }

    // ---- Compat: routing the OLD /approvals/{id}/decide endpoint ------------

    /// <summary>
    /// Outcome of trying to decide a chain-governed request's CURRENT step
    /// through the OLD, pre-chain <c>POST /approvals/{id}/decide</c> endpoint
    /// — compat/slice-17 follow-up so an installed phone build (which only
    /// ever calls that endpoint, never the chain-card's own decide call) keeps
    /// working for a request a chain now governs, with no app update needed.
    ///
    /// Deliberately a plain value record, not a wrapper around
    /// <see cref="ApprovalChainInstance"/> — <see
    /// cref="ProcessLayer.Approvals.ApprovalProcess"/> only needs "did this
    /// decide, and if so is the whole request now finished", never the
    /// instance's own shape, and returning the entity would leak a System
    /// type across a Process/Process call for no reason.
    /// </summary>
    internal sealed record LegacyDecideOutcome(
        string? ConflictMessage, string? WaitingOnMessage, bool? FinalApproved)
    {
        public static LegacyDecideOutcome Conflict(string message) => new(message, null, null);
        public static LegacyDecideOutcome NotApprover(string message) => new(null, message, null);
        // FinalApproved is null while the chain is still pending after this
        // decision (a non-final step advanced) — the underlying request
        // stays "pending" either way, same as DecideStepAsync's own outcome.
        public static LegacyDecideOutcome Ok(bool? finalApproved) => new(null, null, finalApproved);
    }

    /// <summary>
    /// Called from <see cref="ProcessLayer.Approvals.ApprovalProcess.DecideAsync"/>
    /// once it finds an ACTIVE chain instance governing <paramref name="req"/>
    /// — <paramref name="req"/>'s own team-scope and self-decision checks have
    /// ALREADY passed by then (the same E0.1 gates this method would otherwise
    /// re-apply), so this only resolves the current step's approver(s) and,
    /// if <paramref name="deciderId"/> is one of them, decides it through the
    /// SAME mutation <see cref="DecideStepAsync"/> uses. A caller who is NOT
    /// the current step's approver is refused with a plain message naming who
    /// the request is waiting on — <c>ApprovalProcess.DecideAsync</c> wraps
    /// this 403, keeping the WIRE code <c>governed_by_chain</c> so the
    /// desktop's existing defensive handling (a card that raced a chain
    /// appearing after its own "no chain" read) still recognises it.
    ///
    /// No delegation input exists on the legacy endpoint's
    /// <c>ApprovalDecisionInput</c> — there is nothing to refuse there, unlike
    /// <see cref="DecideStepAsync"/>.
    /// </summary>
    internal async Task<LegacyDecideOutcome> DecideCurrentStepForLegacyEndpointAsync(
        ApprovalRequest req, Guid deciderId, bool approve, string? note, CancellationToken ct = default)
    {
        var instance = await _store.InstanceForRequestAsync(req.Id, ct);
        if (instance is null || instance.Status != ApprovalChainInstanceStatus.Pending)
            return LegacyDecideOutcome.Conflict(
                "This request is no longer governed by an active approval chain step. Refresh and try again.");

        var steps = await _store.StepsForChainAsync(instance.ChainId, ct);
        var step = steps.FirstOrDefault(s => s.Order == instance.CurrentStep);
        if (step is null)
            return LegacyDecideOutcome.Conflict("This chain has no step at the current position.");

        var lead = await _store.LeadAsync(req.LeadId, ct);
        var approverIds = await ResolveApproverIdsAsync(step, lead, req.RequesterId, ct);

        if (!approverIds.Contains(deciderId))
        {
            var names = approverIds.Count == 0 ? new() : await _store.ProfileNamesAsync(approverIds, ct);
            var waitingOn = approverIds.Count == 0
                ? "an approver this step has none configured for"
                : string.Join(" or ", approverIds.Select(id => names.GetValueOrDefault(id) ?? "someone"));
            return LegacyDecideOutcome.NotApprover($"Waiting on {waitingOn} (step {step.Order} of {steps.Count}).");
        }

        var applied = await ApplyStepDecisionAsync(instance, steps, step, approve, note, deciderId, req, lead, ct);
        if (applied.Raced)
            return LegacyDecideOutcome.Conflict("Someone else just decided this step first. Refresh to see the outcome.");
        return LegacyDecideOutcome.Ok(applied.FinalApproved);
    }

    /// <summary>
    /// The count of pending requests, among <paramref name="requesterIds"/>'s
    /// scope, that are governed by an ACTIVE chain instance AND currently
    /// waiting on <paramref name="deciderId"/> specifically — the chain half
    /// of <see cref="ProcessLayer.Approvals.ApprovalProcess.PendingCountAsync"/>'s
    /// split count (E2.6 + E0.1). <see
    /// cref="SystemLayer.Approvals.ApprovalStore.PendingCountAsync"/> excludes
    /// every chain-governed row from the OTHER half, so nothing here is
    /// double-counted there.
    /// </summary>
    internal async Task<int> PendingCountForApproverAsync(
        List<Guid>? requesterIds, Guid deciderId, Guid? excludeRequesterId, CancellationToken ct = default)
    {
        var rows = await _store.PendingChainGovernedAsync(requesterIds, ct);
        if (rows.Count == 0) return 0;

        var leadIds = rows.Select(r => r.Request.LeadId).Distinct().ToList();
        var leads = await _store.LeadsByIdsAsync(leadIds, ct);
        var stepsByChain = new Dictionary<Guid, List<ApprovalChainStep>>();

        var count = 0;
        foreach (var (request, instance) in rows)
        {
            if (excludeRequesterId is Guid me && request.RequesterId == me) continue;
            if (!stepsByChain.TryGetValue(instance.ChainId, out var steps))
                stepsByChain[instance.ChainId] = steps = await _store.StepsForChainAsync(instance.ChainId, ct);
            var step = steps.FirstOrDefault(s => s.Order == instance.CurrentStep);
            if (step is null) continue;
            var lead = leads.GetValueOrDefault(request.LeadId);
            var approverIds = await ResolveApproverIdsAsync(step, lead, request.RequesterId, ct);
            if (approverIds.Contains(deciderId)) count++;
        }
        return count;
    }

    /// <summary>The people who may decide <paramref name="step"/> — see
    /// <see cref="ApprovalChainStore.ResolveApproverIdsAsync"/> (moved there so
    /// a Process reader that needs no notification dependency, like
    /// <c>NeedsYouTodayProcess</c>, can resolve it too).</summary>
    private Task<List<Guid>> ResolveApproverIdsAsync(ApprovalChainStep step, Lead? lead, Guid? requesterId, CancellationToken ct) =>
        _store.ResolveApproverIdsAsync(step, lead, requesterId, ct);

    /// <summary>Notifies a step's approver(s) the same way a pending approval
    /// notifies today (<c>NotificationDomainEventHandler.HandleApprovalRequestedAsync</c>'s
    /// shape) — reuses <c>NotificationEvents.Keys.ApprovalRequested</c> rather
    /// than declaring a new event type, since this IS the same fact ("you have
    /// an approval waiting on you"), just narrowed to the chain's own
    /// resolved approver instead of the org's whole decider population. Called
    /// synchronously (not via the async domain-event dispatch worker other
    /// approval notifications now use) because chain step advance is not
    /// itself a call site any domain-event handler currently reacts to, and
    /// adding one is more machinery than this slice's notification
    /// requirement needs — see the story report.</summary>
    private async Task NotifyStepApproverAsync(ApprovalChainStep step, ApprovalRequest req, Lead? lead, CancellationToken ct)
    {
        var approverIds = await ResolveApproverIdsAsync(step, lead, req.RequesterId, ct);
        var recipients = approverIds.Where(id => id != req.RequesterId).ToList();
        if (recipients.Count == 0) return;

        var requesterName = await _store.ProfileFullNameAsync(req.RequesterId, ct) ?? "A rep";
        if (req.Type == ApprovalTypes.Reveal)
        {
            // E12.5: no lead to link to and never a value. The approver opens GET /reveal-requests to decide.
            await _notify.NotifyAsync(new NotifyRequest(
                recipients, NotificationEvents.Keys.ApprovalRequested,
                $"{requesterName} asked to reveal {SensitiveCategories.Label(req.Category ?? "").ToLowerInvariant()} (step {step.Order})",
                $"On a {req.RecordType} record — {req.Reason ?? "no reason given"}")
            {
                InvolvedUserIds = recipients,
            }, ct);
            return;
        }
        var subject = lead is null ? "a lead"
            : string.IsNullOrWhiteSpace(lead.Company) ? lead.Name : $"{lead.Name} · {lead.Company}";

        await _notify.NotifyAsync(new NotifyRequest(
            recipients, NotificationEvents.Keys.ApprovalRequested,
            $"{requesterName} needs a {req.Type} approved (step {step.Order})",
            $"{subject} — {req.Reason ?? "no reason given"}")
        {
            LeadId = req.LeadId,
            TeamId = lead?.TeamId,
            InvolvedUserIds = recipients,
            EmailDetails = req.Amount is decimal amt ? [("Type", req.Type), ("Amount", amt.ToString("0.00"))] : [("Type", req.Type)],
        }, ct);
    }
}

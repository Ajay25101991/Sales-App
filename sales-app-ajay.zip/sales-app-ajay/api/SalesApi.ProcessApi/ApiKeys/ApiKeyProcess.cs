using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.ApiKeys;

namespace SalesApi.ProcessLayer.ApiKeys;

/// <summary>
/// Named, scoped, revocable API keys — a CREDENTIAL, not an ordinary record.
/// Generation, hashing and revocation are moved here EXACTLY as
/// <c>ApiKeysController</c> did them, because this is the one domain in the
/// batch where "tidied while migrating" would be a security regression:
///
/// <list type="bullet">
/// <item>The full key exists in plaintext exactly once, in the response to
/// <see cref="CreateAsync"/> / <see cref="RotateAsync"/> — never re-derivable, never logged, never
/// returned again. Only <c>ApiKeyHasher.Hash</c>'s output and the display
/// prefix are persisted (see that class's own docs for why SHA-256, not
/// bcrypt, is the right primitive for a 256-bit generated secret).</item>
/// <item>Scopes are validated against <see cref="ApiKeyScopes"/> — the ONLY
/// place a scope is declared — so a typo or an unregistered scope is dropped
/// rather than silently persisted as something nothing enforces.</item>
/// <item>Revoke is a soft flag (<c>RevokedAt</c>), never a delete: a revoked
/// key stays visible (greyed out) so "did we already kill this" stays
/// answerable without an audit log, matching the design.</item>
/// <item>Every create / edit / revoke / rotate raises an audit-only domain event (<c>api_key.*</c>: who, when, which key id and
/// name - never key material) in the SAME save as the change.</item>
/// </list>
///
/// Who may call these methods (view/create/revoke) is decided at the
/// controller — <c>ManageSettings</c> — and this layer never widens it: there
/// is no method here that returns a key list, a plaintext key, or a scope
/// catalogue to an unauthenticated or unauthorized caller on its own; the
/// permission gate stays in front of every call.
///
/// THE PLAN GATE (<c>api_webhooks</c>) lives here, not on the controller, because it is not all-or-nothing: managing a key is gated
/// EXCEPT a website lead key - one whose only scope is <c>leads:create</c> - which every plan may create, rotate and edit (website lead
/// capture always works). An attribute cannot see the scopes in the body; this can. Listing and revoking are never gated, so a
/// downgraded org can still see and kill every key it has.
/// </summary>
public sealed class ApiKeyProcess
{
    private readonly ApiKeyStore _store;
    private readonly DomainEventWriter _events;
    public ApiKeyProcess(ApiKeyStore store, DomainEventWriter events)
    {
        _store = store;
        _events = events;
    }

    /// <summary>Why a request could not be carried out, or null when it can. <paramref name="PlanBlocked"/>: the org's plan does not
    /// include the developer API (the controller answers 403 <c>feature_not_in_plan</c>, same shape as <c>[RequirePlanFeature]</c>).</summary>
    public sealed record Refusal(string Reason, bool NotFound = false, bool PlanBlocked = false);

    public sealed record KeyOutcome(Refusal? Refusal, ApiKeyDto? Key)
    {
        public static KeyOutcome Refused(Refusal r) => new(r, null);
        public static KeyOutcome Ok(ApiKeyDto k) => new(null, k);
    }

    public sealed record CreateOutcome(Refusal? Refusal, ApiKeyCreatedDto? Created)
    {
        public static CreateOutcome Refused(Refusal r) => new(r, null);
        public static CreateOutcome Ok(ApiKeyCreatedDto c) => new(null, c);
    }

    public sealed record SettingsOutcome(Refusal? Refusal, ApiKeySettingsDto? Settings)
    {
        public static SettingsOutcome Refused(Refusal r) => new(r, null);
        public static SettingsOutcome Ok(ApiKeySettingsDto s) => new(null, s);
    }

    private static readonly Refusal PlanRefusal = new("The \"api_webhooks\" feature is not included in this organization's plan.", PlanBlocked: true);

    private static List<string> ScopesOf(ApiKey k) =>
        k.Scopes.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();

    private static ApiKeyDto ToDto(ApiKey k) => new(
        k.Id, k.Name, k.DisplayPrefix, ScopesOf(k), k.CreatedAt, k.ExpiresAt, k.LastUsedAt, k.RevokedAt);

    /// <summary>A website lead key: its ONLY scope is <c>leads:create</c>. Never plan-gated.</summary>
    public static bool IsWebsiteLeadKey(IReadOnlyCollection<string> scopes) =>
        scopes.Count == 1 && scopes.First() == ApiKeyScopes.Keys.CreateLeads;

    /// <summary>The registered scope catalogue, for the UI to render checkboxes
    /// against — never free text. No permission check: same as the original
    /// endpoint, this reads no key data, only the static catalogue.</summary>
    public List<ScopeDefDto> Scopes() => [.. ApiKeyScopes.All.Select(d => new ScopeDefDto(d.Key, d.Label))];

    public async Task<List<ApiKeyDto>> ListAsync(CancellationToken ct = default) =>
        [.. (await _store.ListAsync(ct)).Select(ToDto)];

    // ---- org settings ---------------------------------------------------------------------------------------------

    public async Task<ApiKeySettingsDto> GetSettingsAsync(CancellationToken ct = default) =>
        new(await _store.GetDefaultExpiryDaysAsync(), await _store.GetRateLimitPerMinuteAsync(),
            [.. OrgSettings.ApiKeyExpiryChoices], OrgSettings.MinApiKeyRateLimitPerMinute, OrgSettings.MaxApiKeyRateLimitPerMinute);

    /// <summary>PUT: the default lifetime is ALWAYS applied (null = new keys never expire); a null rate limit leaves the stored one alone.</summary>
    public async Task<SettingsOutcome> SetSettingsAsync(int? defaultExpiryDays, int? rateLimitPerMinute, CancellationToken ct = default)
    {
        if (!await _store.PlanAllowsApiAsync(ct)) return SettingsOutcome.Refused(PlanRefusal);
        if (defaultExpiryDays is { } d && !OrgSettings.ApiKeyExpiryChoices.Contains(d))
            return SettingsOutcome.Refused(new Refusal($"default_expiry_days must be {string.Join(", ", OrgSettings.ApiKeyExpiryChoices)}, or null for never."));
        if (rateLimitPerMinute is { } r && (r < OrgSettings.MinApiKeyRateLimitPerMinute || r > OrgSettings.MaxApiKeyRateLimitPerMinute))
            return SettingsOutcome.Refused(new Refusal(
                $"rate_limit_per_minute must be between {OrgSettings.MinApiKeyRateLimitPerMinute} and {OrgSettings.MaxApiKeyRateLimitPerMinute}."));

        await _store.SetDefaultExpiryDaysAsync(defaultExpiryDays);
        if (rateLimitPerMinute is { } limit) await _store.SetRateLimitPerMinuteAsync(limit);
        return SettingsOutcome.Ok(await GetSettingsAsync(ct));
    }

    // ---- keys -----------------------------------------------------------------------------------------------------

    // The full key is returned exactly once, here, and never again.
    public async Task<CreateOutcome> CreateAsync(
        string? name, List<string>? scopes, DateTime? expiresAt, int? expiresInDays, Guid createdById, CancellationToken ct = default)
    {
        var trimmedName = name?.Trim();
        if (string.IsNullOrWhiteSpace(trimmedName))
            return CreateOutcome.Refused(new Refusal("name is required"));

        var parsedScopes = ApiKeyScopes.Parse(scopes);
        if (parsedScopes.Count == 0)
            return CreateOutcome.Refused(new Refusal("At least one valid scope is required."));

        if (!IsWebsiteLeadKey(parsedScopes) && !await _store.PlanAllowsApiAsync(ct))
            return CreateOutcome.Refused(PlanRefusal);

        var now = DateTime.UtcNow;
        var (expiry, expiryProblem) = await ResolveExpiryAsync(expiresAt, expiresInDays, now);
        if (expiryProblem is not null) return CreateOutcome.Refused(expiryProblem);

        var generated = ApiKeyHasher.NewKey();
        var row = NewRow(trimmedName, parsedScopes, generated, createdById, expiry);
        _store.Add(row);
        _events.Raise(DomainEventTypes.Keys.ApiKeyCreated, DomainEventTypes.AggregateTypes.ApiKey, row.Id, createdById,
            new DomainEventPayloads.ApiKeyCreated(row.Id, row.Name, row.Scopes, row.ExpiresAt));
        await _store.SaveChangesAsync(ct);
        return CreateOutcome.Ok(new ApiKeyCreatedDto(ToDto(row), generated.PlaintextKey));
    }

    /// <summary>Id is assigned HERE (not by Postgres on insert) so the audit event raised in the same save can name it.</summary>
    private static ApiKey NewRow(string name, List<string> scopes, ApiKeyHasher.Generated generated, Guid createdById, DateTime? expiresAt) => new()
    {
        Id = Guid.NewGuid(),
        Name = name,
        KeyHash = generated.Hash,
        DisplayPrefix = generated.Prefix,
        Scopes = string.Join(',', scopes),
        CreatedById = createdById,
        ExpiresAt = expiresAt,
    };

    /// <summary>
    /// The new key's expiry. An exact <paramref name="expiresAt"/> must be in the future; <paramref name="expiresInDays"/> is
    /// 30 / 90 / 365, or 0 for never; neither given = the org's default (null = never). Both given is refused rather than guessed at.
    /// </summary>
    private async Task<(DateTime? Expiry, Refusal? Refusal)> ResolveExpiryAsync(DateTime? expiresAt, int? expiresInDays, DateTime now)
    {
        if (expiresAt is not null && expiresInDays is not null)
            return (null, new Refusal("Give expires_in_days or expires_at, not both."));
        if (expiresAt is { } at)
        {
            var utc = at.ToUniversalTime();
            return utc <= now ? (null, new Refusal("expires_at must be in the future.")) : (utc, null);
        }
        if (expiresInDays is { } days)
        {
            if (days == 0) return (null, null);
            return OrgSettings.ApiKeyExpiryChoices.Contains(days)
                ? (now.AddDays(days), null)
                : (null, new Refusal($"expires_in_days must be {string.Join(", ", OrgSettings.ApiKeyExpiryChoices)}, or 0 for never."));
        }
        var orgDefault = await _store.GetDefaultExpiryDaysAsync();
        return (orgDefault is { } d ? now.AddDays(d) : null, null);
    }

    /// <summary>PATCH: rename and/or change scopes of a live (not revoked) key. Expiry is not editable - rotate for a fresh lifetime.</summary>
    public async Task<KeyOutcome> UpdateAsync(Guid id, string? name, List<string>? scopes, Guid actorId, CancellationToken ct = default)
    {
        var row = await _store.GetAsync(id, ct);
        if (row is null) return KeyOutcome.Refused(new Refusal("Key not found", NotFound: true));
        if (row.RevokedAt is not null) return KeyOutcome.Refused(new Refusal("A revoked key cannot be edited."));

        var changed = new List<string>();
        var newName = name?.Trim();
        if (name is not null && string.IsNullOrWhiteSpace(newName))
            return KeyOutcome.Refused(new Refusal("name cannot be blank."));

        List<string>? newScopes = null;
        if (scopes is not null)
        {
            newScopes = ApiKeyScopes.Parse(scopes);
            if (newScopes.Count == 0)
                return KeyOutcome.Refused(new Refusal("At least one valid scope is required."));
        }

        var before = ScopesOf(row);
        var after = newScopes ?? before;
        // Allowed without the feature only when the key is a website lead key before AND after (no escalation off the free path).
        if (!(IsWebsiteLeadKey(before) && IsWebsiteLeadKey(after)) && !await _store.PlanAllowsApiAsync(ct))
            return KeyOutcome.Refused(PlanRefusal);

        if (newName is not null && newName != row.Name) { row.Name = newName; changed.Add("name"); }
        if (newScopes is not null && !newScopes.OrderBy(s => s, StringComparer.Ordinal).SequenceEqual(before.OrderBy(s => s, StringComparer.Ordinal)))
        {
            row.Scopes = string.Join(',', newScopes);
            changed.Add("scopes");
        }

        if (changed.Count > 0)
        {
            _events.Raise(DomainEventTypes.Keys.ApiKeyUpdated, DomainEventTypes.AggregateTypes.ApiKey, row.Id, actorId,
                new DomainEventPayloads.ApiKeyUpdated(row.Id, row.Name, row.Scopes, [.. changed]));
            await _store.SaveChangesAsync(ct);
        }
        return KeyOutcome.Ok(ToDto(row));
    }

    // No DELETE: a revoked key stays in the list (greyed out, revoked_at set)
    // so "did we already kill this" is answerable without digging through an
    // audit log, matching how the design shows a per-row menu action rather
    // than a disappearing row. Never plan-gated: a downgraded org must still be able to kill a key.
    public async Task<KeyOutcome> RevokeAsync(Guid id, Guid actorId, CancellationToken ct = default)
    {
        var row = await _store.GetAsync(id, ct);
        if (row is null) return KeyOutcome.Refused(new Refusal("Key not found", NotFound: true));

        if (row.RevokedAt is null)
        {
            row.RevokedAt = DateTime.UtcNow;
            _events.Raise(DomainEventTypes.Keys.ApiKeyRevoked, DomainEventTypes.AggregateTypes.ApiKey, row.Id, actorId,
                new DomainEventPayloads.ApiKeyRevoked(row.Id, row.Name));
        }
        await _store.SaveChangesAsync(ct);
        return KeyOutcome.Ok(ToDto(row));
    }

    /// <summary>
    /// Rotate: a NEW key with the same name and scopes and the same lifetime the old one was issued for (an old key with no expiry
    /// yields a new one with none), the old key revoked in the same save, and the new plaintext returned exactly once - the same response
    /// as create. A key that has already EXPIRED can be rotated (the common case); a revoked one cannot.
    /// </summary>
    public async Task<CreateOutcome> RotateAsync(Guid id, Guid actorId, CancellationToken ct = default)
    {
        var old = await _store.GetAsync(id, ct);
        if (old is null) return CreateOutcome.Refused(new Refusal("Key not found", NotFound: true));
        if (old.RevokedAt is not null) return CreateOutcome.Refused(new Refusal("A revoked key cannot be rotated. Create a new one."));

        var scopes = ScopesOf(old);
        if (!IsWebsiteLeadKey(scopes) && !await _store.PlanAllowsApiAsync(ct))
            return CreateOutcome.Refused(PlanRefusal);

        var now = DateTime.UtcNow;
        DateTime? expiry = old.ExpiresAt is { } oldExpiry ? now + (oldExpiry - old.CreatedAt) : null;
        var generated = ApiKeyHasher.NewKey();
        var row = NewRow(old.Name, scopes, generated, actorId, expiry);
        _store.Add(row);
        old.RevokedAt = now;
        _events.Raise(DomainEventTypes.Keys.ApiKeyRotated, DomainEventTypes.AggregateTypes.ApiKey, old.Id, actorId,
            new DomainEventPayloads.ApiKeyRotated(old.Id, row.Id, old.Name));
        await _store.SaveChangesAsync(ct);
        return CreateOutcome.Ok(new ApiKeyCreatedDto(ToDto(row), generated.PlaintextKey));
    }
}

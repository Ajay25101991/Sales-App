using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.AiPlatform;

namespace SalesApi.ProcessLayer.AiPlatform;

/// <summary>
/// The E4.4 prompt/skill registry CRUD rules (design doc
/// to-do/e4-ai-platform-design.md §4, §15 slice 6). "Your role cannot manage
/// AI skills" stays on the controller, same split every other AiPlatform
/// Process class in this vertical documents.
/// </summary>
public sealed class AiSkillProcess
{
    private readonly AiSkillStore _store;
    private readonly IAiSkillPublishGate _publishGate;

    public AiSkillProcess(AiSkillStore store, IAiSkillPublishGate publishGate)
    {
        _store = store;
        _publishGate = publishGate;
    }

    public sealed record Refusal(string Reason, bool NotFound = false);

    private static AiSkillVersionDto ToVersionDto(AiSkillVersion v) => new(
        v.Id, v.Version, v.Status, v.OrgId == null, v.TaskClass, v.SystemPromptTemplate, v.OutputSchemaJson,
        v.CreatedAt, v.CreatedById, v.PublishedAt, v.PublishedById);

    public async Task<List<AiSkillSummaryDto>> ListAsync(Guid orgId, CancellationToken ct = default)
    {
        var skills = await _store.ListSkillsAsync(ct);
        var result = new List<AiSkillSummaryDto>();
        foreach (var skill in skills)
        {
            var platformLive = await _store.PlatformLiveAsync(skill.Id, ct);
            var orgLive = await _store.OrgLiveAsync(skill.Id, orgId, ct);
            var orgDraft = await _store.OrgDraftAsync(skill.Id, orgId, ct);
            result.Add(new AiSkillSummaryDto(
                skill.Id, skill.Key, skill.Name, skill.IsBuiltIn,
                platformLive?.Version ?? 0, orgLive?.Version, orgDraft?.Version, orgLive is not null));
        }
        return result;
    }

    public async Task<(List<AiSkillVersionDto>? Versions, Refusal? Refusal)> VersionsAsync(
        Guid skillId, Guid orgId, CancellationToken ct = default)
    {
        var skill = await _store.GetSkillByIdAsync(skillId, ct);
        if (skill is null) return (null, new Refusal("AI skill not found.", NotFound: true));

        var versions = await _store.VersionsVisibleToOrgAsync(skillId, orgId, ct);
        return ([.. versions.Select(ToVersionDto)], null);
    }

    /// <summary>The resolver design §4 asks for: "the effective prompt for
    /// skill X in org Y" — org's live override if it has one, else the
    /// platform default. No model call anywhere in this slice; this only
    /// resolves WHICH prompt text a future gateway call would use.</summary>
    public async Task<(AiSkillEffectivePromptDto? Result, Refusal? Refusal)> EffectivePromptAsync(
        string skillKey, Guid orgId, CancellationToken ct = default)
    {
        var version = await _store.ResolveEffectiveAsync(skillKey, orgId, ct);
        if (version is null) return (null, new Refusal($"Unknown AI skill '{skillKey}'.", NotFound: true));
        return (new AiSkillEffectivePromptDto(
            skillKey, version.Version, version.OrgId is not null, version.TaskClass,
            version.SystemPromptTemplate, version.OutputSchemaJson), null);
    }

    public async Task<(AiSkillDraftResultDto? Result, Refusal? Refusal)> SaveDraftAsync(
        Guid skillId, Guid orgId, AiSkillDraftInput input, Guid userId, CancellationToken ct = default)
    {
        var skill = await _store.GetSkillByIdAsync(skillId, ct);
        if (skill is null) return (null, new Refusal("AI skill not found.", NotFound: true));

        var taskClass = input.TaskClass;
        if (taskClass is null)
        {
            // Inherit from whatever the org currently runs (its own draft/live,
            // else the platform default) so editing only the prompt text never
            // silently changes what task class the skill invokes.
            var current = await _store.OrgDraftAsync(skillId, orgId, ct)
                          ?? await _store.OrgLiveAsync(skillId, orgId, ct)
                          ?? await _store.PlatformLiveAsync(skillId, ct);
            taskClass = current?.TaskClass ?? AiSkillTaskClasses.Complete;
        }
        if (!AiSkillTaskClasses.IsValid(taskClass))
            return (null, new Refusal($"Task class must be one of: {string.Join(", ", AiSkillTaskClasses.All)}."));

        var draft = await _store.SaveOrgDraftAsync(
            skillId, orgId, input.SystemPromptTemplate ?? "", input.OutputSchemaJson, taskClass, userId, ct);
        return (new AiSkillDraftResultDto(draft.Id, draft.Version, draft.Status), null);
    }

    public async Task<(AiSkillPublishResultDto? Result, Refusal? Refusal)> PublishAsync(
        Guid skillId, Guid orgId, Guid userId, CancellationToken ct = default)
    {
        var skill = await _store.GetSkillByIdAsync(skillId, ct);
        if (skill is null) return (null, new Refusal("AI skill not found.", NotFound: true));

        var draft = await _store.OrgDraftAsync(skillId, orgId, ct);
        if (draft is null) return (null, new Refusal("This skill has no draft to publish."));
        if (string.IsNullOrWhiteSpace(draft.SystemPromptTemplate))
            return (null, new Refusal("A skill's prompt cannot be published empty."));

        var previousLive = await _store.OrgLiveAsync(skillId, orgId, ct);
        var gateResult = await _publishGate.CheckAsync(draft, previousLive, ct);
        if (gateResult.Blocked)
            return (null, new Refusal(gateResult.Reason ?? "This version regresses its evaluation set."));

        var published = await _store.PublishOrgDraftAsync(skillId, orgId, draft, userId, ct);
        return (new AiSkillPublishResultDto(published.Id, published.Version, published.Status, published.PublishedAt, gateResult.CaseResults), null);
    }

    /// <summary>
    /// Rollback (design §15 slice 6's own "publish/rollback") — re-publishes
    /// an earlier version's content as a NEW org-owned version, mirroring
    /// <c>LeadFormService.RollbackAsync</c>'s own "re-publish an earlier
    /// version's schema as a new version" shape. The target may be the org's
    /// own past version OR a published platform version (adopting the
    /// platform's wording as the org's own starting point) — never a platform
    /// DRAFT, which <see cref="AiSkillStore.VisibleVersionByIdAsync"/> already
    /// excludes.
    /// </summary>
    public async Task<(AiSkillPublishResultDto? Result, Refusal? Refusal)> RollbackAsync(
        Guid skillId, Guid orgId, Guid targetVersionId, Guid userId, CancellationToken ct = default)
    {
        var skill = await _store.GetSkillByIdAsync(skillId, ct);
        if (skill is null) return (null, new Refusal("AI skill not found.", NotFound: true));

        var target = await _store.VisibleVersionByIdAsync(skillId, targetVersionId, orgId, ct);
        if (target is null) return (null, new Refusal("That version was not found.", NotFound: true));

        var draft = await _store.SaveOrgDraftAsync(
            skillId, orgId, target.SystemPromptTemplate, target.OutputSchemaJson, target.TaskClass, userId, ct);

        var previousLive = await _store.OrgLiveAsync(skillId, orgId, ct);
        var gateResult = await _publishGate.CheckAsync(draft, previousLive, ct);
        if (gateResult.Blocked)
            return (null, new Refusal(gateResult.Reason ?? "This version regresses its evaluation set."));

        var published = await _store.PublishOrgDraftAsync(skillId, orgId, draft, userId, ct);
        return (new AiSkillPublishResultDto(published.Id, published.Version, published.Status, published.PublishedAt, gateResult.CaseResults), null);
    }
}

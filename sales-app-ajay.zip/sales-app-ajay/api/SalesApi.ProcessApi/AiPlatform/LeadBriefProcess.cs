using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Leads;
using SalesApi.Services;
using SalesApi.SystemLayer.AiPlatform;

namespace SalesApi.ProcessLayer.AiPlatform;

/// <summary>
/// E5.1 — the deal/account brief (to-do/epics-ai-native-crm.md E5.1 row;
/// design doc to-do/e4-ai-platform-design.md §5/§10/§17-18). Orchestrates:
/// availability (E4.3's two-gate check), the SAME governed lead read/timeline
/// read the detail screen itself uses (masking never re-derived here, per
/// root CLAUDE.md and <see cref="AiContextEngine"/>'s own class doc), the
/// E4.5 context engine, the E4.4 effective-prompt resolver, a call to the
/// resolved gateway's <c>ExtractAsync</c>, and the per-(lead,user) cache.
///
/// "AI not available" is the ONLY refusal shape that is not a
/// <see cref="Refusal"/> — the owner decision (E5 build decisions
/// 2026-09-28: "AI-off hides E5 entirely") is that an unavailable org gets
/// <see cref="LeadBriefDto.Unavailable"/> back as a 200, not a 403/503; a
/// <see cref="Refusal"/> is reserved for "you may not see this LEAD" (record
/// access), which is a different, always-true-regardless-of-AI question.
/// </summary>
public sealed class LeadBriefProcess
{
    private readonly LeadReadProcess _leads;
    private readonly IAiContextEngine _contextEngine;
    private readonly AiSkillStore _skills;
    private readonly AiAvailability _availability;
    private readonly AiProviderResolver _resolver;
    private readonly LeadBriefStore _briefs;

    public LeadBriefProcess(
        LeadReadProcess leads, IAiContextEngine contextEngine, AiSkillStore skills,
        AiAvailability availability, AiProviderResolver resolver, LeadBriefStore briefs)
    {
        _leads = leads;
        _contextEngine = contextEngine;
        _skills = skills;
        _availability = availability;
        _resolver = resolver;
        _briefs = briefs;
    }

    public sealed record Refusal(string Reason, bool NotFound = false, bool Forbidden = false);

    private const string SkillKey = "deal-brief";
    private const string Feature = "deal-brief";

    /// <summary>Same page size <c>AiContextEngine</c> itself asks for — the
    /// pre-check below reads the timeline directly (rather than through the
    /// context engine) specifically so a "too little history" answer never
    /// triggers the context engine's knowledge/embed fan-out, per build item
    /// 2's "without calling the model".</summary>
    private const int TimelinePageSize = 100;

    /// <summary>"Too little context" (build item 2) — fewer than this many
    /// TIMELINE items (never counting the lead's own static field values) is
    /// not enough to brief from. Named rather than a bare literal, per the
    /// story brief's own wording; picked as the smallest count that still
    /// lets a brief say something about MOMENTUM (a single past event has no
    /// direction to compare against).</summary>
    public const int MinTimelineItemsForBrief = 2;

    /// <summary>The context engine's token budget for this skill — matches
    /// the golden-set fixtures' own <c>tokenBudget</c> (AiEvals/deal-brief/cases.json)
    /// so a case that passes evaluation reflects the same budget production
    /// actually renders under.</summary>
    public const int ContextTokenBudget = 4000;

    public Task<(LeadBriefDto? Dto, Refusal? Refusal)> GetAsync(
        RecordAccessContext caller, LeadView view, bool canSeeFinancials, Guid orgId, Guid userId, Guid leadId,
        CancellationToken ct = default) =>
        ResolveAsync(caller, view, canSeeFinancials, orgId, userId, leadId, forceRefresh: false, ct);

    public Task<(LeadBriefDto? Dto, Refusal? Refusal)> RefreshAsync(
        RecordAccessContext caller, LeadView view, bool canSeeFinancials, Guid orgId, Guid userId, Guid leadId,
        CancellationToken ct = default) =>
        ResolveAsync(caller, view, canSeeFinancials, orgId, userId, leadId, forceRefresh: true, ct);

    private async Task<(LeadBriefDto? Dto, Refusal? Refusal)> ResolveAsync(
        RecordAccessContext caller, LeadView view, bool canSeeFinancials, Guid orgId, Guid userId, Guid leadId,
        bool forceRefresh, CancellationToken ct)
    {
        var availability = await _availability.GetAsync(ct);
        if (!availability.Available) return (LeadBriefDto.Unavailable, null);

        // The SAME governed read the detail screen makes — masking is never
        // re-derived here (AiContextEngine's own class doc). A lead the
        // caller cannot see gets the same not-found/forbidden outcome the
        // detail screen would.
        var (leadRefusal, leadDto) = await _leads.GetAsync(caller, view, leadId);
        if (leadRefusal is not null || leadDto is null)
            return (null, new Refusal(
                leadRefusal?.Reason ?? "Lead not found", leadRefusal?.NotFound ?? true, leadRefusal?.Forbidden ?? false));

        var (timelineRefusal, timelinePage) = await _leads.TimelineAsync(
            caller, view, canSeeFinancials, leadId, cursor: null, limit: TimelinePageSize, kinds: null);
        if (timelineRefusal is not null)
            return (null, new Refusal(timelineRefusal.Reason, timelineRefusal.NotFound, timelineRefusal.Forbidden));

        // Build item 2: too little history -> "not_enough_history" WITHOUT
        // calling the model — checked here, before the context engine's own
        // knowledge/embed fan-out ever runs, not just before the Extract call.
        if ((timelinePage?.Items.Count ?? 0) < MinTimelineItemsForBrief)
            return (new LeadBriefDto(true, "not_enough_history", null, null, null, null, null, null, null, null, null), null);

        AiContext context;
        try
        {
            context = await _contextEngine.GetContextAsync(
                caller, view, canSeeFinancials, "lead", leadId, SkillKey, ContextTokenBudget, ct);
        }
        catch (AiContextRefusedException e)
        {
            return (null, new Refusal(e.Message, e.NotFound, e.Forbidden));
        }

        var contextHash = HashContext(context);

        if (!forceRefresh)
        {
            var cached = await _briefs.GetAsync(leadId, userId, ct);
            if (cached is not null && cached.ContextHash == contextHash)
            {
                try
                {
                    var cachedDto = JsonSerializer.Deserialize<LeadBriefDto>(cached.ResultJson);
                    if (cachedDto is not null) return (cachedDto, null);
                }
                catch (JsonException)
                {
                    // Fall through and regenerate — a corrupt cache row is
                    // never a reason to refuse the caller a brief.
                }
            }
        }

        var version = await _skills.ResolveEffectiveAsync(SkillKey, orgId, ct);
        if (version is null)
            return (new LeadBriefDto(
                true, "refused", null, null, null, null, null, null, null,
                "skill_not_configured", "The deal-brief skill is not configured for this deployment."), null);

        var extraValues = new Dictionary<string, string>(StringComparer.Ordinal)
        {
            ["entity_type"] = "lead",
            ["entity_name"] = string.IsNullOrWhiteSpace(leadDto.Name)
                ? (string.IsNullOrWhiteSpace(leadDto.Company) ? "this lead" : leadDto.Company)
                : leadDto.Name,
            ["evidence"] = "the timeline below",
        };
        var render = AiPromptRenderer.Render(version, context, SkillKey, extraValues);

        var resolved = await _resolver.ResolveAsync(ct);
        if (resolved.Status != AiProviderStatus.Ready || resolved.Platform is null)
            return (new LeadBriefDto(
                true, "refused", null, null, null, null, null, null, null,
                "unavailable", resolved.Reason ?? "AI is unavailable right now."), null);

        // RequestId assigned client-side (AiRequest.RequestId's own doc
        // comment) so this process can name the log entry the call writes —
        // on EVERY outcome, ok or refused — without a second lookup query.
        var requestId = Guid.NewGuid();
        var request = new AiRequest(
            orgId, userId, Feature, SkillKey, version.Version, AiTaskClass.Extract,
            render.Messages, Tools: null, MaxOutputTokens: null, Temperature: null, Stream: false,
            Sources: context.Sources, RequestId: requestId);

        AiResponse response;
        try
        {
            response = await resolved.Platform.ExtractAsync(request, new JsonSchema(version.OutputSchemaJson ?? "{}"), ct);
        }
        catch (AiRequestRefusedException e)
        {
            // Never a 500 — the server's own refusal message, verbatim
            // (design §13's "the budget-stop message appears wherever an AI
            // action is refused").
            return (new LeadBriefDto(
                true, "refused", null, null, null, null, null, null, requestId, e.Code, e.Message), null);
        }

        if (!TryParseBriefOutput(
                response.Text ?? "{}", version.OutputSchemaJson, context.Sources,
                out var momentum, out var summary, out var reasons, out var action, out var confidence))
        {
            return (new LeadBriefDto(
                true, "refused", null, null, null, null, null, null, requestId,
                "invalid_output", "The AI response did not match the expected format."), null);
        }

        var generatedAt = DateTime.UtcNow;
        var resultDto = new LeadBriefDto(
            true, "ok", momentum, summary, reasons, action, confidence, generatedAt, requestId, null, null);

        await _briefs.SaveAsync(leadId, userId, JsonSerializer.Serialize(resultDto), requestId, contextHash, ct);
        return (resultDto, null);
    }

    /// <summary>A stable hash of the assembled context's ranked items — the
    /// SAME order <c>AiContextEngine</c> guarantees Items/Sources line up in,
    /// so two builds of the identical context always hash identically. Not a
    /// security boundary, just a cheap "did the underlying record/timeline
    /// change" fingerprint (SHA-256 over kind|source-id|text lines).</summary>
    private static string HashContext(AiContext context)
    {
        var sb = new StringBuilder();
        foreach (var item in context.Items)
            sb.Append(item.Kind).Append('|').Append(item.SourceId).Append('|').Append(item.Text).Append('\n');
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(sb.ToString())));
    }

    /// <summary>
    /// Validates the Extract call's raw output against the version's own
    /// <see cref="AiSkillVersion.OutputSchemaJson"/> (the SAME
    /// <c>MinimalJsonSchemaValidator</c> the golden-set evaluator uses — one
    /// validator, not two), then maps citation markers to resolved evidence
    /// sources. A citation index that does not fall inside
    /// <paramref name="sources"/> is DROPPED from that reason's citation
    /// list, never invented back (build item 2). Returns false for anything
    /// that fails validation or does not parse — the caller turns that into
    /// a "refused: invalid_output" answer rather than a 500.
    /// </summary>
    /// <summary>internal (not private): unit-tested directly against crafted
    /// output JSON and a crafted <paramref name="sources"/> list — see
    /// LeadBriefCitationMappingTests — since exercising the citation-drop
    /// path end to end would need a hand-authored provider double this
    /// process's own <c>AiProviderResolver</c> dependency does not allow
    /// swapping in.</summary>
    internal static bool TryParseBriefOutput(
        string outputJson, string? outputSchemaJson, IReadOnlyList<AiContextSource> sources,
        out string momentum, out string summary, out List<LeadBriefReasonDto> reasons,
        out LeadBriefRecommendedActionDto action, out string confidence)
    {
        momentum = "";
        summary = "";
        confidence = "";
        reasons = new List<LeadBriefReasonDto>();
        action = new LeadBriefRecommendedActionDto("none", "");

        if (string.IsNullOrWhiteSpace(outputSchemaJson)) return false;
        var (valid, _) = MinimalJsonSchemaValidator.Validate(outputSchemaJson, outputJson);
        if (!valid) return false;

        try
        {
            using var doc = JsonDocument.Parse(outputJson);
            var root = doc.RootElement;

            momentum = root.GetProperty("momentum").GetString() ?? "";
            summary = root.GetProperty("summary").GetString() ?? "";
            confidence = root.GetProperty("confidence").GetString() ?? "";

            var actionEl = root.GetProperty("recommended_action");
            action = new LeadBriefRecommendedActionDto(
                actionEl.TryGetProperty("kind", out var kindEl) ? kindEl.GetString() ?? "none" : "none",
                actionEl.TryGetProperty("text", out var textEl) ? textEl.GetString() ?? "" : "");

            foreach (var reasonEl in root.GetProperty("reasons").EnumerateArray())
            {
                var text = reasonEl.TryGetProperty("text", out var t) ? t.GetString() ?? "" : "";
                var citations = new List<LeadBriefEvidenceSourceDto>();
                if (reasonEl.TryGetProperty("citations", out var citationsEl) && citationsEl.ValueKind == JsonValueKind.Array)
                {
                    foreach (var c in citationsEl.EnumerateArray())
                    {
                        if (c.ValueKind != JsonValueKind.Number || !c.TryGetInt32(out var marker)) continue;
                        if (marker < 1 || marker > sources.Count) continue; // unresolved — dropped, never invented
                        var source = sources[marker - 1];
                        citations.Add(new LeadBriefEvidenceSourceDto(source.Kind, source.Id));
                    }
                }
                reasons.Add(new LeadBriefReasonDto(text, citations));
            }
            return true;
        }
        catch (Exception e) when (e is JsonException or InvalidOperationException or KeyNotFoundException)
        {
            return false;
        }
    }
}

using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.SystemLayer.AiPlatform;

namespace SalesApi.ProcessLayer.AiPlatform;

/// <summary>
/// E5's shared AI-feedback frame (design doc to-do/e4-ai-platform-design.md
/// §3's "UserFeedback") and its reject-reason policy (E5.0 design review
/// decision 2: "reject reason is an org setting"). ONE endpoint, used by
/// every E5 AI-output surface (the brief today; drafts/hygiene/risk/etc. as
/// each lands), not duplicated per feature — same "one shared frame" posture
/// the "AI output frame" shared component (to-do/epics-ai-native-crm.md line
/// ~58) takes on the client.
/// </summary>
public sealed class AiFeedbackProcess
{
    private readonly AiExecutionLogStore _log;
    private readonly AiFeedbackSettingsStore _settings;

    public AiFeedbackProcess(AiExecutionLogStore log, AiFeedbackSettingsStore settings)
    {
        _log = log;
        _settings = settings;
    }

    public sealed record Refusal(string Reason, bool NotFound = false, bool Forbidden = false);

    /// <summary>The story brief's own "sensible defaults" — substituted at
    /// READ time when an org has never saved its own chip list (empty
    /// <c>ReasonChipsJson</c>/no row at all), never baked into the row's
    /// column default (see <c>AiFeedbackSetting.ReasonChipsJson</c>'s own
    /// doc comment on why that distinction matters).</summary>
    public static readonly IReadOnlyList<string> DefaultReasonChips = ["Wrong", "Not relevant", "Already done", "Other"];

    public async Task<AiFeedbackSettingsDto> GetSettingsAsync(CancellationToken ct = default)
    {
        var row = await _settings.GetAsync(ct);
        var chips = ParseChips(row?.ReasonChipsJson);
        return new AiFeedbackSettingsDto(
            row?.ReasonPolicy ?? AiFeedbackReasonPolicies.Optional,
            chips.Count > 0 ? chips : DefaultReasonChips);
    }

    public async Task<(AiFeedbackSettingsDto? Dto, Refusal? Refusal)> SaveSettingsAsync(
        AiFeedbackSettingsInput input, Guid actorId, CancellationToken ct = default)
    {
        if (input.ReasonPolicy is not null && !AiFeedbackReasonPolicies.IsValid(input.ReasonPolicy))
            return (null, new Refusal($"Reason policy must be one of: {string.Join(", ", AiFeedbackReasonPolicies.All)}."));
        if (input.ReasonChips is not null && input.ReasonChips.Any(string.IsNullOrWhiteSpace))
            return (null, new Refusal("A reject-reason chip cannot be blank."));

        await _settings.SaveAsync(input.ReasonPolicy, input.ReasonChips, actorId, ct);
        return (await GetSettingsAsync(ct), null);
    }

    /// <summary>
    /// Records one AI-output verdict. Only the user who MADE the logged call
    /// may leave feedback on it (build item 3) — anyone else's attempt is a
    /// Forbidden refusal, same as touching another user's own record would
    /// be anywhere else in this codebase. The reject-reason policy is
    /// enforced ONLY for <see cref="AiFeedbackVerdicts.Rejected"/> — accepting
    /// or editing a suggestion never needs a reason regardless of the org's
    /// policy.
    /// </summary>
    public async Task<(AiFeedbackResultDto? Result, Refusal? Refusal)> SubmitAsync(
        AiFeedbackInput input, Guid callerId, CancellationToken ct = default)
    {
        if (!AiFeedbackVerdicts.IsValid(input.Verdict))
            return (null, new Refusal($"Verdict must be one of: {string.Join(", ", AiFeedbackVerdicts.All)}."));

        var entry = await _log.GetTrackedAsync(input.LogEntryId, ct);
        if (entry is null) return (null, new Refusal("AI log entry not found.", NotFound: true));
        if (entry.UserId != callerId)
            return (null, new Refusal("Only the user who made this call may leave feedback on it.", Forbidden: true));

        if (input.Verdict == AiFeedbackVerdicts.Rejected)
        {
            var settings = await GetSettingsAsync(ct);
            var hasReason = !string.IsNullOrWhiteSpace(input.Reason) || !string.IsNullOrWhiteSpace(input.ReasonChip);
            if (settings.ReasonPolicy == AiFeedbackReasonPolicies.Required && !hasReason)
                return (null, new Refusal("A reason is required when rejecting an AI suggestion."));
        }

        await _log.SetFeedbackAsync(entry, input.Verdict, input.Reason, input.ReasonChip, ct);
        return (new AiFeedbackResultDto(entry.Id, input.Verdict, input.Reason, input.ReasonChip), null);
    }

    private static List<string> ParseChips(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return new List<string>();
        try { return JsonSerializer.Deserialize<List<string>>(json) ?? new List<string>(); }
        catch (JsonException) { return new List<string>(); }
    }
}

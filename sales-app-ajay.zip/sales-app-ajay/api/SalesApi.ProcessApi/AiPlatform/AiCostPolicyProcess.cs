using SalesApi.Dtos;
using SalesApi.Services;
using SalesApi.SystemLayer.AiPlatform;

namespace SalesApi.ProcessLayer.AiPlatform;

/// <summary>
/// The E4.3 cost-policy validation (design doc to-do/e4-ai-platform-design.md
/// §13, §15 slice 5): no negative budget/cap/price. Deliberately does NOT
/// decide who may write — same split <see cref="AiActionPolicyProcess"/>'s
/// own header gives.
/// </summary>
public sealed class AiCostPolicyProcess
{
    private readonly AiCostPolicyStore _store;
    public AiCostPolicyProcess(AiCostPolicyStore store) => _store = store;

    public sealed record Refusal(string Reason);

    public async Task<AiCostPolicyDto> GetAsync(CancellationToken ct = default)
    {
        var row = await _store.GetAsync(ct);
        var spend = await _store.MonthToDateSpendAsync(ct);
        return ToDto(row, spend);
    }

    public async Task<(AiCostPolicyDto? Dto, Refusal? Refusal)> SaveAsync(
        AiCostPolicyInput input, Guid actorId, CancellationToken ct = default)
    {
        if (input.MonthlyBudgetUsd is < 0)
            return (null, new Refusal("Monthly budget cannot be negative."));
        if (input.PerUserMonthlyCapUsd is < 0)
            return (null, new Refusal("Per-user monthly cap cannot be negative."));
        if (input.ModelPrices is not null)
        {
            foreach (var (model, price) in input.ModelPrices)
            {
                if (price.InputPerMillionUsd < 0 || price.OutputPerMillionUsd < 0)
                    return (null, new Refusal($"Price for model \"{model}\" cannot be negative."));
            }
        }

        var features = input.Features is null ? null : new Dictionary<string, bool>(input.Features);
        var prices = input.ModelPrices is null
            ? null
            : input.ModelPrices.ToDictionary(
                kv => kv.Key, kv => new AiModelPrice(kv.Value.InputPerMillionUsd, kv.Value.OutputPerMillionUsd));

        await _store.SaveAsync(input.MonthlyBudgetUsd, input.PerUserMonthlyCapUsd, features, prices, actorId, ct);
        return (await GetAsync(ct), null);
    }

    private static AiCostPolicyDto ToDto(Models.AiCostPolicy? row, decimal monthToDateSpend)
    {
        var features = row is null
            ? new Dictionary<string, bool>()
            : AiCostPolicyJson.ParseFeatures(row.FeaturesJson);
        var prices = row is null
            ? new Dictionary<string, AiModelPriceDto>()
            : AiCostPolicyJson.ParsePrices(row.ModelPricesJson)
                .ToDictionary(kv => kv.Key, kv => new AiModelPriceDto(kv.Value.InputPerMillionUsd, kv.Value.OutputPerMillionUsd));

        return new AiCostPolicyDto(
            row?.MonthlyBudgetUsd, row?.PerUserMonthlyCapUsd, features, prices, monthToDateSpend);
    }
}

using System.Text.Json;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Services;
using SalesApi.SystemLayer.AiPlatform;

namespace SalesApi.ProcessLayer.AiPlatform;

/// <summary>
/// E5.6 deal risk (to-do/epics-ai-native-crm.md E5.6) — the PERMISSION-GATED
/// READ only: GET /leads/{id}/risk (story brief items 6-7). The COMPUTE side
/// (recompute on change / the daily sweep) lives in SystemApi's
/// <see cref="DealRiskComputeService"/> instead, because its callers
/// (<c>DealRiskDomainEventHandler</c>, <c>DealRiskSweepWorker</c>) are both
/// SystemApi classes with no <c>ClaimsPrincipal</c> at all, and SystemApi
/// cannot reference ProcessApi — see that class's own doc comment for the
/// full reasoning (mirrors <c>KnowledgeIngestionService</c>/<c>KnowledgeProcess</c>'s
/// own split).
///
/// Layering round 4 (owner decision 2026-09-30): the one lead lookup behind
/// the RecordAccess.CanView gate now goes through <see cref="LeadRiskStore.LeadForAccessAsync"/>
/// rather than a raw <see cref="AppDbContext"/> field.
///
/// PERMISSION IS THE LEAD'S OWN (story brief item 7): <see cref="GetAsync"/>
/// takes the caller's <see cref="RecordAccessContext"/> and applies the exact
/// same <see cref="RecordAccess.CanView"/> gate <c>LeadReadProcess.GetAsync</c>
/// does, never a bespoke risk-specific check.
/// </summary>
public sealed class DealRiskProcess
{
    private readonly LeadRiskStore _riskStore;
    private readonly AiAvailability _aiAvailability;

    public DealRiskProcess(LeadRiskStore riskStore, AiAvailability aiAvailability)
    {
        _riskStore = riskStore;
        _aiAvailability = aiAvailability;
    }

    public sealed record Refusal(string Reason, bool NotFound = false, bool Forbidden = false);

    public async Task<(Refusal? Refusal, bool Available, DealRiskDto? Dto)> GetAsync(
        RecordAccessContext vis, Guid leadId, CancellationToken ct = default)
    {
        var lead = await _riskStore.LeadForAccessAsync(leadId, ct);
        if (lead is null) return (new Refusal("Lead not found", NotFound: true), false, null);
        if (!RecordAccess.CanView(vis, lead.OwnerId, lead.TeamId))
            return (new Refusal("Not allowed to access this lead", Forbidden: true), false, null);

        // Owner decision (to-do/epics-ai-native-crm.md "E5 build decisions"
        // item 2): "every risk read returns nothing while AI is not
        // configured for the org" — the whole feature, not just the AI-worded
        // half.
        var availability = await _aiAvailability.GetAsync(ct);
        if (!availability.Available) return (null, false, null);

        var risk = await _riskStore.GetForLeadAsync(leadId, ct);
        if (risk is null) return (null, true, null); // available, but not computed yet (e.g. sweep hasn't run)

        var evidence = ParseEvidence(risk.SignalsJson)
            .Select(s => new DealRiskEvidenceDto(s.Kind, s.Text, s.Level, s.CitationKind, s.CitationId))
            .ToList();
        return (null, true, new DealRiskDto(true, risk.Level, evidence, risk.ReasonsText, risk.ComputedAt));
    }

    private static List<DealRiskSignal> ParseEvidence(string json)
    {
        try { return JsonSerializer.Deserialize<List<DealRiskSignal>>(json) ?? []; }
        catch { return []; }
    }
}

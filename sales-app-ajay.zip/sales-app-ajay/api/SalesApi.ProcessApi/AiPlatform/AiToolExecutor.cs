using System.Text.Json;
using SalesApi.Data;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Approvals;
using SalesApi.ProcessLayer.AiPlatform.Tools;
using SalesApi.Services;
using SalesApi.SystemLayer.AiPlatform;

namespace SalesApi.ProcessLayer.AiPlatform;

/// <summary>
/// The E4.7 tool registry's propose/execute split (design §7.2, §15 slice 9)
/// — sits between a future skill loop and every <see cref="IAiTool"/>.
///
/// <see cref="OfferedToolsAsync"/> is what "prohibited actions are never
/// offered" (epics-ai-native-crm.md:272) means concretely: a tool whose
/// <see cref="IAiTool.ActionType"/> resolves to
/// <see cref="AiAutonomyLevels.Prohibited"/> for this org is left out of the
/// list a skill loop would ever hand the model, not merely refused after the
/// model asks for it anyway — <see cref="ExecuteAsync"/> refuses it too, as
/// defence in depth against a stale tool list or a model call built before a
/// policy change.
///
/// <see cref="ExecuteAsync"/>'s autonomy resolution: an unknown tool name or
/// a prohibited action is refused and NEVER calls
/// <see cref="IAiTool.ExecuteAsync"/>. For a known, allowed tool: autonomy
/// <see cref="AiAutonomyLevels.Read"/>/<see cref="AiAutonomyLevels.Automatic"/>
/// call the tool for real (design §7.2 item 3, "execute"); a tool's own
/// internal permission check — the SAME check its wrapped Process method
/// already applies — is what makes "the tool never grants a permission the
/// caller lacks" true for THAT call, since nothing is written until the tool
/// itself runs. <see cref="AiAutonomyLevels.Recommend"/> returns
/// <see cref="AiToolOutcomeStatus.Suggested"/> carrying the caller's own
/// proposed args back UNEXECUTED; <see cref="AiAutonomyLevels.Approval"/>
/// returns <see cref="AiToolOutcomeStatus.ApprovalRequired"/> — a named seam
/// for slice 10's approval pause/resume (reusing
/// <c>ApprovalChainProcess</c>/<c>ApprovalTypes.Automation</c> per the design
/// §18 build note), deliberately NOT built here.
///
/// Every call — whatever it resolved to — is logged to
/// <see cref="AiToolInvocation"/> (design §7.3). A repeated
/// <paramref name="idempotencyKey"/> (on <see cref="ExecuteAsync"/>) returns
/// the FIRST call's own outcome without touching a tool a second time,
/// mirroring <c>AutomationRun</c>'s own unique-index dedupe.
///
/// TODO(E4 execution log): when a skill loop exists to drive this executor,
/// wire tool proposals/outcomes into <c>AiExecutionLogEntry.ToolsProposedJson</c>/
/// <c>ActionsExecutedJson</c> (slices 4-5, merged) at the call site that has
/// BOTH the model's tool-use turn and this executor's outcome in scope — not
/// here, since this class has no model turn to attribute a proposal to yet
/// (per this slice's brief, item 5).
/// </summary>
public sealed class AiToolExecutor : IAiToolApprovalResumer
{
    private readonly IEnumerable<IAiTool> _tools;
    private readonly AiActionPolicyStore _policies;
    private readonly AiToolInvocationStore _invocations;
    private readonly ApprovalProcess _approvals;
    private readonly OrganizationRoleService _roles;

    public AiToolExecutor(
        IEnumerable<IAiTool> tools, AiActionPolicyStore policies, AiToolInvocationStore invocations,
        ApprovalProcess approvals, OrganizationRoleService roles)
    {
        _tools = tools;
        _policies = policies;
        _invocations = invocations;
        _approvals = approvals;
        _roles = roles;
    }

    /// <summary>The tools a skill loop may offer the model for THIS org —
    /// every registered <see cref="IAiTool"/> whose <see cref="IAiTool.ActionType"/>
    /// is not <see cref="AiAutonomyLevels.Prohibited"/>. Scoped to the ambient
    /// tenant (<c>AiActionPolicyStore</c>'s own query filter), the same
    /// "no explicit org id needed" posture that store already documents — no
    /// separate <c>org</c> parameter here for the same reason.</summary>
    public async Task<IReadOnlyList<AiToolSpec>> OfferedToolsAsync(CancellationToken ct = default)
    {
        var policies = await _policies.ListAsync(ct);
        var prohibited = policies
            .Where(p => p.Autonomy == AiAutonomyLevels.Prohibited)
            .Select(p => p.ActionType)
            .ToHashSet(StringComparer.Ordinal);

        return [.. _tools.Where(t => !prohibited.Contains(t.ActionType)).Select(t => t.Spec)];
    }

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, AiToolCall call, string? idempotencyKey, CancellationToken ct = default)
    {
        if (idempotencyKey is not null)
        {
            var existing = await _invocations.FindByIdempotencyKeyAsync(idempotencyKey, ct);
            if (existing is not null) return FromInvocation(existing);
        }

        var tool = _tools.FirstOrDefault(t => string.Equals(t.Spec.Name, call.Name, StringComparison.Ordinal));
        if (tool is null)
        {
            var refused = AiToolResult.Refused($"Unknown AI tool '{call.Name}'.");
            await LogAsync(caller, call.Name, "(unknown)", "(unknown)", refused, idempotencyKey, call.ArgsJson, ct);
            return refused;
        }

        var policy = await _policies.GetByActionTypeAsync(tool.ActionType, ct);
        // Defensive default: an action type with no seeded row yet (a race with
        // AiActionPolicySeedService, or a build that added a tool ahead of its
        // policy row) resolves to the SAME safe default the seed service itself
        // would give it — recommend, never automatic. See that service's own
        // "ships with every non-read action at recommend" comment.
        var autonomy = policy?.Autonomy
            ?? (tool.ActionType == AiActionTypes.Read ? AiAutonomyLevels.Read : AiAutonomyLevels.Recommend);

        if (autonomy == AiAutonomyLevels.Prohibited)
        {
            var refused = AiToolResult.Refused($"The '{tool.ActionType}' action is prohibited for this organization.");
            await LogAsync(caller, tool.Spec.Name, tool.ActionType, autonomy, refused, idempotencyKey, call.ArgsJson, ct);
            return refused;
        }

        JsonElement args;
        try
        {
            args = string.IsNullOrWhiteSpace(call.ArgsJson)
                ? JsonDocument.Parse("{}").RootElement
                : JsonDocument.Parse(call.ArgsJson).RootElement;
        }
        catch (JsonException ex)
        {
            var refused = AiToolResult.Refused($"Could not parse tool arguments: {ex.Message}");
            await LogAsync(caller, tool.Spec.Name, tool.ActionType, autonomy, refused, idempotencyKey, call.ArgsJson, ct);
            return refused;
        }

        if (autonomy is AiAutonomyLevels.Read or AiAutonomyLevels.Automatic)
        {
            var invocationId = Guid.NewGuid(); // assigned client-side — see IAiTool.ExecuteAsync's own doc comment
            var result = await tool.ExecuteAsync(caller, args, invocationId, ct);
            await LogAsync(caller, tool.Spec.Name, tool.ActionType, autonomy, result, idempotencyKey, call.ArgsJson, ct);
            return result;
        }

        if (autonomy == AiAutonomyLevels.Recommend)
        {
            var suggested = new AiToolResult(
                AiToolOutcomeStatus.Suggested,
                "Proposed, not executed — this organization's policy for this action is 'recommend'.",
                call.ArgsJson, []);
            await LogAsync(caller, tool.Spec.Name, tool.ActionType, autonomy, suggested, idempotencyKey, call.ArgsJson, ct);
            return suggested;
        }

        // autonomy == Approval (design §7.2 item 3, §15 slice 10). Creates an
        // ApprovalRequest of type ApprovalTypes.Automation — the SAME "plain
        // sign-off, no baked-in effect" type request_approval's own automation
        // action uses (design §12 slice 10 of the automation design) — and
        // pauses this invocation. AiToolApprovalResumeHandler resumes it once
        // that request is decided (ApprovalDecided), running the tool for real
        // as the ORIGINAL requesting user, re-checked at that moment (slice
        // 9's own note: no permission check happened at propose time).
        var leadId = AiToolArgs.GetGuid(args, "lead_id");
        if (leadId is null)
        {
            var noLead = AiToolResult.Refused(
                "This action needs approval, but its arguments carry no \"lead_id\" to raise the approval against.");
            await LogAsync(caller, tool.Spec.Name, tool.ActionType, autonomy, noLead, idempotencyKey, call.ArgsJson, ct);
            return noLead;
        }

        // Human-readable summary — field NAMES only, never values (design
        // §7.2's "no masked values in the summary — use field names for masked
        // fields"; this build applies that rule to EVERY field, not just the
        // masked ones, since a tool call's args carry no per-field masking
        // fact this executor could consult — see this slice's own report).
        var fieldNames = JsonSerializer.Deserialize<List<string>>(ArgFieldNamesJson(call.ArgsJson)) ?? [];
        var summary = fieldNames.Count > 0
            ? $"AI proposes to run '{tool.Spec.Name}' on lead {leadId.Value} — fields: {string.Join(", ", fieldNames)}."
            : $"AI proposes to run '{tool.Spec.Name}' on lead {leadId.Value}.";

        var approvalInput = new ApprovalInput(ApprovalTypes.Automation, leadId.Value, null, summary, null);
        var approvalOutcome = await _approvals.CreateAsync(approvalInput, caller.Access.UserId, hasViewLeadValues: true, ct);
        if (approvalOutcome.Refusal is not null)
        {
            var refusedApproval = AiToolResult.Refused(DescribeApprovalRefusal(approvalOutcome.Refusal));
            await LogAsync(caller, tool.Spec.Name, tool.ActionType, autonomy, refusedApproval, idempotencyKey, call.ArgsJson, ct);
            return refusedApproval;
        }

        var approvalId = approvalOutcome.Approval!.Id;
        var approvalRequired = new AiToolResult(
            AiToolOutcomeStatus.ApprovalRequired,
            $"Approval requested (id {approvalId}) — this organization's policy for '{tool.ActionType}' is 'approval'.",
            call.ArgsJson, []);
        await _invocations.AddAsync(new AiToolInvocation
        {
            UserId = caller.Access.UserId,
            ToolName = tool.Spec.Name,
            ActionType = tool.ActionType,
            AutonomyApplied = autonomy,
            Status = AiToolInvocationStatus.PendingApproval,
            ArgFieldNamesJson = ArgFieldNamesJson(call.ArgsJson),
            Message = approvalRequired.Message,
            IdempotencyKey = idempotencyKey,
            ApprovalRequestId = approvalId,
            ProposedArgsJson = call.ArgsJson,
        }, ct);
        return approvalRequired;
    }

    private static string DescribeApprovalRefusal(ApprovalProcess.Refusal refusal) =>
        refusal.Body is { } body ? JsonSerializer.Serialize(body) : refusal.Kind.ToString();

    /// <summary>
    /// <see cref="IAiToolApprovalResumer"/>'s implementation — resumes a
    /// <see cref="AiToolInvocationStatus.PendingApproval"/> row once its
    /// <c>ApprovalRequest</c> is decided. Called by
    /// <c>Services.AiToolApprovalResumeHandler</c> (SystemApi) reacting to
    /// <c>DomainEventTypes.Keys.ApprovalDecided</c> — that interface's own
    /// class comment explains why this method's PUBLIC signature names only
    /// <c>invocationId</c>, never the <see cref="AiToolInvocation"/> entity
    /// itself (the same "AppDbContext is the one exemption" layering
    /// <c>IAutomationActionExecutor</c> already established).
    ///
    /// REJECT: terminal, nothing executes, nothing written (design §15 slice 10:
    /// "reject → invocation rejected, nothing written").
    ///
    /// APPROVE: re-resolves <see cref="AiToolCallerFacts"/> for the ORIGINAL
    /// requesting user AS OF NOW (never the facts captured at propose time,
    /// which do not exist here anyway — slice 9 never checked permission at
    /// propose time for exactly this reason) via
    /// <see cref="AiToolCallerFactsResolver.ResolveAsync"/>, then runs the SAME
    /// tool.ExecuteAsync a Read/Automatic call would — so the tool's own
    /// permission check (e.g. LeadWriteProcess's manage-access gate) is what
    /// makes "permission lost between propose and approve resolves to refused,
    /// nothing written" true, not a duplicate check here. A missing/deactivated
    /// user, a since-removed tool, or the action having gone PROHIBITED in the
    /// meantime all refuse the same way.
    /// </summary>
    public async Task ResumeAsync(AppDbContext db, Guid invocationId, bool approved, CancellationToken ct = default)
    {
        var invocation = await _invocations.GetByIdAsync(invocationId, ct);
        if (invocation is null) return; // deleted — nothing to resume onto

        // Idempotent: a replayed ApprovalDecided event (design §3's at-least-
        // once contract) must not execute a write tool twice.
        if (invocation.Status != AiToolInvocationStatus.PendingApproval) return;

        if (!approved)
        {
            invocation.Status = AiToolInvocationStatus.Rejected;
            invocation.Message = "Rejected by approval decision.";
            invocation.ProposedArgsJson = null;
            await _invocations.SaveChangesAsync(ct);
            return;
        }

        var facts = await AiToolCallerFactsResolver.ResolveAsync(db, _roles, invocation.UserId, ct);
        if (facts is null)
        {
            invocation.Status = AiToolInvocationStatus.Refused;
            invocation.Message = "The requesting user is no longer active — nothing was executed.";
            invocation.ProposedArgsJson = null;
            await _invocations.SaveChangesAsync(ct);
            return;
        }

        var tool = _tools.FirstOrDefault(t => string.Equals(t.Spec.Name, invocation.ToolName, StringComparison.Ordinal));
        if (tool is null)
        {
            invocation.Status = AiToolInvocationStatus.Refused;
            invocation.Message = $"Tool '{invocation.ToolName}' is no longer registered — nothing was executed.";
            invocation.ProposedArgsJson = null;
            await _invocations.SaveChangesAsync(ct);
            return;
        }

        var policy = await _policies.GetByActionTypeAsync(tool.ActionType, ct);
        if (policy?.Autonomy == AiAutonomyLevels.Prohibited)
        {
            invocation.Status = AiToolInvocationStatus.Refused;
            invocation.Message = $"The '{tool.ActionType}' action is now prohibited for this organization — nothing was executed.";
            invocation.ProposedArgsJson = null;
            await _invocations.SaveChangesAsync(ct);
            return;
        }

        JsonElement args;
        try
        {
            args = string.IsNullOrWhiteSpace(invocation.ProposedArgsJson)
                ? JsonDocument.Parse("{}").RootElement
                : JsonDocument.Parse(invocation.ProposedArgsJson).RootElement;
        }
        catch (JsonException ex)
        {
            invocation.Status = AiToolInvocationStatus.Refused;
            invocation.Message = $"Could not parse the proposed arguments: {ex.Message}";
            invocation.ProposedArgsJson = null;
            await _invocations.SaveChangesAsync(ct);
            return;
        }

        var result = await tool.ExecuteAsync(facts.Value, args, invocation.Id, ct);
        invocation.Status = StatusWire(result.Status); // Executed or Refused — a tool never returns Suggested/ApprovalRequired (IAiTool's own contract)
        invocation.Message = result.Message;
        invocation.CreatedRecordIdsJson = result.CreatedRecordIds.Count > 0
            ? JsonSerializer.Serialize(result.CreatedRecordIds) : null;
        invocation.ProposedArgsJson = null;
        await _invocations.SaveChangesAsync(ct);
    }

    private async Task LogAsync(
        AiToolCallerFacts caller, string toolName, string actionType, string autonomy,
        AiToolResult result, string? idempotencyKey, string argsJson, CancellationToken ct)
    {
        await _invocations.AddAsync(new AiToolInvocation
        {
            UserId = caller.Access.UserId,
            ToolName = toolName,
            ActionType = actionType,
            AutonomyApplied = autonomy,
            Status = StatusWire(result.Status),
            ArgFieldNamesJson = ArgFieldNamesJson(argsJson),
            CreatedRecordIdsJson = result.CreatedRecordIds.Count > 0
                ? JsonSerializer.Serialize(result.CreatedRecordIds) : null,
            Message = result.Message,
            IdempotencyKey = idempotencyKey,
        }, ct);
    }

    private static AiToolResult FromInvocation(AiToolInvocation invocation) => new(
        WireStatus(invocation.Status),
        invocation.Message,
        null, // never replays the tool's own result body — see AiToolInvocation's class remarks
        invocation.CreatedRecordIdsJson is string json
            ? JsonSerializer.Deserialize<List<Guid>>(json) ?? []
            : []);

    private static string StatusWire(AiToolOutcomeStatus status) => status switch
    {
        AiToolOutcomeStatus.Executed => "executed",
        AiToolOutcomeStatus.Suggested => "suggested",
        AiToolOutcomeStatus.ApprovalRequired => "approval_required",
        AiToolOutcomeStatus.Refused => "refused",
        _ => "refused",
    };

    private static AiToolOutcomeStatus WireStatus(string status) => status switch
    {
        "executed" => AiToolOutcomeStatus.Executed,
        "suggested" => AiToolOutcomeStatus.Suggested,
        "approval_required" => AiToolOutcomeStatus.ApprovalRequired,
        // Slice 10 — a retry (same idempotency key) that lands while the
        // original call is STILL pending_approval replays the same
        // ApprovalRequired outcome, never a fresh approval request.
        AiToolInvocationStatus.PendingApproval => AiToolOutcomeStatus.ApprovalRequired,
        // "rejected" (slice 10) has no dedicated AiToolOutcomeStatus value —
        // Refused is the correct replay: nothing executes, nothing written,
        // same as any other terminal non-success.
        _ => AiToolOutcomeStatus.Refused,
    };

    /// <summary>Argument FIELD NAMES only — never values (class-level
    /// discipline this table exists to enforce; see <see cref="AiToolInvocation"/>'s
    /// own remarks).</summary>
    private static string ArgFieldNamesJson(string argsJson)
    {
        try
        {
            using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(argsJson) ? "{}" : argsJson);
            if (doc.RootElement.ValueKind != JsonValueKind.Object) return "[]";
            return JsonSerializer.Serialize(doc.RootElement.EnumerateObject().Select(p => p.Name).ToList());
        }
        catch (JsonException)
        {
            return "[]";
        }
    }
}

using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Tasks;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// <c>create_task</c> — a thin wrapper over <see cref="TaskProcess.CreateAsync"/>,
/// the SAME <c>POST /tasks</c> path a manual call uses (assignee resolution,
/// "only a manager may assign to someone else" — that refusal IS the "the
/// tool never grants a permission the caller lacks" guarantee for this tool,
/// design §7.2 item 1). Stamps <c>Source=TaskSources.Ai</c> and
/// <c>SourceRef=invocationId</c> — the SAME reserved columns
/// <c>AutomationActionExecutor.CreateTaskAsync</c> stamps with the automation
/// run's id, this time with the AI TOOL CALL's own id (design §7.1: "an
/// AiToolCallLogEntry.Id... stamped as the SourceRef").
/// </summary>
public sealed class CreateTaskTool : IAiTool
{
    private readonly TaskProcess _tasks;
    public CreateTaskTool(TaskProcess tasks) => _tasks = tasks;

    public string ActionType => AiActionTypes.CreateTask;

    public AiToolSpec Spec { get; } = new(
        "create_task",
        "Create a task. Defaults to assigning the caller; assigning someone else requires manager access.",
        new JsonSchema("""
        {"type":"object","properties":{
          "title":{"type":"string"},
          "description":{"type":"string"},
          "assignee_id":{"type":"string","format":"uuid"},
          "due_at":{"type":"string","format":"date-time"},
          "priority":{"type":"string","enum":["low","medium","high"]},
          "linked_record_type":{"type":"string","enum":["lead","account"]},
          "linked_record_id":{"type":"string","format":"uuid"}
        },"required":["title"]}
        """),
        AiToolRiskClass.Write,
        Idempotent: false);

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, JsonElement args, Guid invocationId, CancellationToken ct = default)
    {
        var title = AiToolArgs.GetString(args, "title");
        if (string.IsNullOrWhiteSpace(title))
            return AiToolResult.Refused("\"title\" is required.");

        var input = new TaskInput(
            title, AiToolArgs.GetString(args, "description"), AiToolArgs.GetGuid(args, "assignee_id"),
            AiToolArgs.GetDate(args, "due_at"), AiToolArgs.GetString(args, "priority"),
            AiToolArgs.GetString(args, "linked_record_type"), AiToolArgs.GetGuid(args, "linked_record_id"),
            TeamId: null, Checklist: null);

        var (dto, refusal) = await _tasks.CreateAsync(
            caller.Access, caller.OrgId, input, ct, TaskSources.Ai, invocationId);
        if (refusal is not null || dto is null)
            return AiToolResult.Refused(refusal?.Reason ?? "Could not create the task.");

        return AiToolResult.Ok(AiToolArgs.ToResultJson(dto), [dto.Id]);
    }
}

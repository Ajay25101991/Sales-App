using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Leads;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// <c>log_activity</c> — a thin wrapper over <see cref="LeadReadProcess.AddActivityAsync"/>,
/// the SAME <c>POST /leads/{id}/activities</c> path a manual call uses. That
/// method requires MANAGE access to the lead (<c>LoadAsync(vis, id, manage:
/// true)</c>), so a caller who can only view the lead is refused exactly as
/// the controller would refuse them — no separate permission check needed
/// here.
///
/// NO SOURCE-REF EQUIVALENT: <c>LeadActivity</c> (verified against
/// <c>SalesApi.SystemApi/Models/LeadActivity.cs</c>) has
/// <c>CausedByAutomationId</c>, stamped ambiently by
/// <c>AppDbContext.StampAutomationCausation</c> only while an
/// <c>AutomationRunContext</c> is active — no generic source/source-ref pair,
/// and no AI-specific column. Per this slice's brief ("do not add columns to
/// those tables in this slice"), the invocation id is NOT stamped on the
/// created row; the <c>AiToolInvocation</c> log (via <c>CreatedRecordIds</c>)
/// is the only link. Flagged here rather than worked around.
///
/// <paramref name="caller"/>'s actor NAME is not carried on
/// <see cref="AiToolCallerFacts"/> (no controller-equivalent display-name
/// lookup happens before a tool runs) — verified that
/// <c>AddActivityAsync</c>'s own <c>actorName</c> parameter is UNUSED inside
/// that method (its body never reads it), so passing a literal here costs
/// nothing today; flagged rather than silently assumed correct if that method
/// ever starts using it.
/// </summary>
public sealed class LogActivityTool : IAiTool
{
    private readonly LeadReadProcess _leads;
    public LogActivityTool(LeadReadProcess leads) => _leads = leads;

    public string ActionType => AiActionTypes.LogActivity;

    public AiToolSpec Spec { get; } = new(
        "log_activity",
        "Log an activity (note/call/email/meeting) on a lead. Requires manage access to the lead.",
        new JsonSchema("""
        {"type":"object","properties":{
          "lead_id":{"type":"string","format":"uuid"},
          "type":{"type":"string","enum":["note","call","email","meeting"]},
          "body":{"type":"string"}
        },"required":["lead_id"]}
        """),
        AiToolRiskClass.Write,
        Idempotent: false);

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, JsonElement args, Guid invocationId, CancellationToken ct = default)
    {
        var leadId = AiToolArgs.GetGuid(args, "lead_id");
        if (leadId is null)
            return AiToolResult.Refused("\"lead_id\" is required and must be a UUID.");

        var input = new ActivityInput(AiToolArgs.GetString(args, "type"), AiToolArgs.GetString(args, "body"));
        var (refusal, dto) = await _leads.AddActivityAsync(caller.Access, caller.Access.UserId, "AI", leadId.Value, input);
        if (refusal is not null || dto is null)
            return AiToolResult.Refused(refusal?.Reason ?? "Could not log the activity.");

        return AiToolResult.Ok(AiToolArgs.ToResultJson(dto), [dto.Id]);
    }
}

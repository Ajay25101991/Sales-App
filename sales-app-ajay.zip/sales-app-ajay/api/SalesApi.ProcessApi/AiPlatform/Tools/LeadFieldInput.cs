using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.ProcessLayer.Leads;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// Shared plumbing for <see cref="ChangeStageTool"/> and <see cref="UpdateFieldTool"/>
/// — both call <c>LeadWriteProcess.UpdateAsync</c> with a <c>LeadInput</c> that
/// sets exactly ONE thing (a stage, or a single field) and leaves every other
/// property null, the same "null means no change" contract <c>Apply()</c>
/// already documents (verified: no property of <c>LeadInput</c> is read as
/// anything other than "changed" when non-null across every call site in
/// <c>LeadWriteProcess</c>). Factored out so the two tools do not each hand-roll
/// the same ~20-parameter positional record twice.
/// </summary>
internal static class LeadFieldInput
{
    /// <summary>A <c>LeadInput</c> with only <paramref name="status"/> (and
    /// optionally <paramref name="reason"/>) set — <see cref="ChangeStageTool"/>'s
    /// own shape.</summary>
    public static LeadInput For(string? status = null, string? reason = null, JsonElement? custom = null,
        string? priority = null, string? source = null, decimal? estimatedValue = null, string? notes = null) => new(
        Name: null, Company: null, Email: null, Phone: null, Status: status, Priority: priority, Source: source,
        EstimatedValue: estimatedValue, Notes: notes, NextFollowUpAt: null, Reason: reason, Custom: custom,
        AccountId: null, CloseReason: null, Products: null, Address: null, City: null, State: null,
        PostalCode: null, Country: null, Nationality: null, ExpectedCloseDate: null);

    /// <summary>
    /// The <c>LeadActor</c> a tool call runs as — the SAME facts
    /// <c>LeadsController.ActorAsync</c> resolves for a human PATCH, built from
    /// what <see cref="AiToolCallerFacts"/> already carries.
    ///
    /// <c>Name</c> is the empty string, not a display-name lookup: verified
    /// against every read of <c>actor.Name</c> in <c>LeadWriteProcess</c> (there
    /// are none reachable from <c>UpdateAsync</c>'s status/field-only path this
    /// helper serves — see that class's own <c>Apply()</c>, which never reads
    /// it) — flagged here rather than silently assumed safe for any FUTURE
    /// caller of this helper that reaches a path which does.
    ///
    /// <c>CanCreateTags</c> is always false: neither tool this helper serves
    /// ever sets <c>LeadInput.Tags</c>/<c>TagNames</c>, the only inputs that
    /// consult it.
    /// </summary>
    public static LeadActor ActorFor(AiToolCallerFacts caller) => new(
        caller.Access.UserId, caller.OrgId, "", caller.Access.HasManagerAccess, caller.Access.Visibility,
        CanCreateTags: false);
}

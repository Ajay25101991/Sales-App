using System.Text.Json;
using SalesApi.Models;
using SalesApi.ProcessLayer.Leads;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// <c>draft_email</c> — slice 10 (this slice's brief, item 1): mapped to
/// <see cref="AiActionTypes.Read"/>, NOT <c>send_email</c>'s row — it writes
/// nothing and sends nothing, so it carries no more risk than
/// <see cref="GetLeadTool"/> does. Renders a subject/body TEMPLATE against the
/// lead's own merge-field values (<see cref="AutomationMergeFields.Render"/> —
/// the SAME renderer <c>AutomationActionExecutor.SendTemplateEmailAsync</c>
/// uses for its own per-recipient subject/body), resolved through
/// <see cref="LeadReadProcess.GetAsync"/> under the CALLER's own
/// <see cref="AiToolCallerFacts.LeadView"/> — a masked contact detail or lead
/// value renders as an EMPTY token (<c>Render</c>'s own "unresolved token
/// renders as empty" rule), never the "Hidden" placeholder or the real value,
/// so a caller without <c>contact_details.view</c>/<c>lead_values.view</c>
/// cannot use a draft to learn what they are not otherwise shown.
///
/// A SMALLER merge-field set than <c>AutomationActionExecutor</c>'s own lead
/// snapshot (name/company/owner/email/phone/next-follow-up only — no
/// stage/estimated-value/custom.* fields) — this tool drafts outbound
/// correspondence, not an internal notification, and a smaller, well-understood
/// set is easier to audit for what a drafted email could ever contain. Flagged
/// as a scope decision rather than silently matching the automation's full set.
/// </summary>
public sealed class DraftEmailTool : IAiTool
{
    private readonly LeadReadProcess _leads;
    public DraftEmailTool(LeadReadProcess leads) => _leads = leads;

    public string ActionType => AiActionTypes.Read;

    public AiToolSpec Spec { get; } = new(
        "draft_email",
        "Draft an email's subject/body for a lead from merge-field templates (e.g. \"Hi {{lead.name}}\"). " +
        "Read-only — writes and sends nothing. Use send_email to actually send.",
        new JsonSchema("""
        {"type":"object","properties":{
          "lead_id":{"type":"string","format":"uuid"},
          "subject_template":{"type":"string"},
          "body_template":{"type":"string"}
        },"required":["lead_id","subject_template","body_template"]}
        """),
        AiToolRiskClass.Read,
        Idempotent: true);

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, JsonElement args, Guid invocationId, CancellationToken ct = default)
    {
        var leadId = AiToolArgs.GetGuid(args, "lead_id");
        if (leadId is null)
            return AiToolResult.Refused("\"lead_id\" is required and must be a UUID.");
        var subjectTemplate = AiToolArgs.GetString(args, "subject_template");
        var bodyTemplate = AiToolArgs.GetString(args, "body_template");
        if (subjectTemplate is null || bodyTemplate is null)
            return AiToolResult.Refused("\"subject_template\" and \"body_template\" are required.");

        var (refusal, dto) = await _leads.GetAsync(caller.Access, caller.LeadView, leadId.Value);
        if (refusal is not null || dto is null)
            return AiToolResult.Refused(refusal?.Reason ?? "Lead not found.");

        var values = new Dictionary<string, object?>(StringComparer.Ordinal)
        {
            ["lead.name"] = dto.Name,
            ["lead.company"] = dto.Company,
            ["lead.owner_name"] = dto.OwnerName,
            // Already null under !CanSeeContactDetails — LeadMapping.ToDto
            // masked them before this DTO left the mapper, same reasoning
            // GetLeadTool's own class comment gives.
            ["lead.email"] = dto.Email,
            ["lead.phone"] = dto.Phone,
            ["lead.next_follow_up_at"] = dto.NextFollowUpAt?.ToString("yyyy-MM-dd"),
        };

        var subject = AutomationMergeFields.Render(subjectTemplate, values);
        var body = AutomationMergeFields.Render(bodyTemplate, values);
        var result = AiToolArgs.ToResultJson(new { lead_id = leadId.Value, subject, body });
        return AiToolResult.Ok(result);
    }
}

using System.Text.Json;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// Tiny JsonElement readers shared by every concrete <c>IAiTool</c> — the same
/// "never throw into the model loop" discipline as
/// <c>AutomationActionExecutor</c>'s own <c>GetString</c>/<c>GetInt</c>/
/// <c>GetGuid</c> helpers (that class's own private statics), duplicated here
/// rather than shared across assemblies because that class is
/// <c>internal</c>-shaped by convention (its own file, no public surface) and
/// this is a genuinely small helper.
/// </summary>
internal static class AiToolArgs
{
    public static string? GetString(JsonElement el, string property) =>
        el.ValueKind == JsonValueKind.Object && el.TryGetProperty(property, out var v) && v.ValueKind == JsonValueKind.String
            ? v.GetString() : null;

    public static Guid? GetGuid(JsonElement el, string property) =>
        GetString(el, property) is string s && Guid.TryParse(s, out var g) ? g : null;

    public static DateTime? GetDate(JsonElement el, string property) =>
        GetString(el, property) is string s && DateTime.TryParse(
            s, null, System.Globalization.DateTimeStyles.RoundtripKind, out var d) ? d : null;

    public static List<string>? GetStringList(JsonElement el, string property)
    {
        if (el.ValueKind != JsonValueKind.Object || !el.TryGetProperty(property, out var v) || v.ValueKind != JsonValueKind.Array)
            return null;
        var list = new List<string>();
        foreach (var item in v.EnumerateArray())
            if (item.ValueKind == JsonValueKind.String && item.GetString() is string s)
                list.Add(s);
        return list.Count > 0 ? list : null;
    }

    /// <summary>Slice 10's <c>create_quote</c> — <c>module_ids</c>, a UUID
    /// array. Same "absent/empty/unparsable resolves to null, never throws"
    /// posture as every other reader in this class.</summary>
    public static List<Guid>? GetGuidList(JsonElement el, string property)
    {
        if (el.ValueKind != JsonValueKind.Object || !el.TryGetProperty(property, out var v) || v.ValueKind != JsonValueKind.Array)
            return null;
        var list = new List<Guid>();
        foreach (var item in v.EnumerateArray())
            if (item.ValueKind == JsonValueKind.String && Guid.TryParse(item.GetString(), out var g))
                list.Add(g);
        return list.Count > 0 ? list : null;
    }

    /// <summary>The wire convention every AiToolResult.ResultJson serializes
    /// under — snake_case, matching Program.cs's own
    /// <c>JsonNamingPolicy.SnakeCaseLower</c> for the ordinary API response
    /// bodies these DTOs already serialize as, so a tool's JSON echoes the
    /// same field names a manual API call would show the model.</summary>
    public static readonly JsonSerializerOptions ResultOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
    };

    public static string ToResultJson<T>(T value) => JsonSerializer.Serialize(value, ResultOptions);
}

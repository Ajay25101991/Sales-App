using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Leads;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// <c>change_stage</c> — slice 10 (design §7.1, §15 slice 10). A thin wrapper
/// over <see cref="LeadWriteProcess.UpdateAsync"/> with ONLY <c>Status</c> (and
/// optionally <c>Reason</c>) set — the SAME method <c>PATCH /leads/{id}</c>
/// calls for a stage move, so every gate that method already enforces applies
/// completely unchanged: playbook exit criteria
/// (<c>MissingStageRequirementsAsync</c>), the backward-move manager+reason
/// rule, the reopen-needs-approval refusal (<c>reopen_requires_approval</c>),
/// payment-terms-before-won, and the out-of-sync-playbook block. A gate refusal
/// comes back as this tool's own <see cref="AiToolResult.Refused"/> carrying
/// that gate's own message — never a separate, weaker check re-implemented
/// here.
/// </summary>
public sealed class ChangeStageTool : IAiTool
{
    private readonly LeadWriteProcess _writes;
    public ChangeStageTool(LeadWriteProcess writes) => _writes = writes;

    public string ActionType => AiActionTypes.ChangeStage;

    public AiToolSpec Spec { get; } = new(
        "change_stage",
        "Move a lead to a different pipeline stage. Goes through every existing stage gate " +
        "(playbook requirements, reopen/backward-move approval, payment terms before won) — a blocked move is refused " +
        "with that gate's own message, never silently skipped.",
        new JsonSchema("""
        {"type":"object","properties":{
          "lead_id":{"type":"string","format":"uuid"},
          "status":{"type":"string"},
          "reason":{"type":"string"}
        },"required":["lead_id","status"]}
        """),
        AiToolRiskClass.Write,
        Idempotent: false);

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, JsonElement args, Guid invocationId, CancellationToken ct = default)
    {
        var leadId = AiToolArgs.GetGuid(args, "lead_id");
        if (leadId is null)
            return AiToolResult.Refused("\"lead_id\" is required and must be a UUID.");
        var status = AiToolArgs.GetString(args, "status");
        if (string.IsNullOrWhiteSpace(status))
            return AiToolResult.Refused("\"status\" is required.");

        var input = LeadFieldInput.For(status: status, reason: AiToolArgs.GetString(args, "reason"));
        var actor = LeadFieldInput.ActorFor(caller);
        var (refusal, dto) = await _writes.UpdateAsync(caller.Access, caller.LeadView, actor, leadId.Value, input);
        if (refusal is not null || dto is null)
            return AiToolResult.Refused(refusal?.Reason ?? "Could not move this lead's stage.");

        return AiToolResult.Ok(AiToolArgs.ToResultJson(dto));
    }
}

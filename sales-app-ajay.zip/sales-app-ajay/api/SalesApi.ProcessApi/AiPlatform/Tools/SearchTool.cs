using System.Text.Json;
using SalesApi.Models;
using SalesApi.ProcessLayer.Search;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// <c>search</c> — a thin wrapper over <see cref="SearchProcess.SearchAsync"/>,
/// the SAME global-search palette <c>GET /search</c> uses (design §7.1 "each a
/// thin wrapper over one existing Process method"). Every visibility rule
/// SearchProcess's own class comment documents (leads/accounts/invoices reuse
/// their list endpoints' WhereViewable; contacts inherit their account's
/// visibility; contact email/phone drop out of the match entirely without
/// <c>contact_details.view</c>) applies unchanged, because this tool calls
/// the exact same method with the exact same caller facts a controller would.
/// Always <see cref="AiActionTypes.Read"/> — read tools carry no write risk
/// (design §8.1's own vocabulary comment), so <see cref="Idempotent"/> is
/// true and this is the one tool whose autonomy is never anything but
/// <see cref="AiAutonomyLevels.Read"/>.
/// </summary>
public sealed class SearchTool : IAiTool
{
    private readonly SearchProcess _search;
    public SearchTool(SearchProcess search) => _search = search;

    public string ActionType => AiActionTypes.Read;

    public AiToolSpec Spec { get; } = new(
        "search",
        "Full-text search across leads, accounts, contacts, quotes and invoices the caller may see. Money and masked contact details never appear in results.",
        new JsonSchema("""
        {"type":"object","properties":{
          "query":{"type":"string","description":"Search text, at least 2 characters."},
          "types":{"type":"array","items":{"type":"string","enum":["lead","account","contact","quote","invoice"]},"description":"Optional: restrict to these result groups."}
        },"required":["query"]}
        """),
        AiToolRiskClass.Read,
        Idempotent: true);

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, JsonElement args, Guid invocationId, CancellationToken ct = default)
    {
        var query = AiToolArgs.GetString(args, "query");
        if (string.IsNullOrWhiteSpace(query))
            return AiToolResult.Refused("\"query\" is required.");

        var types = AiToolArgs.GetStringList(args, "types");
        // E12.2 decision 23: phone/email are search keys only where the whole visible set is readable raw (same rule as GET /search).
        var mayMatchContact = caller.LeadView.CanSeeContactDetails && (caller.LeadView.Sensitive?.ContactDetailsSearchable ?? true);
        var results = await _search.SearchAsync(caller.Access, query, types, mayMatchContact, ct);
        return AiToolResult.Ok(AiToolArgs.ToResultJson(results));
    }
}

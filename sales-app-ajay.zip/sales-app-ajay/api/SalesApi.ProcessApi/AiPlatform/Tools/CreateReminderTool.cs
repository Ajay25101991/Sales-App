using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Reminders;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// <c>create_reminder</c> — a thin wrapper over <see cref="ReminderProcess.CreateAsync"/>,
/// the SAME <c>POST /reminders</c> path a manual call uses. That method takes
/// only the TOKEN-derived caller id (its own doc comment: "callers never
/// supply their own, so a reminder can never be created for someone else
/// through this path") — no <c>RecordAccessContext</c>, no manager-assignee
/// override exists for reminders the way it does for tasks, so this tool
/// always creates the reminder as <see cref="AiToolCallerFacts.Access"/>'s
/// own user, exactly mirroring <c>RemindersController.Create</c>.
///
/// NO SOURCE-REF EQUIVALENT: unlike <see cref="TaskItem.SourceRef"/>,
/// <c>Reminder</c> has no "what caused this" column (verified against
/// <c>SalesApi.SystemApi/Models/Reminder.cs</c> — it carries
/// <c>InvoiceId</c>/<c>AmcId</c>/<c>Kind</c>/<c>EventType</c> for specific
/// AUTO-GENERATED reminder kinds, none of which fit an AI tool call, and no
/// generic source/source-ref pair). Per this slice's brief ("do not add
/// columns to those tables in this slice"), the invocation id is NOT stamped
/// anywhere on the created <c>Reminder</c> row — the <c>AiToolInvocation</c>
/// row this call is logged against (via its <c>CreatedRecordIds</c>) is the
/// only place the link exists today. Flagged here rather than worked around.
/// </summary>
public sealed class CreateReminderTool : IAiTool
{
    private readonly ReminderProcess _reminders;
    public CreateReminderTool(ReminderProcess reminders) => _reminders = reminders;

    public string ActionType => AiActionTypes.CreateReminder;

    public AiToolSpec Spec { get; } = new(
        "create_reminder",
        "Create a reminder for the caller. Cannot be created for anyone else.",
        new JsonSchema("""
        {"type":"object","properties":{
          "lead_id":{"type":"string","format":"uuid"},
          "title":{"type":"string"},
          "notes":{"type":"string"},
          "remind_at":{"type":"string","format":"date-time"},
          "channels":{"type":"array","items":{"type":"string","enum":["push","email","in_app"]}}
        },"required":["title","remind_at"]}
        """),
        AiToolRiskClass.Write,
        Idempotent: false);

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, JsonElement args, Guid invocationId, CancellationToken ct = default)
    {
        var title = AiToolArgs.GetString(args, "title");
        if (string.IsNullOrWhiteSpace(title))
            return AiToolResult.Refused("\"title\" is required.");
        var remindAt = AiToolArgs.GetDate(args, "remind_at");
        if (remindAt is null)
            return AiToolResult.Refused("\"remind_at\" is required.");

        var input = new ReminderInput(
            AiToolArgs.GetGuid(args, "lead_id"), title, AiToolArgs.GetString(args, "notes"), remindAt,
            AiToolArgs.GetStringList(args, "channels"), Status: null);

        var (dto, refusal) = await _reminders.CreateAsync(caller.Access.UserId, input, ct);
        if (refusal is not null || dto is null)
            return AiToolResult.Refused(refusal?.Reason ?? "Could not create the reminder.");

        return AiToolResult.Ok(AiToolArgs.ToResultJson(dto), [dto.Id]);
    }
}

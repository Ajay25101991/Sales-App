using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Leads;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// <c>send_email</c> — slice 10 (design §7.1, §15 slice 10). Sends through the
/// org's own RESOLVED email sender (<see cref="EmailProviderResolver.ResolveAsync"/>
/// — the SAME gate every other outbound mail in this codebase goes through:
/// infra kill switch, provider configuration, the undeliverable-recipient
/// guard), and records the send on the lead's timeline through
/// <see cref="LeadReadProcess.AddActivityAsync"/> (type <c>"email"</c> — the
/// SAME activity TYPE <c>LogActivityTool</c>/the lead-activity form already use
/// for "a rep logging that they sent an email") — the SAME manage-access check
/// that method already applies is what makes "the tool never grants a
/// permission the caller lacks" true here: a caller who cannot manage a lead
/// cannot send email attributed to it either.
///
/// NO EXISTING "compose and send an email to a lead" endpoint exists in this
/// codebase to wrap (verified: only automation's own templated
/// <c>send_template_email</c> action and scheduled-report delivery call
/// <c>IEmailSender</c> today — see <c>AutomationActionExecutor.SendTemplateEmailAsync</c>).
/// This tool is therefore the FIRST caller of <see cref="EmailProviderResolver"/>
/// for a manually composed, ad-hoc message; flagged as a decision rather than
/// silently assumed to match a precedent that does not exist.
/// </summary>
public sealed class SendEmailTool : IAiTool
{
    private readonly EmailProviderResolver _resolver;
    private readonly LeadReadProcess _leads;

    public SendEmailTool(EmailProviderResolver resolver, LeadReadProcess leads)
    {
        _resolver = resolver;
        _leads = leads;
    }

    public string ActionType => AiActionTypes.SendEmail;

    public AiToolSpec Spec { get; } = new(
        "send_email",
        "Send an email about a lead and record it on the lead's timeline. Requires manage access to the lead.",
        new JsonSchema("""
        {"type":"object","properties":{
          "lead_id":{"type":"string","format":"uuid"},
          "to":{"type":"string"},
          "subject":{"type":"string"},
          "body":{"type":"string"}
        },"required":["lead_id","to","subject","body"]}
        """),
        AiToolRiskClass.Send,
        Idempotent: false);

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, JsonElement args, Guid invocationId, CancellationToken ct = default)
    {
        var leadId = AiToolArgs.GetGuid(args, "lead_id");
        if (leadId is null)
            return AiToolResult.Refused("\"lead_id\" is required and must be a UUID.");
        var to = AiToolArgs.GetString(args, "to");
        var subject = AiToolArgs.GetString(args, "subject");
        var body = AiToolArgs.GetString(args, "body");
        if (string.IsNullOrWhiteSpace(to) || string.IsNullOrWhiteSpace(subject) || string.IsNullOrWhiteSpace(body))
            return AiToolResult.Refused("\"to\", \"subject\" and \"body\" are all required.");

        // The SAME manage-access check AddActivityAsync's own header comment
        // documents (LoadAsync(vis, id, manage: true)) — checked BEFORE
        // sending, so a caller without manage access to this lead can never
        // trigger a real outbound send through this tool at all. Deliberately
        // NEUTRAL wording ("Emailing", not "Sent") because this write happens
        // BEFORE the send is attempted below (no cheap "check manage access
        // without writing" call exists on LeadReadProcess today) — a failed
        // send still leaves an honest record that an attempt was made, never
        // a false claim of delivery.
        var (refusal, dto) = await _leads.AddActivityAsync(
            caller.Access, caller.Access.UserId, "AI", leadId.Value,
            new ActivityInput("email", $"Emailing {to}: \"{subject}\"\n\n{body}"));
        if (refusal is not null || dto is null)
            return AiToolResult.Refused(refusal?.Reason ?? "Not allowed to send email for this lead.");

        var resolved = await _resolver.ResolveAsync(ct);
        if (resolved.Status != EmailProviderStatus.Ready || resolved.Sender is null)
            return AiToolResult.Refused(resolved.Reason ?? "Email is not available for this organization.");

        var htmlBody = EmailBody.FromPlainText(body);
        var sendResult = await resolved.Sender.SendAsync(new EmailMessage(to, subject, body, htmlBody), ct);
        if (!sendResult.Accepted)
            return AiToolResult.Refused(sendResult.Reason ?? "The email could not be sent.");

        return AiToolResult.Ok(AiToolArgs.ToResultJson(dto), [dto.Id]);
    }
}

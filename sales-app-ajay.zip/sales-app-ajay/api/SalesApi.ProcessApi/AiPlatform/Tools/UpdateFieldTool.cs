using System.Text.Json;
using System.Text.Json.Nodes;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.CustomFields;
using SalesApi.ProcessLayer.Leads;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// <c>update_field</c> — slice 10 (design §7.1, §15 slice 10). A thin wrapper
/// over <see cref="LeadWriteProcess.UpdateAsync"/> with a SINGLE field set —
/// the SAME <c>PATCH /leads/{id}</c> path a manual edit uses, so
/// <c>ValidateSensitiveInput</c>'s masking (a caller without
/// <c>lead_values.view</c> cannot touch <c>estimated_value</c>; without
/// <c>contact_details.view</c> cannot touch email/phone/address) applies
/// exactly as it would for a human, no second check needed for those.
///
/// <c>status</c> is deliberately NOT a supported field here — that is
/// <see cref="ChangeStageTool"/>'s own action type
/// (<see cref="AiActionTypes.ChangeStage"/>), gated and audited separately per
/// the design's own tool list (§7.1).
///
/// CUSTOM FIELDS (<c>custom.&lt;key&gt;</c>) get their OWN masking check here,
/// up front, refusing rather than relying on
/// <c>CustomFieldMasking.PreserveHidden</c>'s own silent "the incoming value for
/// a hidden key never lands" behaviour (that class's own remarks) — a SILENT
/// no-op would look like a successful update to the caller (and to the model),
/// which is worse than an honest refusal for a tool call. The blob passed to
/// <c>LeadWriteProcess</c> is the lead's OWN existing custom object with just
/// the one key changed, never a client-supplied full replacement — a single-
/// field update tool must not require (or trust) the caller to echo back every
/// other key.
/// </summary>
public sealed class UpdateFieldTool : IAiTool
{
    /// <summary>The standard, non-contact, non-financial scalar fields this
    /// tool supports — the same set <c>AutomationActionExecutor.SetFieldAsync</c>
    /// supports for its own <c>set_field</c> action, minus <c>status</c> (see
    /// class remarks). <c>estimated_value</c>/contact fields are supported too
    /// (unlike the automation action, which never touches money/contact data at
    /// all) because THIS tool goes through <c>ValidateSensitiveInput</c>'s own
    /// masking, where the automation's system actor bypasses it entirely.</summary>
    private static readonly string[] SupportedStandardFields =
        ["priority", "source", "estimated_value", "notes", "email", "phone"];

    private readonly LeadWriteProcess _writes;
    private readonly LeadReadProcess _reads;
    private readonly CustomFieldProcess _customFields;

    public UpdateFieldTool(LeadWriteProcess writes, LeadReadProcess reads, CustomFieldProcess customFields)
    {
        _writes = writes;
        _reads = reads;
        _customFields = customFields;
    }

    public string ActionType => AiActionTypes.UpdateField;

    public AiToolSpec Spec { get; } = new(
        "update_field",
        "Update a single field on a lead — one of priority/source/estimated_value/notes/email/phone, " +
        "or a custom field (\"custom.<key>\"). A field the caller cannot see cannot be updated. " +
        "Use change_stage to move the pipeline stage instead.",
        new JsonSchema("""
        {"type":"object","properties":{
          "lead_id":{"type":"string","format":"uuid"},
          "field":{"type":"string"},
          "value":{}
        },"required":["lead_id","field","value"]}
        """),
        AiToolRiskClass.Write,
        Idempotent: false);

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, JsonElement args, Guid invocationId, CancellationToken ct = default)
    {
        var leadId = AiToolArgs.GetGuid(args, "lead_id");
        if (leadId is null)
            return AiToolResult.Refused("\"lead_id\" is required and must be a UUID.");
        var field = AiToolArgs.GetString(args, "field");
        if (string.IsNullOrWhiteSpace(field))
            return AiToolResult.Refused("\"field\" is required.");
        if (!args.TryGetProperty("value", out var value))
            return AiToolResult.Refused("\"value\" is required.");

        LeadInput input;
        if (field.StartsWith("custom.", StringComparison.Ordinal))
        {
            var key = field["custom.".Length..];
            if (string.IsNullOrWhiteSpace(key))
                return AiToolResult.Refused("\"custom.<key>\" must name a field.");

            var defs = await _customFields.ListAsync(includeArchived: false, objectType: CustomFieldDef.ObjectTypes.Lead, ct);
            var def = defs.FirstOrDefault(d => string.Equals(d.Key, key, StringComparison.OrdinalIgnoreCase));
            if (def is not null)
            {
                var fakeDef = new CustomFieldDef { Key = def.Key, VisibleToRoles = def.VisibleToRoles ?? [], Sensitive = def.Sensitive };
                if (!CustomFieldMasking.IsVisibleTo(fakeDef, caller.LeadView.CallerRole))
                    return AiToolResult.Refused($"Your role cannot view or change the \"{def.Label}\" field.");
            }

            var (readRefusal, leadDto) = await _reads.GetAsync(caller.Access, caller.LeadView, leadId.Value);
            if (readRefusal is not null || leadDto is null)
                return AiToolResult.Refused(readRefusal?.Reason ?? "Lead not found.");

            // Rebuild the lead's OWN existing custom object with just this one
            // key changed — never a client-supplied full replacement (class
            // remarks). leadDto.Custom is already CustomFieldMasking.Apply-ed
            // for THIS caller's role, but that only ever replaces a hidden
            // key's VALUE with the literal "Hidden" — it never removes the key
            // — so every key this caller cannot see is still present here and
            // round-trips through PreserveHidden unchanged (its own "restored
            // from what was already stored" branch), exactly as if this caller
            // had PATCHed the full blob back unmodified.
            var obj = new JsonObject();
            if (leadDto.Custom is { ValueKind: JsonValueKind.Object } existing)
                foreach (var prop in existing.EnumerateObject())
                    obj[prop.Name] = JsonNode.Parse(prop.Value.GetRawText());
            obj[key] = JsonNode.Parse(value.GetRawText());

            input = LeadFieldInput.For(custom: JsonSerializer.Deserialize<JsonElement>(obj.ToJsonString()));
        }
        else if (!SupportedStandardFields.Contains(field))
        {
            return AiToolResult.Refused(
                $"\"{field}\" isn't a field this tool can set (supported: {string.Join(", ", SupportedStandardFields)}, or \"custom.<key>\").");
        }
        else
        {
            input = LeadFieldInput.For(
                priority: field == "priority" ? RequireString(value) : null,
                source: field == "source" ? RequireString(value) : null,
                estimatedValue: field == "estimated_value" ? value.GetDecimal() : null,
                notes: field == "notes" ? RequireString(value) : null);
            if (field is "email" or "phone")
                input = input with { Email = field == "email" ? RequireString(value) : null, Phone = field == "phone" ? RequireString(value) : null };
        }

        var actor = LeadFieldInput.ActorFor(caller);
        var (refusal, dto) = await _writes.UpdateAsync(caller.Access, caller.LeadView, actor, leadId.Value, input);
        if (refusal is not null || dto is null)
            return AiToolResult.Refused(refusal?.Reason ?? "Could not update this field.");

        return AiToolResult.Ok(AiToolArgs.ToResultJson(dto));
    }

    private static string? RequireString(JsonElement value) =>
        value.ValueKind == JsonValueKind.String ? value.GetString() : value.GetRawText();
}

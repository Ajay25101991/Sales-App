using System.Text.Json;
using SalesApi.Models;
using SalesApi.ProcessLayer.Leads;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// <c>get_lead</c> — a thin wrapper over <see cref="LeadReadProcess.GetAsync"/>,
/// the SAME <c>GET /leads/{id}</c> read path/DTO mapper a manual call uses, so
/// contact-details/lead-values masking (<c>LeadMapping.ToDto</c>,
/// <see cref="AiToolCallerFacts.LeadView"/>) and record-scope visibility
/// (<see cref="AiToolCallerFacts.Access"/>) apply exactly as they would in the
/// app — a masked field never reaches this tool's result because it never
/// left the mapper in the first place, the same reasoning
/// <c>AiContextEngine</c>'s own class comment gives for why it runs no second
/// masking pass.
/// </summary>
public sealed class GetLeadTool : IAiTool
{
    private readonly LeadReadProcess _leads;
    public GetLeadTool(LeadReadProcess leads) => _leads = leads;

    public string ActionType => AiActionTypes.Read;

    public AiToolSpec Spec { get; } = new(
        "get_lead",
        "Fetch one lead by id, masked exactly as it would render for this caller (contact details/values hidden per their permissions).",
        new JsonSchema("""
        {"type":"object","properties":{"lead_id":{"type":"string","format":"uuid"}},"required":["lead_id"]}
        """),
        AiToolRiskClass.Read,
        Idempotent: true);

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, JsonElement args, Guid invocationId, CancellationToken ct = default)
    {
        var leadId = AiToolArgs.GetGuid(args, "lead_id");
        if (leadId is null)
            return AiToolResult.Refused("\"lead_id\" is required and must be a UUID.");

        var (refusal, dto) = await _leads.GetAsync(caller.Access, caller.LeadView, leadId.Value);
        if (refusal is not null || dto is null)
            return AiToolResult.Refused(refusal?.Reason ?? "Lead not found.");

        return AiToolResult.Ok(AiToolArgs.ToResultJson(dto));
    }
}

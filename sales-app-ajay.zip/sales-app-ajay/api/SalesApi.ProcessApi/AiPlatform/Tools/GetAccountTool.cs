using System.Text.Json;
using SalesApi.Models;
using SalesApi.ProcessLayer.Accounts;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// <c>get_account</c> — a thin wrapper over <see cref="AccountProcess.GetAsync"/>,
/// the SAME <c>GET /accounts/{id}</c> read path a manual call uses, so
/// financial masking (<see cref="AiToolCallerFacts.CanSeeAccountFinancials"/>,
/// mirroring <c>AccountsController.CanSeeFullAccountFinancials</c>) and
/// lead-values masking (<see cref="AiToolCallerFacts.LeadView"/>'s
/// <c>CanSeeValues</c>, mirroring <c>CanSeeAccountLeadValues</c>) apply
/// exactly as they would in the app.
/// </summary>
public sealed class GetAccountTool : IAiTool
{
    private readonly AccountProcess _accounts;
    public GetAccountTool(AccountProcess accounts) => _accounts = accounts;

    public string ActionType => AiActionTypes.Read;

    public AiToolSpec Spec { get; } = new(
        "get_account",
        "Fetch one account by id, masked exactly as it would render for this caller (financials/lead-values hidden per their permissions).",
        new JsonSchema("""
        {"type":"object","properties":{"account_id":{"type":"string","format":"uuid"}},"required":["account_id"]}
        """),
        AiToolRiskClass.Read,
        Idempotent: true);

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, JsonElement args, Guid invocationId, CancellationToken ct = default)
    {
        var accountId = AiToolArgs.GetGuid(args, "account_id");
        if (accountId is null)
            return AiToolResult.Refused("\"account_id\" is required and must be a UUID.");

        var outcome = await _accounts.GetAsync(
            caller.Access, caller.CanSeeAccountFinancials, accountId.Value,
            caller.LeadView.CallerRole, caller.LeadView.CanSeeValues, ct);
        if (outcome.Refusal is not null || outcome.Detail is null)
            return AiToolResult.Refused(outcome.Refusal?.Reason ?? "Account not found.");

        return AiToolResult.Ok(AiToolArgs.ToResultJson(outcome.Detail));
    }
}

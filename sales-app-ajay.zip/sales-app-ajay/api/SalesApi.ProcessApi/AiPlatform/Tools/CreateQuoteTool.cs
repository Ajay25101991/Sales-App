using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Leads;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// <c>create_quote</c> — slice 10 (design §7.1, §15 slice 10; owner decision
/// 2026-09-28: its own <see cref="AiActionTypes.CreateQuote"/> action-policy
/// row, seeded at <c>recommend</c> for every org via
/// <c>AiActionPolicySeedService</c> — see that class's own "IDEMPOTENT" remark
/// for why adding the constant to <see cref="AiActionTypes.All"/> is the whole
/// backfill, no separate migration data needed).
///
/// A thin wrapper over <see cref="LeadQuoteProcess.GenerateAsync"/> — the SAME
/// <c>POST /leads/{id}/proposal</c> path a manual "generate a quote" click
/// uses: MANAGE access to the lead, the org's own module catalogue, and the
/// org's own currency/tax defaults, all unchanged.
/// </summary>
public sealed class CreateQuoteTool : IAiTool
{
    private readonly LeadQuoteProcess _quotes;
    public CreateQuoteTool(LeadQuoteProcess quotes) => _quotes = quotes;

    public string ActionType => AiActionTypes.CreateQuote;

    public AiToolSpec Spec { get; } = new(
        "create_quote",
        "Generate a quote (proposal) for a lead from its selected catalogue modules. Requires manage access to the lead.",
        new JsonSchema("""
        {"type":"object","properties":{
          "lead_id":{"type":"string","format":"uuid"},
          "module_ids":{"type":"array","items":{"type":"string","format":"uuid"}}
        },"required":["lead_id"]}
        """),
        AiToolRiskClass.Write,
        Idempotent: false);

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, JsonElement args, Guid invocationId, CancellationToken ct = default)
    {
        var leadId = AiToolArgs.GetGuid(args, "lead_id");
        if (leadId is null)
            return AiToolResult.Refused("\"lead_id\" is required and must be a UUID.");

        var moduleIds = AiToolArgs.GetGuidList(args, "module_ids");
        var input = new GenerateProposalInput(moduleIds);

        var (refusal, dto) = await _quotes.GenerateAsync(caller.Access, caller.Access.UserId, leadId.Value, input);
        if (refusal is not null || dto is null)
            return AiToolResult.Refused(refusal?.Reason ?? "Could not generate a quote for this lead.");

        return AiToolResult.Ok(AiToolArgs.ToResultJson(dto), [dto.Id]);
    }
}

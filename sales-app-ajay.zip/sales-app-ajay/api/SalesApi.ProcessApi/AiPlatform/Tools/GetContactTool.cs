using System.Text.Json;
using SalesApi.Models;
using SalesApi.ProcessLayer.Contacts;
using SalesApi.Services;

namespace SalesApi.ProcessLayer.AiPlatform.Tools;

/// <summary>
/// <c>get_contact</c> — a thin wrapper over <see cref="ContactProcess.GetAsync"/>,
/// the SAME <c>GET /contacts/{id}</c> read path a manual call uses. Contact
/// visibility is routed through the owning account
/// (<c>ContactProcess.GetAsync</c>'s own doc comment), and — per that same
/// comment — "there is no partial view of a contact today, only 'may see this
/// contact' or not", gated by <c>contact_details.view</c> at the controller.
/// This tool mirrors that: a caller without
/// <see cref="AiToolCallerFacts.LeadView"/>'s <c>CanSeeContactDetails</c> is
/// refused before the underlying read, never handed a contact with fields
/// silently blanked (there is nothing to blank — email/phone/name are the
/// whole point of a contact record).
/// </summary>
public sealed class GetContactTool : IAiTool
{
    private readonly ContactProcess _contacts;
    public GetContactTool(ContactProcess contacts) => _contacts = contacts;

    public string ActionType => AiActionTypes.Read;

    public AiToolSpec Spec { get; } = new(
        "get_contact",
        "Fetch one contact by id. Refused if the caller lacks contact_details.view.",
        new JsonSchema("""
        {"type":"object","properties":{"contact_id":{"type":"string","format":"uuid"}},"required":["contact_id"]}
        """),
        AiToolRiskClass.Read,
        Idempotent: true);

    public async Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, JsonElement args, Guid invocationId, CancellationToken ct = default)
    {
        // E12.2: a reader whose contact details are MASKED is served the masked contact (the mapper masks it); only a
        // reader who cannot reach the category at all (hidden) is refused. No access on the view = the old boolean.
        var mayReach = caller.LeadView.Sensitive is { } sensitive
            ? SensitiveLevels.CanReach(sensitive.RoleLevel(SensitiveCategories.ContactDetails))
            : caller.LeadView.CanSeeContactDetails;
        if (!mayReach)
            return AiToolResult.Refused("This caller does not have contact_details.view.");

        var contactId = AiToolArgs.GetGuid(args, "contact_id");
        if (contactId is null)
            return AiToolResult.Refused("\"contact_id\" is required and must be a UUID.");

        var outcome = await _contacts.GetAsync(caller.Access, contactId.Value, caller.LeadView.CallerRole, ct);
        if (outcome.Refusal is not null || outcome.Detail is null)
            return AiToolResult.Refused(outcome.Refusal?.Reason ?? "Contact not found.");

        return AiToolResult.Ok(AiToolArgs.ToResultJson(outcome.Detail));
    }
}

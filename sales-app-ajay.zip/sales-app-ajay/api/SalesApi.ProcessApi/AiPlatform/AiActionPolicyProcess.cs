using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.SystemLayer.AiPlatform;

namespace SalesApi.ProcessLayer.AiPlatform;

/// <summary>
/// The E4.8 action-risk-policy CRUD rules. Deliberately does NOT decide who
/// may write — "your role cannot manage AI actions" is a request-shaped fact
/// about the caller, not a rule about a policy row, so it stays on the
/// controller (same reasoning <c>MessageTemplateProcess</c>'s own header
/// gives for the identical split).
/// </summary>
public sealed class AiActionPolicyProcess
{
    private readonly AiActionPolicyStore _store;
    public AiActionPolicyProcess(AiActionPolicyStore store) => _store = store;

    public sealed record Refusal(string Reason, bool NotFound = false);

    public sealed record PolicyOutcome(Refusal? Refusal, AiActionPolicyDto? Policy)
    {
        public static PolicyOutcome Refused(Refusal r) => new(r, null);
        public static PolicyOutcome Ok(AiActionPolicyDto p) => new(null, p);
    }

    private static AiActionPolicyDto ToDto(AiActionPolicy p) =>
        new(p.ActionType, p.Autonomy, p.UpdatedAt, p.UpdatedById);

    public async Task<List<AiActionPolicyDto>> ListAsync(CancellationToken ct = default) =>
        [.. (await _store.ListAsync(ct)).Select(ToDto)];

    /// <summary>
    /// Updates the autonomy for one action type. The row itself is never
    /// created here — <see cref="Services.AiActionPolicySeedService"/> is the
    /// only writer of new rows (design §8.2's seeded-defaults guarantee: every
    /// org already has one row per known action type before an admin ever
    /// opens this screen), so an unknown action type here means either a
    /// stale client or a seeding gap, not "create it on the fly".
    /// </summary>
    public async Task<PolicyOutcome> SetAutonomyAsync(
        string actionType, AiActionPolicyInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!AiActionTypes.IsValid(actionType))
            return PolicyOutcome.Refused(new Refusal($"Unknown AI action type '{actionType}'.", NotFound: true));
        if (!AiAutonomyLevels.IsValid(input.Autonomy))
            return PolicyOutcome.Refused(new Refusal(
                $"Autonomy must be one of: {string.Join(", ", AiAutonomyLevels.All)}."));

        var policy = await _store.GetByActionTypeAsync(actionType, ct);
        if (policy is null)
            return PolicyOutcome.Refused(new Refusal($"AI action type '{actionType}' is not seeded for this org.", NotFound: true));

        policy.Autonomy = input.Autonomy!;
        policy.UpdatedAt = DateTime.UtcNow;
        policy.UpdatedById = actorId;
        await _store.SaveChangesAsync(ct);
        return PolicyOutcome.Ok(ToDto(policy));
    }
}

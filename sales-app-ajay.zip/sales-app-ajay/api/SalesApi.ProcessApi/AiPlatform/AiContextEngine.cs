using System.Globalization;
using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.ProcessLayer.Leads;
using SalesApi.Services;
using SalesApi.SystemLayer.CatalogItems;
using SalesApi.SystemLayer.Knowledge;

namespace SalesApi.ProcessLayer.AiPlatform;

/// <summary>
/// The E4.5 context engine (design doc to-do/e4-ai-platform-design.md §5,
/// §15 slice 7) — implements <see cref="IAiContextEngine"/> for entityType
/// "lead" only. Any other entity type is refused with
/// <see cref="NotSupportedException"/> naming it; the next entity type this
/// grows to cover gets its own fan-out branch, not a generic one guessed at
/// ahead of a second caller.
///
/// A FAN-OUT OVER <see cref="LeadReadProcess"/>'s OWN GOVERNED READS —
/// <see cref="LeadReadProcess.GetAsync"/> for the record (already masked by
/// <c>LeadMapping.ToDto</c>/<c>CustomFieldMasking</c> for THIS caller) and
/// <see cref="LeadReadProcess.TimelineAsync"/> for the timeline (already
/// masked the same way the timeline screen is). This class runs no query of
/// its own against <c>Lead</c>/<c>LeadActivity</c>/etc. — a field it cannot
/// see never reaches it in the first place, so there is no second masking
/// implementation to get wrong here.
/// </summary>
public sealed class AiContextEngine : IAiContextEngine
{
    private readonly LeadReadProcess _leads;
    private readonly KnowledgeStore _knowledge;
    private readonly AiProviderResolver _aiResolver;
    private readonly CatalogItemStore _catalog;

    public AiContextEngine(LeadReadProcess leads, KnowledgeStore knowledge, AiProviderResolver aiResolver, CatalogItemStore catalog)
    {
        _leads = leads;
        _knowledge = knowledge;
        _aiResolver = aiResolver;
        _catalog = catalog;
    }

    // One page of the lead's timeline is what the fan-out asks for — the same
    // single governed read a detail-screen open makes, at the widest page
    // size TimelineService offers. Ranking + budget trimming below decide
    // what actually survives into the assembled context; pulling further
    // pages here would only grow work that trimming immediately discards.
    private const int TimelinePageSize = 100;

    // Deterministic token estimate (chars / 4, rounded up) — no tokenizer
    // dependency for a v1 that only needs a stable, comparable number to trim
    // against. Not calibrated to any specific model's actual tokenizer.
    private static int EstimateTokens(string text) =>
        string.IsNullOrEmpty(text) ? 0 : (int)Math.Ceiling(text.Length / 4.0);

    /// <summary>
    /// In-code default ranking weights, keyed by <see cref="AiContextItem.Kind"/>
    /// (design §5.2: "recency + explicit skill-declared weights ... if
    /// slice 6's AiSkillVersion has no place for weights, use a small in-code
    /// default weight table"). `AiSkillVersion` has no weight column today —
    /// verified against SalesApi.SystemApi/Models/AiSkill.cs — so `purpose`
    /// is accepted (it is part of the interface's designed signature, §5.1)
    /// but not yet consulted here. Per-skill weights are a follow-up once the
    /// registry grows a place to declare them.
    /// </summary>
    private const double RecordFieldWeight = 100;
    private const double StageOrApprovalWeight = 60;
    private const double ActivityWeight = 40;
    private const double OtherTimelineWeight = 20;

    private static double WeightFor(string kind) => kind switch
    {
        RecordFieldKind => RecordFieldWeight,
        TimelineKinds.LeadStageChanged => StageOrApprovalWeight,
        TimelineKinds.ApprovalRequested => StageOrApprovalWeight,
        TimelineKinds.ApprovalDecided => StageOrApprovalWeight,
        TimelineKinds.ActivityLogged => ActivityWeight,
        _ => OtherTimelineWeight,
    };

    private const string RecordFieldKind = "lead_field";

    // --- E4.6 slice 12: the knowledge fan-out (design §5.2 step 5, §6) ------

    private const string KnowledgeChunkKind = "knowledge_chunk";

    /// <summary>Placed between the stage/approval tier and the plain-activity
    /// tier: a knowledge-base fact is more deliberately curated than an
    /// ordinary logged activity, but is not as directly about THIS lead as its
    /// own stage history — an in-code default like every other weight here
    /// (see this class's own weight-table doc comment on why `purpose` isn't
    /// consulted yet).</summary>
    private const double KnowledgeChunkWeight = 50;

    /// <summary>How many of the scope-filtered candidate chunks survive into
    /// the context, by similarity — a technical/product choice, named rather
    /// than left as a magic number. Kept small: this is added to a budget the
    /// record + timeline already compete for, and a low-similarity 20th match
    /// is worse than not spending the tokens.</summary>
    private const int KnowledgeTopN = 5;

    public async Task<AiContext> GetContextAsync(
        RecordAccessContext caller, LeadView leadView, bool canSeeFinancials,
        string entityType, Guid entityId, string purpose, int tokenBudget,
        CancellationToken ct = default)
    {
        if (entityType != "lead")
            throw new NotSupportedException($"AiContextEngine does not support entity type '{entityType}' yet.");

        var (refusal, lead) = await _leads.GetAsync(caller, leadView, entityId);
        if (refusal is not null || lead is null)
            throw new AiContextRefusedException(
                refusal?.Reason ?? "Lead not found", refusal?.NotFound ?? true, refusal?.Forbidden ?? false);

        // Same call the timeline screen itself makes for this lead — one
        // page, newest first, every kind (kinds: null).
        var (timelineRefusal, timelinePage) = await _leads.TimelineAsync(
            caller, leadView, canSeeFinancials, entityId, cursor: null, limit: TimelinePageSize, kinds: null);
        // Access to the lead already succeeded above via the same
        // RecordAccessContext/LeadView, so TimelineAsync cannot legitimately
        // refuse here — but if it ever does (e.g. a race with the lead being
        // deleted), give the caller the same refusal rather than silently
        // dropping the timeline half of the context.
        if (timelineRefusal is not null)
            throw new AiContextRefusedException(
                timelineRefusal.Reason, timelineRefusal.NotFound, timelineRefusal.Forbidden);

        var pairs = new List<(AiContextItem Item, AiContextSource Source, double Weight, DateTime OccurredAt)>();

        var productNames = await _catalog.NamesByKeyAsync(lead.Products ?? new List<string>());
        foreach (var (field, label, value) in RecordFields(lead, productNames))
        {
            if (value is null) continue;
            var text = $"{label}: {value}";
            pairs.Add((
                new AiContextItem(RecordFieldKind, null, text, EstimateTokens(text)),
                new AiContextSource("lead", null, field),
                RecordFieldWeight,
                lead.UpdatedAt));
        }

        if (lead.Custom.ValueKind == JsonValueKind.Object)
        {
            foreach (var prop in lead.Custom.EnumerateObject())
            {
                if (prop.Value.ValueKind == JsonValueKind.Null) continue;
                // The masking placeholder itself: CustomFieldMasking.Apply
                // rewrites a hidden key's value to this exact literal for a
                // caller who may not see it. No item, no source — the whole
                // point of the fan-out is that this caller never learns the
                // key exists, same as the field never rendering on the
                // detail screen for them.
                if (prop.Value.ValueKind == JsonValueKind.String && prop.Value.GetString() == CustomFieldMasking.Hidden)
                    continue;

                var value = prop.Value.ValueKind == JsonValueKind.String
                    ? prop.Value.GetString()
                    : prop.Value.GetRawText();
                if (string.IsNullOrEmpty(value)) continue;

                var field = $"custom.{prop.Name}";
                var text = $"{field}: {value}";
                pairs.Add((
                    new AiContextItem(RecordFieldKind, null, text, EstimateTokens(text)),
                    new AiContextSource("lead", null, field),
                    RecordFieldWeight,
                    lead.UpdatedAt));
            }
        }

        foreach (var t in timelinePage?.Items ?? [])
        {
            var text = string.IsNullOrEmpty(t.Detail) ? t.Summary : $"{t.Summary}: {t.Detail}";
            pairs.Add((
                new AiContextItem(t.Kind, t.SourceId, text, EstimateTokens(text)),
                new AiContextSource(t.Kind, t.SourceId, null),
                WeightFor(t.Kind),
                t.OccurredAt));
        }

        // Knowledge fan-out (design §5.2 step 5, §6.3): candidates are
        // ALREADY scope-filtered (team + skill) by the store's own query —
        // this step only ranks by similarity and never widens who may see
        // what. Never throws: an unavailable/refused embed leaves the
        // context built WITHOUT knowledge, flagged via KnowledgeUnavailable
        // below, exactly like the design brief's "no exception" instruction.
        var knowledgeUnavailable = false;
        try
        {
            var candidates = await _knowledge.CandidateChunksAsync(caller.Scope, purpose, ct);
            if (candidates.Count > 0)
            {
                var resolved = await _aiResolver.ResolveAsync(ct);
                if (resolved.Status != SalesApi.Services.AiProviderStatus.Ready)
                {
                    knowledgeUnavailable = true;
                }
                else
                {
                    // Query text: the lead's name + company (LeadDto has no
                    // standalone "title"/job-title field of its own — that
                    // lives on a contact, not the lead record this engine
                    // reads — so name + company is the closest identifying
                    // text available) plus the purpose (skill key), so the
                    // embedding leans toward what the SKILL is trying to do,
                    // not just which lead it is about.
                    var queryText = $"{lead.Name} {lead.Company} {purpose}".Trim();
                    var queryVector = await resolved.Platform!.EmbedAsync(
                        new AiEmbedRequest(_knowledge.CurrentOrgId, caller.UserId, purpose, queryText), ct);

                    var top = candidates
                        .Select(c => (Chunk: c, Score: CosineSimilarity(queryVector, c.Embedding)))
                        .OrderByDescending(x => x.Score)
                        .Take(KnowledgeTopN);

                    // Inserted already sorted best-first; OrderByDescending
                    // below is stable, so equal weight/recency preserves this
                    // similarity order among the knowledge items themselves.
                    var now = DateTime.UtcNow;
                    foreach (var (chunk, _) in top)
                    {
                        pairs.Add((
                            new AiContextItem(KnowledgeChunkKind, chunk.ChunkId, chunk.Text, EstimateTokens(chunk.Text)),
                            new AiContextSource(KnowledgeChunkKind, chunk.ChunkId, null),
                            KnowledgeChunkWeight,
                            now));
                    }
                }
            }
        }
        catch (AiRequestRefusedException)
        {
            knowledgeUnavailable = true;
        }
        catch (AiPlatformUnavailableException)
        {
            knowledgeUnavailable = true;
        }

        // Rank: weight tier first (record fields > stage/approval > knowledge
        // > activity > everything else), then recency within a tier — design
        // §5.2.
        var ranked = pairs
            .OrderByDescending(p => p.Weight)
            .ThenByDescending(p => p.OccurredAt)
            .ToList();

        // Budget: drop the LOWEST-ranked item WHOLE, repeatedly, until the
        // total fits — never truncate an item's text (design §5.2).
        var total = ranked.Sum(p => p.Item.EstimatedTokens);
        while (total > tokenBudget && ranked.Count > 0)
        {
            var dropped = ranked[^1];
            ranked.RemoveAt(ranked.Count - 1);
            total -= dropped.Item.EstimatedTokens;
        }

        return new AiContext(
            [.. ranked.Select(p => p.Item)],
            [.. ranked.Select(p => p.Source)],
            knowledgeUnavailable);
    }

    /// <summary>Standard cosine similarity — 0 for a shape mismatch or an
    /// all-zero vector on either side, rather than throwing (a chunk embedded
    /// under a different/older model dimensionality should score as "not
    /// similar", not blow up the whole context assembly).</summary>
    private static double CosineSimilarity(float[] a, float[] b)
    {
        if (a.Length == 0 || b.Length == 0 || a.Length != b.Length) return 0;
        double dot = 0, na = 0, nb = 0;
        for (var i = 0; i < a.Length; i++)
        {
            dot += a[i] * b[i];
            na += a[i] * a[i];
            nb += b[i] * b[i];
        }
        if (na == 0 || nb == 0) return 0;
        return dot / (Math.Sqrt(na) * Math.Sqrt(nb));
    }

    /// <summary>
    /// The non-custom <see cref="LeadDto"/> fields rendered as context items —
    /// design §5.2's "one item per non-null, non-hidden field". A field
    /// already masked for this caller (contact details / values) arrives here
    /// as null straight from <c>LeadMapping.ToDto</c>, so the null check below
    /// IS the masking gate; nothing here re-derives who may see what. Purely
    /// structural fields with no standalone display value (Id, OwnerId,
    /// AccountId, ContactId, PlaybookId, TeamId, the alpha-2 code twins of
    /// Country/Nationality/Phone, and Tags, which already has its own
    /// TagRefDto shape) are left out — their human-readable counterparts
    /// (OwnerName, AccountName, TeamName, Country, Nationality, Phone) are
    /// included instead.
    /// </summary>
    private static IEnumerable<(string Field, string Label, string? Value)> RecordFields(LeadDto l, IReadOnlyDictionary<string, string> productNames)
    {
        yield return ("name", "Name", l.Name);
        yield return ("company", "Company", l.Company);
        yield return ("email", "Email", l.Email);
        yield return ("phone", "Phone", l.Phone);
        yield return ("status", "Status", l.Status);
        yield return ("priority", "Priority", l.Priority);
        yield return ("source", "Source", l.Source);
        yield return ("estimated_value", "Estimated value",
            l.EstimatedValue?.ToString(CultureInfo.InvariantCulture));
        yield return ("notes", "Notes", l.Notes);
        yield return ("next_follow_up_at", "Next follow-up", DateStr(l.NextFollowUpAt));
        yield return ("owner_name", "Owner", l.OwnerName);
        yield return ("account_name", "Account", l.AccountName);
        yield return ("close_reason", "Close reason", l.CloseReason);
        yield return ("products", "Products", l.Products is { Count: > 0 } ? string.Join(", ", l.Products.Select(k => productNames.GetValueOrDefault(k, k))) : null);
        yield return ("address", "Address", l.Address);
        yield return ("city", "City", l.City);
        yield return ("state", "State", l.State);
        yield return ("postal_code", "Postal code", l.PostalCode);
        yield return ("country", "Country", l.Country);
        yield return ("nationality", "Nationality", l.Nationality);
        yield return ("expected_close_date", "Expected close date", DateStr(l.ExpectedCloseDate));
        yield return ("won_at", "Won at", DateStr(l.WonAt));
        yield return ("lost_at", "Lost at", DateStr(l.LostAt));
        yield return ("days_in_stage", "Days in stage", l.DaysInStage?.ToString(CultureInfo.InvariantCulture));
        yield return ("payment_term_key", "Payment term", l.PaymentTermKey);
        yield return ("payment_due_date", "Payment due date", DateStr(l.PaymentDueDate));
        yield return ("team_name", "Team", l.TeamName);
        yield return ("has_been_worked", "Has been worked", l.HasBeenWorked is bool w ? (w ? "Yes" : "No") : null);
        yield return ("deal_type", "Deal type", l.DealType);
    }

    private static string? DateStr(DateTime? dt) => dt?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
}

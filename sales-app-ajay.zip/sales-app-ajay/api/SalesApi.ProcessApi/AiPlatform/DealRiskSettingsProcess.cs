using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.SystemLayer.AiPlatform;

namespace SalesApi.ProcessLayer.AiPlatform;

/// <summary>
/// The E5.6 deal-risk threshold validation (story brief item 1: "validated,
/// positive numbers, Medium &lt;= High"). Deliberately does NOT decide who may
/// write — same split <see cref="AiCostPolicyProcess"/>'s own header gives.
/// </summary>
public sealed class DealRiskSettingsProcess
{
    private readonly DealRiskSettingsStore _store;
    public DealRiskSettingsProcess(DealRiskSettingsStore store) => _store = store;

    public sealed record Refusal(string Reason);

    public async Task<DealRiskSettingsDto> GetAsync(CancellationToken ct = default) =>
        ToDto(await _store.GetOrDefaultAsync(ct));

    public async Task<(DealRiskSettingsDto? Dto, Refusal? Refusal)> SaveAsync(
        DealRiskSettingsInput input, Guid actorId, CancellationToken ct = default)
    {
        var current = await _store.GetOrDefaultAsync(ct);

        // Validate against what the row will look like AFTER the merge —
        // Medium<=High must hold on the EFFECTIVE values, not just on
        // whichever field this particular PUT happened to include (a partial
        // save that only raises Medium above the row's still-unsent High
        // must be refused too, not just a save that submits both at once).
        var quietMedium = input.QuietDaysMedium ?? current.QuietDaysMedium;
        var quietHigh = input.QuietDaysHigh ?? current.QuietDaysHigh;
        var pushesMedium = input.CloseDatePushesMedium ?? current.CloseDatePushesMedium;
        var pushesHigh = input.CloseDatePushesHigh ?? current.CloseDatePushesHigh;
        var multiplierMedium = input.StageAgeMedianMultiplierMedium ?? current.StageAgeMedianMultiplierMedium;
        var multiplierHigh = input.StageAgeMedianMultiplierHigh ?? current.StageAgeMedianMultiplierHigh;
        var fallbackMedium = input.StageAgeFallbackMediumDays ?? current.StageAgeFallbackMediumDays;
        var fallbackHigh = input.StageAgeFallbackHighDays ?? current.StageAgeFallbackHighDays;
        var minSamples = input.MinCompletedStageSamples ?? current.MinCompletedStageSamples;
        var timing = input.RecalculationTiming ?? current.RecalculationTiming;

        if (quietMedium <= 0 || quietHigh <= 0) return (null, new Refusal("Quiet-days thresholds must be positive."));
        if (quietMedium > quietHigh) return (null, new Refusal("Quiet-days Medium cannot exceed High."));

        if (pushesMedium <= 0 || pushesHigh <= 0) return (null, new Refusal("Close-date-push thresholds must be positive."));
        if (pushesMedium > pushesHigh) return (null, new Refusal("Close-date-push Medium cannot exceed High."));

        if (multiplierMedium <= 0 || multiplierHigh <= 0) return (null, new Refusal("Stage-age multipliers must be positive."));
        if (multiplierMedium > multiplierHigh) return (null, new Refusal("Stage-age multiplier Medium cannot exceed High."));

        if (fallbackMedium <= 0 || fallbackHigh <= 0) return (null, new Refusal("Stage-age fallback days must be positive."));
        if (fallbackMedium > fallbackHigh) return (null, new Refusal("Stage-age fallback Medium cannot exceed High."));

        if (minSamples <= 0) return (null, new Refusal("Minimum completed samples must be positive."));

        if (!DealRiskRecalculationTimings.All.Contains(timing))
            return (null, new Refusal($"Recalculation timing must be one of: {string.Join(", ", DealRiskRecalculationTimings.All)}."));

        var saved = await _store.SaveAsync(input, actorId, ct);
        return (ToDto(saved), null);
    }

    private static DealRiskSettingsDto ToDto(DealRiskSettings s) => new(
        s.QuietDaysMedium, s.QuietDaysHigh, s.CloseDatePushesMedium, s.CloseDatePushesHigh,
        s.StageAgeMedianMultiplierMedium, s.StageAgeMedianMultiplierHigh,
        s.StageAgeFallbackMediumDays, s.StageAgeFallbackHighDays,
        s.MinCompletedStageSamples, s.RecalculationTiming);
}

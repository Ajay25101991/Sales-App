using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.SystemLayer.AiPlatform;

namespace SalesApi.ProcessLayer.AiPlatform;

/// <summary>
/// The E4.2 execution-log read rules and the text-capture toggle's
/// validation. Deliberately does NOT decide who may read — same split
/// <see cref="AiActionPolicyProcess"/>'s own header gives.
/// </summary>
public sealed class AiExecutionLogProcess
{
    private readonly AiExecutionLogStore _store;
    public AiExecutionLogProcess(AiExecutionLogStore store) => _store = store;

    public sealed record Refusal(string Reason, bool NotFound = false);

    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private static AiExecutionLogEntryDto ToDto(AiExecutionLogEntry e) => new(
        e.Id, e.UserId, e.Feature, e.Skill, e.SkillVersion, e.Provider, e.ModelId,
        e.Outcome, e.ErrorMessage, e.LatencyMs, e.InputTokens, e.OutputTokens,
        e.EstimatedCostUsd, e.ApprovalOutcome, e.UserFeedback, e.OccurredAt,
        e.UserFeedbackReasonChip, e.UserFeedbackReasonText);

    public async Task<PagedResult<AiExecutionLogEntryDto>> ListAsync(
        Guid? userId, string? feature, string? outcome, DateTime? from, DateTime? to,
        string? cursor, int? limit, CancellationToken ct = default)
    {
        var page = await _store.ListPageAsync(userId, feature, outcome, from, to, cursor, limit, ct);
        return new PagedResult<AiExecutionLogEntryDto>([.. page.Items.Select(ToDto)], page.NextCursor);
    }

    /// <summary>The full trace: the row, plus captured text if any exists and
    /// hasn't expired (design brief: "GET /admin/ai-log/{id} — full trace (the
    /// row; plus captured text if any exists and not expired)"). Citations and
    /// proposed-tool arg field names are parsed from their JSON columns here,
    /// never re-derived from anything that could carry a real value.</summary>
    public async Task<(AiExecutionLogDetailDto? Detail, Refusal? Refusal)> GetAsync(Guid id, CancellationToken ct = default)
    {
        var entry = await _store.GetAsync(id, ct);
        if (entry is null) return (null, new Refusal("AI log entry not found.", NotFound: true));

        var sources = ParseOrEmpty<AiContextSourceDto>(entry.ContextSourcesJson);
        var tools = ParseOrEmpty<AiToolProposedDto>(entry.ToolsProposedJson);
        var captured = await _store.GetCapturedTextAsync(id, ct);

        return (new AiExecutionLogDetailDto(ToDto(entry), sources, tools, captured?.PromptText, captured?.CompletionText), null);
    }

    public async Task<AiTextCaptureStatusDto> GetCaptureStatusAsync(CancellationToken ct = default)
    {
        var row = await _store.GetCaptureSettingAsync(ct);
        var active = row?.CaptureUntil is { } until && until > DateTime.UtcNow;
        return new AiTextCaptureStatusDto(active, row?.CaptureUntil);
    }

    public const int MinCaptureDays = 1;
    public const int MaxCaptureDays = 30;

    public async Task<(AiTextCaptureStatusDto? Status, Refusal? Refusal)> SetCaptureAsync(
        AiTextCaptureInput input, Guid actorId, CancellationToken ct = default)
    {
        if (input.Off == true)
        {
            var offRow = await _store.SetCaptureAsync(null, actorId, ct);
            return (new AiTextCaptureStatusDto(false, offRow.CaptureUntil), null);
        }

        if (input.Days is not { } days || days < MinCaptureDays || days > MaxCaptureDays)
            return (null, new Refusal($"Days must be between {MinCaptureDays} and {MaxCaptureDays}."));

        var until = DateTime.UtcNow.AddDays(days);
        var row = await _store.SetCaptureAsync(until, actorId, ct);
        return (new AiTextCaptureStatusDto(true, row.CaptureUntil), null);
    }

    private static List<T> ParseOrEmpty<T>(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return new List<T>();
        try { return JsonSerializer.Deserialize<List<T>>(json, JsonOptions) ?? new List<T>(); }
        catch (JsonException) { return new List<T>(); }
    }
}

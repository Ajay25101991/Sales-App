using System.Net.Mail;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.ProcessLayer.Contacts;
using SalesApi.ProcessLayer.SavedViews;
using SalesApi.Services;
using SalesApi.SystemLayer.Campaigns;
using SalesApi.SystemLayer.Contacts;
using SalesApi.SystemLayer.SavedViews;

namespace SalesApi.ProcessLayer.Campaigns;

/// <summary>
/// E21 - email campaigns, the screen-facing half: create and edit a draft, see who it would reach, preview a message, test-send it to yourself, schedule and
/// cancel it, and read the results. The rules of WHO is reached are the contacts list's own (<see cref="ContactProcess.AudienceAsync"/> over the saved view)
/// and WHO may do what is the caller's own record access; sending itself is <see cref="CampaignSendProcess"/>.
///
/// A campaign is always MARKETING mail, so every message is built by <see cref="CampaignEmailComposer"/> (marketing kind, unsubscribe headers and link) and
/// goes through the guarded sender chain <see cref="MarketingEmailResolver"/> hands back (opt-out, bounced, undeliverable, sandbox) - the preview, the test
/// send and the live send share one builder, so a rep sees what the contact will get.
///
/// Only a DRAFT is edited; a scheduled one is cancelled (and, if needed, copied into a new draft by the screen). Only a draft is deleted - a campaign that
/// has started keeps its results.
/// </summary>
public sealed class CampaignProcess
{
    public const int SampleSize = 25;
    public const int MaxPageSize = 200;
    public const int DefaultPageSize = 50;
    private const int MaxNameLength = 200;

    private readonly CampaignStore _store;
    private readonly ContactProcess _contacts;
    private readonly ContactStore _contactStore;
    private readonly SavedViewProcess _views;
    private readonly SavedViewStore _viewStore;
    private readonly MarketingEmailResolver _marketing;
    private readonly UnsubscribeTokenService _tokens;
    private readonly IConfiguration _config;
    private readonly TimeProvider _clock;

    public CampaignProcess(
        CampaignStore store, ContactProcess contacts, ContactStore contactStore, SavedViewProcess views, SavedViewStore viewStore,
        MarketingEmailResolver marketing, UnsubscribeTokenService tokens, IConfiguration config, TimeProvider? clock = null)
    {
        _store = store;
        _contacts = contacts;
        _contactStore = contactStore;
        _views = views;
        _viewStore = viewStore;
        _marketing = marketing;
        _tokens = tokens;
        _config = config;
        _clock = clock ?? TimeProvider.System;
    }

    public sealed record Refusal(string Reason, bool NotFound = false, bool Forbidden = false, bool Conflict = false, string? Code = null);

    public sealed record Result<T>(Refusal? Refusal, T? Value)
    {
        public static Result<T> Ok(T value) => new(null, value);
        public static Result<T> Fail(Refusal r) => new(r, default);
        public static Result<T> Fail(string reason) => new(new Refusal(reason), default);
        public static Result<T> NotFound(string reason) => new(new Refusal(reason, NotFound: true), default);
        public static Result<T> Conflict(string reason, string? code = null) => new(new Refusal(reason, Conflict: true, Code: code), default);
    }

    private DateTime Now => _clock.GetUtcNow().UtcDateTime;

    // ---- reads ------------------------------------------------------------------------------------------------------------

    public async Task<List<CampaignDto>> ListAsync(string? status = null, CancellationToken ct = default)
    {
        var campaigns = await _store.CampaignsAsync(string.IsNullOrWhiteSpace(status) ? null : status, ct);
        var counts = await _store.CountsAsync(campaigns.Select(c => c.Id), ct);
        var templates = await _store.MessageTemplatesAsync(campaigns.SelectMany(c => c.Templates).Select(t => t.MessageTemplateId), ct);
        return campaigns.Select(c => ToDto(c, counts[c.Id], templates)).ToList();
    }

    public async Task<Result<CampaignDto>> GetAsync(Guid id, CancellationToken ct = default)
    {
        var c = await _store.CampaignAsync(id, ct);
        return c is null ? Result<CampaignDto>.NotFound("Campaign not found") : Result<CampaignDto>.Ok(await ToDtoAsync(c, ct));
    }

    private async Task<CampaignDto> ToDtoAsync(Campaign c, CancellationToken ct)
    {
        var counts = await _store.CountsAsync([c.Id], ct);
        var templates = await _store.MessageTemplatesAsync(c.Templates.Select(t => t.MessageTemplateId), ct);
        return ToDto(c, counts[c.Id], templates);
    }

    private static CampaignDto ToDto(Campaign c, CampaignStore.StatusCounts n, List<MessageTemplate> templates) => new(
        c.Id, c.Name, c.SavedViewId, c.ContactRole, c.ContactOwnRole, c.FallbackLanguage, c.FromAddressId, c.FromAddress?.Address, c.FromAddress?.DisplayName,
        c.ReplyTo, c.Status, c.ScheduledAt, c.ScheduledById, c.StartedAt, c.CompletedAt, c.CancelledAt, c.FailureReason,
        c.Templates.OrderBy(t => t.Language).Select(t =>
        {
            var m = templates.FirstOrDefault(x => x.Id == t.MessageTemplateId);
            return new CampaignTemplateDto(t.Language, t.MessageTemplateId, m?.Name, m?.Subject);
        }).ToList(),
        new CampaignTotalsDto(n.Queued, n.Sent, n.Suppressed, n.Failed, n.Bounced, n.Complained, n.Unsubscribed),
        c.CreatedById, c.CreatedAt, c.UpdatedAt);

    /// <summary>GET /campaigns/{id}/recipients: the send queue, oldest first, optionally one status.</summary>
    public async Task<Result<CampaignRecipientPageDto>> RecipientsAsync(
        Guid id, string? status, int? limit, int? offset, CancellationToken ct = default)
    {
        if (status is not null && !CampaignRecipientStatuses.All.Contains(status))
            return Result<CampaignRecipientPageDto>.Fail("status must be one of: " + string.Join(", ", CampaignRecipientStatuses.All));
        if (await _store.CampaignAsync(id, ct) is null) return Result<CampaignRecipientPageDto>.NotFound("Campaign not found");

        var take = Math.Clamp(limit ?? DefaultPageSize, 1, MaxPageSize);
        var skip = Math.Max(offset ?? 0, 0);
        var (items, total) = await _store.RecipientPageAsync(id, status, skip, take, ct);
        return Result<CampaignRecipientPageDto>.Ok(new CampaignRecipientPageDto(
            items.Select(r => new CampaignRecipientDto(r.Id, r.ContactId, r.Address, r.Language, r.Status, r.Error, r.QueuedAt, r.SentAt, r.UnsubscribedAt)).ToList(),
            total, take, skip));
    }

    // ---- create / edit / delete a draft -----------------------------------------------------------------------------------------

    private sealed record Checked(
        string Name, Guid SavedViewId, string? Role, string? OwnRole, string Fallback, Guid FromAddressId, string? ReplyTo, List<(string Language, Guid TemplateId)> Templates);

    public async Task<Result<CampaignDto>> CreateAsync(RecordAccessContext ctx, CampaignInput input, CancellationToken ct = default)
    {
        var (valid, refusal) = await CheckAsync(ctx, input, ct);
        if (valid is null) return Result<CampaignDto>.Fail(refusal!);

        var campaign = new Campaign { Id = Guid.NewGuid(), CreatedById = ctx.UserId, CreatedAt = Now };
        Apply(campaign, valid);
        _store.Add(campaign);
        await _store.SaveChangesAsync(ct);
        return Result<CampaignDto>.Ok(await ToDtoAsync((await _store.CampaignAsync(campaign.Id, ct))!, ct));
    }

    public async Task<Result<CampaignDto>> UpdateAsync(RecordAccessContext ctx, Guid id, CampaignInput input, CancellationToken ct = default)
    {
        var campaign = await _store.CampaignAsync(id, ct);
        if (campaign is null) return Result<CampaignDto>.NotFound("Campaign not found");
        if (campaign.Status != CampaignStatuses.Draft) return Result<CampaignDto>.Conflict("Only a draft campaign can be edited.");

        var (valid, refusal) = await CheckAsync(ctx, input, ct);
        if (valid is null) return Result<CampaignDto>.Fail(refusal!);

        // The old wording goes first, in its own save: a language kept under the same campaign would otherwise meet its own row on the unique (campaign, language) index.
        foreach (var old in campaign.Templates.ToList()) _store.Remove(old);
        campaign.Templates.Clear();
        await _store.SaveChangesAsync(ct);
        Apply(campaign, valid);
        // Added explicitly: a new row reached only through the tracked collection, with its Id already set, is taken for an existing row and UPDATEd.
        foreach (var t in campaign.Templates) _store.Add(t);
        campaign.UpdatedAt = Now;
        await _store.SaveChangesAsync(ct);
        return Result<CampaignDto>.Ok(await ToDtoAsync((await _store.CampaignAsync(id, ct))!, ct));
    }

    public async Task<Refusal?> DeleteAsync(Guid id, CancellationToken ct = default)
    {
        var campaign = await _store.CampaignAsync(id, ct);
        if (campaign is null) return new Refusal("Campaign not found", NotFound: true);
        if (campaign.Status != CampaignStatuses.Draft)
            return new Refusal("Only a draft campaign can be deleted; one that has been scheduled keeps its results.", Conflict: true);
        _store.Remove(campaign);
        await _store.SaveChangesAsync(ct);
        return null;
    }

    private static void Apply(Campaign c, Checked v)
    {
        c.Name = v.Name;
        c.SavedViewId = v.SavedViewId;
        c.ContactRole = v.Role;
        c.ContactOwnRole = v.OwnRole;
        c.FallbackLanguage = v.Fallback;
        c.FromAddressId = v.FromAddressId;
        c.ReplyTo = v.ReplyTo;
        foreach (var (language, templateId) in v.Templates)
            c.Templates.Add(new CampaignTemplate { Id = Guid.NewGuid(), CampaignId = c.Id, Language = language, MessageTemplateId = templateId });
    }

    private async Task<(Checked? Valid, Refusal? Refusal)> CheckAsync(RecordAccessContext ctx, CampaignInput input, CancellationToken ct)
    {
        Refusal Bad(string reason) => new(reason);

        var name = input.Name?.Trim() ?? "";
        if (name.Length == 0) return (null, Bad("name is required"));
        if (name.Length > MaxNameLength) return (null, Bad($"name must be at most {MaxNameLength} characters"));

        if (input.SavedViewId is not Guid viewId) return (null, Bad("saved_view_id is required"));
        if (await ViewRefusalAsync(ctx, viewId, ct) is { } viewRefusal) return (null, viewRefusal);

        if (input.FromAddressId is not Guid fromId) return (null, Bad("from_address_id is required"));
        if (await _store.FromAddressAsync(fromId, ct) is null) return (null, Bad("from_address_id is not one of the org's marketing from-addresses"));

        string? replyTo = string.IsNullOrWhiteSpace(input.ReplyTo) ? null : input.ReplyTo.Trim();
        if (replyTo is not null && (replyTo.Length > 320 || !MailAddress.TryCreate(replyTo, out _))) return (null, Bad("reply_to is not a valid email address"));

        if (!string.IsNullOrWhiteSpace(input.FallbackLanguage) && !MessageMergeFields.IsLanguageCode(input.FallbackLanguage))
            return (null, Bad("fallback_language is not a valid language code"));
        var fallback = MessageMergeFields.NormalizeLanguage(input.FallbackLanguage);

        var role = string.IsNullOrWhiteSpace(input.ContactRole) ? null : input.ContactRole.Trim();
        if (role is { Length: > 100 }) return (null, Bad("contact_role must be at most 100 characters"));
        var ownRole = string.IsNullOrWhiteSpace(input.ContactOwnRole) ? null : input.ContactOwnRole.Trim();
        if (ownRole is { Length: > 100 }) return (null, Bad("contact_own_role must be at most 100 characters"));

        var templates = new List<(string Language, Guid TemplateId)>();
        foreach (var t in input.Templates ?? [])
        {
            if (!MessageMergeFields.IsLanguageCode(t.Language)) return (null, Bad("each template needs a valid language"));
            if (t.MessageTemplateId is not Guid templateId) return (null, Bad("each template needs a message_template_id"));
            var language = MessageMergeFields.NormalizeLanguage(t.Language);
            if (templates.Any(x => x.Language == language)) return (null, Bad($"there is more than one template for language '{language}'"));
            templates.Add((language, templateId));
        }
        if (templates.Count == 0) return (null, Bad("at least one template is required"));
        if (templates.All(t => t.Language != fallback)) return (null, Bad($"there must be a template for the fallback language '{fallback}'"));

        var found = await _store.MessageTemplatesAsync(templates.Select(t => t.TemplateId), ct);
        foreach (var (language, templateId) in templates)
        {
            var m = found.FirstOrDefault(x => x.Id == templateId);
            if (m is null) return (null, Bad("a message template was not found"));
            if (MessageMergeFields.NormalizeLanguage(m.Language) != language)
                return (null, Bad($"message template '{m.Name}' is written in '{m.Language}', not '{language}'"));
            if (string.IsNullOrWhiteSpace(m.Subject)) return (null, Bad($"message template '{m.Name}' has no subject line"));
        }

        return (new Checked(name, viewId, role, ownRole, fallback, fromId, replyTo, templates), null);
    }

    /// <summary>The saved view must exist, be a view of the CONTACTS list and be one the caller may open (their own, org-wide, or shared with a team they are on).</summary>
    private async Task<Refusal?> ViewRefusalAsync(RecordAccessContext ctx, Guid viewId, CancellationToken ct)
    {
        var caller = new SavedViewProcess.Caller(ctx.UserId, ctx.IsOrgAdmin, await _viewStore.LiveTeamIdsForUserAsync(ctx.UserId, ct));
        var (dto, refusal) = await _views.GetAsync(caller, viewId, ct);
        if (dto is null) return new Refusal(refusal?.Reason ?? "Saved view not found.");
        return dto.List == SavedView.Lists.Contacts ? null : new Refusal("The saved view must be a view of the contacts list.");
    }

    // ---- who it would reach -------------------------------------------------------------------------------------------------

    /// <summary>The contacts list's inputs a saved view stores: the search box, similarity and the one-table column filters (a JSON list). Columns, sorts and widths are ignored.</summary>
    internal static ContactProcess.AudienceParams AudienceOf(SavedView view, string? role, string? ownRole = null)
    {
        string? search = null, filters = null;
        double? similarity = null;
        try
        {
            using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(view.DefinitionJson) ? "{}" : view.DefinitionJson);
            var root = doc.RootElement;
            if (root.ValueKind == JsonValueKind.Object)
            {
                if (root.TryGetProperty("search", out var s) && s.ValueKind == JsonValueKind.String) search = s.GetString();
                if (root.TryGetProperty("similarity", out var sim) && sim.ValueKind == JsonValueKind.Number) similarity = sim.GetDouble();
                if (root.TryGetProperty("filters", out var f) && f.ValueKind == JsonValueKind.Array && f.GetArrayLength() > 0) filters = f.GetRawText();
            }
        }
        catch (JsonException) { /* an unreadable definition is an empty one: the whole list */ }
        return new ContactProcess.AudienceParams(search, similarity, filters, role, ownRole);
    }

    internal sealed record Classified(ContactProcess.AudienceContact Contact, string? Address, string Outcome, string? Reason);

    public static class Outcomes
    {
        public const string WillSend = "will_send";
        public const string OptedOut = "opted_out";
        public const string Undeliverable = "undeliverable";
        public const string NoEmail = "no_email";
        public const string Duplicate = "duplicate";
    }

    /// <summary>
    /// Sorts an audience into who will be mailed and who will not, and why. The rules are the send guards' own, applied up front so a preview can say what the send
    /// will do: no address; opted out (the contact itself, or any contact of the org on the same address); undeliverable (a reserved domain, or an address the provider
    /// reported bounced); the same address as an earlier contact (mailed once). The send still runs every message through the guarded chain - a contact who opts out
    /// after this ran is caught there.
    /// </summary>
    internal async Task<List<Classified>> ClassifyAsync(List<ContactProcess.AudienceContact> audience, CancellationToken ct)
    {
        var addresses = audience.Select(a => a.Email?.Trim().ToLowerInvariant()).Where(a => !string.IsNullOrEmpty(a)).Select(a => a!).Distinct().ToList();
        var optedOut = await _store.OptedOutAddressesAsync(addresses, ct);
        var bounced = await _store.UndeliverableAddressesAsync(addresses, ct);

        var seen = new HashSet<string>();
        var result = new List<Classified>(audience.Count);
        foreach (var contact in audience)
        {
            var address = contact.Email?.Trim();
            if (string.IsNullOrEmpty(address)) { result.Add(new(contact, null, Outcomes.NoEmail, "no_email")); continue; }
            var lower = address.ToLowerInvariant();
            if (contact.EmailOptedOutAt != null || optedOut.Contains(lower)) { result.Add(new(contact, address, Outcomes.OptedOut, OptOutGuardEmailSender.Reason)); continue; }
            if (UndeliverableRecipientGuardEmailSender.Undeliverable(address) is { } why) { result.Add(new(contact, address, Outcomes.Undeliverable, why)); continue; }
            if (bounced.Contains(lower)) { result.Add(new(contact, address, Outcomes.Undeliverable, BouncedAddressGuardEmailSender.Reason)); continue; }
            if (!seen.Add(lower)) { result.Add(new(contact, address, Outcomes.Duplicate, "duplicate_address")); continue; }
            result.Add(new(contact, address, Outcomes.WillSend, null));
        }
        return result;
    }

    /// <summary>The audience of one campaign for the caller's record access, or the reason it cannot be resolved.</summary>
    internal async Task<(List<ContactProcess.AudienceContact>? Audience, Refusal? Refusal)> AudienceForAsync(
        Campaign campaign, RecordAccessContext ctx, bool canViewContactDetails, string callerRole, CancellationToken ct)
    {
        var view = await _store.SavedViewAsync(campaign.SavedViewId, ct);
        if (view is null) return (null, new Refusal("The saved view this campaign sends to has been deleted."));
        if (view.List != SavedView.Lists.Contacts) return (null, new Refusal("The saved view is not a view of the contacts list."));
        var outcome = await _contacts.AudienceAsync(ctx, canViewContactDetails, callerRole, AudienceOf(view, campaign.ContactRole, campaign.ContactOwnRole), ct);
        return outcome.Refusal is { } r ? (null, new Refusal("The saved view's filters could not be applied: " + r.Reason, Code: r.Code)) : (outcome.Contacts, null);
    }

    /// <summary>GET /campaigns/{id}/recipients-preview: the counts, and a sample, of who the campaign would reach if it started now with the CALLER's access.</summary>
    public async Task<Result<CampaignAudienceDto>> PreviewAudienceAsync(
        RecordAccessContext ctx, bool canViewContactDetails, string callerRole, Guid id, CancellationToken ct = default)
    {
        var campaign = await _store.CampaignAsync(id, ct);
        if (campaign is null) return Result<CampaignAudienceDto>.NotFound("Campaign not found");
        var (audience, refusal) = await AudienceForAsync(campaign, ctx, canViewContactDetails, callerRole, ct);
        if (audience is null) return Result<CampaignAudienceDto>.Fail(refusal!);

        var classified = await ClassifyAsync(audience, ct);
        int Count(string outcome) => classified.Count(c => c.Outcome == outcome);
        return Result<CampaignAudienceDto>.Ok(new CampaignAudienceDto(
            classified.Count, Count(Outcomes.WillSend), Count(Outcomes.OptedOut), Count(Outcomes.Undeliverable), Count(Outcomes.NoEmail), Count(Outcomes.Duplicate),
            classified.Take(SampleSize)
                .Select(c => new CampaignAudienceSampleDto(c.Contact.Id, c.Contact.Name, c.Address, PickLanguage(campaign, c.Contact.PreferredLanguage), c.Outcome)).ToList()));
    }

    // ---- building the message ------------------------------------------------------------------------------------------------

    /// <summary>The language this contact is written to: their own when the campaign has a template for it, else the campaign's fallback language.</summary>
    internal static string PickLanguage(Campaign campaign, string? contactLanguage)
    {
        var wanted = MessageMergeFields.NormalizeLanguage(contactLanguage);
        return campaign.Templates.Any(t => t.Language == wanted) ? wanted : campaign.FallbackLanguage;
    }

    /// <summary>The unsubscribe link for a token, on the server's public address; null when the server has none (marketing mail without a working link is not sent).</summary>
    internal string? UnsubscribeUrl(UnsubscribePayload payload)
    {
        var baseUrl = PublicBaseUrl.From(_config);
        return baseUrl is null ? null : $"{baseUrl}/unsubscribe/{_tokens.Sign(payload)}";
    }

    internal async Task<Dictionary<Guid, MessageTemplate>> TemplatesOfAsync(Campaign campaign, CancellationToken ct) =>
        (await _store.MessageTemplatesAsync(campaign.Templates.Select(t => t.MessageTemplateId), ct)).ToDictionary(t => t.Id);

    /// <summary>
    /// Builds the one email of a campaign for one person, or null when no template can be found (the contact's language and the fallback both missing - a template
    /// deleted after the campaign was saved). <paramref name="recipientId"/> is the queue row (Guid.Empty for a preview or a test send, whose unsubscribe link then
    /// does nothing).
    /// </summary>
    internal EmailMessage? Compose(
        Campaign campaign, IReadOnlyDictionary<Guid, MessageTemplate> templates, string language, string to, string? name, string? company,
        Guid recipientId, Guid contactId)
    {
        var chosen = campaign.Templates.FirstOrDefault(t => t.Language == language) ?? campaign.Templates.FirstOrDefault(t => t.Language == campaign.FallbackLanguage);
        if (chosen is null || !templates.TryGetValue(chosen.MessageTemplateId, out var template)) return null;
        var link = UnsubscribeUrl(new UnsubscribePayload(campaign.OrgId ?? Guid.Empty, recipientId, contactId));
        if (link is null || campaign.FromAddress is null) return null;

        return CampaignEmailComposer.Compose(new CampaignMailInput(
            to, name, company, chosen.Language, template.Subject, template.Body, campaign.Name,
            campaign.FromAddress.Address, campaign.FromAddress.DisplayName, campaign.ReplyTo,
            link, _config["Campaigns:UnsubscribeMailto"],
            new Dictionary<string, string>
            {
                [CampaignEmailComposer.CampaignTag] = campaign.Id.ToString(),
                [CampaignEmailComposer.RecipientTag] = recipientId.ToString(),
            }));
    }

    /// <summary>GET /campaigns/{id}/preview?contact_id=: the message one contact would get. The contact must be one the caller may view.</summary>
    public async Task<Result<CampaignPreviewDto>> PreviewMessageAsync(RecordAccessContext ctx, Guid id, Guid contactId, CancellationToken ct = default)
    {
        var campaign = await _store.CampaignAsync(id, ct);
        if (campaign is null) return Result<CampaignPreviewDto>.NotFound("Campaign not found");
        var contact = await _contactStore.LoadWithAccountAsync(contactId, ct);
        if (contact is null || contact.Account is null || !RecordAccess.CanView(ctx, contact.Account.OwnerId, contact.Account.TeamId))
            return Result<CampaignPreviewDto>.NotFound("Contact not found");

        var templates = await TemplatesOfAsync(campaign, ct);
        var language = PickLanguage(campaign, contact.PreferredLanguage);
        var message = Compose(campaign, templates, language, contact.Email ?? "", contact.Name, contact.Company ?? contact.Account.Name, Guid.Empty, Guid.Empty);
        if (message is null) return Result<CampaignPreviewDto>.Conflict("The message cannot be built: a template is missing or the server has no public address for the unsubscribe link.");
        return Result<CampaignPreviewDto>.Ok(new CampaignPreviewDto(
            language, message.FromAddress!, message.FromName, message.ReplyTo, message.Subject, message.TextBody, message.HtmlBody));
    }

    /// <summary>
    /// POST /campaigns/{id}/test-send: the campaign's message to the CALLER's own address - never anyone else's, whatever contact fills the merge fields.
    /// It goes through the same marketing sender chain, so a misconfigured SES refuses it and an opted-out or bounced address of the caller's is suppressed.
    /// </summary>
    public async Task<Result<CampaignTestSendDto>> TestSendAsync(RecordAccessContext ctx, Guid id, CampaignTestSendInput input, CancellationToken ct = default)
    {
        var campaign = await _store.CampaignAsync(id, ct);
        if (campaign is null) return Result<CampaignTestSendDto>.NotFound("Campaign not found");
        if (!string.IsNullOrWhiteSpace(input.Language) && !MessageMergeFields.IsLanguageCode(input.Language))
            return Result<CampaignTestSendDto>.Fail("language is not a valid language code");

        var me = await _store.ProfileAsync(ctx.UserId, ct);
        if (me is null || string.IsNullOrWhiteSpace(me.Email)) return Result<CampaignTestSendDto>.Fail("Your profile has no email address to send the test to.");

        string? name = me.Name, company = null;
        var language = string.IsNullOrWhiteSpace(input.Language) ? campaign.FallbackLanguage : MessageMergeFields.NormalizeLanguage(input.Language);
        if (input.ContactId is Guid contactId)
        {
            var contact = await _contactStore.LoadWithAccountAsync(contactId, ct);
            if (contact is null || contact.Account is null || !RecordAccess.CanView(ctx, contact.Account.OwnerId, contact.Account.TeamId))
                return Result<CampaignTestSendDto>.NotFound("Contact not found");
            (name, company) = (contact.Name, contact.Company ?? contact.Account.Name);
            if (string.IsNullOrWhiteSpace(input.Language)) language = PickLanguage(campaign, contact.PreferredLanguage);
        }

        var provider = await _marketing.ResolveAsync(ct);
        if (provider.Status != EmailProviderStatus.Ready)
            return Result<CampaignTestSendDto>.Conflict(provider.Reason ?? "Marketing email is not available.", "marketing_email_unavailable");

        var templates = await TemplatesOfAsync(campaign, ct);
        var message = Compose(campaign, templates, language, me.Email, name, company, Guid.Empty, Guid.Empty);
        if (message is null) return Result<CampaignTestSendDto>.Conflict("The message cannot be built: a template is missing or the server has no public address for the unsubscribe link.");
        message = message with { Subject = "[Test] " + message.Subject };

        var sent = await provider.Sender!.SendAsync(message, ct);
        return Result<CampaignTestSendDto>.Ok(new CampaignTestSendDto(
            sent.Accepted && sent.Outcome == EmailDeliveryOutcome.Sent, me.Email, sent.Accepted && sent.Outcome == EmailDeliveryOutcome.Sent ? null : sent.Reason));
    }

    // ---- schedule / cancel --------------------------------------------------------------------------------------------------------

    /// <summary>
    /// POST /campaigns/{id}/schedule. Sets the time (now, or the given UTC time; a time already past means now), records WHO scheduled it - their record access is
    /// what the audience is resolved with when the send starts - and moves the campaign to scheduled. Refused while marketing mail cannot be sent (SES not
    /// configured, email switched off, no public address for the unsubscribe link): better to say so now than to find out at the send time.
    /// </summary>
    public async Task<Result<CampaignDto>> ScheduleAsync(RecordAccessContext ctx, Guid id, CampaignScheduleInput input, CancellationToken ct = default)
    {
        var campaign = await _store.CampaignAsync(id, ct);
        if (campaign is null) return Result<CampaignDto>.NotFound("Campaign not found");
        if (campaign.Status is not (CampaignStatuses.Draft or CampaignStatuses.Scheduled))
            return Result<CampaignDto>.Conflict($"A {campaign.Status} campaign cannot be scheduled.");
        if (await ViewRefusalAsync(ctx, campaign.SavedViewId, ct) is { } viewRefusal) return Result<CampaignDto>.Fail(viewRefusal);

        var provider = await _marketing.ResolveAsync(ct);
        if (provider.Status != EmailProviderStatus.Ready)
            return Result<CampaignDto>.Conflict(provider.Reason ?? "Marketing email is not available.", "marketing_email_unavailable");
        if (PublicBaseUrl.From(_config) is null)
            return Result<CampaignDto>.Conflict("The server has no public address, so the unsubscribe link cannot be built.", "no_public_url");

        var now = Now;
        var at = input.Now == true || input.ScheduledAt is null ? now : AsUtc(input.ScheduledAt.Value);
        campaign.ScheduledAt = at < now ? now : at;
        campaign.ScheduledById = ctx.UserId;
        campaign.Status = CampaignStatuses.Scheduled;
        campaign.FailureReason = null;
        campaign.UpdatedAt = now;
        await _store.SaveChangesAsync(ct);
        return Result<CampaignDto>.Ok(await ToDtoAsync(campaign, ct));
    }

    private static DateTime AsUtc(DateTime t) => t.Kind switch
    {
        DateTimeKind.Utc => t,
        DateTimeKind.Local => t.ToUniversalTime(),
        _ => DateTime.SpecifyKind(t, DateTimeKind.Utc),
    };

    /// <summary>POST /campaigns/{id}/cancel: a scheduled or sending campaign stops. Rows still queued are never sent; those already sent stay sent.</summary>
    public async Task<Result<CampaignDto>> CancelAsync(Guid id, CancellationToken ct = default)
    {
        var campaign = await _store.CampaignAsync(id, ct);
        if (campaign is null) return Result<CampaignDto>.NotFound("Campaign not found");
        if (campaign.Status is not (CampaignStatuses.Scheduled or CampaignStatuses.Sending))
            return Result<CampaignDto>.Conflict($"A {campaign.Status} campaign cannot be cancelled.");
        campaign.Status = CampaignStatuses.Cancelled;
        campaign.CancelledAt = campaign.UpdatedAt = Now;
        await _store.SaveChangesAsync(ct);
        return Result<CampaignDto>.Ok(await ToDtoAsync(campaign, ct));
    }
}

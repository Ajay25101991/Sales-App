using System.Text.Json;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.Campaigns;
using SalesApi.SystemLayer.Contacts;

namespace SalesApi.ProcessLayer.Campaigns;

/// <summary>
/// E21 - what comes back from outside, with no signed-in caller: a contact using the unsubscribe link in a campaign email, and Amazon SES telling us (through SNS)
/// that a message bounced, was complained about or was delivered. Both are public endpoints, so each proves itself first - the link by its HMAC token
/// (<see cref="UnsubscribeTokenService"/>), the notice by its SNS signature (<see cref="SnsMessageVerifier"/>) - and only then reaches the database, scoped to
/// the org the proof names.
///
/// OWNER DECISIONS (2026-11-05): a hard (Permanent) bounce marks the address undeliverable for ALL email; a complaint opts the contact out of marketing email;
/// soft (Transient) bounces are counted per address and 3 in a row make it undeliverable, a delivery resetting the count. Opt-outs go through
/// <see cref="ContactConsentStore"/> so the consent log records them with their source ("unsubscribe_link" or "complaint"); undeliverability is an
/// <see cref="EmailAddressHealth"/> row, which <see cref="BouncedAddressGuardEmailSender"/> reads on every send.
///
/// Every handler is idempotent: SNS delivers at least once, links get clicked twice and mail clients prefetch them.
/// </summary>
public sealed class CampaignFeedbackProcess
{
    /// <summary>Soft bounces in a row (no delivery between) after which an address is undeliverable.</summary>
    public const int SoftBounceLimit = 3;

    private readonly CampaignStore _store;
    private readonly ContactConsentStore _consent;
    private readonly ContactStore _contacts;
    private readonly UnsubscribeTokenService _tokens;
    private readonly SnsMessageVerifier _sns;
    private readonly TimeProvider _clock;

    public CampaignFeedbackProcess(
        CampaignStore store, ContactConsentStore consent, ContactStore contacts, UnsubscribeTokenService tokens, SnsMessageVerifier sns, TimeProvider? clock = null)
    {
        _store = store;
        _consent = consent;
        _contacts = contacts;
        _tokens = tokens;
        _sns = sns;
        _clock = clock ?? TimeProvider.System;
    }

    private DateTime Now => _clock.GetUtcNow().UtcDateTime;

    // ---- unsubscribe -----------------------------------------------------------------------------------------------------------

    /// <summary>Whether a token is one we signed (no database read) - the GET page only offers the button for a good link.</summary>
    public bool IsValidUnsubscribeToken(string? token) => _tokens.TryRead(token, out _);

    /// <summary>
    /// POST of the unsubscribe link, including the RFC 8058 one-click POST a mail client sends on its own: opts the contact out of EMAIL, source
    /// "unsubscribe_link", and stamps the campaign recipient. False for a token that is not ours. Using it again changes nothing (the first opt-out date stands, no
    /// second log line); a test send's link, or a contact deleted since, is a quiet success.
    /// </summary>
    public async Task<bool> UnsubscribeAsync(string? token, CancellationToken ct = default)
    {
        if (!_tokens.TryRead(token, out var payload)) return false;
        if (payload.IsTest) return true;

        _store.UseTenant(payload.OrgId);
        var now = Now;
        var recipient = payload.RecipientId == Guid.Empty ? null : await _store.RecipientAsync(payload.RecipientId, ct);
        var campaignName = recipient is null ? null : await _store.CampaignNameAsync(recipient.CampaignId, ct);
        var contact = await _contacts.LoadWithAccountAsync(payload.ContactId, ct);
        if (contact is not null)
            _consent.StageOptOut(contact, ConsentChannels.Email, ConsentSources.UnsubscribeLink,
                campaignName is null ? "campaign unsubscribe link" : $"campaign unsubscribe link: {campaignName}", null, now);
        if (recipient is not null && recipient.UnsubscribedAt is null) recipient.UnsubscribedAt = now;
        await _store.SaveChangesAsync(ct);
        return true;
    }

    // ---- SNS -------------------------------------------------------------------------------------------------------------------

    public enum SnsOutcome { Handled, Unverified, Malformed }

    /// <summary>
    /// The body of one SNS HTTP delivery. Verified before anything else (a bad signature, a certificate off an SNS host or a topic we did not subscribe to is
    /// <see cref="SnsOutcome.Unverified"/>, and nothing is read from it). A SubscriptionConfirmation is confirmed; a Notification is an SES event.
    /// </summary>
    public async Task<SnsOutcome> HandleSnsAsync(string body, CancellationToken ct = default)
    {
        SnsMessage? message;
        try { message = ParseSns(body); }
        catch (JsonException) { return SnsOutcome.Malformed; }
        if (message is null) return SnsOutcome.Malformed;

        if (!await _sns.VerifyAsync(message, ct)) return SnsOutcome.Unverified;

        switch (message.Type)
        {
            case "SubscriptionConfirmation":
                return await _sns.ConfirmAsync(message, ct) ? SnsOutcome.Handled : SnsOutcome.Unverified;
            case "Notification":
                await HandleSesEventAsync(message.Message, ct);
                return SnsOutcome.Handled;
            default:
                return SnsOutcome.Handled;   // UnsubscribeConfirmation: nothing to do
        }
    }

    private static SnsMessage? ParseSns(string body)
    {
        using var doc = JsonDocument.Parse(body);
        var root = doc.RootElement;
        if (root.ValueKind != JsonValueKind.Object) return null;
        string? Str(string name) => root.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

        var type = Str("Type");
        var messageId = Str("MessageId");
        var topic = Str("TopicArn");
        var message = Str("Message");
        var timestamp = Str("Timestamp");
        var version = Str("SignatureVersion");
        var signature = Str("Signature");
        var certUrl = Str("SigningCertURL");
        if (type is null || messageId is null || topic is null || message is null || timestamp is null || version is null || signature is null || certUrl is null)
            return null;
        return new SnsMessage(type, messageId, topic, Str("Subject"), message, timestamp, version, signature, certUrl, Str("SubscribeURL"), Str("Token"));
    }

    // ---- SES events ------------------------------------------------------------------------------------------------------------

    /// <summary>
    /// One SES event (the JSON inside a verified SNS notification): a Bounce, Complaint or Delivery for a message we sent, found by the message id SES returned. An
    /// event for a message that is not a campaign's, or that is not JSON (SES's own set-up notices), is ignored.
    /// </summary>
    public async Task HandleSesEventAsync(string json, CancellationToken ct = default)
    {
        JsonDocument doc;
        try { doc = JsonDocument.Parse(json); }
        catch (JsonException) { return; }

        using (doc)
        {
            var root = doc.RootElement;
            if (root.ValueKind != JsonValueKind.Object) return;
            var eventType = Str(root, "eventType") ?? Str(root, "notificationType");
            if (!root.TryGetProperty("mail", out var mail) || Str(mail, "messageId") is not { } messageId) return;

            var recipient = await _store.RecipientByProviderMessageIdAsync(messageId, ct);
            if (recipient is null || recipient.OrgId is not Guid orgId) return;
            _store.UseTenant(orgId);
            var now = Now;

            switch (eventType)
            {
                case "Bounce" when root.TryGetProperty("bounce", out var bounce):
                    await OnBounceAsync(recipient, bounce, now, ct);
                    break;
                case "Complaint" when root.TryGetProperty("complaint", out var complaint):
                    await OnComplaintAsync(recipient, complaint, now, ct);
                    break;
                case "Delivery" when root.TryGetProperty("delivery", out var delivery):
                    await OnDeliveryAsync(recipient, delivery, ct);
                    break;
            }
            await _store.SaveChangesAsync(ct);
        }
    }

    private static string? Str(JsonElement e, string name) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    /// <summary>The addresses a notice lists under <paramref name="list"/> (bouncedRecipients, complainedRecipients, recipients), else the message's own.</summary>
    private static List<string> AddressesOf(JsonElement e, string list, string? key, CampaignRecipient fallback)
    {
        var found = new List<string>();
        if (e.TryGetProperty(list, out var items) && items.ValueKind == JsonValueKind.Array)
            foreach (var item in items.EnumerateArray())
            {
                var address = key is null ? (item.ValueKind == JsonValueKind.String ? item.GetString() : null) : Str(item, key);
                if (!string.IsNullOrWhiteSpace(address)) found.Add(address.Trim());
            }
        if (found.Count == 0 && !string.IsNullOrWhiteSpace(fallback.Address)) found.Add(fallback.Address);
        return found.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    private async Task OnBounceAsync(CampaignRecipient recipient, JsonElement bounce, DateTime now, CancellationToken ct)
    {
        var addresses = AddressesOf(bounce, "bouncedRecipients", "emailAddress", recipient);
        var permanent = Str(bounce, "bounceType") == "Permanent";
        // A notice SNS delivers twice must not count twice: only the first bounce of THIS message moves its row and the address's soft count.
        var firstForMessage = recipient.Status is not (CampaignRecipientStatuses.Bounced or CampaignRecipientStatuses.Complained);

        foreach (var address in addresses)
        {
            var health = await _store.HealthAsync(address, ct);
            if (permanent)
            {
                MarkUndeliverable(health, "hard_bounce", now);
            }
            else if (firstForMessage)
            {
                health.SoftBounceCount++;
                health.LastSoftBounceAt = now;
                if (health.SoftBounceCount >= SoftBounceLimit) MarkUndeliverable(health, "soft_bounces", now);
            }
            health.UpdatedAt = now;
        }

        if (recipient.Status != CampaignRecipientStatuses.Complained)
        {
            recipient.Status = CampaignRecipientStatuses.Bounced;
            recipient.Error = permanent ? "hard_bounce" : "soft_bounce";
            recipient.UpdatedAt = now;
        }
    }

    private static void MarkUndeliverable(EmailAddressHealth health, string reason, DateTime now)
    {
        if (health.UndeliverableAt is not null) return;
        health.UndeliverableAt = now;
        health.UndeliverableReason = reason;
    }

    private async Task OnComplaintAsync(CampaignRecipient recipient, JsonElement complaint, DateTime now, CancellationToken ct)
    {
        var contacts = new Dictionary<Guid, Contact>();
        foreach (var address in AddressesOf(complaint, "complainedRecipients", "emailAddress", recipient))
            foreach (var contact in await _consent.ContactsByEmailAsync(address, ct)) contacts[contact.Id] = contact;
        // The contact the mail was sent to, even if its address has changed since.
        if (!contacts.ContainsKey(recipient.ContactId) && await _contacts.LoadWithAccountAsync(recipient.ContactId, ct) is { } own) contacts[own.Id] = own;

        foreach (var contact in contacts.Values)
            _consent.StageOptOut(contact, ConsentChannels.Email, ConsentSources.Complaint, "marked a campaign email as spam", null, now);

        recipient.Status = CampaignRecipientStatuses.Complained;
        recipient.Error = "complaint";
        recipient.UpdatedAt = now;
    }

    private async Task OnDeliveryAsync(CampaignRecipient recipient, JsonElement delivery, CancellationToken ct)
    {
        foreach (var address in AddressesOf(delivery, "recipients", null, recipient))
        {
            // Only an address the provider has complained about before has a row; a delivery to a clean one writes nothing.
            if (await _store.HealthOrNullAsync(address, ct) is not { } health) continue;
            health.SoftBounceCount = 0;
            health.LastDeliveredAt = Now;
            health.UpdatedAt = Now;
        }
    }
}

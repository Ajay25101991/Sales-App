using System.Net.Mail;
using SalesApi.Dtos;
using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.Campaigns;

namespace SalesApi.ProcessLayer.Campaigns;

/// <summary>
/// E21 - what an admin sets up before anyone sends a campaign: the marketing from-addresses (each on an SES-verified domain; a campaign must pick one), the org's
/// send rate (<c>campaign_sends_per_second</c>, default 1) and, optionally, the org's own SES region / configuration-set name over the deployment's. These are org
/// settings, not hard-coded rules (business policy is the org's), and the controller gates every WRITE on settings.manage.
/// </summary>
public sealed class CampaignSettingsProcess
{
    private const int MaxAddressLength = 320;
    private const int MaxDisplayNameLength = 200;

    private readonly CampaignStore _store;
    private readonly OrgSettingsReader _settings;
    private readonly MarketingEmailResolver _marketing;
    private readonly TimeProvider _clock;

    public CampaignSettingsProcess(CampaignStore store, OrgSettingsReader settings, MarketingEmailResolver marketing, TimeProvider? clock = null)
    {
        _store = store;
        _settings = settings;
        _marketing = marketing;
        _clock = clock ?? TimeProvider.System;
    }

    private static MarketingFromAddressDto ToDto(MarketingFromAddress a) => new(a.Id, a.Address, a.DisplayName, a.CreatedAt);

    public async Task<List<MarketingFromAddressDto>> FromAddressesAsync(CancellationToken ct = default) =>
        (await _store.FromAddressesAsync(ct)).Select(ToDto).ToList();

    private static (string? Address, string? DisplayName, string? Error) Check(MarketingFromAddressInput input)
    {
        var address = input.Address?.Trim() ?? "";
        if (address.Length == 0 || address.Length > MaxAddressLength || !MailAddress.TryCreate(address, out var parsed) || parsed.Address != address)
            return (null, null, "address must be a plain email address");
        var name = input.DisplayName?.Trim() ?? "";
        if (name.Length == 0) return (null, null, "display_name is required");
        if (name.Length > MaxDisplayNameLength) return (null, null, $"display_name must be at most {MaxDisplayNameLength} characters");
        return (address, name, null);
    }

    public async Task<CampaignProcess.Result<MarketingFromAddressDto>> CreateFromAddressAsync(MarketingFromAddressInput input, CancellationToken ct = default)
    {
        var (address, name, error) = Check(input);
        if (error is not null) return CampaignProcess.Result<MarketingFromAddressDto>.Fail(error);
        if (await _store.FromAddressExistsAsync(address!, null, ct)) return CampaignProcess.Result<MarketingFromAddressDto>.Conflict("That from-address already exists.");

        var row = new MarketingFromAddress { Id = Guid.NewGuid(), Address = address!, DisplayName = name!, CreatedAt = _clock.GetUtcNow().UtcDateTime };
        _store.Add(row);
        await _store.SaveChangesAsync(ct);
        return CampaignProcess.Result<MarketingFromAddressDto>.Ok(ToDto(row));
    }

    public async Task<CampaignProcess.Result<MarketingFromAddressDto>> UpdateFromAddressAsync(Guid id, MarketingFromAddressInput input, CancellationToken ct = default)
    {
        var row = await _store.FromAddressAsync(id, ct);
        if (row is null) return CampaignProcess.Result<MarketingFromAddressDto>.NotFound("From-address not found");
        var (address, name, error) = Check(input);
        if (error is not null) return CampaignProcess.Result<MarketingFromAddressDto>.Fail(error);
        if (await _store.FromAddressExistsAsync(address!, id, ct)) return CampaignProcess.Result<MarketingFromAddressDto>.Conflict("That from-address already exists.");

        row.Address = address!;
        row.DisplayName = name!;
        row.UpdatedAt = _clock.GetUtcNow().UtcDateTime;
        await _store.SaveChangesAsync(ct);
        return CampaignProcess.Result<MarketingFromAddressDto>.Ok(ToDto(row));
    }

    public async Task<CampaignProcess.Refusal?> DeleteFromAddressAsync(Guid id, CancellationToken ct = default)
    {
        var row = await _store.FromAddressAsync(id, ct);
        if (row is null) return new CampaignProcess.Refusal("From-address not found", NotFound: true);
        if (await _store.FromAddressInUseAsync(id, ct))
            return new CampaignProcess.Refusal("A campaign uses this from-address, so it cannot be removed.", Conflict: true);
        _store.Remove(row);
        await _store.SaveChangesAsync(ct);
        return null;
    }

    // ---- send rate and SES ---------------------------------------------------------------------------------------------------

    public async Task<CampaignSettingsDto> GetSettingsAsync(CancellationToken ct = default)
    {
        var provider = await _marketing.ResolveAsync(ct);
        var ready = provider.Status == EmailProviderStatus.Ready;
        return new CampaignSettingsDto(
            await _settings.GetCampaignSendsPerSecondAsync(), await _settings.GetCampaignSesRegionAsync(), await _settings.GetCampaignSesConfigurationSetAsync(),
            ready, ready ? null : provider.Reason);
    }

    public async Task<CampaignProcess.Result<CampaignSettingsDto>> SaveSettingsAsync(CampaignSettingsInput input, CancellationToken ct = default)
    {
        if (input.SendsPerSecond is int rate && (rate < OrgSettings.MinCampaignSendsPerSecond || rate > OrgSettings.MaxCampaignSendsPerSecond))
            return CampaignProcess.Result<CampaignSettingsDto>.Fail(
                $"sends_per_second must be between {OrgSettings.MinCampaignSendsPerSecond} and {OrgSettings.MaxCampaignSendsPerSecond}");
        if (input.SesRegion is { Length: > 40 } || input.SesConfigurationSet is { Length: > 64 })
            return CampaignProcess.Result<CampaignSettingsDto>.Fail("ses_region or ses_configuration_set is too long");

        if (input.SendsPerSecond is int perSecond) await _settings.SetCampaignSendsPerSecondAsync(perSecond);
        if (input.SesRegion is not null || input.SesConfigurationSet is not null)
            await _settings.SetCampaignSesAsync(
                input.SesRegion ?? await _settings.GetCampaignSesRegionAsync(), input.SesConfigurationSet ?? await _settings.GetCampaignSesConfigurationSetAsync());
        return CampaignProcess.Result<CampaignSettingsDto>.Ok(await GetSettingsAsync(ct));
    }
}

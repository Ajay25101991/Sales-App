using SalesApi.Models;
using SalesApi.Services;
using SalesApi.SystemLayer.Campaigns;
using SalesApi.SystemLayer.Contacts;

namespace SalesApi.ProcessLayer.Campaigns;

/// <summary>
/// E21 - the send queue, one tick at a time. The worker (<c>CampaignSendWorker</c>) calls <see cref="RunDueAsync"/> once a second per org that has work, inside
/// that org's own scope, so one org's failure never stops another's.
///
/// A tick does four things, in this order:
/// <list type="number">
/// <item><b>Starts due campaigns.</b> A scheduled campaign whose time has come resolves its audience NOW, with the record access of the person who scheduled
/// it (their id was stored; the access context is rebuilt here, so a role revoked since is honoured and a deactivated user stops the campaign), and writes one
/// <see cref="CampaignRecipient"/> per contact: queued, or already suppressed when the contact opted out / the address is undeliverable. The rows and the move to
/// "sending" are one save.</item>
/// <item><b>Settles stale claims.</b> A queued row claimed long ago means a worker died between taking it and writing its outcome - the mail may or may not have
/// left, so the row is marked failed and NEVER retried: a possible missed mail is better than a certain double send.</item>
/// <item><b>Sends a batch</b> of at most the org's <c>campaign_sends_per_second</c> rows. Each is claimed atomically first (<see cref="CampaignStore.TryClaimAsync"/>),
/// then sent through the guarded marketing chain; the outcome (sent, suppressed - an opt-out or undeliverable address is NOT a failure - or failed) is saved row by row.
/// A terminal row is never claimed again, so a retry of the whole tick cannot double-send.</item>
/// <item><b>Completes</b> sending campaigns with nothing left queued.</item>
/// </list>
/// A marketing sender that is not ready (SES unconfigured, email switched off) PAUSES sending with the reason on the campaign - it does not fail the rows and it
/// never falls back to another provider; fix the setting and the next tick resumes.
/// </summary>
public sealed class CampaignSendProcess
{
    /// <summary>How long a claim may sit before the row is treated as abandoned by a dead worker.</summary>
    public static readonly TimeSpan StaleClaimAfter = TimeSpan.FromMinutes(10);

    private readonly CampaignStore _store;
    private readonly CampaignProcess _campaigns;
    private readonly ContactStore _contactStore;
    private readonly RecordAccessContextFactory _access;
    private readonly MarketingEmailResolver _marketing;
    private readonly OrgSettingsReader _settings;
    private readonly TimeProvider _clock;

    public CampaignSendProcess(
        CampaignStore store, CampaignProcess campaigns, ContactStore contactStore, RecordAccessContextFactory access,
        MarketingEmailResolver marketing, OrgSettingsReader settings, TimeProvider? clock = null)
    {
        _store = store;
        _campaigns = campaigns;
        _contactStore = contactStore;
        _access = access;
        _marketing = marketing;
        _settings = settings;
        _clock = clock ?? TimeProvider.System;
    }

    public sealed record TickResult(int Started, int Claimed, int Sent, int Suppressed, int Failed, int Completed);

    private DateTime Now => _clock.GetUtcNow().UtcDateTime;

    /// <summary>The orgs with campaign work due now (crosses tenants - the worker calls it from a scope with no org).</summary>
    public Task<List<Guid>> OrgIdsWithWorkAsync(CancellationToken ct = default) => _store.OrgIdsWithWorkAsync(Now, ct);

    public async Task<TickResult> RunDueAsync(CancellationToken ct = default)
    {
        var now = Now;

        var started = 0;
        foreach (var campaign in await _store.DueScheduledAsync(now, ct))
            if (await StartAsync(campaign, now, ct)) started++;

        foreach (var stale in await _store.StaleClaimsAsync(now - StaleClaimAfter, ct))
        {
            stale.Status = CampaignRecipientStatuses.Failed;
            stale.Error = "The send was interrupted before its result was recorded. It was not retried, so the contact is never mailed twice.";
            stale.UpdatedAt = now;
        }
        await _store.SaveChangesAsync(ct);

        int claimed = 0, sent = 0, suppressed = 0, failed = 0;
        var perSecond = await _settings.GetCampaignSendsPerSecondAsync();
        var candidates = await _store.ClaimCandidatesAsync(perSecond, ct);
        var provider = candidates.Count > 0 ? await _marketing.ResolveAsync(ct) : null;
        if (provider is not null && provider.Status == EmailProviderStatus.Ready)
        {
            var campaigns = new Dictionary<Guid, (Campaign Campaign, Dictionary<Guid, MessageTemplate> Templates)?>();
            foreach (var row in candidates)
            {
                if (!await _store.TryClaimAsync(row, now, ct)) continue;
                claimed++;
                var outcome = await SendOneAsync(row, provider, campaigns, now, ct);
                if (outcome == CampaignRecipientStatuses.Sent) sent++;
                else if (outcome == CampaignRecipientStatuses.Suppressed) suppressed++;
                else failed++;
            }
        }

        var completed = 0;
        foreach (var campaign in await _store.SendingAsync(ct))
        {
            if (provider is not null && provider.Status != EmailProviderStatus.Ready)
            {
                campaign.FailureReason = provider.Reason;   // paused, not failed: the rows stay queued
                continue;
            }
            campaign.FailureReason = null;
            if (await _store.HasQueuedAsync(campaign.Id, ct)) continue;
            campaign.Status = CampaignStatuses.Sent;
            campaign.CompletedAt = campaign.UpdatedAt = now;
            completed++;
        }
        await _store.SaveChangesAsync(ct);
        return new TickResult(started, claimed, sent, suppressed, failed, completed);
    }

    private async Task<bool> StartAsync(Campaign campaign, DateTime now, CancellationToken ct)
    {
        async Task<bool> StopAsync(string reason)
        {
            campaign.Status = CampaignStatuses.Cancelled;
            campaign.CancelledAt = campaign.UpdatedAt = now;
            campaign.FailureReason = reason.Length > 500 ? reason[..500] : reason;
            await _store.SaveChangesAsync(ct);
            return false;
        }

        // A crash after the rows were written but before this ran again cannot queue anyone twice: the rows are the proof.
        if (!await _store.HasRecipientsAsync(campaign.Id, ct))
        {
            if (campaign.ScheduledById is not Guid scheduler) return await StopAsync("No one is recorded as having scheduled this campaign.");
            var access = await _access.CallerAccessForUserAsync(scheduler, ct);
            if (access is null) return await StopAsync("The person who scheduled this campaign is no longer an active user.");

            var (audience, refusal) = await _campaigns.AudienceForAsync(campaign, access.Context, access.CanViewContactDetails, access.BaseRole, ct);
            if (audience is null) return await StopAsync(refusal!.Reason);

            var rows = (await _campaigns.ClassifyAsync(audience, ct))
                .Where(c => c.Address is not null)
                // QueuedAt keeps the audience's (name) order: the queue is sent oldest first, so the send order is the same on every run.
                .Select((c, i) => new CampaignRecipient
                {
                    Id = Guid.NewGuid(),
                    CampaignId = campaign.Id,
                    ContactId = c.Contact.Id,
                    Address = c.Address!,
                    Language = CampaignProcess.PickLanguage(campaign, c.Contact.PreferredLanguage),
                    Status = c.Outcome == CampaignProcess.Outcomes.WillSend ? CampaignRecipientStatuses.Queued : CampaignRecipientStatuses.Suppressed,
                    Error = c.Reason,
                    QueuedAt = now.AddTicks(i),
                    UpdatedAt = now,
                }).ToList();
            _store.AddRange(rows);
        }
        campaign.Status = CampaignStatuses.Sending;
        campaign.StartedAt = now;
        campaign.FailureReason = null;
        campaign.UpdatedAt = now;
        await _store.SaveChangesAsync(ct);
        return true;
    }

    /// <summary>Sends one claimed row and writes its outcome. Returns the status it ended in. Never throws: an unexpected error fails THIS row and the tick goes on.</summary>
    private async Task<string> SendOneAsync(
        CampaignRecipient row, ResolvedEmailProvider provider,
        Dictionary<Guid, (Campaign Campaign, Dictionary<Guid, MessageTemplate> Templates)?> cache, DateTime now, CancellationToken ct)
    {
        EmailSendResult result;
        try
        {
            (Campaign Campaign, Dictionary<Guid, MessageTemplate> Templates)? entry;
            if (!cache.TryGetValue(row.CampaignId, out entry))
            {
                var loaded = await _store.CampaignAsync(row.CampaignId, ct);
                entry = loaded is null ? null : (loaded, await _campaigns.TemplatesOfAsync(loaded, ct));
                cache[row.CampaignId] = entry;
            }
            var contact = await _contactStore.LoadWithAccountAsync(row.ContactId, ct);
            if (entry is null || contact is null)
                result = EmailSendResult.Fail("The contact or the campaign no longer exists.");
            else
            {
                var (campaign, templates) = entry.Value;
                var message = _campaigns.Compose(campaign, templates, row.Language, row.Address, contact.Name, contact.Company ?? contact.Account?.Name, row.Id, row.ContactId);
                result = message is null
                    ? EmailSendResult.Fail("The message could not be built: its template is missing or the server has no public address for the unsubscribe link.")
                    : await provider.Sender!.SendAsync(message, ct);
            }
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            Console.WriteLine($"[campaign] unexpected error sending recipient {row.Id}: {e.Message}");
            result = EmailSendResult.Fail("Unexpected error while sending.");
        }

        if (result.Accepted && result.Outcome == EmailDeliveryOutcome.Sent)
        {
            row.Status = CampaignRecipientStatuses.Sent;
            row.SentAt = now;
            row.ProviderMessageId = result.ProviderMessageId;
            row.Error = null;
        }
        else if (result.Outcome == EmailDeliveryOutcome.Suppressed)
        {
            // An opt-out, an undeliverable or bounced address, a sandbox org: held back by a guard, which is not a failure.
            row.Status = CampaignRecipientStatuses.Suppressed;
            row.Error = result.Reason;
        }
        else
        {
            row.Status = CampaignRecipientStatuses.Failed;
            row.Error = result.Reason is { Length: > 500 } r ? r[..500] : result.Reason ?? "send_failed";
        }
        row.UpdatedAt = now;
        await _store.SaveChangesAsync(ct);
        return row.Status;
    }
}

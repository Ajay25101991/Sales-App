using SalesApi.Dtos;
using SalesApi.ProcessLayer.Roles;

namespace SalesApi.ExperienceLayer.Roles;

/// <summary>
/// The roles admin screen: list with per-role "may I hand this out" flags, and
/// the save path with every guard PUT /roles has always enforced.
///
/// THIS FILE CANNOT SEE THE DATABASE OR <c>UserAdminContext</c> — enforced by
/// <c>DisableTransitiveProjectReferences</c>, same as every other Experience
/// class. The rank guard therefore runs here only through
/// <see cref="RoleProcess.CanIntroduceOrRaiseBaseRole"/>, which takes plain
/// values (the caller's base role and admin flags) and does the
/// <c>UserAdminContext</c> work on Process's side of the line.
/// </summary>
public sealed class RolesExperience
{
    private readonly RoleProcess _process;
    public RolesExperience(RoleProcess process) => _process = process;

    public Task<List<RoleDefinitionDto>> ListAsync(
        Guid? orgId, string actorBaseRole, bool isOrgAdmin, bool isSuntechAdmin, CancellationToken ct = default) =>
        _process.ListForActorAsync(orgId, actorBaseRole, isOrgAdmin, isSuntechAdmin, ct);

    /// <summary>
    /// Save the org's roles. Preserves the ORIGINAL order of checks exactly:
    /// normalize, then the rank guard (may the caller hand out every base role
    /// the submission introduces or raises?), then the self-grant and
    /// self-visibility guards, then the "role still assigned" conflict, then
    /// persist. Org admins and platform admins skip the self-guards, matching
    /// <c>RolesController.Save</c>'s original exemption — without it, the first
    /// admin editing their own role (the only role with <c>roles.manage</c> on
    /// a fresh org) could never grant it anything new.
    /// </summary>
    public async Task<(RoleConfigSnapshot? Config, RoleProcess.Refusal? Refusal)> SaveAsync(
        Guid orgId, List<RoleDraft> requested, string actorBaseRole, bool isOrgAdmin, bool isSuntechAdmin,
        Guid callerId, CancellationToken ct = default)
    {
        List<RoleDraft> normalized;
        try { normalized = _process.Normalize(requested); }
        catch (ArgumentException ex) { return (null, new RoleProcess.Refusal(RoleProcess.RefusalKind.Validation, ex.Message)); }

        var before = await _process.ConfigAsync(orgId, ct);
        foreach (var role in normalized)
            if (!_process.CanIntroduceOrRaiseBaseRole(actorBaseRole, isOrgAdmin, isSuntechAdmin, role.Key, role.BaseRole, before))
                return (null, new RoleProcess.Refusal(RoleProcess.RefusalKind.RankDenied, RoleProcess.AssignRoleDenied));

        var callerRoleKey = before.Assignments.GetValueOrDefault(callerId, actorBaseRole);
        return await _process.SaveAsync(orgId, normalized, callerRoleKey, callerId, skipSelfGuards: isOrgAdmin || isSuntechAdmin, ct);
    }
}

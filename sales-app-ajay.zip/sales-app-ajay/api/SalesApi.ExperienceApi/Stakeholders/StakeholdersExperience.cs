using SalesApi.Dtos;
using SalesApi.ProcessLayer.Stakeholders;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Stakeholders;

/// <summary>
/// FORWARDS — the desktop stakeholder panel wants exactly what
/// <see cref="StakeholderProcess"/> computes, same as every domain added
/// since the owner's 2026-08-28 decision to add Experience uniformly.
/// </summary>
public sealed class StakeholdersExperience
{
    private readonly StakeholderProcess _stakeholders;
    public StakeholdersExperience(StakeholderProcess stakeholders) => _stakeholders = stakeholders;

    public Task<StakeholderProcess.ListOutcome> ListAsync(
        RecordAccessContext ctx, Guid leadId, bool canSeeContactDetails, string callerRole, CancellationToken ct = default) =>
        _stakeholders.ListAsync(ctx, leadId, canSeeContactDetails, callerRole, ct);

    public Task<StakeholderProcess.StakeholderOutcome> AddAsync(
        RecordAccessContext ctx, Guid leadId, Guid actorId, string callerRole, bool canSeeContactDetails,
        StakeholderInput input, CancellationToken ct = default) =>
        _stakeholders.AddAsync(ctx, leadId, actorId, callerRole, canSeeContactDetails, input, ct);

    public Task<StakeholderProcess.StakeholderOutcome> UpdateAsync(
        RecordAccessContext ctx, Guid leadId, Guid stakeholderId, Guid actorId, string callerRole, bool canSeeContactDetails,
        StakeholderInput input, CancellationToken ct = default) =>
        _stakeholders.UpdateAsync(ctx, leadId, stakeholderId, actorId, callerRole, canSeeContactDetails, input, ct);

    public Task<StakeholderProcess.RemoveOutcome> RemoveAsync(
        RecordAccessContext ctx, Guid leadId, Guid stakeholderId, Guid actorId, CancellationToken ct = default) =>
        _stakeholders.RemoveAsync(ctx, leadId, stakeholderId, actorId, ct);
}

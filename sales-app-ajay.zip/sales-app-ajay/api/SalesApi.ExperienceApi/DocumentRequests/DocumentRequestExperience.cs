using SalesApi.Dtos;
using SalesApi.ProcessLayer.DocumentRequests;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.DocumentRequests;

/// <summary>
/// The document requests on the account screen (ask, resend, withdraw, read) and on the client's public link (read, upload a file, submit). Nothing is
/// shaped differently per caller - the account-access rule is the Process's and the route's permission is the controller's - so this is a pass-through
/// that gives the two controllers one Experience class to depend on, like <c>IrlExperience</c>.
/// </summary>
public sealed class DocumentRequestExperience
{
    private readonly DocumentRequestProcess _requests;
    private readonly DocumentRequestPublicProcess _public;

    public DocumentRequestExperience(DocumentRequestProcess requests, DocumentRequestPublicProcess publicLink)
    {
        _requests = requests;
        _public = publicLink;
    }

    // ---- the rep's side ----

    public Task<DocumentRequestProcess.Result<List<DocumentRequestDto>>> ListAsync(RecordAccessContext vis, Guid accountId, CancellationToken ct = default) =>
        _requests.ListAsync(vis, accountId, ct);

    public Task<DocumentRequestProcess.Result<DocumentRequestDto>> CreateAsync(
        RecordAccessContext vis, Guid actorId, string actorName, Guid accountId, CreateDocumentRequestInput input, CancellationToken ct = default) =>
        _requests.CreateAsync(vis, actorId, actorName, accountId, input, ct);

    public Task<DocumentRequestProcess.Result<DocumentRequestDto>> ResendAsync(
        RecordAccessContext vis, Guid actorId, string actorName, Guid requestId, CancellationToken ct = default) =>
        _requests.ResendAsync(vis, actorId, actorName, requestId, ct);

    public Task<DocumentRequestProcess.Result<DocumentRequestDto>> RevokeAsync(RecordAccessContext vis, Guid actorId, Guid requestId, CancellationToken ct = default) =>
        _requests.RevokeAsync(vis, actorId, requestId, ct);

    // ---- the client's side ----

    public Task<DocumentRequestPublicProcess.Result<DocumentRequestPublicViewDto>> ViewAsync(string? token, CancellationToken ct = default) =>
        _public.ViewAsync(token, ct);

    public Task<DocumentRequestPublicProcess.Result<DocumentRequestFileUploadedDto>> UploadAsync(
        string? token, string? documentType, string? filename, string? contentType, long length, Stream content, CancellationToken ct = default) =>
        _public.UploadAsync(token, documentType, filename, contentType, length, content, ct);

    public Task<DocumentRequestPublicProcess.Result<DocumentRequestSubmitResultDto>> SubmitAsync(string? token, CancellationToken ct = default) =>
        _public.SubmitAsync(token, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Dashboard;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Dashboard;

/// <summary>
/// The dashboard screen's payload.
///
/// Forwards today. Worth saying plainly: of twenty-odd migrated domains only
/// two — quotes and roles — have an Experience class that does anything, and
/// this is not one of them. The owner chose uniformity knowing that, so the
/// seam exists here for the day a second consumer wants a different shape.
///
/// If any domain eventually justifies reshaping, it is likely this one: the
/// dashboard payload is the most screen-specific thing in the API, and a phone
/// plausibly wants fewer tiles than a laptop.
/// </summary>
public sealed class DashboardExperience
{
    private readonly DashboardProcess _dashboard;
    public DashboardExperience(DashboardProcess dashboard) => _dashboard = dashboard;

    public Task<DashboardDto> AggregatedAsync(
        List<Guid>? people, List<Guid>? statsPeople, string period, CalendarDto cal,
        DateTime now, int idleDays, bool valuesVisible, Guid? teamId = null) =>
        _dashboard.AggregatedAsync(people, statsPeople, period, cal, now, idleDays, valuesVisible, teamId);

    public Task<PipelineByAccountFieldDto> PipelineByAccountFieldAsync(List<Guid>? statsPeople, Guid? teamId, bool valuesVisible) =>
        _dashboard.PipelineByAccountFieldAsync(statsPeople, teamId, valuesVisible);

    public Task<StageEntriesDto> StageEntriesAsync(DateOnly fromDay, DateOnly toDay, List<Guid>? statsPeople, Guid? teamId) =>
        _dashboard.StageEntriesAsync(fromDay, toDay, statsPeople, teamId);

    public Task<AmcRenewalsDto> AmcRenewalsAsync(
        DateOnly fromDay, DateOnly toDay, DateOnly today, List<Guid>? statsPeople, Guid? teamId, bool valuesVisible) =>
        _dashboard.AmcRenewalsAsync(fromDay, toDay, today, statsPeople, teamId, valuesVisible);

    public Task<DashboardDto> TagFilteredAsync(
        List<Guid>? people, List<Guid>? statsPeople, List<Guid> tagIds, string period,
        CalendarDto cal, DateTime now, int idleDays, bool valuesVisible, Guid? teamId = null) =>
        _dashboard.TagFilteredAsync(people, statsPeople, tagIds, period, cal, now, idleDays, valuesVisible, teamId);
}

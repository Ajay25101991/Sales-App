using SalesApi.Dtos;
using SalesApi.ProcessLayer.Accounts;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Accounts;

/// <summary>
/// What the accounts screens need. It FORWARDS — every method here calls
/// straight through to <see cref="AccountProcess"/> with no reshaping, same as
/// ten of the eleven previously-migrated domains (Quotes is still the only one
/// where a second consumer forced a real change). Built anyway, per the
/// owner's 2026-08-28 decision to add Experience uniformly: the account page
/// wants exactly what Process computes today, and the moment a second
/// consumer wants something different (a phone widget that wants only the
/// receivables tile, say), the difference lands here and Process stays
/// untouched.
///
/// The loyalty slice of this domain (<see cref="Loyalty.AccountLoyaltyExperience"/>)
/// is its own, already-migrated Experience class and is untouched by this one
/// — <c>AccountsController</c> takes both.
/// </summary>
public sealed class AccountsExperience
{
    private readonly AccountProcess _accounts;
    public AccountsExperience(AccountProcess accounts) => _accounts = accounts;

    public Task<AccountProcess.ListOutcome> ListAsync(
        RecordAccessContext ctx, bool canSeeFullFinancials, bool canSeeValues, AccountProcess.ListParams p, string callerRole = "", CancellationToken ct = default) =>
        _accounts.ListAsync(ctx, canSeeFullFinancials, canSeeValues, p, callerRole, ct);

    /// <summary>May this caller view this account? Used by the loyalty endpoints,
    /// which need the permission answer and not the account itself.</summary>
    public Task<AccountProcess.Refusal?> CheckViewAsync(
        RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _accounts.CheckViewAsync(ctx, id, ct);

    public Task<int> CountAsync(
        RecordAccessContext ctx, string? search, double? similarity, string? owner, string? industry, bool? hasOpenValue,
        bool canSeeValues = true, CancellationToken ct = default,
        string? filters = null, bool canSeeFullFinancials = true, string callerRole = "") =>
        _accounts.CountAsync(ctx, search, similarity, owner, industry, hasOpenValue, canSeeValues, ct, filters, canSeeFullFinancials, callerRole);

    public Task<AccountFacetsDto> FacetsAsync(
        RecordAccessContext ctx, string? search, double? similarity, string? owner, string? industry, bool? hasOpenValue,
        bool canSeeValues = true, CancellationToken ct = default,
        string? filters = null, bool canSeeFullFinancials = true, string callerRole = "") =>
        _accounts.FacetsAsync(ctx, search, similarity, owner, industry, hasOpenValue, canSeeValues, ct, filters, canSeeFullFinancials, callerRole);

    public Task<TableColumnsDto> ColumnsAsync(
        RecordAccessContext ctx, bool canSeeFullFinancials, bool canSeeValues, string callerRole = "", CancellationToken ct = default) =>
        _accounts.ColumnsAsync(ctx, canSeeFullFinancials, canSeeValues, callerRole, ct);

    public Task<string> ExportCsvAsync(
        RecordAccessContext ctx, bool canSeeFullFinancials, bool canSeeValues = true, CancellationToken ct = default,
        string? filters = null, string? sorts = null, string callerRole = "", IReadOnlyCollection<Guid>? ids = null) =>
        _accounts.ExportCsvAsync(ctx, canSeeFullFinancials, canSeeValues, ct, filters, sorts, callerRole, ids);

    public Task<List<AccountDto>> MatchAsync(
        RecordAccessContext ctx, bool canSeeFullFinancials, string? company, string? email, bool canSeeValues = true, CancellationToken ct = default) =>
        _accounts.MatchAsync(ctx, canSeeFullFinancials, company, email, canSeeValues, ct);

    public Task<MatchBulkResultDto> MatchBulkAsync(RecordAccessContext ctx, List<string>? companies, CancellationToken ct = default) =>
        _accounts.MatchBulkAsync(ctx, companies, ct);

    public Task<LinkUnlinkedLeadsPreviewDto> PreviewLinkUnlinkedLeadsAsync(RecordAccessContext ctx, CancellationToken ct = default) =>
        _accounts.PreviewLinkUnlinkedLeadsAsync(ctx, ct);

    public Task<LinkUnlinkedLeadsResultDto> LinkUnlinkedLeadsAsync(RecordAccessContext ctx, CancellationToken ct = default) =>
        _accounts.LinkUnlinkedLeadsAsync(ctx, ct);

    public Task<AccountProcess.AccountDetailOutcome> GetAsync(
        RecordAccessContext ctx, bool canSeeFullFinancials, Guid id, string callerRole = "", bool canSeeValues = true, CancellationToken ct = default) =>
        _accounts.GetAsync(ctx, canSeeFullFinancials, id, callerRole, canSeeValues, ct);

    public Task<(AccountProcess.Refusal? Refusal, PagedResult<FieldChangeAuditEntryDto>? Page)> HistoryAsync(
        RecordAccessContext ctx, bool canSeeValues, bool canSeeContactDetails, Guid id, string? cursor, int? limit, CancellationToken ct = default) =>
        _accounts.HistoryAsync(ctx, canSeeValues, canSeeContactDetails, id, cursor, limit, ct);

    public Task<(AccountProcess.Refusal? Refusal, PagedResult<TimelineItemDto>? Page)> TimelineAsync(
        RecordAccessContext ctx, bool canSeeValues, bool canSeeContactDetails, bool canSeeFinancials,
        Guid id, string? cursor, int? limit, string? kinds, string? scope, CancellationToken ct = default) =>
        _accounts.TimelineAsync(ctx, canSeeValues, canSeeContactDetails, canSeeFinancials, id, cursor, limit, kinds, scope, ct);

    public Task<AccountProcess.AccountOutcome> CreateAsync(
        Guid ownerId, Guid? orgId, AccountInput input, string callerRole = "",
        bool canSeeValues = true, bool canSeeFullFinancials = true, CancellationToken ct = default, bool canCreateTags = false, SensitiveAccess? sensitive = null, RecordAccessContext? access = null) =>
        _accounts.CreateAsync(ownerId, orgId, input, callerRole, canSeeValues, canSeeFullFinancials, ct, canCreateTags, sensitive, access);

    public Task<AccountProcess.AccountOutcome> UpdateAsync(
        RecordAccessContext ctx, Guid id, AccountInput input, string callerRole = "",
        bool canSeeValues = true, bool canSeeFullFinancials = true, CancellationToken ct = default, bool canCreateTags = false) =>
        _accounts.UpdateAsync(ctx, id, input, callerRole, canSeeValues, canSeeFullFinancials, ct, canCreateTags);

    public Task<AccountProcess.DeleteOutcome> DeleteAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _accounts.DeleteAsync(ctx, id, ct);

    // --- Accounts rework (to-do/accounts-rework-design.md) ---

    public Task<AccountProcess.DeleteOutcome> DeleteAsync(RecordAccessContext ctx, Guid id, bool deleteDeals, CancellationToken ct = default) =>
        _accounts.DeleteAsync(ctx, id, deleteDeals, ct);

    public Task<(AccountProcess.Refusal? Refusal, AccountDeletePreviewDto? Preview)> DeletePreviewAsync(
        RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _accounts.DeletePreviewAsync(ctx, id, ct);

    public Task<(AccountProcess.Refusal? Refusal, List<ActivityDto>? Dto)> ActivitiesAsync(
        RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _accounts.ActivitiesAsync(ctx, id, ct);

    public Task<(AccountProcess.Refusal? Refusal, ActivityDto? Dto)> AddActivityAsync(
        RecordAccessContext ctx, Guid actorId, Guid id, AccountActivityInput input, CancellationToken ct = default) =>
        _accounts.AddActivityAsync(ctx, actorId, id, input, ct);

    public Task<AccountProcess.AssignOutcome> AssignAsync(
        RecordAccessContext ctx, AccountProcess.AccountActor actor, Guid id, AccountAssignInput input,
        bool canSeeValues = true, bool canSeeFullFinancials = true, CancellationToken ct = default) =>
        _accounts.AssignAsync(ctx, actor, id, input, canSeeValues, canSeeFullFinancials, ct);

    public Task<(AccountProcess.Refusal? Refusal, AccountBulkResult? Result)> BulkAsync(
        RecordAccessContext ctx, AccountProcess.AccountActor actor, AccountBulkInput input, CancellationToken ct = default,
        bool canSeeValues = true, bool canSeeFullFinancials = true) =>
        _accounts.BulkAsync(ctx, actor, input, ct, canSeeValues, canSeeFullFinancials);

    public Task<List<Guid>> MatchingIdsAsync(
        RecordAccessContext ctx, AccountMatchInput match, bool canSeeValues, bool canSeeFullFinancials, string callerRole, CancellationToken ct = default) =>
        _accounts.MatchingIdsAsync(ctx, match, canSeeValues, canSeeFullFinancials, callerRole, ct);

    public Task<AccountProcess.ContactsOutcome> ContactsAsync(
        RecordAccessContext ctx, Guid id, string callerRole = "", CancellationToken ct = default) =>
        _accounts.ContactsAsync(ctx, id, callerRole, ct);

    public Task<AccountProcess.ContactOutcome> AddContactAsync(
        RecordAccessContext ctx, Guid id, ContactInput input, string callerRole = "", CancellationToken ct = default) =>
        _accounts.AddContactAsync(ctx, id, input, callerRole, ct);

    // --- E3.4: parent/subsidiary, relationships, external ids, tree ---

    public Task<AccountProcess.AccountOutcome> SetParentAsync(
        RecordAccessContext ctx, Guid id, Guid? parentAccountId, Guid actorId, string callerRole = "",
        bool canSeeValues = true, bool canSeeFullFinancials = true, CancellationToken ct = default) =>
        _accounts.SetParentAsync(ctx, id, parentAccountId, actorId, callerRole, canSeeValues, canSeeFullFinancials, ct);

    public Task<AccountProcess.AccountOutcome> FollowParentAsync(
        RecordAccessContext ctx, Guid id, List<string>? fields, string callerRole = "",
        bool canSeeValues = true, bool canSeeFullFinancials = true, CancellationToken ct = default) =>
        _accounts.FollowParentAsync(ctx, id, fields, callerRole, canSeeValues, canSeeFullFinancials, ct);

    public Task<(AccountProcess.Refusal? Refusal, AccountChildNodeDto? Tree)> ChildrenTreeAsync(
        RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _accounts.ChildrenTreeAsync(ctx, id, ct);

    public Task<(AccountProcess.Refusal? Refusal, List<AccountRelationshipDto>? Relationships)> RelationshipsAsync(
        RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _accounts.RelationshipsAsync(ctx, id, ct);

    public Task<(AccountProcess.Refusal? Refusal, AccountRelationshipDto? Relationship)> AddRelationshipAsync(
        RecordAccessContext ctx, Guid id, AccountRelationshipInput input, Guid actorId, CancellationToken ct = default) =>
        _accounts.AddRelationshipAsync(ctx, id, input, actorId, ct);

    public Task<AccountProcess.Refusal?> RemoveRelationshipAsync(
        RecordAccessContext ctx, Guid id, Guid relationshipId, Guid actorId, CancellationToken ct = default) =>
        _accounts.RemoveRelationshipAsync(ctx, id, relationshipId, actorId, ct);

    public Task<(AccountProcess.Refusal? Refusal, List<AccountExternalIdDto>? Ids)> ExternalIdsAsync(
        RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _accounts.ExternalIdsAsync(ctx, id, ct);

    public Task<(AccountProcess.Refusal? Refusal, AccountExternalIdDto? ExternalId)> AddExternalIdAsync(
        RecordAccessContext ctx, Guid id, AccountExternalIdInput input, CancellationToken ct = default) =>
        _accounts.AddExternalIdAsync(ctx, id, input, ct);

    public Task<AccountProcess.Refusal?> RemoveExternalIdAsync(
        RecordAccessContext ctx, Guid id, Guid externalIdId, CancellationToken ct = default) =>
        _accounts.RemoveExternalIdAsync(ctx, id, externalIdId, ct);
}

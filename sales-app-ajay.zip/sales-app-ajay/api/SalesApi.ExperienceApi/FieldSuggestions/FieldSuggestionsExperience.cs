using SalesApi.Dtos;
using SalesApi.ProcessLayer.FieldSuggestions;

namespace SalesApi.ExperienceLayer.FieldSuggestions;

/// <summary>Pass-through to <see cref="FieldSuggestionProcess"/> - the controller-facing shape for enrichment suggestions (the app's list / accept / reject). No orchestration
/// across verticals lives here (the seam exists for consistency with every other Experience class). The MCP <c>suggest_field_value</c> tool calls
/// <see cref="FieldSuggestionProcess.SuggestAsync"/> directly.</summary>
public sealed class FieldSuggestionsExperience
{
    private readonly FieldSuggestionProcess _suggestions;
    public FieldSuggestionsExperience(FieldSuggestionProcess suggestions) => _suggestions = suggestions;

    public Task<(FieldSuggestionProcess.Refusal? Refusal, List<FieldSuggestionDto>? Items)> ListForRecordAsync(
        SuggestionCaller caller, string? recordType, Guid recordId, bool includeDecided, CancellationToken ct = default) =>
        _suggestions.ListForRecordAsync(caller, recordType, recordId, includeDecided, ct);

    public Task<PagedResult<FieldSuggestionDto>> ListOpenAsync(SuggestionCaller caller, int? limit, string? cursor, CancellationToken ct = default) =>
        _suggestions.ListOpenAsync(caller, limit, cursor, ct);

    public Task<(FieldSuggestionProcess.Refusal? Refusal, FieldSuggestionDto? Dto)> AcceptAsync(SuggestionCaller caller, Guid id, CancellationToken ct = default) =>
        _suggestions.AcceptAsync(caller, id, ct);

    public Task<(FieldSuggestionProcess.Refusal? Refusal, FieldSuggestionDto? Dto)> RejectAsync(SuggestionCaller caller, Guid id, CancellationToken ct = default) =>
        _suggestions.RejectAsync(caller, id, ct);
}

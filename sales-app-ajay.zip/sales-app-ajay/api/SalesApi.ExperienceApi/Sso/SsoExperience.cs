using SalesApi.Dtos;
using SalesApi.ProcessLayer.Sso;

namespace SalesApi.ExperienceLayer.Sso;

/// <summary>What the sign-in screen and the admin SSO settings screen need —
/// every method here forwards, same shape as <c>MailboxSyncSettingsExperience</c>/
/// <c>AuthExperience</c>.</summary>
public sealed class SsoExperience
{
    private readonly SsoOAuthProcess _oauth;
    private readonly SsoSettingsProcess _settings;

    public SsoExperience(SsoOAuthProcess oauth, SsoSettingsProcess settings)
    {
        _oauth = oauth;
        _settings = settings;
    }

    public Task<SsoStartResult> StartAsync(string? email, string? client = null, CancellationToken ct = default) =>
        _oauth.StartAsync(email, client, ct);

    public Task<string> ClientForStateAsync(string? state, CancellationToken ct = default) =>
        _oauth.ClientForStateAsync(state, ct);

    public Task<(SsoRefusal? Refusal, string? AuthorizeUrl)> BuildTestAuthorizeUrlAsync(
        Guid orgId, Guid adminProfileId, CancellationToken ct = default) =>
        _oauth.BuildTestAuthorizeUrlAsync(orgId, adminProfileId, ct);

    public Task<SsoCallbackResult> ExchangeCallbackAsync(string code, string state, CancellationToken ct = default) =>
        _oauth.ExchangeCallbackAsync(code, state, ct);

    public Task<(SsoRefusal? Refusal, AuthResponse? Response)> ExchangeSessionAsync(
        string? code, bool supportsRefresh, CancellationToken ct = default) =>
        _oauth.ExchangeSessionAsync(code, supportsRefresh, ct);

    public Task<SsoSettingsDto> GetSettingsAsync(Guid orgId, CancellationToken ct = default) =>
        _settings.GetAsync(orgId, ct);

    public Task<(SsoSettingsDto? Dto, SsoSettingsProcess.Refusal? Refusal)> SaveSettingsAsync(
        Guid orgId, SsoSettingsInput input, Guid actorId, CancellationToken ct = default) =>
        _settings.SaveAsync(orgId, input, actorId, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.DocumentRegister;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.DocumentRegister;

/// <summary>
/// What the Documents register tab (on an account and on a contact) needs. It FORWARDS - every method calls straight through to
/// <see cref="DocumentRegisterProcess"/> with no reshaping, like <c>ClientDocumentsExperience</c>: the tab wants exactly what Process
/// computes today, and the first second consumer that wants something different adds the difference here.
/// </summary>
public sealed class DocumentRegisterExperience
{
    private readonly DocumentRegisterProcess _register;
    public DocumentRegisterExperience(DocumentRegisterProcess register) => _register = register;

    public Task<DocumentRegisterProcess.ListOutcome> ListAsync(
        RecordAccessContext ctx, string callerRole, Guid? accountId, Guid? contactId, bool includeHistory, bool includeInherited, CancellationToken ct = default) =>
        _register.ListAsync(ctx, callerRole, accountId, contactId, includeHistory, includeInherited, ct);

    public Task<DocumentRegisterProcess.ChecklistOutcome> ChecklistAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default) =>
        _register.ChecklistAsync(ctx, accountId, ct);

    public Task<DocumentRegisterProcess.EntryOutcome> AddAsync(
        RecordAccessContext ctx, string callerRole, AttachmentPermissions perms, Guid userId, Guid? orgId, DocumentRegisterAddInput input,
        string? fileName, string? contentType, long length, Stream? content, CancellationToken ct = default) =>
        _register.AddAsync(ctx, callerRole, perms, userId, orgId, input, fileName, contentType, length, content, ct);

    public Task<DocumentRegisterProcess.EntryOutcome> UpdateAsync(
        RecordAccessContext ctx, string callerRole, Guid id, DocumentRegisterEditInput input, CancellationToken ct = default) =>
        _register.UpdateAsync(ctx, callerRole, id, input, ct);

    public Task<DocumentRegisterProcess.EntryOutcome> SetVerifiedAsync(
        RecordAccessContext ctx, string callerRole, Guid id, bool verified, CancellationToken ct = default) =>
        _register.SetVerifiedAsync(ctx, callerRole, id, verified, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Tasks;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Tasks;

/// <summary>What the tasks screens need, shaped for them — a pass-through today,
/// same as <see cref="Reminders.RemindersExperience"/> and for the same
/// documented reason (owner decision 2026-08-28, "build Experience everywhere").</summary>
public sealed class TasksExperience
{
    private readonly TaskProcess _tasks;
    private readonly TaskFileProcess _files;
    public TasksExperience(TaskProcess tasks, TaskFileProcess files)
    {
        _tasks = tasks;
        _files = files;
    }

    // Files on a task (to-do/task-files-design.md).
    public Task<(List<AttachmentDto>? Files, TaskProcess.Refusal? Refusal)> FilesAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, Guid taskId, CancellationToken ct = default) =>
        _files.ListAsync(ctx, perms, taskId, ct);

    public Task<(List<AttachmentDto>? Files, TaskProcess.Refusal? Refusal)> LinkFilesAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, Guid taskId, TaskFileLinksInput input, Guid callerId, CancellationToken ct = default) =>
        _files.LinkAsync(ctx, perms, taskId, input.AttachmentIds, callerId, ct);

    public Task<TaskProcess.Refusal?> UnlinkFileAsync(RecordAccessContext ctx, Guid taskId, Guid attachmentId, CancellationToken ct = default) =>
        _files.UnlinkAsync(ctx, taskId, attachmentId, ct);

    public Task<(AttachmentDto? File, TaskProcess.Refusal? Refusal)> UploadFileAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, Guid taskId, Guid uploaderId, Guid? orgId,
        string filename, string? contentType, long length, Stream content, CancellationToken ct = default) =>
        _files.UploadAsync(ctx, perms, taskId, uploaderId, orgId, filename, contentType, length, content, ct);

    public Task<(List<TaskDto>? Dtos, TaskProcess.Refusal? Refusal)> ListAsync(
        RecordAccessContext ctx, string? scope, Guid? teamId, string? status, CancellationToken ct = default,
        string? filters = null, string? sorts = null) =>
        _tasks.ListAsync(ctx, scope, teamId, status, ct, filters, sorts);

    public Task<TableColumnsDto> ColumnsAsync(RecordAccessContext ctx, CancellationToken ct = default) =>
        _tasks.ColumnsAsync(ctx, ct);

    public Task<List<TaskDto>> ForLeadAsync(RecordAccessContext ctx, Guid leadId, CancellationToken ct = default) =>
        _tasks.ForLeadAsync(ctx, leadId, ct);

    public Task<List<TaskDto>> ForAccountAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default) =>
        _tasks.ForAccountAsync(ctx, accountId, ct);

    public Task<(TaskDto? Dto, TaskProcess.Refusal? Refusal)> GetAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _tasks.GetAsync(ctx, id, ct);

    public Task<(TaskDto? Dto, TaskProcess.Refusal? Refusal)> CreateAsync(
        RecordAccessContext ctx, Guid? orgId, TaskInput input, CancellationToken ct = default) =>
        _tasks.CreateAsync(ctx, orgId, input, ct);

    public Task<(TaskDto? Dto, TaskProcess.Refusal? Refusal)> UpdateAsync(
        RecordAccessContext ctx, Guid? orgId, Guid id, TaskInput input, CancellationToken ct = default) =>
        _tasks.UpdateAsync(ctx, orgId, id, input, ct);

    public Task<(TaskDto? Dto, TaskProcess.Refusal? Refusal)> CompleteAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _tasks.CompleteAsync(ctx, id, ct);

    public Task<(TaskDto? Dto, TaskProcess.Refusal? Refusal)> ClaimAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _tasks.ClaimAsync(ctx, id, ct);

    public Task<(TaskDto? Dto, TaskProcess.Refusal? Refusal)> CancelAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _tasks.CancelAsync(ctx, id, ct);

    public Task<(TaskDto? Dto, TaskProcess.Refusal? Refusal)> SnoozeAsync(
        RecordAccessContext ctx, Guid id, TaskSnoozeInput input, CancellationToken ct = default) =>
        _tasks.SnoozeAsync(ctx, id, input, ct);

    public Task<TaskBulkResultDto> BulkCompleteAsync(RecordAccessContext ctx, List<Guid> ids, CancellationToken ct = default) =>
        _tasks.BulkCompleteAsync(ctx, ids, ct);

    public Task<TaskBulkResultDto> BulkReassignAsync(
        RecordAccessContext ctx, Guid? orgId, List<Guid> ids, Guid assigneeId, CancellationToken ct = default) =>
        _tasks.BulkReassignAsync(ctx, orgId, ids, assigneeId, ct);
}

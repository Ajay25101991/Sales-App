using SalesApi.Dtos;
using SalesApi.ProcessLayer.Public;

namespace SalesApi.ExperienceLayer.Public;

/// <summary>
/// The website contact form's submit call. Forwards Process today — this
/// endpoint has exactly one caller shape (a form POST) and nothing to reshape.
/// </summary>
public sealed class PublicIntakeExperience
{
    private readonly PublicIntakeProcess _process;
    public PublicIntakeExperience(PublicIntakeProcess process) => _process = process;

    public Task<PublicIntakeProcess.Result> CreateLeadAsync(string? providedApiKey, PublicLeadInput input, CancellationToken ct = default) =>
        _process.CreateLeadAsync(providedApiKey, input, ct);
}

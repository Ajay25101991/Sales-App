using SalesApi.Dtos;
using SalesApi.ProcessLayer.Sandbox;

namespace SalesApi.ExperienceLayer.Sandbox;

/// <summary>Pass-through to <see cref="SandboxProcess"/> — the controller-facing
/// shape for E7.3's sandbox endpoints. No orchestration across verticals lives
/// here yet (unlike <c>AdminExperience</c>'s template+org-creation composition);
/// the seam exists for the same reason every other Experience class does
/// (owner decision, 2026-08-28).</summary>
public sealed class SandboxExperience
{
    private readonly SandboxProcess _sandbox;
    public SandboxExperience(SandboxProcess sandbox) => _sandbox = sandbox;

    public Task<(SandboxCreateResultDto? Result, SandboxProcess.Refusal? Refusal)> CreateAsync(
        Guid productionOrgId, Guid actorId, CancellationToken ct = default) =>
        _sandbox.CreateAsync(productionOrgId, actorId, ct);

    /// <summary>§11 build-notes gap: GET /admin/sandbox's status read.</summary>
    public Task<SandboxStatusDto> StatusAsync(Guid productionOrgId, CancellationToken ct = default) =>
        _sandbox.StatusAsync(productionOrgId, ct);

    public Task<(PackageImportPreviewDto? Preview, SandboxProcess.Refusal? Refusal)> RefreshPreviewAsync(
        Guid productionOrgId, CancellationToken ct = default) =>
        _sandbox.RefreshPreviewAsync(productionOrgId, ct);

    public Task<(PackageApplyResultDto? Result, SandboxProcess.Refusal? Refusal)> RefreshApplyAsync(
        Guid productionOrgId, Guid actorId, List<PackageItemResolutionDto> resolutions, CancellationToken ct = default) =>
        _sandbox.RefreshApplyAsync(productionOrgId, actorId, resolutions, ct);

    public Task<(int Deleted, SandboxProcess.Refusal? Refusal)> DeleteAsync(
        Guid productionOrgId, CancellationToken ct = default) =>
        _sandbox.DeleteAsync(productionOrgId, ct);

    public Task<(SandboxDiffDto? Diff, SandboxProcess.Refusal? Refusal)> DiffAsync(
        Guid productionOrgId, CancellationToken ct = default) =>
        _sandbox.DiffAsync(productionOrgId, ct);

    public Task<(PackageApplyResultDto? Result, SandboxProcess.Refusal? Refusal)> PromoteAsync(
        Guid productionOrgId, Guid actorId, SandboxPromoteRequestDto request, CancellationToken ct = default) =>
        _sandbox.PromoteAsync(productionOrgId, actorId, request, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Quotes;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Quotes;

/// <summary>
/// What the customer-facing quote page needs.
///
/// Also impossible to write until 2026-08-28, for the opposite reason to
/// <see cref="Collections.CollectionsExperience"/>: `QuoteProcess` handed out the
/// `Proposal` ENTITY. That one could NOT be fixed by moving the type into
/// Contracts — an entity as a contract means a column rename is a breaking
/// change for every consumer, which is the coupling this architecture exists to
/// remove. So Process now maps it to `CustomerQuoteDto` — eleven fields, exactly
/// what the page renders — and the entity stays in System.
///
/// This is the first Experience class in the codebase whose existence forced a
/// real change rather than forwarding calls.
/// </summary>
public sealed class QuotesExperience
{
    private readonly QuoteProcess _quotes;
    public QuotesExperience(QuoteProcess quotes) => _quotes = quotes;

    public Task<QuoteProcess.QuoteView> ViewAsync(string? token, string? ip = null, string? userAgent = null, CancellationToken ct = default) =>
        _quotes.ViewAsync(token, ip, userAgent, ct);

    public Task<QuoteProcess.AcceptResult> AcceptAsync(string? token, string? name, CancellationToken ct = default) =>
        _quotes.AcceptAsync(token, name, ct);

    // E6.3 — GET /quotes/{id}/views. Authenticated (unlike the two above), so
    // the caller's RecordAccessContext travels down as data, per the layering
    // rule (permission stays at the HTTP layer, decided from data, never a
    // ClaimsPrincipal reaching this far down).
    public Task<(QuoteProcess.ViewsRefusal? Refusal, QuoteViewSummaryDto? Dto)> ViewsAsync(
        RecordAccessContext vis, Guid quoteId, CancellationToken ct = default) =>
        _quotes.ViewsAsync(vis, quoteId, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Contacts;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Contacts;

/// <summary>
/// What the contact editor needs. FORWARDS — the panel wants exactly what
/// <see cref="ContactProcess"/> computes, same as ten of eleven domains
/// migrated before this one (built anyway, per the owner's 2026-08-28
/// decision to add Experience uniformly rather than carry a growing list of
/// exceptions).
/// </summary>
public sealed class ContactsExperience
{
    private readonly ContactProcess _contacts;
    public ContactsExperience(ContactProcess contacts) => _contacts = contacts;

    // The all-contacts table: forwards, the way AccountsExperience forwards the accounts table.
    public Task<TableColumnsDto> ColumnsAsync(
        RecordAccessContext ctx, bool canViewContactDetails, string callerRole = "", CancellationToken ct = default) =>
        _contacts.ColumnsAsync(ctx, canViewContactDetails, callerRole, ct);

    public Task<ContactProcess.ListOutcome> ListAsync(
        RecordAccessContext ctx, bool canViewContactDetails, ContactProcess.ListParams p, string callerRole = "", CancellationToken ct = default) =>
        _contacts.ListAsync(ctx, canViewContactDetails, p, callerRole, ct);

    public Task<int> CountAsync(
        RecordAccessContext ctx, bool canViewContactDetails, string? search, double? similarity, string? filters,
        string callerRole = "", CancellationToken ct = default) =>
        _contacts.CountAsync(ctx, canViewContactDetails, search, similarity, filters, callerRole, ct);

    public Task<string> ExportCsvAsync(
        RecordAccessContext ctx, bool canViewContactDetails, string? filters = null, string? sorts = null,
        string callerRole = "", IReadOnlyCollection<Guid>? ids = null, CancellationToken ct = default) =>
        _contacts.ExportCsvAsync(ctx, canViewContactDetails, filters, sorts, callerRole, ids, ct);

    public Task<ContactProcess.ContactDetailOutcome> GetAsync(
        RecordAccessContext ctx, Guid id, string callerRole = "", CancellationToken ct = default) =>
        _contacts.GetAsync(ctx, id, callerRole, ct);

    public Task<ContactProcess.ContactOutcome> UpdateAsync(
        RecordAccessContext ctx, Guid id, ContactInput input, string callerRole = "", CancellationToken ct = default) =>
        _contacts.UpdateAsync(ctx, id, input, callerRole, ct);

    public Task<ContactProcess.DeleteOutcome> DeleteAsync(
        RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _contacts.DeleteAsync(ctx, id, ct);

    public Task<ContactProcess.DealsOutcome> DealsAsync(
        RecordAccessContext ctx, Guid id, bool canSeeValues, CancellationToken ct = default) =>
        _contacts.DealsAsync(ctx, id, canSeeValues, ct);

    public Task<ContactProcess.ContactOutcome> SetReportsToAsync(
        RecordAccessContext ctx, Guid id, Guid? reportsToContactId, string callerRole = "", CancellationToken ct = default) =>
        _contacts.SetReportsToAsync(ctx, id, reportsToContactId, callerRole, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Contacts;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Contacts;

/// <summary>E16.1 - the contact screen's opt-out calls. FORWARDS: the screen wants exactly what <see cref="ContactConsentProcess"/> computes.</summary>
public sealed class ContactConsentExperience
{
    private readonly ContactConsentProcess _consent;
    public ContactConsentExperience(ContactConsentProcess consent) => _consent = consent;

    public Task<ContactConsentProcess.StateOutcome> OptOutAsync(RecordAccessContext ctx, Guid id, ContactOptOutInput input, CancellationToken ct = default) =>
        _consent.OptOutAsync(ctx, id, input, ct);

    public Task<ContactConsentProcess.StateOutcome> OptInAsync(RecordAccessContext ctx, Guid id, ContactOptOutInput input, CancellationToken ct = default) =>
        _consent.OptInAsync(ctx, id, input, ct);

    public Task<ContactConsentProcess.HistoryOutcome> HistoryAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _consent.HistoryAsync(ctx, id, ct);
}

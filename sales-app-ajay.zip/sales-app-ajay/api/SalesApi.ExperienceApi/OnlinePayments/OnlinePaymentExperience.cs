using SalesApi.Dtos;
using SalesApi.ProcessLayer.OnlinePayments;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.OnlinePayments;

/// <summary>
/// Online payment on the invoice screen (ask for the Pay now link, the reconciliation list, the setup facts), on the customer's public link (read what
/// is owed, start a checkout) and on the gateway's signed callback. Nothing is shaped differently per caller - the invoice-access rule is the
/// Process's and each route's permission is its controller's - so this is a pass-through that gives the three controllers one Experience class to
/// depend on, like <c>DocumentRequestExperience</c>.
/// </summary>
public sealed class OnlinePaymentExperience
{
    private readonly OnlinePaymentProcess _staff;
    private readonly OnlinePaymentPublicProcess _public;
    private readonly OnlinePaymentWebhookProcess _webhook;

    public OnlinePaymentExperience(OnlinePaymentProcess staff, OnlinePaymentPublicProcess publicLink, OnlinePaymentWebhookProcess webhook)
    {
        _staff = staff;
        _public = publicLink;
        _webhook = webhook;
    }

    // ---- staff ----

    public Task<OnlinePaymentProcess.Result<PayLinkDto>> CreatePayLinkAsync(RecordAccessContext ctx, Guid invoiceId, Guid actorId, CancellationToken ct = default) =>
        _staff.CreatePayLinkAsync(ctx, invoiceId, actorId, ct);

    public Task<OnlinePaymentProcess.Result<List<OnlinePaymentDto>>> ListAsync(DateOnly? from, DateOnly? to, string? status, int? limit, CancellationToken ct = default) =>
        _staff.ListAsync(from, to, status, limit, ct);

    public Task<OnlinePaymentSetupDto> SetupAsync(CancellationToken ct = default) => _staff.SetupAsync(ct);

    // ---- the customer ----

    public Task<OnlinePaymentPublicProcess.Result<PayPublicViewDto>> ViewAsync(string? token, CancellationToken ct = default) => _public.ViewAsync(token, ct);

    public Task<OnlinePaymentPublicProcess.Result<PayCheckoutDto>> CheckoutAsync(string? token, CancellationToken ct = default) => _public.CheckoutAsync(token, ct);

    // ---- the gateway ----

    public Task<OnlinePaymentWebhookProcess.Result> HandleWebhookAsync(Guid connectionId, byte[] rawBody, string? signatureHeader, CancellationToken ct = default) =>
        _webhook.HandleAsync(connectionId, rawBody, signatureHeader, ct);
}

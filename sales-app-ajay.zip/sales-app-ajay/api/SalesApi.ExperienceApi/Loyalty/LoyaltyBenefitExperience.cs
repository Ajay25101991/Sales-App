using SalesApi.Dtos;
using SalesApi.ProcessLayer.Loyalty;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Loyalty;

/// <summary>
/// What the "Tiers &amp; rewards" admin and the account's rewards panel need (E20.2). It FORWARDS - every method calls straight through to
/// <see cref="LoyaltyBenefitProcess"/> with no reshaping, like <c>DocumentRegisterExperience</c>: the screens want exactly what Process computes today, and the
/// first second consumer (a portal request, a mobile summary) that wants something different adds the difference here. Like every Experience class it cannot see
/// the database: <c>DisableTransitiveProjectReferences</c> makes the System types invisible to this project.
/// </summary>
public sealed class LoyaltyBenefitExperience
{
    private readonly LoyaltyBenefitProcess _benefits;
    public LoyaltyBenefitExperience(LoyaltyBenefitProcess benefits) => _benefits = benefits;

    public Task<List<LoyaltyBenefitDto>> ListBenefitsAsync(bool activeOnly, CancellationToken ct = default) =>
        _benefits.ListBenefitsAsync(activeOnly, ct);

    public Task<(LoyaltyBenefitProcess.Refusal? Refusal, LoyaltyBenefitDto? Dto)> CreateBenefitAsync(LoyaltyBenefitInput input, CancellationToken ct = default) =>
        _benefits.CreateBenefitAsync(input, ct);

    public Task<(LoyaltyBenefitProcess.Refusal? Refusal, LoyaltyBenefitDto? Dto)> UpdateBenefitAsync(Guid id, LoyaltyBenefitInput input, CancellationToken ct = default) =>
        _benefits.UpdateBenefitAsync(id, input, ct);

    public Task<List<LoyaltyEntitlementDto>> ListEntitlementsAsync(string? tierKey, CancellationToken ct = default) =>
        _benefits.ListEntitlementsAsync(tierKey, ct);

    public Task<(LoyaltyBenefitProcess.Refusal? Refusal, List<LoyaltyEntitlementDto>? Dto)> SetTierEntitlementsAsync(
        string tierKey, LoyaltyEntitlementSetInput input, CancellationToken ct = default) =>
        _benefits.SetTierEntitlementsAsync(tierKey, input, ct);

    public Task<(LoyaltyBenefitProcess.Refusal? Refusal, AccountLoyaltyBenefitsDto? Dto)> RemainingAsync(
        RecordAccessContext ctx, Guid accountId, CancellationToken ct = default) =>
        _benefits.RemainingAsync(ctx, accountId, ct);

    public Task<(LoyaltyBenefitProcess.Refusal? Refusal, List<LoyaltyBenefitUseDto>? Dto)> UsesAsync(
        RecordAccessContext ctx, Guid accountId, Guid? benefitId, bool includeSuperseded, CancellationToken ct = default) =>
        _benefits.UsesAsync(ctx, accountId, benefitId, includeSuperseded, ct);

    public Task<(LoyaltyBenefitProcess.Refusal? Refusal, LoyaltyBenefitUseDto? Dto)> RecordUseAsync(
        RecordAccessContext ctx, Guid accountId, Guid? actorId, LoyaltyBenefitUseInput input, CancellationToken ct = default) =>
        _benefits.RecordUseAsync(ctx, accountId, actorId, input, ct);

    public Task<(LoyaltyBenefitProcess.Refusal? Refusal, LoyaltyBenefitUseDto? Dto)> CorrectUseAsync(
        RecordAccessContext ctx, Guid accountId, Guid useId, Guid? actorId, bool canManage, LoyaltyBenefitUseCorrectionInput input, CancellationToken ct = default) =>
        _benefits.CorrectUseAsync(ctx, accountId, useId, actorId, canManage, input, ct);
}

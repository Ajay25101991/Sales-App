using SalesApi.Dtos;
using SalesApi.ProcessLayer.Loyalty;

namespace SalesApi.ExperienceLayer.Loyalty;

/// <summary>
/// What the account page's loyalty panel needs, shaped for that panel.
///
/// THIS FILE CANNOT SEE THE DATABASE, and that is enforced rather than agreed:
/// `SalesApi.ExperienceApi` sets `DisableTransitiveProjectReferences`, so
/// `AppDbContext`, `LoyaltyEvent` and every other System type are invisible
/// here. An Experience class that reaches for one does not compile. Try it —
/// that is the whole reason the flag is set.
///
/// It looks thin today because the panel wants almost exactly what the Process
/// layer computes. That is the honest state of a first vertical, not a sign the
/// layer is pointless: the moment a second consumer appears — a phone that
/// wants the tier and not the 200-row ledger, a customer-facing page that wants
/// the tier and NOTHING else — the difference lands here and Process stays
/// untouched. Today's thinness is the thing being bought.
/// </summary>
public sealed class AccountLoyaltyExperience
{
    private readonly LoyaltyStatusProcess _status;
    public AccountLoyaltyExperience(LoyaltyStatusProcess status) => _status = status;

    /// <summary>
    /// The desktop account panel's payload.
    ///
    /// Note what it does NOT decide: whether this reader may see loyalty at all.
    /// That is `loyalty.view_status`, it is enforced at the endpoint, and it
    /// answers 403 — deliberately not `enabled: false`, which means something
    /// else entirely ("this org does not run loyalty"). Collapsing the two would
    /// tell a rep without the permission that their company has no programme.
    /// </summary>
    public async Task<AccountLoyaltyDto> PanelAsync(Guid accountId, CancellationToken ct = default)
    {
        var status = await _status.ForAccountAsync(accountId, ct);
        return new AccountLoyaltyDto(
            status.Enabled, status.Balance, status.Events,
            status.Tier, status.NextTier, status.PointsToNextTier, status.Window, status.WindowMonths);
    }

    /// <summary>The panel's editor: this account's override, with the org rule
    /// it overrides alongside it.</summary>
    public Task<LoyaltyAccountRuleDto> RuleAsync(Guid accountId, CancellationToken ct = default) =>
        _status.RuleForAccountAsync(accountId, ct);

    /// <summary>Save the override. Range validation happens here AND in Process
    /// AND at the endpoint — defence in depth is one of the migration's stated
    /// principles, and the layer that is reused is the one that must not trust
    /// its caller.</summary>
    public Task<LoyaltyAccountRuleDto> SaveRuleAsync(
        Guid accountId, int? pointsInvoice, int? pointsAmc, string? reason, Guid? actorId,
        CancellationToken ct = default)
    {
        // Validated HERE as well as in Process and System (step 7). The bound
        // itself lives in one place — LoyaltyRules.IsValidPoints in Contracts —
        // so three layers enforce one rule rather than three spellings of it,
        // which would be three rules that agree until someone edits one.
        if (!LoyaltyRules.IsValidPoints(pointsInvoice))
            throw new ArgumentOutOfRangeException(nameof(pointsInvoice), LoyaltyRules.PointsRangeMessage);
        if (!LoyaltyRules.IsValidPoints(pointsAmc))
            throw new ArgumentOutOfRangeException(nameof(pointsAmc), LoyaltyRules.PointsRangeMessage);

        return _status.SaveRuleAsync(accountId, pointsInvoice, pointsAmc, reason, actorId, ct);
    }
}

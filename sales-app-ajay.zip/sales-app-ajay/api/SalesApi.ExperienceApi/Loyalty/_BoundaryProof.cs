// The Experience layer's boundary, stated as something you can run.
//
// SalesApi.ExperienceApi sets DisableTransitiveProjectReferences, so it sees
// SalesApi.ProcessApi and SalesApi.Contracts and NOTHING ELSE — no AppDbContext,
// no entities, no EF. Uncomment the three lines below and the project fails to
// compile with CS0234 ("the type or namespace name 'Data' does not exist in the
// namespace 'SalesApi'"). Verified 2026-08-28.
//
// That is the difference between this layering and the service layer it
// replaces. Nothing stopped a service reaching into a controller, so eventually
// fourteen of them did, and the layer decayed into a helper library. Here the
// compiler stops it.
//
// using SalesApi.Data;
// namespace SalesApi.ExperienceLayer.Loyalty;
// internal sealed class ProvesTheBoundary { private AppDbContext? _db; }

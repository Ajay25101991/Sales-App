using SalesApi.Dtos;
using SalesApi.ProcessLayer.Admin;
using SalesApi.ProcessLayer.Packages;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Admin;

/// <summary>
/// What the platform-admin console needs, shaped for that console.
///
/// THIS FILE CANNOT SEE THE DATABASE — `SalesApi.ExperienceApi` sets
/// `DisableTransitiveProjectReferences`, so `AppDbContext`, `Organization` and
/// `AllowedDomain` are invisible here. That constraint is what forced
/// `AggregateDriftReport` down into Contracts: this class returns it, and a
/// System type on that signature would not merely trip `LayerBoundaryTests`, it
/// would not compile.
///
/// Pass-through today, and the seam is the point (owner decision, 2026-08-28).
/// The second consumer is already easy to name: a support view that wants the
/// org register with its drift status attached, without the full per-org report.
/// When it arrives it lands here and Process stays untouched.
///
/// E7.2 (design doc to-do/e7-config-platform-design.md §3, §8 slice 8) adds
/// <see cref="PackageTemplateProcess"/>/<see cref="PackageCloneProcess"/> —
/// two independent Process classes this Experience COMPOSES rather than lets
/// leak into `PlatformProcess`: "create an org, then apply a template to it"
/// and "check both orgs exist, then clone one's config into the other" are
/// consumer-specific orchestrations of two otherwise-unrelated verticals
/// (org provisioning, package import), which is exactly what this layer is
/// for — Process stays about ONE domain's own rules.
/// </summary>
public sealed class AdminExperience
{
    private readonly PlatformProcess _platform;
    private readonly PackageTemplateProcess _templates;
    private readonly PackageCloneProcess _clone;

    public AdminExperience(PlatformProcess platform, PackageTemplateProcess templates, PackageCloneProcess clone)
    {
        _platform = platform;
        _templates = templates;
        _clone = clone;
    }

    // --- The self-registration allowlist ---

    public Task<List<AllowedDomainDto>> AllowedDomainsAsync(CancellationToken ct = default) =>
        _platform.AllowedDomainsAsync(ct);

    public Task<(AllowedDomainDto? Domain, PlatformProcess.Refusal? Refusal)> AddAllowedDomainAsync(
        AllowedDomainInput input, Guid actorId, CancellationToken ct = default) =>
        _platform.AddAllowedDomainAsync(input, actorId, ct);

    public Task<PlatformProcess.Refusal?> RemoveAllowedDomainAsync(Guid id, CancellationToken ct = default) =>
        _platform.RemoveAllowedDomainAsync(id, ct);

    // --- The organization register ---

    public Task<List<OrganizationDto>> OrganizationsAsync(CancellationToken ct = default) =>
        _platform.OrganizationsAsync(ct);

    /// <summary>Creates the org, then — only when <see cref="CreateOrganizationInput.TemplateId"/>
    /// names a real template — applies it through the same import pipeline
    /// any package uses (§3). An unrecognised template id refuses BEFORE the
    /// org is created (validated first), so a bad id never leaves a
    /// half-set-up org behind. A template that somehow fails to apply to the
    /// org it was just built for (it should never — see
    /// <see cref="PackageTemplateProcess.ApplyToNewOrgAsync"/>'s own
    /// defensive check) throws rather than reporting the org as cleanly
    /// created when it was not: a shipped template that cannot apply to an
    /// empty org is a bug in the template, not a normal refusal a caller
    /// should have to handle.</summary>
    public async Task<(AdminOrganizationDto? Org, PlatformProcess.Refusal? Refusal)> CreateOrganizationAsync(
        CreateOrganizationInput input, Guid actorId, CancellationToken ct = default)
    {
        if (!string.IsNullOrWhiteSpace(input.TemplateId) && !PackageTemplateProcess.Exists(input.TemplateId))
            return (null, new PlatformProcess.Refusal($"Unknown template '{input.TemplateId}'."));

        var (org, refusal) = await _platform.CreateOrganizationAsync(input, ct);
        if (refusal is not null || org is null) return (org, refusal);

        if (!string.IsNullOrWhiteSpace(input.TemplateId))
        {
            var (_, templateRefusal) = await _templates.ApplyToNewOrgAsync(org.Id, input.TemplateId!, actorId, ct);
            if (templateRefusal is not null)
                throw new InvalidOperationException(
                    $"Organization '{org.Name}' was created but template '{input.TemplateId}' failed to apply: {templateRefusal.Reason}");
        }

        return (org, null);
    }

    /// <summary>GET /templates — the new-org wizard's "start from template"
    /// picker (§3).</summary>
    public List<TemplateSummaryDto> Templates() => _templates.List();

    /// <summary>Clone-from-org (§3, §10 owner answer 2): platform-admin only
    /// (enforced at the controller, same discipline PlatformStore's own
    /// class comment states), config only, audited via the ordinary
    /// PackageApplyRecord trail. Both orgs must already exist.</summary>
    public async Task<(PackageApplyResultDto? Result, PlatformProcess.Refusal? Refusal)> CloneOrgConfigAsync(
        Guid sourceOrgId, Guid targetOrgId, string? name, Guid actorId, CancellationToken ct = default)
    {
        if (!await _platform.OrgExistsAsync(sourceOrgId, ct))
            return (null, new PlatformProcess.Refusal("Source organization not found", NotFound: true));
        if (!await _platform.OrgExistsAsync(targetOrgId, ct))
            return (null, new PlatformProcess.Refusal("Target organization not found", NotFound: true));

        var (result, refusal) = await _clone.CloneAsync(sourceOrgId, targetOrgId, name, actorId, ct);
        return refusal is null ? (result, null) : (null, new PlatformProcess.Refusal(refusal.Reason));
    }

    public Task<(int Deleted, PlatformProcess.Refusal? Refusal)> DeleteOrgLeadsAsync(
        Guid orgId, CancellationToken ct = default) =>
        _platform.DeleteOrgLeadsAsync(orgId, ct);

    // --- Aggregate health ---

    public Task<List<AggregateHealthDto>> AggregateHealthAsync(bool live, CancellationToken ct = default) =>
        _platform.AggregateHealthAsync(live, ct);

    public Task<(AggregateDriftReport? Report, PlatformProcess.Refusal? Refusal)> ResyncAggregatesAsync(
        Guid orgId, CancellationToken ct = default) =>
        _platform.ResyncAggregatesAsync(orgId, ct);
}

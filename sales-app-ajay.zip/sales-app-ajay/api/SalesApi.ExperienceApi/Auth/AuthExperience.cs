using SalesApi.Dtos;
using SalesApi.ProcessLayer.Auth;
using SalesApi.ProcessLayer.UserProfile;

namespace SalesApi.ExperienceLayer.Auth;

/// <summary>
/// What the auth screens need — today, exactly what Process computes. Every
/// method here forwards; nothing reshapes. Auth has one caller (the mobile/
/// desktop sign-in flow) that wants the same <see cref="AuthResponse"/> shape
/// every endpoint already returns, so there is nothing to reshape YET — the
/// seam exists for the day a second consumer (an admin console issuing invites
/// without redeeming its own, say) wants something narrower.
/// </summary>
public sealed class AuthExperience
{
    private readonly AuthProcess _auth;
    private readonly ProfileProcess? _profile;
    // ProfileProcess is optional so the hand-wired test chains that predate handoff keep compiling; DI always supplies it.
    public AuthExperience(AuthProcess auth, ProfileProcess? profile = null) { _auth = auth; _profile = profile; }

    public Task<(AuthProcess.Refusal? Refusal, HandoffCodeResponse? Response)> CreateHandoffAsync(
        HandoffRequest req, CancellationToken ct = default) => _auth.CreateHandoffAsync(req, ct);

    /// <summary>Same shape as sign-in. When the handed-over token is studio-scoped, the
    /// <c>user</c> is the ACTING org's profile (what GET /profile would say for that token),
    /// not the home-org one, so the client does not show the wrong org until its first refetch.</summary>
    public async Task<(AuthProcess.Refusal? Refusal, AuthResponse? Response)> RedeemHandoffAsync(
        string? code, CancellationToken ct = default)
    {
        var (refusal, redeemed) = await _auth.RedeemHandoffAsync(code, ct);
        if (refusal is not null || redeemed is null) return (refusal, null);
        var response = redeemed.Response;
        if (_profile is not null && redeemed.ActingOrgId is not null && redeemed.StudioKind is not null
            && await _profile.GetAsync(response.User.Id, redeemed.ActingOrgId, redeemed.StudioKind, ct: ct) is { } acting)
            response = response with { User = acting };
        return (null, response);
    }

    public Task<(AuthProcess.Refusal? Refusal, AuthResponse? Response)> SignupAsync(
        SignupRequest req, CancellationToken ct = default) => _auth.SignupAsync(req, ct);

    public Task<(AuthProcess.Refusal? Refusal, AuthResponse? Response)> SigninAsync(
        SigninRequest req, CancellationToken ct = default) => _auth.SigninAsync(req, ct);

    public Task<AuthResponse?> RefreshAsync(string? rawToken, CancellationToken ct = default) =>
        _auth.RefreshAsync(rawToken, ct);

    public Task SignOutAsync(Guid userId, string? refreshToken, CancellationToken ct = default) =>
        _auth.SignOutAsync(userId, refreshToken, ct);

    public Task<AuthProcess.Refusal?> RecordActivityAsync(Guid userId, string? platform, CancellationToken ct = default) =>
        _auth.RecordActivityAsync(userId, platform, ct);

    public Task<(AuthProcess.Refusal? Refusal, AuthResponse? Response, bool NoContent)> ChangePasswordAsync(
        Guid userId, ChangePasswordRequest req, CancellationToken ct = default) =>
        _auth.ChangePasswordAsync(userId, req, ct);

    public Task<(AuthProcess.Refusal? Refusal, AuthResponse? Response, string OutcomeLabel)> AcceptInviteAsync(
        AcceptInviteRequest req, CancellationToken ct = default) => _auth.AcceptInviteAsync(req, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.ProcessLayer.Usage;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Usage;

/// <summary>
/// What the usage screens and the platform's push need, shaped for them: the finance import (preview, commit, reject, history), a client's months, a deal's usage against its
/// frozen quote, and the scoped API push. Thin today - the Process layer already returns the DTOs the screens read. THIS FILE CANNOT SEE THE DATABASE (the Experience project hides the
/// System layer), so every rule stays below it.
/// </summary>
public sealed class UsageExperience
{
    private readonly UsageImportProcess _import;
    private readonly UsageViewProcess _view;
    public UsageExperience(UsageImportProcess import, UsageViewProcess view)
    {
        _import = import;
        _view = view;
    }

    public Task<CpResult<UsageBatchDto>> PreviewCsvAsync(UsageCsvInput input, Guid actorId, CancellationToken ct = default) => _import.PreviewCsvAsync(input, actorId, ct);
    public Task<CpResult<UsageBatchDto>> CommitAsync(Guid batchId, Guid actorId, CancellationToken ct = default) => _import.CommitAsync(batchId, actorId, ct);
    public Task<CpResult<UsageBatchDto>> RejectAsync(Guid batchId, Guid actorId, CancellationToken ct = default) => _import.RejectAsync(batchId, actorId, ct);
    public Task<CpResult<UsageBatchDto>> GetBatchAsync(Guid batchId, CancellationToken ct = default) => _import.GetAsync(batchId, ct);
    public Task<CpResult<List<UsageBatchDto>>> ListBatchesAsync(CancellationToken ct = default) => _import.ListAsync(ct);
    public Task<CpResult<UsageBatchDto>> PushAsync(UsagePushInput input, Guid? apiKeyId, CancellationToken ct = default) => _import.PushAsync(input, apiKeyId, ct);

    public Task<CpResult<UsageAccountDto>> AccountAsync(RecordAccessContext ctx, Guid accountId, DateOnly? from, DateOnly? to, CancellationToken ct = default) =>
        _view.AccountAsync(ctx, accountId, from, to, ct);
    public Task<CpResult<UsageDealDto>> DealAsync(RecordAccessContext ctx, Guid leadId, int? contractYear, CancellationToken ct = default) =>
        _view.DealAsync(ctx, leadId, contractYear, ct);
}

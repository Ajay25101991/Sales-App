using SalesApi.Dtos;
using SalesApi.ProcessLayer.UserProfile;

namespace SalesApi.ExperienceLayer.UserProfile;

/// <summary>
/// What GET/PATCH /profile need. FORWARDS — the endpoint wants exactly what
/// <see cref="ProfileProcess"/> computes. Built anyway, per the owner's
/// 2026-08-28 decision to add Experience uniformly rather than carry a
/// growing list of exceptions.
///
/// Both methods take the caller's OWN <c>userId</c>, the same load-bearing
/// rule as Process: the backend derives the user from the TOKEN, and nothing
/// on this surface lets a client name a different one.
/// </summary>
public sealed class ProfileExperience
{
    private readonly ProfileProcess _profile;
    public ProfileExperience(ProfileProcess profile) => _profile = profile;

    public Task<ProfileDto?> GetAsync(
        Guid userId, Guid? actingOrgId = null, string? studioKind = null, string? previewRoleKey = null,
        CancellationToken ct = default) =>
        _profile.GetAsync(userId, actingOrgId, studioKind, previewRoleKey, ct);

    public Task<ProfileDto?> UpdateAsync(
        Guid userId, string? fullName, string? expoPushToken, CancellationToken ct = default) =>
        _profile.UpdateAsync(userId, fullName, expoPushToken, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Reports;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Reports;

/// <summary>
/// What the analytics screens need, shaped for them.
///
/// Reports are the clearest case in the codebase for this layer existing, and
/// also the one where it is currently thinnest. Every figure here already has
/// two audiences with different needs — the desktop analytics tabs, which want
/// the full breakdown, and the phone, which wants the headline and a trend —
/// and a third is already named in the backlog (a scheduled digest that mails a
/// subset). None of those differences belong in Process, which computes a report
/// from a scope and should not know who is looking.
///
/// It forwards today. That is the honest state of a slice mid-migration, not a
/// claim that the layer is pointless: the alternative is that the first consumer
/// with a different shape edits the computation, and then the two shapes are one
/// function with a flag.
/// </summary>
public sealed class ReportsExperience
{
    private readonly ReportsProcess _reports;
    private readonly MovementProcess _movement;
    private readonly TrendsProcess _trends;
    private readonly LeaderboardProcess _leaderboard;
    private readonly MdPackProcess _mdPack;
    private readonly ScorecardProcess _scorecard;
    private readonly NeedsYouTodayProcess _needsYouToday;

    public ReportsExperience(
        ReportsProcess reports, MovementProcess movement, TrendsProcess trends,
        LeaderboardProcess leaderboard, MdPackProcess mdPack, ScorecardProcess scorecard,
        NeedsYouTodayProcess needsYouToday)
    {
        _reports = reports;
        _movement = movement;
        _trends = trends;
        _leaderboard = leaderboard;
        _mdPack = mdPack;
        _scorecard = scorecard;
        _needsYouToday = needsYouToday;
    }

    // --- Scope helpers the endpoints need before they can ask for anything ----
    // These answer questions ABOUT the caller's scope rather than returning a
    // report, which is why they are here rather than folded into each read: the
    // controller needs them to pick a status code (403 for a person outside
    // scope) before any figure is computed.

    public Task<List<Guid>?> VisiblePeopleAsync(RecordAccessContext ctx) => _reports.VisiblePeopleAsync(ctx);

    public Task<bool> CanSeePersonAsync(RecordAccessContext ctx, Guid id) => _reports.CanSeePersonAsync(ctx, id);

    // --- The reports ----------------------------------------------------------

    /// <summary>Win/loss, optionally scoped to one team. The caller has already
    /// decided whether this reader may see the requested team — same division of
    /// labour as LeaderboardAsync below.</summary>
    public Task<WinLossDto> WinLossAsync(
        RecordAccessContext ctx, bool showValues, string period, Guid? teamId = null) =>
        _reports.WinLossAsync(ctx, showValues, period, teamId);

    public Task<List<ForecastSnapshotDto>> ForecastSnapshotsAsync(bool showValues) =>
        _reports.ForecastSnapshotsAsync(showValues);

    public Task<(ReportsProcess.CompareRefusal? Refusal, PeriodComparisonDto? Dto)> CompareAsync(
        RecordAccessContext ctx, bool showValues, string measure,
        DateTime start, DateTime end, string? basis, Guid? ownerId) =>
        _reports.CompareAsync(ctx, showValues, measure, start, end, basis, ownerId);

    public ExploreCatalogueDto ExploreCatalogue() => ReportsProcess.ExploreCatalogue();

    public Task<(ReportsProcess.ExploreRefusal? Refusal, ExploreResultDto? Dto)> ExploreAsync(
        RecordAccessContext ctx, string? measures, string? groupBy, string? splitBy, string? grain,
        DateTime? start, DateTime? end, string? owners, string? sources, string? stages, string? teams,
        string? dealTypes = null, CancellationToken ct = default) =>
        _reports.ExploreAsync(ctx, measures, groupBy, splitBy, grain, start, end, owners, sources, stages, teams, dealTypes, ct);

    public Task<TrendsDto> TrendsAsync(
        RecordAccessContext ctx, bool showValues, bool showFinancials, string granularity) =>
        _trends.BuildAsync(ctx, showValues, showFinancials, granularity);

    /// <summary>The leaderboard rows, ranked. The caller has already decided
    /// whether this reader may see the requested team.</summary>
    public Task<List<LeaderboardRowDto>> LeaderboardAsync(
        RecordAccessContext access, Guid? orgId, bool showValues, string period, Guid? teamId, List<string>? dealTypes = null) =>
        _leaderboard.BuildAsync(access, orgId, showValues, period, teamId, dealTypes: dealTypes);

    public Task<string> LeaderboardCsvAsync(
        RecordAccessContext access, Guid? orgId, bool showValues, string period, Guid? teamId, List<string>? dealTypes = null) =>
        _leaderboard.ExportCsvAsync(access, orgId, showValues, period, teamId, dealTypes: dealTypes);

    public Task<(string? Refusal, ActivityEffortDto? Dto)> ActivityEffortAsync(
        RecordAccessContext access, bool showValues, DateTime? start, DateTime? end) =>
        _reports.ActivityEffortAsync(access, showValues, start, end);

    public Task<CohortsDto> CohortsAsync(RecordAccessContext access, int months, int maxAgeMonths) =>
        _reports.CohortsAsync(access, months, maxAgeMonths);

    public Task<ActivityReportDto> ActivityAsync(RecordAccessContext access, Guid? orgId) =>
        _reports.ActivityAsync(access, orgId);

    public Task<List<FeedItemDto>> FeedAsync(RecordAccessContext access) => _reports.FeedAsync(access);

    public Task<(ReportsProcess.RepRefusal? Refusal, RepReportDto? Dto)> RepAsync(
        RecordAccessContext access, Guid? orgId, bool showValues, Guid id) =>
        _reports.RepAsync(access, orgId, showValues, id);

    public Task<(ReportsProcess.RepRefusal? Refusal, string? Csv)> RepExportCsvAsync(
        RecordAccessContext access, Guid? orgId, bool showValues, Guid id) =>
        _reports.RepExportCsvAsync(access, orgId, showValues, id);

    public Task<StagePerformanceDto> StagePerformanceAsync(
        RecordAccessContext access, Guid? orgId, int days) =>
        _reports.StagePerformanceAsync(access, orgId, days);

    public Task<LeadsAddedReportDto> LeadsAddedAsync(
        RecordAccessContext access, Guid? orgId, DateTime? from, DateTime? to) =>
        _reports.LeadsAddedAsync(access, orgId, from, to);

    public Task<string> LeadsAddedCsvAsync(
        RecordAccessContext access, Guid? orgId, DateTime? from, DateTime? to) =>
        _reports.LeadsAddedCsvAsync(access, orgId, from, to);

    public Task<QuoteConversionDto> QuotesAsync(
        RecordAccessContext access, Guid? orgId, bool showValues, string period) =>
        _reports.QuotesAsync(access, orgId, showValues, period);

    /// <summary>Org-wide quote conversion for the MD pack — deliberately not the
    /// reader-scoped reading; see ReportsProcess for why that is a separate
    /// method rather than a flag.</summary>
    public Task<QuoteConversionDto> QuoteConversionOrgWideAsync(
        Guid? orgId, bool showValues, DateTime? periodStart, DateTime? periodEnd) =>
        _reports.QuoteConversionOrgWideAsync(orgId, showValues, periodStart, periodEnd);

    public Task<PipelineCoverageDto> PipelineCoverageAsync(
        RecordAccessContext access, Guid? orgId, bool showValues, Guid? teamId = null) =>
        _reports.PipelineCoverageAsync(access, orgId, showValues, teamId);

    public Task<(string? Refusal, MdPackDto? Dto)> MdPackAsync(
        RecordAccessContext access, Guid? orgId, string? period, bool canSeeFinancials = true) =>
        _mdPack.BuildAsync(access, orgId, period, canSeeFinancials);

    public Task<(ScorecardProcess.Refusal? Refusal, ScorecardDto? Dto)> ScorecardAsync(
        RecordAccessContext access, Guid callerId, Guid? orgId, bool showValues,
        string? period, Guid? userId) =>
        _scorecard.BuildAsync(access, callerId, orgId, showValues, period, userId);

    public Task<(ScorecardProcess.Refusal? Refusal, string? Csv)> ScorecardCsvAsync(
        RecordAccessContext access, Guid callerId, Guid? orgId, bool showValues,
        string? period, Guid? userId) =>
        _scorecard.ExportCsvAsync(access, callerId, orgId, showValues, period, userId);

    /// <summary>The action list. Both gates are facts about the CALLER, decided
    /// at the endpoint and passed down — see NeedsYouTodayProcess.</summary>
    public Task<NeedsYouTodayDto> NeedsYouTodayAsync(
        RecordAccessContext access, Guid? orgId, bool showMoney, bool canDecideApprovals,
        Guid? teamId = null) =>
        _needsYouToday.BuildAsync(access, orgId, showMoney, canDecideApprovals, teamId);

    // --- Movement (migrated first; wrapped here so the controller has ONE
    // Experience dependency rather than one per slice) -------------------------

    public Task<MovementReportDto> MovementAsync(
        RecordAccessContext ctx, Guid? orgId, bool showValues,
        DateTime? from, DateTime? to, Guid? ownerId, Guid? teamId = null) =>
        _movement.BuildAsync(ctx, orgId, showValues, from, to, ownerId, teamId);

    // --- Estimated vs closed (GET /reports/estimated-vs-closed) ---------------
    // No showValues parameter: the controller gates this action outright on
    // lead_values.view (403), so every caller that reaches here may see values.
    public Task<EstimatedVsClosedReportDto> EstimatedVsClosedAsync(
        RecordAccessContext ctx, Guid? teamId, Guid? ownerId, DateOnly? from, DateOnly? to,
        bool onlyDifferent, string? cursor, int? limit, CancellationToken ct = default) =>
        _reports.EstimatedVsClosedAsync(ctx, teamId, ownerId, from, to, onlyDifferent, cursor, limit, ct);
}

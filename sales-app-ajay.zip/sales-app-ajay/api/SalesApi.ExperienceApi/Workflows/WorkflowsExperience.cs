using SalesApi.Dtos;
using SalesApi.ProcessLayer.Workflows;

namespace SalesApi.ExperienceLayer.Workflows;

/// <summary>
/// What the workflow designer screen needs, shaped for it.
///
/// It forwards today, and says so plainly rather than dressing itself up:
/// every endpoint already returns exactly what Process computes, and this is
/// legacy, single-consumer territory (the desktop app has moved on to
/// playbooks; this path exists for the two phone clients that still design
/// pipelines the old way). Built anyway — the owner's decision was every
/// domain gets an Experience class for uniformity, so the seam is already
/// here the day a second consumer wants something different.
/// </summary>
public sealed class WorkflowsExperience
{
    private readonly WorkflowProcess _workflows;
    public WorkflowsExperience(WorkflowProcess workflows) => _workflows = workflows;

    public Task<List<WorkflowResponseDto>> GetAllAsync(Guid? orgId, CancellationToken ct = default) =>
        _workflows.GetAllAsync(orgId, ct);

    public Task<(WorkflowResponseDto? Result, WorkflowProcess.Refusal? Refusal)> CreateAsync(
        Guid orgId, WorkflowInput input, Guid actorId, CancellationToken ct = default) =>
        _workflows.CreateAsync(orgId, input, actorId, ct);

    public Task<(WorkflowResponseDto? Result, WorkflowProcess.Refusal? Refusal)> UpdateAsync(
        Guid orgId, Guid id, WorkflowInput input, CancellationToken ct = default) =>
        _workflows.UpdateAsync(orgId, id, input, ct);

    public Task<(WorkflowPublishPreviewDto? Result, WorkflowProcess.Refusal? Refusal)> PublishPreviewAsync(
        Guid orgId, Guid id, bool showValue, CancellationToken ct = default) =>
        _workflows.PublishPreviewAsync(orgId, id, showValue, ct);

    public Task<(WorkflowResponseDto? Result, WorkflowProcess.Refusal? Refusal)> PublishAsync(
        Guid orgId, Guid id, Dictionary<string, string>? remap, bool showValue, Guid movedById,
        CancellationToken ct = default) =>
        _workflows.PublishAsync(orgId, id, remap, showValue, movedById, ct);

    public Task<WorkflowProcess.Refusal?> DeleteAsync(Guid orgId, Guid id, CancellationToken ct = default) =>
        _workflows.DeleteAsync(orgId, id, ct);
}

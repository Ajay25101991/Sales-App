using SalesApi.Dtos;
using SalesApi.ProcessLayer.Meta;

namespace SalesApi.ExperienceLayer.Meta;

/// <summary>What the Meta Lead Ads admin screens and the public webhook need. FORWARDS - same shape as <c>LinkedInExperience</c>.</summary>
public sealed class MetaExperience
{
    private readonly MetaOAuthProcess _oauth;
    private readonly MetaPagesProcess _pages;
    private readonly MetaFormMappingProcess _mapping;
    private readonly MetaFormsProcess _forms;
    private readonly MetaLeadSyncProcess _sync;

    public MetaExperience(
        MetaOAuthProcess oauth, MetaPagesProcess pages, MetaFormMappingProcess mapping, MetaFormsProcess forms, MetaLeadSyncProcess sync)
    {
        _oauth = oauth;
        _pages = pages;
        _mapping = mapping;
        _forms = forms;
        _sync = sync;
    }

    public Task<(MetaOAuthRefusal? Refusal, MetaAuthorizeUrlDto? Result)> BuildAuthorizeUrlAsync(
        Guid orgId, Guid profileId, string adminName, CancellationToken ct = default) =>
        _oauth.BuildAuthorizeUrlAsync(orgId, profileId, adminName, ct);

    public Task<(MetaOAuthRefusal? Refusal, MetaConnectResult? Result)> ExchangeCallbackAsync(
        string code, string state, CancellationToken ct = default) =>
        _oauth.ExchangeCallbackAsync(code, state, ct);

    public Task<MetaConnectionDetailDto> GetConnectionDetailAsync(Guid orgId, CancellationToken ct = default) =>
        _oauth.GetConnectionDetailAsync(orgId, ct);

    public Task<(MetaSelectPagesResultDto? Result, MetaPagesProcess.Refusal? Refusal)> SelectPagesAsync(
        IReadOnlyCollection<string> pageIds, CancellationToken ct = default) =>
        _pages.SelectPagesAsync(pageIds, ct);

    public Task<MetaBackfillResultDto> BackfillAsync(string? pageId, CancellationToken ct = default) =>
        _pages.BackfillAsync(pageId, ct);

    public Task DisconnectAsync(CancellationToken ct = default) => _pages.DisconnectAsync(ct);

    public Task<MetaFormsResultDto> GetFormsAsync(Guid orgId, CancellationToken ct = default) => _forms.GetFormsAsync(orgId, ct);

    public Task<List<MetaFormMappingDto>> ListMappingsAsync(CancellationToken ct = default) => _mapping.ListAsync(ct);

    public Task<MetaFormMappingDto?> GetMappingAsync(string formId, CancellationToken ct = default) => _mapping.GetAsync(formId, ct);

    public Task<(MetaFormMappingDto? Dto, MetaFormMappingProcess.Refusal? Refusal)> SaveMappingAsync(
        MetaFormMappingInput input, Guid actorId, CancellationToken ct = default) =>
        _mapping.SaveAsync(input, actorId, ct);

    public Task<bool> DeleteMappingAsync(string formId, CancellationToken ct = default) => _mapping.DeleteAsync(formId, ct);

    // The public webhook (anonymous; trust is the signature / verify token).
    public Task<bool> VerifyHandshakeAsync(Guid orgId, string? mode, string? verifyToken, CancellationToken ct = default) =>
        _sync.VerifyHandshakeAsync(orgId, mode, verifyToken, ct);

    public Task<MetaWebhookOutcome> HandleWebhookAsync(Guid orgId, byte[] rawBody, string? signatureHeader, CancellationToken ct = default) =>
        _sync.HandleWebhookAsync(orgId, rawBody, signatureHeader, ct);
}

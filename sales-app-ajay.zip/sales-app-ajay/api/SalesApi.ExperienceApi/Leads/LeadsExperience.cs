using SalesApi.Dtos;
using SalesApi.ProcessLayer.Leads;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Leads;

/// <summary>
/// What the lead screens need, shaped for them.
///
/// `LeadsController` is the largest surface in the app — 27 endpoints across
/// create, edit, merge, import, proposals and the pipeline board — and it has
/// the most obviously distinct consumers of anything here: a phone's swipeable
/// lead card, the desktop board, the CSV importer, and the public web form all
/// read and write the same rows through very different shapes.
///
/// It forwards today, one slice at a time as the controller is strangled. The
/// point of the seam is that when the phone wants a lead card without the
/// proposal history, that difference lands in this file and the Process layer
/// stays as it is.
/// </summary>
public sealed class LeadsExperience
{
    private readonly LeadMergeProcess _merge;
    private readonly LeadQuoteProcess _quotes;
    private readonly LeadImportProcess _import;
    private readonly LeadReadProcess _reads;
    private readonly LeadAssignProcess _assign;
    private readonly LeadWriteProcess _writes;
    private readonly LeadListProcess _list;

    public LeadsExperience(
        LeadMergeProcess merge, LeadQuoteProcess quotes, LeadImportProcess import,
        LeadReadProcess reads, LeadAssignProcess assign, LeadWriteProcess writes,
        LeadListProcess list)
    {
        _list = list;
        _merge = merge;
        _quotes = quotes;
        _import = import;
        _reads = reads;
        _assign = assign;
        _writes = writes;
    }

    // --- Merging and deleting -------------------------------------------------
    // The caller's scope and its two render permissions travel in as data; see
    // LeadView for why the mapper cannot resolve them itself.

    public Task<(LeadMergeProcess.Refusal? Refusal, MergePreviewDto? Dto)> MergePreviewAsync(
        RecordAccessContext vis, LeadView view, Guid? primaryId, Guid? duplicateId) =>
        _merge.PreviewAsync(vis, view, primaryId, duplicateId);

    public Task<(LeadMergeProcess.Refusal? Refusal, MergeResultDto? Dto)> MergeAsync(
        RecordAccessContext vis, LeadView view, Guid actorId, MergeInput input) =>
        _merge.MergeAsync(vis, view, actorId, input);

    public Task<(LeadMergeProcess.Refusal? Refusal, LeadDto? Dto)> UndoMergeAsync(
        RecordAccessContext vis, LeadView view, Guid actorId, Guid? orgId, Guid id) =>
        _merge.UndoMergeAsync(vis, view, actorId, orgId, id);

    public Task<LeadMergeProcess.Refusal?> DeleteAsync(RecordAccessContext vis, Guid id) =>
        _merge.DeleteAsync(vis, id);

    // --- Quotes on a lead -----------------------------------------------------
    // The override path takes BOTH the permission and the actor's display name,
    // because the audit note it writes has to say who forced the decision.

    public Task<(LeadQuoteProcess.Refusal? Refusal, List<ProposalDto>? Dto)> QuotesAsync(
        RecordAccessContext vis, Guid id) => _quotes.ListAsync(vis, id);

    public Task<(LeadQuoteProcess.Refusal? Refusal, ProposalDto? Dto)> GenerateQuoteAsync(
        RecordAccessContext vis, Guid actorId, Guid id, GenerateProposalInput input) =>
        _quotes.GenerateAsync(vis, actorId, id, input);

    public Task<(LeadQuoteProcess.Refusal? Refusal, ProposalDto? Dto)> GenerateQuoteDocumentAsync(
        RecordAccessContext vis, Guid actorId, Guid id, GenerateQuoteDocumentInput input) =>
        _quotes.GenerateDocumentAsync(vis, actorId, id, input);

    public Task<(LeadQuoteProcess.Refusal? Refusal, ProposalDto? Dto)> UpdateQuoteAsync(
        RecordAccessContext vis, Guid actorId, string actorName, bool canOverrideQuoteStatus,
        Guid id, Guid pid, ProposalStatusInput input) =>
        _quotes.UpdateAsync(vis, actorId, actorName, canOverrideQuoteStatus, id, pid, input);

    public Task<(LeadQuoteProcess.Refusal? Refusal, string? Token)> QuoteShareLinkAsync(RecordAccessContext vis, Guid id, Guid pid) =>
        _quotes.ShareLinkAsync(vis, id, pid);

    public Task<(LeadQuoteProcess.Refusal? Refusal, ProposalDto? Dto)> ReviseQuoteAsync(
        RecordAccessContext vis, Guid actorId, Guid id, Guid pid) =>
        _quotes.ReviseAsync(vis, actorId, id, pid);

    // --- CSV import -----------------------------------------------------------
    // The importer is the clearest case on this surface for a shaping layer that
    // is not yet needed: the wizard wants a preview, an eventual scheduled feed
    // would want none of it. Both read the same code today.

    public Task<(LeadImportProcess.Refusal? Refusal, CsvImportResult? Dto)> ImportAsync(
        Guid actorId, Guid? orgId, bool canAssign, LeadView view, CsvImportInput input,
        string? accountModeRaw, Guid? teamId, bool preview, bool createReminders) =>
        _import.ImportAsync(actorId, orgId, canAssign, view, input, accountModeRaw, teamId, preview, createReminders);

    public Task<(LeadImportProcess.Refusal? Refusal, SavedImportMappingDto? Dto)> SavedImportMappingAsync(
        string? headers) => _import.SavedMappingAsync(headers);

    public Task<CsvImportDefaultsDto> ImportDefaultsAsync(Guid actorId) => _import.DefaultsAsync(actorId);

    // --- One lead, and the things hanging off it -------------------------------

    public Task<(LeadReadProcess.Refusal? Refusal, LeadDto? Dto)> GetAsync(
        RecordAccessContext vis, LeadView view, Guid id) => _reads.GetAsync(vis, view, id);

    public Task<(LeadReadProcess.Refusal? Refusal, List<LeadStageEventDto>? Dto)> StageHistoryAsync(
        RecordAccessContext vis, Guid id) => _reads.StageHistoryAsync(vis, id);

    public Task<(LeadReadProcess.Refusal? Refusal, PagedResult<FieldChangeAuditEntryDto>? Page)> HistoryAsync(
        RecordAccessContext vis, LeadView view, Guid id, string? cursor, int? limit) =>
        _reads.HistoryAsync(vis, view, id, cursor, limit);

    public Task<(LeadReadProcess.Refusal? Refusal, PagedResult<TimelineItemDto>? Page)> TimelineAsync(
        RecordAccessContext vis, LeadView view, bool canSeeFinancials, Guid id, string? cursor, int? limit, string? kinds) =>
        _reads.TimelineAsync(vis, view, canSeeFinancials, id, cursor, limit, kinds);

    public Task<(LeadReadProcess.Refusal? Refusal, List<ActivityDto>? Dto)> ActivitiesAsync(
        RecordAccessContext vis, Guid id) => _reads.ActivitiesAsync(vis, id);

    public Task<(LeadReadProcess.Refusal? Refusal, ActivityDto? Dto)> AddActivityAsync(
        RecordAccessContext vis, Guid actorId, string actorName, Guid id, ActivityInput input) =>
        _reads.AddActivityAsync(vis, actorId, actorName, id, input);

    public Task<List<string>> CompaniesAsync(RecordAccessContext vis, string? q) =>
        _reads.CompaniesAsync(vis, q);

    // --- Reassignment and contact promotion -------------------------------------

    public Task<(LeadAssignProcess.Refusal? Refusal, LeadDto? Dto)> AssignAsync(
        RecordAccessContext vis, LeadView view, Guid actorId, string actorName, Guid? orgId,
        bool callerIsManager, string visibility, Guid id, AssignInput input) =>
        _assign.AssignAsync(vis, view, actorId, actorName, orgId, callerIsManager, visibility, id, input);

    public Task<(LeadAssignProcess.Refusal? Refusal, PromoteContactResultDto? Dto)> PromoteContactAsync(
        RecordAccessContext access, Guid id) => _assign.PromoteContactAsync(access, id);

    // --- The write core --------------------------------------------------------
    // Create, update and bulk. Their refusals carry a code and a payload so the
    // endpoint can rebuild the exact bodies these routes have always returned —
    // see LeadWriteProcess.Refusal.

    public Task<(LeadWriteProcess.Refusal? Refusal, LeadDto? Dto)> CreateAsync(
        RecordAccessContext vis, LeadView view, LeadActor actor, LeadInput input,
        IReadOnlyList<LeadWriteProcess.GateFile>? gateFiles = null) =>
        _writes.CreateAsync(vis, view, actor, input, gateFiles);

    public Task<LeadPlaybookPreviewDto> PreviewPlaybookAsync(LeadActor actor, LeadInput input) =>
        _writes.PreviewPlaybookAsync(actor, input);

    // E3.12 — "the form shown is the form checked". Same resolver
    // CreateAsync/UpdateAsync themselves call; see LeadWriteProcess's own
    // remarks on each.
    public Task<LeadFormResolutionDto> PreviewCreateFormAsync(LeadActor actor, string callerRole, LeadFormForCreateInput input) =>
        _writes.PreviewCreateFormAsync(actor, callerRole, input);

    public Task<LeadFormResolutionDto?> PreviewLeadFormAsync(RecordAccessContext vis, Guid leadId, string callerRole) =>
        _writes.PreviewLeadFormAsync(vis, leadId, callerRole);

    // Item 6 - the stage-move dialog's question: which "rep picks" stage tasks does this move create, and who may the mover hand them to.
    public Task<(LeadWriteProcess.Refusal? Refusal, StageTaskPicksDto? Dto)> StageTaskPicksAsync(
        RecordAccessContext vis, LeadActor actor, Guid leadId, string toStatus) =>
        _writes.StageTaskPicksAsync(vis, actor, leadId, toStatus);

    // Parked item 7 - the stage-move dialog's question for a move to the Won stage: which deal values / payment term does the win ask.
    public Task<(LeadWriteProcess.Refusal? Refusal, WinAskDto? Dto)> WinAskAsync(
        RecordAccessContext vis, LeadView view, Guid actorId, Guid leadId, string toStatus) =>
        _writes.WinAskAsync(vis, view, actorId, leadId, toStatus);

    public Task<(LeadWriteProcess.Refusal? Refusal, LeadDto? Dto)> UpdateAsync(
        RecordAccessContext vis, LeadView view, LeadActor actor, Guid id, LeadInput input) =>
        _writes.UpdateAsync(vis, view, actor, id, input);

    /// <summary>
    /// POST /leads/bulk. Exactly one of <c>ids</c> / <c>match</c>: a <c>match</c> ("select all N matching") is resolved to ids by the
    /// list's own filtered query (<see cref="LeadListProcess.MatchingIdsAsync"/>, the one /leads/count counts), then runs the
    /// ordinary per-row bulk path - same rules, skips counted. A match that finds nothing is a successful no-op (0 updated).
    /// </summary>
    public async Task<(LeadWriteProcess.Refusal? Refusal, BulkResult? Dto)> BulkAsync(
        RecordAccessContext vis, LeadView view, LeadActor actor, BulkInput input)
    {
        if (input.Match is null) return await _writes.BulkAsync(vis, actor, input);
        if (input.Ids is not null)
            return (new LeadWriteProcess.Refusal("Send either ids or match, not both"), null);
        if (input.Action is not ("assign" or "stage" or "delete" or "tag_add" or "tag_remove"))
            return (new LeadWriteProcess.Refusal("action must be assign, stage, delete, tag_add or tag_remove"), null);
        var ids = await _list.MatchingIdsAsync(vis, actor.Id, input.Match, view);
        if (ids.Count == 0) return (null, new BulkResult(0, 0, []));
        return await _writes.BulkAsync(vis, actor, input with { Ids = ids, Match = null });
    }

    /// <summary>POST /leads/bulk/ids: what a "select all N matching" resolves to, for a client that runs the action in batches.</summary>
    public Task<List<Guid>> MatchingIdsAsync(RecordAccessContext vis, LeadView view, Guid actorId, LeadMatchInput match) =>
        _list.MatchingIdsAsync(vis, actorId, match, view);

    // --- The list, and everything computed from the same filter set -------------
    // One builder behind all five, so the count, the value total and the facets
    // can never describe a different population from the rows on screen.

    public Task<(LeadListProcess.Refusal? Refusal, object? Dto)> ListAsync(
        RecordAccessContext vis, LeadView view, Guid actorId,
        string? status, string? search, string? sort, string? owner, string? source, string? product,
        bool overdue, bool idle, bool mine, int? limit, int? offset, double? similarity,
        string? custom, bool paged, string? cursor,
        DateTime? quietSince, int? quietWindowDays, string? tagIds, Guid? teamId, string? dealType = null,
        string? filters = null, string? sorts = null) =>
        _list.ListAsync(vis, view, actorId, status, search, sort, owner, source, product,
            overdue, idle, mine, limit, offset, similarity, custom, paged, cursor,
            quietSince, quietWindowDays, tagIds, teamId, dealType, filters, sorts);

    public Task<int> CountAsync(
        RecordAccessContext vis, Guid actorId,
        string? status, string? search, string? owner, string? source, string? product,
        bool overdue, bool idle, bool mine, double? similarity, string? custom,
        DateTime? quietSince, int? quietWindowDays, string? tagIds, Guid? teamId, string? dealType = null,
        bool canSeeContactDetails = true, string? filters = null, LeadView? view = null) =>
        _list.CountAsync(vis, actorId, status, search, owner, source, product,
            overdue, idle, mine, similarity, custom, quietSince, quietWindowDays, tagIds, teamId, dealType, canSeeContactDetails, filters, view);

    public Task<decimal> ValueTotalAsync(
        RecordAccessContext vis, Guid actorId,
        string? status, string? search, string? owner, string? source, string? product,
        bool overdue, bool idle, bool mine, double? similarity, string? custom, string? tagIds,
        Guid? teamId, string? dealType = null, bool canSeeContactDetails = true,
        string? filters = null, LeadView? view = null) =>
        _list.ValueTotalAsync(vis, actorId, status, search, owner, source, product,
            overdue, idle, mine, similarity, custom, tagIds, teamId, dealType, canSeeContactDetails, filters, view);

    public Task<LeadFacetsDto> FacetsAsync(
        RecordAccessContext vis, Guid actorId,
        string? status, string? search, string? owner, string? source, string? product,
        bool overdue, bool idle, bool mine, double? similarity, Guid? teamId, bool canSeeContactDetails = true,
        string? filters = null, LeadView? view = null) =>
        _list.FacetsAsync(vis, actorId, status, search, owner, source, product, overdue, idle, mine, similarity, teamId, canSeeContactDetails, filters, view);

    /// <summary>GET /leads/columns — the one-table column catalogue for this caller.</summary>
    public Task<TableColumnsDto> ColumnsAsync(RecordAccessContext vis, LeadView view) => _list.ColumnsAsync(vis, view);

    public Task<LeadTeamBackfillDto> BackfillTeamsAsync(
        bool preview, int? limit = null, CancellationToken ct = default) =>
        _writes.BackfillTeamsAsync(preview, limit, ct);

    public Task<string> ExportCsvAsync(RecordAccessContext vis, LeadView view, string? filters = null, string? sorts = null, List<Guid>? ids = null) =>
        _list.ExportCsvAsync(vis, view, filters, sorts, ids);
}

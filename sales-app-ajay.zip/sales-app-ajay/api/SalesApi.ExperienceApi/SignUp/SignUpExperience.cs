using SalesApi.Dtos;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.ProcessLayer.SignUp;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.SignUp;

/// <summary>
/// The controller-facing shape for E19.5's four surfaces: the admin settings, the public sign-up (options, start, verify), the applicant's own application (read, submit), and the
/// staff review queue. Pass-through to <see cref="SignUpProcess"/> - the seam exists for consistency with every other vertical; no orchestration across verticals lives here.
/// </summary>
public sealed class SignUpExperience
{
    private readonly SignUpProcess _signUp;
    public SignUpExperience(SignUpProcess signUp) => _signUp = signUp;

    // ---- admin settings ----
    public Task<SignUpSettingsDto> GetSettingsAsync(CancellationToken ct = default) => _signUp.GetSettingsAsync(ct);
    public Task<CpResult<SignUpSettingsDto>> UpdateSettingsAsync(SignUpSettingsInput input, CancellationToken ct = default) => _signUp.UpdateSettingsAsync(input, ct);

    // ---- public ----
    public Task<CpResult<SignUpOptionsDto>> OptionsAsync(string? org, string? kind, CancellationToken ct = default) => _signUp.OptionsAsync(org, kind, ct);
    public Task<CpResult<bool>> StartAsync(SignUpStartInput input, Func<string, string> buildUrl, CancellationToken ct = default) => _signUp.StartAsync(input, buildUrl, ct);
    public Task<CpResult<SignUpVerifyDto>> VerifyAsync(SignUpVerifyInput input, CancellationToken ct = default) => _signUp.VerifyAsync(input, ct);

    // ---- the applicant ----
    public Task<CpResult<SignUpDetailsDto>> DetailsAsync(PortalScope scope, CancellationToken ct = default) => _signUp.DetailsAsync(scope, ct);
    public Task<CpResult<SignUpMineDto>> MineAsync(PortalScope scope, CancellationToken ct = default) => _signUp.MineAsync(scope, ct);
    public Task<CpResult<SignUpApplicationDto>> SubmitAsync(PortalScope scope, SignUpSubmitInput input, CancellationToken ct = default) => _signUp.SubmitAsync(scope, input, ct);

    // ---- staff ----
    public Task<CpResult<List<SignUpApplicationDto>>> ListAsync(RecordAccessContext ctx, string? status, string? kind, CancellationToken ct = default) =>
        _signUp.ListAsync(ctx, status, kind, ct);
    public Task<CpResult<SignUpApplicationDetailDto>> GetAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) => _signUp.GetAsync(ctx, id, ct);
    public Task<CpResult<SignUpApplicationDto>> ApproveAsync(
        RecordAccessContext ctx, PartnerImportActor actor, Guid id, SignUpApproveInput input, Func<string, string> buildUrl, CancellationToken ct = default) =>
        _signUp.ApproveAsync(ctx, actor, id, input, buildUrl, ct);
    public Task<CpResult<SignUpApplicationDto>> RejectAsync(
        RecordAccessContext ctx, PartnerImportActor actor, Guid id, SignUpRejectInput input, CancellationToken ct = default) =>
        _signUp.RejectAsync(ctx, actor, id, input, ct);
    public Task<CpResult<SignUpCountDto>> CountAsync(RecordAccessContext ctx, CancellationToken ct = default) => _signUp.CountAsync(ctx, ct);
    public Task<CpResult<SignUpApplicationDto>> LinkAsync(
        RecordAccessContext ctx, PartnerImportActor actor, Guid id, SignUpLinkInput input, Func<string, string> buildUrl, CancellationToken ct = default) =>
        _signUp.LinkAsync(ctx, actor, id, input, buildUrl, ct);
    public Task<CpResult<SignUpApplicationDto>> CreateAnywayAsync(PartnerImportActor actor, Guid id, Func<string, string> buildUrl, CancellationToken ct = default) =>
        _signUp.CreateAnywayAsync(actor, id, buildUrl, ct);
}

using SalesApi.Dtos;
using SalesApi.Services;
using SalesApi.ProcessLayer.LeadForms;

namespace SalesApi.ExperienceLayer.LeadForms;

/// <summary>
/// The lead-forms admin library screen: list, create, rename/repoint, archive,
/// and this form's own version history. Thin — the screen wants exactly what
/// Process computes, same honest state most first-pass Experience classes are
/// in (see the plan doc's step-8 notes on loyalty/goals/tags).
///
/// The schema editor itself (draft/publish/rollback) is NOT here — see
/// LeadFormLibraryStore's class comment for why <c>LeadFormSchemaModel</c>
/// keeps those four endpoints on the controller calling
/// <c>SalesApi.Services.LeadFormService</c> directly.
/// </summary>
public sealed class LeadFormLibraryExperience
{
    private readonly LeadFormLibraryProcess _process;
    public LeadFormLibraryExperience(LeadFormLibraryProcess process) => _process = process;

    public Task<List<LeadFormSummaryDto>> ListAsync(CancellationToken ct = default) => _process.ListAsync(ct);

    public Task<bool> ExistsAsync(Guid id, CancellationToken ct = default) => _process.ExistsAsync(id, ct);

    public Task<(LeadFormSummaryDto? Form, LeadFormLibraryProcess.Refusal? Refusal)> CreateAsync(
        string? name, Guid? playbookId, string? key, Guid userId, CancellationToken ct = default,
        Guid? copyFromFormId = null) =>
        _process.CreateAsync(name, playbookId, key, userId, ct, copyFromFormId);

    public Task<List<LeadFormWarningDto>> WarningsAsync(CancellationToken ct = default) => _process.WarningsAsync(ct);

    public Task<Dictionary<string, List<LeadFormFieldUsageDto>>> FieldUsageAsync(CancellationToken ct = default) =>
        _process.FieldUsageAsync(ct);

    public Task<LeadFormDraftDto?> VersionAsync(Guid id, int version) => _process.VersionAsync(id, version);

    public Task<LeadFormDraftDto?> RestoreAsync(Guid id, int version, Guid userId) =>
        _process.RestoreAsync(id, version, userId);

    public Task<(LeadFormSummaryDto? Form, LeadFormLibraryProcess.Refusal? Refusal)> CreateAsync(
        string? name, Guid? playbookId, Guid userId, CancellationToken ct = default) =>
        _process.CreateAsync(name, playbookId, userId, ct);

    public Task<LeadFormSummaryDto?> UpdateAsync(
        Guid id, string? name, Guid? playbookId, bool clearPlaybook, CancellationToken ct = default) =>
        _process.UpdateAsync(id, name, playbookId, clearPlaybook, ct);

    public Task<bool> ArchiveAsync(Guid id, CancellationToken ct = default) => _process.ArchiveAsync(id, ct);

    public Task<List<LeadFormVersionDto>> VersionsAsync(Guid id, CancellationToken ct = default) =>
        _process.VersionsAsync(id, ct);

    // --- One form's own schema and version history ---
    // These could not live here until LeadFormSchemaModel moved into Contracts:
    // LeadFormDraftDto carries a schema, and this project cannot see the System
    // layer at all. SystemBoundContracts.cs named that move as the fix; this is
    // it arriving.

    public Task<LeadFormDraftDto> DraftAsync(Guid id) => _process.DraftAsync(id);

    public Task<(LeadFormLibraryProcess.SchemaRefusal? Refusal, LeadFormDraftDto? Saved)> WriteAsync(
        Guid id, LeadFormSchemaModel input, bool publish, Guid userId) =>
        _process.WriteAsync(id, input, publish, userId);

}

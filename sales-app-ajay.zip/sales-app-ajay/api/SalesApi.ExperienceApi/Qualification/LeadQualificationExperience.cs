using SalesApi.Dtos;
using SalesApi.ProcessLayer.Qualification;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Qualification;

/// <summary>
/// What the lead-detail screen's checklist card needs. A pass-through today —
/// same shape as <c>StakeholdersExperience</c>/<c>PlaybooksExperience</c> for
/// their own domains.
/// </summary>
public sealed class LeadQualificationExperience
{
    private readonly LeadQualificationProcess _qualification;
    public LeadQualificationExperience(LeadQualificationProcess qualification) => _qualification = qualification;

    public Task<LeadQualificationProcess.ChecklistOutcome> GetAsync(
        RecordAccessContext ctx, Guid leadId, CancellationToken ct = default) =>
        _qualification.GetAsync(ctx, leadId, ct);

    public Task<LeadQualificationProcess.MarkOutcome> CompleteAsync(
        RecordAccessContext ctx, Guid leadId, string itemKey, Guid actorId, string? note, CancellationToken ct = default) =>
        _qualification.CompleteAsync(ctx, leadId, itemKey, actorId, note, ct);

    public Task<LeadQualificationProcess.MarkOutcome> UncompleteAsync(
        RecordAccessContext ctx, Guid leadId, string itemKey, Guid actorId, CancellationToken ct = default) =>
        _qualification.UncompleteAsync(ctx, leadId, itemKey, actorId, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Collections;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Collections;

/// <summary>
/// What the collections screens need.
///
/// This class was IMPOSSIBLE to write until 2026-08-28: every `CollectionProcess`
/// method took `RecordAccessContext`, which lived in the System layer, so
/// Experience could not name it. The fix was not to weaken the boundary but to
/// move the caller-scope value objects into Contracts, where they always
/// belonged — they contain no EF and no HTTP, only a description of who is
/// asking. The factories that BUILD one from a ClaimsPrincipal and the database
/// stayed in System.
/// </summary>
public sealed class CollectionsExperience
{
    private readonly CollectionProcess _collections;
    public CollectionsExperience(CollectionProcess collections) => _collections = collections;

    public Task<CollectionsDto> DashboardAsync(RecordAccessContext ctx, DateTime now, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _collections.DashboardAsync(ctx, now, canSeeFinancials, ct);

    public Task<List<CollectionsLeaderboardRowDto>> LeaderboardAsync(
        RecordAccessContext ctx, Guid? orgId, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _collections.LeaderboardAsync(ctx, orgId, canSeeFinancials, ct);

    public Task<List<CollectionsByCustomerRowDto>> ByCustomerAsync(
        RecordAccessContext ctx, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _collections.ByCustomerAsync(ctx, canSeeFinancials, ct);

    public Task<CollectionReminderConfigDto> ReminderConfigAsync(CancellationToken ct = default) =>
        _collections.ReminderConfigAsync(ct);

    public Task<CollectionReminderConfigDto> SetReminderConfigAsync(
        CollectionReminderConfigInput input, CancellationToken ct = default) =>
        _collections.SetReminderConfigAsync(input, ct);

    public Task<int> GenerateRemindersAsync(CancellationToken ct = default) =>
        _collections.GenerateRemindersAsync(ct);
}

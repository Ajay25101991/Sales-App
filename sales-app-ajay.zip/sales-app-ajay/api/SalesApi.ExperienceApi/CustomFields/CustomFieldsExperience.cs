using SalesApi.Dtos;
using SalesApi.ProcessLayer.CustomFields;

namespace SalesApi.ExperienceLayer.CustomFields;

/// <summary>
/// What the custom-fields admin screen and the lead form need.
///
/// Forwards today. See <see cref="Goals.GoalsExperience"/> for why that is
/// still worth having.
///
/// NOTE for whoever migrates the lead-form DESIGNER: its `LeadFormDraftDto`
/// names `Services.LeadFormSchemaModel`, a System type, so it cannot cross this
/// boundary and lives in `SalesApi.SystemApi/Dtos/SystemBoundContracts.cs`. The
/// owner's decision (2026-08-28) is to move that dependency down into Contracts
/// rather than weaken the boundary — do that first, not a workaround here.
/// </summary>
public sealed class CustomFieldsExperience
{
    private readonly CustomFieldProcess _fields;
    public CustomFieldsExperience(CustomFieldProcess fields) => _fields = fields;

    public Task<List<CustomFieldDefDto>> ListAsync(bool includeArchived, string? objectType = null, CancellationToken ct = default) =>
        _fields.ListAsync(includeArchived, objectType, ct);

    public Task<(CustomFieldDefDto? Created, CustomFieldProcess.Refusal? Refusal)> CreateAsync(
        CustomFieldInput input, CancellationToken ct = default, Guid? actorId = null) =>
        _fields.CreateAsync(input, ct, actorId);

    public Task<(CustomFieldDefDto? Updated, CustomFieldProcess.Refusal? Refusal)> UpdateAsync(
        Guid id, CustomFieldInput input, CancellationToken ct = default) =>
        _fields.UpdateAsync(id, input, ct);

    public Task<(List<CustomFieldDefDto>? Reordered, CustomFieldProcess.Refusal? Refusal)> ReorderAsync(
        List<Guid>? ids, CancellationToken ct = default) =>
        _fields.ReorderAsync(ids, ct);

    public Task<CustomFieldProcess.Refusal?> DeleteAsync(Guid id, CancellationToken ct = default) =>
        _fields.DeleteAsync(id, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Teams;

namespace SalesApi.ExperienceLayer.Teams;

/// <summary>
/// The teams management screen's payloads.
///
/// EVERY METHOD HERE FORWARDS. This is the sixth-of-seven-plus finding the plan
/// already recorded for goals/tags/custom-fields/collections/quotes: the
/// management screen wants exactly what Process computes — a team list, a team
/// detail, a calendar override, a refusal reason — and there is no second
/// consumer yet asking for a different shape (a phone wanting team NAMES only,
/// a picker wanting active teams without the archived ones already filtered
/// server-side, ...). Built anyway, per the owner's uniformity decision
/// (2026-08-28): a rule with exceptions is not a rule, and the value shows up
/// the moment a second consumer wants something this shape doesn't give it —
/// landing here, leaving Process untouched, exactly as it did for loyalty's
/// second consumer.
///
/// It cannot see <c>AppDbContext</c>, <c>Team</c> or any other System type —
/// enforced by <c>DisableTransitiveProjectReferences</c> on this project, not by
/// convention. Only <c>TeamProcess</c> and the Contracts it already returns are
/// visible here.
/// </summary>
public sealed class TeamsExperience
{
    private readonly TeamProcess _process;
    public TeamsExperience(TeamProcess process) => _process = process;

    public Task<List<TeamSummaryDto>> ListAsync(bool includeArchived, CancellationToken ct = default) =>
        _process.ListAsync(includeArchived, ct);

    public Task<TeamDetailDto?> GetAsync(Guid id, CancellationToken ct = default) =>
        _process.GetAsync(id, ct);

    public Task<(TeamProcess.Refusal? Refusal, TeamDetailDto? Team)> CreateAsync(
        Guid? org, string? name, CancellationToken ct = default) =>
        _process.CreateAsync(org, name, ct);

    public Task<(TeamProcess.Refusal? Refusal, TeamSummaryDto? Team)> RenameAsync(
        Guid org, Guid teamId, string? name, CancellationToken ct = default) =>
        _process.RenameAsync(org, teamId, name, ct);

    public Task<(TeamArchiveOutcome Outcome, int Detached)> ArchiveAsync(
        Guid teamId, Guid? moveTo = null, Guid? actorId = null, CancellationToken ct = default) =>
        _process.ArchiveAsync(teamId, moveTo, actorId, ct);

    public Task<(TeamProcess.Refusal? Refusal, CalendarSettingsDto? Calendar)> GetCalendarAsync(
        Guid teamId, CancellationToken ct = default) =>
        _process.GetCalendarAsync(teamId, ct);

    public Task<TeamProcess.Refusal?> ClearCalendarAsync(Guid teamId, CancellationToken ct = default) =>
        _process.ClearCalendarAsync(teamId, ct);

    public Task<(TeamProcess.Refusal? Refusal, CalendarSettingsDto? Calendar)> SetCalendarAsync(
        Guid org, Guid teamId, string timeZoneId, int weekStartDay, List<int> nonSendingDays, CancellationToken ct = default) =>
        _process.SetCalendarAsync(org, teamId, timeZoneId, weekStartDay, nonSendingDays, ct);

    public Task<(TeamProcess.Refusal? Refusal, TeamDetailDto? Team)> SetMembersAsync(
        Guid org, Guid teamId, List<Guid>? userIds, CancellationToken ct = default) =>
        _process.SetMembersAsync(org, teamId, userIds, ct);
}

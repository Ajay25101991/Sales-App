using SalesApi.Dtos;
using SalesApi.ProcessLayer.Mailbox;

namespace SalesApi.ExperienceLayer.Mailbox;

/// <summary>The Microsoft 365 screen's "Team mailboxes" tab: list / add / edit / delete / check access. FORWARDS —
/// one consumer wants exactly what Process computes.</summary>
public sealed class SharedMailboxExperience
{
    private readonly SharedMailboxProcess _process;
    public SharedMailboxExperience(SharedMailboxProcess process) => _process = process;

    public Task<List<SharedMailboxDto>> ListAsync(CancellationToken ct = default) => _process.ListAsync(ct);

    public Task<(SharedMailboxProcess.Refusal? Refusal, SharedMailboxDto? Dto)> CreateAsync(
        SharedMailboxInput input, CancellationToken ct = default) => _process.CreateAsync(input, ct);

    public Task<(SharedMailboxProcess.Refusal? Refusal, SharedMailboxDto? Dto)> UpdateAsync(
        Guid id, SharedMailboxInput input, CancellationToken ct = default) => _process.UpdateAsync(id, input, ct);

    public Task<SharedMailboxProcess.Refusal?> DeleteAsync(Guid id, CancellationToken ct = default) => _process.DeleteAsync(id, ct);

    public Task<(SharedMailboxProcess.Refusal? Refusal, SharedMailboxCheckDto? Result)> CheckAsync(
        Guid id, CancellationToken ct = default) => _process.CheckAsync(id, ct);
}

/// <summary>The "Unmatched emails" review list. FORWARDS; the caller's scope arrives as data.</summary>
public sealed class EmailTriageExperience
{
    private readonly EmailTriageProcess _triage;
    public EmailTriageExperience(EmailTriageProcess triage) => _triage = triage;

    public Task<List<EmailUnmatchedMessageDto>> ListAsync(EmailTriageScope scope, Guid? mailboxId, CancellationToken ct = default) =>
        _triage.ListAsync(scope, mailboxId, ct);

    public Task<EmailUnmatchedSummaryDto> SummaryAsync(EmailTriageScope scope, CancellationToken ct = default) =>
        _triage.SummaryAsync(scope, ct);

    public Task<(EmailTriageProcess.Refusal? Refusal, EmailUnmatchedMessageDto? Dto)> LinkAsync(
        Guid id, Guid leadId, Guid actorId, EmailTriageScope scope, CancellationToken ct = default) =>
        _triage.LinkAsync(id, leadId, actorId, scope, ct);

    public Task<(EmailTriageProcess.Refusal? Refusal, Guid? LeadId)> CreateLeadAsync(
        Guid id, Guid actorId, EmailTriageScope scope, EmailCreateLeadInput? edits = null, CancellationToken ct = default) =>
        _triage.CreateLeadAsync(id, actorId, scope, edits, ct);

    public Task<(EmailTriageProcess.Refusal? Refusal, EmailUnmatchedMessageDto? Dto)> DismissAsync(
        Guid id, Guid actorId, EmailTriageScope scope, CancellationToken ct = default) =>
        _triage.DismissAsync(id, actorId, scope, ct);
}

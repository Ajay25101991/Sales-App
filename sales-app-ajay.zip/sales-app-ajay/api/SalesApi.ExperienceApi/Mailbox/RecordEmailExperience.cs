using SalesApi.Dtos;
using SalesApi.ProcessLayer.Mailbox;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Mailbox;

/// <summary>
/// The in-CRM email compose (E12.6) for the lead and contact screens. Nothing is shaped per caller (the reach rule and the "never the
/// address" rule are the Process's), so this is a pass-through giving the controller one Experience class, like
/// <c>EngagementLetterExperience</c>.
/// </summary>
public sealed class RecordEmailExperience
{
    private readonly RecordEmailProcess _emails;
    public RecordEmailExperience(RecordEmailProcess emails) => _emails = emails;

    public Task<List<MessageTemplateDto>> TemplatesAsync(CancellationToken ct = default) => _emails.TemplatesAsync(ct);

    public Task<RecordEmailProcess.Result<RecordEmailSentDto>> SendToLeadAsync(
        RecordAccessContext vis, Guid actorId, string actorName, Guid leadId, SendRecordEmailInput input, CancellationToken ct = default) =>
        _emails.SendToLeadAsync(vis, actorId, actorName, leadId, input, ct);

    public Task<RecordEmailProcess.Result<RecordEmailSentDto>> SendToContactAsync(
        RecordAccessContext vis, Guid actorId, string actorName, Guid contactId, SendRecordEmailInput input, CancellationToken ct = default) =>
        _emails.SendToContactAsync(vis, actorId, actorName, contactId, input, ct);

    public Task<RecordEmailProcess.Result<RecordEmailSentDto>> SendToAccountAsync(
        RecordAccessContext vis, Guid actorId, string actorName, Guid accountId, SendRecordEmailInput input, CancellationToken ct = default) =>
        _emails.SendToAccountAsync(vis, actorId, actorName, accountId, input, ct);

    public Task<RecordEmailProcess.Result<List<EmailRecipientCandidateDto>>> AccountRecipientsAsync(RecordAccessContext vis, Guid accountId, CancellationToken ct = default) =>
        _emails.AccountRecipientsAsync(vis, accountId, ct);

    public Task<RecordEmailProcess.Result<RecordEmailSentDto>> SendToInvoiceAsync(
        RecordAccessContext vis, Guid actorId, string actorName, Guid invoiceId, SendRecordEmailInput input, CancellationToken ct = default) =>
        _emails.SendToInvoiceAsync(vis, actorId, actorName, invoiceId, input, ct);

    public Task<RecordEmailProcess.Result<RecordEmailSentDto>> SendToAmcAsync(
        RecordAccessContext vis, Guid actorId, string actorName, Guid amcId, SendRecordEmailInput input, CancellationToken ct = default) =>
        _emails.SendToAmcAsync(vis, actorId, actorName, amcId, input, ct);

    public Task<RecordEmailProcess.Result<List<EmailRecipientCandidateDto>>> RecipientsAsync(RecordAccessContext vis, Guid leadId, CancellationToken ct = default) =>
        _emails.RecipientsAsync(vis, leadId, ct);

    public Task<RecordEmailProcess.Result<ReplyDraftDto>> ReplyDraftAsync(RecordAccessContext vis, Guid actorId, Guid eventId, CancellationToken ct = default) =>
        _emails.ReplyDraftAsync(vis, actorId, eventId, ct);

    public Task<RecordEmailProcess.Result<List<RecordEmailThreadDto>>> ThreadsAsync(
        RecordAccessContext vis, Guid actorId, Guid leadId, CancellationToken ct = default) =>
        _emails.ThreadsAsync(vis, actorId, leadId, ct);
}

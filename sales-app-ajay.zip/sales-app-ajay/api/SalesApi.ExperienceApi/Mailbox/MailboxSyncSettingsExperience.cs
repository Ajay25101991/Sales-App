using SalesApi.Dtos;
using SalesApi.ProcessLayer.Mailbox;

namespace SalesApi.ExperienceLayer.Mailbox;

/// <summary>What "Admin, mailbox-sync settings" needs. FORWARDS — same shape
/// <c>DealRiskSettingsExperience</c> takes.</summary>
public sealed class MailboxSyncSettingsExperience
{
    private readonly MailboxSyncSettingsProcess _settings;
    public MailboxSyncSettingsExperience(MailboxSyncSettingsProcess settings) => _settings = settings;

    public Task<MailboxSyncSettingsDto> GetAsync(CancellationToken ct = default) => _settings.GetAsync(ct);

    public Task<(MailboxSyncSettingsDto? Dto, MailboxSyncSettingsProcess.Refusal? Refusal)> SaveAsync(
        MailboxSyncSettingsInput input, Guid actorId, CancellationToken ct = default) =>
        _settings.SaveAsync(input, actorId, ct);
}

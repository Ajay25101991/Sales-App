using SalesApi.Dtos;
using SalesApi.ProcessLayer.Mailbox;

namespace SalesApi.ExperienceLayer.Mailbox;

/// <summary>
/// The Connected-accounts (self) and admin "who is connected" screens'
/// payload — forwards Process's answer unchanged today, same "one consumer
/// wants exactly what Process computes" starting shape
/// <see cref="ExperienceLayer.Integrations.IntegrationsExperience"/> already
/// documents for itself.
/// </summary>
public sealed class MailboxExperience
{
    private readonly MailboxOAuthProcess _process;
    public MailboxExperience(MailboxOAuthProcess process) => _process = process;

    public Task<(MailboxOAuthRefusal? Refusal, MailboxAuthorizeUrlResult? Result)> BuildAuthorizeUrlAsync(
        Guid orgId, Guid profileId, string connectorKey, CancellationToken ct = default) =>
        _process.BuildAuthorizeUrlAsync(orgId, profileId, connectorKey, ct);

    public Task<(MailboxOAuthRefusal? Refusal, MailboxConnectResult? Result)> ExchangeCallbackAsync(
        string code, string state, CancellationToken ct = default) =>
        _process.ExchangeCallbackAsync(code, state, ct);

    public Task<MailboxConnectionDto?> GetMyConnectionAsync(Guid profileId, string connectorKey, CancellationToken ct = default) =>
        _process.GetMyConnectionAsync(profileId, connectorKey, ct);

    public Task<MailboxStatusDto> GetStatusAsync(Guid profileId, string connectorKey, CancellationToken ct = default) =>
        _process.GetStatusAsync(profileId, connectorKey, ct);

    public Task<bool> DisconnectAsync(Guid connectionId, CancellationToken ct = default) =>
        _process.DisconnectAsync(connectionId, ct);

    public Task<List<MailboxConnectionDto>> ListAllAsync(CancellationToken ct = default) =>
        _process.ListAllAsync(ct);

    public Task<(MailboxOAuthRefusal? Refusal, MailboxConnectionDto? Result)> AdminDisconnectAsync(
        Guid connectionId, CancellationToken ct = default) =>
        _process.AdminDisconnectAsync(connectionId, ct);
}

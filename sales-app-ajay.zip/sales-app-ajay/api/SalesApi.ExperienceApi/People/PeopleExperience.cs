using SalesApi.Dtos;
using SalesApi.ProcessLayer.People;

namespace SalesApi.ExperienceLayer.People;

/// <summary>
/// The team roster / invites screen's payloads (backs <c>TeamController</c> —
/// singular; not <c>TeamsController</c>'s <c>ExperienceLayer.Teams.TeamsExperience</c>,
/// which owns the <c>teams</c> table itself).
///
/// EVERY METHOD HERE FORWARDS, same finding as ten of eleven previously migrated
/// domains: the roster screen wants exactly what Process computes — a roster
/// row, a login-activity table, a create/update/delete outcome — and there is no
/// second consumer yet asking for a different shape. Built anyway per the
/// owner's uniformity decision (2026-08-28).
///
/// It cannot see <c>AppDbContext</c>, <c>Profile</c> or any other System type —
/// enforced by the Experience project's disabled transitive project references,
/// not by convention. Only <c>PeopleProcess</c> and the Contracts it already
/// returns are visible here — including <c>PeopleProcess</c>'s own nested
/// <c>Refusal</c>/<c>PersonGate</c>/<c>RoleResolution</c>/<c>CreatePreparation</c>/
/// <c>RosterRow</c> types, which are themselves built from nothing but plain
/// values and Contracts DTOs (see that class's own doc comment for why rank and
/// reach are deliberately absent from its surface).
/// </summary>
public sealed class PeopleExperience
{
    private readonly PeopleProcess _process;
    public PeopleExperience(PeopleProcess process) => _process = process;

    public Task<List<PeopleProcess.RosterRow>> GetRosterAsync(Guid org, CancellationToken ct = default) =>
        _process.GetRosterAsync(org, ct);

    public Task<List<LoginActivityDto>> GetLoginActivityAsync(Guid org, int periodDays, CancellationToken ct = default) =>
        _process.GetLoginActivityAsync(org, periodDays, ct);

    public Task<PeopleProcess.PersonGate?> GetGateAsync(Guid id, bool crossOrg, Guid? callerOrg, CancellationToken ct = default) =>
        _process.GetGateAsync(id, crossOrg, callerOrg, ct);

    public Task<PeopleProcess.RoleResolution> ResolveRoleAsync(Guid? orgId, string roleKey, bool actorIsSuntechAdmin, CancellationToken ct = default) =>
        _process.ResolveRoleAsync(orgId, roleKey, actorIsSuntechAdmin, ct);

    public Task<PeopleProcess.CreatePreparation> PrepareCreateAsync(CreateUserInput input, bool actorIsSuntechAdmin, Guid actorUserId, CancellationToken ct = default) =>
        _process.PrepareCreateAsync(input, actorIsSuntechAdmin, actorUserId, ct);

    public Task<(ProfileDto Profile, Guid Id)> CommitCreateAsync(PeopleProcess.CreatePreparation prep, CancellationToken ct = default) =>
        _process.CommitCreateAsync(prep, ct);

    public Task<string?> ReactivationRefusalAsync(Guid id, bool? isActive, CancellationToken ct = default) =>
        _process.ReactivationRefusalAsync(id, isActive, ct);

    public Task<ProfileDto?> ApplyUpdateAsync(Guid id, string? requestedRoleKey, string? newBaseRole, bool? isActive, Guid actorId, CancellationToken ct = default) =>
        _process.ApplyUpdateAsync(id, requestedRoleKey, newBaseRole, isActive, actorId, ct);

    public Task<(PeopleProcess.Refusal? Refusal, ProfileDto? Dto)> SetPrimaryTeamAsync(
        Guid id, Guid? teamId, CancellationToken ct = default) =>
        _process.SetPrimaryTeamAsync(id, teamId, ct);

    public Task<(PeopleProcess.Refusal? Refusal, bool Done)> DeleteAsync(
        Guid id, Guid actorId, Guid? actorOrgId, string? reassignMode, Guid? to,
        Guid? teamId = null, CancellationToken ct = default) =>
        _process.DeleteAsync(id, actorId, actorOrgId, reassignMode, to, teamId, ct);

    public Task<PeopleProcess.Refusal?> ResetPasswordAsync(Guid id, string? password, CancellationToken ct = default) =>
        _process.ResetPasswordAsync(id, password, ct);

    public Task<ProfileDto?> UnlinkSsoAsync(Guid id, Guid actorId, CancellationToken ct = default) =>
        _process.UnlinkSsoAsync(id, actorId, ct);

    public Task<(bool Sent, string? Error)> SendInviteEmailAsync(Guid userId, Func<string, string> buildUrl, CancellationToken ct = default) =>
        _process.SendInviteEmailAsync(userId, buildUrl, ct);
}

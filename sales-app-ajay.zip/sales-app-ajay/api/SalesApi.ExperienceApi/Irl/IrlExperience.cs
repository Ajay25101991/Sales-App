using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.ProcessLayer.Irl;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Irl;

/// <summary>
/// The e-invoicing IRL on the deal screen (send, resend, revoke, reopen, read, upload a completed workbook) and on the client's public link
/// (read, autosave, submit, upload a Section D document). Nothing is shaped differently per caller - the deal-access rule is the Process's and the
/// route's permission is the controller's - so this is a pass-through that gives the two controllers one Experience class to depend on, like
/// <c>EngagementLetterExperience</c>.
/// </summary>
public sealed class IrlExperience
{
    private readonly IrlRequestProcess _requests;
    private readonly IrlPublicProcess _public;

    public IrlExperience(IrlRequestProcess requests, IrlPublicProcess publicLink)
    {
        _requests = requests;
        _public = publicLink;
    }

    // ---- the rep's side ----

    public Task<IrlRequestProcess.Result<IrlDetailDto>> GetAsync(RecordAccessContext vis, Guid leadId, CancellationToken ct = default) =>
        _requests.GetAsync(vis, leadId, ct);

    public Task<IrlRequestProcess.Result<IrlSubmissionDetailDto>> SubmissionAsync(RecordAccessContext vis, Guid leadId, Guid submissionId, CancellationToken ct = default) =>
        _requests.SubmissionAsync(vis, leadId, submissionId, ct);

    public Task<IrlRequestProcess.Result<EngagementLetterEmailDto>> EmailAsync(RecordAccessContext vis, string repName, Guid leadId, CancellationToken ct = default) =>
        _requests.EmailAsync(vis, repName, leadId, ct);

    public Task<IrlRequestProcess.Result<IrlRequestDto>> SendAsync(
        RecordAccessContext vis, Guid actorId, string actorName, Guid leadId, SendIrlInput input, CancellationToken ct = default) =>
        _requests.SendAsync(vis, actorId, actorName, leadId, input, ct);

    public Task<IrlRequestProcess.Result<IrlRequestDto>> ResendAsync(
        RecordAccessContext vis, Guid actorId, string actorName, Guid leadId, SendIrlInput input, CancellationToken ct = default) =>
        _requests.ResendAsync(vis, actorId, actorName, leadId, input, ct);

    public Task<IrlRequestProcess.Result<IrlRequestDto>> RevokeAsync(RecordAccessContext vis, Guid actorId, Guid leadId, CancellationToken ct = default) =>
        _requests.RevokeAsync(vis, actorId, leadId, ct);

    public Task<IrlRequestProcess.Result<IrlRequestDto>> ReopenAsync(RecordAccessContext vis, Guid actorId, Guid leadId, CancellationToken ct = default) =>
        _requests.ReopenAsync(vis, actorId, leadId, ct);

    public Task<IrlRequestProcess.Result<IrlUploadResultDto>> UploadWorkbookAsync(
        RecordAccessContext vis, Guid actorId, string actorName, Guid leadId, Guid? serviceId,
        string filename, string? contentType, long length, Stream content, string? mode = null, CancellationToken ct = default) =>
        _requests.UploadWorkbookAsync(vis, actorId, actorName, leadId, serviceId, filename, contentType, length, content, mode, ct);

    // ---- the client's link ----

    public Task<IrlPublicProcess.Result<IrlPublicViewDto>> ViewAsync(string? token, string? ip, string? userAgent, CancellationToken ct = default) =>
        _public.ViewAsync(token, ip, userAgent, ct);

    public Task<IrlPublicProcess.Result<IrlSaveResultDto>> SaveAsync(string? token, JsonElement answers, CancellationToken ct = default) =>
        _public.SaveAsync(token, answers, ct);

    public Task<IrlPublicProcess.Result<IrlSubmitResultDto>> SubmitAsync(string? token, JsonElement? answers, CancellationToken ct = default) =>
        _public.SubmitAsync(token, answers, ct);

    public Task<IrlPublicProcess.Result<IrlDocumentUploadedDto>> UploadDocumentAsync(
        string? token, string itemId, string filename, string? contentType, long length, Stream content, CancellationToken ct = default) =>
        _public.UploadDocumentAsync(token, itemId, filename, contentType, length, content, ct);
}

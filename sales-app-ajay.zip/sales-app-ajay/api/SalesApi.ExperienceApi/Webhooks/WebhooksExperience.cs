using SalesApi.Dtos;
using SalesApi.ProcessLayer.Webhooks;

namespace SalesApi.ExperienceLayer.Webhooks;

/// <summary>
/// The webhooks admin screen. Forwards Process today — one consumer, the
/// desktop webhooks panel.
/// </summary>
public sealed class WebhooksExperience
{
    private readonly WebhookProcess _process;
    public WebhooksExperience(WebhookProcess process) => _process = process;

    public List<WebhookEventDefDto> Events() => _process.Events();

    /// <summary>E1 step 8: GET /webhooks/catalog — the full grouped catalogue.</summary>
    public List<WebhookCatalogEntryDto> Catalog() => _process.Catalog();

    public Task<List<WebhookSubscriptionDto>> ListAsync(CancellationToken ct = default) =>
        _process.ListAsync(ct);

    public Task<(WebhookSubscriptionCreatedDto? Created, WebhookProcess.Refusal? Refusal)> CreateAsync(
        string? @event, string? endpointUrl, Guid createdById, CancellationToken ct = default) =>
        _process.CreateAsync(@event, endpointUrl, createdById, ct);

    public Task<WebhookProcess.Refusal?> RevokeAsync(Guid id, CancellationToken ct = default) =>
        _process.RevokeAsync(id, ct);

    public Task<(WebhookSubscriptionDto? Subscription, WebhookProcess.Refusal? Refusal)> UpdateAsync(
        Guid id, string? @event, string? endpointUrl, CancellationToken ct = default) =>
        _process.UpdateAsync(id, @event, endpointUrl, ct);

    public Task<(WebhookSubscriptionCreatedDto? Created, WebhookProcess.Refusal? Refusal)> RotateSecretAsync(Guid id, CancellationToken ct = default) =>
        _process.RotateSecretAsync(id, ct);

    public Task<(Guid? DeliveryId, WebhookProcess.Refusal? Refusal)> TestAsync(Guid id, CancellationToken ct = default) =>
        _process.TestAsync(id, ct);

    public Task<(Guid? DeliveryId, WebhookProcess.Refusal? Refusal)> RedeliverAsync(Guid id, Guid deliveryId, CancellationToken ct = default) =>
        _process.RedeliverAsync(id, deliveryId, ct);

    public Task<(int? Retrying, WebhookProcess.Refusal? Refusal)> ResumeAsync(Guid id, CancellationToken ct = default) =>
        _process.ResumeAsync(id, ct);

    public Task<(List<WebhookDeliveryDto>? Deliveries, WebhookProcess.Refusal? Refusal)> DeliveriesAsync(
        Guid id, int limit, CancellationToken ct = default) =>
        _process.DeliveriesAsync(id, limit, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Proposals;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Proposals;

/// <summary>
/// What the admin "Quotes overview" screen needs.
///
/// Pure forwarding: the screen wants exactly the list + KPI shapes
/// ProposalProcess already returns, so there is nothing to reshape yet — same
/// finding as ten of the eleven domains before it.
/// </summary>
public sealed class ProposalsExperience
{
    private readonly ProposalProcess _proposals;
    public ProposalsExperience(ProposalProcess proposals) => _proposals = proposals;

    public Task<List<QuoteOverviewDto>> ListAsync(
        RecordAccessContext ctx, CancellationToken ct = default, string? filters = null, string? sorts = null) =>
        _proposals.ListAsync(ctx, ct, filters, sorts);

    public Task<TableColumnsDto> ColumnsAsync(RecordAccessContext ctx, CancellationToken ct = default) =>
        _proposals.ColumnsAsync(ctx, ct);

    public Task<QuoteOverviewSummaryDto> SummaryAsync(RecordAccessContext ctx, CancellationToken ct = default) =>
        _proposals.SummaryAsync(ctx, ct);
}

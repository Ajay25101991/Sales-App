using SalesApi.Dtos;
using SalesApi.ProcessLayer.Proposals;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Proposals;

/// <summary>
/// The deal screen's "Generate proposal" and the quote page's Versions panel (E10.5 / E10.6): forwards to
/// <see cref="ProposalGenerateProcess"/> and applies the value permission at the DTO edge. A caller without <c>lead_values.view</c>
/// (<c>canSeeValues</c>, a fact the controller resolved) gets every money figure as null, never 0 - see
/// <see cref="ProposalMasking"/>. The permission to USE priced proposals and the deal access rule are the endpoint's and the Process's.
/// </summary>
public sealed class ProposalGenerationExperience
{
    private readonly ProposalGenerateProcess _generate;
    public ProposalGenerationExperience(ProposalGenerateProcess generate) => _generate = generate;

    private static ProposalGenerateProcess.Result<T> Shape<T>(ProposalGenerateProcess.Result<T> r, Func<T, T> mask) =>
        r.Value is null ? r : r with { Value = mask(r.Value) };

    public async Task<ProposalGenerateProcess.Result<ProposalGeneratedDto>> GenerateAsync(
        RecordAccessContext vis, Guid actorId, Guid leadId, GenerateProposalVersionInput input, bool canSeeValues, CancellationToken ct = default) =>
        Shape(await _generate.GenerateAsync(vis, actorId, leadId, input, ct), v => ProposalMasking.Mask(v, canSeeValues));

    /// <summary>The custom-field / partner tokens the chosen templates use that are blank on this deal. Carries no money, so nothing to mask.</summary>
    public Task<ProposalGenerateProcess.Result<AgreementNamesDto>> AgreementsAsync(
        RecordAccessContext vis, Guid leadId, IReadOnlyList<Guid> serviceIds, CancellationToken ct = default) =>
        _generate.AgreementsAsync(vis, leadId, serviceIds, ct);

    public Task<ProposalGenerateProcess.Result<DocumentBlankFieldsDto>> BlankFieldsAsync(
        RecordAccessContext vis, Guid leadId, IReadOnlyList<Guid> serviceIds, bool deck, IReadOnlyList<string?> variants, CancellationToken ct = default) =>
        _generate.BlankFieldsAsync(vis, leadId, serviceIds, deck, variants, ct);

    public async Task<ProposalGenerateProcess.Result<List<ProposalVersionDto>>> VersionsAsync(
        RecordAccessContext vis, Guid leadId, Guid pid, bool canSeeValues, CancellationToken ct = default) =>
        Shape(await _generate.VersionsAsync(vis, leadId, pid, ct), v => ProposalMasking.Mask(v, canSeeValues));

    public async Task<ProposalGenerateProcess.Result<ProposalDiffDto>> DiffAsync(
        RecordAccessContext vis, Guid leadId, Guid pid, Guid? against, bool canSeeValues, CancellationToken ct = default) =>
        Shape(await _generate.DiffAsync(vis, leadId, pid, against, ct), v => ProposalMasking.Mask(v, canSeeValues));

    public async Task<ProposalGenerateProcess.Result<ProposalVersionDto>> RetryPdfAsync(
        RecordAccessContext vis, Guid actorId, Guid leadId, Guid pid, bool canSeeValues, CancellationToken ct = default) =>
        Shape(await _generate.RetryPdfAsync(vis, actorId, leadId, pid, ct), v => ProposalMasking.Mask(v, canSeeValues));

    public async Task<ProposalGenerateProcess.Result<ProposalVersionDto>> UploadPdfAsync(
        RecordAccessContext vis, Guid actorId, Guid leadId, Guid pid, byte[] pdf, bool canSeeValues, CancellationToken ct = default) =>
        Shape(await _generate.UploadPdfAsync(vis, actorId, leadId, pid, pdf, ct), v => ProposalMasking.Mask(v, canSeeValues));
}

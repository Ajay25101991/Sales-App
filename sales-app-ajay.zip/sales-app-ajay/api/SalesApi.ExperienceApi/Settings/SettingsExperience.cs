using SalesApi.Dtos;
using SalesApi.Services;
using SalesApi.ProcessLayer.Settings;

namespace SalesApi.ExperienceLayer.Settings;

/// <summary>
/// Everything the settings surface serves, shaped for whoever is asking.
///
/// Forwards for most of it today — a settings screen and Process want the same
/// shape — but two audiences are already visible in the method list and are why
/// this layer is here rather than skipped. The stage list, the lead form, the
/// board policy and the loyalty toggle are read by every rep on every screen
/// load, not only by an admin editing them; and swipe actions are read one way
/// by a phone (two lists) and another by the admin screen (the fallback plus
/// every team's override). The moment one of those wants something narrower,
/// the difference lands in this file and Process stays untouched.
/// </summary>
public sealed class SettingsExperience
{
    private readonly SettingsProcess _settings;
    public SettingsExperience(SettingsProcess settings) => _settings = settings;

    // --- Lead visibility ---------------------------------------------------------
    public Task<SettingsDto> GetSettingsAsync() => _settings.GetSettingsAsync();

    public Task<(SettingsProcess.Refusal? Refusal, SettingsDto? Dto)> UpdateSettingsAsync(string? mode) =>
        _settings.UpdateSettingsAsync(mode);

    // --- Idle-lead SLA threshold --------------------------------------------------
    public Task<int> GetSlaAsync() => _settings.GetSlaAsync();
    public Task<(SettingsProcess.Refusal? Refusal, int? IdleDays)> SetSlaAsync(int? idleDays) =>
        _settings.SetSlaAsync(idleDays);
    // --- Accounts rework (decisions 6, 8, 14) ------------------------------------------
    public Task<AccountsReworkSettingsDto> GetAccountsReworkAsync() => _settings.GetAccountsReworkAsync();
    public Task<(SettingsProcess.Refusal? Refusal, AccountsReworkSettingsDto? Dto)> SaveAccountsReworkAsync(AccountsReworkSettingsInput input) =>
        _settings.SaveAccountsReworkAsync(input);

    // --- E14: account hierarchy (inheriting fields, child-count statuses) ---------------
    public Task<AccountHierarchySettingsDto> GetAccountHierarchyAsync() => _settings.GetAccountHierarchyAsync();
    public Task<(SettingsProcess.Refusal? Refusal, AccountHierarchySettingsDto? Dto)> SaveAccountHierarchyAsync(AccountHierarchySettingsInput input) =>
        _settings.SaveAccountHierarchyAsync(input);

    // --- E15.3: KYC checklist rules ---------------------------------------------------
    public Task<KycChecklistSettingsDto> GetKycChecklistAsync() => _settings.GetKycChecklistAsync();
    public Task<(SettingsProcess.Refusal? Refusal, KycChecklistSettingsDto? Dto)> SaveKycChecklistAsync(KycChecklistSettingsInput input) =>
        _settings.SaveKycChecklistAsync(input);

    public Task<SensitiveDataSettingsDto> GetSensitiveDataAsync() => _settings.GetSensitiveDataAsync();
    public Task<(SettingsProcess.Refusal? Refusal, SensitiveDataSettingsDto? Dto)> SaveSensitiveDataAsync(SensitiveDataSettingsInput input) =>
        _settings.SaveSensitiveDataAsync(input);
    public Task<string> GetSensitiveAssignedScopeAsync() => _settings.GetSensitiveAssignedScopeAsync();
    public Task<(SettingsProcess.Refusal? Refusal, string? Scope)> SetSensitiveAssignedScopeAsync(string? scope) =>
        _settings.SetSensitiveAssignedScopeAsync(scope);
    public Task<MessageKindSettingsDto> GetMessageKindsAsync() => _settings.GetMessageKindsAsync();
    public Task<(SettingsProcess.Refusal? Refusal, MessageKindSettingsDto? Dto)> SaveMessageKindsAsync(MessageKindSettingsInput input) =>
        _settings.SaveMessageKindsAsync(input);
    public Task<AutomationStageMovesDto> GetAutomationStageMovesAsync() => _settings.GetAutomationStageMovesAsync();
    public Task<(SettingsProcess.Refusal? Refusal, AutomationStageMovesDto? Dto)> SaveAutomationStageMovesAsync(AutomationStageMovesInput input) =>
        _settings.SaveAutomationStageMovesAsync(input);
    public Task<HeaderTilesDto> GetHeaderTilesAsync() => _settings.GetHeaderTilesAsync();
    public Task<(SettingsProcess.Refusal? Refusal, HeaderTilesDto? Dto)> SaveHeaderTilesAsync(HeaderTilesInput input) =>
        _settings.SaveHeaderTilesAsync(input);
    public Task<string> GetContactPromotionAsync() => _settings.GetContactPromotionAsync();
    public Task<(SettingsProcess.Refusal? Refusal, string? Mode)> SetContactPromotionAsync(string? mode) =>
        _settings.SetContactPromotionAsync(mode);

    // --- Teammate-invite link lifetime --------------------------------------------
    public Task<int> GetInviteSettingsAsync() => _settings.GetInviteSettingsAsync();

    public Task<(SettingsProcess.Refusal? Refusal, int? TokenDays)> SetInviteSettingsAsync(int? tokenDays) =>
        _settings.SetInviteSettingsAsync(tokenDays);

    // --- Weekly activity quota ------------------------------------------------------
    public Task<int> GetActivityQuotaAsync() => _settings.GetActivityQuotaAsync();
    public Task<int> SetActivityQuotaAsync(int? quota) => _settings.SetActivityQuotaAsync(quota);

    // --- Lead sources ----------------------------------------------------------------
    public Task<List<string>> GetLeadSourcesAsync() => _settings.GetLeadSourcesAsync();

    public Task<(SettingsProcess.Refusal? Refusal, List<string>? Sources)> SetLeadSourcesAsync(List<string>? sources) =>
        _settings.SetLeadSourcesAsync(sources);

    // --- Deal types (E3.11) -----------------------------------------------------------
    public Task<List<string>> GetDealTypesAsync() => _settings.GetDealTypesAsync();

    public Task<(SettingsProcess.Refusal? Refusal, List<string>? Types)> SetDealTypesAsync(List<string>? types) =>
        _settings.SetDealTypesAsync(types);

    // --- Terminology (E3.5) --------------------------------------------------------------
    public Task<Dictionary<string, TermDto>> GetTerminologyAsync() => _settings.GetTerminologyAsync();

    public Task<(SettingsProcess.Refusal? Refusal, Dictionary<string, TermDto>? Terms)> SetTerminologyAsync(
        Dictionary<string, TermDto>? terms) => _settings.SetTerminologyAsync(terms);

    // --- Account relationship types (E3.4) ---------------------------------------------
    public Task<List<string>> GetAccountRelationshipTypesAsync() => _settings.GetAccountRelationshipTypesAsync();

    public Task<(SettingsProcess.Refusal? Refusal, List<string>? Types)> SetAccountRelationshipTypesAsync(List<string>? types) =>
        _settings.SetAccountRelationshipTypesAsync(types);

    // --- Buying roles / required stakeholder roles (E3.3) -----------------------------
    public Task<List<string>> GetBuyingRolesAsync() => _settings.GetBuyingRolesAsync();

    public Task<(SettingsProcess.Refusal? Refusal, List<string>? Roles)> SetBuyingRolesAsync(List<string>? roles) =>
        _settings.SetBuyingRolesAsync(roles);

    public Task<List<string>> GetRequiredStakeholderRolesAsync() => _settings.GetRequiredStakeholderRolesAsync();

    public Task<(SettingsProcess.Refusal? Refusal, List<string>? Roles)> SetRequiredStakeholderRolesAsync(List<string>? roles) =>
        _settings.SetRequiredStakeholderRolesAsync(roles);

    // --- Lead source machine policy ---------------------------------------------------
    public Task<LeadSourcePolicyDto> GetLeadSourcePolicyAsync() => _settings.GetLeadSourcePolicyAsync();

    public Task<(SettingsProcess.Refusal? Refusal, LeadSourcePolicyDto? Dto)> SetLeadSourcePolicyAsync(
        string? mode, string? wantedDefault) =>
        _settings.SetLeadSourcePolicyAsync(mode, wantedDefault);

    // --- Tax / invoicing profile -------------------------------------------------------
    public Task<InvoiceProfileDto> GetInvoiceProfileAsync() => _settings.GetInvoiceProfileAsync();

    public Task<(SettingsProcess.Refusal? Refusal, InvoiceProfileDto? Dto)> SetInvoiceProfileAsync(
        decimal? vatRate, string? trn, string? legalName, string? legalAddress, string? taxLabel,
        string? quoteOverDiscountPolicy, Dictionary<string, decimal>? quoteDiscountLimits = null) =>
        _settings.SetInvoiceProfileAsync(vatRate, trn, legalName, legalAddress, taxLabel, quoteOverDiscountPolicy, quoteDiscountLimits);

    // --- Rep risk weights -----------------------------------------------------------
    public Task<RiskWeightsDto> GetRiskWeightsAsync() => _settings.GetRiskWeightsAsync();

    public Task<(SettingsProcess.Refusal? Refusal, RiskWeightsDto? Dto)> SetRiskWeightsAsync(
        double? overdueWeight, double? stalledWeight, double? regressedWeight) =>
        _settings.SetRiskWeightsAsync(overdueWeight, stalledWeight, regressedWeight);

    // --- Task snooze quick options (E2.0 decision 5) -------------------------------
    public Task<TaskSnoozeOptionsDto> GetTaskSnoozeOptionsAsync() => _settings.GetTaskSnoozeOptionsAsync();

    public Task<(SettingsProcess.Refusal? Refusal, TaskSnoozeOptionsDto? Dto)> SetTaskSnoozeOptionsAsync(List<int>? quickDays) =>
        _settings.SetTaskSnoozeOptionsAsync(quickDays);

    // --- Automation limits (E2.2, design doc §6; owner answer §14.2) -----------------
    public Task<AutomationLimitsDto> GetAutomationLimitsAsync() => _settings.GetAutomationLimitsAsync();

    public Task<(SettingsProcess.Refusal? Refusal, AutomationLimitsDto? Dto)> SetAutomationLimitsAsync(
        int? maxLiveAutomations, int? maxActionsPerMinute, int? maxChainDepth) =>
        _settings.SetAutomationLimitsAsync(maxLiveAutomations, maxActionsPerMinute, maxChainDepth);

    // --- Inbound (website contact form) config ---------------------------------------------
    public Task<InboundConfigDto> GetInboundAsync() => _settings.GetInboundAsync();

    public Task<(SettingsProcess.Refusal? Refusal, InboundConfigDto? Dto)> SetInboundOwnerAsync(
        Guid? ownerId, Guid? callerOrgId) =>
        _settings.SetInboundOwnerAsync(ownerId, callerOrgId);

    // --- The policy singletons ---------------------------------------------
    // Read by far more than the settings screen: the board asks for its default
    // view, the lead form asks whether to draw a playbook picker, an account
    // panel asks whether loyalty runs at all. That is exactly the second
    // consumer this layer exists for, even while it still forwards.

    public Task<OrgSetupDto> GetOrgSetupAsync() => _settings.GetOrgSetupAsync();

    public Task<(SettingsProcess.Refusal? Refusal, OrgSetupDto? Dto)> SetOrgSetupAsync(
        string? policy, Guid? catchAllPlaybookId) => _settings.SetOrgSetupAsync(policy, catchAllPlaybookId);

    public Task<GateEscalationSettingsDto> GetGateEscalationAsync() => _settings.GetGateEscalationAsync();

    public Task<(SettingsProcess.Refusal? Refusal, GateEscalationSettingsDto? Dto)> SetGateEscalationAsync(
        string? approverPolicy, string? selfDecision) => _settings.SetGateEscalationAsync(approverPolicy, selfDecision);

    public Task<PlaybookPolicyDto> GetPlaybookPolicyAsync() => _settings.GetPlaybookPolicyAsync();

    public Task<(SettingsProcess.Refusal? Refusal, PlaybookPolicyDto? Dto)> SetPlaybookPolicyAsync(
        string? humanChoicePolicy, string? pickerAccessPolicy) =>
        _settings.SetPlaybookPolicyAsync(humanChoicePolicy, pickerAccessPolicy);

    public Task<LoyaltyPolicyDto> GetLoyaltyPolicyAsync() => _settings.GetLoyaltyPolicyAsync();

    public Task<(SettingsProcess.Refusal? Refusal, LoyaltyPolicyDto? Dto)> SetLoyaltyPolicyAsync(
        bool? enabled, string? earnSource, int? pointsInvoicePayment, int? pointsAmcRenewal,
        string? window = null, int? windowMonths = null) =>
        _settings.SetLoyaltyPolicyAsync(enabled, earnSource, pointsInvoicePayment, pointsAmcRenewal, window, windowMonths);

    public Task<LoyaltyTierConfigDto> GetLoyaltyTiersAsync() => _settings.GetLoyaltyTiersAsync();

    public Task<(SettingsProcess.Refusal? Refusal, LoyaltyTierConfigDto? Dto)> SetLoyaltyTiersAsync(
        LoyaltyTierConfigDto input) => _settings.SetLoyaltyTiersAsync(input);

    public Task<LeadFormPolicyDto> GetLeadFormPolicyAsync() => _settings.GetLeadFormPolicyAsync();

    public Task<(SettingsProcess.Refusal? Refusal, LeadFormPolicyDto? Dto)> SetLeadFormPolicyAsync(
        string? source, string? noPlaybookPolicy, string? pinningPolicy) =>
        _settings.SetLeadFormPolicyAsync(source, noPlaybookPolicy, pinningPolicy);

    public Task<BoardRenderingPolicyDto> GetBoardRenderingPolicyAsync() => _settings.GetBoardRenderingPolicyAsync();

    public Task<(SettingsProcess.Refusal? Refusal, BoardRenderingPolicyDto? Dto)> SetBoardRenderingPolicyAsync(
        string? policy) => _settings.SetBoardRenderingPolicyAsync(policy);

    // --- Pipeline stages, the canonical axis, routing, the org calendar ------
    // The stage list is the most widely read thing on this surface: every board
    // load, every lead form, the mobile stage editor. It is also the clearest
    // case for a layer here — a phone wanting labels and colours has no use for
    // requirements, coordinates and win probabilities, and that difference will
    // land in this file rather than in Process.

    public Task<List<StageDefDto>> GetStagesAsync() => _settings.GetStagesAsync();

    public Task<List<StageDefDto>> GetAllStagesAsync(Guid? playbookId) => _settings.GetAllStagesAsync(playbookId);

    public Task<Dictionary<string, int>> StageLeadCountsAsync() => _settings.StageLeadCountsAsync();

    public Task<(SettingsProcess.Refusal? Refusal, List<StageDefDto>? Stages)> SaveStagesAsync(string rawBody) =>
        _settings.SaveStagesAsync(rawBody);

    public Task<List<CanonicalStageDto>> GetCanonicalStagesAsync() => _settings.GetCanonicalStagesAsync();

    public Task<(SettingsProcess.CanonicalRefusal? Refusal, List<CanonicalStageDto>? Saved)> SaveCanonicalStagesAsync(
        CanonicalStagesInput input) => _settings.SaveCanonicalStagesAsync(input);

    public Task<LeadRoutingDto> GetRoutingAsync() => _settings.GetRoutingAsync();

    public Task<LeadRoutingDto> SaveRoutingAsync(
        string? mode, List<Guid>? pool, Dictionary<string, SourceRuleDto>? sourceRules,
        Guid? unassignedTeamId, bool clearUnassignedTeam, Dictionary<string, Guid>? sourcePlaybooks = null) =>
        _settings.SaveRoutingAsync(mode, pool, sourceRules, unassignedTeamId, clearUnassignedTeam, sourcePlaybooks);

    public Task<RoutingAuditDto> RoutingAuditAsync(RecordAccessContext ctx, int? days, int? limit) =>
        _settings.RoutingAuditAsync(ctx, days, limit);

    public Task<CalendarSettingsDto> GetCalendarAsync(Guid? orgId) => _settings.GetCalendarAsync(orgId);

    public Task<(SettingsProcess.Refusal? Refusal, CalendarSettingsDto? Dto)> SetCalendarAsync(
        Guid? orgId, string? timeZoneId, int? weekStartDay, List<int>? nonSendingDays) =>
        _settings.SetCalendarAsync(orgId, timeZoneId, weekStartDay, nonSendingDays);

    // --- The template, the taxonomy screen, the reasons, the workflow -------

    public Task<InvoiceEmailTemplateDto> GetInvoiceEmailAsync() => _settings.GetInvoiceEmailAsync();

    public Task<InvoiceEmailTemplateDto> SetInvoiceEmailAsync(string? subject, string? body) =>
        _settings.SetInvoiceEmailAsync(subject, body);

    public Task<LeadTaxonomyUsageDto> LeadTaxonomyUsageAsync() => _settings.LeadTaxonomyUsageAsync();

    public Task<CloseReasonsDto> GetCloseReasonsAsync() => _settings.GetCloseReasonsAsync();

    public Task<CloseReasonsDto> SaveCloseReasonsAsync(List<string>? won, List<string>? lost) =>
        _settings.SaveCloseReasonsAsync(won, lost);

    public Task<ReopenSettingsDto> GetReopenPolicyAsync() => _settings.GetReopenPolicyAsync();

    public Task<ReopenSettingsDto> SaveReopenPolicyAsync(ReopenSettingsInput input) =>
        _settings.SaveReopenPolicyAsync(input);

    public Task<ProposalFeeFieldsDto> GetProposalFeeFieldsAsync() => _settings.GetProposalFeeFieldsAsync();

    public Task<(ProposalFeeFieldsDto? Saved, string? Error)> SaveProposalFeeFieldsAsync(ProposalFeeFieldsInput input) =>
        _settings.SaveProposalFeeFieldsAsync(input);

    public Task<PaymentWorkflowConfigDto> GetPaymentWorkflowAsync() => _settings.GetPaymentWorkflowAsync();

    public string? PaymentWorkflowProblem(PaymentWorkflowConfigInput input) => SettingsProcess.PaymentWorkflowProblem(input);

    public Task<PaymentWorkflowConfigDto> SavePaymentWorkflowAsync(PaymentWorkflowConfigInput input) =>
        _settings.SavePaymentWorkflowAsync(input);

    // --- Email provider (org-level) -----------------------------------------

    public Task<EmailProviderConfigDto> GetEmailProviderAsync() => _settings.GetEmailProviderAsync();

    public Task<(SettingsProcess.Refusal? Refusal, EmailProviderConfigDto? Dto)> SetEmailProviderAsync(
        EmailProviderInput input, Guid? orgId) => _settings.SetEmailProviderAsync(input, orgId);

    public Task<SettingsProcess.TestEmailResult> SendTestEmailAsync(Guid userId) =>
        _settings.SendTestEmailAsync(userId);

    // --- AI provider (org-level, E4.1 slices 1-2) ---------------------------

    public Task<AiProviderConfigDto> GetAiProviderAsync() => _settings.GetAiProviderAsync();

    public Task<(SettingsProcess.Refusal? Refusal, AiProviderConfigDto? Dto)> SetAiProviderAsync(
        AiProviderInput input, Guid? orgId, Guid configuredById) => _settings.SetAiProviderAsync(input, orgId, configuredById);

    public Task<SettingsProcess.TestAiConnectionResult> TestAiProviderConnectionAsync() =>
        _settings.TestAiProviderConnectionAsync();

    // --- Lead-card swipe actions, per team (phone only) ---------------------
    // The clearest split on this surface: the phone reads ResolveSwipeActions
    // (two lists, nothing else), the admin screen reads SwipeActionsConfig (the
    // fallback plus every team's override). Same data, two shapes, already.

    public Task<ResolvedSwipeActionsDto> ResolveSwipeActionsAsync(Guid userId) =>
        _settings.ResolveSwipeActionsAsync(userId);

    public Task<SwipeActionsConfigDto> SwipeActionsConfigAsync() => _settings.SwipeActionsConfigAsync();

    public Task<SettingsProcess.SwipeSaveResult> SaveSwipeActionsAsync(
        Guid? teamId, List<string>? left, List<string>? right, Func<Guid, bool> canConfigureTeam) =>
        _settings.SaveSwipeActionsAsync(teamId, left, right, canConfigureTeam);

    public Task ClearSwipeActionsAsync(Guid teamId) => _settings.ClearSwipeActionsAsync(teamId);

    // --- The lead form designer, and the admin hub's timestamps -------------
    // GetLeadFormAsync is read by every rep to render the form at all; the draft,
    // the version list and the writes are the designer's. Two audiences on one
    // set of rows, which is the case this layer exists for.
    //
    // E3.2 — GetLeadFormAsync takes the caller's role and returns it already
    // filtered (SettingsProcess/SettingsStore/LeadFormService.GetAsync(db, role)):
    // a field a rep's role cannot see is removed, not merely masked, so the
    // rendered form never offers a box for it. The draft/versions reads below
    // are the designer's own (ManageSettings-gated at the controller) and stay
    // unfiltered on purpose — an admin editing the form must see every field.

    public Task<LeadFormSchemaModel> GetLeadFormAsync(string callerRole) => _settings.GetLeadFormAsync(callerRole);

    public Task<LeadFormDraftDto> GetLeadFormDraftAsync() => _settings.GetLeadFormDraftAsync();

    public Task<List<LeadFormVersionDto>> LeadFormVersionsAsync() => _settings.LeadFormVersionsAsync();

    public Task<(SettingsProcess.SchemaRefusal? Refusal, LeadFormDraftDto? Saved)> WriteLeadFormAsync(
        LeadFormSchemaModel input, bool publish, Guid userId) =>
        _settings.WriteLeadFormAsync(input, publish, userId);

    public Task<LeadFormDraftDto?> RestoreLeadFormAsync(int version, Guid userId) =>
        _settings.RestoreLeadFormAsync(version, userId);

    public Task<Dictionary<string, DateTime?>> SettingsLastUpdatedAsync() => _settings.SettingsLastUpdatedAsync();
}

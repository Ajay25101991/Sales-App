using SalesApi.Dtos;
using SalesApi.ProcessLayer.Goals;

namespace SalesApi.ExperienceLayer.Goals;

/// <summary>
/// What the goals screens need, shaped for them.
///
/// It is a pass-through today and says so plainly rather than dressing itself
/// up: the targets endpoints return exactly what Process computes. It exists
/// because the owner chose uniformity — every domain gets an Experience class,
/// so the seam is already there the day a consumer wants something different,
/// and nobody has to ask "why does this one domain skip a layer?".
///
/// The honest trade, recorded so the next reader does not mistake thinness for
/// an oversight: six domains in a row needed no reshaping, so most of these
/// classes will forward. The value is the SEAM, not today's code in it.
/// </summary>
public sealed class GoalsExperience
{
    private readonly GoalProcess _goals;
    public GoalsExperience(GoalProcess goals) => _goals = goals;

    public Task<GoalProcess.Refusal?> SetTargetAsync(
        Guid? userId, string? period, decimal? amount, Guid? orgId, Guid actorId,
        CancellationToken ct = default) =>
        _goals.SetTargetAsync(userId, period, amount, orgId, actorId, ct);

    public Task<List<TargetProgressDto>> ComputeAsync(
        string period, Guid? orgId, List<Guid>? peopleIds, CancellationToken ct = default) =>
        _goals.ComputeAsync(period, orgId, peopleIds, ct);

    public Task<List<TargetHistoryPeriodDto>> HistoryAsync(
        string period, int months, Guid? orgId, List<Guid>? peopleIds, CancellationToken ct = default) =>
        _goals.HistoryAsync(period, months, orgId, peopleIds, ct);

    public Task<TargetTotalDto> TotalAsync(
        string period, Guid? orgId, List<Guid>? peopleIds, CancellationToken ct = default) =>
        _goals.TotalAsync(period, orgId, peopleIds, ct);

    public Task<OrgGoalsResponseDto> OrgGoalsAsync(string period, Guid? orgId, CancellationToken ct = default) =>
        _goals.OrgGoalsAsync(period, orgId, ct);

    public Task<GoalProcess.Refusal?> SetOrgGoalAsync(
        string period, decimal? amount, Guid actorId, CancellationToken ct = default) =>
        _goals.SetOrgGoalAsync(period, amount, actorId, ct);

    public Task<bool> TeamExistsAsync(Guid teamId, CancellationToken ct = default) =>
        _goals.TeamExistsAsync(teamId, ct);

    public Task<GoalProcess.Refusal?> SetTeamGoalAsync(
        Guid? teamId, string period, decimal? amount, Guid actorId, CancellationToken ct = default) =>
        _goals.SetTeamGoalAsync(teamId, period, amount, actorId, ct);

    public Task<List<TargetAuditEntryDto>> AuditAsync(string period, CancellationToken ct = default) =>
        _goals.AuditAsync(period, ct);
}

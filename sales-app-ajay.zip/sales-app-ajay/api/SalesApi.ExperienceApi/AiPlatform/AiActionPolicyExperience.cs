using SalesApi.Dtos;
using SalesApi.ProcessLayer.AiPlatform;

namespace SalesApi.ExperienceLayer.AiPlatform;

/// <summary>
/// What the "Admin, AI actions" screen (§8.3) needs. FORWARDS — same shape
/// every migrated domain's Experience takes per the owner's 2026-08-28
/// decision to add Experience uniformly.
/// </summary>
public sealed class AiActionPolicyExperience
{
    private readonly AiActionPolicyProcess _policies;
    public AiActionPolicyExperience(AiActionPolicyProcess policies) => _policies = policies;

    public Task<List<AiActionPolicyDto>> ListAsync(CancellationToken ct = default) =>
        _policies.ListAsync(ct);

    public Task<AiActionPolicyProcess.PolicyOutcome> SetAutonomyAsync(
        string actionType, AiActionPolicyInput input, Guid actorId, CancellationToken ct = default) =>
        _policies.SetAutonomyAsync(actionType, input, actorId, ct);
}

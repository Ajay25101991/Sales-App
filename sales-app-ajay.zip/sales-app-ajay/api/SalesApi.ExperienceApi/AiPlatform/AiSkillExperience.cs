using SalesApi.Dtos;
using SalesApi.ProcessLayer.AiPlatform;

namespace SalesApi.ExperienceLayer.AiPlatform;

/// <summary>
/// What the "Admin, AI skills" screen (design §4.3) needs. FORWARDS — same
/// shape every migrated domain's Experience takes per the owner's 2026-08-28
/// decision to add Experience uniformly.
/// </summary>
public sealed class AiSkillExperience
{
    private readonly AiSkillProcess _skills;
    public AiSkillExperience(AiSkillProcess skills) => _skills = skills;

    public Task<List<AiSkillSummaryDto>> ListAsync(Guid orgId, CancellationToken ct = default) =>
        _skills.ListAsync(orgId, ct);

    public Task<(List<AiSkillVersionDto>? Versions, AiSkillProcess.Refusal? Refusal)> VersionsAsync(
        Guid skillId, Guid orgId, CancellationToken ct = default) =>
        _skills.VersionsAsync(skillId, orgId, ct);

    public Task<(AiSkillEffectivePromptDto? Result, AiSkillProcess.Refusal? Refusal)> EffectivePromptAsync(
        string skillKey, Guid orgId, CancellationToken ct = default) =>
        _skills.EffectivePromptAsync(skillKey, orgId, ct);

    public Task<(AiSkillDraftResultDto? Result, AiSkillProcess.Refusal? Refusal)> SaveDraftAsync(
        Guid skillId, Guid orgId, AiSkillDraftInput input, Guid userId, CancellationToken ct = default) =>
        _skills.SaveDraftAsync(skillId, orgId, input, userId, ct);

    public Task<(AiSkillPublishResultDto? Result, AiSkillProcess.Refusal? Refusal)> PublishAsync(
        Guid skillId, Guid orgId, Guid userId, CancellationToken ct = default) =>
        _skills.PublishAsync(skillId, orgId, userId, ct);

    public Task<(AiSkillPublishResultDto? Result, AiSkillProcess.Refusal? Refusal)> RollbackAsync(
        Guid skillId, Guid orgId, Guid targetVersionId, Guid userId, CancellationToken ct = default) =>
        _skills.RollbackAsync(skillId, orgId, targetVersionId, userId, ct);
}

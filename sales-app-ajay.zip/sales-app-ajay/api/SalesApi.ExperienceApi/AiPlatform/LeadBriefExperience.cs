using SalesApi.Dtos;
using SalesApi.ProcessLayer.AiPlatform;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.AiPlatform;

/// <summary>E5.1 — what <c>LeadBriefController</c> needs. FORWARDS — same
/// shape every migrated domain's Experience takes here, per
/// <see cref="AiCostPolicyExperience"/>.</summary>
public sealed class LeadBriefExperience
{
    private readonly LeadBriefProcess _brief;
    public LeadBriefExperience(LeadBriefProcess brief) => _brief = brief;

    public Task<(LeadBriefDto? Dto, LeadBriefProcess.Refusal? Refusal)> GetAsync(
        RecordAccessContext caller, LeadView view, bool canSeeFinancials, Guid orgId, Guid userId, Guid leadId,
        CancellationToken ct = default) =>
        _brief.GetAsync(caller, view, canSeeFinancials, orgId, userId, leadId, ct);

    public Task<(LeadBriefDto? Dto, LeadBriefProcess.Refusal? Refusal)> RefreshAsync(
        RecordAccessContext caller, LeadView view, bool canSeeFinancials, Guid orgId, Guid userId, Guid leadId,
        CancellationToken ct = default) =>
        _brief.RefreshAsync(caller, view, canSeeFinancials, orgId, userId, leadId, ct);
}

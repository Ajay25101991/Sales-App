using SalesApi.Dtos;
using SalesApi.ProcessLayer.AiPlatform;

namespace SalesApi.ExperienceLayer.AiPlatform;

/// <summary>E5's shared AI-feedback frame. FORWARDS — same shape every
/// migrated domain's Experience takes here, per <see cref="AiCostPolicyExperience"/>.</summary>
public sealed class AiFeedbackExperience
{
    private readonly AiFeedbackProcess _feedback;
    public AiFeedbackExperience(AiFeedbackProcess feedback) => _feedback = feedback;

    public Task<AiFeedbackSettingsDto> GetSettingsAsync(CancellationToken ct = default) =>
        _feedback.GetSettingsAsync(ct);

    public Task<(AiFeedbackSettingsDto? Dto, AiFeedbackProcess.Refusal? Refusal)> SaveSettingsAsync(
        AiFeedbackSettingsInput input, Guid actorId, CancellationToken ct = default) =>
        _feedback.SaveSettingsAsync(input, actorId, ct);

    public Task<(AiFeedbackResultDto? Result, AiFeedbackProcess.Refusal? Refusal)> SubmitAsync(
        AiFeedbackInput input, Guid callerId, CancellationToken ct = default) =>
        _feedback.SubmitAsync(input, callerId, ct);
}

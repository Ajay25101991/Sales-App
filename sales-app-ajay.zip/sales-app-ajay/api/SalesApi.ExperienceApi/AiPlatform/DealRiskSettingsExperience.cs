using SalesApi.Dtos;
using SalesApi.ProcessLayer.AiPlatform;

namespace SalesApi.ExperienceLayer.AiPlatform;

/// <summary>What "Admin, deal-risk settings" (story brief item 1) needs.
/// FORWARDS — same shape <see cref="AiCostPolicyExperience"/> takes.</summary>
public sealed class DealRiskSettingsExperience
{
    private readonly DealRiskSettingsProcess _settings;
    public DealRiskSettingsExperience(DealRiskSettingsProcess settings) => _settings = settings;

    public Task<DealRiskSettingsDto> GetAsync(CancellationToken ct = default) => _settings.GetAsync(ct);

    public Task<(DealRiskSettingsDto? Dto, DealRiskSettingsProcess.Refusal? Refusal)> SaveAsync(
        DealRiskSettingsInput input, Guid actorId, CancellationToken ct = default) =>
        _settings.SaveAsync(input, actorId, ct);
}

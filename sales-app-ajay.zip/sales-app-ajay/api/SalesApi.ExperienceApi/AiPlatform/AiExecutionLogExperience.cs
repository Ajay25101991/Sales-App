using SalesApi.Dtos;
using SalesApi.ProcessLayer.AiPlatform;

namespace SalesApi.ExperienceLayer.AiPlatform;

/// <summary>
/// What the "Admin, AI activity" screen (design §3.4) needs. FORWARDS — same
/// shape every migrated domain's Experience takes, per <see cref="AiActionPolicyExperience"/>.
/// </summary>
public sealed class AiExecutionLogExperience
{
    private readonly AiExecutionLogProcess _log;
    public AiExecutionLogExperience(AiExecutionLogProcess log) => _log = log;

    public Task<PagedResult<AiExecutionLogEntryDto>> ListAsync(
        Guid? userId, string? feature, string? outcome, DateTime? from, DateTime? to,
        string? cursor, int? limit, CancellationToken ct = default) =>
        _log.ListAsync(userId, feature, outcome, from, to, cursor, limit, ct);

    public Task<(AiExecutionLogDetailDto? Detail, AiExecutionLogProcess.Refusal? Refusal)> GetAsync(
        Guid id, CancellationToken ct = default) => _log.GetAsync(id, ct);

    public Task<AiTextCaptureStatusDto> GetCaptureStatusAsync(CancellationToken ct = default) =>
        _log.GetCaptureStatusAsync(ct);

    public Task<(AiTextCaptureStatusDto? Status, AiExecutionLogProcess.Refusal? Refusal)> SetCaptureAsync(
        AiTextCaptureInput input, Guid actorId, CancellationToken ct = default) =>
        _log.SetCaptureAsync(input, actorId, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.AiPlatform;

namespace SalesApi.ExperienceLayer.AiPlatform;

/// <summary>
/// What the "Admin, AI usage" screen (design §13) needs. FORWARDS — same
/// shape every migrated domain's Experience takes, per <see cref="AiActionPolicyExperience"/>.
/// </summary>
public sealed class AiCostPolicyExperience
{
    private readonly AiCostPolicyProcess _policy;
    public AiCostPolicyExperience(AiCostPolicyProcess policy) => _policy = policy;

    public Task<AiCostPolicyDto> GetAsync(CancellationToken ct = default) => _policy.GetAsync(ct);

    public Task<(AiCostPolicyDto? Dto, AiCostPolicyProcess.Refusal? Refusal)> SaveAsync(
        AiCostPolicyInput input, Guid actorId, CancellationToken ct = default) =>
        _policy.SaveAsync(input, actorId, ct);
}

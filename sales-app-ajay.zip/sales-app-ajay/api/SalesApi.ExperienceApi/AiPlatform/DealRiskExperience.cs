using SalesApi.ProcessLayer.AiPlatform;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.AiPlatform;

/// <summary>What GET /leads/{id}/risk (story brief item 6/7) needs. FORWARDS.</summary>
public sealed class DealRiskExperience
{
    private readonly DealRiskProcess _risk;
    public DealRiskExperience(DealRiskProcess risk) => _risk = risk;

    public Task<(DealRiskProcess.Refusal? Refusal, bool Available, Dtos.DealRiskDto? Dto)> GetAsync(
        RecordAccessContext vis, Guid leadId, CancellationToken ct = default) =>
        _risk.GetAsync(vis, leadId, ct);
}

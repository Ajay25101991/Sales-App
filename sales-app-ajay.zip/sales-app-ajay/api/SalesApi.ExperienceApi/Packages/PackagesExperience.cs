using SalesApi.Dtos;
using SalesApi.ProcessLayer.Packages;

namespace SalesApi.ExperienceLayer.Packages;

/// <summary>What the Admin, Packages screen needs. Forwards today — see
/// CustomFieldsExperience's own remark for why that is still worth having.
/// Mirrors that class's own shape: the Process's own <c>Refusal</c> record
/// crosses this boundary directly (Experience may name a Process type; only
/// Process may not name a System type), same as
/// <c>CustomFieldProcess.Refusal</c> already does.</summary>
public sealed class PackagesExperience
{
    private readonly PackageExportProcess _export;
    private readonly PackageImportProcess _import;

    public PackagesExperience(PackageExportProcess export, PackageImportProcess import)
    {
        _export = export;
        _import = import;
    }

    public Task<PackageExportResultDto> ExportAsync(
        Guid? sourceOrgId, string? name, List<PackageExportSelectionDto> items, CancellationToken ct = default) =>
        _export.ExportAsync(sourceOrgId, name, items, ct);

    public Task<(PackageImportPreviewDto? Preview, PackageImportProcess.Refusal? Refusal)> PreviewAsync(
        PackageManifestDto package, CancellationToken ct = default) =>
        _import.PreviewAsync(package, ct);

    public Task<(PackageApplyResultDto? Result, PackageImportProcess.Refusal? Refusal)> ApplyAsync(
        Guid? orgId, Guid? actorId, PackageApplyRequestDto request, CancellationToken ct = default) =>
        _import.ApplyAsync(orgId, actorId, request, ct);

    // --- Slice 6: apply history + rollback ---

    public Task<List<PackageApplyRecordDto>> ApplyHistoryAsync(CancellationToken ct = default) =>
        _import.ApplyHistoryAsync(ct);

    public Task<(PackageRollbackResultDto? Result, PackageImportProcess.RollbackRefusal? Refusal)> RollbackAsync(
        Guid? orgId, Guid? actorId, Guid applyRecordId, bool force, CancellationToken ct = default) =>
        _import.RollbackAsync(orgId, actorId, applyRecordId, force, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.EngagementLetters;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.EngagementLetters;

/// <summary>
/// The engagement letter on the deal screen (make, review, send, PDF, signed copy) and on the customer's accept page (E10.9). Nothing
/// is shaped differently per caller - the permission to use priced proposals and the deal access rule are the endpoint's and the
/// Process's - so this is a pass-through that gives the two controllers one Experience class to depend on, like
/// <c>ProposalGenerationExperience</c>.
/// </summary>
public sealed class EngagementLetterExperience
{
    private readonly EngagementLetterProcess _letters;
    private readonly EngagementLetterAcceptProcess _accept;

    public EngagementLetterExperience(EngagementLetterProcess letters, EngagementLetterAcceptProcess accept)
    {
        _letters = letters;
        _accept = accept;
    }

    public Task<EngagementLetterProcess.Result<List<EngagementLetterDto>>> ListAsync(RecordAccessContext vis, Guid leadId, Guid pid, CancellationToken ct = default) =>
        _letters.ListAsync(vis, leadId, pid, ct);

    public Task<EngagementLetterProcess.Result<EngagementLetterGeneratedDto>> GenerateAsync(
        RecordAccessContext vis, Guid actorId, Guid leadId, Guid pid, IReadOnlyList<string>? variants = null, CancellationToken ct = default) =>
        _letters.GenerateAsync(vis, actorId, leadId, pid, variants, ct);

    public Task<EngagementLetterProcess.Result<EngagementLetterDto>> RetryPdfAsync(
        RecordAccessContext vis, Guid actorId, Guid leadId, Guid pid, Guid? letterId = null, CancellationToken ct = default) =>
        _letters.RetryPdfAsync(vis, actorId, leadId, pid, letterId, ct);

    public Task<EngagementLetterProcess.Result<EngagementLetterDto>> UploadPdfAsync(
        RecordAccessContext vis, Guid actorId, Guid leadId, Guid pid, byte[] pdf, Guid? letterId = null, CancellationToken ct = default) =>
        _letters.UploadPdfAsync(vis, actorId, leadId, pid, pdf, letterId, ct);

    public Task<EngagementLetterProcess.Result<List<EngagementLetterThreadDto>>> ThreadsAsync(RecordAccessContext vis, Guid actorId, Guid leadId, Guid pid, CancellationToken ct = default) =>
        _letters.ThreadsAsync(vis, actorId, leadId, pid, ct);

    public Task<EngagementLetterProcess.Result<EngagementLetterEmailDto>> EmailAsync(
        RecordAccessContext vis, string repName, Guid leadId, Guid pid, List<Guid>? letterIds = null, CancellationToken ct = default) =>
        _letters.EmailAsync(vis, repName, leadId, pid, letterIds, ct);

    public Task<EngagementLetterProcess.Result<EngagementLetterDto>> SendAsync(
        RecordAccessContext vis, Guid actorId, string actorName, Guid leadId, Guid pid, SendEngagementLetterInput input, CancellationToken ct = default) =>
        _letters.SendAsync(vis, actorId, actorName, leadId, pid, input, ct);

    public Task<EngagementLetterProcess.Result<EngagementLetterDto>> UploadSignedAsync(
        RecordAccessContext vis, AttachmentPermissions perms, Guid actorId, string actorName, Guid? orgId, Guid leadId, Guid pid,
        string filename, string? contentType, long length, Stream content, Guid? letterId = null, CancellationToken ct = default) =>
        _letters.UploadSignedAsync(vis, perms, actorId, actorName, orgId, leadId, pid, filename, contentType, length, content, letterId, ct);

    // ---- the customer's link ----

    public Task<EngagementLetterAcceptProcess.LetterView> ViewAsync(string? token, string? ip, string? userAgent, CancellationToken ct = default) =>
        _accept.ViewAsync(token, ip, userAgent, ct);

    public Task<EngagementLetterAcceptProcess.AcceptResult> AcceptAsync(string? token, string? name, CancellationToken ct = default) =>
        _accept.AcceptAsync(token, name, ct);

    public Task<(Stream Stream, string? MimeType, string Filename)?> PdfAsync(string? token, CancellationToken ct = default) =>
        _accept.PdfAsync(token, ct);
}

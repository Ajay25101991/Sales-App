using SalesApi.Dtos;
using SalesApi.ProcessLayer.ApiKeys;

namespace SalesApi.ExperienceLayer.ApiKeys;

/// <summary>
/// What the Integrations screen's API-key panel needs. FORWARDS — same shape as ten of eleven domains migrated before it. Built anyway,
/// per the owner's 2026-08-28 decision to add Experience uniformly rather than carry a growing list of exceptions.
///
/// Carries no permission logic of its own: who may call these methods (ManageSettings) is decided at the controller, same as every layered
/// domain before it, so this file never widens who can read a key.
/// </summary>
public sealed class ApiKeysExperience
{
    private readonly ApiKeyProcess _keys;
    public ApiKeysExperience(ApiKeyProcess keys) => _keys = keys;

    public List<ScopeDefDto> Scopes() => _keys.Scopes();

    public Task<List<ApiKeyDto>> ListAsync(CancellationToken ct = default) => _keys.ListAsync(ct);

    public Task<ApiKeySettingsDto> GetSettingsAsync(CancellationToken ct = default) => _keys.GetSettingsAsync(ct);

    public Task<ApiKeyProcess.SettingsOutcome> SetSettingsAsync(int? defaultExpiryDays, int? rateLimitPerMinute, CancellationToken ct = default) =>
        _keys.SetSettingsAsync(defaultExpiryDays, rateLimitPerMinute, ct);

    public Task<ApiKeyProcess.CreateOutcome> CreateAsync(
        string? name, List<string>? scopes, DateTime? expiresAt, int? expiresInDays, Guid createdById, CancellationToken ct = default) =>
        _keys.CreateAsync(name, scopes, expiresAt, expiresInDays, createdById, ct);

    public Task<ApiKeyProcess.KeyOutcome> UpdateAsync(Guid id, string? name, List<string>? scopes, Guid actorId, CancellationToken ct = default) =>
        _keys.UpdateAsync(id, name, scopes, actorId, ct);

    public Task<ApiKeyProcess.KeyOutcome> RevokeAsync(Guid id, Guid actorId, CancellationToken ct = default) =>
        _keys.RevokeAsync(id, actorId, ct);

    public Task<ApiKeyProcess.CreateOutcome> RotateAsync(Guid id, Guid actorId, CancellationToken ct = default) =>
        _keys.RotateAsync(id, actorId, ct);
}

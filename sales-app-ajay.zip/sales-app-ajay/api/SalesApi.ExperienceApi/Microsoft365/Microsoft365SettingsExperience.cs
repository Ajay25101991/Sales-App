using SalesApi.Dtos;
using SalesApi.ProcessLayer.Microsoft365;

namespace SalesApi.ExperienceLayer.Microsoft365;

/// <summary>Admin: the Microsoft 365 umbrella summary + "Check access". FORWARDS, same
/// shape as <c>WhatsAppSettingsExperience</c>.</summary>
public sealed class Microsoft365SettingsExperience
{
    private readonly Microsoft365SettingsProcess _settings;
    private readonly Microsoft365TestConnectionProcess _test;
    private readonly SharePointMoveProcess _move;

    public Microsoft365SettingsExperience(Microsoft365SettingsProcess settings, Microsoft365TestConnectionProcess test, SharePointMoveProcess move)
    {
        _settings = settings;
        _test = test;
        _move = move;
    }

    // "Move existing files to SharePoint": each action answers the GET body (or a plain refusal the route turns into a 400).
    public async Task<(MicrosoftConnectionDto? Dto, SharePointMoveProcess.Refusal? Refusal)> StartMoveAsync(Guid actorId, CancellationToken ct = default) =>
        await After(await _move.StartAsync(actorId, ct: ct), ct);

    public async Task<(MicrosoftConnectionDto? Dto, SharePointMoveProcess.Refusal? Refusal)> StopMoveAsync(CancellationToken ct = default) =>
        await After(await _move.StopAsync(ct), ct);

    public async Task<(MicrosoftConnectionDto? Dto, SharePointMoveProcess.Refusal? Refusal)> RetryFailedMoveAsync(Guid actorId, CancellationToken ct = default) =>
        await After(await _move.RetryFailedAsync(actorId, ct: ct), ct);

    private async Task<(MicrosoftConnectionDto? Dto, SharePointMoveProcess.Refusal? Refusal)> After(SharePointMoveProcess.Refusal? refusal, CancellationToken ct) =>
        refusal is not null ? (null, refusal) : (await _settings.GetAsync(ct), null);

    public Task<MicrosoftConnectionDto> GetAsync(CancellationToken ct = default) => _settings.GetAsync(ct);

    public Task<MicrosoftConnectionDto?> RetrySyncProblemAsync(Guid id, CancellationToken ct = default) =>
        _settings.RetrySyncProblemAsync(id, ct);

    public Task<(MicrosoftConnectionDto? Dto, Microsoft365SettingsProcess.Refusal? Refusal)> SaveAsync(MicrosoftSettingsInput input, Guid actorId, CancellationToken ct = default) =>
        _settings.SaveAsync(input, actorId, ct);

    public Task<MicrosoftConnectionDto> TestConnectionAsync(Guid actorId, CancellationToken ct = default) =>
        _test.TestAsync(actorId, ct);
}

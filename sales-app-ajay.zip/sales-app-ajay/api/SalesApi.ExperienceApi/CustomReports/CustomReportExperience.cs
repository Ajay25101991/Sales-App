using SalesApi.Dtos;
using SalesApi.ProcessLayer.CustomReports;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.CustomReports;

/// <summary>
/// Forwards today — same honest mid-migration state <c>ReportsExperience</c>
/// documents for itself. One consumer (the desktop/web Reports screen) so far;
/// the natural second one (a scheduled export of a saved custom report, slice 4)
/// is exactly why this layer exists rather than the controller calling Process
/// directly.
/// </summary>
public sealed class CustomReportExperience
{
    private readonly CustomReportProcess _reports;
    public CustomReportExperience(CustomReportProcess reports) => _reports = reports;

    /// <summary><paramref name="Dto"/> is a <see cref="CustomReportResultDto"/>
    /// for breakdown mode, or a <see cref="CustomReportTableResultDto"/> for
    /// table mode — see <c>CustomReportProcess.RunAsync</c>'s own remarks.</summary>
    public Task<(CustomReportProcess.Refusal? Refusal, object? Dto)> RunAsync(
        RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole,
        CustomReportRequestDto request, CancellationToken ct = default, ReportViewer? viewer = null) =>
        _reports.RunAsync(ctx, showValues, orgId, callerRole, request, ct, viewer: viewer);

    public Task<(CustomReportProcess.Refusal? Refusal, string? Csv)> ExportCsvAsync(
        RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole,
        CustomReportRequestDto request, CancellationToken ct = default, ReportViewer? viewer = null) =>
        _reports.ExportCsvAsync(ctx, showValues, orgId, callerRole, request, ct, viewer: viewer);

    /// <summary>E18.2: every source this caller may report over, with its fields.</summary>
    public Task<ReportSourcesDto> SourcesAsync(
        Guid? orgId, string callerRole, ReportViewer viewer, CancellationToken ct = default, SensitiveAccess? sensitive = null) =>
        _reports.SourcesAsync(orgId, callerRole, viewer, ct, sensitive);

    /// <summary>E18.2: a non-lead source's table columns catalogue (null = no such source for this caller).</summary>
    public Task<TableColumnsDto?> SourceTableColumnsAsync(
        string sourceKey, Guid? orgId, string callerRole, ReportViewer viewer, CancellationToken ct = default, SensitiveAccess? sensitive = null) =>
        _reports.SourceTableColumnsAsync(sourceKey, orgId, callerRole, viewer, ct, sensitive);

    public Task<CustomReportFieldsDto> FieldsAsync(Guid? orgId, string callerRole, CancellationToken ct = default, SensitiveAccess? sensitive = null) =>
        _reports.FieldsAsync(orgId, callerRole, ct, sensitive);

    /// <summary>The results table's columns (type, sort / filter support, operators, options) for this caller.</summary>
    public Task<TableColumnsDto> TableColumnsAsync(
        RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole, CancellationToken ct = default) =>
        _reports.TableColumnsAsync(ctx, showValues, orgId, callerRole, ct);
}

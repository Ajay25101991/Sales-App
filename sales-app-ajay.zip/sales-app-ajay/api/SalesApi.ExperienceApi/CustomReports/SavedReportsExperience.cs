using SalesApi.Dtos;
using SalesApi.ProcessLayer.CustomReports;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.CustomReports;

/// <summary>Forwards today, same honest mid-migration shape as
/// <c>CustomReportExperience</c> beside it — one consumer (the Reports
/// screen) so far.</summary>
public sealed class SavedReportsExperience
{
    private readonly SavedReportProcess _reports;
    public SavedReportsExperience(SavedReportProcess reports) => _reports = reports;

    public Task<List<SavedReportDto>> ListForMeAsync(SavedReportProcess.Caller caller, CancellationToken ct = default) =>
        _reports.ListForMeAsync(caller, ct);

    public Task<(SavedReportDto? Dto, SavedReportProcess.Refusal? Refusal)> GetAsync(
        SavedReportProcess.Caller caller, Guid id, CancellationToken ct = default) =>
        _reports.GetAsync(caller, id, ct);

    public Task<(SavedReportDto? Created, SavedReportProcess.Refusal? Refusal)> CreateAsync(
        SavedReportProcess.Caller caller, Guid? orgId, string callerRole, SavedReportInput input, CancellationToken ct = default) =>
        _reports.CreateAsync(caller, orgId, callerRole, input, ct);

    public Task<(SavedReportDto? Updated, SavedReportProcess.Refusal? Refusal)> UpdateAsync(
        SavedReportProcess.Caller caller, Guid? orgId, string callerRole, Guid id, SavedReportInput input, CancellationToken ct = default) =>
        _reports.UpdateAsync(caller, orgId, callerRole, id, input, ct);

    public Task<SavedReportProcess.Refusal?> DeleteAsync(SavedReportProcess.Caller caller, Guid id, CancellationToken ct = default) =>
        _reports.DeleteAsync(caller, id, ct);

    public Task<(object? Dto, SavedReportProcess.Refusal? Refusal)> RunAsync(
        SavedReportProcess.Caller caller, RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole,
        Guid id, CancellationToken ct = default, ReportViewer? viewer = null) =>
        _reports.RunAsync(caller, ctx, showValues, orgId, callerRole, id, ct, viewer);

    public Task<(string? Csv, SavedReportProcess.Refusal? Refusal)> ExportCsvAsync(
        SavedReportProcess.Caller caller, RecordAccessContext ctx, bool showValues, Guid? orgId, string callerRole,
        Guid id, CancellationToken ct = default, ReportViewer? viewer = null) =>
        _reports.ExportCsvAsync(caller, ctx, showValues, orgId, callerRole, id, ct, viewer);
}

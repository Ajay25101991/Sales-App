using SalesApi.Dtos;
using SalesApi.ProcessLayer.AccountingSync;

namespace SalesApi.ExperienceLayer.AccountingSync;

/// <summary>
/// What the finance screens need from the accounting sync log. Every method
/// forwards — no screen wants a different shape than Process computes yet; the
/// seam is here for when one does (same stance as <c>InvoicesExperience</c>).
/// </summary>
public sealed class AccountingSyncExperience
{
    private readonly AccountingSyncProcess _sync;
    public AccountingSyncExperience(AccountingSyncProcess sync) => _sync = sync;

    public Task<List<AccountingSyncDto>> ListFailedAsync(int? limit, CancellationToken ct = default) =>
        _sync.ListFailedAsync(limit, ct);

    public Task<AccountingSyncProcess.RetryOutcome> RetryAsync(Guid id, DateTime now, CancellationToken ct = default) =>
        _sync.RetryAsync(id, now, ct);
}

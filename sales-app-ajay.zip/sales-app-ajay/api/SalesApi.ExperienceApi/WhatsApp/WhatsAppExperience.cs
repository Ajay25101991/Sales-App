using SalesApi.Dtos;
using SalesApi.ProcessLayer.WhatsApp;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.WhatsApp;

/// <summary>What the lead-detail composer needs (design §7.2): the window
/// indicator and the send action. FORWARDS — same shape every other thin
/// Experience in this story takes.</summary>
public sealed class WhatsAppExperience
{
    private readonly WhatsAppSendProcess _send;
    public WhatsAppExperience(WhatsAppSendProcess send) => _send = send;

    public Task<(WhatsAppSendProcess.Refusal? Refusal, WhatsAppWindowDto? Dto)> GetWindowAsync(
        RecordAccessContext vis, Guid leadId, CancellationToken ct = default) =>
        _send.GetWindowAsync(vis, leadId, ct);

    public Task<(WhatsAppSendProcess.Refusal? Refusal, WhatsAppSendResultDto? Dto)> SendAsync(
        RecordAccessContext vis, Guid callerId, Guid leadId, string? body, CancellationToken ct = default) =>
        _send.SendAsync(vis, callerId, leadId, body, ct);

    public Task<(WhatsAppSendProcess.Refusal? Refusal, WhatsAppSendResultDto? Dto)> SendTemplateAsync(
        RecordAccessContext vis, Guid callerId, Guid leadId, string? templateName, string? templateLanguage,
        IReadOnlyList<string>? templateParams, CancellationToken ct = default) =>
        _send.SendTemplateAsync(vis, callerId, leadId, templateName, templateLanguage, templateParams, ct);
}

/// <summary>Admin: the WhatsApp org settings + test connection. FORWARDS,
/// same shape as MailboxSyncSettingsExperience.</summary>
public sealed class WhatsAppSettingsExperience
{
    private readonly WhatsAppSettingsProcess _settings;
    private readonly WhatsAppTestConnectionProcess _test;

    public WhatsAppSettingsExperience(WhatsAppSettingsProcess settings, WhatsAppTestConnectionProcess test)
    {
        _settings = settings;
        _test = test;
    }

    public Task<WhatsAppSettingsDto> GetAsync(Guid? orgId = null, CancellationToken ct = default) => _settings.GetAsync(orgId, ct);

    public Task<(WhatsAppSettingsDto? Dto, WhatsAppSettingsProcess.Refusal? Refusal)> SaveAsync(
        WhatsAppSettingsInput input, Guid actorId, Guid? orgId = null, CancellationToken ct = default) =>
        _settings.SaveAsync(input, actorId, orgId, ct);

    public Task<WhatsAppTestConnectionResultDto> TestConnectionAsync(CancellationToken ct = default) => _test.TestAsync(ct);
}

/// <summary>E6.4 finish, slice 5 (design §3.4) — the template list + manual
/// "sync now" trigger. FORWARDS.</summary>
public sealed class WhatsAppTemplatesExperience
{
    private readonly WhatsAppTemplateSyncProcess _sync;
    public WhatsAppTemplatesExperience(WhatsAppTemplateSyncProcess sync) => _sync = sync;

    public Task<List<WhatsAppTemplateDto>> ListApprovedAsync(CancellationToken ct = default) => _sync.ListApprovedAsync(ct);

    public async Task<WhatsAppTemplateSyncResultDto> SyncNowAsync(CancellationToken ct = default)
    {
        var result = await _sync.SyncAsync(ct);
        return new WhatsAppTemplateSyncResultDto(result.Ok, result.Synced, result.ErrorReason);
    }
}

/// <summary>The "Unmatched WhatsApp" triage screen. FORWARDS.</summary>
public sealed class WhatsAppTriageExperience
{
    private readonly WhatsAppTriageProcess _triage;
    public WhatsAppTriageExperience(WhatsAppTriageProcess triage) => _triage = triage;

    public Task<List<WhatsAppUnmatchedMessageDto>> ListAsync(CancellationToken ct = default) => _triage.ListAsync(ct);

    public Task<(WhatsAppTriageProcess.Refusal? Refusal, WhatsAppUnmatchedMessageDto? Dto)> LinkAsync(
        Guid id, Guid leadId, Guid actorId, CancellationToken ct = default) => _triage.LinkAsync(id, leadId, actorId, ct);

    public Task<(WhatsAppTriageProcess.Refusal? Refusal, Guid? LeadId)> CreateLeadAsync(
        Guid id, Guid actorId, CancellationToken ct = default) => _triage.CreateLeadAsync(id, actorId, ct);

    public Task<(WhatsAppTriageProcess.Refusal? Refusal, WhatsAppUnmatchedMessageDto? Dto)> DismissAsync(
        Guid id, Guid actorId, CancellationToken ct = default) => _triage.DismissAsync(id, actorId, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.CatalogItems;

namespace SalesApi.ExperienceLayer.CatalogItems;

/// <summary>
/// What the Products and services list's admin screen (and every reader of it -
/// the deal form's picker, the quote builder, an account's ownership panel)
/// needs.
///
/// Forwarding, except for money: the PRICE is withheld (null, which the
/// contract omits) from a caller without financials.view, so a rep can pick a
/// product on a deal without learning what it sells for. Whether the caller may
/// see financials is a fact the controller resolved; this layer only shapes.
/// </summary>
public sealed class CatalogItemsExperience
{
    private readonly CatalogItemProcess _catalog;
    public CatalogItemsExperience(CatalogItemProcess catalog) => _catalog = catalog;

    private static CatalogItemDto Shape(CatalogItemDto item, bool canSeeFinancials) =>
        canSeeFinancials ? item : item with { Price = null };

    private static CatalogItemProcess.Result Shape(CatalogItemProcess.Result r, bool canSeeFinancials) =>
        r.Item is null ? r : r with { Item = Shape(r.Item, canSeeFinancials) };

    public async Task<List<CatalogItemDto>> ListAsync(bool includeArchived, bool canSeeFinancials, CancellationToken ct = default) =>
        [.. (await _catalog.ListAsync(includeArchived, ct)).Select(i => Shape(i, canSeeFinancials))];

    /// <summary>E10.2 - services the caller may propose for (optionally for one deal). NotFound is a deal the
    /// caller cannot see.</summary>
    public async Task<(List<CatalogItemDto>? Items, string? NotFound)> ListProposableAsync(
        SalesApi.Services.RecordAccessContext caller, Guid? dealId, bool canSeeFinancials, CancellationToken ct = default)
    {
        var (items, notFound) = await _catalog.ListProposableAsync(caller, dealId, ct);
        return (items?.Select(i => Shape(i, canSeeFinancials)).ToList(), notFound);
    }

    public Task<bool> CanProposeAsync(Guid catalogItemId, SalesApi.Services.RecordAccessContext caller, CancellationToken ct = default) =>
        _catalog.CanProposeAsync(catalogItemId, caller, ct);

    public async Task<CatalogItemProcess.Result> CreateAsync(CatalogItemInput input, bool canSeeFinancials, CancellationToken ct = default) =>
        Shape(await _catalog.CreateAsync(input, ct), canSeeFinancials);

    public async Task<CatalogItemProcess.Result> UpdateAsync(Guid id, CatalogItemInput input, bool canSeeFinancials, CancellationToken ct = default) =>
        Shape(await _catalog.UpdateAsync(id, input, ct), canSeeFinancials);

    public async Task<List<CatalogItemDto>> ReorderAsync(List<Guid> ids, bool canSeeFinancials, CancellationToken ct = default) =>
        [.. (await _catalog.ReorderAsync(ids, ct)).Select(i => Shape(i, canSeeFinancials))];

    public Task<CatalogItemProcess.DeleteOutcome> DeleteAsync(Guid id, CancellationToken ct = default) =>
        _catalog.DeleteAsync(id, ct);

    public async Task<CatalogItemProcess.Result> RestoreAsync(Guid id, bool canSeeFinancials, CancellationToken ct = default) =>
        Shape(await _catalog.RestoreAsync(id, ct), canSeeFinancials);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.AfterWin;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.AfterWin;

/// <summary>
/// What the won-deal "After the win" card needs. It forwards: the card wants exactly what <see cref="AfterWinProcess"/> works out,
/// and the first consumer with a different need (a phone summary, say) is where a difference would land - here, not in Process.
/// </summary>
public sealed class AfterWinExperience
{
    private readonly AfterWinProcess _afterWin;
    public AfterWinExperience(AfterWinProcess afterWin) => _afterWin = afterWin;

    public Task<AfterWinProcess.Outcome> GetAsync(
        RecordAccessContext ctx, LeadView view, Guid leadId, bool canViewMoney, bool canChangeSettings, DateTime now, CancellationToken ct = default) =>
        _afterWin.GetAsync(ctx, view, leadId, canViewMoney, canChangeSettings, now, ct);

    public Task<AfterWinProcess.Refusal?> DismissRecurringOfferAsync(RecordAccessContext ctx, Guid leadId, Guid actorId, DateTime now, CancellationToken ct = default) =>
        _afterWin.DismissRecurringOfferAsync(ctx, leadId, actorId, now, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Picklists;

namespace SalesApi.ExperienceLayer.Picklists;

/// <summary>What the Settings › Picklists screen, and any form rendering a
/// picklist-backed field, need. Forwards today — see Goals.GoalsExperience
/// for why that is still worth having.</summary>
public sealed class PicklistsExperience
{
    private readonly PicklistProcess _picklists;
    public PicklistsExperience(PicklistProcess picklists) => _picklists = picklists;

    public Task<List<OrgPicklistDto>> ListAsync(CancellationToken ct = default) => _picklists.ListAsync(ct);

    public Task<(OrgPicklistDto? Created, PicklistProcess.Refusal? Refusal)> CreateAsync(
        PicklistInput input, CancellationToken ct = default) => _picklists.CreateAsync(input, ct);

    public Task<(OrgPicklistValueDto? Created, PicklistProcess.Refusal? Refusal)> AddValueAsync(
        Guid picklistId, PicklistValueInput input, CancellationToken ct = default) =>
        _picklists.AddValueAsync(picklistId, input, ct);

    public Task<(OrgPicklistValueDto? Updated, PicklistProcess.Refusal? Refusal)> RenameValueAsync(
        Guid valueId, PicklistValueInput input, CancellationToken ct = default) =>
        _picklists.RenameValueAsync(valueId, input, ct);

    public Task<PicklistProcess.Refusal?> SetArchivedAsync(Guid valueId, bool archived, CancellationToken ct = default) =>
        _picklists.SetArchivedAsync(valueId, archived, ct);

    public Task<(List<OrgPicklistValueDto>? Reordered, PicklistProcess.Refusal? Refusal)> ReorderValuesAsync(
        Guid picklistId, List<Guid>? ids, CancellationToken ct = default) =>
        _picklists.ReorderValuesAsync(picklistId, ids, ct);

    public Task<PicklistProcess.Refusal?> DeleteValueAsync(Guid valueId, CancellationToken ct = default) =>
        _picklists.DeleteValueAsync(valueId, ct);
}

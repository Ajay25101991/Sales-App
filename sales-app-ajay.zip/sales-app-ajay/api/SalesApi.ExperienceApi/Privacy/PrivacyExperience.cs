using SalesApi.Dtos;
using SalesApi.ProcessLayer.Privacy;

namespace SalesApi.ExperienceLayer.Privacy;

/// <summary>
/// What the privacy request screen needs (E22.1). FORWARDS - same shape every migrated domain's Experience takes
/// (see <see cref="SalesApi.ExperienceLayer.DataAccessLog.DataAccessLogExperience"/>).
/// </summary>
public sealed class PrivacyExperience
{
    private readonly PrivacyProcess _privacy;
    public PrivacyExperience(PrivacyProcess privacy) => _privacy = privacy;

    public PrivacyMapDto Map() => _privacy.Map();

    public Task<PrivacyHoldsDto> GetHoldsAsync() => _privacy.GetHoldsAsync();

    public Task<(PrivacyHoldsDto? Holds, PrivacyProcess.Refusal? Refusal)> SaveHoldsAsync(PrivacyHoldsDto input) => _privacy.SaveHoldsAsync(input);

    public Task<List<PrivacyErasureLogDto>> ListLogAsync(CancellationToken ct = default) => _privacy.ListLogAsync(ct);

    public Task<(PrivacyExportFileDto? File, PrivacyProcess.Refusal? Refusal)> ExportAsync(
        string kind, Guid subjectId, Guid requestedBy, CancellationToken ct = default) =>
        _privacy.ExportAsync(kind, subjectId, requestedBy, ct);

    public Task<(PrivacyErasureResultDto? Result, PrivacyProcess.Refusal? Refusal)> EraseAsync(
        string kind, Guid subjectId, string? confirm, Guid requestedBy, CancellationToken ct = default) =>
        _privacy.EraseAsync(kind, subjectId, confirm, requestedBy, ct);
}

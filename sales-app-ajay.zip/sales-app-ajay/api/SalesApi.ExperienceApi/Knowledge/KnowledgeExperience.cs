using SalesApi.Dtos;
using SalesApi.ProcessLayer.Knowledge;

namespace SalesApi.ExperienceLayer.Knowledge;

/// <summary>What the "Admin, Knowledge" screen (design §6.5) needs. FORWARDS —
/// same shape every migrated domain's Experience takes, per
/// <see cref="AiPlatform.AiCostPolicyExperience"/>.</summary>
public sealed class KnowledgeExperience
{
    private readonly KnowledgeProcess _knowledge;
    public KnowledgeExperience(KnowledgeProcess knowledge) => _knowledge = knowledge;

    public Task<List<KnowledgeCollectionDto>> ListCollectionsAsync(CancellationToken ct = default) =>
        _knowledge.ListCollectionsAsync(ct);

    public Task<(KnowledgeCollectionDto? Dto, KnowledgeProcess.Refusal? Refusal)> CreateCollectionAsync(
        Guid? orgId, Guid actorId, KnowledgeCollectionInput input, CancellationToken ct = default) =>
        _knowledge.CreateCollectionAsync(orgId, actorId, input, ct);

    public Task<KnowledgeProcess.UpdateResult> UpdateCollectionAsync(Guid id, KnowledgeCollectionInput input, CancellationToken ct = default) =>
        _knowledge.UpdateCollectionAsync(id, input, ct);

    public Task<bool> DeleteCollectionAsync(Guid id, CancellationToken ct = default) =>
        _knowledge.DeleteCollectionAsync(id, ct);

    public Task<KnowledgeProcess.ListDocsResult> ListDocumentsAsync(Guid collectionId, CancellationToken ct = default) =>
        _knowledge.ListDocumentsAsync(collectionId, ct);

    public Task<KnowledgeProcess.UploadResult> UploadDocumentAsync(
        Guid collectionId, Guid? orgId, Guid uploaderId, string filename, string? contentType, long length,
        Stream content, CancellationToken ct = default) =>
        _knowledge.UploadDocumentAsync(collectionId, orgId, uploaderId, filename, contentType, length, content, ct);

    public Task<KnowledgeProcess.RetryResult> RetryDocumentAsync(Guid documentId, CancellationToken ct = default) =>
        _knowledge.RetryDocumentAsync(documentId, ct);

    public Task<bool> DeleteDocumentAsync(Guid documentId, CancellationToken ct = default) =>
        _knowledge.DeleteDocumentAsync(documentId, ct);
}

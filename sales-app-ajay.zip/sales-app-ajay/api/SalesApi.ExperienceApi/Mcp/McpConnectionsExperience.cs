using SalesApi.Dtos;
using SalesApi.ProcessLayer.Mcp;

namespace SalesApi.ExperienceLayer.Mcp;

/// <summary>The "AI tool connections" admin screen's consumer: forwards to <see cref="McpConnectionsProcess"/> (like <c>IntegrationEventsExperience</c>).</summary>
public sealed class McpConnectionsExperience
{
    private readonly McpConnectionsProcess _process;
    public McpConnectionsExperience(McpConnectionsProcess process) => _process = process;

    public Task<McpStatusDto> StatusAsync(Guid? orgId, string url, bool canConnect, bool mayReadRoles, CancellationToken ct = default, Guid? userId = null) =>
        _process.StatusAsync(orgId, url, canConnect, mayReadRoles, ct, userId);

    public Task<McpAccessDto> GetAccessAsync(Guid orgId, CancellationToken ct = default) => _process.GetAccessAsync(orgId, ct);

    public Task<(McpConnectionsProcess.Refusal? Refusal, McpAccessDto? Dto)> SetAccessAsync(Guid orgId, Guid actorId, McpAccessInput input, CancellationToken ct = default) =>
        _process.SetAccessAsync(orgId, actorId, input, ct);

    /// <summary>Writes one call-log line (what <c>McpToolRunner</c> calls); never throws.</summary>
    public Task RecordCallAsync(Guid orgId, string tool, bool isApiKey, Guid actorId, string outcome, string? reason, int durationMs, CancellationToken ct = default) =>
        _process.RecordAsync(orgId, tool, isApiKey, actorId, outcome, reason, durationMs, ct);

    public Task<McpCallPageDto> ListCallsAsync(int limit, string? cursor, CancellationToken ct = default) => _process.ListAsync(limit, cursor, ct);
}

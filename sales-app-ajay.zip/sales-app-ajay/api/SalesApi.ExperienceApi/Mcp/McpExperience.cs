using SalesApi.ProcessLayer.Mcp;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Mcp;

/// <summary>
/// What the MCP endpoint (<c>/mcp</c>, the AI-tool consumer) calls: one method per tool, each forwarding to the Process class that owns the read.
/// Forwards today, like <c>DashboardExperience</c> - the seam exists for the day an AI consumer wants a different shape from the app's. The tool
/// names, input schemas and annotations live on the host's <c>McpTools</c>; who the caller is and what they may do is decided before any method here
/// runs (<c>McpAccess</c>) and arrives as the <see cref="McpCaller"/> argument.
/// </summary>
public sealed class McpExperience
{
    private readonly McpReadProcess _read;
    private readonly McpSummaryProcess _summary;
    private readonly McpDirectoryProcess _directory;
    private readonly McpRecordsProcess _records;

    private readonly McpSuggestProcess _suggest;

    public McpExperience(McpReadProcess read, McpSummaryProcess summary, McpDirectoryProcess directory, McpRecordsProcess records, McpSuggestProcess suggest)
    {
        _suggest = suggest;
        _read = read;
        _summary = summary;
        _directory = directory;
        _records = records;
    }

    public Task<McpToolResult> SearchAsync(McpCaller c, string? query, IReadOnlyList<string>? types, CancellationToken ct) => _read.SearchAsync(c, query, types, ct);
    public Task<McpToolResult> GetDealAsync(McpCaller c, Guid id, CancellationToken ct) => _read.GetDealAsync(c, id, ct);
    public Task<McpToolResult> GetAccountAsync(McpCaller c, Guid id, CancellationToken ct) => _read.GetAccountAsync(c, id, ct);
    public Task<McpToolResult> GetContactAsync(McpCaller c, Guid id, CancellationToken ct) => _read.GetContactAsync(c, id, ct);
    public Task<McpToolResult> DraftEmailAsync(McpCaller c, Guid dealId, string? subject, string? body, CancellationToken ct) => _read.DraftEmailAsync(c, dealId, subject, body, ct);
    public Task<McpToolResult> ListLinkedAsync(McpCaller c, string recordType, Guid id, CancellationToken ct) => _read.ListLinkedAsync(c, recordType, id, ct);
    public Task<McpToolResult> GetTimelineAsync(McpCaller c, string recordType, Guid id, string? cursor, int? limit, string? kinds, string? scope, CancellationToken ct) =>
        _read.GetTimelineAsync(c, recordType, id, cursor, limit, kinds, scope, ct);

    public Task<McpToolResult> DealBriefAsync(McpCaller c, Guid id, CancellationToken ct) => _summary.DealBriefAsync(c, id, ct);
    public Task<McpToolResult> AccountSummaryAsync(McpCaller c, Guid id, CancellationToken ct) => _summary.AccountSummaryAsync(c, id, ct);
    public Task<McpToolResult> PipelineSummaryAsync(McpCaller c, string? period, Guid? teamId, CancellationToken ct) => _summary.PipelineSummaryAsync(c, period, teamId, ct);

    public Task<McpToolResult> ListWorkflowsAsync(McpCaller c, CancellationToken ct) => _directory.ListWorkflowsAsync(c, ct);
    public Task<McpToolResult> ListUsersAsync(McpCaller c, CancellationToken ct) => _directory.ListUsersAsync(c, ct);
    public Task<McpToolResult> ListTeamsAsync(McpCaller c, CancellationToken ct) => _directory.ListTeamsAsync(c, ct);

    public Task<McpToolResult> ListRecordTypesAsync(McpCaller c) => _records.ListRecordTypesAsync(c);
    public Task<McpToolResult> DescribeRecordTypeAsync(McpCaller c, string recordType, CancellationToken ct) => _records.DescribeRecordTypeAsync(c, recordType, ct);
    public Task<McpToolResult> ListRecordsAsync(McpCaller c, string recordType, string? search, string? filters, string? sorts, int? limit, string? cursor, CancellationToken ct) =>
        _records.ListRecordsAsync(c, recordType, search, filters, sorts, limit, cursor, ct);
    public Task<McpToolResult> EnrichmentContextAsync(McpCaller c, string recordType, Guid id, CancellationToken ct) => _records.EnrichmentContextAsync(c, recordType, id, ct);

    public Task<McpToolResult> SuggestFieldValueAsync(McpCaller c, string recordType, Guid id, string field, System.Text.Json.JsonElement value, string? note, string? sourceUrl, CancellationToken ct) =>
        _suggest.SuggestAsync(c, recordType, id, field, value, note, sourceUrl, ct);
}

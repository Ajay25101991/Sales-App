using SalesApi.Dtos;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.ChannelPartners;

/// <summary>
/// What the bulk partner upload and the "Partners to complete" screen need, shaped for the desktop (to-do/partner-management-design.md section 11). Thin on purpose: the two imports
/// (preview and commit are ONE Process method with a flag), the masking by Partner commercials and every write path already live in Process, which reuses the account, contact,
/// relationship, partner-profile and deal-partner paths. THIS FILE CANNOT SEE THE DATABASE (the Experience project hides the System layer).
/// </summary>
public sealed class PartnerBulkExperience
{
    private readonly PartnerBulkImportProcess _import;
    private readonly PartnerCompletionProcess _completion;

    public PartnerBulkExperience(PartnerBulkImportProcess import, PartnerCompletionProcess completion)
    {
        _import = import;
        _completion = completion;
    }

    // ---- the two files ----
    public Task<CpResult<PartnerFileResultDto>> PartnersPreviewAsync(RecordAccessContext ctx, PartnerImportActor actor, PartnerFileInput input, CancellationToken ct = default) =>
        _import.PartnersAsync(ctx, actor, input, commit: false, ct);
    public Task<CpResult<PartnerFileResultDto>> PartnersCommitAsync(RecordAccessContext ctx, PartnerImportActor actor, PartnerFileInput input, CancellationToken ct = default) =>
        _import.PartnersAsync(ctx, actor, input, commit: true, ct);
    public Task<CpResult<ClientSheetResultDto>> ClientsPreviewAsync(RecordAccessContext ctx, PartnerImportActor actor, ClientSheetInput input, CancellationToken ct = default) =>
        _import.ClientsAsync(ctx, actor, input, commit: false, ct);
    public Task<CpResult<ClientSheetResultDto>> ClientsCommitAsync(RecordAccessContext ctx, PartnerImportActor actor, ClientSheetInput input, CancellationToken ct = default) =>
        _import.ClientsAsync(ctx, actor, input, commit: true, ct);

    // ---- partners to complete, and attaching a plan later ----
    public Task<PartnersToCompleteDto> ToCompleteAsync(RecordAccessContext ctx, CancellationToken ct = default) => _completion.ToCompleteAsync(ctx, ct);

    /// <summary>One deal partner (the list of one) or, with <paramref name="partnerAccountId"/>, all of a partner's planless deal partners.</summary>
    public Task<CpResult<BackPayPreviewDto>> BackPayPreviewAsync(RecordAccessContext ctx, Guid? partnerAccountId, AttachPlanInput input, CancellationToken ct = default) =>
        _completion.PreviewAsync(ctx, partnerAccountId, input, ct);
    public Task<CpResult<AttachPlanResultDto>> AttachPlanAsync(RecordAccessContext ctx, Guid? partnerAccountId, AttachPlanInput input, CancellationToken ct = default) =>
        _completion.AttachAsync(ctx, partnerAccountId, input, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Accounts;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.ChannelPartners;

/// <summary>
/// What the Stock tab, the channel stock page, the deal partner card and the distributor view need (Phase 3), shaped for the desktop. Thin on purpose: the masking by the caller's
/// Partner commercials level already happens in Process. The one thing composed here is "add a sub-reseller": the org's depth rule is Process's
/// (<see cref="PartnerStockProcess.CheckSubResellerAsync"/>) and the edge itself is the EXISTING <see cref="AccountProcess.AddRelationshipAsync"/>, so there is one way to add a
/// relationship between accounts.
///
/// THIS FILE CANNOT SEE THE DATABASE (the Experience project hides the System layer).
/// </summary>
public sealed class PartnerStockExperience
{
    private readonly PartnerStockProcess _stock;
    private readonly AccountProcess _accounts;
    public PartnerStockExperience(PartnerStockProcess stock, AccountProcess accounts)
    {
        _stock = stock;
        _accounts = accounts;
    }

    // ---- a partner's stock ----
    public Task<CpResult<PartnerStockSummaryDto>> SummaryAsync(RecordAccessContext ctx, Guid partnerAccountId, CancellationToken ct = default) => _stock.SummaryAsync(ctx, partnerAccountId, ct);
    public Task<CpResult<PartnerStockMovementPageDto>> MovementsAsync(
        RecordAccessContext ctx, Guid partnerAccountId, Guid? lotId, string? kind, int skip, int take, CancellationToken ct = default) =>
        _stock.MovementsAsync(ctx, partnerAccountId, lotId, kind, skip, take, ct);
    public Task<CpResult<PartnerStockLotDto>> RecordLotAsync(RecordAccessContext ctx, Guid partnerAccountId, PartnerStockLotInput input, Guid actorId, CancellationToken ct = default) =>
        _stock.RecordLotAsync(ctx, partnerAccountId, input, actorId, ct);
    public Task<CpResult<PartnerStockLotDto>> OverrideLotAsync(RecordAccessContext ctx, Guid lotId, PartnerStockOverrideInput input, Guid actorId, CancellationToken ct = default) =>
        _stock.OverrideLotAsync(ctx, lotId, input, actorId, ct);
    public Task<CpResult<PartnerStockLotDto>> AdjustLotAsync(RecordAccessContext ctx, Guid lotId, PartnerStockAdjustInput input, Guid actorId, CancellationToken ct = default) =>
        _stock.AdjustLotAsync(ctx, lotId, input, actorId, ct);
    public Task<CpResult<PartnerStockLotDto>> ApplyCreditAsync(RecordAccessContext ctx, PartnerStockCreditApplyInput input, Guid actorId, CancellationToken ct = default) =>
        _stock.ApplyCreditAsync(ctx, input, actorId, ct);
    public Task<CpResult<PartnerStockOverviewDto>> OverviewAsync(RecordAccessContext ctx, int expiringWithinDays, CancellationToken ct = default) =>
        _stock.OverviewAsync(ctx, expiringWithinDays, ct);

    // ---- a deal partner's stock, and the two named figures ----
    public Task<CpResult<DealPartnerStockDto>> DealPartnerStockAsync(RecordAccessContext ctx, Guid leadId, Guid dealPartnerId, CancellationToken ct = default) =>
        _stock.DealPartnerStockAsync(ctx, leadId, dealPartnerId, ct);
    public Task<CpResult<DealPartnerStockDto>> SetDealPartnerStockAsync(RecordAccessContext ctx, Guid leadId, Guid dealPartnerId, DealPartnerStockInput input, CancellationToken ct = default) =>
        _stock.SetDealPartnerStockAsync(ctx, leadId, dealPartnerId, input, ct);
    public Task<CpResult<DealRevenueDto>> DealRevenueAsync(RecordAccessContext ctx, Guid leadId, CancellationToken ct = default) => _stock.DealRevenueAsync(ctx, leadId, ct);

    // ---- distributors ----
    public Task<CpResult<DistributorTreeDto>> TreeAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default) => _stock.TreeAsync(ctx, accountId, ct);

    /// <summary>The depth / partner / cycle checks (Process), then the ordinary account relationship distributor_for: distributor -> sub-reseller.</summary>
    public async Task<CpResult<AccountRelationshipDto>> AddSubResellerAsync(
        RecordAccessContext ctx, Guid distributorId, SubResellerInput input, Guid actorId, CancellationToken ct = default)
    {
        var check = await _stock.CheckSubResellerAsync(ctx, distributorId, input.SubResellerAccountId, ct);
        if (!check.IsOk) return Cp.As<AccountRelationshipDto, bool>(check);
        var (refusal, relationship) = await _accounts.AddRelationshipAsync(
            ctx, distributorId, new AccountRelationshipInput(input.SubResellerAccountId, ChannelPartnerVocab.DistributorRelationship), actorId, ct);
        if (refusal is null) return Cp.Ok(relationship!);
        return refusal switch
        {
            { NotFound: true } => Cp.NotFound<AccountRelationshipDto>(refusal.Reason),
            { Forbidden: true } => Cp.Forbidden<AccountRelationshipDto>(refusal.Reason, refusal.Code),
            { Conflict: true } or { Code: "duplicate_relationship" } => Cp.Conflict<AccountRelationshipDto>(refusal.Reason, refusal.Code),
            _ => Cp.Invalid<AccountRelationshipDto>(refusal.Reason, refusal.Code),
        };
    }
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.ChannelPartners;

/// <summary>
/// What the channel-partner screens need, shaped for the desktop: partner profiles and settings, deal partners on a deal, and commission plans.
///
/// THIS FILE CANNOT SEE THE DATABASE (the Experience project hides the System layer). It is thin today because the screens want almost exactly what the Process layer
/// computes - the masking by the caller's Partner commercials / ID &amp; bank level already happens in Process, from the access context. A phone that wants less
/// would be shaped here.
/// </summary>
public sealed class ChannelPartnersExperience
{
    private readonly ChannelPartnerProcess _partners;
    private readonly PartnerPlanProcess _plans;
    private readonly PartnerRemittanceProcess? _remittances;
    public ChannelPartnersExperience(ChannelPartnerProcess partners, PartnerPlanProcess plans, PartnerRemittanceProcess? remittances = null)
    {
        _partners = partners;
        _plans = plans;
        _remittances = remittances;
    }

    // ---- settings / profiles ----
    public Task<ChannelPartnerSettingsDto> SettingsAsync() => _partners.GetSettingsAsync();
    public Task<CpResult<ChannelPartnerSettingsDto>> SaveSettingsAsync(ChannelPartnerSettingsInput input) => _partners.SaveSettingsAsync(input);

    public Task<List<PartnerListItemDto>> ListAsync(RecordAccessContext ctx, string? status, string? type, CancellationToken ct = default) =>
        _partners.ListAsync(ctx, status, type, ct);
    public Task<List<PartnerPickDto>> PickerAsync(CancellationToken ct = default) => _partners.PickerAsync(ct);
    public Task<CpResult<PartnerProfileDto>> GetAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default) => _partners.GetAsync(ctx, accountId, ct);
    public Task<CpResult<PartnerOverviewDto>> OverviewAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default) => _partners.OverviewAsync(ctx, accountId, ct);
    public Task<CpResult<PartnerProfileDto>> CreateAsync(RecordAccessContext ctx, Guid accountId, PartnerProfileInput input, Guid actorId, CancellationToken ct = default) =>
        _partners.CreateAsync(ctx, accountId, input, actorId, ct);
    public Task<CpResult<PartnerProfileDto>> UpdateAsync(RecordAccessContext ctx, Guid accountId, PartnerProfileInput input, CancellationToken ct = default) =>
        _partners.UpdateAsync(ctx, accountId, input, ct);
    public Task<CpResult<PartnerTermsOpenDealsDto>> TermsOpenDealsAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default) => _partners.TermsOpenDealsAsync(ctx, accountId, ct);
    public Task<CpResult<PartnerTermsAppliedDto>> ApplyTermsToOpenDealsAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default) => _partners.ApplyTermsToOpenDealsAsync(ctx, accountId, ct);
    public Task<CpResult<bool>> DeleteAsync(RecordAccessContext ctx, Guid accountId, CancellationToken ct = default) => _partners.DeleteAsync(ctx, accountId, ct);

    // ---- deal partners ----
    public Task<CpResult<List<DealPartnerDto>>> DealPartnersAsync(RecordAccessContext ctx, Guid leadId, bool includeEnded, CancellationToken ct = default) =>
        _partners.ListDealPartnersAsync(ctx, leadId, includeEnded, ct);
    public Task<CpResult<List<DealPartnerDto>>> DealsOfPartnerAsync(RecordAccessContext ctx, Guid accountId, bool activeOnly, CancellationToken ct = default) =>
        _partners.DealsOfPartnerAsync(ctx, accountId, activeOnly, ct);
    public async Task<CpResult<DealPartnerDto>> AttributeAsync(RecordAccessContext ctx, Guid leadId, DealPartnerInput input, Guid actorId, CancellationToken ct = default)
    {
        var attributed = await _partners.AttributeAsync(ctx, leadId, input, actorId, ct);
        // Owner Q5: a financial-service partner that bills the end client gets its billing deal made and linked right away; the answer then carries the link.
        if (attributed.IsOk && attributed.Value is { BillsEndClient: true, BillingLeadId: null } fsp && _remittances is not null
            && await _remittances.EnsureBillingDealAsync(ctx, fsp.Id, actorId, ct) is not null)
            return await _partners.ListDealPartnersAsync(ctx, leadId, includeEnded: true, ct) is { IsOk: true } listed && listed.Value!.FirstOrDefault(d => d.Id == fsp.Id) is { } fresh
                ? Cp.Ok(fresh) : attributed;
        return attributed;
    }
    public Task<CpResult<DealPartnerDto>> EndDealPartnerAsync(RecordAccessContext ctx, Guid dealPartnerId, DealPartnerEndInput input, Guid actorId, CancellationToken ct = default) =>
        _partners.EndAsync(ctx, dealPartnerId, input, actorId, ct);
    public Task<CpResult<DealPartnerDto>> RepointAsync(RecordAccessContext ctx, Guid dealPartnerId, DealPartnerRepointInput input, CancellationToken ct = default) =>
        _partners.RepointAsync(ctx, dealPartnerId, input, ct);

    // ---- plans ----
    public Task<List<PartnerPlanDto>> PlansAsync(bool includeArchived, CancellationToken ct = default) => _plans.ListAsync(includeArchived, ct);
    public Task<bool> PlanCreatedByAsync(Guid planId, Guid userId, CancellationToken ct = default) => _plans.CreatedByAsync(planId, userId, ct);
    public Task<CpResult<PartnerPlanDto>> PlanAsync(Guid planId, CancellationToken ct = default) => _plans.GetAsync(planId, ct);
    public Task<CpResult<PartnerPlanSavedDto>> CreatePlanAsync(PartnerPlanCreateInput input, Guid? userId, CancellationToken ct = default) => _plans.CreateAsync(input, userId, ct);
    public Task<CpResult<PartnerPlanSavedDto>> SavePlanDraftAsync(Guid planId, PartnerPlanDraftInput input, Guid? userId, CancellationToken ct = default) =>
        _plans.SaveDraftAsync(planId, input, userId, ct);
    public Task<CpResult<PricingValidationDto>> ValidatePlanAsync(Guid planId, PartnerPlanContentDto? body, bool forPublish, CancellationToken ct = default) =>
        _plans.ValidateAsync(planId, body, forPublish, ct);
    public Task<CpResult<decimal>> PreviewPlanAsync(Guid planId, PartnerPlanContentDto? body, decimal collected, decimal dealBase, CancellationToken ct = default) =>
        _plans.PreviewAsync(planId, body, collected, dealBase, ct);
    public Task<CpResult<PartnerPlanVersionDto>> PublishPlanAsync(Guid planId, Guid? userId, CancellationToken ct = default) => _plans.PublishAsync(planId, userId, ct);
    public Task<CpResult<List<PartnerPlanVersionDto>>> PlanVersionsAsync(Guid planId, CancellationToken ct = default) => _plans.ListVersionsAsync(planId, ct);
    public Task<CpResult<PartnerPlanVersionDto>> PlanVersionAsync(Guid planId, int version, CancellationToken ct = default) => _plans.GetVersionAsync(planId, version, ct);
    public Task<CpResult<PartnerPlanDto>> RestorePlanVersionAsync(Guid planId, int version, bool replaceDraft, Guid? userId, CancellationToken ct = default) =>
        _plans.RestoreVersionAsync(planId, version, replaceDraft, userId, ct);
    public Task<CpResult<PartnerPlanDto>> SetPlanArchivedAsync(Guid planId, bool archived, CancellationToken ct = default) => _plans.SetArchivedAsync(planId, archived, ct);
    public Task<CpResult<List<PartnerPlanAssignmentDto>>> AssignmentsAsync(Guid partnerAccountId, CancellationToken ct = default) => _plans.ListAssignmentsAsync(partnerAccountId, ct);
    public Task<CpResult<PartnerPlanAssignmentDto>> AssignAsync(Guid partnerAccountId, PartnerPlanAssignmentInput input, Guid? userId, CancellationToken ct = default) =>
        _plans.AssignAsync(partnerAccountId, input, userId, ct);
}

/// <summary>The partner's money: ledger, clawback decisions, statements, and the stored aggregate. See <see cref="PartnerLedgerProcess"/>.</summary>
public sealed class PartnerMoneyExperience
{
    private readonly PartnerLedgerProcess _ledger;
    public PartnerMoneyExperience(PartnerLedgerProcess ledger) => _ledger = ledger;

    public Task<CpResult<PartnerLedgerPageDto>> LedgerAsync(
        RecordAccessContext ctx, Guid? partnerAccountId, Guid? leadId, Guid? dealPartnerId, string? kind, DateTime? from, DateTime? to, bool? settled, int skip, int take,
        string? direction = null, CancellationToken ct = default) =>
        _ledger.PageAsync(ctx, partnerAccountId, leadId, dealPartnerId, kind, from, to, settled, skip, take, direction, ct);
    public Task<CpResult<PartnerAdjustmentResultDto>> AdjustAsync(RecordAccessContext ctx, Guid partnerAccountId, PartnerLedgerAdjustInput input, Guid actorId, CancellationToken ct = default) =>
        _ledger.AdjustAsync(ctx, partnerAccountId, input, actorId, ct);

    public Task<CpResult<List<PartnerClawbackDecisionDto>>> DecisionsAsync(RecordAccessContext ctx, Guid? partnerAccountId, string? status, CancellationToken ct = default) =>
        _ledger.ListDecisionsAsync(ctx, partnerAccountId, status, ct);
    public Task<CpResult<PartnerClawbackDecisionDto>> DecideAsync(RecordAccessContext ctx, Guid decisionId, PartnerClawbackDecideInput input, Guid actorId, CancellationToken ct = default) =>
        _ledger.DecideAsync(ctx, decisionId, input, actorId, ct);

    public Task<CpResult<PartnerStatementDto>> PreviewStatementAsync(RecordAccessContext ctx, Guid partnerAccountId, PartnerStatementInput input, CancellationToken ct = default) =>
        _ledger.PreviewStatementAsync(ctx, partnerAccountId, input, ct);
    public Task<CpResult<PartnerStatementDto>> IssueStatementAsync(RecordAccessContext ctx, Guid partnerAccountId, PartnerStatementInput input, Guid actorId, CancellationToken ct = default) =>
        _ledger.IssueStatementAsync(ctx, partnerAccountId, input, actorId, ct);
    public Task<CpResult<List<PartnerStatementDto>>> StatementsAsync(RecordAccessContext ctx, Guid partnerAccountId, string? direction = null, CancellationToken ct = default) =>
        _ledger.ListStatementsAsync(ctx, partnerAccountId, direction, ct);
    public Task<CpResult<PartnerStatementDto>> StatementAsync(RecordAccessContext ctx, Guid statementId, CancellationToken ct = default) => _ledger.GetStatementAsync(ctx, statementId, ct);
    public Task<CpResult<(string FileName, byte[] Pdf)>> StatementPdfAsync(RecordAccessContext ctx, Guid statementId, CancellationToken ct = default) =>
        _ledger.StatementPdfAsync(ctx, statementId, ct);

    public Task<CpResult<PartnerStatsDto>> StatsAsync(RecordAccessContext ctx, Guid? partnerAccountId, DateOnly? from, DateOnly? to, CancellationToken ct = default) =>
        _ledger.StatsAsync(ctx, partnerAccountId, from, to, ct);
    public Task<CpResult<bool>> ResyncStatsAsync(Guid? partnerAccountId, CancellationToken ct = default) => _ledger.ResyncStatsAsync(partnerAccountId, ct);
}

/// <summary>Payouts to partners: prepare, submit for approval, mark paid, bank CSV. See <see cref="PartnerPayoutProcess"/>.</summary>
public sealed class PartnerPayoutsExperience
{
    private readonly PartnerPayoutProcess _payouts;
    public PartnerPayoutsExperience(PartnerPayoutProcess payouts) => _payouts = payouts;

    public Task<CpResult<List<PartnerPayoutDto>>> ListAsync(RecordAccessContext ctx, Guid? partnerAccountId, string? status, CancellationToken ct = default) =>
        _payouts.ListAsync(ctx, partnerAccountId, status, ct);
    public Task<CpResult<PartnerPayoutDto>> GetAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) => _payouts.GetAsync(ctx, id, ct);
    public Task<CpResult<PartnerPayoutDto>> PrepareAsync(RecordAccessContext ctx, PartnerPayoutPrepareInput input, Guid actorId, CancellationToken ct = default) =>
        _payouts.PrepareAsync(ctx, input, actorId, ct);
    public Task<CpResult<PartnerPayoutDto>> UpdateAsync(RecordAccessContext ctx, Guid id, PartnerPayoutUpdateInput input, CancellationToken ct = default) =>
        _payouts.UpdateAsync(ctx, id, input, ct);
    public Task<CpResult<PartnerPayoutDto>> SubmitAsync(RecordAccessContext ctx, Guid id, Guid actorId, CancellationToken ct = default) => _payouts.SubmitAsync(ctx, id, actorId, ct);
    public Task<CpResult<PartnerPayoutDto>> CancelAsync(RecordAccessContext ctx, Guid id, PartnerPayoutCancelInput input, CancellationToken ct = default) =>
        _payouts.CancelAsync(ctx, id, input, ct);
    public Task<CpResult<PartnerPayoutDto>> MarkPaidAsync(RecordAccessContext ctx, Guid id, PartnerPayoutMarkPaidInput input, Guid actorId, CancellationToken ct = default) =>
        _payouts.MarkPaidAsync(ctx, id, input, actorId, ct);
    public Task<CpResult<(string FileName, byte[] Content)>> ExportAsync(RecordAccessContext ctx, IReadOnlyCollection<Guid>? ids, CancellationToken ct = default) =>
        _payouts.ExportAsync(ctx, ids, ct);
}

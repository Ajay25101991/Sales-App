using SalesApi.Dtos;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.ChannelPartners;

// Channel partners, Phase 2: what the desktop screens need, shaped for them. Thin on purpose, like ChannelPartnersExperience - the masking by the caller's Partner commercials level
// already happens in Process, from the access context, and this project cannot see the database.

/// <summary>Registrations (a record), the pipeline flag and claim conflicts. See <see cref="PartnerRegistrationProcess"/>.</summary>
public sealed class PartnerRegistrationExperience
{
    private readonly PartnerRegistrationProcess _registrations;
    public PartnerRegistrationExperience(PartnerRegistrationProcess registrations) => _registrations = registrations;

    public Task<CpResult<List<DealPartnerDto>>> QueueAsync(RecordAccessContext ctx, string? registrationStatus, bool pipelinePending, CancellationToken ct = default) =>
        _registrations.ListAsync(ctx, registrationStatus, pipelinePending, ct);
    public Task<CpResult<DealPartnerDto>> RecordAsync(RecordAccessContext ctx, Guid dealPartnerId, DealPartnerRegistrationInput input, Guid actorId, CancellationToken ct = default) =>
        _registrations.RecordAsync(ctx, dealPartnerId, input, actorId, ct);
    public Task<CpResult<DealPartnerDto>> DecidePipelineAsync(
        RecordAccessContext ctx, Guid dealPartnerId, PipelineDecisionInput input, Guid actorId, bool isPartnerManager, CancellationToken ct = default) =>
        _registrations.DecidePipelineAsync(ctx, dealPartnerId, input, actorId, isPartnerManager, ct);

    public Task<CpResult<List<PartnerRegistrationConflictDto>>> ConflictsAsync(
        RecordAccessContext ctx, string? status, Guid? partnerAccountId, Guid? leadId, CancellationToken ct = default) =>
        _registrations.ConflictsAsync(ctx, status, partnerAccountId, leadId, ct);
    public Task<CpResult<PartnerRegistrationConflictDto>> DecideConflictAsync(
        RecordAccessContext ctx, Guid conflictId, PartnerConflictDecideInput input, Guid actorId, CancellationToken ct = default) =>
        _registrations.DecideConflictAsync(ctx, conflictId, input, actorId, ct);
}

/// <summary>An integrator's milestones and the cost they record. See <see cref="PartnerMilestoneProcess"/>.</summary>
public sealed class PartnerMilestoneExperience
{
    private readonly PartnerMilestoneProcess _milestones;
    public PartnerMilestoneExperience(PartnerMilestoneProcess milestones) => _milestones = milestones;

    public Task<CpResult<List<DealPartnerMilestoneDto>>> ListAsync(RecordAccessContext ctx, Guid dealPartnerId, CancellationToken ct = default) =>
        _milestones.ListAsync(ctx, dealPartnerId, ct);
    public Task<CpResult<List<PartnerLedgerEntryDto>>> CostsAsync(RecordAccessContext ctx, CancellationToken ct = default) => _milestones.CostsAsync(ctx, ct);
    public Task<CpResult<DealPartnerMilestoneDto>> CreateAsync(RecordAccessContext ctx, Guid dealPartnerId, DealPartnerMilestoneInput input, Guid actorId, CancellationToken ct = default) =>
        _milestones.CreateAsync(ctx, dealPartnerId, input, actorId, ct);
    public Task<CpResult<DealPartnerMilestoneDto>> UpdateAsync(RecordAccessContext ctx, Guid milestoneId, DealPartnerMilestoneInput input, CancellationToken ct = default) =>
        _milestones.UpdateAsync(ctx, milestoneId, input, ct);
    public Task<CpResult<bool>> DeleteAsync(RecordAccessContext ctx, Guid milestoneId, CancellationToken ct = default) => _milestones.DeleteAsync(ctx, milestoneId, ct);
    public Task<CpResult<DealPartnerMilestoneDto>> AcceptAsync(RecordAccessContext ctx, Guid milestoneId, MilestoneDecisionInput input, Guid actorId, bool isPartnerManager, CancellationToken ct = default) =>
        _milestones.AcceptAsync(ctx, milestoneId, input, actorId, isPartnerManager, ct);
    public Task<CpResult<DealPartnerMilestoneDto>> RejectAsync(RecordAccessContext ctx, Guid milestoneId, MilestoneDecisionInput input, Guid actorId, bool isPartnerManager, CancellationToken ct = default) =>
        _milestones.RejectAsync(ctx, milestoneId, input, actorId, isPartnerManager, ct);
    public Task<CpResult<DealPartnerMilestoneDto>> ReopenAsync(RecordAccessContext ctx, Guid milestoneId, MilestoneDecisionInput input, Guid actorId, bool isPartnerManager, CancellationToken ct = default) =>
        _milestones.ReopenAsync(ctx, milestoneId, input, actorId, isPartnerManager, ct);
}

/// <summary>What an FSP owes us. See <see cref="PartnerRemittanceProcess"/>.</summary>
public sealed class PartnerRemittanceExperience
{
    private readonly PartnerRemittanceProcess _remittances;
    public PartnerRemittanceExperience(PartnerRemittanceProcess remittances) => _remittances = remittances;

    public Task<CpResult<List<PartnerRemittanceDto>>> ListAsync(RecordAccessContext ctx, Guid? partnerAccountId, Guid? dealPartnerId, string? status, CancellationToken ct = default) =>
        _remittances.ListAsync(ctx, partnerAccountId, dealPartnerId, status, ct);
    public Task<CpResult<PartnerBalancesDto>> BalancesAsync(RecordAccessContext ctx, Guid partnerAccountId, CancellationToken ct = default) => _remittances.BalancesAsync(ctx, partnerAccountId, ct);
    public Task<CpResult<PartnerRemittanceDto>> LinkBillingDealAsync(RecordAccessContext ctx, Guid dealPartnerId, DealPartnerBillingDealInput input, Guid actorId, CancellationToken ct = default) =>
        _remittances.LinkBillingDealAsync(ctx, dealPartnerId, input, actorId, ct);
    public Task<CpResult<PartnerRemittanceDto>> UpdateAsync(RecordAccessContext ctx, Guid id, PartnerRemittanceUpdateInput input, CancellationToken ct = default) =>
        _remittances.UpdateAsync(ctx, id, input, ct);
    public Task<CpResult<PartnerRemittanceDto>> LinkInvoiceAsync(RecordAccessContext ctx, Guid id, PartnerRemittanceLinkInvoiceInput input, CancellationToken ct = default) =>
        _remittances.LinkInvoiceAsync(ctx, id, input, ct);
    public Task<CpResult<PartnerRemittanceDto>> WaiveAsync(RecordAccessContext ctx, Guid id, PartnerRemittanceWaiveInput input, Guid actorId, CancellationToken ct = default) =>
        _remittances.WaiveAsync(ctx, id, input, actorId, ct);
}

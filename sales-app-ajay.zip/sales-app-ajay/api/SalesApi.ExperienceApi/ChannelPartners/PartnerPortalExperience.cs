using SalesApi.Dtos;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.ChannelPartners;

/// <summary>
/// What the separate partner-portal app needs, shaped for it. READ-ONLY by construction: this class has no method that writes. The partner arrives as a
/// <see cref="PartnerPortalScope"/> the controller built from the principal; this layer cannot see the database or the principal (the Experience project hides the System layer).
/// Thin today because the portal's own DTOs are already what the Process layer returns.
/// </summary>
public sealed class PartnerPortalExperience
{
    private readonly PartnerPortalProcess _portal;
    public PartnerPortalExperience(PartnerPortalProcess portal) => _portal = portal;

    public Task<CpResult<PartnerPortalMeDto>> MeAsync(PartnerPortalScope scope, CancellationToken ct = default) => _portal.MeAsync(scope, ct);
    public Task<CpResult<PartnerPortalOverviewDto>> OverviewAsync(PartnerPortalScope scope, CancellationToken ct = default) => _portal.OverviewAsync(scope, ct);
    public Task<CpResult<List<PartnerPortalDealDto>>> DealsAsync(PartnerPortalScope scope, CancellationToken ct = default) => _portal.DealsAsync(scope, ct);
    public Task<CpResult<PartnerPortalDealDetailDto>> DealAsync(PartnerPortalScope scope, Guid dealPartnerId, CancellationToken ct = default) => _portal.DealAsync(scope, dealPartnerId, ct);
    public Task<CpResult<PartnerPortalEntriesPageDto>> EntriesAsync(PartnerPortalScope scope, int skip, int take, CancellationToken ct = default) => _portal.EntriesAsync(scope, skip, take, ct);
    public Task<CpResult<List<PartnerPortalStatementDto>>> StatementsAsync(PartnerPortalScope scope, CancellationToken ct = default) => _portal.StatementsAsync(scope, ct);
    public Task<CpResult<PartnerPortalStatementDto>> StatementAsync(PartnerPortalScope scope, Guid statementId, CancellationToken ct = default) => _portal.StatementAsync(scope, statementId, ct);
    public Task<CpResult<(string FileName, byte[] Pdf)>> StatementPdfAsync(PartnerPortalScope scope, Guid statementId, CancellationToken ct = default) => _portal.StatementPdfAsync(scope, statementId, ct);
    public Task<CpResult<List<PartnerPortalPayoutDto>>> PayoutsAsync(PartnerPortalScope scope, CancellationToken ct = default) => _portal.PayoutsAsync(scope, ct);
    public Task<CpResult<PartnerPortalPayoutDto>> PayoutAsync(PartnerPortalScope scope, Guid payoutId, CancellationToken ct = default) => _portal.PayoutAsync(scope, payoutId, ct);
    public Task<CpResult<PartnerPortalUsageDto>> UsageAsync(PartnerPortalScope scope, DateOnly? from, DateOnly? to, CancellationToken ct = default) => _portal.UsageAsync(scope, from, to, ct);
}

/// <summary>The channel team's portal-user panel: invite, list, resend, switch off. See <see cref="PartnerPortalUsersProcess"/>.</summary>
public sealed class PartnerPortalUsersExperience
{
    private readonly PartnerPortalUsersProcess _users;
    public PartnerPortalUsersExperience(PartnerPortalUsersProcess users) => _users = users;

    public Task<CpResult<PartnerPortalUsageDto>> UsageAsync(RecordAccessContext ctx, Guid partnerAccountId, DateOnly? from, DateOnly? to, CancellationToken ct = default) =>
        _users.UsageAsync(ctx, partnerAccountId, from, to, ct);
    /// <param name="kind">E19.1: "partner" or "customer" (PortalKinds, which this layer cannot name); the controller always passes it.</param>
    public Task<CpResult<List<PartnerPortalUserDto>>> ListAsync(RecordAccessContext ctx, Guid partnerAccountId, string kind, CancellationToken ct = default) => _users.ListAsync(ctx, partnerAccountId, ct, kind: kind);
    public Task<CpResult<PartnerPortalUserInvitedDto>> InviteAsync(
        RecordAccessContext ctx, Guid partnerAccountId, PartnerPortalUserInviteInput input, Guid actorId, Func<string, string> buildUrl, string kind, CancellationToken ct = default) =>
        _users.InviteAsync(ctx, partnerAccountId, input, actorId, buildUrl, ct, kind: kind);
    public Task<CpResult<bool>> SetActiveAsync(RecordAccessContext ctx, Guid partnerAccountId, Guid userId, bool active, Guid actorId, string kind, CancellationToken ct = default) =>
        _users.SetActiveAsync(ctx, partnerAccountId, userId, active, actorId, ct, kind: kind);
    public Task<CpResult<PartnerPortalUserInvitedDto>> ResendInviteAsync(
        RecordAccessContext ctx, Guid partnerAccountId, Guid userId, Func<string, string> buildUrl, string kind, CancellationToken ct = default) =>
        _users.ResendInviteAsync(ctx, partnerAccountId, userId, buildUrl, ct, kind: kind);
}

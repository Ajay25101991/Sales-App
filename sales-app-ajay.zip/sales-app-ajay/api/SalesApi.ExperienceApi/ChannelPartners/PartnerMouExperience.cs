using SalesApi.Dtos;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.ChannelPartners;

/// <summary>
/// The partner MoU net-margin screens (to-do/partner-mou-net-margin-design.md): consumption entry and upload, "Run month", the statement and its approve / void, and the monthly report. Thin on
/// purpose - the masking by Partner commercials and every rule is in <see cref="PartnerMouProcess"/>; this project cannot see the database.
/// </summary>
public sealed class PartnerMouExperience
{
    private readonly PartnerMouProcess _mou;
    public PartnerMouExperience(PartnerMouProcess mou) => _mou = mou;

    public Task<CpResult<List<PartnerConsumptionDto>>> ConsumptionAsync(RecordAccessContext ctx, Guid partnerAccountId, string? month, CancellationToken ct = default) =>
        _mou.ConsumptionAsync(ctx, partnerAccountId, month, ct);
    public Task<CpResult<PartnerConsumptionDto>> SaveConsumptionAsync(RecordAccessContext ctx, Guid partnerAccountId, PartnerConsumptionInput input, Guid actorId, CancellationToken ct = default) =>
        _mou.SaveConsumptionAsync(ctx, partnerAccountId, input, actorId, ct);
    public Task<CpResult<PartnerConsumptionUploadResultDto>> UploadConsumptionAsync(RecordAccessContext ctx, Guid partnerAccountId, PartnerConsumptionUploadInput input, Guid actorId, CancellationToken ct = default) =>
        _mou.UploadAsync(ctx, partnerAccountId, input, actorId, ct);

    public Task<CpResult<PartnerMouStatementDto>> RunAsync(RecordAccessContext ctx, Guid partnerAccountId, PartnerMouRunInput input, Guid actorId, CancellationToken ct = default) =>
        _mou.RunAsync(ctx, partnerAccountId, input, actorId, ct);
    public Task<CpResult<List<PartnerMouStatementSummaryDto>>> StatementsAsync(RecordAccessContext ctx, Guid partnerAccountId, CancellationToken ct = default) =>
        _mou.StatementsAsync(ctx, partnerAccountId, ct);
    public Task<CpResult<PartnerMouStatementDto>> StatementAsync(RecordAccessContext ctx, Guid statementId, Guid actorId, bool inChannel, CancellationToken ct = default) => _mou.StatementAsync(ctx, statementId, actorId, inChannel, ct);
    public Task<CpResult<List<PartnerMouStatementSummaryDto>>> AwaitingMyChoiceAsync(RecordAccessContext ctx, Guid actorId, bool isPartnerManager, CancellationToken ct = default) => _mou.AwaitingMyChoiceAsync(ctx, actorId, isPartnerManager, ct);
    public Task<CpResult<PartnerMouStatementDto>> ApproveAsync(RecordAccessContext ctx, Guid statementId, PartnerMouApproveInput input, Guid actorId, CancellationToken ct = default) =>
        _mou.ApproveAsync(ctx, statementId, input, actorId, ct);
    public Task<CpResult<PartnerMouStatementDto>> VoidAsync(RecordAccessContext ctx, Guid statementId, PartnerMouVoidInput input, Guid actorId, CancellationToken ct = default) =>
        _mou.VoidAsync(ctx, statementId, input, actorId, ct);
    public Task<CpResult<PartnerMouStatementDto>> ChooseShortfallAsync(RecordAccessContext ctx, Guid statementId, PartnerMouShortfallInput input, Guid actorId, bool isPartnerManager, CancellationToken ct = default) =>
        _mou.ChooseShortfallAsync(ctx, statementId, input, actorId, isPartnerManager, ct);
    public Task<CpResult<PartnerMouStatementDto>> RecordReceiptAsync(RecordAccessContext ctx, Guid statementId, PartnerMouReceiptInput input, Guid actorId, CancellationToken ct = default) =>
        _mou.RecordReceiptAsync(ctx, statementId, input, actorId, ct);
    public Task<CpResult<PartnerMouReportDto>> ReportAsync(RecordAccessContext ctx, string? from, string? to, CancellationToken ct = default) => _mou.ReportAsync(ctx, from, to, ct);
}

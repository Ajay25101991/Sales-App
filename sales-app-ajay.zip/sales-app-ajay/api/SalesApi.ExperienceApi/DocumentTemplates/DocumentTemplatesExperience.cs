using SalesApi.Dtos;
using SalesApi.ProcessLayer.DocumentTemplates;

namespace SalesApi.ExperienceLayer.DocumentTemplates;

/// <summary>
/// What the settings screen and the service editor need for deck and letter templates (E10.4 / E10.9). Pure forwarding today:
/// the shapes the screens want are what <see cref="DocumentTemplateProcess"/> returns. Rendering a proposal is NOT here - the
/// proposal generator (E10.5) calls <c>ProposalDocumentProcess</c>, not an HTTP-shaped experience.
/// </summary>
public sealed class DocumentTemplatesExperience
{
    private readonly DocumentTemplateProcess _templates;
    public DocumentTemplatesExperience(DocumentTemplateProcess templates) => _templates = templates;

    public Task<List<DocumentTemplateSlotDto>> ListAsync(CancellationToken ct = default) => _templates.ListAsync(ct);

    public Task<DocumentTemplateProcess.Result<DocumentFieldsDto>> FieldsAsync(string kind, Guid? catalogItemId, CancellationToken ct = default) =>
        _templates.FieldsAsync(kind, catalogItemId, ct);

    public Task<DocumentTemplateProcess.Result<List<DocumentTemplateVersionDto>>> ListVersionsAsync(string kind, Guid? catalogItemId, string? variant = null, CancellationToken ct = default) =>
        _templates.ListVersionsAsync(kind, catalogItemId, variant, ct);

    public Task<DocumentTemplateProcess.Result<DocumentTemplateVersionDto>> GetVersionAsync(Guid id, CancellationToken ct = default) =>
        _templates.GetVersionAsync(id, ct);

    public Task<DocumentTemplateProcess.Result<DocumentTemplateProcess.Download>> DownloadAsync(Guid id, CancellationToken ct = default) =>
        _templates.DownloadAsync(id, ct);

    public Task<DocumentTemplateProcess.Result<DocumentTemplateVersionDto>> UploadAsync(
        string kind, Guid? catalogItemId, string? fileName, byte[] bytes, Guid? userId, bool dryRun, string? variant = null, CancellationToken ct = default) =>
        _templates.UploadAsync(kind, catalogItemId, fileName, bytes, userId, dryRun, variant, ct);
}

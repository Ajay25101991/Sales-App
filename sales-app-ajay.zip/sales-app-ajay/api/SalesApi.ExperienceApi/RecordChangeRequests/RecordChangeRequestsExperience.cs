using SalesApi.Dtos;
using SalesApi.ProcessLayer.RecordChangeRequests;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.RecordChangeRequests;

/// <summary>Pass-through to <see cref="RecordChangeRequestProcess"/> - the controller-facing shape for E19.2's two surfaces: what a portal user submits and sees, and the
/// staff queue. No orchestration across verticals lives here (the seam exists for consistency with every other Experience class).</summary>
public sealed class RecordChangeRequestsExperience
{
    private readonly RecordChangeRequestProcess _requests;
    public RecordChangeRequestsExperience(RecordChangeRequestProcess requests) => _requests = requests;

    // ---- portal user ----

    public Task<(RecordChangeRequestProcess.Refusal? Refusal, RecordChangePortalDto? Dto)> SubmitAsync(
        RecordChangePortalScope scope, RecordChangeSubmitInput input, CancellationToken ct = default) =>
        _requests.SubmitAsync(scope, input, ct);

    public Task<List<RecordChangePortalDto>> MineAsync(RecordChangePortalScope scope, CancellationToken ct = default) =>
        _requests.MineAsync(scope, ct);

    public Task<(RecordChangeRequestProcess.Refusal? Refusal, RecordChangePortalDto? Dto)> WithdrawAsync(
        RecordChangePortalScope scope, Guid id, CancellationToken ct = default) =>
        _requests.WithdrawAsync(scope, id, ct);

    // ---- staff ----

    public Task<(RecordChangeRequestProcess.Refusal? Refusal, List<RecordChangeRequestDto>? Items)> ListAsync(
        RecordAccessContext ctx, string callerRole, string? status, Guid? accountId, CancellationToken ct = default) =>
        _requests.ListAsync(ctx, callerRole, status, accountId, ct);

    public Task<(RecordChangeRequestProcess.Refusal? Refusal, RecordChangeRequestDto? Dto)> ApproveAsync(
        RecordAccessContext ctx, string callerRole, Guid id, CancellationToken ct = default) =>
        _requests.ApproveAsync(ctx, callerRole, id, ct);

    public Task<(RecordChangeRequestProcess.Refusal? Refusal, RecordChangeRequestDto? Dto)> RejectAsync(
        RecordAccessContext ctx, string callerRole, Guid id, string? reason, CancellationToken ct = default) =>
        _requests.RejectAsync(ctx, callerRole, id, reason, ct);
}

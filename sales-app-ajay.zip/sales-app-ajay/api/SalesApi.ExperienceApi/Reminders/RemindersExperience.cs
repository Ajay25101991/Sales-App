using SalesApi.Dtos;
using SalesApi.ProcessLayer.Reminders;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Reminders;

/// <summary>
/// What the reminders screens need, shaped for them.
///
/// It is a pass-through today, and says so plainly rather than dressing itself
/// up: every endpoint returns exactly what Process computes. Built anyway
/// (owner decision 2026-08-28, "build Experience everywhere") so the seam
/// already exists the day a consumer — a phone widget wanting only today's
/// reminders, a digest wanting a different shape — asks for something Process
/// does not already hand back.
/// </summary>
public sealed class RemindersExperience
{
    private readonly ReminderProcess _reminders;
    public RemindersExperience(ReminderProcess reminders) => _reminders = reminders;

    public Task<List<ReminderDto>> ListAsync(
        RecordAccessContext ctx, string? ownerIdFilter, bool? pending, string? status,
        CancellationToken ct = default) =>
        _reminders.ListAsync(ctx, ownerIdFilter, pending, status, ct);

    public Task<(ReminderDto? Dto, ReminderProcess.Refusal? Refusal)> CreateAsync(
        Guid userId, ReminderInput input, CancellationToken ct = default) =>
        _reminders.CreateAsync(userId, input, ct);

    public Task<(ReminderDto? Dto, ReminderProcess.Refusal? Refusal)> UpdateAsync(
        RecordAccessContext ctx, Guid? orgId, Guid id, ReminderInput input, CancellationToken ct = default) =>
        _reminders.UpdateAsync(ctx, orgId, id, input, ct);

    public Task<ReminderProcess.Refusal?> DeleteAsync(Guid userId, Guid id, CancellationToken ct = default) =>
        _reminders.DeleteAsync(userId, id, ct);

    public Task<int> SweepAsync(Guid orgId) => _reminders.SweepAsync(orgId);
}

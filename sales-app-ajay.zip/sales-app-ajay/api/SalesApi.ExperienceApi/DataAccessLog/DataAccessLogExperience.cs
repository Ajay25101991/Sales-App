using SalesApi.Dtos;
using SalesApi.ProcessLayer.DataAccessLog;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.DataAccessLog;

/// <summary>
/// What the "Data access log" admin screen, the device-launch call and the export filter need. FORWARDS - same shape every
/// migrated domain's Experience takes (see AiExecutionLogExperience).
/// </summary>
public sealed class DataAccessLogExperience
{
    private readonly DataAccessLogProcess _log;
    public DataAccessLogExperience(DataAccessLogProcess log) => _log = log;

    public Task<(PagedResult<DataAccessLogEntryDto>? Page, DataAccessLogProcess.Refusal? Refusal)> ListAsync(
        Guid? userId, string? action, string? recordType, Guid? recordId, DateTime? from, DateTime? to,
        string? cursor, int? limit, CancellationToken ct = default) =>
        _log.ListAsync(userId, action, recordType, recordId, from, to, cursor, limit, ct);

    public Task RecordExportAsync(Guid userId, string recordType, int rowCount, string format, CancellationToken ct = default) =>
        _log.RecordExportAsync(userId, recordType, rowCount, format, ct);

    public Task<DataAccessLogProcess.Refusal?> LaunchAsync(
        RecordAccessContext ctx, bool mayOpenWhatsAppExternal, DataAccessLaunchInput input, CancellationToken ct = default) =>
        _log.LaunchAsync(ctx, mayOpenWhatsAppExternal, input, ct);
}

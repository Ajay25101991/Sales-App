using SalesApi.Dtos;
using SalesApi.ProcessLayer.Approvals;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Approvals;

/// <summary>
/// What the approvals screens need.
///
/// Built for uniformity per the owner's 2026-08-28 decision (every domain gets
/// an Experience class), not because these screens want a different shape than
/// Process computes — they do not. Every method here forwards; say so plainly
/// rather than dressing a pass-through up as a reshape. The seam is the
/// purchase: the moment a second consumer (a phone's "approve" quick action
/// wanting a slimmer payload, a digest that only wants the count) wants
/// something different, the difference lands here and Process stays untouched.
/// </summary>
public sealed class ApprovalsExperience
{
    private readonly ApprovalProcess _approvals;
    public ApprovalsExperience(ApprovalProcess approvals) => _approvals = approvals;

    public Task<List<ApprovalDto>> ListAsync(
        RecordAccessContext ctx, string? status, bool hasViewFinancials, bool hasViewLeadValues, CancellationToken ct = default) =>
        _approvals.ListAsync(ctx, status, hasViewFinancials, hasViewLeadValues, ct);

    public Task<int> PendingCountAsync(
        RecordAccessContext ctx, bool hasFinancials, bool canDecideGateExceptions,
        string selfDecisionPolicy, CancellationToken ct = default) =>
        _approvals.PendingCountAsync(ctx, hasFinancials, canDecideGateExceptions, selfDecisionPolicy, ct);

    public Task<ApprovalProcess.ApprovalOutcome> CreateAsync(
        ApprovalInput input, Guid requesterId, bool hasViewLeadValues, CancellationToken ct = default) =>
        _approvals.CreateAsync(input, requesterId, hasViewLeadValues, ct);

    public Task<ApprovalProcess.ApprovalOutcome> DecideAsync(
        Guid id, ApprovalDecisionInput input, Guid deciderId,
        bool hasDecideApprovals, bool hasViewFinancials, bool canDecideGateExceptions,
        RecordAccessContext ctx, string selfDecisionPolicy, bool hasViewLeadValues,
        CancellationToken ct = default) =>
        _approvals.DecideAsync(id, input, deciderId, hasDecideApprovals, hasViewFinancials, canDecideGateExceptions, ctx, selfDecisionPolicy, hasViewLeadValues, ct);

    // E2.6 slice 9 — used only by ApprovalChainsController, once
    // ApprovalChainProcess.DecideStepAsync reports a chain's final outcome.
    // See ApprovalProcess.ApplyChainOutcomeAsync's own comment for why this
    // path skips the permission re-checks DecideAsync above performs.
    public Task<ApprovalProcess.ApprovalOutcome> ApplyChainOutcomeAsync(
        Guid requestId, bool approve, Guid deciderId, string? note, bool hasViewLeadValues, CancellationToken ct = default) =>
        _approvals.ApplyChainOutcomeAsync(requestId, approve, deciderId, note, hasViewLeadValues, ct);
}

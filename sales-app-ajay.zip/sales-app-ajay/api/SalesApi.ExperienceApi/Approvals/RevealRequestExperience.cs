using SalesApi.Dtos;
using SalesApi.ProcessLayer.Approvals;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Approvals;

/// <summary>
/// What the reveal-request screens need (E12.5). FORWARDS - same plain pass-through every other domain's Experience starts as; the
/// "request a reveal" form and the approver's queue both want exactly the shapes Process builds.
/// </summary>
public sealed class RevealRequestExperience
{
    private readonly RevealRequestProcess _reveals;
    public RevealRequestExperience(RevealRequestProcess reveals) => _reveals = reveals;

    public Task<RevealRequestProcess.Outcome> CreateAsync(RecordAccessContext ctx, RevealRequestInput input, CancellationToken ct = default) =>
        _reveals.CreateAsync(ctx, input, ct);

    public Task<(ApprovalProcess.Refusal? Refusal, RevealRequestListDto? Page)> ListAsync(
        RecordAccessContext ctx, string? status, CancellationToken ct = default) =>
        _reveals.ListAsync(ctx, status, ct);

    public Task LogFirstReadsAsync(Guid userId, IEnumerable<RevealGrant> usedGrants, CancellationToken ct = default) =>
        _reveals.LogFirstReadsAsync(userId, usedGrants, ct);
}

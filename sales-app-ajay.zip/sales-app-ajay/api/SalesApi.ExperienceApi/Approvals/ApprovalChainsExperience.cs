using SalesApi.Dtos;
using SalesApi.ProcessLayer.Approvals;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Approvals;

/// <summary>
/// What the approval-chain admin screens (and the chain-decide endpoint) need
/// — a pass-through onto <see cref="ApprovalChainProcess"/>, same uniformity
/// rationale as <see cref="ApprovalsExperience"/> beside it.
/// </summary>
public sealed class ApprovalChainsExperience
{
    private readonly ApprovalChainProcess _chains;
    public ApprovalChainsExperience(ApprovalChainProcess chains) => _chains = chains;

    public Task<List<ApprovalChainDto>> ListAsync(CancellationToken ct = default) => _chains.ListAsync(ct);

    public Task<ApprovalChainDto?> GetAsync(Guid id, CancellationToken ct = default) => _chains.GetAsync(id, ct);

    public Task<(ApprovalChainDto? Created, ApprovalChainProcess.Refusal? Refusal)> CreateAsync(
        ApprovalChainInput input, Guid createdById, CancellationToken ct = default) =>
        _chains.CreateAsync(input, createdById, ct);

    public Task<(ApprovalChainDto? Updated, ApprovalChainProcess.Refusal? Refusal)> UpdateAsync(
        Guid id, ApprovalChainInput input, CancellationToken ct = default) =>
        _chains.UpdateAsync(id, input, ct);

    public Task<ApprovalChainProcess.Refusal?> DeleteAsync(Guid id, CancellationToken ct = default) =>
        _chains.DeleteAsync(id, ct);

    public Task<(List<ApprovalChainDto>? Reordered, ApprovalChainProcess.Refusal? Refusal)> ReorderAsync(
        List<Guid>? ids, CancellationToken ct = default) => _chains.ReorderAsync(ids, ct);

    public Task<(bool Visible, ApprovalChainInstanceDto? Instance)> GetInstanceForRequestAsync(
        Guid requestId, RecordAccessContext ctx, CancellationToken ct = default) =>
        _chains.GetInstanceForRequestAsync(requestId, ctx, ct);

    public Task<ApprovalChainProcess.StepDecisionOutcome> DecideStepAsync(
        Guid instanceId, ApprovalChainStepDecisionInput input, Guid deciderId,
        RecordAccessContext ctx, CancellationToken ct = default, bool? holdsApprovePartnerPayouts = null) =>
        _chains.DecideStepAsync(instanceId, input, deciderId, ctx, ct, holdsApprovePartnerPayouts);
}

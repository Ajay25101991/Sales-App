using SalesApi.Dtos;
using SalesApi.ProcessLayer.CompanyDocuments;

namespace SalesApi.ExperienceLayer.CompanyDocuments;

/// <summary>
/// The company documents library for the settings screen and for the "Attach company documents" picker on a send. Pure forwarding today:
/// the shapes the screens want are what <see cref="CompanyDocumentProcess"/> returns (like <c>DocumentTemplatesExperience</c>).
/// </summary>
public sealed class CompanyDocumentsExperience
{
    private readonly CompanyDocumentProcess _documents;
    public CompanyDocumentsExperience(CompanyDocumentProcess documents) => _documents = documents;

    public Task<List<CompanyDocumentDto>> ListAsync(bool includeArchived, CancellationToken ct = default) => _documents.ListAsync(includeArchived, ct);

    public Task<List<CompanyDocumentOptionDto>> OptionsAsync(CancellationToken ct = default) => _documents.OptionsAsync(ct);

    public Task<CompanyDocumentProcess.Result<List<CompanyDocumentVersionDto>>> VersionsAsync(Guid id, CancellationToken ct = default) => _documents.VersionsAsync(id, ct);

    public Task<CompanyDocumentProcess.Result<CompanyDocumentDto>> UploadAsync(
        string? name, string? category, string? fileName, string? contentType, Stream content, long length, Guid? userId, CancellationToken ct = default) =>
        _documents.UploadAsync(name, category, fileName, contentType, content, length, userId, ct);

    public Task<CompanyDocumentProcess.Result<CompanyDocumentDto>> ReplaceAsync(
        Guid id, string? fileName, string? contentType, Stream content, long length, Guid? userId, CancellationToken ct = default) =>
        _documents.ReplaceAsync(id, fileName, contentType, content, length, userId, ct);

    public Task<CompanyDocumentProcess.Result<CompanyDocumentDto>> UpdateAsync(Guid id, UpdateCompanyDocumentInput input, CancellationToken ct = default) =>
        _documents.UpdateAsync(id, input, ct);

    public Task<CompanyDocumentProcess.Result<(byte[] Bytes, string ContentType, string FileName)>> DownloadAsync(Guid id, int? version, CancellationToken ct = default) =>
        _documents.DownloadAsync(id, version, ct);
}

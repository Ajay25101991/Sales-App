using SalesApi.Dtos;
using SalesApi.ProcessLayer.Studio;

namespace SalesApi.ExperienceLayer.Studio;

/// <summary>What the Studio home screen (checklist + go-live readiness) needs
/// — thin forwarding to <see cref="StudioChecklistProcess"/>, same shape as
/// <c>PackagesExperience</c>.</summary>
public sealed class StudioChecklistExperience
{
    private readonly StudioChecklistProcess _checklist;
    public StudioChecklistExperience(StudioChecklistProcess checklist) => _checklist = checklist;

    public Task<StudioChecklistResponseDto> GetChecklistAsync(Guid orgId, CancellationToken ct = default) =>
        _checklist.GetChecklistAsync(orgId, ct);

    public Task<StudioChecklistItemDto?> CreateItemAsync(
        Guid orgId, Guid? actorId, StudioChecklistItemInputDto input, CancellationToken ct = default) =>
        _checklist.CreateItemAsync(orgId, actorId, input, ct);

    public Task<bool> SetCheckedAsync(Guid orgId, Guid itemId, bool @checked, Guid? actorId, CancellationToken ct = default) =>
        _checklist.SetCheckedAsync(orgId, itemId, @checked, actorId, ct);

    public Task<bool> DeleteItemAsync(Guid orgId, Guid itemId, CancellationToken ct = default) =>
        _checklist.DeleteItemAsync(orgId, itemId, ct);
}

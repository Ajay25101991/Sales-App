using SalesApi.Dtos;
using SalesApi.ProcessLayer.Studio;

namespace SalesApi.ExperienceLayer.Studio;

/// <summary>Pass-through to <see cref="StudioProcess"/> — the controller-
/// facing shape for E7.4's studio endpoints. No orchestration across
/// verticals lives here yet, same reasoning as <c>SandboxExperience</c>'s
/// own doc comment (owner decision, 2026-08-28).</summary>
public sealed class StudioExperience
{
    private readonly StudioProcess _studio;
    public StudioExperience(StudioProcess studio) => _studio = studio;

    public Task<(StudioAssignmentDto? Result, StudioProcess.Refusal? Refusal)> GrantAsync(
        Guid implementationUserId, Guid orgId, Guid grantedById, CancellationToken ct = default) =>
        _studio.GrantAsync(implementationUserId, orgId, grantedById, ct);

    public Task<(bool Revoked, StudioProcess.Refusal? Refusal)> RevokeAsync(
        Guid assignmentId, Guid revokedById, CancellationToken ct = default) =>
        _studio.RevokeAsync(assignmentId, revokedById, ct);

    public Task<List<StudioAssignedOrgDto>> AssignedOrgsAsync(Guid implementationUserId, CancellationToken ct = default) =>
        _studio.AssignedOrgsAsync(implementationUserId, ct);

    // --- Follow-up (owner 2026-10-04): the platform admin's own grants screen ---

    public Task<StudioAssignmentsDto> ListAssignmentsAsync(CancellationToken ct = default) =>
        _studio.ListAssignmentsAsync(ct);

    public Task<StudioImplementationUsersDto> ListImplementationUsersAsync(Guid callerHomeOrgId, CancellationToken ct = default) =>
        _studio.ListImplementationUsersAsync(callerHomeOrgId, ct);

    public Task<(StudioImplementationUserDto? Result, StudioProcess.Refusal? Refusal)> SetImplementationUserFlagAsync(
        Guid profileId, bool isImplementationUser, Guid callerHomeOrgId, Guid actorId, CancellationToken ct = default) =>
        _studio.SetImplementationUserFlagAsync(profileId, isImplementationUser, callerHomeOrgId, actorId, ct);

    public Task<(StudioSwitchResultDto? Result, StudioProcess.Refusal? Refusal)> SwitchToOrgAsync(
        Guid callerId, Guid targetOrgId, CancellationToken ct = default) =>
        _studio.SwitchToOrgAsync(callerId, targetOrgId, ct);

    public Task<(StudioSwitchResultDto? Result, StudioProcess.Refusal? Refusal)> SwitchToOwnSandboxAsync(
        Guid callerId, CancellationToken ct = default) =>
        _studio.SwitchToOwnSandboxAsync(callerId, ct);

    public Task<(StudioSwitchResultDto? Result, StudioProcess.Refusal? Refusal)> SwitchHomeAsync(
        Guid callerId, CancellationToken ct = default) =>
        _studio.SwitchHomeAsync(callerId, ct);

    // --- Preview as role (slice 19, design doc §5.6) -------------------------

    public Task<(List<StudioPreviewCapabilityDto>? Result, StudioProcess.Refusal? Refusal)> CapabilitiesAsync(
        Guid orgId, string roleKey, CancellationToken ct = default) =>
        _studio.CapabilitiesAsync(orgId, roleKey, ct);

    public Task<(StudioSwitchResultDto? Result, StudioProcess.Refusal? Refusal)> StartPreviewAsync(
        Guid callerId, Guid actingOrgId, Guid? studioHomeOrgId, string? studioKind, string roleKey, DateTime? studioExp = null, CancellationToken ct = default) =>
        _studio.StartPreviewAsync(callerId, actingOrgId, studioHomeOrgId, studioKind, roleKey, studioExp, ct);

    public Task<(StudioSwitchResultDto? Result, StudioProcess.Refusal? Refusal)> ExitPreviewAsync(
        Guid callerId, Guid actingOrgId, Guid? studioHomeOrgId, string? studioKind, DateTime? studioExp = null, CancellationToken ct = default) =>
        _studio.ExitPreviewAsync(callerId, actingOrgId, studioHomeOrgId, studioKind, studioExp, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.ProcessLayer.Portal;

namespace SalesApi.ExperienceLayer.Portal;

/// <summary>What the portal apps need that is true of every portal kind (E19.1). Thin: the Process layer already returns the portal DTOs. See <see cref="PortalProcess"/>.</summary>
public sealed class PortalExperience
{
    private readonly PortalProcess _portal;
    public PortalExperience(PortalProcess portal) => _portal = portal;

    public Task<CpResult<PortalMeDto>> MeAsync(PortalScope scope, CancellationToken ct = default) => _portal.MeAsync(scope, ct);
}

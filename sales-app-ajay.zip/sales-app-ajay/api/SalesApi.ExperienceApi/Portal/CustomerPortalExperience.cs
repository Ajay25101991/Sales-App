using SalesApi.Dtos;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.ProcessLayer.Portal;

namespace SalesApi.ExperienceLayer.Portal;

/// <summary>What the customer portal app needs (E19.3). Thin: the Process layer already returns the portal DTOs, shaped for the customer and nothing else. See <see cref="CustomerPortalProcess"/>.</summary>
public sealed class CustomerPortalExperience
{
    private readonly CustomerPortalProcess _customer;
    public CustomerPortalExperience(CustomerPortalProcess customer) => _customer = customer;

    public Task<CpResult<List<CustomerPortalInvoiceDto>>> InvoicesAsync(PortalScope scope, string? status, CancellationToken ct = default) => _customer.InvoicesAsync(scope, status, ct);
    public Task<CpResult<CustomerPortalProcess.Pdf>> InvoicePdfAsync(PortalScope scope, Guid invoiceId, CancellationToken ct = default) => _customer.InvoicePdfAsync(scope, invoiceId, ct);
    public Task<CpResult<List<CustomerPortalReceiptDto>>> ReceiptsAsync(PortalScope scope, Guid invoiceId, CancellationToken ct = default) => _customer.ReceiptsAsync(scope, invoiceId, ct);
    public Task<CpResult<CustomerPortalProcess.Pdf>> ReceiptPdfAsync(PortalScope scope, Guid collectionTaskId, CancellationToken ct = default) => _customer.ReceiptPdfAsync(scope, collectionTaskId, ct);
    public Task<CpResult<CustomerPortalPayDto>> PayAsync(PortalScope scope, Guid invoiceId, CancellationToken ct = default) => _customer.PayAsync(scope, invoiceId, ct);
    public Task<CpResult<List<CustomerPortalKycDto>>> KycAsync(PortalScope scope, CancellationToken ct = default) => _customer.KycAsync(scope, ct);

    public Task<CpResult<CustomerPortalKycUploadedDto>> UploadKycFileAsync(
        PortalScope scope, Guid accountId, string? documentType, string? fileName, string? contentType, long length, Stream content, CancellationToken ct = default) =>
        _customer.UploadKycFileAsync(scope, accountId, documentType, fileName, contentType, length, content, ct);

    public Task<CpResult<List<CustomerPortalRequestDto>>> RequestsAsync(PortalScope scope, CancellationToken ct = default) => _customer.RequestsAsync(scope, ct);
}

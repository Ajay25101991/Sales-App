using SalesApi.Dtos;
using SalesApi.ProcessLayer.Plans;

namespace SalesApi.ExperienceLayer.Plans;

/// <summary>
/// What the platform-admin "Plans" screen and the org-admin "Plan & usage"
/// screen need. FORWARDS — same shape every migrated domain's Experience
/// takes, per <see cref="SalesApi.ExperienceLayer.AiPlatform.AiCostPolicyExperience"/>.
/// </summary>
public sealed class PlansExperience
{
    private readonly PlanProcess _plans;
    public PlansExperience(PlanProcess plans) => _plans = plans;

    public Task<List<PlanDto>> ListAsync(bool includeArchived, CancellationToken ct = default) =>
        _plans.ListAsync(includeArchived, ct);

    public Task<(PlanDto? Dto, PlanProcess.Refusal? Refusal)> CreateAsync(EntitlementPlanInput input, CancellationToken ct = default) =>
        _plans.CreateAsync(input, ct);

    public Task<(PlanDto? Dto, PlanProcess.Refusal? Refusal)> UpdateAsync(Guid id, EntitlementPlanInput input, CancellationToken ct = default) =>
        _plans.UpdateAsync(id, input, ct);

    public Task<(OrgPlanAssignmentDto? Result, PlanProcess.Refusal? Refusal)> SetOrgPlanAsync(
        Guid orgId, Guid planId, Guid actorId, CancellationToken ct = default) =>
        _plans.SetOrgPlanAsync(orgId, planId, actorId, ct);

    public Task<OrgPlanStatusDto> OrgStatusAsync(CancellationToken ct = default) => _plans.OrgStatusAsync(ct);
}

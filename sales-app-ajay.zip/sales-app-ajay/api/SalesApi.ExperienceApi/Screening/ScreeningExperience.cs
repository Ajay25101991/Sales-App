using SalesApi.Dtos;
using SalesApi.ProcessLayer.Screening;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Screening;

/// <summary>
/// What the screening panel (on an account and on a contact), the review queue and the decision form need. It FORWARDS - every method calls straight
/// through to <see cref="ScreeningProcess"/> with no reshaping, like <c>DocumentRegisterExperience</c>: the screens want exactly what Process computes today,
/// and the first second consumer that wants something different adds the difference here.
/// </summary>
public sealed class ScreeningExperience
{
    private readonly ScreeningProcess _screening;
    public ScreeningExperience(ScreeningProcess screening) => _screening = screening;

    public Task<ScreeningProcess.ListOutcome> ListAsync(RecordAccessContext ctx, Guid? accountId, Guid? contactId, CancellationToken ct = default) =>
        _screening.ListAsync(ctx, accountId, contactId, ct);

    public Task<ScreeningProcess.SubjectsOutcome> SubjectsAsync(RecordAccessContext ctx, Guid? accountId, CancellationToken ct = default) =>
        _screening.SubjectsAsync(ctx, accountId, ct);

    public Task<ScreeningProcess.ListOutcome> QueueAsync(RecordAccessContext ctx, CancellationToken ct = default) => _screening.QueueAsync(ctx, ct);

    public Task<ScreeningProcess.OneOutcome> RecordAsync(RecordAccessContext ctx, Guid userId, ScreeningRecordInput input, CancellationToken ct = default) =>
        _screening.RecordAsync(ctx, userId, input, ct);

    public Task<ScreeningProcess.OneOutcome> DecideAsync(RecordAccessContext ctx, Guid userId, Guid id, ScreeningDecisionInput input, CancellationToken ct = default) =>
        _screening.DecideAsync(ctx, userId, id, input, ct);

    public Task<ScreeningProcess.OneOutcome> AddEvidenceAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, Guid userId, Guid? orgId, Guid id,
        string? fileName, string? contentType, long length, Stream? content, CancellationToken ct = default) =>
        _screening.AddEvidenceAsync(ctx, perms, userId, orgId, id, fileName, contentType, length, content, ct);

    public Task<ScreeningSettingsDto> GetSettingsAsync(CancellationToken ct = default) => _screening.GetSettingsAsync(ct);

    public Task<ScreeningProcess.SettingsOutcome> SaveSettingsAsync(ScreeningSettingsInput input, CancellationToken ct = default) =>
        _screening.SaveSettingsAsync(input, ct);
}

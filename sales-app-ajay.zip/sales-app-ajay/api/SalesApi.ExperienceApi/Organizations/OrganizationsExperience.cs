using SalesApi.Dtos;
using SalesApi.ProcessLayer.Organizations;

namespace SalesApi.ExperienceLayer.Organizations;

/// <summary>
/// The organization settings screen. Forwards Process today — one consumer
/// (the org's own admin settings page), one shape.
/// </summary>
public sealed class OrganizationsExperience
{
    private readonly OrganizationProcess _process;
    public OrganizationsExperience(OrganizationProcess process) => _process = process;

    public Task<List<OrganizationDto>> MineAsync(Guid orgId, CancellationToken ct = default) =>
        _process.MineAsync(orgId, ct);

    public Task<(OrganizationDto? Org, OrganizationProcess.Refusal? Refusal)> UpdateAsync(
        Guid orgId, string? name, string? currency, CancellationToken ct = default) =>
        _process.UpdateAsync(orgId, name, currency, ct);

    public Task<OffboardingBackupArtifactDto?> CreateBackupAsync(Guid orgId, Guid requestedBy, CancellationToken ct = default) =>
        _process.CreateBackupAsync(orgId, requestedBy, ct);

    public Task<(OrganizationOffboardResultDto? Result, OrganizationProcess.Refusal? Refusal)> OffboardAsync(
        Guid orgId, string? confirmation, string? backupReceipt, Guid requestedBy, CancellationToken ct = default) =>
        _process.OffboardAsync(orgId, confirmation, backupReceipt, requestedBy, ct);
}

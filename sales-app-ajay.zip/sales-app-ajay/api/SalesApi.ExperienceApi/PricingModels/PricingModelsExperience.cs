using SalesApi.Dtos;
using SalesApi.ProcessLayer.PricingModels;

namespace SalesApi.ExperienceLayer.PricingModels;

/// <summary>
/// What the service editor's pricing-model panel needs (E10.3), and — later — what the proposal generator
/// calls to price a service (<see cref="EvaluateVersionAsync"/>).
///
/// Pure forwarding today: the shapes the editor wants are exactly what <see cref="PricingModelProcess"/>
/// returns. It exists so the next consumer that wants something different (the generator joining several
/// services' evaluations into one summary) lands here without touching Process.
/// </summary>
public sealed class PricingModelsExperience
{
    private readonly PricingModelProcess _models;
    public PricingModelsExperience(PricingModelProcess models) => _models = models;

    public Task<PricingModelProcess.Result<PricingModelDto>> GetAsync(Guid catalogItemId, CancellationToken ct = default) =>
        _models.GetAsync(catalogItemId, ct);

    public Task<PricingModelProcess.Result<PricingModelSavedDto>> SaveDraftAsync(
        Guid catalogItemId, PricingModelDraftInput input, Guid? userId, CancellationToken ct = default) =>
        _models.SaveDraftAsync(catalogItemId, input, userId, ct);

    public Task<PricingModelProcess.Result<PricingValidationDto>> ValidateAsync(
        Guid catalogItemId, PricingModelDraftInput? body, bool forPublish, CancellationToken ct = default) =>
        _models.ValidateAsync(catalogItemId, body, forPublish, ct);

    public Task<PricingModelProcess.Result<PricingEvaluationDto>> PreviewAsync(
        Guid catalogItemId, PricingPreviewInput input, SalesApi.Services.RecordAccessContext? access, CancellationToken ct = default) =>
        _models.PreviewAsync(catalogItemId, input, access, ct);

    public Task<PricingModelProcess.Result<PricingFieldsDto>> FieldsAsync(
        Guid catalogItemId, string? beforeResultKey, bool publishedOnly = false, CancellationToken ct = default) =>
        _models.FieldsAsync(catalogItemId, beforeResultKey, publishedOnly, ct);

    public Task<List<PricingResultKeyDto>> ResultKeysAsync(CancellationToken ct = default) => _models.ResultKeysAsync(ct);

    public Task<PricingModelProcess.Result<PricingModelVersionDto>> GetLatestVersionAsync(Guid catalogItemId, CancellationToken ct = default) =>
        _models.GetLatestVersionAsync(catalogItemId, ct);

    public Task<PricingModelProcess.Result<PricingModelVersionDto>> PublishAsync(
        Guid catalogItemId, Guid? userId, CancellationToken ct = default) =>
        _models.PublishAsync(catalogItemId, userId, ct);

    public Task<PricingModelProcess.Result<List<PricingModelVersionSummaryDto>>> ListVersionsAsync(
        Guid catalogItemId, CancellationToken ct = default) =>
        _models.ListVersionsAsync(catalogItemId, ct);

    public Task<PricingModelProcess.Result<PricingModelVersionDto>> GetVersionAsync(
        Guid catalogItemId, int version, CancellationToken ct = default) =>
        _models.GetVersionAsync(catalogItemId, version, ct);

    public Task<PricingModelProcess.Result<PricingModelDto>> RestoreVersionAsync(
        Guid catalogItemId, int version, bool replaceDraft, Guid? userId, CancellationToken ct = default) =>
        _models.RestoreVersionAsync(catalogItemId, version, replaceDraft, userId, ct);

    public Task<PricingModelProcess.Result<PricingEvaluationDto>> EvaluateVersionAsync(
        Guid catalogItemId, int version, PricingEvaluateInput input, SalesApi.Services.RecordAccessContext? access, CancellationToken ct = default) =>
        _models.EvaluateVersionAsync(catalogItemId, version, input, access, ct);
}

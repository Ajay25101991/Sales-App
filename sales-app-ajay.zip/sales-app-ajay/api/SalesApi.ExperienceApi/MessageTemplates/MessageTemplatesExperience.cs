using SalesApi.Dtos;
using SalesApi.ProcessLayer.MessageTemplates;

namespace SalesApi.ExperienceLayer.MessageTemplates;

/// <summary>
/// What the message-templates screens need. FORWARDS — same shape as ten of
/// eleven domains migrated before it. Built anyway, per the owner's
/// 2026-08-28 decision to add Experience uniformly rather than carry a
/// growing list of exceptions.
/// </summary>
public sealed class MessageTemplatesExperience
{
    private readonly MessageTemplateProcess _templates;
    public MessageTemplatesExperience(MessageTemplateProcess templates) => _templates = templates;

    public Task<List<MessageTemplateDto>> ListAsync(CancellationToken ct = default) =>
        _templates.ListAsync(ct);

    public Task<MessageTemplateProcess.TemplateOutcome> CreateAsync(
        MessageTemplateInput input, CancellationToken ct = default) =>
        _templates.CreateAsync(input, ct);

    public Task<MessageTemplateProcess.TemplateOutcome> UpdateAsync(
        Guid id, MessageTemplateInput input, CancellationToken ct = default) =>
        _templates.UpdateAsync(id, input, ct);

    public Task<MessageTemplateProcess.DeleteOutcome> DeleteAsync(Guid id, CancellationToken ct = default) =>
        _templates.DeleteAsync(id, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Search;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Search;

/// <summary>What the desktop ⌘K palette needs. A thin forward today — see
/// Goals.GoalsExperience for why that is still worth having even with one
/// caller.</summary>
public sealed class SearchExperience
{
    private readonly SearchProcess _search;
    public SearchExperience(SearchProcess search) => _search = search;

    public Task<SearchResultsDto> SearchAsync(
        RecordAccessContext ctx, string? q, IReadOnlyCollection<string>? types, bool canSeeContactDetails,
        CancellationToken ct = default) =>
        _search.SearchAsync(ctx, q, types, canSeeContactDetails, ct);
}

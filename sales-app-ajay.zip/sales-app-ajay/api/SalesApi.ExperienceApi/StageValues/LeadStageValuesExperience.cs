using SalesApi.Dtos;
using SalesApi.ProcessLayer.StageValues;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.StageValues;

/// <summary>FORWARDS - the deal page's stage-value table wants exactly what <see cref="LeadStageValueProcess"/> computes (owner 2026-11-12).</summary>
public sealed class LeadStageValuesExperience
{
    private readonly LeadStageValueProcess _values;
    public LeadStageValuesExperience(LeadStageValueProcess values) => _values = values;

    public Task<LeadStageValueProcess.Outcome> GetAsync(RecordAccessContext ctx, LeadView view, Guid leadId, CancellationToken ct = default) =>
        _values.GetAsync(ctx, view, leadId, ct);

    public Task<LeadStageValueProcess.Outcome> PutAsync(
        RecordAccessContext ctx, LeadView view, Guid actorId, Guid leadId, string kind, StageValueSetInput input, DateTime now, CancellationToken ct = default) =>
        _values.PutAsync(ctx, view, actorId, leadId, kind, input, now, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Attachments;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Attachments;

/// <summary>
/// The Files panel on every record type (lead, account, quote, invoice, AMC): list, upload, download, delete, plus the two
/// org-wide settings (storage provider, business-card retention) the same
/// screen surfaces. Forwards throughout — the screen wants exactly what
/// Process computes, same as most first-pass Experience classes in this
/// migration.
/// </summary>
public sealed class AttachmentsExperience
{
    private readonly AttachmentProcess _process;
    public AttachmentsExperience(AttachmentProcess process) => _process = process;

    public static (string Type, Guid Id, AttachmentProcess.Refusal? Refusal) Target(Guid legacyLeadId, string? recordType, Guid? recordId) =>
        AttachmentProcess.NormaliseTarget(legacyLeadId, recordType, recordId);

    public Task<(AttachmentProcess.Refusal? Refusal, List<AttachmentDto>? Files)> ListAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, string type, Guid id, CancellationToken ct = default, bool includeQuotes = false) =>
        _process.ListAsync(ctx, perms, type, id, ct, includeQuotes);

    public Task<AttachmentProcess.UploadResult> UploadAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, string type, Guid id, Guid uploaderId, Guid? orgId,
        string filename, string? contentType, long length, Stream content, string? tag,
        CancellationToken ct = default) =>
        _process.UploadAsync(ctx, perms, type, id, uploaderId, orgId, filename, contentType, length, content, tag, ct);

    public Task<AttachmentProcess.LinkResult> LinkAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, AttachmentLinkInput input, Guid callerId, CancellationToken ct = default) =>
        _process.LinkAsync(ctx, perms, input.RecordType, input.RecordId,
            input.Items?.Select(i => (i.DriveId, i.ItemId)).ToList(), callerId, ct);

    public Task<AttachmentProcess.DownloadResult> DownloadAsync(RecordAccessContext ctx, AttachmentPermissions perms, Guid attachmentId, CancellationToken ct = default) =>
        _process.DownloadAsync(ctx, perms, attachmentId, ct);

    public Task<AttachmentProcess.Refusal?> DeleteAsync(RecordAccessContext ctx, AttachmentPermissions perms, Guid attachmentId, Guid callerId, CancellationToken ct = default) =>
        _process.DeleteAsync(ctx, perms, attachmentId, callerId, ct);

    public Task<(AttachmentProcess.Refusal? Refusal, AttachmentDto? File)> LinkGateAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, Guid attachmentId, AttachmentGateLinkInput input, Guid callerId, CancellationToken ct = default) =>
        _process.LinkGateAsync(ctx, perms, attachmentId, input.Stage, input.RequirementKey, callerId, ct);

    public Task<AttachmentProcess.Refusal?> UnlinkGateAsync(
        RecordAccessContext ctx, AttachmentPermissions perms, Guid attachmentId, string? stage, string? requirementKey, CancellationToken ct = default) =>
        _process.UnlinkGateAsync(ctx, perms, attachmentId, stage, requirementKey, ct);

    public IReadOnlyList<string> AvailableStorageProviders => _process.AvailableStorageProviders;

    public Task<AttachmentStorageProviderDto> CurrentStorageProviderAsync(Guid? orgId, CancellationToken ct = default) =>
        _process.CurrentStorageProviderAsync(orgId, ct);

    public Task<AttachmentProcess.SetStorageProviderResult> SetStorageProviderAsync(Guid? orgId, string? provider, CancellationToken ct = default) =>
        _process.SetStorageProviderAsync(orgId, provider, ct);

    public Task<CardScanRetentionDto> GetCardScanRetentionAsync(CancellationToken ct = default) =>
        _process.GetCardScanRetentionAsync(ct);

    public Task<CardScanRetentionDto> SetCardScanRetentionAsync(string? mode, int? retentionDays, CancellationToken ct = default) =>
        _process.SetCardScanRetentionAsync(mode, retentionDays, ct);

    public Task<DeletedRecordRetentionDto> GetDeletedRecordRetentionAsync(CancellationToken ct = default) =>
        _process.GetDeletedRecordRetentionAsync(ct);

    public Task<DeletedRecordRetentionDto> SetDeletedRecordRetentionAsync(string? mode, int? retentionDays, CancellationToken ct = default) =>
        _process.SetDeletedRecordRetentionAsync(mode, retentionDays, ct);
}

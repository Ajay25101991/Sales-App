using SalesApi.Dtos;
using SalesApi.ProcessLayer.ChangeRequests;

namespace SalesApi.ExperienceLayer.ChangeRequests;

/// <summary>Pass-through to <see cref="ChangeRequestProcess"/> — the
/// controller-facing shape for E7.4's change-request endpoints. No
/// orchestration across verticals lives here (same reasoning as
/// <c>SandboxExperience</c>'s own comment) — the seam exists for
/// consistency with every other Experience class (owner decision,
/// 2026-08-28).</summary>
public sealed class ChangeRequestsExperience
{
    private readonly ChangeRequestProcess _changeRequests;
    public ChangeRequestsExperience(ChangeRequestProcess changeRequests) => _changeRequests = changeRequests;

    public Task<List<ChangeRequestDto>> ListAsync(CancellationToken ct = default) => _changeRequests.ListAsync(ct);

    public Task<(ChangeRequestProcess.Refusal? Refusal, ChangeRequestDetailDto? Dto)> DetailAsync(Guid id, CancellationToken ct = default) =>
        _changeRequests.DetailAsync(id, ct);

    public Task<ChangeRequestDto> CreateAsync(Guid orgId, Guid actorId, string title, string description, CancellationToken ct = default) =>
        _changeRequests.CreateAsync(orgId, actorId, title, description, ct);

    public Task<(ChangeRequestProcess.Refusal? Refusal, ChangeRequestCommentDto? Dto)> CommentAsync(
        Guid id, Guid actorId, string body, CancellationToken ct = default) =>
        _changeRequests.CommentAsync(id, actorId, body, ct);

    public Task<(ChangeRequestProcess.Refusal? Refusal, ChangeRequestDto? Dto, string? RawApprovalToken)> LinkItemsAsync(
        Guid id, List<ChangeRequestItemSelectionDto> items, List<ChangeRequestRemovalSelectionDto> removals, CancellationToken ct = default) =>
        _changeRequests.LinkItemsAsync(id, items, removals, ct);

    public Task<(ChangeRequestProcess.Refusal? Refusal, ChangeRequestDto? Dto)> DecideAsync(
        Guid id, Guid actorId, bool approve, CancellationToken ct = default) =>
        _changeRequests.DecideAsync(id, actorId, approve, ct);

    public Task<(ChangeRequestProcess.Refusal? Refusal, PackageApplyResultDto? Result)> PromoteAsync(
        Guid orgId, Guid actorId, Guid id, CancellationToken ct = default) =>
        _changeRequests.PromoteAsync(orgId, actorId, id, ct);

    // --- Public token path -------------------------------------------------

    public Task<ChangeRequestProcess.PublicView> ViewByTokenAsync(string? rawToken, CancellationToken ct = default) =>
        _changeRequests.ViewByTokenAsync(rawToken, ct);

    public Task<ChangeRequestProcess.PublicDecisionResult> DecideByTokenAsync(string? rawToken, bool approve, CancellationToken ct = default) =>
        _changeRequests.DecideByTokenAsync(rawToken, approve, ct);
}

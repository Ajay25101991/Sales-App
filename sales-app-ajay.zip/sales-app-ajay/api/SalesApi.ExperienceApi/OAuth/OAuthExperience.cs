using SalesApi.Dtos;
using SalesApi.ProcessLayer.OAuth;

namespace SalesApi.ExperienceLayer.OAuth;

/// <summary>
/// What the OAuth endpoints, the consent page and the "connected AI tools" lists need - exactly what <see cref="OAuthProcess"/> computes. Every method
/// forwards; the wire shapes are already the RFC ones (or the consent page's own), so there is nothing to reshape yet. Same seam AuthExperience keeps.
/// </summary>
public sealed class OAuthExperience
{
    private readonly OAuthProcess _oauth;
    public OAuthExperience(OAuthProcess oauth) => _oauth = oauth;

    public OAuthProtectedResourceMetadata ProtectedResource(string resource, string issuer) => _oauth.ProtectedResource(resource, issuer);

    public OAuthServerMetadata ServerMetadata(string issuer, string authorizeUrl, string tokenUrl, string registerUrl) =>
        _oauth.ServerMetadata(issuer, authorizeUrl, tokenUrl, registerUrl);

    public Task<(OAuthProcess.Refusal? Refusal, OAuthRegisterResponse? Response)> RegisterAsync(OAuthRegisterRequest req) => _oauth.RegisterAsync(req);

    public Task<OAuthAuthorizeOutcome> AuthorizeAsync(OAuthAuthorizeQuery query, string resource) => _oauth.AuthorizeAsync(query, resource);

    public Task<OAuthConsentRequest?> GetConsentAsync(Guid requestId, bool canConnect, string? reason) => _oauth.GetConsentAsync(requestId, canConnect, reason);

    public Task<(OAuthProcess.Refusal? Refusal, OAuthRedirect? Redirect)> DecideAsync(
        Guid requestId, bool approve, bool canConnect, string? reason, Guid userId, Guid? orgId) =>
        _oauth.DecideAsync(requestId, approve, canConnect, reason, userId, orgId);

    public Task<(OAuthTokenError? Error, OAuthTokenResponse? Response)> TokenAsync(IReadOnlyDictionary<string, string> form, string resource) =>
        _oauth.TokenAsync(form, resource);

    public Task<List<AiConnectionDto>> ListMineAsync(Guid userId) => _oauth.ListMineAsync(userId);
    public Task<List<AiConnectionDto>> ListForOrgAsync(Guid orgId, Guid? userId) => _oauth.ListForOrgAsync(orgId, userId);
    public Task<bool> DisconnectMineAsync(Guid id, Guid userId) => _oauth.DisconnectMineAsync(id, userId);
    public Task<bool> DisconnectInOrgAsync(Guid id, Guid orgId) => _oauth.DisconnectInOrgAsync(id, orgId);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Reports;

namespace SalesApi.ExperienceLayer.ReportSchedules;

/// <summary>
/// Forwards to <see cref="ReportScheduleProcess"/>. Owner-only CRUD — see that
/// class's own doc — so every method takes the CALLER's own id as the owner;
/// there is no path here for "someone else's schedules".
/// </summary>
public sealed class ReportSchedulesExperience
{
    private readonly ReportScheduleProcess _process;
    public ReportSchedulesExperience(ReportScheduleProcess process) => _process = process;

    public Task<List<ReportScheduleDto>> ListAsync(Guid ownerId, CancellationToken ct = default) =>
        _process.ListAsync(ownerId, ct);

    public Task<(ReportScheduleProcess.Refusal? Refusal, ReportScheduleDto? Dto)> CreateAsync(
        Guid ownerId, ReportScheduleInput input, CancellationToken ct = default) =>
        _process.CreateAsync(ownerId, input, ct);

    public Task<(ReportScheduleProcess.Refusal? Refusal, ReportScheduleDto? Dto)> UpdateAsync(
        Guid ownerId, Guid id, ReportScheduleInput input, CancellationToken ct = default) =>
        _process.UpdateAsync(ownerId, id, input, ct);

    public Task<ReportScheduleProcess.Refusal?> DeleteAsync(Guid ownerId, Guid id, CancellationToken ct = default) =>
        _process.DeleteAsync(ownerId, id, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Invoices;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Invoices;

/// <summary>
/// What the invoice/collections screens need.
///
/// Built for uniformity per the owner's 2026-08-28 decision (every domain gets
/// an Experience class), not because these screens want a different shape than
/// Process computes — they do not. Every method here forwards; say so plainly
/// rather than dressing a pass-through up as a reshape. The seam is the
/// purchase: the moment a second consumer (a phone wanting a lighter invoice
/// list, a customer-facing statement page) wants something different, the
/// difference lands here and Process — the highest-money domain migrated so
/// far — stays untouched.
/// </summary>
public sealed class InvoicesExperience
{
    private readonly InvoiceProcess _invoices;
    public InvoicesExperience(InvoiceProcess invoices) => _invoices = invoices;

    public Task<List<InvoiceDto>> ListAsync(
        RecordAccessContext ctx, string? status, bool? overdue, string? search, Guid? accountId, Guid? leadId, bool? brokenPromise,
        bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.ListAsync(ctx, status, overdue, search, accountId, leadId, brokenPromise, canSeeFinancials, ct);

    public Task<DiscountResidualListDto> DiscountResidualsAsync(RecordAccessContext ctx, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.DiscountResidualsAsync(ctx, canSeeFinancials, ct);

    public Task<InvoiceProcess.InvoiceOutcome> SettleResidualAsync(RecordAccessContext ctx, Guid id, Guid actorId, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.SettleResidualAsync(ctx, id, actorId, canSeeFinancials, ct);

    public Task<InvoiceProcess.InvoiceOutcome> DismissResidualAsync(RecordAccessContext ctx, Guid id, Guid actorId, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.DismissResidualAsync(ctx, id, actorId, canSeeFinancials, ct);

    public Task<List<BillableLeadDto>> BillableLeadsAsync(RecordAccessContext ctx, CancellationToken ct = default) =>
        _invoices.BillableLeadsAsync(ctx, ct);

    public Task<InvoiceProcess.InvoiceDetailOutcome> GetAsync(RecordAccessContext ctx, Guid id, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.GetAsync(ctx, id, canSeeFinancials, ct);

    public Task<InvoiceProcess.PdfOutcome> PdfAsync(RecordAccessContext ctx, Guid id, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.PdfAsync(ctx, id, canSeeFinancials, ct);

    public Task<InvoiceProcess.InvoiceOutcome> CreateAsync(RecordAccessContext ctx, InvoiceInput input, Guid actorId, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.CreateAsync(ctx, input, actorId, canSeeFinancials, ct);

    public Task<InvoiceProcess.InvoiceOutcome> RaiseAsync(RecordAccessContext ctx, Guid id, Guid actorId, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.RaiseAsync(ctx, id, actorId, canSeeFinancials, ct);

    public Task<InvoiceProcess.InvoiceOutcome> RecordExternalAsync(RecordAccessContext ctx, Guid id, RecordExternalInvoiceInput input, Guid actorId, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.RecordExternalAsync(ctx, id, input, actorId, canSeeFinancials, ct);

    public Task<InvoiceProcess.InvoiceOutcome> UpdateAsync(RecordAccessContext ctx, Guid id, InvoiceInput input, Guid actorId, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.UpdateAsync(ctx, id, input, actorId, canSeeFinancials, ct);

    public Task<InvoiceProcess.InvoiceOutcome> RecordPaymentAsync(RecordAccessContext ctx, Guid id, PaymentInput input, Guid actorId, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.RecordPaymentAsync(ctx, id, input, actorId, canSeeFinancials, ct);

    public Task<(InvoiceProcess.Refusal? Refusal, DealBillingFlagDto? Flag)> BillingFlagAsync(RecordAccessContext ctx, Guid leadId, CancellationToken ct = default) =>
        _invoices.BillingFlagAsync(ctx, leadId, ct);

    public Task<AccountCreditListDto> CreditsAsync(RecordAccessContext ctx, Guid? accountId, Guid? leadId, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.CreditsAsync(ctx, accountId, leadId, canSeeFinancials, ct);

    public Task<InvoiceProcess.CreditOutcome> ApplyCreditAsync(RecordAccessContext ctx, Guid creditId, ApplyCreditInput input, Guid actorId, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.ApplyCreditAsync(ctx, creditId, input, actorId, canSeeFinancials, ct);

    public Task<InvoiceProcess.CreditOutcome> RefundCreditAsync(RecordAccessContext ctx, Guid creditId, RefundCreditInput input, Guid actorId, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.RefundCreditAsync(ctx, creditId, input, actorId, canSeeFinancials, ct);

    public Task<InvoiceProcess.PlanOutcome> SetPlanAsync(RecordAccessContext ctx, Guid id, PlanInput input, Guid actorId, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _invoices.SetPlanAsync(ctx, id, input, actorId, canSeeFinancials, ct);

    public Task<InvoiceProcess.PlanClearOutcome> ClearPlanAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _invoices.ClearPlanAsync(ctx, id, ct);

    public Task<(InvoiceProcess.Refusal? Refusal, List<InvoiceActivityDto>? Activities)> ActivitiesAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _invoices.ActivitiesAsync(ctx, id, ct);

    public Task<InvoiceProcess.ActivityOutcome> AddActivityAsync(RecordAccessContext ctx, Guid id, InvoiceActivityInput input, Guid actorId, CancellationToken ct = default) =>
        _invoices.AddActivityAsync(ctx, id, input, actorId, ct);

    public Task<InvoiceProcess.DeleteOutcome> DeleteAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _invoices.DeleteAsync(ctx, id, ct);
}

using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.ProcessLayer.Playbooks;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Playbooks;

/// <summary>
/// What the playbook screens (library, builder, picker, assignment editor)
/// need, shaped for them.
///
/// A PASS-THROUGH today, and it says so rather than dressing itself up: every
/// endpoint here returns exactly what <see cref="PlaybookProcess"/> already
/// computes — same finding as six of the six domains migrated before this one
/// (goals, tags, custom fields, collections, quotes, loyalty). It exists
/// because the owner chose uniformity: every domain gets an Experience class,
/// so the seam is already there the day a consumer wants something the
/// library screen and the builder screen would disagree about — a phone
/// wanting the picker's id/name pair without the library's version metadata
/// is already served by <see cref="LiveAsync"/> being a different shape from
/// <see cref="ListAsync"/>, which is the one place this vertical already
/// diverges by consumer rather than by accident.
///
/// THIS FILE CANNOT SEE THE DATABASE — `SalesApi.ExperienceApi` disables
/// transitive project references, so `AppDbContext`, `Playbook`,
/// `PlaybookVersion` are all invisible here, checked by the compiler rather
/// than by convention.
/// </summary>
public sealed class PlaybooksExperience
{
    private readonly PlaybookProcess _playbooks;
    public PlaybooksExperience(PlaybookProcess playbooks) => _playbooks = playbooks;

    public Task<List<PlaybookSummaryDto>> ListAsync(
        bool isOrgAdmin, TeamScope scope, bool includeArchived = false, CancellationToken ct = default) =>
        _playbooks.ListAsync(isOrgAdmin, scope, includeArchived, ct);

    public Task<List<PlaybookLiteDto>> LiveAsync(bool isOrgAdmin, TeamScope scope, CancellationToken ct = default) =>
        _playbooks.LiveAsync(isOrgAdmin, scope, ct);

    public Task<PlaybookDetailDto?> GetAsync(Guid id, bool isOrgAdmin, TeamScope scope, CancellationToken ct = default) =>
        _playbooks.GetAsync(id, isOrgAdmin, scope, ct);

    public Task<List<PlaybookVersionDto>?> VersionsAsync(
        Guid id, bool isOrgAdmin, TeamScope scope, CancellationToken ct = default) =>
        _playbooks.VersionsAsync(id, isOrgAdmin, scope, ct);

    public Task<(PlaybookRestoreResultDto? Result, PlaybookProcess.Refusal? Refusal)> RestoreVersionAsync(
        Guid id, bool isOrgAdmin, TeamScope scope, int version, bool replaceDraft, Guid userId, CancellationToken ct = default) =>
        _playbooks.RestoreVersionAsync(id, isOrgAdmin, scope, version, replaceDraft, userId, ct);

    public Task<(PlaybookSummaryDto? Created, PlaybookProcess.Refusal? Refusal)> CreateAsync(
        string? name, string? description, string? key, Guid userId, CancellationToken ct = default) =>
        _playbooks.CreateAsync(name, description, key, userId, ct);

    public Task<(PlaybookSummaryDto? Created, PlaybookProcess.Refusal? Refusal)> CreateAsync(
        string? name, string? description, Guid userId, CancellationToken ct = default) =>
        _playbooks.CreateAsync(name, description, userId, ct);

    public Task<(PlaybookMatchingResultDto? Result, PlaybookProcess.Refusal? Refusal)> SetMatchingAsync(
        Guid id, bool isOrgAdmin, TeamScope scope, int? priority, JsonElement? matchCondition, CancellationToken ct = default) =>
        _playbooks.SetMatchingAsync(id, isOrgAdmin, scope, priority, matchCondition, ct);

    public Task<UnmatchedLeadsResultDto> UnmatchedLeadsAsync(CancellationToken ct = default) =>
        _playbooks.UnmatchedLeadsAsync(ct);

    public Task<(PlaybookDraftResultDto? Result, PlaybookProcess.Refusal? Refusal)> SaveDraftAsync(
        Guid id, bool isOrgAdmin, TeamScope scope, List<StageDefDto>? stages, Guid userId, CancellationToken ct = default,
        PlaybookPostWinDto? postWin = null, List<string>? stageValueFields = null) =>
        _playbooks.SaveDraftAsync(id, isOrgAdmin, scope, stages, userId, ct, postWin, stageValueFields);

    public Task<(PlaybookPublishPreview? Preview, PlaybookProcess.Refusal? Refusal)> PublishPreviewAsync(
        Guid id, bool isOrgAdmin, TeamScope scope, CancellationToken ct = default) =>
        _playbooks.PublishPreviewAsync(id, isOrgAdmin, scope, ct);

    public Task<(PlaybookPublishResultDto? Result, PlaybookProcess.Refusal? Refusal)> PublishAsync(
        Guid id, bool isOrgAdmin, TeamScope scope, Dictionary<string, string>? remap, Guid userId, CancellationToken ct = default) =>
        _playbooks.PublishAsync(id, isOrgAdmin, scope, remap, userId, ct);

    public Task<(PlaybookAssignmentsDto? Result, PlaybookProcess.Refusal? Refusal)> GetAssignmentsAsync(
        Guid id, bool isOrgAdmin, TeamScope scope, CancellationToken ct = default) =>
        _playbooks.GetAssignmentsAsync(id, isOrgAdmin, scope, ct);

    public Task<(PlaybookAssignmentsDto? Result, PlaybookProcess.Refusal? Refusal)> SetAssignmentsAsync(
        Guid id, bool isOrgAdmin, TeamScope scope, List<Guid>? teamIds, CancellationToken ct = default) =>
        _playbooks.SetAssignmentsAsync(id, isOrgAdmin, scope, teamIds, ct);

    public Task<(bool Ok, PlaybookProcess.Refusal? Refusal)> ArchiveAsync(
        Guid id, bool isOrgAdmin, TeamScope scope, Guid? actorId = null, CancellationToken ct = default) =>
        _playbooks.ArchiveAsync(id, isOrgAdmin, scope, actorId, ct);

    public Task<(bool Ok, PlaybookProcess.Refusal? Refusal)> UnarchiveAsync(
        Guid id, bool isOrgAdmin, TeamScope scope, Guid? actorId = null, CancellationToken ct = default) =>
        _playbooks.UnarchiveAsync(id, isOrgAdmin, scope, actorId, ct);

    public Task<(List<QualificationItemDto>? Items, PlaybookProcess.Refusal? Refusal)> QualificationItemsAsync(
        Guid id, bool isOrgAdmin, TeamScope scope, CancellationToken ct = default) =>
        _playbooks.QualificationItemsAsync(id, isOrgAdmin, scope, ct);

    public Task<(QualificationDraftResultDto? Result, PlaybookProcess.Refusal? Refusal)> SaveQualificationItemsAsync(
        Guid id, bool isOrgAdmin, TeamScope scope, List<QualificationItemDto>? items, Guid userId, CancellationToken ct = default) =>
        _playbooks.SaveQualificationItemsAsync(id, isOrgAdmin, scope, items, userId, ct);
}

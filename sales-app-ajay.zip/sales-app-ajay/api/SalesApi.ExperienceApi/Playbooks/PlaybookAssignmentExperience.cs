using SalesApi.Dtos;
using SalesApi.ProcessLayer.Playbooks;

namespace SalesApi.ExperienceLayer.Playbooks;

/// <summary>
/// "Apply to existing leads" (owner decision 2026-10-03). A pass-through, same
/// as <see cref="PlaybooksExperience"/> — every endpoint returns exactly what
/// <see cref="PlaybookAssignmentProcess"/> already computes. Its own class
/// (rather than two more methods on <see cref="PlaybooksExperience"/>) mirrors
/// the vertical split already made at the Store/Process layer.
/// </summary>
public sealed class PlaybookAssignmentExperience
{
    private readonly PlaybookAssignmentProcess _process;
    public PlaybookAssignmentExperience(PlaybookAssignmentProcess process) => _process = process;

    public Task<PlaybookApplyPreviewDto> PreviewAsync(CancellationToken ct = default) =>
        _process.PreviewAsync(ct);

    public Task<(PlaybookApplyResultDto? Result, PlaybookAssignmentProcess.Refusal? Refusal)> ApplyAsync(
        string? previewToken, List<PlaybookApplyChoiceInput>? choices, Guid actorId, CancellationToken ct = default) =>
        _process.ApplyAsync(previewToken, choices, actorId, ct);
}

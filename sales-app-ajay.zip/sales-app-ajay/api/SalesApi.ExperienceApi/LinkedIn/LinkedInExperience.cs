using SalesApi.Dtos;
using SalesApi.ProcessLayer.LinkedIn;

namespace SalesApi.ExperienceLayer.LinkedIn;

/// <summary>What the LinkedIn connect/mapping screens need. FORWARDS — same
/// shape <c>MailboxExperience</c> takes for E6.1/E6.2.</summary>
public sealed class LinkedInExperience
{
    private readonly LinkedInOAuthProcess _oauth;
    private readonly LinkedInFieldMappingProcess _mapping;
    private readonly LinkedInSyncSettingsProcess _settings;
    private readonly LinkedInLeadSyncProcess _sync;
    private readonly LinkedInFormsProcess _forms;

    public LinkedInExperience(
        LinkedInOAuthProcess oauth, LinkedInFieldMappingProcess mapping,
        LinkedInSyncSettingsProcess settings, LinkedInLeadSyncProcess sync, LinkedInFormsProcess forms)
    {
        _oauth = oauth;
        _mapping = mapping;
        _settings = settings;
        _sync = sync;
        _forms = forms;
    }

    public Task<(LinkedInOAuthRefusal? Refusal, LinkedInAuthorizeUrlDto? Result)> BuildAuthorizeUrlAsync(
        Guid orgId, Guid profileId, string adminName, CancellationToken ct = default) =>
        _oauth.BuildAuthorizeUrlAsync(orgId, profileId, adminName, ct);

    public Task<(LinkedInOAuthRefusal? Refusal, LinkedInConnectResult? Result)> ExchangeCallbackAsync(
        string code, string state, CancellationToken ct = default) =>
        _oauth.ExchangeCallbackAsync(code, state, ct);

    public Task<List<LinkedInFieldMappingDto>> ListMappingsAsync(CancellationToken ct = default) => _mapping.ListAsync(ct);

    public Task<LinkedInFieldMappingDto?> GetMappingAsync(string formId, CancellationToken ct = default) => _mapping.GetAsync(formId, ct);

    public Task<(LinkedInFieldMappingDto? Dto, LinkedInFieldMappingProcess.Refusal? Refusal)> SaveMappingAsync(
        LinkedInFieldMappingInput input, Guid actorId, CancellationToken ct = default) =>
        _mapping.SaveAsync(input, actorId, ct);

    public Task<bool> DeleteMappingAsync(string formId, CancellationToken ct = default) => _mapping.DeleteAsync(formId, ct);

    public Task<LinkedInSyncSettingsDto> GetSettingsAsync(CancellationToken ct = default) => _settings.GetAsync(ct);

    public Task<(LinkedInSyncSettingsDto? Dto, LinkedInSyncSettingsProcess.Refusal? Refusal)> SaveSettingsAsync(
        LinkedInSyncSettingsInput input, Guid actorId, CancellationToken ct = default) =>
        _settings.SaveAsync(input, actorId, ct);

    /// <summary>POST /integrations/linkedin/sync-now — org-scoped manual
    /// trigger, same "POST /reminders/sweep" precedent (design §1).</summary>
    public Task<LinkedInSyncNowResultDto> SyncNowAsync(CancellationToken ct = default) => _sync.SyncAsync(ct);

    /// <summary>GET /integrations/linkedin/connection — lifetime totals +
    /// last error for the connector card (E6 follow-up owner answer
    /// 2026-09-29).</summary>
    public Task<LinkedInConnectionDetailDto> GetConnectionDetailAsync(CancellationToken ct = default) =>
        _oauth.GetConnectionDetailAsync(ct);

    /// <summary>GET /integrations/linkedin/forms — the mapping screen's form
    /// picker (E6 follow-up owner answer 2026-09-29).</summary>
    public Task<LinkedInFormsResultDto> GetFormsAsync(Guid orgId, CancellationToken ct = default) =>
        _forms.GetFormsAsync(orgId, ct);
}

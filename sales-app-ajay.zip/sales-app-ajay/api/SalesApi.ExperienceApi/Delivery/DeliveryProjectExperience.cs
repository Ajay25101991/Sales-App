using SalesApi.Dtos;
using SalesApi.ProcessLayer.ChannelPartners;
using SalesApi.ProcessLayer.Delivery;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Delivery;

/// <summary>
/// The delivery project on the rep's screens (the services list for the ask, read and request a deal's project) and on the delivery tool's status call back
/// (Partner API). Nothing is shaped differently per caller - the deal-access rule is the Process's and each route's permission or key scope is its controller's -
/// so this is a pass-through that gives the two controllers one Experience class to depend on, like <c>IrlExperience</c>.
/// </summary>
public sealed class DeliveryProjectExperience
{
    private readonly DeliveryProjectProcess _process;
    public DeliveryProjectExperience(DeliveryProjectProcess process) => _process = process;

    public Task<CpResult<List<DeliveryServiceDto>>> ServicesAsync(CancellationToken ct = default) => _process.ServicesAsync(ct);

    public Task<CpResult<DeliveryProjectDto?>> GetAsync(RecordAccessContext vis, Guid leadId, CancellationToken ct = default) =>
        _process.GetAsync(vis, leadId, ct);

    public Task<CpResult<DeliveryProjectProcess.Requested>> RequestAsync(
        RecordAccessContext vis, Guid actorId, Guid leadId, DeliveryProjectInput input, CancellationToken ct = default) =>
        _process.RequestAsync(vis, actorId, leadId, input, ct);

    public Task<CpResult<DeliveryProjectDto>> ReportAsync(Guid leadId, PartnerDeliveryProjectInput input, CancellationToken ct = default) =>
        _process.ReportAsync(leadId, input, ct);
}

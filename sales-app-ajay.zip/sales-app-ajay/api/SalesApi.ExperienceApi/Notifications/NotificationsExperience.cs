using SalesApi.Dtos;
using SalesApi.ProcessLayer.Notifications;

namespace SalesApi.ExperienceLayer.Notifications;

/// <summary>
/// One person's notification preferences screen and in-app inbox. Forwards
/// throughout — the screen wants exactly what Process composes.
/// </summary>
public sealed class NotificationsExperience
{
    private readonly NotificationProcess _process;
    public NotificationsExperience(NotificationProcess process) => _process = process;

    public Task<NotificationSettingsDto> SettingsAsync(Guid userId, Guid? orgId, CancellationToken ct = default) =>
        _process.SettingsAsync(userId, orgId, ct);

    public Task<NotificationSettingsDto?> UpdateSettingsAsync(
        Guid userId, Guid? orgId, NotificationSettingsInput input,
        bool quietFromProvided, bool quietToProvided, CancellationToken ct = default) =>
        _process.UpdateSettingsAsync(userId, orgId, input, quietFromProvided, quietToProvided, ct);

    public Task<NotificationSettingsDto?> SetEventPreferenceAsync(
        Guid userId, Guid? orgId, NotificationPreferenceInput input, CancellationToken ct = default) =>
        _process.SetEventPreferenceAsync(userId, orgId, input, ct);

    public Task<NotificationSettingsDto?> SetTeamPreferenceAsync(
        Guid userId, Guid? orgId, TeamNotificationPreferenceInput input, CancellationToken ct = default) =>
        _process.SetTeamPreferenceAsync(userId, orgId, input, ct);

    public Task<List<AppNotificationDto>> InboxAsync(Guid userId, bool unreadOnly, CancellationToken ct = default) =>
        _process.InboxAsync(userId, unreadOnly, ct);

    public Task<int> UnreadCountAsync(Guid userId, CancellationToken ct = default) => _process.UnreadCountAsync(userId, ct);

    public Task<int> MarkReadAsync(Guid userId, List<Guid>? ids, CancellationToken ct = default) =>
        _process.MarkReadAsync(userId, ids, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.ClientDocuments;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.ClientDocuments;

/// <summary>
/// What the "Documents read" panel (on an account, and on a deal) needs. It FORWARDS - every method calls straight through to
/// <see cref="ClientDocumentProcess"/> with no reshaping, like the other forwarding Experience classes: the panel wants exactly what
/// Process computes today, and the first second consumer that wants something different adds the difference here.
/// </summary>
public sealed class ClientDocumentsExperience
{
    private readonly ClientDocumentProcess _documents;
    public ClientDocumentsExperience(ClientDocumentProcess documents) => _documents = documents;

    public List<ClientDocumentTypeDto> Catalogue() => ClientDocumentProcess.Catalogue();

    public Task<ClientDocumentProcess.ListOutcome> ListAsync(
        RecordAccessContext ctx, string callerRole, Guid? accountId, Guid? leadId, string? status, CancellationToken ct = default) =>
        _documents.ListAsync(ctx, callerRole, accountId, leadId, status, ct);

    public Task<ClientDocumentProcess.Refusal?> ReadAgainAsync(RecordAccessContext ctx, Guid attachmentId, CancellationToken ct = default) =>
        _documents.ReadAgainAsync(ctx, attachmentId, ct);

    public Task<ClientDocumentProcess.ValueOutcome> ConfirmAsync(RecordAccessContext ctx, string callerRole, Guid valueId, CancellationToken ct = default) =>
        _documents.ConfirmAsync(ctx, callerRole, valueId, ct);

    public Task<ClientDocumentProcess.ValueOutcome> ConfirmEditedAsync(
        RecordAccessContext ctx, string callerRole, Guid valueId, ClientDocumentEditInput input, CancellationToken ct = default) =>
        _documents.ConfirmEditedAsync(ctx, callerRole, valueId, input, ct);

    public Task<ClientDocumentProcess.ValueOutcome> AddManualAsync(
        RecordAccessContext ctx, string callerRole, ClientDocumentManualInput input, CancellationToken ct = default) =>
        _documents.AddManualAsync(ctx, callerRole, input, ct);

    public Task<ClientDocumentProcess.ValueOutcome> RejectAsync(RecordAccessContext ctx, string callerRole, Guid valueId, CancellationToken ct = default) =>
        _documents.RejectAsync(ctx, callerRole, valueId, ct);
}

using System.Text.Json;
using SalesApi.Dtos;
using SalesApi.ProcessLayer.Automations;

namespace SalesApi.ExperienceLayer.Automations;

/// <summary>
/// What the automations screens (library, builder) need, shaped for them.
///
/// A PASS-THROUGH, same finding as <c>PlaybooksExperience</c> and every other
/// migrated domain's Experience class (see that file's own doc comment for
/// the full reasoning) — the seam exists for uniformity and for the day a
/// second consumer (a phone read-only view, the AI assistant) wants a
/// different shape than the desktop builder does.
///
/// THIS FILE CANNOT SEE THE DATABASE — <c>SalesApi.ExperienceApi</c> disables
/// transitive project references, so <c>AppDbContext</c>, <c>Automation</c>,
/// <c>AutomationVersion</c> are all invisible here, checked by the compiler.
/// </summary>
public sealed class AutomationsExperience
{
    private readonly AutomationProcess _automations;
    public AutomationsExperience(AutomationProcess automations) => _automations = automations;

    public Task<List<AutomationSummaryDto>> ListAsync(bool includeArchived, CancellationToken ct = default) =>
        _automations.ListAsync(includeArchived, ct);

    public Task<AutomationDetailDto?> GetAsync(Guid id, CancellationToken ct = default) =>
        _automations.GetAsync(id, ct);

    public Task<List<AutomationVersionDto>?> VersionsAsync(Guid id, CancellationToken ct = default) =>
        _automations.VersionsAsync(id, ct);

    public Task<(AutomationSummaryDto? Created, AutomationProcess.Refusal? Refusal)> CreateAsync(
        string? name, string? description, string? key, Guid userId, CancellationToken ct = default) =>
        _automations.CreateAsync(name, description, key, userId, ct);

    public Task<(AutomationSummaryDto? Created, AutomationProcess.Refusal? Refusal)> CreateAsync(
        string? name, string? description, Guid userId, CancellationToken ct = default) =>
        _automations.CreateAsync(name, description, userId, ct);

    public Task<(AutomationSummaryDto? Result, AutomationProcess.Refusal? Refusal)> RenameAsync(
        Guid id, string? name, string? description, CancellationToken ct = default) =>
        _automations.RenameAsync(id, name, description, ct);

    public Task<(AutomationDraftResultDto? Result, AutomationProcess.Refusal? Refusal)> SaveDraftAsync(
        Guid id, JsonElement? trigger, JsonElement? condition, JsonElement? actions, Guid userId, CancellationToken ct = default) =>
        _automations.SaveDraftAsync(id, trigger, condition, actions, userId, ct);

    public Task<(AutomationPublishResultDto? Result, AutomationProcess.Refusal? Refusal)> PublishAsync(
        Guid id, Guid userId, CancellationToken ct = default) =>
        _automations.PublishAsync(id, userId, ct);

    public Task<(bool Ok, AutomationProcess.Refusal? Refusal)> SetEnabledAsync(
        Guid id, bool enabled, CancellationToken ct = default) =>
        _automations.SetEnabledAsync(id, enabled, ct);

    public Task<(bool Ok, AutomationProcess.Refusal? Refusal)> ArchiveAsync(Guid id, CancellationToken ct = default) =>
        _automations.ArchiveAsync(id, ct);

    public Task<(bool Ok, AutomationProcess.Refusal? Refusal)> UnarchiveAsync(Guid id, CancellationToken ct = default) =>
        _automations.UnarchiveAsync(id, ct);

    // "Restore default" (E2.5, design doc §12 slice 7 rule 3) — distinct from
    // UnarchiveAsync above (un-retiring a custom automation): re-seeds a
    // BUILT-IN's shipped definition as a new draft version.
    public Task<(AutomationVersionDto? Result, AutomationProcess.Refusal? Refusal)> RestoreDefaultAsync(
        Guid id, Guid userId, CancellationToken ct = default) =>
        _automations.RestoreDefaultAsync(id, userId, ct);

    public Task<(bool Ok, AutomationProcess.Refusal? Refusal)> HardDeleteAsync(
        Guid id, string? confirmation, CancellationToken ct = default) =>
        _automations.HardDeleteAsync(id, confirmation, ct);

    public Task<AutomationLimitsDto> GetLimitsAsync(CancellationToken ct = default) => _automations.GetLimitsAsync(ct);

    public AutomationWatchableFieldsDto WatchableFields() => _automations.WatchableFields();

    public Task<List<AutomationMergeFieldDto>> MergeFieldsAsync(string? entityType, CancellationToken ct = default) =>
        _automations.MergeFieldsAsync(entityType, ct);

    public Task<(PagedResult<AutomationRunDto>? Page, AutomationProcess.Refusal? Refusal)> RunsAsync(
        Guid id, string? cursor, int? limit, CancellationToken ct = default) =>
        _automations.RunsAsync(id, cursor, limit, ct);

    public Task<(AutomationRunDto? Result, AutomationProcess.Refusal? Refusal)> RetryRunAsync(
        Guid id, Guid runId, CancellationToken ct = default) =>
        _automations.RetryRunAsync(id, runId, ct);

    public Task<(AutomationPreviewResultDto? Result, AutomationProcess.Refusal? Refusal)> PreviewAsync(
        Guid id, int? sampleSize, CancellationToken ct = default) =>
        _automations.PreviewAsync(id, sampleSize, ct);

    public Task<(AutomationPublishPreviewDto? Result, AutomationProcess.Refusal? Refusal)> PublishPreviewAsync(
        Guid id, int? sampleSize, CancellationToken ct = default) =>
        _automations.PublishPreviewAsync(id, sampleSize, ct);
}

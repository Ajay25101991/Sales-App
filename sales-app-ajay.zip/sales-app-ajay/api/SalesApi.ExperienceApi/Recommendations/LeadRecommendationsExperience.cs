using SalesApi.Dtos;
using SalesApi.ProcessLayer.Recommendations;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Recommendations;

/// <summary>FORWARDS - the lead page's "Recommended next" panel wants exactly what <see cref="LeadRecommendationProcess"/> computes (owner 2026-11-11).</summary>
public sealed class LeadRecommendationsExperience
{
    private readonly LeadRecommendationProcess _recommendations;
    public LeadRecommendationsExperience(LeadRecommendationProcess recommendations) => _recommendations = recommendations;

    public Task<LeadRecommendationProcess.Outcome> GetAsync(RecordAccessContext ctx, Guid leadId, CancellationToken ct = default) =>
        _recommendations.GetAsync(ctx, leadId, ct);

    public Task<LeadRecommendationProcess.Outcome> ChangeAsync(
        RecordAccessContext ctx, Guid actorId, Guid leadId, string recommendationId, LeadRecommendationProcess.Change change, CancellationToken ct = default) =>
        _recommendations.ChangeAsync(ctx, actorId, leadId, recommendationId, change, ct);
}

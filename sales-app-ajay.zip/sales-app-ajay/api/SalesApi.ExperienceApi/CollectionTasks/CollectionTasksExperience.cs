using SalesApi.Dtos;
using SalesApi.ProcessLayer.CollectionTasks;

namespace SalesApi.ExperienceLayer.CollectionTasks;

/// <summary>
/// What the collection-task screens need.
///
/// Built for uniformity per the owner's 2026-08-28 decision (every domain gets
/// an Experience class), not because this screen wants a different shape than
/// Process computes — it does not. Every method here forwards; say so plainly
/// rather than dressing a pass-through up as a reshape. The seam is the
/// purchase: the moment a second consumer (a collector's phone view wanting
/// only its own open pool, a customer-facing receipt page) wants something
/// different, the difference lands here and Process stays untouched.
/// </summary>
public sealed class CollectionTasksExperience
{
    private readonly CollectionTaskProcess _tasks;
    public CollectionTasksExperience(CollectionTaskProcess tasks) => _tasks = tasks;

    public Task<List<CollectionTaskDto>> ListAsync(
        bool restrictToCollector, Guid collectorId, string? status, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _tasks.ListAsync(restrictToCollector, collectorId, status, canSeeFinancials, ct);

    public Task<CollectionTaskDto?> GetAsync(Guid id, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _tasks.GetAsync(id, canSeeFinancials, ct);

    public Task<CollectionTaskProcess.PdfOutcome> ReceiptPdfAsync(Guid id, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _tasks.ReceiptPdfAsync(id, canSeeFinancials, ct);

    public Task<List<string>?> CustomerModulesAsync(Guid id, CancellationToken ct = default) =>
        _tasks.CustomerModulesAsync(id, ct);

    public Task<CollectionTaskProcess.TaskOutcome> CreateAsync(
        Guid? invoiceId, decimal? amount, string? method, string? notes, Guid assignedById,
        bool canSeeFinancials = true, CancellationToken ct = default) =>
        _tasks.CreateAsync(invoiceId, amount, method, notes, assignedById, canSeeFinancials, ct);

    public Task<CollectionTaskProcess.TaskOutcome> CollectAsync(
        Guid id, decimal? amount, string? method, string? reference, DateTime? paidAt, string? note,
        List<string>? modules, Guid? proofAttachmentId, List<Guid>? proofInvoiceIds, Guid collectedById,
        bool canSeeFinancials = true, CancellationToken ct = default) =>
        _tasks.CollectAsync(id, amount, method, reference, paidAt, note, modules, proofAttachmentId, proofInvoiceIds, collectedById, canSeeFinancials, ct);

    public Task<CollectionTaskProcess.InvoicesOutcome> CustomerInvoicesAsync(Guid id, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _tasks.CustomerInvoicesAsync(id, canSeeFinancials, ct);

    public Task<CollectionTaskProcess.TaskOutcome> CancelAsync(Guid id, bool canSeeFinancials = true, CancellationToken ct = default) =>
        _tasks.CancelAsync(id, canSeeFinancials, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.PartnerApi;

namespace SalesApi.ExperienceLayer.PartnerApi;

/// <summary>
/// What <c>PartnerApiController</c> needs — a thin forward, same shape as
/// every other Experience class built under the "add Experience uniformly"
/// decision. Carries no scope logic of its own: which scope gates which
/// method is decided entirely by <c>[RequireApiKeyScope]</c> on the
/// controller action, never here.
/// </summary>
public sealed class PartnerApiExperience
{
    private readonly PartnerApiProcess _partner;
    public PartnerApiExperience(PartnerApiProcess partner) => _partner = partner;

    public Task<PagedResult<PartnerAccountDto>> AccountsAsync(
        DateTime? updatedSince, string? cursor, int? limit, CancellationToken ct = default) =>
        _partner.AccountsAsync(updatedSince, cursor, limit, ct);

    public Task<(PartnerAccountDto? Account, PartnerApiProcess.Refusal? Refusal)> AccountAsync(Guid id, CancellationToken ct = default) =>
        _partner.AccountAsync(id, ct);

    public Task<(PagedResult<PartnerContactDto>? Page, PartnerApiProcess.Refusal? Refusal)> ContactsAsync(
        Guid? accountId, DateTime? updatedSince, string? cursor, int? limit, CancellationToken ct = default) =>
        _partner.ContactsAsync(accountId, updatedSince, cursor, limit, ct);

    public Task<(PartnerLeadDto? Lead, PartnerApiProcess.Refusal? Refusal)> LeadAsync(Guid id, CancellationToken ct = default) =>
        _partner.LeadAsync(id, ct);

    public Task<(PartnerLeadDto? Lead, PartnerApiProcess.Refusal? Refusal)> UpdateDeliveryAsync(
        Guid id, PartnerLeadDeliveryInput input, CancellationToken ct = default) =>
        _partner.UpdateDeliveryAsync(id, input, ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.SharePointBrowse;

namespace SalesApi.ExperienceLayer.SharePointBrowse;

/// <summary>The SharePoint picker's data (recent, sites, libraries, folders, search, and the caller's own state). Forwards throughout -
/// the picker wants exactly what Process computes, like <c>AttachmentsExperience</c>.</summary>
public sealed class SharePointBrowseExperience
{
    private readonly SharePointBrowseProcess _process;
    public SharePointBrowseExperience(SharePointBrowseProcess process) => _process = process;

    public Task<SharePointBrowseStatusDto> StatusAsync(Guid profileId, CancellationToken ct = default) => _process.StatusAsync(profileId, ct);
    public Task<BrowseResult> RecentAsync(Guid profileId, string? cursor, DateTime? now = null, CancellationToken ct = default) => _process.RecentAsync(profileId, cursor, now, ct);
    public Task<BrowseResult> SitesAsync(Guid profileId, string? search, string? cursor, CancellationToken ct = default) => _process.SitesAsync(profileId, search, cursor, ct);
    public Task<BrowseResult> LibrariesAsync(Guid profileId, string? siteId, string? cursor, CancellationToken ct = default) => _process.LibrariesAsync(profileId, siteId, cursor, ct);
    public Task<BrowseResult> FolderAsync(Guid profileId, string? driveId, string? itemId, string? cursor, CancellationToken ct = default) => _process.FolderAsync(profileId, driveId, itemId, cursor, ct);
    public Task<BrowseResult> SearchAsync(Guid profileId, string? q, string? cursor, CancellationToken ct = default) => _process.SearchAsync(profileId, q, cursor, ct);
}

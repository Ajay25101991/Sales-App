using SalesApi.Dtos;
using SalesApi.ProcessLayer.Amcs;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Amcs;

/// <summary>
/// What the AMC screens need. It FORWARDS — every method here calls straight
/// through to <see cref="AmcProcess"/> with no reshaping, same as ten of the
/// eleven domains migrated before it (Quotes is still the only one where a
/// second consumer forced a real change). Built anyway, per the owner's
/// 2026-08-28 decision to add Experience uniformly rather than carry a
/// growing list of exceptions: the panel wants exactly what Process computes
/// today, and the moment a second consumer (a phone renewal-book widget that
/// wants only the days-to-renewal figure, say) wants something different, the
/// difference lands here and Process stays untouched.
/// </summary>
public sealed class AmcsExperience
{
    private readonly AmcProcess _amcs;
    public AmcsExperience(AmcProcess amcs) => _amcs = amcs;

    public Task<List<AmcDto>> ListAsync(RecordAccessContext ctx, string? status, CancellationToken ct = default, Guid? leadId = null) =>
        _amcs.ListAsync(ctx, status, ct, leadId);

    public Task<AmcReminderConfigDto> GetReminderConfigAsync(CancellationToken ct = default) =>
        _amcs.GetReminderConfigAsync(ct);

    public Task<AmcReminderConfigDto> SetReminderConfigAsync(AmcReminderConfigInput input, CancellationToken ct = default) =>
        _amcs.SetReminderConfigAsync(input, ct);

    public Task<AmcEmailTemplateDto> GetEmailTemplateAsync(CancellationToken ct = default) =>
        _amcs.GetEmailTemplateAsync(ct);

    public Task<AmcEmailTemplateDto> SetEmailTemplateAsync(AmcEmailTemplateInput input, CancellationToken ct = default) =>
        _amcs.SetEmailTemplateAsync(input, ct);

    public Task<int> GenerateAsync(CancellationToken ct = default) => _amcs.GenerateAsync(ct);

    public Task<AmcProcess.AmcOutcome> GetAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _amcs.GetAsync(ctx, id, ct);

    public Task<AmcProcess.AmcOutcome> CreateAsync(RecordAccessContext ctx, AmcInput input, CancellationToken ct = default) =>
        _amcs.CreateAsync(ctx, input, ct);

    public Task<AmcProcess.AmcTermsOutcome> TermsAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _amcs.TermsAsync(ctx, id, ct);

    public Task<AmcProcess.AmcOutcome> UpdateAsync(RecordAccessContext ctx, Guid id, AmcInput input, CancellationToken ct = default) =>
        _amcs.UpdateAsync(ctx, id, input, ct);

    public Task<AmcProcess.AmcTermOutcome> UpdateTermAsync(
        RecordAccessContext ctx, Guid id, Guid termId, AmcTermInput input, CancellationToken ct = default) =>
        _amcs.UpdateTermAsync(ctx, id, termId, input, ct);

    public Task<AmcValueChangePolicyDto> GetValueChangePolicyAsync(CancellationToken ct = default) =>
        _amcs.GetValueChangePolicyAsync(ct);

    public Task<AmcValueChangePolicyDto> SetValueChangePolicyAsync(AmcValueChangePolicyInput input, CancellationToken ct = default) =>
        _amcs.SetValueChangePolicyAsync(input, ct);

    public Task<AmcProcess.AmcOutcome> RenewAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default, AmcRenewInput? input = null) =>
        _amcs.RenewAsync(ctx, id, ct, input);

    public Task<AmcProcess.DeleteOutcome> DeleteAsync(RecordAccessContext ctx, Guid id, CancellationToken ct = default) =>
        _amcs.DeleteAsync(ctx, id, ct);
}

using SalesApi.Contracts;
using SalesApi.ProcessLayer.PhoneReview;

namespace SalesApi.ExperienceLayer.PhoneReview;

/// <summary>
/// What the Admin "Phone numbers to review" screen needs. FORWARDS — same
/// shape every migrated domain's Experience takes, per
/// <see cref="SalesApi.ExperienceLayer.AiPlatform.AiExecutionLogExperience"/>.
/// </summary>
public sealed class PhoneReviewExperience
{
    private readonly PhoneReviewProcess _process;
    public PhoneReviewExperience(PhoneReviewProcess process) => _process = process;

    public Task<(PhoneReviewListDto? List, PhoneReviewProcess.Refusal? Refusal)> ListAsync(
        string? kind, string? cursor, int? limit, CancellationToken ct = default) =>
        _process.ListAsync(kind, cursor, limit, ct);

    public Task<PhoneReviewCountDto> CountAsync(CancellationToken ct = default) => _process.CountAsync(ct);

    public Task<(PhoneReviewApplyResponseDto? Response, PhoneReviewProcess.Refusal? Refusal)> ApplyAsync(
        PhoneReviewApplyInput input, Guid actorId, CancellationToken ct = default) =>
        _process.ApplyAsync(input, actorId, ct);
}

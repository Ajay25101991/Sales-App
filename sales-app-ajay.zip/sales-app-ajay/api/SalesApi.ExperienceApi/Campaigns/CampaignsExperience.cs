using SalesApi.Dtos;
using SalesApi.ProcessLayer.Campaigns;
using SalesApi.Services;

namespace SalesApi.ExperienceLayer.Campaigns;

/// <summary>E21 - the campaign screens' calls. FORWARDS: the composer, the schedule list and the results want exactly what <see cref="CampaignProcess"/> and
/// <see cref="CampaignSettingsProcess"/> compute.</summary>
public sealed class CampaignsExperience
{
    private readonly CampaignProcess _campaigns;
    private readonly CampaignSettingsProcess _settings;

    public CampaignsExperience(CampaignProcess campaigns, CampaignSettingsProcess settings)
    {
        _campaigns = campaigns;
        _settings = settings;
    }

    // ---- campaigns ----

    public Task<List<CampaignDto>> ListAsync(string? status, CancellationToken ct = default) => _campaigns.ListAsync(status, ct);
    public Task<CampaignProcess.Result<CampaignDto>> GetAsync(Guid id, CancellationToken ct = default) => _campaigns.GetAsync(id, ct);
    public Task<CampaignProcess.Result<CampaignDto>> CreateAsync(RecordAccessContext ctx, CampaignInput input, CancellationToken ct = default) => _campaigns.CreateAsync(ctx, input, ct);
    public Task<CampaignProcess.Result<CampaignDto>> UpdateAsync(RecordAccessContext ctx, Guid id, CampaignInput input, CancellationToken ct = default) => _campaigns.UpdateAsync(ctx, id, input, ct);
    public Task<CampaignProcess.Refusal?> DeleteAsync(Guid id, CancellationToken ct = default) => _campaigns.DeleteAsync(id, ct);

    public Task<CampaignProcess.Result<CampaignAudienceDto>> PreviewAudienceAsync(
        RecordAccessContext ctx, bool canViewContactDetails, string callerRole, Guid id, CancellationToken ct = default) =>
        _campaigns.PreviewAudienceAsync(ctx, canViewContactDetails, callerRole, id, ct);

    public Task<CampaignProcess.Result<CampaignPreviewDto>> PreviewMessageAsync(RecordAccessContext ctx, Guid id, Guid contactId, CancellationToken ct = default) =>
        _campaigns.PreviewMessageAsync(ctx, id, contactId, ct);

    public Task<CampaignProcess.Result<CampaignTestSendDto>> TestSendAsync(RecordAccessContext ctx, Guid id, CampaignTestSendInput input, CancellationToken ct = default) =>
        _campaigns.TestSendAsync(ctx, id, input, ct);

    public Task<CampaignProcess.Result<CampaignDto>> ScheduleAsync(RecordAccessContext ctx, Guid id, CampaignScheduleInput input, CancellationToken ct = default) =>
        _campaigns.ScheduleAsync(ctx, id, input, ct);

    public Task<CampaignProcess.Result<CampaignDto>> CancelAsync(Guid id, CancellationToken ct = default) => _campaigns.CancelAsync(id, ct);

    public Task<CampaignProcess.Result<CampaignRecipientPageDto>> RecipientsAsync(Guid id, string? status, int? limit, int? offset, CancellationToken ct = default) =>
        _campaigns.RecipientsAsync(id, status, limit, offset, ct);

    // ---- from-addresses and settings ----

    public Task<List<MarketingFromAddressDto>> FromAddressesAsync(CancellationToken ct = default) => _settings.FromAddressesAsync(ct);
    public Task<CampaignProcess.Result<MarketingFromAddressDto>> CreateFromAddressAsync(MarketingFromAddressInput input, CancellationToken ct = default) => _settings.CreateFromAddressAsync(input, ct);
    public Task<CampaignProcess.Result<MarketingFromAddressDto>> UpdateFromAddressAsync(Guid id, MarketingFromAddressInput input, CancellationToken ct = default) => _settings.UpdateFromAddressAsync(id, input, ct);
    public Task<CampaignProcess.Refusal?> DeleteFromAddressAsync(Guid id, CancellationToken ct = default) => _settings.DeleteFromAddressAsync(id, ct);
    public Task<CampaignSettingsDto> GetSettingsAsync(CancellationToken ct = default) => _settings.GetSettingsAsync(ct);
    public Task<CampaignProcess.Result<CampaignSettingsDto>> SaveSettingsAsync(CampaignSettingsInput input, CancellationToken ct = default) => _settings.SaveSettingsAsync(input, ct);
}

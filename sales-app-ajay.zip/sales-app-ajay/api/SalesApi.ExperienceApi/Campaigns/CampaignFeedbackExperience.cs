using System.Net;
using SalesApi.ProcessLayer.Campaigns;

namespace SalesApi.ExperienceLayer.Campaigns;

/// <summary>
/// E21 - the public side of a campaign email: the unsubscribe page a recipient lands on, and the SES feedback webhook. The pages are small, self-contained HTML
/// (no app bundle, no sign-in): the confirm page shows a button that POSTs to the same address, which is also what a mail client's one-click POST (RFC 8058) does.
/// The wording is deliberately generic - it names no org and no address, because the link is the only proof the reader has and the page must not leak who it is for.
/// </summary>
public sealed class CampaignFeedbackExperience
{
    private readonly CampaignFeedbackProcess _feedback;
    public CampaignFeedbackExperience(CampaignFeedbackProcess feedback) => _feedback = feedback;

    public bool IsValidUnsubscribeToken(string? token) => _feedback.IsValidUnsubscribeToken(token);

    public Task<bool> UnsubscribeAsync(string? token, CancellationToken ct = default) => _feedback.UnsubscribeAsync(token, ct);

    public Task<CampaignFeedbackProcess.SnsOutcome> HandleSnsAsync(string body, CancellationToken ct = default) => _feedback.HandleSnsAsync(body, ct);

    /// <summary>GET: the confirm page for a good link (button POSTs back to <paramref name="actionPath"/>), or the "link not valid" page.</summary>
    public string ConfirmPage(string? token, string actionPath) =>
        IsValidUnsubscribeToken(token)
            ? Page("Unsubscribe from marketing email",
                "<p>Do you want to stop receiving marketing email from us?</p>" +
                $"<form method=\"post\" action=\"{WebUtility.HtmlEncode(actionPath)}\"><button type=\"submit\">Unsubscribe</button></form>")
            : InvalidPage();

    public string DonePage() =>
        Page("You are unsubscribed", "<p>You will no longer receive marketing email from us. You can close this page.</p>");

    public string InvalidPage() =>
        Page("This link is not valid", "<p>This unsubscribe link is not valid. If you want to stop receiving our email, reply to any message and ask us to remove you.</p>");

    private static string Page(string title, string body) =>
        "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
        $"<meta name=\"robots\" content=\"noindex\"><title>{WebUtility.HtmlEncode(title)}</title>" +
        "<style>body{font-family:system-ui,sans-serif;max-width:32rem;margin:4rem auto;padding:0 1rem;line-height:1.5}button{font-size:1rem;padding:.6rem 1.2rem;cursor:pointer}</style></head>" +
        $"<body><h1>{WebUtility.HtmlEncode(title)}</h1>{body}</body></html>";
}

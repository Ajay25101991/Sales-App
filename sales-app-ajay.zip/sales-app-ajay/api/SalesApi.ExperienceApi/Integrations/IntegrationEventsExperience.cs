using SalesApi.Dtos;
using SalesApi.ProcessLayer.Integrations;

namespace SalesApi.ExperienceLayer.Integrations;

/// <summary>
/// The integrations admin page's extras (integrations audit): the incoming log, the common "test connection", and the needs-attention
/// items - plus the one-line writer the public webhook controllers call. FORWARDS, like <see cref="IntegrationsExperience"/>.
/// </summary>
public sealed class IntegrationEventsExperience
{
    private readonly IntegrationEventsProcess _events;
    private readonly IntegrationTestProcess _tests;
    private readonly IntegrationAttentionProcess _attention;

    public IntegrationEventsExperience(IntegrationEventsProcess events, IntegrationTestProcess tests, IntegrationAttentionProcess attention)
    {
        _events = events;
        _tests = tests;
        _attention = attention;
    }

    /// <summary>Writes one incoming-log line; a null org writes nothing; never throws.</summary>
    public Task RecordInboundAsync(
        Guid? orgId, string connector, string outcome, string? detail = null, string? externalId = null, CancellationToken ct = default) =>
        _events.RecordAsync(orgId, connector, outcome, detail, externalId, ct);

    public Task<InboundEventPageDto> ListEventsAsync(string? connector, string? outcome, int page, int pageSize, CancellationToken ct = default) =>
        _events.ListAsync(connector, outcome, page, pageSize, ct);

    public Task<ConnectionTestResultDto?> TestAsync(string key, Guid? orgId, Guid userId, CancellationToken ct = default) =>
        _tests.TestAsync(key, orgId, userId, ct);

    public Task<IntegrationAttentionDto> AttentionAsync(CancellationToken ct = default) => _attention.GetAsync(ct);
}

using SalesApi.Dtos;
using SalesApi.ProcessLayer.Integrations;

namespace SalesApi.ExperienceLayer.Integrations;

/// <summary>
/// The integrations directory screen's payload. Forwards Process's answer
/// unchanged today — one consumer (the desktop directory) wants exactly what
/// Process computes. Built anyway, per the owner's uniformity decision: the
/// value arrives with the second consumer, and Process stays untouched when
/// it does.
/// </summary>
public sealed class IntegrationsExperience
{
    private readonly IntegrationsProcess _process;
    public IntegrationsExperience(IntegrationsProcess process) => _process = process;

    public Task<List<ConnectorSummaryDto>> ListAsync(CancellationToken ct = default) =>
        _process.ListAsync(ct);

    public Task<ConnectorDetailDto?> DetailAsync(string key, CancellationToken ct = default) =>
        _process.DetailAsync(key, ct);

    public Task<ConnectorDetailDto> SaveCredentialsAsync(
        string key, Guid userId, Dictionary<string, string> values, CancellationToken ct = default) =>
        _process.SaveCredentialsAsync(key, userId, values, ct);

    public Task<ConnectorDetailDto?> DisconnectAsync(string key, CancellationToken ct = default) =>
        _process.DisconnectAsync(key, ct);
}

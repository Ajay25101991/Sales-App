using SalesApi.Dtos;
using SalesApi.ProcessLayer.SavedViews;

namespace SalesApi.ExperienceLayer.SavedViews;

/// <summary>What the leads/accounts/quotes/invoices view switcher and the
/// Explore "pin to overview" need. Forwards today — see
/// Goals.GoalsExperience for why that is still worth having.</summary>
public sealed class SavedViewsExperience
{
    private readonly SavedViewProcess _views;
    public SavedViewsExperience(SavedViewProcess views) => _views = views;

    public Task<List<SavedViewDto>> ListForMeAsync(SavedViewProcess.Caller caller, string? list, CancellationToken ct = default) =>
        _views.ListForMeAsync(caller, list, ct);

    public Task<(SavedViewDto? Dto, SavedViewProcess.Refusal? Refusal)> GetAsync(SavedViewProcess.Caller caller, Guid id, CancellationToken ct = default) =>
        _views.GetAsync(caller, id, ct);

    public Task<(SavedViewDto? Created, SavedViewProcess.Refusal? Refusal)> CreateAsync(SavedViewProcess.Caller caller, SavedViewInput input, CancellationToken ct = default) =>
        _views.CreateAsync(caller, input, ct);

    public Task<(SavedViewDto? Updated, SavedViewProcess.Refusal? Refusal)> UpdateAsync(SavedViewProcess.Caller caller, Guid id, SavedViewInput input, CancellationToken ct = default) =>
        _views.UpdateAsync(caller, id, input, ct);

    public Task<SavedViewProcess.Refusal?> DeleteAsync(SavedViewProcess.Caller caller, Guid id, CancellationToken ct = default) =>
        _views.DeleteAsync(caller, id, ct);

    public Task<SavedViewProcess.Refusal?> SetOrgDefaultAsync(SavedViewProcess.Caller caller, Guid id, bool orgDefault, CancellationToken ct = default) =>
        _views.SetOrgDefaultAsync(caller, id, orgDefault, ct);

    public Task<SavedViewProcess.Refusal?> SetMyDefaultAsync(SavedViewProcess.Caller caller, Guid id, bool myDefault, CancellationToken ct = default) =>
        _views.SetMyDefaultAsync(caller, id, myDefault, ct);
}

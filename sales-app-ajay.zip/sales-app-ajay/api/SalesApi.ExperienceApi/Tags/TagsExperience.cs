using SalesApi.Dtos;
using SalesApi.ProcessLayer.Tags;

namespace SalesApi.ExperienceLayer.Tags;

/// <summary>
/// What the tag pickers and the tag-admin screen need.
///
/// Forwards today — tags are vocabulary data and every caller wants the same
/// shape. See <see cref="Goals.GoalsExperience"/> for why a forwarding layer is
/// still worth having under the "Experience everywhere" decision.
/// </summary>
public sealed class TagsExperience
{
    private readonly TagProcess _tags;
    public TagsExperience(TagProcess tags) => _tags = tags;

    public Task<List<TagDto>> SearchAsync(string? q, CancellationToken ct = default) =>
        _tags.SearchAsync(q, ct);

    public Task<(TagProcess.Refusal? Refusal, TagDto? Dto, bool Created)> CreateAsync(
        string? name, string? color, Guid? createdById, CancellationToken ct = default) =>
        _tags.CreateAsync(name, color, createdById, ct);

    public Task<(TagProcess.Refusal? Refusal, TagDto? Dto)> UpdateAsync(
        Guid id, string? name, string? color, CancellationToken ct = default) =>
        _tags.UpdateAsync(id, name, color, ct);

    // `intoTagId` is NULLABLE and stays that way: "merge into nothing" is a
    // request a client can make, and Process is what refuses it. Tightening the
    // type here would move that refusal into the compiler and lose the error
    // message the API returns.
    public Task<(TagProcess.Refusal? Refusal, TagDto? Dto)> MergeAsync(
        Guid sourceId, Guid? intoTagId, CancellationToken ct = default) =>
        _tags.MergeAsync(sourceId, intoTagId, ct);

    public Task<TagProcess.Refusal?> DeleteAsync(Guid id, CancellationToken ct = default) =>
        _tags.DeleteAsync(id, ct);
}

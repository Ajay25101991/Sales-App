// E7.7 single sign-on with Microsoft. Server halves only — see
// to-do/epics-ai-native-crm.md row "E7.6 plans + E7.7 SSO" and the running
// brief for the owner's binding answers.

namespace SalesApi.Dtos;

// --- POST /auth/sso/start (anonymous) -------------------------------------

/// <summary><see cref="Client"/> (wire name <c>client</c>) is optional:
/// "desktop" (default for absent or unrecognised), "phone_web" or "native".
/// It only selects which of the server's fixed sign-in redirects the callback
/// uses — it is never a URL.</summary>
public record SsoStartRequest(string? Email, string? Client = null);

/// <summary>
/// THE SAME SHAPE whether the email is unknown, the org has no SSO, SSO is
/// misconfigured, or the deployment has the feature off — <see cref="Available"/>
/// false and <see cref="AuthorizeUrl"/> null in every case (brief: "no
/// account enumeration"). The client's only reaction to false is to show the
/// password form; it never learns which of those reasons applied.
/// </summary>
public record SsoStartResponse(bool Available, string? AuthorizeUrl);

// --- POST /auth/sso/exchange (anonymous, single-use code -> real session) -

public record SsoExchangeRequest(string? Code, bool? SupportsRefresh = null);

// --- Org admin settings (ManageSettings) ----------------------------------

public record SsoSettingsDto(bool Enabled, string PasswordPolicy, bool GraphAppConfigured);
public record SsoSettingsInput(bool? Enabled, string? PasswordPolicy);

// --- Org admin "Test sign-in" (ManageSettings, authenticated) -------------

public record SsoTestStartResponse(string AuthorizeUrl);

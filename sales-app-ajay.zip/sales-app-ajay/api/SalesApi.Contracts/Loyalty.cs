namespace SalesApi.Dtos;

// The loyalty contracts — the first slice moved into SalesApi.Contracts as part
// of the API-led migration's loyalty vertical (step 5). The namespace is
// unchanged on purpose: moving a record between assemblies costs callers
// nothing, renaming its namespace costs every one of them a `using`.
//
// Note what is NOT here: LoyaltyEvent, LoyaltyAccountRule and the DbContext.
// Those are entities, they live in the System layer, and this project has no
// project references at all so it cannot reach them even by accident.

// --- Loyalty (P0) ---
// E20.1: `Window` is "lifetime" (the default) or "rolling"; `WindowMonths` is the rolling length and null for lifetime.
public record LoyaltyPolicyDto(
    bool Enabled, string EarnSource, int PointsInvoicePayment, int PointsAmcRenewal,
    string Window = "lifetime", int? WindowMonths = null);
public record LoyaltyPolicyInput(
    bool? Enabled, string? EarnSource, int? PointsInvoicePayment, int? PointsAmcRenewal,
    string? Window = null, int? WindowMonths = null);
public record LoyaltyEventLite(Guid Id, string SourceType, int Points, string RuleScope, DateTime OccurredAt);

// The account's own earn override, or the absence of one. `PointsInvoicePayment`
// / `PointsAmcRenewal` null means "follow the org's rule for that source" — a
// partial override is the normal case, see LoyaltyAccountRule.
public record LoyaltyAccountRuleDto(
    int? PointsInvoicePayment, int? PointsAmcRenewal, string? Reason,
    int OrgPointsInvoicePayment, int OrgPointsAmcRenewal);
public record LoyaltyAccountRuleInput(int? PointsInvoicePayment, int? PointsAmcRenewal, string? Reason);

// One tier. `MinPoints` is the LIFETIME balance at which it is reached; the
// tier an account holds is the highest whose threshold it clears, derived on
// read and never stored (see LoyaltyTierService).
public record LoyaltyTierDto(string Key, string Name, int MinPoints);

// The org's whole tier scheme. A LIST, not three named settings: an org chooses
// its own names, thresholds AND number of tiers (owner, 2026-08-28), and three
// columns would have made "three tiers" the shape of the feature.
public record LoyaltyTierConfigDto(List<LoyaltyTierDto> Tiers);

// `Tier` / `NextTier` / `PointsToNextTier` are DERIVED from Balance and the
// org's current thresholds on every read — there is no stored tier to drift
// from the ledger. Tier is null when the balance clears no threshold at all,
// which is a real state for an org whose lowest tier starts above zero.
public record AccountLoyaltyDto(
    bool Enabled, int Balance, List<LoyaltyEventLite> Events,
    LoyaltyTierDto? Tier = null, LoyaltyTierDto? NextTier = null, int? PointsToNextTier = null,
    // E20.1: the window Balance and Tier were counted over (Events stays the whole history either way).
    string Window = "lifetime", int? WindowMonths = null);

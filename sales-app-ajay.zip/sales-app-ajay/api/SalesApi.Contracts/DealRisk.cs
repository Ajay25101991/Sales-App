namespace SalesApi.Dtos;

// E5.6 deal risk (to-do/epics-ai-native-crm.md E5.6) — thresholds admin
// screen plus the per-lead read. Split into its own file, same reasoning as
// Stakeholders.cs's own header: one file per domain.

// GET/PUT /admin/deal-risk-settings — every threshold is an org setting
// (root CLAUDE.md: "every business rule that is policy goes in an org
// setting"), never a compiled constant. Mirrors AiCostPolicyDto's shape.
public record DealRiskSettingsDto(
    int QuietDaysMedium,
    int QuietDaysHigh,
    int CloseDatePushesMedium,
    int CloseDatePushesHigh,
    double StageAgeMedianMultiplierMedium,
    double StageAgeMedianMultiplierHigh,
    int StageAgeFallbackMediumDays,
    int StageAgeFallbackHighDays,
    int MinCompletedStageSamples,
    string RecalculationTiming);

// PUT body — every field optional so a partial save (one threshold at a
// time) doesn't clobber the rest, same "partial update" convention
// AiCostPolicyInput/AiCostPolicyStore.SaveAsync already follow.
public record DealRiskSettingsInput(
    int? QuietDaysMedium,
    int? QuietDaysHigh,
    int? CloseDatePushesMedium,
    int? CloseDatePushesHigh,
    double? StageAgeMedianMultiplierMedium,
    double? StageAgeMedianMultiplierHigh,
    int? StageAgeFallbackMediumDays,
    int? StageAgeFallbackHighDays,
    int? MinCompletedStageSamples,
    string? RecalculationTiming);

// One line of evidence behind a risk level — "kind, plain text, level
// contributed, citation ids (activity id / audit entry id / none) so the
// client can link to the timeline" (story brief item 2).
public record DealRiskEvidenceDto(
    string Kind,
    string Text,
    string Level,
    string? CitationKind,
    Guid? CitationId);

// GET /leads/{id}/risk when AI is off for the org — the owner decision
// verbatim shape (to-do/epics-ai-native-crm.md "E5 build decisions" item 2):
// "every risk read returns nothing while AiAvailability is not available".
public record DealRiskUnavailableDto(bool Available = false);

// GET /leads/{id}/risk when AI is on for the org. Level is Low/Medium/High,
// never a number (owner decision, "E5.6 deal score"). ReasonsText is the
// AI-worded gloss on the same deterministic evidence — null when AI has not
// (yet, or ever) worded this exact signal set; the evidence itself is never
// gated on that (story brief item 5).
public record DealRiskDto(
    bool Available,
    string Level,
    List<DealRiskEvidenceDto> Evidence,
    string? ReasonsText,
    DateTime ComputedAt);

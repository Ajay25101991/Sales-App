// The E4.7 tool registry contracts (design doc to-do/e4-ai-platform-design.md
// §7, §15 slice 9). Lives in SalesApi.Contracts — same reasoning Ai.cs's own
// header gives for AiToolSpec/AiToolCall living here: a concrete IAiTool
// implementation needs Process-layer dependencies, but the SHAPE a tool
// exposes (its spec, what it returns) names only Contracts types
// (RecordAccessContext, LeadView, JsonElement, Guid — no AppDbContext, no
// ClaimsPrincipal), so the interface itself can sit where every layer can see
// it, exactly like AiToolSpec/AiToolCall already do.
//
// AiToolSpec/AiToolRiskClass/AiToolCall themselves are NOT redefined here —
// they already exist in Ai.cs; this file only adds what slice 9 needs on top.
using SalesApi.Dtos;

namespace SalesApi.Services;

/// <summary>
/// The caller facts a tool needs to run — the SAME "facts about the caller
/// travel down as data" discipline root CLAUDE.md states for controllers,
/// carried one layer further so <see cref="IAiTool"/> never reads a
/// <c>ClaimsPrincipal</c> either. Mirrors exactly what a controller resolves
/// before calling into a Process method today:
/// <see cref="RecordAccessContext"/> (via <c>CallerContext.ForAsync</c>),
/// <see cref="LeadView"/> (contact-details/lead-values visibility + role, the
/// same shape <c>LeadsController.LeadViewOf</c> builds), and
/// <see cref="CanSeeAccountFinancials"/> (the <c>account_financials.view</c>
/// permission <c>AccountsController.CanSeeFullAccountFinancials</c> resolves)
/// — the one extra flag <see cref="LeadView"/> does not carry, needed by
/// <c>get_account</c>. <see cref="OrgId"/> is carried explicitly because
/// <c>TaskProcess.CreateAsync</c>'s own signature takes it as data (the same
/// "orgId" every controller reads off <c>User.OrgId()</c>), not inferred
/// inside a tool.
/// </summary>
public readonly record struct AiToolCallerFacts(
    RecordAccessContext Access,
    Guid? OrgId,
    LeadView LeadView,
    bool CanSeeAccountFinancials);

/// <summary>
/// What one tool call produced. <see cref="AiToolOutcomeStatus.Executed"/>/
/// <see cref="AiToolOutcomeStatus.Refused"/> are the only two an
/// <see cref="IAiTool"/> implementation itself ever returns — a tool has no
/// notion of the org's autonomy policy, so it never decides to merely suggest
/// or pause for approval; <see cref="Services.AiToolExecutor"/> is the only
/// place that constructs a <see cref="AiToolOutcomeStatus.Suggested"/>/
/// <see cref="AiToolOutcomeStatus.ApprovalRequired"/> result, and it does so
/// WITHOUT ever calling <see cref="IAiTool.ExecuteAsync"/> (design §7.2:
/// "do NOT execute").
/// </summary>
public enum AiToolOutcomeStatus { Executed, Suggested, ApprovalRequired, Refused }

/// <summary>
/// <paramref name="ResultJson"/> is the tool's own answer shape (a read
/// tool's masked DTO, a write tool's created-record echo, or — for
/// <see cref="AiToolOutcomeStatus.Suggested"/>/<see cref="AiToolOutcomeStatus.ApprovalRequired"/>
/// — the raw proposed args the caller offered, unexecuted) serialized as
/// JSON text, the same opaque-JSON-text posture <see cref="JsonSchema"/>
/// already takes for schema-shaped data in this codebase. <paramref name="CreatedRecordIds"/>
/// is empty unless the call executed a create.
/// </summary>
public sealed record AiToolResult(
    AiToolOutcomeStatus Status,
    string? Message,
    string? ResultJson,
    IReadOnlyList<Guid> CreatedRecordIds)
{
    public static AiToolResult Ok(string? resultJson, IReadOnlyList<Guid>? createdRecordIds = null) =>
        new(AiToolOutcomeStatus.Executed, null, resultJson, createdRecordIds ?? []);

    public static AiToolResult Refused(string message) =>
        new(AiToolOutcomeStatus.Refused, message, null, []);
}

/// <summary>
/// One concrete tool — a thin wrapper over ONE existing Process method,
/// giving the model the SAME result a manual API call would, under the SAME
/// caller permission check the controller for that call applies (design §7.1:
/// "the identical shape AutomationActionExecutor already proved" — except a
/// tool, unlike AutomationActionExecutor's system-actor actions, always runs
/// under the CALLING USER's own <see cref="AiToolCallerFacts"/>, never an
/// elevated access, because "the tool never grants a permission the caller
/// lacks" (design §7.2 item 1).
/// </summary>
public interface IAiTool
{
    AiToolSpec Spec { get; }

    /// <summary>One of <c>Models.AiActionTypes</c>' constants (SystemApi —
    /// not nameable from this Contracts file, so this is a plain string by
    /// convention, the same posture <c>AiActionPolicy.ActionType</c> itself
    /// takes). <see cref="Services.AiToolExecutor"/> looks this up against
    /// the org's <c>AiActionPolicy</c> row to decide autonomy.</summary>
    string ActionType { get; }

    /// <summary>
    /// Executes the underlying Process call for real — ONLY ever invoked by
    /// <see cref="Services.AiToolExecutor"/> when the org's autonomy for
    /// <see cref="ActionType"/> resolves to execute (read/automatic). Must
    /// never throw for a bad-argument or a permission refusal — both come
    /// back as <see cref="AiToolResult.Refused"/> (design §7.1: "validate
    /// args and return a clear error result, never throw into the model
    /// loop"). <paramref name="invocationId"/> is THIS call's own id (assigned
    /// client-side by the executor before this runs, the same "assigned
    /// client-side" convention <c>WebhookDelivery.Id</c> uses) — a tool that
    /// creates a record stamps it as that record's source ref, mirroring how
    /// <c>AutomationActionExecutor.CreateTaskAsync</c> stamps the CURRENT
    /// run's id, never the automation's.
    /// </summary>
    Task<AiToolResult> ExecuteAsync(
        AiToolCallerFacts caller, System.Text.Json.JsonElement args, Guid invocationId, CancellationToken ct = default);
}

// The E4.5 context engine contracts (design doc
// to-do/e4-ai-platform-design.md §5, §15 slice 7).
//
// Lives in SalesApi.Contracts, same reasoning Ai.cs (E4.1) already documents:
// a ProcessApi engine needs to hand this shape to a future skill-invoking
// caller without either side seeing AppDbContext or a ClaimsPrincipal.
// `RecordAccessContext`/`LeadView` are already Contracts types (CallerScope.cs,
// Leads.cs) — the very reason this engine can take the ALREADY-BUILT caller
// facts as plain data instead of resolving them itself, so this file needs no
// new project reference to sit next to them.
//
// Namespace stays `SalesApi.Services` for the interface/exception (Ai.cs's own
// convention: a plain-interface contract lives in `SalesApi.Services`
// regardless of which project the file is physically in) and `SalesApi.Dtos`
// for the wire-shaped record types (AiSkills.cs's convention for a DTO built
// to be rendered/serialised, even though this one is never itself an HTTP
// response body today — it is the SAME shape §5.3 says the execution log, the
// E5.1 evidence lines and Ask CRM's "why this answer" disclosure will all
// share, so it earns the DTO treatment now rather than three separate copies
// later). Two block-scoped namespaces, not two files, so the whole context
// engine's contract reads as one unit — same reason CallerScope.cs keeps
// `RecordAccessContext` and `CalendarDto` together.

using SalesApi.Services;

namespace SalesApi.Dtos
{
    /// <summary>
    /// One fact assembled into a prompt — either a lead record field ("Status:
    /// Qualified") or a timeline entry. <see cref="Kind"/> is either the fixed
    /// entity-field bucket ("lead_field") or, for a timeline-sourced item, the
    /// SAME <c>TimelineItemDto.Kind</c> string the timeline screen renders
    /// (<c>TimelineKinds</c>/a raw <c>DomainEvent.Type</c>) — one vocabulary,
    /// not a second one invented here, since the engine's ranking weights and
    /// the timeline's own icon-by-kind switch are describing the same facts.
    ///
    /// <see cref="SourceId"/> is null for a record-field item (there is no
    /// standalone id for "the lead's Status field" other than the lead
    /// itself, which the caller already knows from `entityId`) and the
    /// timeline item's own <c>SourceId</c> for a timeline-sourced item — see
    /// <see cref="AiContextSource"/> for how each mode is cited.
    /// </summary>
    public sealed record AiContextItem(string Kind, Guid? SourceId, string Text, int EstimatedTokens);

    // AiContextSource (the citation record) lives in Ai.cs beside AiRequest,
    // which carries the same list to the execution log. A timeline fact is cited
    // as (its kind, its SourceId, null); a record field as ("lead", null, field name).

    /// <summary>
    /// Ranked, budget-trimmed context ready to render into a prompt (design
    /// §5.1). <see cref="Sources"/> is exactly the citation for each item
    /// still present in <see cref="Items"/>, in the same order — no item
    /// survives trimming without a citation and no citation names a dropped
    /// item (design §5.2's budget rule).
    ///
    /// <paramref name="KnowledgeUnavailable"/> (E4.6 slice 12, design §6, this
    /// story's build item 6): true when the knowledge fan-out step could not
    /// run — AI not configured/ready, or the embed call itself refused
    /// (budget/feature/cap/unpriced model) — so the context was assembled
    /// WITHOUT any knowledge_chunk items, never by throwing. False (the
    /// default) covers both "no knowledge was needed" and "knowledge ran
    /// fine, possibly with zero matches" — a caller that wants to tell an
    /// apathetic zero-match from a genuine outage checks this flag, not the
    /// item count.
    /// </summary>
    public sealed record AiContext(
        IReadOnlyList<AiContextItem> Items, IReadOnlyList<AiContextSource> Sources, bool KnowledgeUnavailable = false);
}

namespace SalesApi.Services
{
    using SalesApi.Dtos;

    /// <summary>
    /// The E4.5 context engine (design §5) — a FAN-OUT over reads the caller
    /// has already been granted, never a second, parallel query path with its
    /// own notion of masking (design §5.2's opening paragraph, and root
    /// CLAUDE.md's "Authorization is enforced here, not in the DB").
    ///
    /// <paramref name="caller"/> is the SAME <see cref="RecordAccessContext"/>
    /// five controllers already build (root CLAUDE.md) — this engine takes it
    /// as a parameter and never constructs one from a `ClaimsPrincipal`
    /// itself, which would put an HTTP concept inside a Process-layer class.
    ///
    /// <paramref name="leadView"/>/<paramref name="canSeeFinancials"/> are the
    /// SAME plain-data permission facts <c>LeadsController.LeadViewOf()</c>
    /// already resolves once per request and hands to
    /// <c>LeadReadProcess.GetAsync</c>/<c>TimelineAsync</c> — not a second
    /// permission check, just the caller passing through what it already has,
    /// the same "facts about the caller travel down as data" discipline
    /// `AiRequest.OrgId` follows (Ai.cs). Entity types beyond "lead" will need
    /// their own equivalent bundle when they are added (design §15 slice 7
    /// supports lead only); this signature does not yet generalise past that,
    /// and does not try to.
    /// </summary>
    public interface IAiContextEngine
    {
        Task<AiContext> GetContextAsync(
            RecordAccessContext caller, LeadView leadView, bool canSeeFinancials,
            string entityType, Guid entityId, string purpose, int tokenBudget,
            CancellationToken ct = default);
    }

    /// <summary>
    /// The context engine's own refusal — mirrors
    /// <c>LeadReadProcess.Refusal</c>'s two-flag shape exactly (design §5.2:
    /// "a lead the caller cannot see gets the same not-found/forbidden
    /// outcome the existing read gives"), thrown rather than returned as a
    /// tuple because <see cref="IAiContextEngine.GetContextAsync"/>'s
    /// signature is fixed by design §5.1 to return <c>Task&lt;AiContext&gt;</c>
    /// alone — the same shape every one of its three planned consumers
    /// (execution log, E5.1 brief, Ask CRM) wants back on success.
    /// </summary>
    public sealed class AiContextRefusedException : Exception
    {
        public bool NotFound { get; }
        public bool Forbidden { get; }

        public AiContextRefusedException(string reason, bool notFound = false, bool forbidden = false) : base(reason)
        {
            NotFound = notFound;
            Forbidden = forbidden;
        }
    }
}

// SavedViews contracts (E3.8 — saved views and column chooser). Same
// split-per-domain convention as Picklists.cs beside it: this project has no
// references at all, so anything the Experience layer must be able to return
// has to live here.

using System.Text.Json;

namespace SalesApi.Dtos;

/// <summary>
/// One saved view as the client sees it. <c>Definition</c> is returned
/// verbatim (never per-viewer-filtered) — a saved view's DEFINITION is not a
/// masked figure; only the RESULT of running it through the real list
/// endpoint is, and that endpoint already applies the viewer's own masking
/// (see SavedView's own class remarks). <c>CanEdit</c> tells the client
/// whether to offer rename/share/delete for THIS caller, computed the same
/// way the write endpoints re-check it, so the UI can never offer an action
/// the server would then refuse.
/// </summary>
public record SavedViewDto(
    Guid Id, string List, Guid? OwnerId, string? OwnerName, string Name,
    JsonElement Definition, string Visibility, List<Guid> SharedTeamIds,
    bool IsOrgDefault, bool IsMyDefault, bool PinnedToOverview,
    DateTime CreatedAt, DateTime? UpdatedAt, bool CanEdit,
    // Accounts rework (decision 14): a shipped, org-visible view. Not editable or deletable (CanEdit is false); copy it
    // with POST /saved-views. OwnerId is null for these. BuiltInKey is stable across renames.
    bool IsBuiltIn = false, string? BuiltInKey = null);

/// <summary>Create or update a saved view. <c>Definition</c> is validated
/// against <c>List</c>'s own accepted filter/sort/column (or, for
/// <c>explore</c>, query-spec) vocabulary — see SavedViewVocabulary — with
/// unknown keys refused, never silently dropped. <c>SharedTeamIds</c> is only
/// meaningful when <c>Visibility == "team"</c>; sent null/omitted otherwise.</summary>
public record SavedViewInput(
    string? List, string? Name, JsonElement? Definition, string? Visibility,
    List<Guid>? SharedTeamIds, bool? PinnedToOverview);

public record SavedViewRenameInput(string? Name);

public record SetOrgDefaultInput(bool OrgDefault);
public record SetMyDefaultInput(bool MyDefault);
public record PinToOverviewInput(bool Pinned);

namespace SalesApi.Dtos;

// "Apply to existing leads" (owner decision 2026-10-03, to-do/playbook-assignment-todo.md
// "Owner decisions (2026-10-03)") — moves a lead onto its TEAM's assigned playbook when the
// team has exactly one. Preview-then-apply, the same two-step shape as
// PlaybookService.PublishPreviewAsync/PublishAsync: nothing changes until an admin
// confirms, and the apply is refused if the underlying data moved since the preview ran.

/// <summary>Wire values for a stage-map row's <c>mapped_by</c> — which of the three rules
/// (server/playbook-assignment-todo.md "Stage mapping per lead") produced the target
/// stage.</summary>
public static class PlaybookAssignmentMappedBy
{
    public const string SameKey = "same_key";
    public const string Canonical = "canonical";
    public const string Fallback = "fallback";
}

public record PlaybookOptionDto(Guid Id, string Name);

/// <summary>One (from stage -> to stage) bucket within a from-playbook group, with how many
/// leads land there and which rule decided it.</summary>
public record StageMapEntryDto(string FromStage, string FromLabel, string ToStage, string ToLabel, int Count, string MappedBy);

/// <summary>Every lead moving from ONE source playbook (or none — <see cref="FromPlaybookId"/>
/// null means "the org's default pipeline") onto a team's target playbook, broken down by
/// stage mapping.</summary>
public record TeamMoveGroupDto(Guid? FromPlaybookId, string? FromPlaybookName, int Count, List<StageMapEntryDto> StageMap);

/// <summary>One team whose leads can be placed unambiguously — it has exactly one LIVE
/// assigned playbook, which is why it is not in <see cref="PlaybookApplyPreviewDto.NeedsChoice"/>.</summary>
public record TeamApplyPreviewDto(
    Guid TeamId, string TeamName, Guid PlaybookId, string PlaybookName,
    List<TeamMoveGroupDto> Moves, int AlreadyOnIt);

/// <summary>A team with SEVERAL live assigned playbooks — not auto-placed; an admin must
/// pick one of <see cref="PlaybookOptions"/> (owner decision 2026-10-03).</summary>
public record NeedsChoiceTeamDto(Guid TeamId, string TeamName, List<PlaybookOptionDto> PlaybookOptions, int LeadCount);

public record TeamWithoutPlaybookDto(Guid TeamId, string TeamName, int LeadCount);

/// <summary>Leads this action can never place: no team at all, or a team with zero live
/// assigned playbooks.</summary>
public record UnplaceableDto(int NoTeam, List<TeamWithoutPlaybookDto> TeamWithoutPlaybook);

public record PlaybookApplyPreviewDto(
    List<TeamApplyPreviewDto> Teams,
    List<NeedsChoiceTeamDto> NeedsChoice,
    UnplaceableDto Unplaceable,
    int TotalMoving,
    /// <summary>Opaque — echoed back on POST /playbooks/apply-to-existing. Encodes a
    /// fingerprint of every input the preview was computed from (lead team/playbook/
    /// status, each team's live playbook candidates, the canonical axis, and every
    /// referenced playbook's stage snapshot) — NOT the resolved move list itself, since
    /// the admin's choices for "needs a choice" teams are only known at apply time and
    /// must still count as applying "exactly the previewed set".</summary>
    string PreviewToken);

/// <summary>One "needs a choice" team's resolution, submitted with the apply call.</summary>
public record PlaybookApplyChoiceInput(Guid TeamId, Guid PlaybookId);

public record PlaybookApplyInput(string? PreviewToken, List<PlaybookApplyChoiceInput>? Choices);

public record PerTeamApplyResultDto(Guid TeamId, string TeamName, int Moved);

public record PlaybookApplyResultDto(int Moved, List<PerTeamApplyResultDto> PerTeam);

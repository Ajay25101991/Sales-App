// The MessageTemplates contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Message templates ---
// E10.9: Subject (for email templates) and Purpose (a server-known use, e.g. "engagement_letter_email"; null for a plain snippet) are optional.
public record MessageTemplateDto(Guid Id, string Name, string Body, int SortOrder, DateTime CreatedAt, string? Subject = null, string? Purpose = null,
    // E16.3: the language of this wording ("en", "ar"); one row per (purpose, language), English is the fallback.
    string Language = "en");
// E16.3: Purpose + Language on a create make the wording of a server-known purpose in another language (e.g. the Arabic IRL email); both are ignored on an update.
public record MessageTemplateInput(string? Name, string? Body, int? SortOrder, string? Subject = null, string? Purpose = null, string? Language = null);

namespace SalesApi.Dtos;

// E21 - email campaigns. Wire keys are snake_case (JsonNamingPolicy.SnakeCaseLower). Every /campaigns endpoint needs the campaigns.send permission;
// the from-address and settings WRITES need settings.manage.

// ---- settings: marketing from-addresses, send rate, SES overrides ---------------------------------------------------------------------

/// <summary>POST / PUT /campaigns/from-addresses. The address must be on a domain verified in SES; the display name is the "From" label the reader sees.</summary>
public record MarketingFromAddressInput(string? Address, string? DisplayName);

public record MarketingFromAddressDto(Guid Id, string Address, string DisplayName, DateTime CreatedAt);

/// <summary>GET / PUT /campaigns/settings. <c>SendsPerSecond</c> is the org's throttle (default 1). <c>SesRegion</c> / <c>SesConfigurationSet</c> are the org's
/// overrides of the deployment's SES settings (null = use the deployment's); <c>SesConfigured</c> is whether marketing mail can be sent at all right now.</summary>
public record CampaignSettingsDto(int SendsPerSecond, string? SesRegion, string? SesConfigurationSet, bool SesConfigured, string? SesProblem);

/// <summary>PUT /campaigns/settings. A null field is left as it is; an empty string clears an SES override.</summary>
public record CampaignSettingsInput(int? SendsPerSecond, string? SesRegion, string? SesConfigurationSet);

// ---- campaigns ------------------------------------------------------------------------------------------------------------------------

/// <summary>One language's wording: a message template (GET /message-templates) whose own language is <c>Language</c>.</summary>
public record CampaignTemplateInput(string? Language, Guid? MessageTemplateId);

public record CampaignTemplateDto(string Language, Guid MessageTemplateId, string? TemplateName, string? Subject);

/// <summary>POST /campaigns and PUT /campaigns/{id} (a draft only). <c>SavedViewId</c> is a saved view of the contacts list; <c>ContactRole</c> narrows it to
/// contacts holding that buying role on a deal; <c>ContactOwnRole</c> narrows it to contacts whose own buying roles include that role (both set = both must match); <c>Templates</c> must include <c>FallbackLanguage</c>.</summary>
public record CampaignInput(
    string? Name, Guid? SavedViewId, string? ContactRole, string? ContactOwnRole, string? FallbackLanguage, Guid? FromAddressId, string? ReplyTo,
    List<CampaignTemplateInput>? Templates);

/// <summary>The per-campaign figures. <c>Unsubscribed</c> counts recipients who used this campaign's unsubscribe link.</summary>
public record CampaignTotalsDto(int Queued, int Sent, int Suppressed, int Failed, int Bounced, int Complained, int Unsubscribed);

/// <summary><c>Status</c> is draft | scheduled | sending | sent | cancelled. <c>FailureReason</c> says why a campaign was stopped, or why a sending one is paused.</summary>
public record CampaignDto(
    Guid Id, string Name, Guid SavedViewId, string? ContactRole, string? ContactOwnRole, string FallbackLanguage, Guid FromAddressId, string? FromAddress, string? FromName,
    string? ReplyTo, string Status, DateTime? ScheduledAt, Guid? ScheduledById, DateTime? StartedAt, DateTime? CompletedAt, DateTime? CancelledAt,
    string? FailureReason, List<CampaignTemplateDto> Templates, CampaignTotalsDto Totals, Guid CreatedById, DateTime CreatedAt, DateTime? UpdatedAt);

/// <summary>POST /campaigns/{id}/schedule. <c>Now</c> true (or no time) sends as soon as the worker next ticks; otherwise at <c>ScheduledAt</c> (UTC).</summary>
public record CampaignScheduleInput(DateTime? ScheduledAt, bool? Now);

// ---- previews ------------------------------------------------------------------------------------------------------------------------

/// <summary><c>Outcome</c> is will_send | opted_out | undeliverable | no_email | duplicate (the same address as an earlier contact).</summary>
public record CampaignAudienceSampleDto(Guid ContactId, string Name, string? Email, string Language, string Outcome);

/// <summary>GET /campaigns/{id}/recipients-preview: who the campaign would reach if it started now, with the caller's record access.</summary>
public record CampaignAudienceDto(
    int Total, int WillSend, int OptedOut, int Undeliverable, int NoEmail, int Duplicate, List<CampaignAudienceSampleDto> Sample);

/// <summary>GET /campaigns/{id}/preview?contact_id=: the exact message one contact would get (the unsubscribe link in it is a placeholder).</summary>
public record CampaignPreviewDto(string Language, string FromAddress, string? FromName, string? ReplyTo, string Subject, string TextBody, string HtmlBody);

/// <summary>POST /campaigns/{id}/test-send. The mail goes to the CALLER's own address, never to the contact whose details fill the merge fields.</summary>
public record CampaignTestSendInput(string? Language, Guid? ContactId);

public record CampaignTestSendDto(bool Sent, string To, string? Reason);

// ---- results -------------------------------------------------------------------------------------------------------------------------

/// <summary><c>Status</c> is queued | sent | suppressed | failed | bounced | complained; <c>Error</c> is the reason (opted_out, bounced, a failure...).</summary>
public record CampaignRecipientDto(
    Guid Id, Guid ContactId, string Address, string Language, string Status, string? Error, DateTime QueuedAt, DateTime? SentAt, DateTime? UnsubscribedAt);

public record CampaignRecipientPageDto(List<CampaignRecipientDto> Items, int Total, int Limit, int Offset);

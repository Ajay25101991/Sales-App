using System.Text.Json;

namespace SalesApi.Dtos;

// E3.10 — "Email me this": an owner's standing request to have a report
// mailed to them on a cadence. See SalesApi.Models.ReportSchedule for the
// entity and SalesApi.ProcessLayer.Reports.ReportScheduleProcess for the
// render/send path.

public record ReportScheduleDto(
    Guid Id,
    string ReportKind,
    JsonElement Parameters,
    string CadenceType,
    int? WeeklyDay,
    int MonthlyDay,
    int Hour,
    string Format,
    bool Enabled,
    DateTime? LastSentAt,
    DateTime CreatedAt);

public record ReportScheduleInput(
    string ReportKind,
    JsonElement? Parameters,
    string CadenceType,
    int? WeeklyDay,
    int? MonthlyDay,
    int? Hour,
    string Format,
    bool? Enabled);

namespace SalesApi.Dtos;

/// <summary>
/// Policy VOCABULARIES that contracts use as default parameter values.
///
/// These are the words the wire speaks — "credit", "clamp", "write_off" — and a
/// record that defaults a field to one of them needs the constant visible from
/// the Contracts project, which by design references nothing. The BEHAVIOUR each
/// word selects stays entirely in the System layer; only the vocabulary lives
/// here.
///
/// The System classes that own the behaviour (`PaymentSettlement`,
/// `QuoteDiscount`) now FORWARD to these rather than declaring their own copies,
/// exactly as `LoyaltyPolicyService` forwards to `LoyaltyRules`. Two spellings
/// of one word is two words: a stored blob written against one and validated
/// against the other passes until the day someone edits one of them.
/// </summary>
public static class OverpaymentPolicies
{
    public const string Credit = "credit";
    public const string Refuse = "refuse";
    public const string CapAndWarn = "cap_and_warn";
}

public static class ResidualSettlementPolicies
{
    public const string DiscountTaken = "discount_taken";
    public const string WriteOff = "write_off";
}

public static class ResidualTriagePolicies
{
    public const string Dismissible = "dismissible";
    public const string AgeFilter = "age_filter";
    public const string ListOnly = "list_only";
}

public static class QuoteDiscountPolicies
{
    public const string OverDiscountAllow = "allow";
    public const string OverDiscountClamp = "clamp";
}

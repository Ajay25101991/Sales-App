// The MCP server's caller and result contracts (owner decisions 2026-11-17, to-do/mcp-server-design.md).
// Plain values only (no EF, no HTTP): McpAccess (System) builds an McpCaller from a ClaimsPrincipal and the database, and every Process
// class under the MCP tools receives it as DATA - the same "facts about the caller travel down" rule root CLAUDE.md states for controllers.
using SalesApi.Dtos;

namespace SalesApi.Services;

/// <summary>
/// WHO is on the other end of an MCP call. A person acts as themselves (<see cref="IsApiKey"/> false, <see cref="Scopes"/> null = no scope
/// limit, everything their roles show them). An org API key acts as the org: <see cref="Facts"/> carries the org-level key view (the same
/// masking a partner-API key read gets) and <see cref="Scopes"/> is what the key was granted.
/// </summary>
/// <param name="ActorId">The person's id; for a key, the key's id (it has no person; used only where a call needs a stable actor, e.g. the deal brief cache).</param>
/// <param name="CanSeeFinancials">The <c>financials.view</c> permission (timeline money, deal brief); a key never holds it.</param>
/// <param name="CanViewTeam">The <c>team.view</c> or <c>team.manage</c> permission (the people roster); a key reads the roster through its directory scope instead.</param>
public sealed record McpCaller(
    AiToolCallerFacts Facts,
    Guid ActorId,
    bool IsApiKey,
    bool CanSeeFinancials,
    bool CanViewTeam,
    IReadOnlySet<string>? Scopes,
    bool ContactDetailsPermission = false)
{
    /// <summary>
    /// What <c>AccountsController</c> / <c>ContactsController</c> require before any read ([RequireSensitiveAccess(ContactDetails)]): the caller's role
    /// can reach contact details at all (real or masked text). A caller who cannot gets no account / contact tool.
    /// </summary>
    public bool CanReachContactDetails =>
        View.Sensitive is { } s ? SensitiveLevels.CanReach(s.RoleLevel(SensitiveCategories.ContactDetails)) : View.CanSeeContactDetails;

    public RecordAccessContext Access => Facts.Access;
    public LeadView View => Facts.LeadView;
    public Guid? OrgId => Facts.OrgId;

    /// <summary>A person has every scope (their roles are the limit); a key only what it was granted.</summary>
    public bool Has(string scope) => Scopes is null || Scopes.Contains(scope);

    /// <summary>The plain-language refusal for a missing scope; null when the caller holds all of them.</summary>
    public string? MissingScope(params string[] scopes)
    {
        foreach (var s in scopes)
            if (!Has(s)) return $"This API key does not have the '{s}' scope.";
        return null;
    }
}

/// <summary>What an MCP tool call produced: JSON text for the AI tool, or a plain-language refusal (returned as an MCP error).</summary>
public sealed record McpToolResult(string? Json, string? Refusal)
{
    public static McpToolResult Ok(string json) => new(json, null);
    public static McpToolResult Refused(string reason) => new(null, reason);
    public bool IsRefusal => Refusal is not null;
}

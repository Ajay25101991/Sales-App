// Team mailboxes (owner decisions 2026-10-14, to-do/e6-capture-design.md §14): the org-owned addresses the org's own
// Microsoft 365 app reads, and the review list of unknown-sender email to them. Contracts so Experience can name them.

namespace SalesApi.Dtos;

/// <summary>One team address on the Microsoft 365 screen: its settings, its sync health, and its pending review work.</summary>
public record SharedMailboxDto(
    Guid Id, string Address, string DisplayName, string LeadSource, Guid? TeamId, string? TeamName,
    string UnknownSenderPolicy, bool Enabled, string Status, string? LastError, DateTime? LastSyncedAt,
    SyncCountersDto Counters, int PendingCount, DateTime CreatedAt, DateTime UpdatedAt, bool ReadSignatures = true);

/// <summary>Create and update both take the whole object (PUT semantics): a null <see cref="TeamId"/> means "no team".
/// <see cref="ReadSignatures"/> (wire <c>read_signatures</c>): null = leave as is (a new address starts ON).</summary>
public record SharedMailboxInput(
    string? Address, string? DisplayName, string? LeadSource, Guid? TeamId, string? UnknownSenderPolicy, bool? Enabled,
    bool? ReadSignatures = null);

/// <summary>"Check access" result: <see cref="Message"/> is a plain sentence either way.</summary>
public record SharedMailboxCheckDto(bool Ok, string Message);

/// <summary>One row on the review list. <see cref="Body"/> is plain text, truncated.</summary>
public record EmailUnmatchedMessageDto(
    Guid Id, Guid MailboxId, string MailboxAddress, string MailboxName,
    string FromAddress, string? FromName, string Subject, string Body,
    DateTime ReceivedAt, string WebLink, string Status, Guid? LinkedLeadId, EmailReadDto? Read = null);

/// <summary>What Create lead would fill in for a review row (wire <c>read</c>): the From display name plus the phone and
/// company read from the signature. The whole block is null when the mailbox's "read signatures" switch is off.</summary>
public record EmailReadDto(string? Name, string? Company, string? Phone);

/// <summary>Optional body of POST email/unmatched/{id}/create-lead: what the person edited. A property left out (null)
/// takes the value that was read; a blank string means "leave it blank".</summary>
public record EmailCreateLeadInput(string? Name, string? Company, string? Phone);

public record EmailLinkUnmatchedInput(Guid LeadId);

/// <summary>GET email/unmatched/summary: whether the caller may work any team mailbox (show the menu item) and how
/// many pending rows are in the ones they may work.</summary>
public record EmailUnmatchedSummaryDto(bool CanWork, int PendingCount);

/// <summary>
/// Which team mailboxes' review lists the caller may work, as DATA (the controller computes it from the token:
/// manageSettings, plus the caller's live team memberships). <see cref="All"/> = every mailbox;
/// otherwise a mailbox is workable when its team is in <see cref="TeamIds"/>.
/// </summary>
public readonly record struct EmailTriageScope(bool All, Guid[] TeamIds)
{
    public bool Permits(Guid? mailboxTeamId) =>
        All || (mailboxTeamId is { } id && Array.IndexOf(TeamIds ?? [], id) >= 0);

    /// <summary>Nothing at all: not a manager and on no team.</summary>
    public bool IsEmpty => !All && (TeamIds is null || TeamIds.Length == 0);
}

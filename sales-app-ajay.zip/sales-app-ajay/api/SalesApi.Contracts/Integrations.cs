// The Integrations contracts (API-led migration, step 8).
//
// Moved out of IntegrationsController's nested records so Experience — which
// cannot see SalesApi.SystemApi at all — can still return them. The shapes
// and property names are unchanged from the controller's originals, so the
// JSON the directory screen already binds to (JsonNamingPolicy.SnakeCaseLower)
// does not move.

namespace SalesApi.Dtos;

public record IntegrationFieldDto(string Name, string Label, bool Secret, bool Required, string HelpText);

public record ConnectorSummaryDto(
    string Key, string Label, string Category, string OwnedBy, string Summary,
    IntegrationFieldDto[] Fields, string Status, string StatusCaption,
    string? ConfiguredByName, DateTime? ConfiguredAt, DateTime? UpdatedAt,
    // E6.1 (design doc to-do/e6-capture-design.md §2.6/§9 slice 3) — how many
    // reps currently have a live connection. Null for every Org-owned
    // connector (the concept doesn't apply); populated for PerUser ones
    // instead of a credential form.
    int? ConnectedCount = null,
    // Integrations audit (to-do/integrations-audit.md): when the last inbound webhook delivery was accepted, and when the last one
    // was rejected or failed - UTC timestamps from the incoming log (null = none recorded, or not an inbound connector). The caption
    // above is server text that already says it in words; these let the client show an exact time.
    DateTime? LastEventAt = null, DateTime? LastErrorAt = null);

public record ConnectorDetailDto(ConnectorSummaryDto Summary, Dictionary<string, string?> Values);

public record SaveConnectorCredentialsInput(Dictionary<string, string>? Values);

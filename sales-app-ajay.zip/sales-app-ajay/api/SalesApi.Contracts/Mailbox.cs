// E6.1/E6.2 mailbox sync contracts (design doc to-do/e6-capture-design.md
// §2.4). Moved out to Contracts, same reasoning Integrations.cs already
// gives: Experience cannot see SalesApi.SystemApi at all, so the shapes it
// returns have to live somewhere both ProcessApi and ExperienceApi can see.

namespace SalesApi.Dtos;

/// <summary>Raw, unambiguous counts (design §3.4/§9's "never a composite
/// health score" rule) — a rep's Connected-accounts card and the admin
/// "who is connected" list both bind to this exact shape.</summary>
public record SyncCountersDto(int Synced, int Logged, int Skipped, int Errors);

/// <summary>One rep's mailbox/calendar connection. <see cref="OwnerName"/>/
/// <see cref="OwnerEmail"/> are populated on the admin list (design §7.2);
/// the self "my status" read is for the caller's own row, so they are
/// harmlessly redundant there rather than omitted, keeping one DTO shape for
/// both consumers.</summary>
public record MailboxConnectionDto(
    Guid Id, string ConnectorKey, string MailboxUpn, string Status,
    DateTime? LastSyncedAt, DateTime ConnectedAt, SyncCountersDto Counters,
    Guid OwnerId, string? OwnerName, string? OwnerEmail);

public record MailboxAuthorizeUrlDto(string AuthorizeUrl);

/// <summary>GET /mailbox/status's actual response shape (design §13 item 4,
/// owner 2026-09-28): <see cref="Enabled"/> is this DEPLOYMENT's
/// Mailbox:Enabled switch, so the client can show "Coming soon" instead of
/// Connect when it is false — independently of whether this rep already has
/// a connection (<see cref="Connection"/> stays honest either way; an
/// existing connection is never hidden just because new connects are
/// paused).</summary>
public record MailboxStatusDto(bool Enabled, MailboxConnectionDto? Connection);

public record MailboxDisconnectedDto(bool Disconnected);

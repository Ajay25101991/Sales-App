// The accounts + leads rework contracts (owner decisions 2026-10-14, to-do/accounts-rework-design.md).
//
// New shapes only; every change to an EXISTING record elsewhere is an optional trailing member (additive wire).
// The wire is snake_case (JsonNamingPolicy.SnakeCaseLower) like the rest of the API.

namespace SalesApi.Dtos;

/// <summary>What a record's "next step" is: the soonest of its open tasks, its open leads' follow-up dates and its next
/// synced calendar meeting (decision 3 + L3). <c>Kind</c> is <c>task</c> | <c>follow_up</c> | <c>meeting</c>.</summary>
/// <para>For <c>kind=meeting</c> only (null otherwise): <c>StartAt</c> (same instant as <c>DueAt</c>), <c>AttendeeCount</c>
/// (everyone invited, as stored) and <c>WebLink</c> (the Outlook link the timeline uses for a synced meeting).</para>
public record NextStepDto(string Kind, string Title, DateTime DueAt, bool Overdue, NextStepRecordDto Record,
    DateTime? StartAt = null, int? AttendeeCount = null, string? WebLink = null);

/// <summary>Which record the step lives on: <c>task</c> (the task's id), or <c>lead</c> (the deal whose follow-up date
/// or meeting it is).</summary>
public record NextStepRecordDto(string Type, Guid Id);

/// <summary>POST /accounts/{id}/activities. <c>Type</c> is note | call | email | meeting (default note). <c>LeadId</c>
/// optionally files the activity under one of the account's leads, which makes it an ordinary lead activity (also
/// stamped with the account). <c>NextFollowUpAt</c> (L6) sets that lead's next follow-up in the same step, so it needs a
/// <c>LeadId</c>.</summary>
public record AccountActivityInput(string? Type, string? Body, Guid? LeadId = null, DateTime? NextFollowUpAt = null);

/// <summary>One skipped row of a bulk action or a lead move: which record, and why.</summary>
public record BulkSkipDto(Guid Id, string Code, string Reason);

/// <summary>POST /accounts/bulk. <c>Action</c> is assign | tag_add | tag_remove | set_status | delete. Result is the lead bulk shape
/// (<see cref="BulkResult"/>) with the per-row reasons alongside.</summary>
/// <summary>Exactly ONE of <c>Ids</c> (ticked rows) or <c>Match</c> ("select all N matching") is sent; both or neither is a 400.</summary>
public record AccountBulkInput(
    List<Guid>? Ids, string? Action, Guid? OwnerId = null, bool? MoveOpenLeads = null, Guid? TagId = null, bool? DeleteDeals = null,
    AccountMatchInput? Match = null,
    // Action set_status: the status KEY to set (validated against the org's account_statuses picklist).
    string? Status = null);

/// <summary>"Select all N matching" on POST /accounts/bulk: the list endpoint's own search + filters, in the same shape and with the
/// SAME wire names as GET /accounts (so the client sends the object it already builds for the list). Resolved server-side to ids through
/// the same filtered query the list and GET /accounts/count run, inside what the caller may see. <c>Filters</c> is the JSON string the
/// <c>filters</c> query parameter carries. Paging and sorting are not part of a match.</summary>
public record AccountMatchInput(
    string? Search = null,
    double? Similarity = null,
    string? Owner = null,
    string? Industry = null,
    [property: System.Text.Json.Serialization.JsonPropertyName("hasOpenValue")] bool? HasOpenValue = null,
    string? Filters = null);

public record AccountBulkResult(int Updated, int Skipped, List<BulkSkipDto> Skips, List<BulkSkipDto>? LeadSkips = null, int? LeadsMoved = null);

/// <summary>POST /accounts/{id}/assign. <c>MoveOpenLeads</c> also moves each of the account's open leads through the lead
/// assign path (its own rules run per lead); the leads that could not move come back in <c>LeadSkips</c>.</summary>
public record AccountAssignInput(Guid? OwnerId, bool? MoveOpenLeads = null);

public record AccountAssignResult(AccountDto Account, int LeadsMoved, List<BulkSkipDto> LeadSkips);

/// <summary>GET /accounts/{id}/delete-preview: what the confirm dialog states. The account delete keeps today's effect
/// (contacts deleted, leads and invoices unlinked); <c>DealsDeletable</c> / <c>DealsBlocked</c> split its leads for the
/// "also delete its deals" tick box (a deal with issued invoices is blocked).</summary>
public record AccountDeletePreviewDto(
    int ContactsDeleted, int LeadsUnlinked, int InvoicesUnlinked, int DealsDeletable, int DealsBlocked, List<BlockedDealDto> BlockedDeals);

/// <summary>A deal that stops "also delete its deals". <c>Code</c> is <c>invoices_issued</c> (it has issued invoices; <c>IssuedInvoices</c> counts them) or
/// <c>not_allowed</c> (the caller may not delete that deal); <c>Reason</c> is a sentence for the confirm text.</summary>
public record BlockedDealDto(Guid Id, string Name, int IssuedInvoices, string? Code = null, string? Reason = null);

/// <summary>One lead's answer to "may this deal be deleted?" - the issued-invoice guard.</summary>
public record LeadDeleteBlockDto(Guid LeadId, string Name, int IssuedInvoices);

/// <summary>Org settings added by the rework (decisions 6, 8, 14). All additive on GET/PUT /settings/accounts-rework.</summary>
public record AccountsReworkSettingsDto(bool DealRequiresContact, string AccountDuplicateMode, int ViewsNoContactDays, int ViewsRenewalDays, int BulkMatchLimit = 5000,
    string ProposalSentGate = "ever_sent", string EngagementLetterSignedRule = "all_sent",
    // E-invoicing IRL: days a client's IRL link stays open after it is sent (1-365, default 30).
    int IrlLinkDays = 30,
    // E17.5 online payment: days a "Pay now" link for an invoice stays valid (1-365, default 30).
    int PayLinkDays = 30);
public record AccountsReworkSettingsInput(bool? DealRequiresContact, string? AccountDuplicateMode, int? ViewsNoContactDays, int? ViewsRenewalDays, int? BulkMatchLimit = null,
    string? ProposalSentGate = null, string? EngagementLetterSignedRule = null, int? IrlLinkDays = null, int? PayLinkDays = null);

/// <summary>POST /accounts/bulk/ids and POST /leads/bulk/ids: the ids a "select all N matching" resolves to (the same set the bulk
/// action would act on), so the client can run the action in small batches with progress instead of one long request.</summary>
public record BulkIdsResult(List<Guid> Ids);

using System.Text.Json;

namespace SalesApi.Dtos;

// The automations vertical's wire shapes (E2.2 slice 1 — data model + draft
// CRUD + publish/disable/restore/hard-delete, no runtime). Field names follow
// the same PascalCase-to-snake_case convention every other Dtos file uses
// (JsonNamingPolicy.SnakeCaseLower).

/// <summary>A library row — everything the `/automations` list renders.</summary>
public record AutomationSummaryDto(
    Guid Id,
    string Name,
    string? Description,
    bool IsBuiltIn,
    bool Enabled,
    int? LiveVersion,
    int? DraftVersion,
    DateTime? PublishedAt,
    DateTime? ArchivedAt,
    /// <summary>E7.1 stable identity (design doc §10 owner answer 5) —
    /// package export/import identifies this automation by this key across
    /// orgs, never <see cref="Id"/>.</summary>
    string Key = "");

/// <summary>One automation WITH the trigger/condition/actions a builder can
/// load and edit. Prefers the draft; falls back to the live version so a
/// never-drafted live automation still opens with its real definition.</summary>
public record AutomationDetailDto(
    Guid Id,
    string Name,
    string? Description,
    bool IsBuiltIn,
    bool Enabled,
    int? LiveVersion,
    int? DraftVersion,
    DateTime? PublishedAt,
    DateTime? ArchivedAt,
    JsonElement Trigger,
    JsonElement Condition,
    JsonElement Actions,
    /// <summary>E7.1 stable identity (design doc §10 owner answer 5).</summary>
    string Key = "");

/// <summary>Result of PUT .../draft.</summary>
public record AutomationDraftResultDto(int Version, string Status);

/// <summary>Result of POST .../publish.</summary>
public record AutomationPublishResultDto(int Version, string Status, DateTime? PublishedAt);

/// <summary>One row of an automation's version history (GET .../versions).</summary>
public record AutomationVersionDto(
    int Version,
    string Status,
    DateTime CreatedAt,
    Guid? CreatedById,
    string? CreatedByName,
    DateTime? PublishedAt,
    Guid? PublishedById,
    string? PublishedByName,
    JsonElement Trigger,
    JsonElement Condition,
    JsonElement Actions);

/// <summary>
/// The org's automation limits (design doc §6, owner answer §14.2, binding):
/// max concurrently-live automations, max actions executed org-wide per
/// minute, and max cross-rule chain depth. Slice 1 only ENFORCES the live-
/// automation cap (on publish, since that is the only thing this slice can
/// produce) — the action budget and chain-depth cap belong to the runtime
/// (later slices) and are stored here now so the settings screen and the
/// builder can show them from day one.
/// </summary>
public record AutomationLimitsDto(int MaxLiveAutomations, int MaxActionsPerMinute, int MaxChainDepth);

public record AutomationLimitsInput(int? MaxLiveAutomations, int? MaxActionsPerMinute, int? MaxChainDepth);

/// <summary>One row of the run log (GET /automations/{id}/runs, E2.2 slice 2,
/// design doc §12 slice 2, fields below added slice 16 "run log details").
/// <see cref="TriggerEventType"/> is null only if the
/// triggering event has since been purged by retention (design doc §2's
/// "same AppSetting-driven default as domain_events") — the run row itself
/// always outlives that, per <see cref="RecordId"/>/<see cref="RecordType"/>
/// being copied onto the row rather than read through the FK.</summary>
/// <param name="WaitingUntil">The pending <c>AutomationWaitTicket.ResumeAt</c>
/// for this run — set ONLY for a <c>wait_n_days</c> pause with a real due
/// date (<c>ApprovalRequestId == null</c> on that ticket); null for every
/// other status, including a <c>request_approval</c> pause, whose ticket
/// carries a "far future" placeholder <c>ResumeAt</c> per that column's own
/// doc comment, not a date worth showing.</param>
/// <param name="WaitingOnApprovalId">The pending ticket's
/// <c>ApprovalRequestId</c> when this run is paused on a <c>request_approval</c>
/// decision; null otherwise (including once the ticket resumes — a run whose
/// wait ticket has moved to 'resumed'/'cancelled' reports neither field).</param>
/// <param name="RecordName">The lead/account name or invoice number the run
/// acted on, resolved the same way <c>AutomationPreviewer.ResolveRecordNameAsync</c>
/// already does for preview rows — null for a record type with no read path
/// (or no <see cref="RecordId"/> at all, e.g. an unmatched run).</param>
/// <param name="RetryOfRunId">Set only when THIS row is itself the retry of
/// another run's failed actions (design §10, 2026-09-27 "automation reach"
/// follow-up) — <see cref="Models.AutomationRun.RetryOfRunId"/>.</param>
/// <param name="RetriedByRunId">The FORWARD link: set on the ORIGINAL run once
/// it has been retried, naming the retry row, so the run log can show "Retry
/// of run …" / "Retried as run …" from either side without a second lookup.
/// Null on every run that has not (yet) been retried.</param>
public record AutomationRunDto(
    Guid Id,
    int Version,
    Guid? TriggerEventId,
    string? TriggerEventType,
    Guid? RecordId,
    string RecordType,
    bool Matched,
    string Status,
    JsonElement Actions,
    DateTime RanAt,
    DateTime? WaitingUntil,
    Guid? WaitingOnApprovalId,
    string? RecordName,
    Guid? RetryOfRunId = null,
    Guid? RetriedByRunId = null);

/// <summary>
/// One executed (or refused/skipped) action, as recorded on
/// <c>AutomationRun.ActionsJson</c> (design doc §2, §12 slice 3: "what ran:
/// [{action, status, error?, resultRef?}]"). Lives in Contracts, not
/// System or Process, because it crosses BOTH boundaries: SystemApi's
/// <c>AutomationRunner</c> serializes a list of these straight into the jsonb
/// column, and ProcessApi's <c>IAutomationActionExecutor</c> implementation
/// returns them — a type only one of those two layers could otherwise name
/// (<c>LayerBoundaryTests</c>' own reason for existing). Property names are
/// explicit snake_case via <c>JsonPropertyName</c> because this record is
/// serialized straight into the jsonb column and read back out as a raw
/// <see cref="JsonElement"/> for the client (<c>AutomationStore.RunsPageAsync</c>),
/// bypassing the controller-level snake_case naming policy entirely.
/// </summary>
/// <summary>
/// One entry in the merge-field vocabulary for one entity type (design doc
/// to-do/e2-automation-design.md §12 slice 4 follow-up: the builder's
/// `{{field}}` picker needs ONE source, not a hand-typed list that can drift
/// from what the server actually resolves at run time). Lives in Contracts —
/// built by a SystemApi static (<c>AutomationMergeFieldCatalog</c>, which owns
/// the fixed part of the vocabulary and reads the org's active custom field
/// defs for the rest) and returned as-is by ProcessApi/ExperienceApi/the
/// controller, the same "crosses both boundaries" reason
/// <see cref="AutomationActionOutcome"/> is here.
/// </summary>
public sealed record AutomationMergeFieldDto(string Key, string Label, string? Description);

/// <summary>One entity type a <c>field_changed</c> trigger can watch, with its
/// fields in the FORM vocabulary (snake_case, the lead form's keys) —
/// <c>GET /automations/watchable-fields</c>. Derived from the field-change
/// audit's own allow-list, so the builder can only offer a field that really
/// fires. <see cref="CustomFields"/> says custom fields (<c>custom:&lt;key&gt;</c>)
/// are audited for this entity too.</summary>
public sealed record AutomationWatchableEntityDto(string EntityType, List<string> Fields, bool CustomFields);

public sealed record AutomationWatchableFieldsDto(List<AutomationWatchableEntityDto> Entities);

public sealed record AutomationActionOutcome(
    [property: System.Text.Json.Serialization.JsonPropertyName("action")] string Action,
    [property: System.Text.Json.Serialization.JsonPropertyName("status")] string Status,
    [property: System.Text.Json.Serialization.JsonPropertyName("error")] string? Error = null,
    [property: System.Text.Json.Serialization.JsonPropertyName("result_ref")] string? ResultRef = null);

// --- Run preview / publish-narrowing (E2.2 slice 8, design doc §7) ---------

/// <summary>One action as it would be described by a run preview — NEVER
/// executed, so there is no <see cref="AutomationActionOutcome.ResultRef"/>
/// or run-time status; just a plain-English "what this would do" a builder
/// can render next to a matched sample record.</summary>
public record AutomationActionPreviewDto(string Type, string Description);

/// <summary>One sampled real record (an event's own aggregate) a run preview
/// evaluated the trigger + condition against, design §7: "which would have
/// matched and what each action WOULD do".</summary>
public record AutomationPreviewMatchDto(
    Guid? EventId,
    DateTime? OccurredAt,
    string RecordType,
    Guid RecordId,
    string? RecordName,
    bool Matched,
    List<AutomationActionPreviewDto> PredictedActions);

/// <summary>Result of GET .../preview (design §7, §12 slice 8). <see cref="Note"/>
/// is set (and <see cref="Matches"/> empty) when the version's trigger isn't
/// an "event" trigger — this build's run worker only fires "event" triggers
/// (design §12 slice 6, "scan-driven triggers", is not built yet), so there is
/// no real record population to sample for the others; see the story report.</summary>
public record AutomationPreviewResultDto(
    string? EventType,
    int SampleSize,
    int MatchedCount,
    List<AutomationPreviewMatchDto> Matches,
    string? Note = null);

/// <summary>One record that matched the LIVE version's trigger + condition
/// over the sample but would stop matching the DRAFT being published —
/// decision 11 (epics-ai-native-crm.md:195): "the publish check names the
/// leads that stop matching".</summary>
public record AutomationNarrowedRecordDto(string RecordType, Guid RecordId, string? RecordName);

/// <summary>Result of GET .../publish-preview (design §7's "the publish-time
/// narrowing check... run twice... diffed", decision 11: warn, still allow).
/// <see cref="Narrows"/> is true only when <see cref="NewlyUnmatched"/> is
/// non-empty — a draft that matches MORE records than live is never a
/// "narrowing" warning, even if the raw counts differ.</summary>
public record AutomationPublishPreviewDto(
    int SampleSize,
    int LiveMatchedCount,
    int DraftMatchedCount,
    List<AutomationNarrowedRecordDto> NewlyUnmatched,
    bool Narrows,
    string? Note = null);

namespace SalesApi.Dtos;

// Partner MoU net-margin model (to-do/partner-mou-net-margin-design.md, owner decisions 1-9, 2026-11-12). All of it is Partner commercials.

public static class PartnerMouVocab
{
    public static class Model
    {
        /// <summary>The 50/50 net-margin MoU: the monthly calculation runs.</summary>
        public const string NetMargin = "net_margin";
        /// <summary>MKCA (decision 7): an end-client price list instead of a share. Terms are recorded; the calculation is SKIPPED until Suntech's share is confirmed.</summary>
        public const string EndClientPriceList = "end_client_price_list";
        public const string None = "none";
        public static readonly string[] All = [NetMargin, EndClientPriceList, None];
    }

    public static class PlatformCostMode
    {
        public const string Flat = "flat";
        public const string Tiered = "tiered";
        public static readonly string[] All = [Flat, Tiered];
    }

    /// <summary>Decision 6: how the contract-year volume tiers price a month's invoices.</summary>
    public static class TierBasis
    {
        /// <summary>Year-to-date banded: invoice number n of the contract year is priced at the band n falls in (the pricing engine's `banded` block).</summary>
        public const string YtdBanded = "ytd_banded";
        /// <summary>Whole-year rate with true-up: every invoice year-to-date is priced at the rate of the band the year-to-date volume is in; each month books the difference to what was booked to date.</summary>
        public const string YearTrueUp = "year_true_up";
        /// <summary>The month's invoices times 12 pick the band; the month's invoices are all priced at that rate.</summary>
        public const string MonthlyX12 = "monthly_x12";
        public static readonly string[] All = [YtdBanded, YearTrueUp, MonthlyX12];
    }

    public static class BillingFrequency
    {
        public const string Monthly = "monthly";
        public const string Quarterly = "quarterly";
        public static readonly string[] All = [Monthly, Quarterly];
    }

    /// <summary>Decision 4: who bills the end client decides the direction of the result.</summary>
    public static class BilledBy
    {
        /// <summary>The partner bills the end client and holds the money: the partner owes Suntech its share (a RECEIVABLE).</summary>
        public const string Partner = "partner";
        /// <summary>Suntech bills the end client and holds the money: Suntech owes the partner its share (a PAYABLE).</summary>
        public const string Suntech = "suntech";
        public static readonly string[] All = [Partner, Suntech];
    }

    /// <summary>Whether the platform subscription fee (min fee and extra-TRN rate) is stated per month or per year. The signed sheet states them per YEAR, so a missing value reads as annual.</summary>
    public static class FeePeriod
    {
        public const string Monthly = "monthly";
        public const string Annual = "annual";
        public static readonly string[] All = [Monthly, Annual];
    }

    /// <summary>Which MoU party Suntech is. Suntech is always the FP (signed sheet), so a missing value reads as FP; kept only so a different MoU could say otherwise.</summary>
    public static class SuntechParty
    {
        public const string Fp = "fp";
        public const string Sp = "sp";
        public static readonly string[] All = [Fp, Sp];
    }

    public static class ConsumptionSource
    {
        public const string Manual = "manual";
        public const string Upload = "upload";
        public const string Integration = "integration";
        public static readonly string[] All = [Manual, Upload, Integration];
    }

    public static class StatementStatus
    {
        public const string Draft = "draft";
        public const string Approved = "approved";
        public const string Void = "void";
        public static readonly string[] All = [Draft, Approved, Void];
    }

    /// <summary>The kinds of line on a statement. Every line carries a signed amount; Net Base is their sum.</summary>
    public static class LineKind
    {
        public const string RecurringRevenue = "recurring_revenue";
        public const string OneTimeRevenue = "one_time_revenue";
        public const string PlatformCost = "platform_cost";
        public const string Subscription = "subscription";
        public const string InfraCost = "infra_cost";
        public const string OneTimeItem = "one_time_item";
        /// <summary>A shortfall carried forward from the partner's previous approved statement (negative).</summary>
        public const string CarriedForward = "carried_forward";
    }

    /// <summary>What the partner account's owner decides for a NEGATIVE net base before the statement can be approved (owner 2026-11-12).</summary>
    public static class ShortfallChoice
    {
        /// <summary>Nothing is posted; the shortfall is deducted from the next month's net base for this partner until used up.</summary>
        public const string CarryForward = "carry_forward";
        /// <summary>Nothing is posted; the shortfall is written off.</summary>
        public const string SettleZero = "settle_zero";
        /// <summary>The opposite direction is posted for the absolute amount.</summary>
        public const string PostReverse = "post_reverse";
        public static readonly string[] All = [CarryForward, SettleZero, PostReverse];
    }

    /// <summary>Where a receivable statement stands against the money received. not_applicable = not an approved receivable.</summary>
    public static class ReceiptStatus
    {
        public const string NotApplicable = "not_applicable";
        public const string Open = "open";
        public const string PartlyReceived = "partly_received";
        public const string Received = "received";
    }

    public const int MaxRows = 5_000;
    public const int MaxOneTimeItems = 20;
}

/// <summary>One volume band. An invoice number n (1-based, within the contract year) is in the band where <c>MinInvoices &lt; n &lt;= MaxInvoices</c>; the first band starts at 0 and the last has no maximum.</summary>
public record PartnerMouTierDto(long MinInvoices, long? MaxInvoices, decimal Rate);

/// <summary>
/// The signed MoU's terms for one partner (stored on the partner profile). Every field is optional; the calculation refuses, in plain words, when one it needs is missing.
/// Amounts are in <paramref name="Currency"/> (the org currency when blank), ex VAT. The credit period is NOT here: it is the partner's existing PaymentTermsDays term (same meaning, one field).
/// </summary>
public record PartnerMouTermsDto(
    string? Model = null,
    decimal? FpSharePct = null, decimal? SpSharePct = null,
    string? SuntechParty = null,
    string? BilledBy = null,
    decimal? SubscriptionMinFee = null, string? SubscriptionFeePeriod = null, int? SubscriptionTrnsIncluded = null, decimal? SubscriptionExtraRatePerTrn = null,
    decimal? ActivationFeePerTrn = null,
    string? PlatformCostMode = null, decimal? PlatformCostPerInvoice = null, List<PartnerMouTierDto>? Tiers = null, string? TierBasis = null,
    decimal? InfraCostAnnual = null, decimal? InfraExtraPerTrnAnnual = null,
    decimal? ItGapFeePerEntity = null,
    string? BillingFrequency = null, string? Currency = null,
    DateOnly? ContractStart = null,
    List<PartnerMouTierDto>? EndClientPriceTiers = null,
    string? Notes = null);

/// <summary>One line of a statement: signed (revenue and income positive, costs negative).</summary>
public record PartnerMouLineDto(
    string Kind, string Label, decimal Amount,
    Guid? ClientAccountId = null, string? ClientName = null, Guid? LeadId = null,
    decimal? Quantity = null, decimal? Rate = null, string? Detail = null);

public record PartnerMouStatementDto(
    Guid Id, Guid PartnerAccountId, string PartnerName, string Number, string Month, string Status,
    decimal Revenue, decimal PlatformCost, decimal Subscription, decimal InfraCost, decimal TopUps, decimal NetBase,
    decimal FpAmount, decimal SpAmount, string Direction, decimal SettleAmount, string Currency,
    PartnerMouTermsDto Terms, List<PartnerMouLineDto> Lines, List<string> Warnings,
    DateTime RunAt, Guid? RunById, DateTime? ApprovedAt, Guid? ApprovedById, string? ApprovalNote, Guid? LedgerEntryId,
    DateTime? VoidedAt, Guid? VoidedById, string? VoidReason, Guid? VoidEntryId,
    // A negative net base waits for the partner account's owner (SettleAmount < 0): who must choose, and the choice once made.
    bool NeedsShortfallChoice = false, Guid? ShortfallOwnerId = null, string? ShortfallOwnerName = null,
    string? ShortfallChoice = null, Guid? ShortfallChosenById = null, DateTime? ShortfallChosenAt = null,
    // Receivables (approved, direction receivable): receipts recorded against it.
    string ReceiptStatus = PartnerMouVocab.ReceiptStatus.NotApplicable, decimal Received = 0m, decimal Outstanding = 0m, bool Overdue = false, DateOnly? DueDate = null,
    List<PartnerMouReceiptDto>? Receipts = null);

/// <summary>The statements list: no lines or terms.</summary>
public record PartnerMouStatementSummaryDto(
    Guid Id, Guid PartnerAccountId, string PartnerName, string Number, string Month, string Status,
    decimal NetBase, decimal FpAmount, decimal SpAmount, string Direction, decimal SettleAmount, string Currency,
    DateTime RunAt, DateTime? ApprovedAt, DateTime? VoidedAt,
    string ReceiptStatus = PartnerMouVocab.ReceiptStatus.NotApplicable, decimal Received = 0m, bool Overdue = false, bool NeedsShortfallChoice = false);

/// <summary>One payment received against a receivable statement. Each posts a settling ledger entry (<c>LedgerEntryId</c>).</summary>
public record PartnerMouReceiptDto(Guid Id, DateOnly Date, decimal Amount, string? Reference, Guid? RecordedById, DateTime RecordedAt, Guid? LedgerEntryId);

/// <summary>Mark received: a payment on an approved receivable statement. Partial is allowed; more than the outstanding amount is refused.</summary>
public record PartnerMouReceiptInput(DateOnly? Date, decimal? Amount, string? Reference);

/// <summary>The account owner's decision on a negative statement: carry_forward | settle_zero | post_reverse.</summary>
public record PartnerMouShortfallInput(string? Choice);

/// <summary>Run month. <c>Month</c> is YYYY-MM.</summary>
public record PartnerMouRunInput(string? Month);

public record PartnerMouApproveInput(string? Note);

public record PartnerMouVoidInput(string? Reason);

public record PartnerOneTimeItemDto(string Label, decimal Amount);

public record PartnerConsumptionDto(
    Guid Id, Guid PartnerAccountId, Guid ClientAccountId, string ClientName, string Month,
    int InvoicesCount, int ActiveTrns, List<PartnerOneTimeItemDto> OneTimeItems, string Source, Guid? EnteredById, DateTime EnteredAt);

/// <summary>One client + month, entered by hand. Saving again for the same client and month replaces the row.</summary>
public record PartnerConsumptionInput(Guid? ClientAccountId, string? Month, int? InvoicesCount, int? ActiveTrns, List<PartnerOneTimeItemDto>? OneTimeItems);

/// <summary>
/// An upload. The desktop converts an XLSX to CSV text first (the usage and partner-file uploads do the same). Columns: client (name or id), month (YYYY-MM), invoices, active_trns, and optionally
/// one_time_label + one_time_amount (a row with the same client and month again adds another one-time item). <c>DryRun</c> reads and validates and saves nothing.
/// </summary>
public record PartnerConsumptionUploadInput(string? Csv, string? FileName = null, bool DryRun = false);

/// <param name="Errors">Plain row-level reasons, rows numbered from the header (first data row = 2). Bad rows are skipped; the good ones are saved.</param>
public record PartnerConsumptionUploadResultDto(int RowCount, int Saved, int Created, int Replaced, bool DryRun, List<UsageRowErrorDto> Errors);

/// <summary>One partner-month of the report. Rows exist for every approved or draft statement in range; <c>Status</c> is the statement's.</summary>
public record PartnerMouReportRowDto(
    Guid PartnerAccountId, string PartnerName, string Month, Guid StatementId, string Number, string Status,
    decimal NetBase, decimal FpAmount, decimal SpAmount, string Direction, decimal SettleAmount, string Currency);

public record PartnerMouReportDto(string From, string To, List<PartnerMouReportRowDto> Rows);

namespace SalesApi.Dtos;

// The CUSTOMER portal's API (/portal/customer/*): what a signed-in customer user sees of its own account (and, per the invite's flag, its child accounts). Every shape here is built to
// carry ONLY what the customer is entitled to: the money is theirs, so it is never masked, but nothing staff-side is in these records - no owner, no team, no deal id, no internal notes,
// no margin, no verifier. A test pins that by reflection (CustomerPortalApiTests), so adding such a field later fails the build.

/// <summary>One invoice row, <c>GET /portal/customer/invoices</c>. <c>Status</c> is open | partial | paid (drafts, voids and write-offs are not the customer's to see).</summary>
public record CustomerPortalInvoiceDto(
    Guid Id, string Number, DateTime IssuedAt, DateTime DueDate, string Currency, decimal Amount, decimal AmountPaid, decimal Balance, string Status, string AccountName);

/// <summary>A receipt of one payment collected against an invoice, <c>GET /portal/customer/invoices/{id}/receipts</c>; the PDF is <c>/portal/customer/receipts/{collection_task_id}/pdf</c>.</summary>
public record CustomerPortalReceiptDto(Guid CollectionTaskId, string ReceiptNumber, DateTime? CollectedAt, decimal Amount, string Currency);

/// <summary><c>POST /portal/customer/invoices/{id}/pay</c>: the invoice's Pay now page.</summary>
public record CustomerPortalPayDto(string Url);

/// <summary>One document of an account's KYC checklist. <c>State</c> is present | missing | expired; <c>AwaitingReview</c> is true while the file we hold has not been checked yet; <c>CanUpload</c> is false for
/// a personal document held by a person (they are not uploadable here yet).</summary>
public record CustomerPortalKycItemDto(
    string DocumentType, string Label, bool Mandatory, string Holder, string State, DateOnly? ExpiryDate, bool AwaitingReview, bool CanUpload);

/// <summary>An account's checklist, <c>GET /portal/customer/kyc</c> (one per in-scope account).</summary>
public record CustomerPortalKycDto(Guid AccountId, string AccountName, bool Complete, int MissingCount, int MissingMandatoryCount, List<CustomerPortalKycItemDto> Items);

/// <summary><c>POST /portal/customer/kyc/{accountId}/files</c>: the file is in and waiting for review.</summary>
public record CustomerPortalKycUploadedDto(string DocumentType, string FileName, DateTime UploadedAt, bool AwaitingReview);

/// <summary>One thing we have asked the customer for, <c>GET /portal/customer/requests</c>. <c>Kind</c> is document_request | irl; <c>Url</c> is the existing secure link, which the portal just opens.</summary>
public record CustomerPortalRequestDto(string Kind, Guid Id, string Title, DateTime? SentAt, DateTime? ExpiresAt, string Status, string Url);

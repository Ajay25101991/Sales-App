// The CollectionTasks contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Collection tasks (field collection by a collector) ---
// Amount/CollectedAmount masked (null) without ViewAccountFinancials
// (invoice-money-masking, owner decision 2026-09-28) — same convention as
// every other invoice-money figure. Both the manager and collector default
// roles hold ViewAccountFinancials (OrganizationRoleService), so this only
// bites a custom role an org has deliberately narrowed.
public record CollectionTaskDto(
    Guid Id,
    Guid InvoiceId,
    string? InvoiceNumber,
    string? CustomerName,
    string? Company,
    decimal? Amount,
    decimal? CollectedAmount,
    string Method,
    string? Notes,
    string Status,
    Guid AssignedById,
    string? AssignedByName,
    Guid? CollectedById,
    string? CollectedByName,
    DateTime? CollectedAt,
    Guid? PaymentId,
    string? ReceiptNumber,
    List<string> Modules,
    DateTime CreatedAt,
    // "invoice_raised" when auto-created by PaymentWorkflowService; null for a
    // manager's manual assignment.
    string? Source = null,
    // normal|high|critical — escalated by CollectionEscalationService as the
    // linked invoice ages past due.
    string Priority = "normal");

public record CollectionTaskInput(Guid? InvoiceId, decimal? Amount, string? Method, string? Notes);
public record CollectTaskInput(decimal? Amount, string? Method, string? Reference, DateTime? PaidAt, string? Note, List<string>? Modules, Guid? ProofAttachmentId, List<Guid>? ProofInvoiceIds);

// A customer's invoice, offered when picking which invoices a single proof
// covers. Amount/Balance masked (null) without ViewAccountFinancials.
public record TaskInvoiceDto(Guid Id, string Number, decimal? Amount, decimal? Balance, string Status, DateTime DueDate);

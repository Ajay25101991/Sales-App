namespace SalesApi.Dtos;

// E3.7 — methodology checklist. Split into its own file, same reasoning as
// Stakeholders.cs's own header comment: one file per domain so the Experience
// layer (reference-free from System) can still see the shape.

/// <summary>
/// One qualification-checklist item, as it lives in a playbook version's
/// <c>QualificationSnapshot</c> (mirrors <see cref="StageDefDto"/> living in a
/// version's <c>StageSnapshot</c>). <see cref="Key"/> is this item's stable
/// identity across edits/republish — <see cref="Models.LeadQualificationCompletion.ItemKey"/>
/// names it by this key, never by position or label.
/// </summary>
/// <param name="LinkedField">
/// Optional — a field key from the SAME live registry a "rule"/"custom" gate
/// validates against (<c>StageGateService.KnownFieldKeysAsync</c>: every
/// built-in lead field, unprefixed, plus every active custom field prefixed
/// with <c>LeadFormService.CustomPrefix</c>). When set, the item reads as done
/// the moment that field is non-empty on the lead — no separate write, the
/// same "read a live value, don't duplicate it into a stored flag" choice
/// <c>StageGateService.HasFieldValue</c>/<c>HasCustomValue</c> already make
/// for gates. Null means the item is manual-only: only a completion row makes
/// it done.
/// </param>
public record QualificationItemDto(
    string Key,
    string Label,
    string? HelpText,
    int Order,
    string? LinkedField = null);

/// <summary>PUT .../qualification-items — replaces the playbook draft's whole
/// item list, the same whole-list-PUT shape <see cref="PlaybookDraftInput"/>
/// uses for stages (two managers editing concurrently collide on the whole
/// list rather than interleave into one neither chose).</summary>
public record QualificationDraftResultDto(int Version, string Status, int ItemCount);

/// <summary>One of the shipped starting templates (MEDDICC, BANT) a playbook
/// author can copy items from — GET /playbooks/qualification-templates.
/// Plain suggestions, not stored anywhere; picking one just seeds the
/// builder's draft list, which the author then edits and saves like any
/// other.</summary>
public record QualificationTemplateDto(string Key, string Name, List<QualificationItemDto> Items);

/// <summary>
/// One checklist row as a LEAD sees it — the item's own definition (from its
/// own playbook's live version) merged with whether this lead has satisfied
/// it. <see cref="Done"/> is true whether satisfied manually (a completion
/// row exists) or automatically (a <see cref="QualificationItemDto.LinkedField"/>
/// is non-empty on the lead) — <see cref="AutoCompleted"/> is what tells the
/// two apart for the UI ("auto" badge vs. a name and timestamp).
/// </summary>
/// <param name="AutoCompletedAt">
/// Only meaningful when <see cref="AutoCompleted"/> is true — the moment the
/// linked field most recently went from empty to non-empty, derived from the
/// field-change audit (<c>Services.QualificationAuditService</c>), never a
/// new stored value. Null when the field is currently empty (the item isn't
/// done), or when no audit row exists for it — either the field carries no
/// audit history at all (most built-in lead fields don't; see
/// <c>Services.FieldAudit.TrackedFields</c>), or its value was set before the
/// audit existed. A null here is a plain "we don't know", not "never".
/// </param>
public record LeadQualificationItemDto(
    string Key,
    string Label,
    string? HelpText,
    int Order,
    bool Done,
    bool AutoCompleted,
    Guid? CompletedById,
    string? CompletedByName,
    DateTime? CompletedAt,
    string? Note,
    DateTime? AutoCompletedAt = null);

/// <summary>GET /leads/{id}/qualification. <see cref="DoneCount"/>/<see cref="TotalCount"/>
/// are pre-computed here (not left to the client to derive from
/// <see cref="Items"/>) for the identical reason
/// <see cref="StakeholderListDto.MissingRequiredRoles"/> is — the same number
/// also has to match what a "qualification" stage gate computed, so both read
/// through <c>QualificationService</c> rather than two hand-rolled counts
/// silently drifting apart.</summary>
public record LeadQualificationChecklistDto(List<LeadQualificationItemDto> Items, int DoneCount, int TotalCount);

/// <summary>POST .../complete body — an optional note, mirroring how
/// <c>StakeholderInput</c> and <c>ReminderInput</c> both let a free-text note
/// ride along with a status change rather than needing a second call.</summary>
public record CompleteQualificationItemInput(string? Note);

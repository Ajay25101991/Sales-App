using SalesApi.Services;

// Channel partners - bulk upload and retrospective terms (to-do/partner-management-design.md section 11, owner decisions 2026-10-20).
//
// Two files, each previewed then committed (the lead import's shape: the CSV and the column mapping travel with BOTH calls, preview and commit are one code path, a bad row is skipped
// and listed): the PARTNERS file (Partner, POC(s), Assigned Manager) and the CLIENT sheet (the e-invoicing client repository; the partner is its Lead Channel). Then "Partners to
// complete": the partners and deal partners the uploads left without terms, and attaching a plan later with a back-pay preview.
//
// Nothing here is stored between preview and commit: the commit repeats the file (as the lead import does), so the commit always acts on the data as it is NOW and the preview can never
// disagree with it.

namespace SalesApi.Dtos;

public static class PartnerBulkVocab
{
    public const int MaxRows = 5000;
    public const int MaxMessages = 200;

    /// <summary>The columns a mapping can name (field -> the file's header). Without a mapping the file's headers are tried by these names.</summary>
    public static class PartnerFileField
    {
        public const string Partner = "partner";
        public const string Pocs = "pocs";
        public const string AssignedManager = "assigned_manager";
        public static readonly string[] All = [Partner, Pocs, AssignedManager];
    }

    public static class ClientSheetField
    {
        public const string Channel = "channel";
        public const string Client = "client";
        public const string DealId = "deal_id";
        public const string Owner = "owner";
        public static readonly string[] All = [Channel, Client, DealId, Owner];
    }

    /// <summary>How a POC (point of contact) name was classified.</summary>
    public static class PocKind
    {
        /// <summary>Matches a CRM user: "our contact for this partner".</summary>
        public const string Internal = "internal";
        /// <summary>Any other name: a contact on the partner's account.</summary>
        public const string Contact = "contact";
        /// <summary>Matches more than one CRM user: nothing is imported for it until the preview's correction names one.</summary>
        public const string Ambiguous = "ambiguous";
    }

    public static class Outcome
    {
        public const string Created = "created";
        public const string Updated = "updated";
        public const string Unchanged = "unchanged";
        public const string Failed = "failed";
    }

    /// <summary>The Owner / Lead Channel value that means the client runs the product itself - not partner business.</summary>
    public const string ManagedByPartner = "managed by partner";

    /// <summary>The smallest name similarity (0..1) at which a partner is SUGGESTED for a channel value. A suggestion is a question for the owner, never an answer.</summary>
    public const double SuggestThreshold = 0.7;
}

/// <summary>The caller's facts the account writes need (the account twin of AccountActor), resolved by the controller so Process never reads a principal.</summary>
public record PartnerImportActor(
    Guid UserId, Guid? OrgId, string Name, bool IsManager, string Visibility, string Role, bool CanCreateTags, SensitiveAccess? Sensitive = null);

public record BulkRowIssueDto(int Row, string Reason);

// ---------------------------------------------------------------------------------------------------------------------
// The partners file
// ---------------------------------------------------------------------------------------------------------------------

/// <summary>
/// Preview and commit take the same body. <c>Mapping</c> is field (partner | pocs | assigned_manager) -> the file's header; absent = the headers are tried by name.
/// <c>RowEdits</c> are the corrections made on the preview: a row's POC split (our contacts / contacts on the partner's account), its assigned manager, or skipping it.
/// </summary>
public record PartnerFileInput(string? Csv, Dictionary<string, string>? Mapping = null, List<PartnerFileRowEdit>? RowEdits = null, string? FileName = null);

/// <summary>Row = the file's row number (the header is row 1). A null list leaves the preview's own value; an empty list means none.</summary>
public record PartnerFileRowEdit(int Row, List<Guid>? InternalContactIds = null, List<string>? ContactNames = null, Guid? AssignedManagerId = null, bool Skip = false);

public record PartnerFileResultDto(
    bool Committed, List<string> Headers, Dictionary<string, string?> MappingUsed,
    int RowCount, int ReadyCount, int WillCreateAccountCount, int ExistingPartnerCount, int ErrorCount,
    List<PartnerFileRowDto> Rows, List<BulkRowIssueDto> Errors, List<BulkRowIssueDto> Warnings,
    PartnerFileCommitDto? Commit = null);

/// <param name="WillCreateAccount">No account matched the partner's name (the company key): one is created, and the preview flags it to confirm.</param>
/// <param name="HasProfile">The account is already a channel partner (its profile is left as it is; the contacts and manager are still added).</param>
public record PartnerFileRowDto(
    int Row, string PartnerName, Guid? AccountId, string? AccountName, bool WillCreateAccount, bool HasProfile, bool WillCreateProfile,
    List<PartnerPocDto> Pocs, PartnerManagerDto? Manager);

/// <param name="ExistingContact">A contact of this name is already on the partner's account (nothing is added).</param>
/// <param name="AlreadyOurContact">The user is already "our contact" on the partner's profile.</param>
public record PartnerPocDto(string Text, string Kind, Guid? UserId, string? UserName, bool ExistingContact, bool AlreadyOurContact);

public record PartnerManagerDto(string Text, Guid? UserId, string? UserName, bool AlreadyOwner);

public record PartnerFileCommitDto(
    int AccountsCreated, int ProfilesCreated, int InternalContactsAdded, int ContactsCreated, int OwnersChanged, int Unchanged, int Failed,
    List<PartnerFileRowOutcomeDto> Rows);

public record PartnerFileRowOutcomeDto(int Row, string PartnerName, Guid? AccountId, string Outcome, string? Reason = null);

// ---------------------------------------------------------------------------------------------------------------------
// The client sheet
// ---------------------------------------------------------------------------------------------------------------------

/// <summary>
/// <c>ChannelMap</c>: the sheet's Lead Channel value -> the partner ACCOUNT id, or null for "not a partner" (the owner confirms it once, from the preview's suggestions).
/// <c>DealPick</c>: row -> the deal the row is about, for a row the preview showed as ambiguous. <c>ExcludedDealIds</c>: deals un-ticked in the preview (every open and won deal of a
/// matched client is ticked by default). <c>PreferredSource</c>: when a client has several deals, prefer the one whose lead source is this text (how the September import marked its deals).
/// </summary>
public record ClientSheetInput(
    string? Csv, Dictionary<string, string>? Mapping = null, Dictionary<string, Guid?>? ChannelMap = null, Dictionary<int, Guid>? DealPick = null,
    List<Guid>? ExcludedDealIds = null, string? PreferredSource = null, string? FileName = null);

public record ClientSheetResultDto(
    bool Committed, List<string> Headers, Dictionary<string, string?> MappingUsed,
    int RowCount, int ReadyCount, int ExcludedCount, int ErrorCount, int AmbiguousCount,
    List<ClientChannelDto> Channels, List<ClientRowDto> Rows, List<ClientRowExcludedDto> Excluded, List<BulkRowIssueDto> Errors,
    ClientSheetCommitDto? Commit = null);

/// <summary>
/// One distinct Lead Channel value. <c>Suggested*</c> is the closest partner by name (null = "not a partner": LinkedIn, a staff name, ...); <c>Candidates</c> the best few for the picker.
/// <c>Mapped</c>/<c>MappedPartnerAccountId</c> echo the map the caller sent. A "Managed by Partner" value is not partner business and is never suggested.
/// </summary>
public record ClientChannelDto(
    string Value, int RowCount, bool ManagedByPartner, Guid? SuggestedPartnerAccountId, string? SuggestedPartnerName, double? Score,
    List<ClientChannelCandidateDto> Candidates, bool Mapped, Guid? MappedPartnerAccountId);

public record ClientChannelCandidateDto(Guid PartnerAccountId, string PartnerName, double Score);

/// <param name="Ambiguous">The client has several candidate deals and the file does not say which: pick one (<c>DealPick</c>) or the row is skipped.</param>
public record ClientRowDto(
    int Row, string Client, string Channel, Guid? PartnerAccountId, string? PartnerName, Guid? AccountId, string? AccountName,
    bool RelationshipExists, Guid? DealId, bool Ambiguous, List<ClientDealDto> Deals);

/// <param name="Phase">open | won | lost. Only open and won deals can take a partner.</param>
/// <param name="Ticked">Will become a deal partner on commit (open and won, not un-ticked).</param>
/// <param name="PartnerAlreadyOnDeal">This partner is already the deal's referrer: skipped, not duplicated.</param>
public record ClientDealDto(
    Guid LeadId, string Name, string Phase, DateTime CreatedAt, string? Source, string? OwnerName, bool Ticked, bool Primary, bool PartnerAlreadyOnDeal);

public record ClientRowExcludedDto(int Row, string Client, string Reason);

public record ClientSheetCommitDto(
    int RelationshipsCreated, int RelationshipsExisting, int DealPartnersCreated, int DealPartnersExisting, int Failed, List<ClientRowOutcomeDto> Rows);

public record ClientRowOutcomeDto(int Row, string Client, bool RelationshipCreated, int DealsAttributed, int DealsAlreadyThere, List<BulkRowIssueDto> Problems);

// ---------------------------------------------------------------------------------------------------------------------
// Partners to complete, and attaching a plan later
// ---------------------------------------------------------------------------------------------------------------------

public static class PartnerMissing
{
    public const string TypeToBeSet = "type_to_be_set";
    // Since 2026-11-10 the list is per partner type: the other keys are the PartnerRequirementCatalogue keys (agreement, default_plan, vat_trn, ...).
    public const string NoDefaultPlan = PartnerRequirementCatalogue.DefaultPlan;
    public const string NoAgreement = PartnerRequirementCatalogue.Agreement;
}

/// <summary>Profiles still to complete (<c>Missing</c> lists which of type_to_be_set | the type's requirement field keys) and deal partners with no plan.</summary>
public record PartnersToCompleteDto(List<PartnerToCompleteDto> Partners, List<DealPartnerToCompleteDto> DealPartners);

public record PartnerToCompleteDto(
    Guid AccountId, string AccountName, string Type, string Status, List<string> Missing, int PlanlessDeals);

public record DealPartnerToCompleteDto(
    Guid DealPartnerId, Guid LeadId, string? LeadName, Guid PartnerAccountId, string PartnerName, string Role, DateTime StartedAt);

/// <summary>
/// Attach a plan to deal partners that have none. <c>DealPartnerIds</c> null = every planless deal partner in scope (the partner's, in the bulk call). <c>Reason</c> is kept on the
/// deal partner; blank = "Terms attached after the bulk upload".
/// </summary>
public record AttachPlanInput(Guid? PlanId, string? Reason = null, List<Guid>? DealPartnerIds = null);

/// <summary>What the partner would earn on everything collected so far, per deal (owner F2), before anything is written. Needs a raw Partner commercials read.</summary>
public record BackPayPreviewDto(
    Guid PlanId, string PlanName, int PlanVersion, PartnerRuleSummaryDto Rule, string Currency,
    List<BackPayLineDto> Lines, decimal TotalBackPay, int Attachable, int Refused);

public record BackPayLineDto(
    Guid DealPartnerId, Guid LeadId, string? LeadName, Guid PartnerAccountId, string PartnerName, string Role,
    decimal CollectedBase, decimal BackPay, bool CanAttach, string? RefusalCode = null, string? Refusal = null);

public record AttachPlanResultDto(
    Guid PlanId, string PlanName, string Currency, List<AttachPlanLineDto> Lines, decimal TotalAccrued, int Attached, int Skipped);

public record AttachPlanLineDto(Guid DealPartnerId, Guid LeadId, string? LeadName, bool Attached, decimal? Accrued, string? Code = null, string? Reason = null);

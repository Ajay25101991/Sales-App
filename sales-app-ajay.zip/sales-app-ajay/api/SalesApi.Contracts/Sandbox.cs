namespace SalesApi.Dtos;

// --- E7.3 sandbox org (design doc to-do/e7-config-platform-design.md §4) ---
// A sandbox is a real Organization row (§4.1); creation/refresh/promote all
// reuse the E7.1/E7.2 package pipeline (PackageExportProcess/PackageImportProcess),
// which is why most of the shapes below are thin wrappers around Packages.cs's
// own DTOs rather than a parallel set — "reuses 100% of the import pipeline"
// (§4.5's own words).

public record SandboxDto(Guid Id, Guid ProductionOrgId, DateTime CreatedAt, DateTime? LastRefreshedAt);

public record SandboxCreateResultDto(SandboxDto Sandbox, PackageApplyResultDto ImportResult);

/// <summary>GET /admin/sandbox/diff — §4.4 point 1/2: the sandbox's own
/// items classified New/Changed/Conflict/Unchanged against a FRESH export of
/// production (the same shape <c>PackageImportPreviewDto</c> uses), PLUS any
/// item present in production's own fresh export but absent from the
/// sandbox's (<see cref="PackageDiffStates.Removed"/>) — something archived/
/// deleted inside the sandbox since it was cloned or last refreshed.</summary>
public record SandboxDiffDto(string PackageHash, List<PackageDiffItemDto> Items);

/// <summary>One item to promote. <see cref="Resolution"/> is required
/// (one of <c>PackageResolutionChoices.All</c>) when the diff classified this
/// item as Changed or Conflict, ignored otherwise — the exact same rule
/// <c>PackageImportProcess.ApplyAsync</c> already enforces for an ordinary
/// import, reused here rather than re-invented.</summary>
public record SandboxPromoteItemSelectionDto(string Kind, string StableKey, string? Resolution);

/// <summary><see cref="Acknowledged"/> must be true or the whole promote is
/// refused (§0.1's mock: "removals need explicit acknowledgement") — listed
/// per item, never a single bulk checkbox for "N items removed".</summary>
public record SandboxPromoteRemovalSelectionDto(string Kind, string StableKey, bool Acknowledged);

public record SandboxPromoteRequestDto(
    List<SandboxPromoteItemSelectionDto> Items,
    List<SandboxPromoteRemovalSelectionDto> Removals);

/// <summary>Why a sandbox operation was refused. <see cref="NotFound"/>
/// distinguishes "this org has no sandbox yet" (404) from an ordinary 400.
/// <see cref="UnresolvedStableKeys"/>/<see cref="UnacknowledgedStableKeys"/>
/// mirror <c>PackageApplyRefusalDto</c>'s own "list exactly which ones,
/// never just the count" rule.</summary>
public record SandboxRefusalDto(
    string Reason,
    bool NotFound = false,
    List<string>? UnresolvedStableKeys = null,
    List<string>? UnacknowledgedStableKeys = null);

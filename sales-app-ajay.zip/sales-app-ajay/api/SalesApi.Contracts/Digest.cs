using System.Text.Json;
using System.Text.Json.Serialization;

// The Digest contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Manager digest (weekly team summary) ---
public class DigestDto
{
    [JsonPropertyName("period")] public string Period { get; set; } = "";
    [JsonPropertyName("openLeads")] public int OpenLeads { get; set; }
    [JsonPropertyName("openValue")] public decimal OpenValue { get; set; }
    [JsonPropertyName("weightedForecast")] public decimal WeightedForecast { get; set; }
    [JsonPropertyName("wonCount")] public int WonCount { get; set; }
    [JsonPropertyName("wonValue")] public decimal WonValue { get; set; }
    [JsonPropertyName("idleLeads")] public int IdleLeads { get; set; }
    [JsonPropertyName("outstanding")] public decimal Outstanding { get; set; }
    [JsonPropertyName("overdue")] public decimal Overdue { get; set; }
    [JsonPropertyName("collected")] public decimal Collected { get; set; }
    [JsonPropertyName("pendingApprovals")] public int PendingApprovals { get; set; }
    [JsonPropertyName("headline")] public string Headline { get; set; } = "";
}
public record DigestConfigDto(bool Enabled, int DayOfWeek, int Hour);
public record DigestConfigInput(bool? Enabled, int? DayOfWeek, int? Hour);

// --- Monthly management report (dated HTML email — owner decision §38) ---
public record MonthlyReportConfigDto(bool Enabled, int DayOfMonth, int Hour);
public record MonthlyReportConfigInput(bool? Enabled, int? DayOfMonth, int? Hour);

// The Auth contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Auth ---
// `SupportsRefresh` is the client saying "I know how to use a refresh token".
// Absent (an older shipped build) it deserializes to null, the server mints the
// legacy 30-day access token and no refresh token, and that client behaves
// exactly as it does today. See JwtService.CreateToken for why the compatibility
// branch exists at all.
public record SignupRequest(string? Email, string? Password, string? FullName, string? OrgName, bool? SupportsRefresh = null);
public record SigninRequest(string? Email, string? Password, string? Platform, bool? SupportsRefresh = null);
// The refresh token IS the credential on this endpoint — there is no Authorization
// header to pair it with, because the access token is expired by definition.
public record RefreshRequest(string? RefreshToken);
// Sign-out names the session to end. Omitted (older client), every session for
// the caller is revoked instead — see AuthController.SignOut.
public record SignOutRequest(string? RefreshToken);
public record AuthActivityRequest(string? Platform);
// Per-teammate sign-in summary for the manager login-activity view.
public record LoginEntryDto(DateTime At, string? Platform);
// LoginCount is the lifetime total; LoginCountPeriod is scoped to the
// trailing PeriodDays window (see TeamController.LoginActivityPeriodDays) —
// "logins this period" is what the adoption table surfaces, not the
// lifetime count, since a rep who logged in 200 times a year ago but not
// since reads as active on a lifetime count alone.
public record LoginActivityDto(
    Guid UserId, string? FullName, string Email, string Role, bool IsActive,
    DateTime? LastLoginAt, int LoginCount, int LoginCountPeriod, List<LoginEntryDto> Recent);
// `SupportsRefresh` decides the RESPONSE shape, not just the token lifetime:
// a refresh-capable client gets 200 + a fresh session (because the change just
// revoked the one it was holding), an older one keeps today's 204. See
// AuthController.ChangePassword.
public record ChangePasswordRequest(string? CurrentPassword, string? NewPassword, bool? SupportsRefresh = null);
public record ResetPasswordInput(string? Password);

public record ProfileDto(
    Guid Id,
    string Email,
    string? FullName,
    string Role,
    string? ExpoPushToken,
    bool IsActive,
    DateTime CreatedAt,
    Guid? OrgId,
    string? Org,
    string? OrgCurrency,
    string? RoleKey = null,
    List<string>? Permissions = null,
    // Forced password change (Part 3) — true right after an invite (temp
    // password) or an admin password reset, until the user changes it
    // themselves. The client redirects to the change-password screen when this
    // is true; the server enforces the same gate independently (see
    // MustChangePasswordMiddleware) so it isn't just a UI redirect.
    bool MustChangePassword = false,
    // The teams this user belongs to, and which one new leads of theirs default
    // to. Sent on /profile so the client can label and filter by team without a
    // second round trip; membership itself is authorized server-side (TeamScope),
    // never from this list.
    List<TeamSummaryDto>? Teams = null,
    Guid? PrimaryTeamId = null,
    // Whether the CALLER may administer this person — UserAdminPolicy.CanModifyUser
    // for the requesting principal, answered by the server so the roster screen can
    // hide an Edit affordance the API would refuse. Only GET /team fills it in;
    // null everywhere else means "not asked", never "allowed". The client must treat
    // it as presentation only: every write re-runs the policy server-side.
    bool? CanManage = null,
    // E7.3 (design doc to-do/e7-config-platform-design.md §4.3): "Expose
    // is_sandbox + sandbox_of on the org/profile/session DTO the client uses
    // to draw the banner." True/set only when THIS profile's own org IS a
    // sandbox (Organization.SandboxOfOrgId != null) — a production-org
    // admin's own profile stays false/null even though their org HAS a
    // sandbox; that fact belongs to a sandbox-listing endpoint, not to every
    // profile read, since "does my org have a sandbox" and "am I currently
    // looking at one" are different questions and only the second one needs
    // to be true on every single request for the striped banner to render.
    bool IsSandbox = false,
    Guid? SandboxOfOrgId = null,
    // E7.4 (design doc to-do/e7-config-platform-design.md §5.1 req 3/4): set
    // only while this session is studio-scoped (an implementation user
    // switched into a customer org, or a production admin switched into
    // their own sandbox) — null on an ordinary session, where OrgId already
    // IS the org being acted in. ActingOrgId always equals OrgId above when
    // set; it is repeated here under its own name so the client can render
    // "you are viewing {Org} as {studio}, your home is {HomeOrgId}" without
    // having to know that OrgId sometimes means something else. StudioKind
    // is "impl" or "sandbox" (StudioSessionKind) — the two cases the studio
    // banner and the sandbox banner render differently.
    Guid? ActingOrgId = null,
    Guid? HomeOrgId = null,
    string? StudioKind = null,
    // E7.4 slice 19 (design doc §5.6) — set only while a Studio
    // preview-as-role session is active: this DTO's Role/RoleKey/Permissions
    // already describe the PREVIEWED role (never the caller's real one, per
    // §5.6's "build the caller's RecordAccessContext for the CHOSEN role"),
    // and this field is what lets the client render "Previewing as {role} —
    // read-only" without having to diff Role against anything else. Null on
    // every non-previewing session.
    string? PreviewRole = null,
    // E7.6: the feature keys (PlanCatalogue.Features) the org's plan switches
    // on, so any screen — not only an admin's — can show "not in your plan"
    // instead of a broken page. Filled on GET /profile; null elsewhere means
    // "not sent", never "none". Presentation only: the server enforces.
    List<string>? PlanFeatures = null,
    // Follow-up (2026-09-30, owner) — whether this person has a Microsoft
    // account bound (Profile.SsoSubject != null), so the Team screen can show
    // an "Unlink Microsoft account" action only where there is something to
    // unlink. Mirrors CanManage exactly: only GET /team fills it in; null
    // everywhere else means "not asked", never "not linked". Presentation
    // only — DELETE /team/{id}/sso-link re-checks nothing client-supplied.
    bool? HasSsoLink = null,
    // E12.4 (owner decision 15) - an opaque value that changes whenever this person's role, their role's permissions or
    // sensitive levels, their assignment, their teams or the org's assigned scope change. The phone wipes its offline copy
    // when it differs from the last one it saw. Filled on GET /profile and the sign-in / refresh responses; null elsewhere
    // means "not sent".
    string? AccessVersion = null);

// A team as the client sees it. MemberCount rather than the member list: the
// roster is a separate, larger read that only the team-management screen needs.
// CanManage mirrors ProfileDto.CanManage exactly: whether the CALLER may administer
// this team — rename it, archive it, edit its roster. It is TeamsController's own
// CanAdminister, the same expression the write paths run, projected so the screen can
// hide a control the PATCH would refuse instead of drawing it and surfacing a 403.
// Only GET /teams and the endpoints that echo a team back fill it in; null everywhere
// else (ProfileDto.Teams, GET /team's rows) means "not asked", never "allowed".
// Presentation only — every write re-runs CanAdminister server-side.
public record TeamSummaryDto(
    Guid Id, string Name, bool IsDefault, int MemberCount, DateTime? ArchivedAt, bool? CanManage = null);
public record TeamDetailDto(Guid Id, string Name, bool IsDefault, DateTime? ArchivedAt, List<Guid> MemberIds);
public record TeamInput(string? Name);
public record TeamMembersInput(List<Guid>? UserIds);

// PlanId/PlanName (E7.6) are filled only on the platform-admin org list, where
// each row shows its plan; null elsewhere means "not sent".
public record OrganizationDto(Guid Id, string Name, string Domain, string Currency, DateTime CreatedAt,
    Guid? PlanId = null, string? PlanName = null);
public record OrganizationInput(string? Name, string? Currency);
public record OrganizationOffboardInput(string? BackupReceipt, string? Confirmation);

// Platform-admin explicit org provisioning (AdminController.CreateOrganization).
// HasAdmin reflects whether the designated admin has registered yet — a platform
// admin reading this back can tell "created, awaiting its admin" from "up and
// running" without a second call.
//
// TemplateId (E7.2, design doc to-do/e7-config-platform-design.md §3, §8 slice
// 8) — optional. Null/empty behaves exactly as before this story: a fresh org
// with nothing configured. A recognised id applies that shipped template
// through the SAME package import pipeline right after the org row is
// created (AdminExperience.CreateOrganizationAsync); an unrecognised id
// refuses the WHOLE request before anything is written, rather than creating
// a half-set-up org.
public record CreateOrganizationInput(string? Name, string? Domain, string? Currency, string? AdminEmail, string? TemplateId = null);
public record AdminOrganizationDto(
    Guid Id, string Name, string Domain, string Currency,
    string? DesignatedAdminEmail, bool HasAdmin, DateTime CreatedAt);

// App-admin allowlist of domains permitted to register a new organization.
public record AllowedDomainDto(Guid Id, string Domain, string? OrgName, DateTime CreatedAt);
public record AllowedDomainInput(string? Domain, string? OrgName);

// `RefreshToken` is null for a client that did not ask for one. It is serialized
// as `refresh_token`; an older client ignores the extra field, which is why this
// is an addition rather than a new response shape.
public record AuthResponse(string Token, ProfileDto User, string? RefreshToken = null);

// --- Session handoff (control panel to CRM, owner 2026-11-17) ---
// POST /auth/handoff { access_token, refresh_token } -> { code, expires_at }
// POST /auth/handoff/redeem { code } -> AuthResponse (the sign-in shape)
public record HandoffRequest(string? AccessToken, string? RefreshToken);
public record HandoffRedeemRequest(string? Code);
public record HandoffCodeResponse(string Code, string ExpiresAt);
// Process to Experience only: the response plus what the token says it is acting as.
public record HandoffRedeemed(AuthResponse Response, Guid? ActingOrgId, string? StudioKind);

// --- Invite redemption (public, unauthenticated, token-gated) ---
public record AcceptInviteRequest(string? Token, string? Password, bool? SupportsRefresh);

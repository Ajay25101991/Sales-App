// Delivery project from a workflow stage (to-do/delivery-project-from-workflow-design.md): the CRM asks Suntech Delivery (the project-management tool)
// for a DRAFT project when a deal enters a stage with "Create delivery project on entry". Wire shapes for the rep's screens, the delivery tool's
// status call back (Partner API) and the two webhook payloads.

namespace SalesApi.Dtos;

/// <summary>One service in the delivery tool's catalogue (GET /delivery/services).</summary>
public record DeliveryServiceDto(string Id, string Code, string Name, string? Category, string? Description);

/// <summary>POST /leads/{id}/delivery-project: the delivery tool's service ids the rep ticked.</summary>
public record DeliveryProjectInput(List<string>? ServiceIds);

/// <summary>One phase and how far along it is, as the delivery tool reports it.</summary>
public record DeliveryPhaseProgressDto(string Name, decimal Percent);

/// <summary>The deal's delivery project (GET /leads/{id}/delivery-project; null body when none was requested).</summary>
public record DeliveryProjectDto(
    Guid LeadId, string? PmProjectId, string? PmUrl, string Status, List<string> ServiceIds, List<DeliveryPhaseProgressDto> PhaseProgress,
    DateTime? LastSyncedAt, Guid RequestedBy, DateTime RequestedAt);

/// <summary>PUT /partner/v1/leads/{id}/delivery-project (scope delivery:write): what the delivery tool reports. Every field is optional; one that is absent is left as it was.</summary>
public record PartnerDeliveryProjectInput(string? PmProjectId, string? PmUrl, string? Status, List<DeliveryPhaseProgressDto>? PhaseProgress);

// ---- Webhook payloads (sent to Suntech Delivery's sales_app endpoint as project.requested / project.services_added) ----
// Property names are literal snake_case: the webhook queue serializes them with default options, exactly like DomainEventPayloads.

/// <summary>A person on the draft: shown by name and email, matched to a delivery user by email where one exists.</summary>
public sealed record DeliveryPerson(string? name, string? email);

/// <summary>One link to a file on the deal or its account. source: "sharepoint" (url is the SharePoint web link) or "crm" (url is the CRM page the file is listed on, opens after CRM sign-in).
/// scope: "deal" or "account".</summary>
public sealed record DeliveryFileLink(string name, string url, string source, string scope);

/// <summary>The body of project.requested (first request for the deal) and project.services_added (service_ids is ONLY the newly added ids). The webhook queue adds <c>event</c> and <c>delivery_id</c>.</summary>
public sealed record DeliveryProjectEvent(
    Guid lead_id, string lead_name, string? company,
    Guid? account_id, string? account_name, DeliveryPerson? account_owner, DeliveryPerson rep,
    List<string> service_ids, List<DeliveryFileLink> files,
    string? deal_url, string? account_url,
    Guid? org_id, string? org_name, string? pm_project_id,
    DateTime requested_at, DeliveryPerson requested_by);

// Admin settings wire shapes for the AI provider (E4.1 slice 2).
//
// Mirrors EmailProviderConfigDto/EmailProviderInput (SwipeActions.cs) exactly,
// per the design brief's "mirror the email provider settings endpoints"
// instruction. Bedrock's actual credentials (region, access key, secret) are
// NOT carried here — they live in a ConnectorConnection row under the
// "ai.bedrock" ConnectorRegistry key, read/written through the existing generic
// /integrations/{key}/credentials endpoints, so this DTO only ever needs to say
// whether a provider is chosen and how it should route each task class.
//
// Split into its own file from Ai.cs (which holds the gateway contracts in
// `namespace SalesApi.Services`) because a source file may declare only one
// file-scoped namespace, and these DTOs follow SwipeActions.cs/Settings.cs's
// convention of staying in `SalesApi.Dtos`.

namespace SalesApi.Dtos;

/// <param name="Status">What the next real gateway call would do, taken from
/// the same resolver a call uses — see EmailProviderConfigDto's identical note
/// on why this is never re-derived from the fields below.</param>
/// <param name="InfraEnabled">The deployment-wide <c>Ai:Enabled</c> kill switch,
/// surfaced read-only.</param>
/// <param name="AiAvailable">Whether an AI feature may run at all right now —
/// <see cref="SalesApi.Services.AiAvailability"/>'s verdict: a provider must be
/// connected AND an org budget must be set (design §17 item 5, "AI is OFF for
/// an org until configured... no default budget"). The full budget/cap table is
/// E4.3 (slice 5); <paramref name="AvailabilityReasonCode"/>/<paramref name="AvailabilityReason"/>
/// name whichever of the two is still missing.</param>
public record AiProviderConfigDto(
    string Status,
    string? StatusReason,
    bool InfraEnabled,
    bool Enabled,
    string Provider,
    IReadOnlyList<string> Available,
    string? CompleteModel,
    string? ExtractModel,
    string? ClassifyModel,
    string? EmbedModel,
    bool AiAvailable,
    string? AvailabilityReasonCode,
    string? AvailabilityReason);

/// <summary>Every field is optional so a partial save (e.g. only changing the
/// Complete model) doesn't force the caller to resend the rest — same
/// <c>?? existing</c> merge rule <c>SettingsStore.SaveEmailProviderAsync</c> already
/// applies.</summary>
public record AiProviderInput(
    bool? Enabled, string? Provider,
    string? CompleteModel, string? ExtractModel, string? ClassifyModel, string? EmbedModel);

// E12.6 - the in-CRM email compose (owner decisions 12, 16 and 30). Wire: to-do/sensitive-data-api.md section 8.
// No address is ever in the OUTPUT of a send. The input takes an optional `to` (the rep picked or typed it; required for an account, which has no
// email of its own); without one the server reads the address from the record, as before.

namespace SalesApi.Dtos;

/// <summary>POST /leads|contacts|accounts|invoices|amcs/{id}/emails. <c>To</c> is the address the rep picked or typed: REQUIRED for an account (it has no email of its own), optional elsewhere (absent = the record's own address, read on the server and never returned). <c>CompanyDocumentIds</c> are library documents to attach (their latest versions). <c>TemplateId</c> is informational (where the text started).
/// <c>ReplyToMessageId</c> is a synced email of the same lead to reply on. <c>QuoteFileIds</c> are a generated proposal's own files (its PDF /
/// PowerPoint attachment ids) to attach; each must be a generated quote file of this deal. <c>QuoteId</c> (<c>quote_id</c>, a lead email only) names the
/// proposal this email delivers: it must be a quote of this deal, and when the send SUCCEEDS a draft is marked sent through the PATCH-status-"sent" path.</summary>
public record SendRecordEmailInput(string? Subject, string? BodyHtml, Guid? TemplateId = null, Guid? ReplyToMessageId = null,
    List<string>? Cc = null, List<string>? Bcc = null, string? To = null, List<Guid>? CompanyDocumentIds = null,
    string? ToRecipientRef = null, List<string>? CcRecipientRefs = null, List<string>? BccRecipientRefs = null, List<Guid>? QuoteFileIds = null,
    Guid? QuoteId = null);

/// <summary>202 body: that it was sent, the subject Graph used, and whether it went as a reply. Never a recipient or the body.</summary>
public record RecordEmailSentDto(bool Sent, string Subject, bool AsReply);

/// <summary>GET /leads/{id}/email-recipients: one person who can be put on CC or BCC of an email on this deal - a contact (with an email) of the
/// deal's account, of its source partner (the "Partner" form field) or of its document partner. <c>Source</c> is "account", "partner" or "lead" (the deal's own email);
/// <c>SourceName</c> is that account's name (for the label "Account · X" / "Partner · X"). A person on two lists appears once, account first.</summary>
public record EmailRecipientCandidateDto(string Name, string? Email, string Source, string SourceName, bool IsDefault = false, string RecipientRef = "");

/// <summary>GET /leads/{id}/email-threads: one thread of the lead's synced email that is in the CALLER's own mailbox. <c>MessageId</c> is the latest
/// message of the thread - what <c>reply_to_message_id</c> takes. <c>Direction</c> is "sent" or "received" (of that latest message). No address.</summary>
public record RecordEmailThreadDto(Guid MessageId, string? Subject, DateTime? LastAt, string Direction);

/// <summary>POST /emails/{eventId}/reply-draft: a draft reply now sitting in the CALLER's own Outlook. <c>WebLink</c> opens it. <c>InThread</c> is true
/// when it replies on the original message (found in their mailbox), false when it is a new draft to the original correspondent (the email
/// was not in their mailbox, e.g. a team-mailbox email). Never an address or a body.</summary>
public record ReplyDraftDto(string WebLink, bool InThread);

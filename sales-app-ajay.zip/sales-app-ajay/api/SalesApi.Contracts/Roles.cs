// The Roles contracts.
//
// Split out for the API-led migration (step 8, roles domain). Mirrors
// SalesApi.Services.OrganizationRoleDefinition field-for-field on purpose:
// that record physically lives in SalesApi.SystemApi (it is what
// OrganizationRoleService persists), so it counts as a System type under
// LayerBoundaryTests even though it carries no EF/HTTP baggage. RoleDraft is
// the plain-value twin Process and Experience are allowed to speak; only
// SalesApi.SystemApi.Roles.RoleStore converts between the two.

namespace SalesApi.Dtos;

/// <summary>A role definition as GET /roles returns it: the stored role plus
/// <paramref name="Assignable"/>, a fact about the CALLER (may they hand this
/// role out?), not the persisted record.</summary>
public record RoleDefinitionDto(
    string Key,
    string Label,
    string BaseRole,
    List<string> Permissions,
    bool IsPredefined,
    string? ParentRoleKey,
    string? LeadVisibility,
    bool Assignable,
    // E12.1 — the role's level per sensitive-data category (always all six keys on a read).
    Dictionary<string, string>? DataAccess = null);

/// <summary>The plain-value shape of one role definition, in and out of
/// PUT /roles once past the controller's model binder.</summary>
public record RoleDraft(
    string Key,
    string Label,
    string BaseRole,
    List<string> Permissions,
    bool IsPredefined,
    string? ParentRoleKey = null,
    string? LeadVisibility = null,
    // E12.1 — category -> level. Optional/partial on a write (see to-do/sensitive-data-api.md section 1).
    Dictionary<string, string>? DataAccess = null);

/// <summary>The org's role config in Process/Experience terms: normalized role
/// definitions plus who is assigned which role key. Mirrors
/// OrganizationRoleConfig without naming it.</summary>
public record RoleConfigSnapshot(List<RoleDraft> Roles, Dictionary<Guid, string> Assignments);

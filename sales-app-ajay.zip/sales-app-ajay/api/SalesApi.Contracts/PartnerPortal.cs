namespace SalesApi.Dtos;

// Channel partners Phase 4 - the read-only partner portal (to-do/partner-management-design.md 9.3.2, owner decisions 4.1 / 4.8, 2026-10-19).
//
// A SEPARATE small web app (own address, e.g. /apps/partner) talks to the SAME API with a normal sign-in (/auth/signin, /auth/accept-invite). A portal user is an ordinary Profile whose
// PortalAccountId is set with PortalKind "partner"; the server default-denies it everywhere but these routes (PortalGuard). Several named users per partner, all with the same read-only view.
//
// OWN DTOs, on purpose. The portal never reuses DealPartnerDto / PartnerLedgerEntryDto / PartnerPayoutDto: those carry override reasons, internal ids of other records, the preparer, the
// approver, the decision note, other partners and bank details. Excluded here BY CONSTRUCTION (there is no field to fill): override reasons, plan and version ids, internal notes, other
// partners, clawback decisions and who decided, manager tasks, the CRM user directory, client contact details, payout bank details, deal values, the estimated usage charge.
// Rates and base amounts appear exactly as they already do on the partner's emailed statement (a statement line carries Rate and BaseDelta), so the portal discloses nothing the PDF did not.

/// <summary>The caller's partner, as DATA handed down from the controller (the layer rule: a Process class never reads a principal). Every portal query is filtered by it.</summary>
public sealed record PartnerPortalScope(Guid PartnerAccountId, Guid UserId);

public record PartnerPortalMeDto(
    Guid UserId, string Email, string? FullName, Guid PartnerAccountId, string PartnerName, string PartnerType, string PartnerStatus, string? Tier,
    string? OrganizationName, string Currency, bool MustChangePassword);

/// <summary>Earned / paid / owed from the STORED aggregate (PartnerStats) - the same figures the staff Partner tab shows. Owed = Accrued - Clawed - Paid.</summary>
public record PartnerPortalOverviewDto(
    string Currency, decimal Accrued, decimal Clawed, decimal Paid, decimal Owed, int DealCount, int OpenDeals, int WonDeals, int LostDeals,
    PartnerPortalLatestStatementDto? LatestStatement, int PayoutsOpen,
    // The partner's END CLIENTS: distinct client accounts on its ACTIVE deals, and the Year 1 / Year 2 values of those deals (sums of each deal's year1 / year2 below; null when no deal has a mark).
    int EndClients = 0, decimal? Year1Total = null, decimal? Year2Total = null);

public record PartnerPortalLatestStatementDto(Guid Id, string Number, DateOnly PeriodStart, DateOnly PeriodEnd, decimal ClosingBalance, DateTime IssuedAt);

/// <summary>One deal the partner is on. Phase is open | won | lost (never the CRM's stage names or a deal value). Earned / Paid / Owed follow the deal partner's own ledger.</summary>
public record PartnerPortalDealDto(
    Guid Id, string DealName, string? ClientName, string Role, string Phase, DateTime StartedAt, DateTime? EndedAt,
    decimal Earned, decimal Paid, decimal Owed, decimal CollectedBase,
    // The deal's Year 1 / Year 2 marks from its accepted (else newest live) quote, summed across services; null when the quote has no marks. The ONLY deal values the portal shows.
    decimal? Year1 = null, decimal? Year2 = null);

public record PartnerPortalDealDetailDto(PartnerPortalDealDto Deal, List<PartnerPortalEntryDto> Entries);

/// <summary>One line of what the partner earned or was paid. Kind is accrual | clawback | adjustment | payout; Settled = a payout already holds it.</summary>
public record PartnerPortalEntryDto(
    Guid Id, string Kind, decimal Amount, string Currency, DateTime EarnedAt, string? DealName, decimal BaseDelta, decimal? Rate, bool Settled);

public record PartnerPortalEntriesPageDto(List<PartnerPortalEntryDto> Entries, int Total);

public record PartnerPortalStatementLineDto(string? DealName, string Kind, decimal Amount, DateTime EarnedAt, decimal BaseDelta, decimal? Rate);

public record PartnerPortalStatementDto(
    Guid Id, string Number, string PartnerName, DateOnly PeriodStart, DateOnly PeriodEnd,
    decimal OpeningBalance, decimal Accruals, decimal Clawbacks, decimal Payouts, decimal ClosingBalance,
    List<PartnerPortalStatementLineDto> Lines, DateTime IssuedAt);

/// <summary>A payout the partner can see: approved (being paid) or paid. Drafts, submissions under review, rejections and cancellations are internal and never listed.</summary>
public record PartnerPortalPayoutDto(
    Guid Id, string Number, string Status, decimal NetAmount, decimal VatRate, decimal VatAmount, decimal GrossAmount, string Currency,
    string? PartnerInvoiceNumber, DateOnly? PartnerInvoiceDate, DateOnly? DueDate, DateTime? PaidAt, string? Method, string? Reference, int EntryCount);

/// <summary>Usage counts reported through this partner, by client, month and metric (live rows only). Counts, never a charge.</summary>
public record PartnerPortalUsageRowDto(Guid ClientAccountId, string ClientName, DateOnly Month, long InvoicesIssued, long InvoicesReceived, long ApiCalls);

public record PartnerPortalUsageDto(List<PartnerPortalUsageRowDto> Rows, long InvoicesIssued, long InvoicesReceived, long ApiCalls);

// ---------------------------------------------------------------------------------------------------------------------
// Staff side: inviting and managing the partner's portal users (partners.manage)
// ---------------------------------------------------------------------------------------------------------------------

/// <summary>
/// Invite a named person at the partner. Either <c>ContactId</c> (a contact already on the partner account: its name and email are used) or <c>Email</c> (+ <c>FullName</c>).
/// One email, one profile: an email already used by any CRM profile is refused.
/// </summary>
/// <summary>Invite one named person. E19.1: <c>IncludeChildren</c> applies to the customer kind only (also see the account's child accounts); ignored for partners.</summary>
public record PartnerPortalUserInviteInput(Guid? ContactId, string? Email, string? FullName, bool IncludeChildren = false);

public record PartnerPortalUserDto(
    Guid Id, string Email, string? FullName, bool IsActive, bool InvitePending, DateTime CreatedAt, DateTime? LastLoginAt, string Kind = "partner", bool IncludeChildren = false);

/// <summary>The new user, the one-time temporary password (share it only if the invite email could not be sent) and whether the invite email went out.</summary>
public record PartnerPortalUserInvitedDto(PartnerPortalUserDto User, string? TempPassword, bool? InviteSent, string? InviteError, string InviteUrlBase, string? InviteUrl = null);

// Wire shapes for the lead form LIBRARY (Controllers/LeadFormsController.cs —
// design doc D2, 2026-08-25).
//
// Moved here from SalesApi.SystemApi/Dtos/LeadFormLibraryDtos.cs during the
// API-led migration (step 8, lead-forms domain): none of these three carry a
// System type, so they belong in Contracts, same as every other domain's
// plain wire records. The namespace stays `SalesApi.Dtos`, so the move costs
// zero `using` edits.
//
// NOT every lead-form wire shape could move. `LeadFormDraftDto` names
// `SalesApi.Services.LeadFormSchemaModel` and stays behind in
// SalesApi.SystemApi/Dtos/SystemBoundContracts.cs — see that file's comment
// and the plan doc's step 4 note. That is also why GetDraft/SaveDraft/Publish/
// Rollback below still call SalesApi.Services.LeadFormService directly from
// the controller rather than through Process/Experience: a layer built to
// return LeadFormDraftDto would itself be a System type on a Process surface.

namespace SalesApi.Dtos;

/// <summary>One row of the forms library list — no schema, same reasoning as
/// PlaybooksController's own list row (a library screen renders many rows and
/// must not pull every version's jsonb to do it).
///
/// Form builder rework (2026-10-16), all trailing and optional: <see cref="IsLive"/> = a published version exists
/// (routing only ever serves such a form); <see cref="HasUnpublishedChanges"/> = a working draft is open;
/// <see cref="UsedByTeams"/> = teams that get this form RIGHT NOW (team -> assigned live playbook -> this form);
/// <see cref="WaitingTeams"/> = teams whose playbook points here but who do not get it yet (draft, or another
/// published form on the same playbook wins).
/// </summary>
public record LeadFormSummaryDto(
    Guid Id, string Name, string Key, Guid? PlaybookId, int? LiveVersion, int? DraftVersion,
    DateTime CreatedAt, DateTime? ArchivedAt,
    bool IsLive = false, bool HasUnpublishedChanges = false, string? PlaybookName = null,
    DateTime? LastPublishedAt = null, string? LastPublishedBy = null,
    DateTime? DraftUpdatedAt = null, string? DraftUpdatedBy = null,
    List<LeadFormTeamRefDto>? UsedByTeams = null, List<LeadFormTeamRefDto>? WaitingTeams = null,
    List<LeadFormWarningDto>? Warnings = null);

public record LeadFormTeamRefDto(Guid Id, string Name);

/// <summary>A library warning. <see cref="Code"/> is stable: <c>playbook_two_forms</c> (more than one form points
/// at the playbook; <see cref="FormIds"/> lists them) or <c>playbook_without_form</c> (a live playbook that teams
/// are assigned has no live form, so those teams fall to the no-playbook policy; <see cref="FormIds"/> is empty).</summary>
public record LeadFormWarningDto(
    string Code, string Message, Guid PlaybookId, string PlaybookName,
    List<Guid> FormIds, List<LeadFormTeamRefDto> Teams);

/// <summary>Where a field is used, for the Fields screen's "Used on N forms" column.</summary>
public record LeadFormFieldUsageDto(Guid FormId, string FormName, bool OnLiveVersion, bool OnDraft);

/// <summary><see cref="Key"/> is the E7.1 stable identity (design doc §10
/// owner answer 5) — left null to pre-fill it from <see cref="Name"/>. There
/// is no update endpoint for it: editing it after creation is refused by
/// omission, not by a guard.
/// <see cref="CopyFromFormId"/> (owner decision 9): seed the new form's DRAFT from that form's working copy
/// (its draft, else its latest) instead of the blank factory layout.</summary>
public record CreateLeadFormRequest(string? Name, Guid? PlaybookId, string? Key = null, Guid? CopyFromFormId = null);

/// <summary>
/// Either field left null leaves it unchanged. To clear the playbook link
/// (rather than leave it as-is), set <see cref="ClearPlaybook"/> — see
/// LeadFormService.UpdateFormAsync's doc comment for why a third state is
/// needed here and a bare null can't mean it.
/// </summary>
public record UpdateLeadFormRequest(string? Name, Guid? PlaybookId, bool? ClearPlaybook);

namespace SalesApi.Dtos;

/// <summary>
/// E7.6 (owner answer 2026-09-29, to-do/epics-ai-native-crm.md row "E7.6 plans +
/// E7.7 SSO"): the fixed, in-code catalogue of gateable FEATURE keys (things a
/// plan can switch on) and METER keys (things a limit can count). Plans
/// themselves are DATA a platform admin defines (name, which of these features,
/// which of these meters get a limit and at what amount/mode) — see
/// <c>Models.Plan</c>. This file is the vocabulary that data is built from,
/// same "fixed vocabulary, not admin-editable" shape as
/// <c>Services.NotificationEvents</c>: a feature/meter key nobody declared here
/// cannot be turned on in a plan, so a typo cannot silently create a dead
/// switch.
///
/// No project references (SalesApi.Contracts has none) — every layer, and
/// eventually the desktop client's generated types, can read this without
/// pulling in EF or ASP.NET.
/// </summary>
public static class PlanCatalogue
{
    /// <summary>How a plan's <c>PlanLimit</c> enforces once a meter reaches its
    /// amount: <c>Warn</c> notifies org admins at 80% and 100% and never stops
    /// anything; <c>Stop</c> pauses the gated feature until the meter's period
    /// resets. Chosen per limit by the platform admin, never inferred.</summary>
    public static class LimitModes
    {
        public const string Warn = "warn";
        public const string Stop = "stop";
        public static readonly string[] All = [Warn, Stop];
        public static bool IsValid(string? v) => v is not null && All.Contains(v);
    }

    public sealed record FeatureDef(string Key, string Label, string EnforcedBy);

    /// <summary>
    /// Owner 2026-11-17 (MCP server, item 4): a plan stores what is switched OFF, so a feature added later starts ON - except the opt-in ones
    /// (<see cref="Features.Mcp"/>), which start OFF on every plan until a platform admin switches them on. An opt-in feature is stored the other
    /// way round, as <c>on:{key}</c> in the same list (no migration, no new column), and an org with NO plan row gets them OFF as well.
    /// </summary>
    public const string OptInMarkerPrefix = "on:";

    /// <summary>
    /// Real, separately-gateable modules already in the app. "EnforcedBy" names
    /// the exact choke point <c>Services.PlanEnforcement</c> is called from for
    /// that feature — see that class and each site for the actual check.
    /// </summary>
    public static class Features
    {
        /// <summary>Any AI feature call (E4 gateway). Checked inside
        /// <c>Services.LoggingAiPlatform.CheckAsync</c>, the same single choke
        /// point every AI call already passes through for the E4.3 budget/
        /// feature-off checks — this is one more check in that same list, not
        /// a second mechanism.</summary>
        public const string Ai = "ai";

        /// <summary>The automation engine (E2.3). Checked when a new
        /// automation is created/published/enabled
        /// (<c>Controllers.AutomationsController</c>, via
        /// <c>RequirePlanFeatureAttribute</c>) and again by the background
        /// scan (<c>Services.AutomationRunner</c>) before it acts on a due
        /// automation for an org — a plan downgrade takes effect on the very
        /// next sweep, not only on the next admin edit.</summary>
        public const string Automations = "automations";

        /// <summary>Sending/receiving WhatsApp messages (E6.4). Checked on
        /// <c>POST /leads/{id}/whatsapp</c> via
        /// <c>RequirePlanFeatureAttribute</c>.</summary>
        public const string WhatsApp = "whatsapp";

        /// <summary>The LinkedIn Lead Sync connector (E6.4). Checked when a
        /// sync is enabled/run via <c>RequirePlanFeatureAttribute</c>.</summary>
        public const string LinkedIn = "linkedin";

        /// <summary>The Meta (Facebook / Instagram) Lead Ads connector. Same plans as <see cref="LinkedIn"/> (owner
        /// 2026-11-14). Checked on every <c>/integrations/meta</c> admin action via
        /// <c>RequirePlanFeatureAttribute</c>, and by the public webhook before it creates a lead
        /// (<c>MetaLeadSyncProcess.HandleWebhookAsync</c>).</summary>
        public const string MetaLeadAds = "meta_lead_ads";

        /// <summary>The developer API: scoped API keys beyond the website-form key, the partner API those keys call, and outgoing webhooks
        /// (owner decision 8, integrations audit). Checked via <c>RequirePlanFeatureAttribute</c> on <c>WebhooksController</c>,
        /// <c>PartnerApiController</c>, <c>PartnerUsageApiController</c>, <c>PartnerDeliveryApiController</c> and the API-key
        /// settings, and by <c>ApiKeyProcess</c> for creating / editing / rotating a key. NEVER checked for website lead capture:
        /// <c>POST /public/leads</c> and a key whose only scope is <c>leads:create</c> always work.</summary>
        public const string ApiWebhooks = "api_webhooks";

        /// <summary>Microsoft 365 mailbox/calendar sync (E6.1/E6.2). Checked
        /// alongside the deployment-level <c>Mailbox:Enabled</c> flag on
        /// <c>POST /mailbox/connect/start</c> via
        /// <c>RequirePlanFeatureAttribute</c> — the config flag decides
        /// whether the DEPLOYMENT offers mailbox sync at all; this decides
        /// whether THIS ORG's plan includes it.</summary>
        public const string MailboxSync = "mailbox_sync";

        /// <summary>Studio — sandbox creation and package export/import
        /// (E7.0-E7.4). Checked on sandbox creation
        /// (<c>Controllers.SandboxController</c>) via
        /// <c>RequirePlanFeatureAttribute</c>.</summary>
        public const string Studio = "studio";

        /// <summary>Scheduled report delivery (E3.10). Checked when a report
        /// schedule is created via <c>RequirePlanFeatureAttribute</c>.</summary>
        public const string ScheduledReports = "scheduled_reports";

        /// <summary>AI tool connections (MCP): the <c>/mcp</c> endpoint AI tools (Claude and others) connect to. OPT-IN: off on every plan until a
        /// platform admin switches it on (see <see cref="PlanCatalogue.OptInMarkerPrefix"/>). Checked per call by <c>McpAccess</c> (person and API key).</summary>
        public const string Mcp = "mcp";

        /// <summary>Features that start OFF (see <see cref="PlanCatalogue.OptInMarkerPrefix"/>); every other feature starts ON.</summary>
        public static readonly string[] OptIn = [Mcp];
        public static bool IsOptIn(string key) => Array.IndexOf(OptIn, key) >= 0;

        public static readonly FeatureDef[] All =
        [
            new(Ai, "AI features", "LoggingAiPlatform.CheckAsync (every AI call)"),
            new(Automations, "Automations", "AutomationsController create/publish/enable + AutomationRunner sweep"),
            new(WhatsApp, "WhatsApp messaging", "WhatsAppController.Send"),
            new(LinkedIn, "LinkedIn lead sync", "LinkedInLeadSyncController enable/sync"),
            new(MetaLeadAds, "Meta Lead Ads", "MetaLeadAdsController (all admin actions) + the Meta webhook"),
            new(ApiWebhooks, "API keys & webhooks", "ApiKeysController (all but website lead keys); WebhooksController; PartnerApiController, PartnerUsageApiController, PartnerDeliveryApiController"),
            new(MailboxSync, "Mailbox/calendar sync", "MailboxConnectController connect/start; SharedMailboxController create/check (team mailboxes)"),
            new(Studio, "Studio (sandboxes & packages)", "SandboxController create"),
            new(ScheduledReports, "Scheduled reports", "ReportSchedulesController create"),
            new(Mcp, "AI tool connections (MCP)", "McpAccess (every /mcp tool call, person and API key)"),
        ];

        public static readonly string[] AllKeys = [.. All.Select(f => f.Key)];

        /// <summary>The features a plan with no stored choices (or no plan at all) has ON: everything except the opt-in ones.</summary>
        public static readonly string[] DefaultOnKeys = [.. AllKeys.Where(k => !IsOptIn(k))];
        public static bool IsValid(string? key) => key is not null && AllKeys.Contains(key);
    }

    public sealed record MeterDef(string Key, string Label, string ComputedFrom, string ResetBoundary);

    /// <summary>
    /// Things a plan can put a numeric limit on. Every meter is COMPUTED from
    /// data that already exists elsewhere — this catalogue deliberately does
    /// not introduce a second counter for anything E4.2/E4.3 (or any other
    /// domain) already counts; see <c>Services.PlanMeters</c> for the exact
    /// query behind each key.
    /// </summary>
    public static class Meters
    {
        /// <summary>Count of <c>AiExecutionLogEntry</c> rows with
        /// <c>Outcome == AiExecutionOutcomes.Ok</c> (calls that actually ran —
        /// a refused/errored attempt never reached the provider and is not
        /// "AI usage"), in the org's current reporting-calendar month. Reuses
        /// the exact table <c>AiCostPolicy</c>'s own budget enforcement already
        /// sums by cost — this counts ROWS instead of USD, no new table.</summary>
        public const string AiCallsPerMonth = "ai_calls_per_month";

        /// <summary>Count of active (<c>Profile.IsActive == true</c>) profiles
        /// in the org, evaluated LIVE — this one has no monthly reset; the
        /// "period" reported alongside it is the current calendar month purely
        /// so its warn-threshold notices dedupe the same way every other
        /// meter's do (see <c>Models.PlanLimitNotice</c>), not because the
        /// count itself resets.</summary>
        public const string ActiveUsers = "active_users";

        /// <summary>Count of <c>WhatsAppOutboundMessage</c> rows (one per
        /// message this app sent, E6.4 slice 8) in the org's current
        /// reporting-calendar month.</summary>
        public const string WhatsAppMessagesPerMonth = "whatsapp_messages_per_month";

        public static readonly MeterDef[] All =
        [
            new(AiCallsPerMonth, "AI calls", "AiExecutionLog rows, outcome=ok", "calendar month, org timezone"),
            new(ActiveUsers, "Active users", "Profiles where IsActive", "live count, no reset"),
            new(WhatsAppMessagesPerMonth, "WhatsApp messages sent", "WhatsAppOutboundMessage rows", "calendar month, org timezone"),
        ];

        public static readonly string[] AllKeys = [.. All.Select(m => m.Key)];
        public static bool IsValid(string? key) => key is not null && AllKeys.Contains(key);
    }

    /// <summary>One limit inside a <c>Models.Plan</c>: a meter, an amount, and
    /// a mode. Stored as a JSON array on the Plan row (<c>PlanJson</c>
    /// serializes/deserializes it) — same "small admin-edited shape, JSON
    /// column, own file" pattern <c>AiCostPolicy.ModelPricesJson</c> and
    /// <c>Services.AiCostPolicyJson</c> already use.</summary>
    public sealed record PlanLimit(string MeterKey, decimal Amount, string Mode);

    /// <summary>The seed plan's key (migration-created, assigned to every
    /// existing org and to a new org that gets no explicit assignment —
    /// "deploy safety": every feature on, no limits, so nothing changes for
    /// anyone on deploy).</summary>
    public const string AllFeaturesPlanKey = "all-features";
    public const string AllFeaturesPlanName = "All features";
}

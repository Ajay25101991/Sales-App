// E10.4 / E10.9 - deck and letter template contracts, and the inputs/outputs of the document renderer the proposal generator
// (E10.5) calls. Wire contract: to-do/proposal-generator-api.md. The namespace stays `SalesApi.Dtos` like every other contract file.

namespace SalesApi.Dtos;

/// <summary>One token found in an uploaded template. Status: "ok", "unknown" (not an available field, left visible when filled),
/// "bad_formatter" (the formatter does not exist, left visible), "structural" (a wrapper layout marker). HasFallback = the token
/// carries <c>|else:text</c>, so a blank value prints that text instead of a gap.</summary>
public record TemplateFieldDto(string Name, string? Formatter, int Count, string Status, bool SplitAcrossRuns, bool HasFallback = false);

/// <summary>Something to fix or know about a template. Code is stable: unknown_field, bad_formatter, split_placeholder,
/// malformed_placeholder, no_fields, no_summary_row, no_insert_marker.  Severity: "warning" (the file is still saved and used).</summary>
public record TemplateIssueDto(string Code, string Message, string? Field = null, string Severity = "warning");

/// <summary>What the check of one template found.</summary>
public record TemplateCheckDto(
    List<TemplateFieldDto> Fields, List<TemplateIssueDto> Issues, int Slides, List<ConditionalShapeDto>? Conditions = null);

/// <summary>A shape (deck) or content control (letter) named "if:FIELD": removed when FIELD is blank. Negate = "if:!FIELD" (kept only when
/// blank); Formatter = "if:FIELD|second" (judges the formatted value). Status: "ok", "unknown" (not an available field, so it is never
/// removed) or "bad_formatter" (the formatter does not exist, so it is never removed).</summary>
public record ConditionalShapeDto(string Field, int Count, string Status, bool Negate = false, string? Formatter = null);

/// <summary>One uploaded version of a deck or letter template. CatalogItemId is null for the org wrapper. Variant is the agreement's
/// name when a letter slot is split into several (null = the single unnamed slot).</summary>
public record DocumentTemplateVersionDto(
    Guid Id, string Kind, Guid? CatalogItemId, int Version, string FileName, long SizeBytes,
    DateTime UploadedAt, Guid? UploadedById, TemplateCheckDto Check, string? Variant = null,
    // Kind "irl" only: what the workbook's _map + Lists sheets were read as (null for a deck or letter).
    IrlTemplateInfoDto? Irl = null);

/// <summary>The latest version of one slot, or none yet. The list the service editor and settings screen draw. A letter slot with
/// named agreements lists the unnamed slot first and then one row per Variant.</summary>
public record DocumentTemplateSlotDto(
    string Kind, Guid? CatalogItemId, string? ServiceName, int? LatestVersion, DateTime? UploadedAt, Guid? UploadedById, string? FileName,
    string? Variant = null);

/// <summary>A field a template may use (GET /document-templates/fields).</summary>
public record DocumentFieldDto(string Name, string Label, string Group);

public record DocumentFieldsDto(List<DocumentFieldDto> Fields, List<DocumentFormatterDto> Formatters);
public record DocumentFormatterDto(string Name, string Description);

// ---- rendering (called by the proposal generator, not an HTTP body) ------------------------------------------------

/// <summary>A pricing input as the rep entered it. Value is null for a blank optional input. Picks (a "choice" input) and Rows (a "number_list") are what was picked / entered, see <see cref="SnapshotInputDto"/>.</summary>
public record RenderInputValue(string Key, string Label, string Type, decimal? Value, List<SnapshotPickDto>? Picks = null, List<decimal>? Rows = null);

/// <summary>A calculated result of the service's pricing model. Format is "money" or "number".</summary>
public record RenderResultValue(string Key, string Label, string Format, decimal Value);

/// <summary>
/// One service of the quote. Year1 / Year2 are the results the service's pricing model MARKS as Year 1 / Year 2
/// (PricingEvaluationDto.Year1 / Year2); null = not marked, shown as an en dash and left out of the totals.
/// DealValue is the result marked "deal value". DeckVersion / LetterVersion pin the template version the quote started with
/// (null = the newest).
/// </summary>
public record RenderServiceInput(
    Guid CatalogItemId, string ServiceName, List<RenderInputValue> Inputs, List<RenderResultValue> Results,
    decimal DealValue, decimal? Year1 = null, decimal? Year2 = null, int? DeckVersion = null, int? LetterVersion = null);

/// <summary>
/// Everything the renderer needs about one quote version. LeadId names the deal (the generator has already checked the caller
/// may see it). QuoteId is the quote version row the files are attached to; its chain's SharePoint folder receives them.
/// QuoteNumber may carry the revision suffix (QT-2026-0012-v3): file names and the QUOTE_NUMBER field drop it.
/// DocumentVersion is the number in the file name: the quote version for a proposal, the letter's own version for a letter.
/// WrapperVersion pins the wrapper deck / letter (null = the newest). AsOf is "today" (null = now).
/// </summary>
public record RenderDocumentInput(
    Guid QuoteId, Guid LeadId, string QuoteNumber, int QuoteVersion, int DocumentVersion, Guid UploaderId,
    List<RenderServiceInput> Services, string? Currency = null, int? WrapperVersion = null, DateTime? AsOf = null,
    // E10.5: true = a PDF that Graph cannot make is NOT a failure. The .pptx/.docx stays saved, the call succeeds with
    // RenderedDocumentDto.PdfError set and no pdf file. False (default) keeps the original behaviour (Unavailable).
    bool KeepOnPdfFailure = false,
    // E10.5: the quote's money lines after discount and VAT. Null (letters, older callers) = the TOTAL_* fields fall back to
    // the services' sum with no discount and no VAT.
    RenderTotals? Totals = null);

/// <summary>Gross = sum of the services' deal values; Discount as printed; ExVat = Gross - Discount (the deal value); Vat at TaxRate (percent); Total = ExVat + Vat.</summary>
public record RenderTotals(decimal Gross, decimal Discount, decimal ExVat, decimal TaxRate, decimal Vat, decimal Total);

/// <summary>A file saved in the quote chain's SharePoint folder (and listed as a file of the quote). Kind: "pptx", "docx" or "pdf".</summary>
public record RenderedFileDto(string Kind, string FileName, Guid AttachmentId, string? WebUrl, long SizeBytes);

/// <summary>The template version one slot was rendered from, so the quote can record it.</summary>
public record TemplateVersionUsedDto(string Kind, Guid? CatalogItemId, int Version, string? Variant = null);

/// <summary>The saved files, the template versions used, and fields that were left as written because nothing could fill them.
/// Variant is the agreement this document is (null = the unnamed letter / a deck).</summary>
public record RenderedDocumentDto(
    List<RenderedFileDto> Files, List<TemplateVersionUsedDto> TemplatesUsed, List<string> LeftVisible, string? PdfError = null,
    string? Variant = null);

// ---- the generator's "blank fields these templates use" (GET /leads/{id}/proposals/blank-fields) --------------------------

/// <summary>
/// A document field the chosen templates use whose value is blank on this deal, so the generator can ask for it.
/// Token is the name as written in the template (DEAL_FIELD_ERP_SYSTEMS, ACCOUNT_FIELD_TRN, PARTNER_FIELD_TRN, PARTNER_NAME ...).
/// ObjectType says whose value to ask for: "lead" (the deal), "account" (the client) or "partner" (the deal's partner account).
/// FieldKey / Label / Type / Options / PicklistKey are the custom-field definition (null FieldKey = a built-in: PARTNER_NAME and the
/// other PARTNER_ address tokens, which are blank when the deal has no partner; Type is then "partner_account"). HasFallback = every use of
/// the token carries <c>|else:</c>, so a generic wording exists if the rep does not fill it. UsedBy names the templates that use it.
/// </summary>
public record DocumentBlankFieldDto(
    string Token, string ObjectType, string? FieldKey, string Label, string Type, List<string> Options, string? PicklistKey,
    bool HasFallback, List<string> UsedBy);

/// <summary>An agreement name that has a letter template: under a service (CatalogItemId) or the organisation's wrapper (null).</summary>
public record AgreementNameDto(Guid? CatalogItemId, string Variant);

public record AgreementNamesDto(List<AgreementNameDto> Agreements);

public record DocumentBlankFieldsDto(List<DocumentBlankFieldDto> Fields);

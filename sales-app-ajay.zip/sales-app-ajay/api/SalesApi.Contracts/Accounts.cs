// The Accounts contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

using System.Text.Json;

namespace SalesApi.Dtos;

// --- Accounts & Contacts ---
public record AccountDto(
    Guid Id,
    Guid OwnerId,
    string Name,
    string? Industry,
    string? Website,
    string? Phone,
    string? Notes,
    string? Address,
    string? City,
    string? State,
    string? PostalCode,
    string? Country,
    string? OwnerName,
    int ContactCount,
    int OpenLeads,
    // Money masking (owner decision 2026-09-27, account-money-masking):
    // mirrors LeadMapping.ToDto's own convention EXACTLY — a caller without
    // the relevant permission gets null, not zero, because zero is a real,
    // renderable figure ("no open pipeline") and null is the only value that
    // reads as "you may not see this". OpenValue/OpenLeads' own value side is
    // masked without ViewLeadValues (the same permission LeadDto.EstimatedValue
    // already gates on); WonValue/Outstanding/Overdue/NextPromisedDate are
    // masked without ViewAccountFinancials. OpenLeads (a COUNT, not a value)
    // stays unmasked, same as LeaderboardRowDto's WonCount beside a masked
    // WonValue.
    decimal? OpenValue,
    decimal? WonValue,
    // Receivables (E2) — computed from this account's invoices, not lead
    // estimates. Zero when the account has no invoices, which is a fact
    // ("nothing billed yet"), not a rounding artifact — masking (see above)
    // is a SEPARATE null, only ever produced by a missing permission.
    decimal? Outstanding,
    decimal? Overdue,
    DateTime? NextPromisedDate,
    DateTime CreatedAt,
    DateTime UpdatedAt,
    // The first few contacts by name, so a list row can say WHO an account is
    // rather than only how many people are on it. Capped here, not in the
    // client: an account with fifty contacts should not ship fifty strings per
    // row to render three. ContactCount stays the authority on the total.
    List<string>? ContactNames = null,
    // Country picker (alpha-2) — same picker, same "free text stays" rule as
    // Lead.CountryCode/LeadDto.CountryCode.
    string? CountryCode = null,
    // E3.1 — custom field values, masked exactly like LeadDto.Custom (see
    // CustomFieldMasking): a sensitive/role-restricted key reads back as the
    // literal string "Hidden" for a caller outside its visible_to_roles.
    // Nullable (unlike LeadDto's required Custom) specifically so this
    // trailing param defaults safely: `default(JsonElement)` is ValueKind
    // Undefined, which THROWS on serialization — a real trap for any older
    // positional construction (tests, an importer) that omits it. Every real
    // mapper (AccountProcess's ToDto/ContactToDto) always supplies a real
    // value; null only ever appears from a construction that didn't ask for
    // custom fields at all.
    JsonElement? Custom = null,
    // E6.1 (design doc to-do/e6-capture-design.md §4.1) — the majority
    // non-free-mail domain among this account's contacts, derived
    // automatically or set explicitly via AccountInput.EmailDomain below.
    string? EmailDomain = null,
    // Accounts rework: the ONE shared last-contact rule across the account's own activities and ALL its leads (open and
    // closed) incl. synced Microsoft 365 mail and meetings; null when never contacted. NextStep: soonest of the
    // account's open tasks, its leads' open tasks, open leads' follow-ups and the next synced meeting; null when none.
    DateTime? LastContactAt = null,
    NextStepDto? NextStep = null,
    // Decision 9: the account's OWN tags (AccountTag), and - separately - the union of its leads' tags. Null when the
    // response did not load them (create/update responses and the like carry them; match results do too).
    List<TagRefDto>? Tags = null,
    List<TagRefDto>? LeadTags = null,
    // The earliest ACTIVE contract (AMC) renewal date on the account - the SAME definition the renewal_date column filter and
    // the "Renewal in M days" view use (AccountColumnRegistry.ActiveAmc). Null when it has no active contract.
    DateTime? RenewalDate = null,
    // E12.2 - see LeadDto.FieldAccess.
    Dictionary<string, string>? FieldAccess = null,
    // E12.5 - category -> the instant an approved reveal stops applying to THIS record for this caller (absent = no active reveal).
    Dictionary<string, DateTime>? RevealExpiresAt = null,
    // Account status (owner decision 2026-11-03): the KEY of one of the org's account_statuses picklist values. Information only.
    string? Status = null,
    // E14.6: DIRECT children counted under the org's child-count status rule (stored on the account, kept by AccountChildCount).
    int ChildCount = 0,
    // E14.1: for each field the org lists as inheriting, whether THIS account follows its parent and from whom. Null when the account
    // has no parent or the org lists no inheriting field. Keys are the inheritance field keys ("industry", "custom.vat_trn", ...).
    Dictionary<string, AccountInheritedFieldDto>? InheritedFields = null,
    // E20.1: the stored loyalty standing (kept by LoyaltyStanding): points over the org's loyalty window, and the tier key that earns. LoyaltyTier is null for an
    // account with no ledger event. These are the REPORTING figures (exact as of the last ledger write or nightly sweep); /accounts/{id}/loyalty is the live read.
    int LoyaltyBalance = 0, string? LoyaltyTier = null);

/// <summary>
/// E14.1: one inheriting field of a child account. <c>Following</c> true = the value shown is copied from the parent's stored value
/// (and changes when the parent's does); false = this account overrides it and keeps its own value until "follow parent again".
/// <c>FromAccountId</c>/<c>FromAccountName</c> name the DIRECT parent either way.
/// </summary>
public record AccountInheritedFieldDto(bool Following, Guid FromAccountId, string FromAccountName);

/// <summary>E14.1: POST /accounts/{id}/follow-parent. The inheriting field keys to follow again; omitted or empty = every one the account overrides.</summary>
public record AccountFollowParentInput(List<string>? Fields = null);

public record AccountInput(
    string? Name, string? Industry, string? Website, string? Phone, string? Notes,
    string? Address, string? City, string? State, string? PostalCode, string? Country,
    string? CountryCode = null, JsonElement? Custom = null,
    // E6.1 — an explicit edit always wins over the automatic derivation
    // (AccountProcess.RecomputeEmailDomainAsync only fills a NULL value, see
    // its own comment); empty string clears a previously-set domain.
    string? EmailDomain = null,
    // Accounts rework (decision 9): set the account's OWN tags exactly like a lead's - the ids of existing org tags, and/or
    // names (a new name mints a tag and needs tags.create). When either is sent the account's tag set becomes exactly that.
    Guid[]? TagIds = null, string[]? TagNames = null,
    // The status KEY; validated against the org's account_statuses picklist (unknown key = 400). Omitted = unchanged (a create starts at prospect).
    string? Status = null,
    // E14.1: CREATE only - the new account is made a child of this account (same checks as PUT /accounts/{id}/parent) and starts
    // following the org's inheriting fields. Ignored on PATCH: re-parenting is PUT /accounts/{id}/parent.
    Guid? ParentAccountId = null);

/// <summary>
/// Account status (owner decision 2026-11-03). The list is the org's "account_statuses" picklist (OrgPicklist.Keys.AccountStatuses):
/// admins rename, add, archive, reorder and (when unused) delete values like any picklist. These are the seed and the two keys the
/// system itself refers to: a new account starts at <see cref="Prospect"/>, and winning a deal moves a prospect to <see cref="ActiveCustomer"/>.
/// Information only - nothing is blocked by a status. Separate from a channel partner's own status (<c>ChannelPartnerVocab.Status</c>).
/// </summary>
public static class AccountStatusVocab
{
    public const string PicklistKey = "account_statuses";
    public const string Prospect = "prospect";
    public const string ActiveCustomer = "active_customer";
    public const string Inactive = "inactive";
    public const string FormerCustomer = "former_customer";
    public const int MaxLength = 40;

    public static readonly (string Key, string Label)[] Defaults =
    [
        (Prospect, "Prospect"), (ActiveCustomer, "Active customer"), (Inactive, "Inactive"), (FormerCustomer, "Former customer"),
    ];
}

// PhoneCountryCode is a TRAILING optional parameter — same convention as
// LeadDto.PhoneCountryCode (ISO 3166-1 alpha-2, not a dial string). Inserting
// it earlier would silently shift every later field at positional call sites.
// E3.4 — ReportsToContactId/ReportsToContactName additive tail, same
// optional-tail convention PhoneCountryCode/Custom already set.
public record ContactDto(
    Guid Id, Guid AccountId, string Name, string? Title, string? Email, string? Phone, string? Notes,
    DateTime CreatedAt, string? PhoneCountryCode = null, JsonElement? Custom = null,
    Guid? ReportsToContactId = null, string? ReportsToContactName = null,
    // E12.2 - see LeadDto.FieldAccess.
    Dictionary<string, string>? FieldAccess = null,
    // E12.5 - category -> the instant an approved reveal stops applying to THIS record for this caller (absent = no active reveal).
    Dictionary<string, DateTime>? RevealExpiresAt = null,
    // E16.3 - the language this person is written to ("en", "ar"); null reads as English.
    string? PreferredLanguage = null,
    // E16.1 - channel ("email" | "sms" | "whatsapp") -> when the contact opted out; the key is absent when they are not opted out of anything.
    Dictionary<string, DateTime>? OptedOut = null,
    // The roles this person usually plays on a deal (org buying-roles picklist keys); every open deal inherits them unless overridden.
    List<string>? BuyingRoles = null);

// E3.11d — GET /contacts/{id}: the single-contact read the account-detail
// screen's Contacts card never needed (it already gets every contact off
// AccountDetailDto.Contacts), but a standalone contact-detail screen does.
// Mirrors AccountDetailDto's own "wrap the record with the parent it belongs
// to" shape: a contact is meaningless without knowing which account it is
// on, so AccountId/AccountName travel alongside it rather than making the
// client issue a second GET /accounts/{id} just to render a breadcrumb.
public record ContactDetailDto(ContactDto Contact, Guid AccountId, string AccountName);

// GET /contacts - one row of the all-contacts table. The masked fields (email, phone, custom, field_access, opted_out) are exactly
// what ContactDto carries for the same contact; the rest is what the table's columns read that ContactDto lacks: the company, the
// account's name and the ACCOUNT's owner and team (a contact has none of its own).
public record ContactListItemDto(
    Guid Id, Guid AccountId, string? AccountName, string Name, string? Title, string? Company,
    string? Email, string? Phone, string? PhoneCountryCode, string? PreferredLanguage,
    Dictionary<string, DateTime>? OptedOut,
    Guid? OwnerId, string? OwnerName, Guid? TeamId, string? TeamName,
    JsonElement? Custom, Dictionary<string, string>? FieldAccess, DateTime CreatedAt, DateTime UpdatedAt);

// POST /leads/{id}/promote-contact — "created" is true only when no matching
// contact existed on the account and a new row was made; false covers both
// "linked to an existing contact just now" and "was already linked". Outcome
// spells out which of the three so the client can say something specific
// ("Already linked to Jane Doe" vs "Linked to existing contact" vs "Created
// new contact") — see Services/ContactPromotionEffect.
public record PromoteContactResultDto(ContactDto Contact, bool Created, string Outcome);
// PhoneCountryCode trailing, same reasoning as ContactDto above.
public record ContactInput(
    string? Name, string? Title, string? Email, string? Phone, string? Notes,
    string? PhoneCountryCode = null, JsonElement? Custom = null,
    // E16.3 - a language code ("en", "ar"); an empty string clears it back to English.
    string? PreferredLanguage = null,
    // Buying roles (picklist keys). Sent = replaces the contact's roles (an empty list clears them); omitted = unchanged.
    List<string>? BuyingRoles = null);

// PUT /contacts/{id}/reports-to — E3.4. Null clears it (a person left, or was
// never actually reporting to anyone). A dedicated endpoint, not a field on
// ContactInput/UpdateAsync: it needs its own loop-refusal check
// (ContactProcess.SetReportsToAsync), the same reason SetParentAsync is its
// own endpoint on accounts rather than a field on AccountInput/UpdateAsync.
public record ContactReportsToInput(Guid? ReportsToContactId);

// Account detail bundles its contacts + a light view of its linked leads.
// PlaybookId is additive/optional (null = org list, D5) so an older client that
// doesn't read it keeps working; the account-detail screen needs it to resolve
// this lead's status label/phase against ITS OWN playbook rather than the org's.
// E3.11 — DealType/ContactId additive, same optional-tail convention PlaybookId
// already set: an older client that doesn't read them keeps working. DealType
// null reads as "new" (Lead.DealType's own doc comment).
// EstimatedValue masked without ViewLeadValues — same rule LeadDto.EstimatedValue
// and AccountDto.OpenValue already follow (account-money-masking); a deal row
// on the account page is exactly the figure a masked lead list already hides.
public record AccountLeadLite(
    Guid Id, string Name, string Status, decimal? EstimatedValue, Guid? PlaybookId = null,
    string? DealType = null, Guid? ContactId = null, string? Company = null);
// Account 360 (Part 4) — read-only invoice and AMC rows for the account page,
// alongside the existing receivables rollup. Each carries the id the client
// needs to deep-link to the real record (the invoice detail screen, or
// /amcs?amc_id= — AMCs have no standalone detail route, so that's the closest
// thing to "the real record" the app has today).
public record AccountInvoiceLite(Guid Id, string Number, decimal Amount, decimal Balance, string Status, DateTime DueDate);
public record AccountAmcLite(Guid Id, string? Title, decimal ContractValue, DateTime RenewalDate, string Status);
// Tags: DERIVED, not stored — the plain union (no duplicates, no counts) of the
// tags carried by this account's own linked leads. Never denormalized onto
// Account itself, so it can never drift from what the leads actually carry.
// E3.4 — additive tail: an older client that doesn't read these keeps
// working. ParentAccountName is null exactly when ParentAccountId is null.
// Children is the DIRECT children only (lite); GET /accounts/{id}/tree has
// the full bounded-depth recursion. Relationships carries both directions
// (see AccountRelationshipDto.Direction). Rollup is over this account plus
// every viewable descendant — see AccountRollupDto's own doc for the masking
// and period decisions.
public record AccountDetailDto(
    AccountDto Account, List<ContactDto> Contacts, List<AccountLeadLite> Leads,
    List<AccountInvoiceLite> Invoices, List<AccountAmcLite> Amcs, List<TagRefDto> Tags,
    Guid? ParentAccountId = null, string? ParentAccountName = null,
    List<AccountChildSummaryDto>? Children = null,
    List<AccountRelationshipDto>? Relationships = null,
    List<AccountExternalIdDto>? ExternalIds = null,
    AccountRollupDto? Rollup = null);


// Disabled = the module read for this org (GET /accounts/{id}/loyalty), unset when
// loyalty_enabled is false — same "toggling it off returns disabled with zero
// behavior change elsewhere" contract every other policy toggle in this codebase
// gives (PlaybookPolicyService's own proof bar, see SettingsController).

// --- the rest of the accounts vertical (API-led migration, 2026-08-28) ---

// GET /accounts/facets — how many accounts each filter option would match.
// Kept distinct from LeadsController's own private FacetCount (same shape,
// different domain, not worth sharing a type across two unmigrated/migrated
// controllers for a two-field record).
public record FacetCount(string Key, int Count);
public record AccountFacetsDto(List<FacetCount> Owner, List<FacetCount> Industry);

// POST /accounts/match-bulk — the CSV import review step's answer to "of these
// N company names, which already exist?".
public record MatchedAccountDto(string Company, Guid AccountId, string AccountName);
public record MatchBulkResultDto(List<MatchedAccountDto> Matched, List<string> Unmatched);

// S9c — the one-off "link my existing unlinked leads to accounts" admin
// tool. GET /accounts/link-unlinked-leads/preview answers "if I ran this,
// what would happen", writing nothing; POST /accounts/link-unlinked-leads
// applies the SAME matching (same `AccountLinkService.CompanyKey`) and
// nothing else — never creates or merges an account, never runs on its own.
public record UnlinkedLeadMatchDto(Guid AccountId, string AccountName, int LeadCount);
public record LinkUnlinkedLeadsPreviewDto(
    int TotalUnlinkedLeads, List<UnlinkedLeadMatchDto> Matches, int UnmatchedLeadCount);
public record LinkUnlinkedLeadsResultDto(int LeadsLinked, int AccountsAffected, int InvoicesBackfilled);

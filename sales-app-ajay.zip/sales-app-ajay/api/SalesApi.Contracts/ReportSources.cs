namespace SalesApi.Dtos;

// E18.2 - the report source registry (to-do/epics-djg-foundations.md E18, to-do/report-builder-design.md slice 4).
// The existing builder reports over leads; these contracts add the other sources (accounts, contacts, invoices, payments,
// AMC renewal terms) WITHOUT a second builder: the same request (CustomReportRequestDto) names the source, and the
// answer's shape differs only where the source is not a lead (a lead breakdown keeps its five metric groups unchanged).

/// <summary>
/// What the caller may do with money and contact data, read once by the controller from the permission claims and passed DOWN
/// as data (a Process class never reads a principal). Null on a run means "none of these" (fail closed); a saved report's
/// definition check uses <see cref="Everything"/> because who SAVES a report is not who runs it, and a run re-checks them for the viewer.
/// <c>ViewFinancials</c> (financials.view) opens the invoice, payment and AMC sources, exactly as it opens /invoices and /amcs;
/// <c>ViewAccountFinancials</c> (account_financials.view) opens their money columns, as invoice money masking does;
/// <c>ViewContactDetails</c> (contact_details.view) opens a contact's email and phone.
/// </summary>
public record ReportViewer(bool ViewFinancials, bool ViewAccountFinancials, bool ViewContactDetails)
{
    public static ReportViewer Everything { get; } = new(true, true, true);
}

/// <summary>One field of a source. <c>Groupable</c> fields can be a breakdown's group-by; <c>Summable</c> fields can be its
/// chosen sum. <c>Type</c> is the table catalogue's wire type (text | number | money | date | pick | multi_pick | person | boolean).</summary>
public record ReportSourceFieldDto(
    string Key, string Label, string Type, bool Filterable, bool Sortable, bool Groupable, bool Summable,
    List<TableColumnOptionDto>? Options,
    // Leads only: the group-by kind ("builtin" | "custom_field" | "account_custom_field") a client echoes back with Key. Null for every other source,
    // whose group-by is just the field key.
    string? Kind = null);

/// <summary><c>Metrics</c> is "lead_metrics" (leads, open, won, lost, win rate: unchanged) or "count_sum" (a count plus the sum
/// of a chosen number or money field).</summary>
public record ReportSourceDto(string Key, string Label, string Metrics, List<ReportSourceFieldDto> Fields);

public record ReportSourcesDto(List<ReportSourceDto> Sources);

/// <summary>One bucket of a non-lead breakdown, and (reused) its totals row. <c>Sum</c> is the sum of the chosen field, null when
/// no field was chosen.</summary>
public record CustomReportSourceRow(string Key, string Label, int Count, decimal? Sum);

/// <summary>A non-lead breakdown. <c>GroupByLabel</c>, <c>Rows</c>, <c>Totals</c>, <c>ValuesVisible</c> and <c>MultiValue</c> keep the
/// lead result's names so a client can read both with one code path; <c>MultiValue</c> is always false here (no multi-select
/// group-by on these sources). <c>Totals</c> is computed over the source's rows, once each (never the sum of <c>Rows</c>).</summary>
public record CustomReportSourceResultDto(
    string GroupByLabel, List<CustomReportSourceRow> Rows, CustomReportSourceRow Totals,
    bool ValuesVisible, bool MultiValue, string? SumField, string? SumLabel);

/// <summary>One row of a non-lead table: the record's id and its values keyed by column key.</summary>
public record CustomReportSourceRowDto(Guid Id, Dictionary<string, object?> Values);

/// <summary>A non-lead table: same envelope as <see cref="CustomReportTableResultDto"/> (columns reuse its column shape), rows keyed by <c>id</c>.</summary>
public record CustomReportSourceTableDto(
    List<CustomReportTableColumnDto> Columns, List<CustomReportSourceRowDto> Rows,
    string? NextCursor, int TotalCount, bool ValuesVisible, List<string> DroppedColumns);

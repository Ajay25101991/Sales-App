// The E4.2 execution-log admin contracts (design doc
// to-do/e4-ai-platform-design.md §3, §15 slice 4). Own file, same reason as
// AiSettings.cs/AiActionPolicy.cs's own headers: the Experience layer cannot
// see the System layer, so any contract it returns lives here.

namespace SalesApi.Dtos;

// --- Execution log: list row ---
// Outcome/Provider/ModelId/etc. are already plain strings on the wire, same
// shape the entity stores — no separate wire vocabulary to keep in sync.
/// <param name="UserFeedback">One of <c>Models.AiFeedbackVerdicts.All</c>
/// ("accepted" | "edited" | "rejected"), null until the calling user submits
/// feedback (E5.1 build item 3, <c>POST /ai/feedback</c>).</param>
/// <param name="UserFeedbackReasonChip">The org-configured quick chip picked
/// when rejecting, null otherwise.</param>
/// <param name="UserFeedbackReasonText">Free-text reject reason, null otherwise.</param>
public record AiExecutionLogEntryDto(
    Guid Id, Guid UserId, string Feature, string Skill, int SkillVersion,
    string Provider, string ModelId, string Outcome, string? ErrorMessage,
    int LatencyMs, int InputTokens, int OutputTokens, decimal? EstimatedCostUsd,
    string? ApprovalOutcome, string? UserFeedback, DateTime OccurredAt,
    string? UserFeedbackReasonChip = null, string? UserFeedbackReasonText = null);

// --- Execution log: one citation / one proposed tool, exactly as stored —
// never the cited value, never the tool's arg values (design §3.2).
public record AiContextSourceDto(string Kind, Guid? Id, string? Field);
public record AiToolProposedDto(string Name, IReadOnlyList<string> ArgFields);

/// <param name="CapturedPromptText">Set only when the org's opt-in capture
/// window was open for this call AND has not expired (owner §17.4). Null
/// otherwise — including "capture was on but this row predates it" and
/// "capture window has since expired and the row was purged".</param>
public record AiExecutionLogDetailDto(
    AiExecutionLogEntryDto Entry,
    IReadOnlyList<AiContextSourceDto> ContextSources,
    IReadOnlyList<AiToolProposedDto> ToolsProposed,
    string? CapturedPromptText,
    string? CapturedCompletionText);

// --- Prompt/completion-text capture toggle (owner §17.4) ---
public record AiTextCaptureStatusDto(bool Active, DateTime? CaptureUntil);

/// <param name="Days">1-30. Switches capture ON, ending N days from now.
/// Ignored when <paramref name="Off"/> is true.</param>
/// <param name="Off">Switches capture OFF immediately (CaptureUntil cleared).</param>
public record AiTextCaptureInput(int? Days, bool? Off);

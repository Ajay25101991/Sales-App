namespace SalesApi.Dtos;

// --- E7.4 implementation studio: access, assignments, org switching ---
// (design doc to-do/e7-config-platform-design.md §5.1, §8 slice 13)

/// <summary>POST /admin/studio/assignments body — suntech-admin grants an
/// implementation user access to one customer org.</summary>
public record StudioGrantInput(Guid? ImplementationUserId, Guid? OrgId);

/// <summary>One grant, as the platform admin or the implementation user sees
/// it. <see cref="IsActive"/> is the server's own answer (not revoked, not
/// expired) so neither client has to reimplement that rule.</summary>
public record StudioAssignmentDto(
    Guid Id, Guid ImplementationUserId, Guid OrgId, string? OrgName,
    DateTime GrantedAt, Guid GrantedById, DateTime? RevokedAt, DateTime? ExpiresAt, bool IsActive);

/// <summary>GET /studio/orgs row — the implementation user's own assignment
/// list, for the org picker (§5.2's "org picker across assignments").</summary>
public record StudioAssignedOrgDto(Guid OrgId, string OrgName, DateTime GrantedAt, DateTime? ExpiresAt);

// --- Follow-up (owner 2026-10-04): the platform admin's own grants screen ---
// (list every grant ever made, and manage who may even BE granted one).
// GrantAsync/RevokeAsync above already exist; these three are new.

/// <summary>GET /admin/studio/assignments row — same facts as
/// <see cref="StudioAssignmentDto"/> plus the implementation user's own
/// name/email, which the platform admin's grants list needs to show WHO
/// without a second round trip. A distinct record rather than widening
/// <see cref="StudioAssignmentDto"/> itself: that one is also the exact
/// shape <c>POST /admin/studio/assignments</c> (Grant) returns today, and
/// widening it would mean every existing caller starts receiving two fields
/// it never asked for.</summary>
public record StudioAssignmentDetailDto(
    Guid Id, Guid ImplementationUserId, string? ImplementationUserName, string? ImplementationUserEmail,
    Guid OrgId, string? OrgName, DateTime GrantedAt, Guid GrantedById, DateTime? RevokedAt, DateTime? ExpiresAt, bool IsActive);

/// <summary>GET /admin/studio/assignments — EVERY grant ever made, newest
/// first, revoked AND expired included (their own <see cref="StudioAssignmentDetailDto.IsActive"/>
/// says which) — the platform admin's own audit view, distinct from
/// <see cref="StudioAssignedOrgDto"/>'s implementation-user-facing "only
/// what still reaches me" picker.</summary>
public record StudioAssignmentsDto(List<StudioAssignmentDetailDto> Assignments);

/// <summary>GET /admin/studio/implementation-users row — one profile in the
/// caller's own home org, with its current <see cref="IsImplementationUser"/>
/// flag so the screen can render the toggle already in the right state.</summary>
public record StudioImplementationUserDto(Guid Id, string? FullName, string Email, bool IsImplementationUser);

public record StudioImplementationUsersDto(List<StudioImplementationUserDto> Users);

/// <summary>PUT /admin/studio/implementation-users/{profileId} body.</summary>
public record StudioImplementationUserToggleInput(bool IsImplementationUser);

/// <summary>The result of POST /studio/switch/{orgId} and POST
/// /studio/switch/home and POST /admin/sandbox/switch and POST
/// /admin/sandbox/switch/home and POST /studio/preview/{roleKey} and POST
/// /studio/preview/exit — a fresh, scoped token plus the profile as it
/// reads while acting in that org (see ProfileDto.ActingOrgId/HomeOrgId) or
/// previewing as that role (see ProfileDto.PreviewRole).
/// <see cref="ExpiresAt"/> is handed back explicitly so the client can warn
/// before the short studio session lapses, rather than discovering it only
/// on the next 401.</summary>
public record StudioSwitchResultDto(string Token, ProfileDto Profile, DateTime ExpiresAt);

// --- E7.4 slice 19: preview as role (design doc §5.6) ---

public static class StudioPreviewAccess
{
    public const string Yes = "yes";
    public const string No = "no";
}

/// <summary>GET /studio/preview/{roleKey}/capabilities row — a plain-language
/// capability ("see other reps' deal values") mapped from one permission the
/// previewed role does or does not hold (§5.6: "derive from the role's
/// permissions... say how each maps"). <see cref="Access"/> is
/// <see cref="StudioPreviewAccess"/>.</summary>
public record StudioPreviewCapabilityDto(string Label, string Permission, string Access);

/// <summary>GET /admin/sandbox — §11 build-notes gap: "no GET /admin/sandbox
/// status endpoint, so the screen can't show created/last-refreshed dates
/// after a reload." Exists=false and the two dates null means this org has
/// no sandbox at all (never 404 — "does my org have a sandbox" is itself the
/// question this answers).</summary>
public record SandboxStatusDto(bool Exists, Guid? SandboxOrgId, DateTime? CreatedAt, DateTime? LastRefreshedAt);

public record StudioRefusalDto(string Reason, bool NotFound = false);

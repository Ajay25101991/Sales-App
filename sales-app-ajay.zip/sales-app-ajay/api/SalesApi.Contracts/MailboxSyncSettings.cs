// E6.1/E6.2 mailbox-sync org settings contracts (design doc
// to-do/e6-capture-design.md §11.2/§11.3) — same shape as DealRiskSettings's
// own Dto/Input pair.

namespace SalesApi.Dtos;

public record MailboxSyncSettingsDto(int BackfillDays, int PollMinutes, string[] CompanyDomains, bool MailEnabled = false, bool CalendarEnabled = false);

/// <summary>Partial-update input — nulls mean "leave as-is", same merge
/// convention <c>DealRiskSettingsStore.SaveAsync</c> already uses.
/// <see cref="CompanyDomains"/> null also means "leave as-is"; an empty list
/// is a real, valid value ("no admin-listed domains", the compiled default).</summary>
public record MailboxSyncSettingsInput(int? BackfillDays, int? PollMinutes, List<string>? CompanyDomains = null, bool? MailEnabled = null, bool? CalendarEnabled = null);

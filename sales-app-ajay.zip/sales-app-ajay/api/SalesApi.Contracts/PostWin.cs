namespace SalesApi.Dtos;

// E13 "After the win" (to-do/e13-after-the-win-design.md). Per-workflow overrides of the org's post-win
// settings, stored on a playbook version next to its stage snapshot. Every field null = use the org setting.
// The partial-override shapes are the org screens' own *Input records, so a workflow overrides exactly the
// fields the org screen edits and nothing new is invented.

/// <summary>A workflow's post-win overrides. Null anywhere = the org setting applies.</summary>
public record PlaybookPostWinDto(
    PaymentWorkflowConfigInput? Payment = null,
    CollectionReminderConfigInput? CollectionReminders = null,
    AmcReminderConfigInput? RecurringReminders = null,
    RecurringContractSettingsDto? Recurring = null,
    /// <summary>off | before_invoice | before_won. Null = off.</summary>
    string? EngagementLetterRequirement = null,
    /// <summary>all_sent | any: with several agreements, met when every sent one is signed / one is. Null = the org setting (default all_sent).</summary>
    string? EngagementLetterSignedRule = null);

/// <summary>
/// The recurring contract opened after a win, reusing the AMC model.
/// Mode: off | offer | auto. Label: what this workflow calls it ("Subscription", "AMC"); null = "AMC".
/// TermMonths: the default contract length for "auto" and the pre-fill for "offer"; null = 12.
/// </summary>
public record RecurringContractSettingsDto(string Mode, string? Label = null, int? TermMonths = null);

/// <summary>
/// LEGACY (workflow stage editor rework, owner 2026-11-10): handover items were merged into the stage-task list (<see cref="StageTaskDto"/>).
/// This shape survives only so HandoverToStageTasksBackfill and old packages can still read a stored item and convert it.
/// One handover item on a workflow stage (owner decision: the checklist IS tasks). Entering the stage created
/// one task per item on the deal. AssigneeKind: owner | role | person; AssigneeRef: the role key or profile id
/// (null for owner). DueDays: due this many days after entry (0 = same day).
/// </summary>
public record HandoverItemDto(string Key, string Label, string AssigneeKind, string? AssigneeRef = null, int DueDays = 0);

/// <summary>
/// One task a workflow stage creates when a deal ENTERS or LEAVES it (stage_snapshot tasksOnEnter / tasksOnLeave). Id is a stable
/// definition id, unique within the stage across both lists (it is what re-entry dedupe hangs on). Title takes merge fields
/// (<c>{{lead.name}}</c>, <c>{{lead.company}}</c>, <c>{{lead.stage}}</c>, <c>{{stage.from}}</c>, <c>{{stage.to}}</c>) like the automation
/// create_task. Priority: low | normal | high. Assignee: "owner" (the deal owner) | "rep_picks" (the mover picks a team member in the move
/// dialog; a move with no dialog gives it to the owner) | "role" (ONE claimable task for the role, the role queue; AssigneeRef = the role key) | "person"
/// (a fixed person; AssigneeRef = their user id). AssigneeRef is null for owner / rep_picks. DueInWorkingDays: due this many working days (the org calendar) after the move.
/// </summary>
public record StageTaskDto(
    string Id, string Title, string? Notes = null, int DueInWorkingDays = 0,
    string Priority = StageTaskPriorities.Normal, string Assignee = StageTaskAssignees.Owner, string? AssigneeRef = null);

public static class StageTaskAssignees
{
    public const string Owner = "owner";
    public const string RepPicks = "rep_picks";
    public const string Role = "role";
    public const string Person = "person";
    public static readonly string[] All = [Owner, RepPicks, Role, Person];
}

public static class StageTaskPriorities
{
    public const string Low = "low";
    public const string Normal = "normal";
    public const string High = "high";
    public static readonly string[] All = [Low, Normal, High];
}

public static class StageTaskTriggers
{
    public const string Enter = "enter";
    public const string Leave = "leave";
}

/// <summary>Where a task came from: the workflow (playbook), the stage key, the definition id and enter/leave. Stored on the task row.</summary>
public record TaskOrigin(Guid PlaybookId, string Stage, string Key, string Trigger);

/// <summary>One task that needs a pick in the move dialog.</summary>
public record StageTaskPickDto(string Id, string Title, string Trigger, string StageKey, string StageLabel);

public record StageTaskPickMemberDto(Guid Id, string Name);
public record StageTaskPickTeamDto(Guid Id, string Name, List<StageTaskPickMemberDto> Members);

/// <summary>
/// GET /leads/{id}/stage-tasks?to=stage_key: the tasks of this move (the current stage's leave tasks, the target's enter tasks) whose assignee is
/// "rep_picks", and the MOVER's teams with their members. Both empty when nothing needs a pick. Send the answer as
/// stage_task_assignees { definition id: user id } on the move; a member must belong to a team the mover belongs to.
/// </summary>
public record StageTaskPicksDto(List<StageTaskPickDto> Tasks, List<StageTaskPickTeamDto> Teams);

/// <summary>The proposal that was accepted on a deal (the "Proposal accepted" badge). Version is the revision number.</summary>
public record AcceptedProposalDto(
    Guid ProposalId, string? Number, int Version, DateTime AcceptedAt, string? AcceptedBy, string? AcceptedVia);

// ---- Ask for deal values and the payment term on a win (owner 2026-10-27, parked item 7) -----------------------------------------

/// <summary>One value the Won stage asks for. Key: "won_value" (the deal's closed value) or "custom.&lt;key&gt;" of an ACTIVE lead custom field of type number/currency.</summary>
public record AskOnWinFieldDto(string Key, bool Required = false);

/// <summary>Whether the Won stage asks for the deal's payment term (a pick from the workflow's payment terms), and whether it must be given.</summary>
public record AskOnWinTermDto(bool Ask = false, bool Required = false);

/// <summary>
/// Stage option on the WON stage of a workflow (stage_snapshot "askOnWin"): which values the win step asks for when the deal has NO accepted proposal
/// generated in the CRM. Null / nothing ticked = no ask. A required value that is missing refuses the move like a gate (stage_requirements).
/// </summary>
public record AskOnWinDto(List<AskOnWinFieldDto>? Fields = null, AskOnWinTermDto? PaymentTerm = null);

/// <summary>
/// The values a move to the Won stage carries (PATCH /leads/{id} win_values). Written in the same save as the stage change:
/// WonValue -> the deal's closed value, Custom -> an overlay into the deal's custom fields (keys WITHOUT the "custom." prefix),
/// PaymentTermKey -> the deal's payment term. Ignored when the ask does not apply to the move.
/// </summary>
public record WinValuesInput(decimal? WonValue = null, Dictionary<string, decimal>? Custom = null, string? PaymentTermKey = null);

/// <summary>One value the win dialog asks. Key as in <see cref="AskOnWinFieldDto"/>; Type "currency" | "number"; CurrentValue prefills (null when none or masked).</summary>
public record WinAskFieldDto(string Key, string Label, string Type, bool Required, decimal? CurrentValue, bool CanEnter = true);

/// <summary>The payment-term question: Terms is the workflow's payment terms list (key + label, as the after-the-win card reads them).</summary>
public record WinAskTermDto(bool Required, string? CurrentKey, List<AfterWinTermDto> Terms);

/// <summary>
/// GET /leads/{id}/win-ask?to=stage_key: what the stage-move dialog asks when the target is the Won stage. Applies is false (Fields empty, PaymentTerm null)
/// when the target is not a Won stage with an ask configured, or the deal already has an accepted proposal generated in the CRM.
/// Send the answers as win_values on the move.
/// </summary>
public record WinAskDto(bool Applies, List<WinAskFieldDto> Fields, WinAskTermDto? PaymentTerm);

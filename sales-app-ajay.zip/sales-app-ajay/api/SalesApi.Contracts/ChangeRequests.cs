namespace SalesApi.Dtos;

// --- E7.4 change requests + customer approval (design doc
// to-do/e7-config-platform-design.md §5.4/§5.5, story brief slices 16-17) ---
// A ChangeRequest wraps an explicit selection of sandbox diff items — the
// SAME shape SandboxPromoteRequestDto already takes (Sandbox.cs) — behind a
// customer-approval gate. Deliberately reuses those item/removal shapes
// rather than inventing parallel ones; only the names differ, to keep this
// file self-contained for the client that consumes it.

public static class ChangeRequestStatuses
{
    public const string Requested = "requested";
    public const string BuiltInSandbox = "built_in_sandbox";
    public const string CustomerApproved = "customer_approved";
    public const string Promoted = "promoted";
    public const string Rejected = "rejected";
}

/// <summary>One linked item. <see cref="Resolution"/> mirrors
/// <c>SandboxPromoteItemSelectionDto.Resolution</c> — required when the
/// sandbox diff classified this item Changed/Conflict, ignored otherwise.</summary>
public record ChangeRequestItemSelectionDto(string Kind, string StableKey, string? Resolution);

/// <summary><see cref="Acknowledged"/> must be true or linking/promoting is
/// refused — same rule as <c>SandboxPromoteRemovalSelectionDto</c>.</summary>
public record ChangeRequestRemovalSelectionDto(string Kind, string StableKey, bool Acknowledged);

public record ChangeRequestCreateDto(string Title, string Description);

/// <summary>Body of the Requested → BuiltInSandbox transition (and any
/// re-link while still BuiltInSandbox): the implementation user's selection
/// of which sandbox diff items this request covers.</summary>
public record ChangeRequestLinkItemsDto(
    List<ChangeRequestItemSelectionDto> Items,
    List<ChangeRequestRemovalSelectionDto> Removals);

public record ChangeRequestCommentDto(Guid Id, Guid AuthorId, string Body, DateTime CreatedAt);
public record ChangeRequestCommentCreateDto(string Body);

/// <summary>Body of the authenticated BuiltInSandbox → CustomerApproved/
/// Rejected transition. <see cref="Approve"/> true approves, false rejects.</summary>
public record ChangeRequestDecideDto(bool Approve);

public record ChangeRequestDto(
    Guid Id,
    string Title,
    string Description,
    string Status,
    Guid RequestedById,
    DateTime CreatedAt,
    List<ChangeRequestItemSelectionDto> LinkedItems,
    List<ChangeRequestRemovalSelectionDto> LinkedRemovals,
    Guid? PackageApplyRecordId,
    DateTime? BuiltInSandboxAt,
    DateTime? CustomerApprovedAt,
    Guid? CustomerApprovedById,
    DateTime? RejectedAt,
    Guid? RejectedById,
    DateTime? PromotedAt,
    Guid? PromotedById,
    /// <summary>True while an unconsumed, unexpired approval link exists —
    /// never the token or its hash, which stay server-side only.</summary>
    bool HasOpenApprovalLink);

public record ChangeRequestDetailDto(ChangeRequestDto ChangeRequest, List<ChangeRequestCommentDto> Comments);

/// <summary>Why a change-request action was refused. <see cref="Conflict"/>
/// marks the "two requests touching the same item" case (§5.4/§10 owner
/// answer 4) — <see cref="ConflictingStableKeys"/> names exactly which
/// linked items overlap and <see cref="ConflictingChangeRequestId"/>/
/// <see cref="ConflictingChangeRequestTitle"/> name the other request, so the
/// caller can resolve it (drop the overlapping item, or wait) rather than
/// being told only "conflict".</summary>
public record ChangeRequestRefusalDto(
    string Reason,
    bool NotFound = false,
    bool Conflict = false,
    List<string>? ConflictingStableKeys = null,
    Guid? ConflictingChangeRequestId = null,
    string? ConflictingChangeRequestTitle = null,
    List<string>? UnacknowledgedStableKeys = null);

/// <summary>The public, unauthenticated view of a change request — no
/// PackageApplyRecordId, no internal ids beyond what the customer needs to
/// read what changed. Mirrors <c>CustomerQuoteDto</c>'s "the page renders a
/// CONTRACT" discipline: this shape, not the entity, is what the anonymous
/// approval page (and any future client) ever sees.</summary>
public record PublicChangeRequestDto(
    string Title,
    string Description,
    string Status,
    List<ChangeRequestItemSelectionDto> LinkedItems,
    List<ChangeRequestRemovalSelectionDto> LinkedRemovals);

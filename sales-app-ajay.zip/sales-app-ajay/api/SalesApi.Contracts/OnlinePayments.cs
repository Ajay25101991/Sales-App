namespace SalesApi.Dtos;

// E17.5 online payment: a customer pays an open invoice by card on a gateway's hosted page, from a "Pay now" link. JSON is snake_case.
// Staff side: POST /invoices/{id}/pay-link, GET /online-payments, GET /online-payments/setup. Customer side: /public/pay/{token}.
// Gateway side: POST /webhooks/payments/stripe/{connection_id} (signed; the response is only { received: true } or { error }).

/// <summary>POST /invoices/{id}/pay-link: the customer's page address and when it stops working.</summary>
public record PayLinkDto(string Url, DateTime ExpiresAt);

/// <summary>
/// GET /public/pay/{token}: everything the customer's page may show and nothing else - no owner, deal, notes, line items, payment history or account
/// details. <c>Status</c> is <c>open</c> (may pay), <c>paid</c> (nothing owed), <c>expired</c> (the link ran out; ask for a new one) or <c>unavailable</c>
/// (the invoice is void, written off or not yet raised). <c>AmountDue</c> is the current balance, and 0 unless the status is <c>open</c>.
/// </summary>
public record PayPublicViewDto(
    string Company, string InvoiceNumber, DateTime IssuedAt, DateTime DueDate, string Currency, decimal AmountDue, string Status);

/// <summary>POST /public/pay/{token}/checkout: where to send the customer (the gateway's hosted page).</summary>
public record PayCheckoutDto(string RedirectUrl);

/// <summary>
/// GET /online-payments (finance): one gateway checkout, for matching against the gateway's payout report. <c>Status</c> is created, processing, paid,
/// needs_review (the gateway took the money but the invoice could not take the payment; <c>Note</c> says why), failed or expired.
/// <c>GatewaySessionId</c> and <c>GatewayPaymentId</c> are the gateway's own ids (Stripe cs_... and pi_...). <c>PaymentId</c> is the ordinary payment row
/// the callback recorded; <c>Amount</c> is what the gateway took (null until it has), <c>AmountRequested</c> what the checkout asked for.
/// </summary>
public record OnlinePaymentDto(
    Guid Id, Guid InvoiceId, string? InvoiceNumber, string Provider, string Status, string Currency, decimal AmountRequested, decimal? Amount,
    string? GatewaySessionId, string? GatewayPaymentId, Guid? PaymentId, string? Note, DateTime CreatedAt, DateTime? PaidAt);

/// <summary>GET /online-payments/setup: whether this organization takes card payments, and the address to register at the gateway. <c>WebhookUrl</c> is
/// null until the gateway is connected (or when the server has no public address).</summary>
public record OnlinePaymentSetupDto(bool Connected, string Provider, string? WebhookUrl, string? PublishableKey, int PayLinkDays);

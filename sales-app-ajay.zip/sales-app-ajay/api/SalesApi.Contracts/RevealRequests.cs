// E12.5 - reveal requests (owner decision 10). Own file: the Experience layer cannot see the System layer, so what it returns lives here.
// Wire: to-do/sensitive-data-api.md section 8.

namespace SalesApi.Dtos;

/// <summary>Wire statuses of a reveal request. <c>refused</c> is stored as the approval table's <c>rejected</c>; <c>expired</c> is never
/// stored - it is an approved request whose time limit has passed, computed on read.</summary>
public static class RevealStatuses
{
    public const string Pending = "pending";
    public const string Approved = "approved";
    public const string Refused = "refused";
    public const string Expired = "expired";
}

/// <summary>The org's reveal time limit and its bounds. Business policy is an org setting, not a hardcoded rule.</summary>
public static class RevealDefaults
{
    public const int Minutes = 15;
    public const int MinMinutes = 1;
    public const int MaxMinutes = 1440;
}

/// <summary>POST /reveal-requests body. <c>Category</c> is one of the six sensitive categories (SensitiveCategories); the reason is required.</summary>
public record RevealRequestInput(string? RecordType, Guid? RecordId, string? Category, string? Reason);

/// <summary>
/// One reveal request. Never carries the revealed value. <c>CanDecide</c> is true only for the caller who is the CURRENT step's
/// approver of a still-pending request (the same resolution the approval chains use); <c>IsMine</c> marks the caller's own.
/// </summary>
public record RevealRequestDto(
    Guid Id, Guid RequesterId, string? RequesterName, string RecordType, Guid RecordId, string? RecordName, string Category,
    string Reason, string Status, DateTime CreatedAt, Guid? DecidedById, string? DecidedByName, DateTime? DecidedAt,
    string? DecisionNote,
    // Approved only: the instant the grant stops applying (decision time + the org's reveal_minutes). Null otherwise.
    DateTime? ExpiresAt,
    int? CurrentStep, int? TotalSteps, List<Guid> WaitingOnIds, List<string> WaitingOnNames, bool CanDecide, bool IsMine,
    // The approval chain instance that governs this request: decide it with the EXISTING POST /approval-chains/instances/{id}/decide.
    Guid? ChainInstanceId = null);

/// <summary>GET /reveal-requests: the caller's own requests, and the pending ones they are the current approver of.</summary>
public record RevealRequestListDto(List<RevealRequestDto> Mine, List<RevealRequestDto> ToDecide);

/// <summary>GET/PUT /settings/sensitive-data. PUT accepts any subset of the three keys; an omitted key is left as stored.</summary>
public record SensitiveDataSettingsDto(string AssignedScope, bool RevealEnabled, int RevealMinutes);

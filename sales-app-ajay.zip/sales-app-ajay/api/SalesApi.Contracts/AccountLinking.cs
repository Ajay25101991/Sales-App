// --- Account linking: the shapes of the question and the answer ---
//
// WHY THEY LIVE HERE. Five plain values — a candidate, the prompt a client
// renders, the effect chosen, the outcome, and the request — with no EF and no
// HTTP anywhere in them. They sat in `SystemApi/Services/AccountLinkService.cs`
// beside the code that produces them.
//
// They were on the very first Contracts sweep's candidate list (2026-08-28) and
// were deliberately LEFT THERE, with the note that they should move if one ever
// crossed a public surface. `LeadWriteProcess.Refusal` carries the prompt — the
// account-link interlock refuses a write and hands the client everything it
// needs to ask a real question — so one now does. `LayerBoundaryTests` caught it
// on the first run, which is the sweep's own prediction arriving on schedule.
//
// Their own file rather than appended to Accounts.cs: that file is
// `namespace SalesApi.Dtos`, and these keep `SalesApi.Services` so the move
// costs no caller a `using`.

using SalesApi.Dtos;

namespace SalesApi.Services;

public record AccountLinkCandidate(Guid Id, string Name);

/// <summary>What the caller must be asked before the write can proceed.</summary>
public record AccountLinkPromptDto(
    string Kind,
    string Question,
    string? Company,
    AccountLinkCandidate? CurrentAccount,
    List<AccountLinkCandidate> Candidates,
    List<string> Choices);

public enum AccountLinkEffect
{
    /// <summary>The link on the lead is already right (or there is nothing to link).</summary>
    None,
    LinkExisting,
    CreateAndLink,
    Unlink,
    /// <summary>Refuse the write; <see cref="AccountLinkOutcome.Prompt"/> says what to ask.</summary>
    ConfirmationRequired,
}

public record AccountLinkOutcome(
    AccountLinkEffect Effect,
    Guid? AccountId = null,
    string? CreateAccountNamed = null,
    AccountLinkPromptDto? Prompt = null);

/// <summary>
/// The lead-side facts a link decision is made from. Nothing here touches the database.
///
/// SubmittedCompany null means "this payload does not mention company" — which is not
/// the same as an empty string ("clear the company"), and must not collapse into one.
/// </summary>
public record AccountLinkRequest(
    string? SubmittedCompany,
    Guid? SubmittedAccountId,
    string? CurrentCompany,
    Guid? CurrentAccountId,
    string? CurrentAccountName,
    List<AccountLinkCandidate> Candidates,
    AccountLinkDecisionInput? Decision);

/// <summary>
/// Decides what an edit to a lead's company should do to its account link.
///
/// Two failures are possible here and they pull in opposite directions: creating a
/// SECOND account for a company that already has one, and merging a lead into an
/// account that belongs to a DIFFERENT company. Matching loosely avoids the first and
/// causes the second; matching strictly does the reverse. There is no threshold that
/// avoids both — see <see cref="CompanyKey"/>, where "Acme Ltd" and "Acme Holdings"
/// normalise to the same key.
///
/// So the ambiguous cases are not decided here at all: they are refused, described,
/// and handed back to the person editing. Only the two unambiguous ones — an exact
/// name match, and no match of any kind — are applied silently.
///
/// All of it is scoped to an edit that actually MOVES the company (or names a
/// different account outright). An unchanged company is not an edit to the company,
/// and must not raise an account question — nor quietly resolve one — while someone
/// is fixing a phone number. The cost is that a lead left unlinked with a stale
/// company stays unlinked until its company is edited; linking those is a backfill's
/// job, not this request's.
///
/// Pure and database-free on purpose: the caller loads the candidates, this decides,
/// and the decision is testable on its own (SalesApi.Tests/AccountLinkTests.cs).
/// </summary>

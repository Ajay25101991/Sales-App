namespace SalesApi.Dtos;

// E20.2 - rewards per loyalty tier. Three things, none of which can live in the points ledger (which refuses deductions by design):
//   the CATALOGUE (what a benefit is), the ENTITLEMENTS (which tier gets how much of it, per period, or unlimited),
//   and the USAGE ledger (one dated row per use; a correction supersedes, nothing is edited or deleted).
// "Remaining this period" is derived per account from those three plus the account's current tier.

public record LoyaltyBenefitDto(Guid Id, string Name, string? Description, bool Active);

// Create and update share one input. On update an omitted field keeps its value; on create `Name` is required and `Active` defaults to true.
public record LoyaltyBenefitInput(string? Name, string? Description, bool? Active);

// One tier's entitlement to one benefit. `Unlimited` true = no cap (Allowance and Period are then null). Otherwise Allowance is the
// quantity per Period ("month" | "quarter" | "year", calendar units in the org's reporting calendar). An allowance of 0 is legal and means
// "listed, but none included".
public record LoyaltyEntitlementDto(Guid BenefitId, string BenefitName, string TierKey, bool Unlimited, int? Allowance, string? Period);
public record LoyaltyEntitlementInput(Guid? BenefitId, bool? Unlimited, int? Allowance, string? Period);

// PUT /loyalty/tiers/{tierKey}/entitlements states the tier's WHOLE set (the same contract the tier list itself uses): a benefit not
// listed is no longer an entitlement of that tier.
public record LoyaltyEntitlementSetInput(List<LoyaltyEntitlementInput>? Entitlements);

// One row of the usage ledger. `SupersededById` is set on a row that a later correction replaced; such a row stays for the audit trail
// and counts toward nothing.
public record LoyaltyBenefitUseDto(
    Guid Id, Guid AccountId, Guid? ContactId, Guid BenefitId, string BenefitName, int Quantity, DateTime UsedAt, string? Note,
    Guid? RecordedById, DateTime CreatedAt, Guid? SupersededById);

public record LoyaltyBenefitUseInput(Guid? BenefitId, Guid? ContactId, int? Quantity, DateTime? UsedAt, string? Note);

// A correction REPLACES a use: the old row is marked superseded and a new row carries the corrected values. An omitted field keeps the old
// row's value. Quantity 0 voids the use (the usual way to cancel one).
public record LoyaltyBenefitUseCorrectionInput(int? Quantity, DateTime? UsedAt, string? Note, Guid? ContactId);

// One benefit's standing for one account in the current period. `PeriodStart` / `PeriodEnd` bound the period (end exclusive); both are null
// for an unlimited benefit, whose `Used` is the quantity used so far in the current calendar year. `Remaining` is null when unlimited, else never
// below zero (`Used` can exceed `Allowance`, e.g. after a tier drop or an over-allowance use).
public record LoyaltyBenefitRemainingDto(
    Guid BenefitId, string BenefitName, bool Unlimited, int? Allowance, string? Period,
    DateTime? PeriodStart, DateTime? PeriodEnd, int Used, int? Remaining);

// `Enabled` false = the org does not run loyalty. `TierKey` / `TierName` null = the account clears no tier, so it has no entitlements.
public record AccountLoyaltyBenefitsDto(bool Enabled, string? TierKey, string? TierName, List<LoyaltyBenefitRemainingDto> Benefits);

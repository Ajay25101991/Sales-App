// The Calendar contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Org calendar (item 1) ---
public record CalendarSettingsDto(string TimeZoneId, int WeekStartDay, List<int> NonSendingDays);
public record CalendarSettingsInput(string? TimeZoneId, int? WeekStartDay, List<int>? NonSendingDays);

// GET /targets/total — the same rows GET /targets returns for the period,
// summed server-side. The client used to reduce() the /targets rows itself
// for the "Team total" row; that was fine while every row was on screen, but
// it is a second copy of arithmetic the server already has the inputs for.
// Computed directly off the same TargetProgressDto rows as GET /targets (not
// a second query), so the two can never disagree.
public record TargetTotalDto(decimal Target, decimal WonValue, double Attainment);

// --- Calendar shape validation ---
//
// WHY IT MOVED HERE. This was `SettingsController.ValidateCalendarInput`, and
// `TeamsController.SetCalendar` called it across — controller to controller.
// Both call sites carried a comment explaining that it could not move: a Process
// class cannot see a controller, and editing the settings controller was out of
// that batch's scope. Migrating settings expires both halves of that reason.
//
// It is a pure shape check — an IANA id the runtime recognises, a day in 0..6 —
// so it belongs in Contracts, where the two controllers and the Process layer
// beneath them can all reach the SAME copy. The alternative every time this
// shape comes up is two copies and a comment asking humans to keep them in
// sync, which is a drift with a deadline rather than a solution.
//
// An unrecognised timezone or an out-of-range day must be refused identically
// whether it is the org default or a team override; that is the whole point of
// there being one of these.
public static class CalendarValidation
{
    public static string? Validate(string? timeZoneId, int? weekStartDay, List<int>? nonSendingDays)
    {
        if (string.IsNullOrWhiteSpace(timeZoneId)) return "time_zone_id is required.";
        try { TimeZoneInfo.FindSystemTimeZoneById(timeZoneId); }
        catch { return $"'{timeZoneId}' is not a recognised timezone."; }
        if (weekStartDay is null || weekStartDay < 0 || weekStartDay > 6) return "week_start_day must be 0-6 (Sunday-Saturday).";
        if (nonSendingDays is not null && nonSendingDays.Any(d => d < 0 || d > 6)) return "non_sending_days must each be 0-6.";
        return null;
    }
}

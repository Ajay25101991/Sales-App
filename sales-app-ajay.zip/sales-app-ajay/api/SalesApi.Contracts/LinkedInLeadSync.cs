// E6.4 LinkedIn Lead Sync contracts (design doc to-do/e6-connectors-design.md
// §6, §9 slices 9-11). Same "Dtos project, no project references" shape every
// other Contracts file in this API uses.

namespace SalesApi.Dtos;

/// <summary>GET /integrations/linkedin/connect's answer — the LinkedIn
/// authorize URL to redirect the admin's browser to, or a refusal reason
/// (credentials not saved yet, deployment switch off, etc).</summary>
public record LinkedInAuthorizeUrlDto(string AuthorizeUrl);

/// <summary>The result of a completed OAuth callback — what
/// <c>LinkedInLeadSyncController.Callback</c> uses to build its redirect
/// query string (design §6.6's state table, never raw LinkedIn error text in
/// a URL — same "reason a human can read" discipline
/// <c>MailboxConnectController</c>'s own doc comment gives).</summary>
public record LinkedInConnectResultDto(bool Connected, string? ReasonCode);

/// <summary>design §6.6 — the LinkedIn-specific state, additive to
/// <see cref="ConnectorSummaryDto.Status"/>'s existing "not_configured"/
/// "configured" two-state vocabulary (no DTO shape change — the field is
/// already a free string): "awaiting_approval" | "active" | "token_expired" |
/// "error", alongside "not_configured" for no credentials saved at all.</summary>
public static class LinkedInConnectionStatus
{
    /// <summary>No <c>LinkedInConnection</c> row at all — design §6.6's
    /// "absence of this row entirely (not a status value) is what
    /// not_configured means". Only ever synthesized by
    /// <c>LinkedInOAuthProcess.GetConnectionDetailAsync</c> for the connection
    /// detail endpoint; never written to the row itself.</summary>
    public const string NotConfigured = "not_configured";
    public const string AwaitingApproval = "awaiting_approval";
    public const string Active = "active";
    public const string TokenExpired = "token_expired";
    public const string Error = "error";
}

/// <summary>design §11 owner answer 6 — an org-wide setting, not a per-form
/// one: how a LinkedIn-synced lead that matches an existing OPEN deal is
/// handled. "website_rule" defers entirely to the E3.11 rule
/// (DuplicateMatchService) every other unattended path already uses;
/// "new_lead" always creates a second lead even against an open match;
/// "add_note" always appends a note, never creating a second lead, even
/// against what would otherwise be a fresh lead with no match at all — see
/// <c>LinkedInLeadSyncProcess</c> for exactly how each mode branches.</summary>
public static class LinkedInDuplicateMode
{
    public const string WebsiteRule = "website_rule";
    public const string NewLead = "new_lead";
    public const string AddNote = "add_note";
}

public record LinkedInSyncSettingsDto(string DuplicateMode, int PollMinutes);

/// <summary>Partial-update input — null means "leave as-is", same merge
/// convention <c>MailboxSyncSettingsInput</c> already uses.</summary>
public record LinkedInSyncSettingsInput(string? DuplicateMode, int? PollMinutes);

/// <summary>design §6.5 — one row per LinkedIn form the org runs ads
/// through: LinkedIn's own question URN mapped to this app's lead field key
/// (a standard field name, or "custom.&lt;key&gt;" for an org custom
/// field — the SAME vocabulary <c>LeadForm</c>'s own field-key JSON already
/// uses, per the design's "one vocabulary regardless of source").</summary>
public record LinkedInFieldMappingDto(
    Guid Id, string LinkedInFormId, string? FormName, Dictionary<string, string> Mapping, DateTime UpdatedAt);

public record LinkedInFieldMappingInput(string LinkedInFormId, string? FormName, Dictionary<string, string> Mapping);

/// <summary>What the connector card's LinkedIn branch needs beyond the
/// generic <see cref="ConnectorSummaryDto"/> shape — who is connected and
/// when it last synced, mirroring <c>MailboxConnectionDto</c>'s own
/// "confirms which mailbox was authorized" precedent (design §6.2 point 4).</summary>
public record LinkedInConnectionDetailDto(
    string Status, string? ConnectedAdminName, DateTime? LastSyncedAt, int PollMinutes,
    int SyncedCount, int CreatedLeadCount, int NoteAddedCount, int ErrorCount, string? LastError);

/// <summary>POST /integrations/linkedin/sync-now's answer — same
/// "org-scoped manual trigger" shape as <c>POST /reminders/sweep</c> (design
/// §1's ReminderSweeper precedent).</summary>
public record LinkedInSyncNowResultDto(int Processed, int Created, int NotesAdded, int Errors);

/// <summary>E6 follow-up owner answer 2026-09-29 — one question on a
/// LinkedIn lead-gen form, as the mapping screen (design §7.4) shows it:
/// LinkedIn's own question id/text plus its answer type (e.g.
/// "SINGLE_LINE_TEXT"), which the client uses only for display — this app
/// never validates an answer against the type, exactly like the existing
/// unmapped-question note fallback already accepts any text.</summary>
public record LinkedInFormQuestionDto(string Id, string Text, string Type);

/// <summary>One of the org's LinkedIn lead-gen forms, with its questions —
/// GET /integrations/linkedin/forms's per-form shape (design §7.4's form
/// picker).</summary>
public record LinkedInFormDto(string Id, string Name, List<LinkedInFormQuestionDto> Questions);

/// <summary>GET /integrations/linkedin/forms's answer. <see cref="Available"/>
/// is false whenever the connection isn't <see cref="LinkedInConnectionStatus.Active"/>
/// (not approved yet, expired, erroring) or LinkedIn rate-limits the list
/// call — the client falls back to manual form-id/question entry rather than
/// ever seeing a 500 (E6 follow-up owner answer 2026-09-29, design §12:
/// "falls back to manual entry until LinkedIn approves access").</summary>
public record LinkedInFormsResultDto(bool Available, string? Reason, List<LinkedInFormDto> Forms);

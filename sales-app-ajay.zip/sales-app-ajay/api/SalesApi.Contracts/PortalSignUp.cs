namespace SalesApi.Dtos;

// E19.5 - self sign-up and application for the two portal kinds (partner, customer). Wire shapes are snake_case like the rest of the API.
// The org switch and owner are an org setting (one JSON blob in the settings table); the application is a row of its own (portal_applications).

/// <summary>The states of a sign-up application (owner decision 2026-11-05). Draft until the applicant presses Submit; staff then approve or reject; an old draft is purged.</summary>
public static class SignUpStatus
{
    public const string Draft = "draft";
    public const string Submitted = "submitted";
    public const string Approved = "approved";
    public const string Rejected = "rejected";
    public const string Purged = "purged";
    public static readonly string[] All = [Draft, Submitted, Approved, Rejected, Purged];
}

/// <summary>Why a verified sign-up was not turned into an account: it looks like one we already hold.</summary>
public static class SignUpDuplicateReasons
{
    public const string ContactEmail = "contact_email";
    public const string CompanyName = "company_name";
    public const string EmailDomain = "email_domain";
}

/// <param name="Enabled">Off by default. Cannot be turned on without an owner who is an active staff user of the org.</param>
/// <param name="OwnerProfileId">The staff member who owns new sign-up accounts of this kind.</param>
/// <param name="OwnerName">Read only: the owner's name, for the settings screen.</param>
public sealed record SignUpKindSettingsDto(bool Enabled, Guid? OwnerProfileId, string? OwnerName = null);

/// <summary>GET/PUT /settings/sign-up. <c>declaration_version</c> is derived from the text (a short hash), so an edited text is a new version.</summary>
public sealed record SignUpSettingsDto(SignUpKindSettingsDto Partner, SignUpKindSettingsDto Customer, int PurgeDays, string DeclarationText, string DeclarationVersion);

/// <summary>PUT /settings/sign-up. A null part is left as it is. An empty declaration text resets to the default.</summary>
public sealed record SignUpKindSettingsInput(bool? Enabled, Guid? OwnerProfileId);
public sealed record SignUpSettingsInput(SignUpKindSettingsInput? Partner, SignUpKindSettingsInput? Customer, int? PurgeDays, string? DeclarationText);

/// <summary>GET /public/sign-up/options?org=&amp;kind= - 200 when sign-up is open for that organisation and kind, else 404 (the same 404 for an unknown organisation).</summary>
public sealed record SignUpOptionsDto(string OrgName, string Kind);

/// <summary>POST /public/sign-up/start. <c>org</c> is the organisation's domain (or its id). Always answers the same, whether or not the email is known.</summary>
public sealed record SignUpStartInput(string? Org, string? Kind, string? FullName, string? CompanyName, string? Email);

/// <summary>POST /public/sign-up/verify.</summary>
public sealed record SignUpVerifyInput(string? Token, string? Password);

/// <param name="Result"><c>created</c> (the applicant can sign in and fill in the application) or <c>under_review</c> (it looked like an existing record, so staff review it first; nothing was created).</param>
public sealed record SignUpVerifyDto(string Result, string Email);

public sealed record SignUpDuplicateDto(Guid AccountId, string AccountName, string Reason);

/// <summary>One application. <c>declaration_*</c> are what the applicant accepted (submitted and later) or, on a draft, what they will be asked to accept.</summary>
public sealed record SignUpApplicationDto(
    Guid Id, string Kind, string Status, Guid? AccountId, string? AccountName, string CompanyName, string ApplicantName, string ApplicantEmail,
    Guid? OwnerId, string? OwnerName, SignUpDuplicateDto? Duplicate,
    DateTime CreatedAt, DateTime? SubmittedAt, DateTime? DecidedAt, string? RejectionReason,
    string? DeclarationText, string? DeclarationVersion, DateTime? DeclarationAcceptedAt);

/// <summary>GET /portal/sign-up/application - the applicant's own application, with the KYC checklist the submit will be judged against.</summary>
public sealed record SignUpMineDto(SignUpApplicationDto Application, KycChecklistDto? Checklist);

/// <summary>POST /portal/sign-up/submit. The applicant must tick the declaration.</summary>
public sealed record SignUpSubmitInput(bool AcceptDeclaration);

/// <summary>POST /sign-up-applications/{id}/approve. <c>owner_id</c> optionally reassigns the account to another active staff user.</summary>
public sealed record SignUpApproveInput(Guid? OwnerId);

/// <summary>POST /sign-up-applications/{id}/reject. The reason is required and is emailed to the applicant.</summary>
public sealed record SignUpRejectInput(string? Reason);

/// <summary>POST /sign-up-applications/{id}/link. <c>account_id</c> is the existing account to invite the applicant onto; omitted = the account the application matched (<c>duplicate.account_id</c>).</summary>
public sealed record SignUpLinkInput(Guid? AccountId);

/// <summary>GET /sign-up-applications/count - the review-queue badge. <c>submitted</c> waits for approve / reject; <c>flagged</c> is a held possible duplicate waiting for link / create anyway / reject. They do not overlap.</summary>
public sealed record SignUpCountDto(int Submitted, int Flagged);

/// <summary>GET /sign-up-applications/{id} - the application plus the account's KYC checklist.</summary>
public sealed record SignUpApplicationDetailDto(SignUpApplicationDto Application, KycChecklistDto? Checklist);

/// <summary>The account's current values for the applicant's form. <c>Fields</c> keys are exactly the keys <c>POST /portal/change-requests</c> accepts for an account; an empty value is null.</summary>
public sealed record SignUpDetailsAccountDto(Guid Id, Dictionary<string, string?> Fields);

/// <summary>One contact's current values; <c>Fields</c> keys are exactly the contact keys <c>POST /portal/change-requests</c> accepts.</summary>
public sealed record SignUpDetailsContactDto(Guid Id, string Name, Dictionary<string, string?> Fields);

/// <summary>GET /portal/sign-up/details. <c>Editable</c> while the application is draft or submitted (a draft saves directly, a submitted one files a change request).</summary>
public sealed record SignUpDetailsDto(bool Editable, SignUpDetailsAccountDto Account, List<SignUpDetailsContactDto> Contacts);

// The Amcs contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- AMCs (annual maintenance contracts) ---
public record AmcDto(
    Guid Id, Guid LeadId, string? CustomerName, string? Company, string? CustomerEmail,
    Guid OwnerId, string? OwnerName, string? Title, decimal ContractValue,
    DateTime StartDate, DateTime RenewalDate, int DaysToRenewal, string Status, string? Notes,
    DateTime CreatedAt, DateTime UpdatedAt, Guid? AccountId,
    // H15 renewal prompt. Set ONLY on the PATCH /amcs/{id} response that changed
    // ContractValue, same pattern as InvoiceDto.PaymentCredited/PaymentNotRecorded —
    // null on every other read of an AMC. Tells the caller whether the new value
    // actually reached the term that's currently open, so a silent no-op (the
    // org policy deferring it to the next renewal) is never mistaken for applied.
    bool? ValueChangeReachedCurrentTerm = null,
    string? ValueChangeNote = null,
    // E13: what the deal's workflow calls this recurring contract ("Subscription", "AMC"). Null = "AMC".
    string? Label = null,
    // E14.7: set ONLY on the POST /amcs/{id}/renew response, when the org setting renewal_reprice is on and the renewal could not be
    // priced from the latest price list - says why the value was carried over (or the rep's was used). Null on every other read.
    string? PricingNote = null);

// POST /amcs/{id}/renew body (optional, E14.7). A value the rep types for the new term; it wins over the re-price and the carried-over value.
public record AmcRenewInput(decimal? ContractValue);
public record AmcInput(
    Guid? LeadId, string? Title, decimal? ContractValue,
    DateTime? StartDate, DateTime? RenewalDate, string? Notes, string? Status,
    string? Label = null,
    // Finance fix: true when this contract is the deal's own recurring contract (the offer confirmed after a win), so its
    // first term IS the deal and is not billed again; renewals bill through the contract.
    bool? CoversDeal = null);

// One term of an AMC (D1) — the current AMC row's own StartDate/RenewalDate/
// ContractValue plus every closed-out prior term. InvoiceId is set once the
// term has been raised as an invoice.
public record AmcTermDto(
    Guid Id, Guid AmcId, DateTime StartDate, DateTime EndDate, decimal ContractValue,
    Guid? InvoiceId, DateTime CreatedAt,
    // E14.7: the published pricing version that priced this renewal term; null when it was not priced from a price list.
    int? PricingModelVersion = null);

// PATCH /amcs/{id}/terms/{termId} — per-term value editor (H15). A term
// already tied to a RAISED invoice can't be edited: that invoice is the
// billed, customer-facing record of the term, and rewriting the term under
// it would desync the two without touching what was actually billed.
public record AmcTermInput(decimal? ContractValue);

// GET/PUT /amcs/value-change-policy (H15, manager-only, same shape as every
// other org-settings key: GET returns the effective value with the default
// applied, PUT accepts a raw policy string and returns the normalised result).
// E14.7: RenewalReprice (wire renewal_reprice) is the org setting "Renewals use the latest price list" - off by default. A PUT that sends only
// renewal_reprice leaves the policy as it is; one that sends only policy leaves renewal_reprice as it is.
public record AmcValueChangePolicyDto(string Policy, bool RenewalReprice = false);
public record AmcValueChangePolicyInput(string? Policy, bool? RenewalReprice = null);

// GET/PUT /attachments/card-scan-retention (manager-only) — owner decision
// §45: whether a scanned business-card PHOTO is kept, and for how long, is an
// org setting, not a hardcoded default. Mode is one of CardScanService.Modes
// ("discard" | "keep_for_days" | "keep_forever"); RetentionDays only matters
// for "keep_for_days" (see CardScanService for the normalisation + defaulting).
public record CardScanRetentionDto(string Mode, int RetentionDays);
public record CardScanRetentionInput(string? Mode, int? RetentionDays);

// GET/PUT /attachments/storage-provider (manager-only) — which backend a NEW
// attachment upload writes to ("s3" | "local", AttachmentStorageResolver.Providers).
// PUT is the switch operation: it stamps every existing row of this org still
// reading as unset with the OUTGOING provider before flipping the config (see
// AttachmentStorageService.SetProviderAsync), so already-stored objects keep
// resolving where they actually are.
public record AttachmentStorageProviderDto(string Provider, IReadOnlyList<string> AvailableProviders);
public record AttachmentStorageProviderInput(string? Provider);

// Pre-renewal reminder schedule (days before renewal) delivered to the owner.
public record AmcReminderConfigDto(bool Enabled, List<int> Offsets, int Hour, List<string> Channels);
public record AmcReminderConfigInput(bool? Enabled, List<int>? Offsets, int? Hour, List<string>? Channels)
{
    /// <summary>Null fields keep the current value. The one merge: PUT /amcs/reminder-config and E13's per-workflow override.</summary>
    public AmcReminderConfigDto ApplyTo(AmcReminderConfigDto current) => new(
        Enabled ?? current.Enabled, Offsets ?? current.Offsets, Hour ?? current.Hour, Channels ?? current.Channels);
}
// Manager-defined customer AMC-renewal email. Placeholders: {customer} {company}
// {title} {amount} {renewal_date}.
public record AmcEmailTemplateDto(string Subject, string Body);
public record AmcEmailTemplateInput(string? Subject, string? Body);

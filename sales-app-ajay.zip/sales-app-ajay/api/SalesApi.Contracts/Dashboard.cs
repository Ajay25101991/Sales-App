using System.Text.Json;
using System.Text.Json.Serialization;

// The Dashboard contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Dashboard (camelCase in the contract; forced with JsonPropertyName) ---
// PlaybookIds: the playbooks whose leads make up this bucket (null = the org's
// own list). A stage key means something only against the playbook it came
// from — `proposal_sent` exists in one playbook and not in the org list — so a
// client resolving label/open-ness from the org list alone files a playbook's
// open stage under "closed" with its raw key as the label. Null when a caller
// does not compute it (reports), which reads as "org list only", as before.
public record StatusBucket(string Status, int Count, decimal Value, List<Guid?>? PlaybookIds = null);

public class DashboardDto
{
    [JsonPropertyName("totalLeads")] public int TotalLeads { get; set; }
    [JsonPropertyName("openLeads")] public int OpenLeads { get; set; }
    [JsonPropertyName("wonLeads")] public int WonLeads { get; set; }
    // The other half of WinRate's denominator. Sent so the win-rate tile can
    // show what the rate was computed FROM ("2 won · 1 lost") rather than a
    // bare percentage — a 67% over three deals and a 67% over three hundred
    // are very different numbers to act on. Both counts are period-scoped,
    // exactly as WinRate is.
    [JsonPropertyName("lostLeads")] public int LostLeads { get; set; }
    [JsonPropertyName("valuesVisible")] public bool ValuesVisible { get; set; }
    [JsonPropertyName("openValue")] public decimal OpenValue { get; set; }
    [JsonPropertyName("wonValue")] public decimal WonValue { get; set; }
    [JsonPropertyName("winRate")] public double WinRate { get; set; }
    [JsonPropertyName("overdueFollowUps")] public int OverdueFollowUps { get; set; }
    // Open leads with no update in the team's SLA window (idle_days).
    [JsonPropertyName("idleLeads")] public int IdleLeads { get; set; }
    [JsonPropertyName("idleDays")] public int IdleDays { get; set; }
    // Current-month revenue goal + won-so-far (rep = own; manager = team totals).
    [JsonPropertyName("monthlyTarget")] public decimal MonthlyTarget { get; set; }
    [JsonPropertyName("monthlyWon")] public decimal MonthlyWon { get; set; }
    // Open pipeline weighted by per-stage win probability (expected revenue).
    [JsonPropertyName("weightedForecast")] public decimal WeightedForecast { get; set; }
    [JsonPropertyName("byStatus")] public List<StatusBucket> ByStatus { get; set; } = new();
    // E3.10 — prior-period comparison for the closed-deal tiles (won/lost
    // count+value, win rate). Null for period=all (no floor to compare
    // against) and for the tag-filtered read (no fast grain carries a tag
    // dimension for a prior window — see DashboardProcess.TagFilteredAsync).
    // See DashboardComparisonDto for the two-mode, no-percentage shape.
    [JsonPropertyName("comparison")] public DashboardComparisonDto? Comparison { get; set; }
}

// E3.10 analytics (owner decision, to-do/epics-ai-native-crm.md 2026-09-27):
// "vs previous period" AND "vs same period last year", together — never a
// toggle the caller has to pick ahead of a request. `Value` is the RAW prior
// figure, through the identical measure/grain/scope/masking the current tile
// value went through — never a percentage: "Do not return a percentage the
// client can't reproduce — return both values and let the client compute."
// `Comparable` is false (and `Value` null) when there is nothing honest to
// compare against: the prior window predates the org's first lead, the prior
// value is masked from this caller, or the prior value is a real 0 — decision
// #2, "No baseline -> no change shown ... never +Inf% or a misleading +100%".
// A client that sees Comparable=false shows no chip/tooltip "no earlier data",
// never a computed 0% or infinite change.
public record KpiComparisonValue(decimal? Value, bool Comparable);
public record KpiComparisonDto(KpiComparisonValue Previous, KpiComparisonValue LastYear);
public record DashboardComparisonDto(
    KpiComparisonDto WonCount, KpiComparisonDto WonValue,
    KpiComparisonDto LostCount, KpiComparisonDto LostValue,
    KpiComparisonDto WinRate);

// Manager-configurable win probability (0..1) per open stage, for the forecast.
// Defaulted lists which keys in Probabilities are a computed fallback (no
// manager-entered value on record for that stage) rather than something a
// manager actually set — the config screen uses it to label "defaulted" vs
// "set" so a manager can tell the two apart instead of reading a bare number
// that looks the same either way.
public record ForecastConfigDto(Dictionary<string, double> Probabilities, HashSet<string> Defaulted);
public record ForecastConfigInput(Dictionary<string, double>? Probabilities);

using System.Text.Json;
using System.Text.Json.Serialization;

// The CatalogItems contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Catalog items: THE Products and services list (E10.1). Kind separates
// products from services; Price is the optional plain-quote price. Lead.Products
// holds the Key of these rows. See api/Models/CatalogItem.cs. ---
//
// Price is WITHHELD (null and omitted, never a zero that renders as a real one -
// MaskedMoneyOmissionTests' rule) for a caller without financials.view. That
// caller still gets the list: the deal form's Products picker needs the names.
public record CatalogItemDto(
    Guid Id, string Key, string Name, string Kind, string? Description,
    int SortOrder, DateTime CreatedAt, DateTime? UpdatedAt, DateTime? ArchivedAt = null,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    decimal? Price = null,
    // E10.2 - teams (Team ids) that may generate this SERVICE's proposal; empty = whole org. Always present.
    IReadOnlyList<string>? ScopedTeamIds = null);
// Key is settable on update, same as CustomFieldInput — a rename is a real
// rename of the stable handle, not a request to detach and re-key silently.
// Price needs financials.view to set (the controller refuses otherwise);
// ClearPrice removes a price (a null Price means "leave it as it is").
public record CatalogItemInput(
    string? Name, string? Kind, string? Description, int? SortOrder, string? Key = null,
    decimal? Price = null, bool? ClearPrice = null,
    // E10.2 - services only. Null = leave as is; [] = whole org (KnowledgeCollectionInput's convention).
    List<string>? ScopedTeamIds = null);
public record CatalogItemReorderInput(List<Guid>? Ids);
public record ProposalDto(
    Guid Id, Guid LeadId, Guid AuthorId, string Title, string? Content, JsonElement Modules, decimal? Total,
    string Status, DateTime? SentAt, DateTime? AcceptedAt, DateTime? DeclinedAt, string? AcceptedBy, string? AcceptToken, DateTime CreatedAt,
    // C1 money model — always server-computed, see ProposalTemplate.BuildDocument.
    JsonElement LineItems, decimal? Subtotal, decimal? DiscountAmount, decimal TaxRate, decimal? TaxAmount, DateTime? ValidUntil, string Currency,
    // Automated billing (ProposalBillingService) — null until the proposal is
    // accepted (NextBillingDate) and until the sweep actually generates the
    // invoice (InvoiceGeneratedAt).
    DateTime? NextBillingDate = null,
    DateTime? InvoiceGeneratedAt = null,
    // Quote number (#83) — null until the quote is SENT. Carries the revision
    // suffix when this quote revises another (QT-2026-0188-v2).
    string? Number = null,
    int Revision = 1,
    Guid? SupersedesId = null,
    // E6.3 — counted views only. 0/null for a quote nobody has opened yet
    // (including every brand-new draft, which is never queried — see
    // LeadQuoteProcess.ProposalToDto's remarks).
    int ViewCount = 0,
    DateTime? LastViewedAt = null,
    // E10.5 - generated proposals only (null on every other quote): "ready" | "pending" (the PDF could not be made yet; the
    // version cannot be sent until it exists), the one-line "what changed" against the version it supersedes, and the
    // frozen snapshot (ProposalSnapshotDto) a new version starts from.
    string? PdfState = null,
    string? ChangeSummary = null,
    JsonElement? Snapshot = null,
    // Q12: accepted by the customer after ValidUntil - the price needs confirming. Task 8: lines with no catalogue price quote at 0 and are counted here (each is flagged no_price in line_items).
    bool AcceptedAfterExpiry = false,
    int UnpricedLineCount = 0,
    // Task 10: "exceeds_closed_value" when the billing sweep skipped this accepted quote for finance to settle.
    string? BillingFlag = null);
// The app sends this field as camelCase "catalogItemIds" (unlike the snake_case rest):
// the ids of Products and services (CatalogItemDto.Id), E10.1. Was "moduleIds".
public record GenerateProposalInput([property: JsonPropertyName("catalogItemIds")] List<Guid>? CatalogItemIds);

// The "good" document generator's output (C1): a set of priced line items plus
// a discount and validity window. The server always recomputes Subtotal/Tax/
// Total from these — TaxRate is not accepted from the client (VAT is org
// config, per the hard constraint), and Currency always comes from the org.
// A priced quote line (#83): what it is, how many, and what one costs. The
// line's total is DERIVED — QuoteNumbering.LineTotal(Quantity, UnitPrice) — and
// is neither accepted from the client nor stored, so it cannot disagree with the
// two numbers it is the product of. Quantity is optional on input and defaults
// to 1, which is both what the old {description, amount} shape meant and what
// the historical rows were migrated to.
public record QuoteLineItemInput(string? Description, decimal? Quantity, decimal? UnitPrice, bool? NoPrice = null);
public record GenerateQuoteDocumentInput(
    string? Title, List<QuoteLineItemInput>? LineItems, decimal? DiscountAmount, int? ValidityDays,
    // Set when re-quoting: the quote this one replaces. The new quote inherits
    // that quote's base number and takes the next -vN suffix on send, instead of
    // being issued a number the customer has never seen (#83).
    Guid? SupersedesId = null);
public record QuoteLineItemDto(string Description, decimal Quantity, decimal UnitPrice);
// Team-wide quotes overview row (GET /proposals) — quote joined with lead + owner.
// LineItemCount is the number of priced lines the quote was built from — it is
// what tells a manager scanning the list how big a piece of work each quote is.
// Counted from LineItems (not Modules) because only LineItems is populated on
// both quote flows: the module-picker flow writes them from the chosen modules,
// the document flow from the rep's own lines.
public record QuoteOverviewDto(
    Guid Id, Guid LeadId, string LeadName, string? LeadCompany, string? OwnerName, string Title,
    decimal Total, string Status, DateTime? SentAt, DateTime? AcceptedAt, DateTime CreatedAt,
    int LineItemCount,
    // The customer-facing QT-YYYY-NNNN (#83) — null on a draft, which has not
    // been sent and so has not been numbered.
    string? Number = null,
    // E6 follow-up (design §13 item 3) — the "Views" column on the team
    // quotes list: counted views + when the most recent one landed, same
    // pair LeadQuoteProcess.ProposalToDto already exposes per-quote,
    // batched here via QuoteViewStore.ViewSummariesForAsync (one extra
    // GROUP BY query for the whole page, not one per row). Defaults so the
    // handful of hand-built test rows that predate this column still
    // compile.
    int ViewCount = 0, DateTime? LastViewedAt = null);

// GET /proposals/summary — the quotes-overview KPIs computed over EVERY quote
// the caller may see, not over the page GET /proposals returned (audit H9).
//
// `Total` is also what tells the screen its list is truncated: the list returns
// at most `ListCap` rows, so `Total > ListCap` means "newest 500 of N".
// `StaleAfterDays` is sent rather than hardcoded a third time in a third client.
public record QuoteOverviewSummaryDto(
    int Total, int Draft, int Sent, int Accepted, int Declined, int Superseded,
    int Decided, double WinRate,
    decimal OpenValue, decimal WonValue,
    int Stale, int StaleAfterDays,
    int ListCap);

// Status change and/or a content edit (title/content). All optional.
public record ProposalStatusInput(string? Status, string? AcceptedBy, string? Title, string? Content);

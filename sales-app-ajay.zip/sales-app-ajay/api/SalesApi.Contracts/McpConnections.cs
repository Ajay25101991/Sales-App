// "AI tool connections" admin screen (to-do/mcp-server-design.md item 10): the status read and the MCP call log.
// Wire keys are snake_case by the API's JSON naming policy.

namespace SalesApi.Dtos;

/// <summary>How one MCP tool call ended, and who made it. Fixed vocabularies - the log screen filters and labels on them.</summary>
public static class McpCallOutcomes
{
    public const string Ok = "ok";
    public const string Refused = "refused";
    public const string Error = "error";
}

public static class McpCallerKinds
{
    public const string Person = "person";
    public const string ApiKey = "api_key";
}

public record McpRoleDto(string Key, string Label);

/// <summary>GET /mcp/status. <paramref name="Enabled"/> and <paramref name="PlanIncludes"/> are both "the org's plan has the mcp feature on" (there is no
/// separate org switch). <paramref name="RolesWithPermission"/> is empty unless the caller manages roles or settings.
/// <paramref name="KeyScopes"/> are the API-key scopes an MCP key needs for the full read set plus suggestions.</summary>
public record McpStatusDto(
    bool Enabled, bool PlanIncludes, string Url, bool CanConnect, List<McpRoleDto> RolesWithPermission, List<string> KeyScopes);

/// <summary>One log line. <paramref name="ActorName"/> is the person's name or the key's name, resolved when read (null if since deleted).
/// <paramref name="Reason"/> is the refusal sentence; never arguments, results or personal data.</summary>
public record McpCallDto(
    Guid Id, DateTime OccurredAt, string Tool, string CallerKind, Guid ActorId, string? ActorName, string Outcome, string? Reason, int DurationMs);

public record McpCallPageDto(List<McpCallDto> Items, string? NextCursor);

/// <summary>The per-person override of the "Connect AI tools" role permission (owner 2026-11-17, design item 11), stored in the org settings JSON
/// as <c>mcp_access</c>. A person is in at most one list. Absent from both = follows their role.</summary>
public record McpAccessSettingsDto(List<Guid> Allow, List<Guid> Block);

public static class McpAccessOverrides
{
    public const string Allow = "allow";
    public const string Block = "block";

    /// <summary>"allow", "block" or null (follows the role) for one person.</summary>
    public static string? Of(McpAccessSettingsDto settings, Guid userId) =>
        settings.Block.Contains(userId) ? Block : settings.Allow.Contains(userId) ? Allow : null;
}

/// <summary>One row of GET /mcp/access. <c>RoleAllows</c>: their role holds ai_tools.connect. <c>Override</c>: "allow" | "block" | null (follows role).
/// <c>CanConnect</c>: the effective answer (blocked = false, allowed = true, else <c>RoleAllows</c>); the plan is a separate check.</summary>
public record McpAccessPersonDto(Guid UserId, string Name, string RoleLabel, bool RoleAllows, string? Override, bool CanConnect);

public record McpAccessDto(List<McpAccessPersonDto> People);

/// <summary>PUT /mcp/access body: set <c>Override</c> ("allow" | "block" | null = back to follows role) for every listed person.</summary>
public record McpAccessInput(List<Guid>? UserIds, string? Override);

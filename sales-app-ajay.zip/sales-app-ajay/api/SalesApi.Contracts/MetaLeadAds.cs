// Meta Lead Ads (Facebook / Instagram) connector contracts - the sibling of LinkedInLeadSync.cs. Same "Dtos project, no project
// references" shape. See to-do/meta-lead-ads-design.md.

namespace SalesApi.Dtos;

/// <summary>GET /integrations/meta/connect's answer - the Facebook Login URL to send the admin's browser to.</summary>
public record MetaAuthorizeUrlDto(string AuthorizeUrl);

/// <summary>The connector's own state, additive to the generic connector card's free-string status. No row at all is
/// "not_configured"; credentials saved but no Facebook sign-in yet is "not_connected"; signed in but no Page picked yet is
/// "awaiting_pages"; otherwise active / token_expired / error.</summary>
public static class MetaConnectionStatus
{
    public const string NotConfigured = "not_configured";
    /// <summary>App id / secret / verify token saved, but nobody has signed in with Facebook yet (no connection row).</summary>
    public const string NotConnected = "not_connected";
    public const string AwaitingPages = "awaiting_pages";
    public const string Active = "active";
    public const string TokenExpired = "token_expired";
    public const string Error = "error";
}

/// <summary>What a processed Meta lead turned into (stored on the idempotency row). "skipped" only ever comes from the backfill.</summary>
public static class MetaSyncOutcome
{
    public const string Created = "created";
    public const string NoteAdded = "note_added";
    public const string Skipped = "skipped";
}

/// <summary>One Facebook Page the connecting admin can reach. <c>selected</c> Pages are the ones leads come from.</summary>
public record MetaPageDto(string PageId, string Name, bool Selected, DateTime? SubscribedAt, DateTime? BackfilledAt, string? LastError);

/// <summary>GET /integrations/meta/connection - the connector card: who connected, the Pages, the counters (Synced / Logged /
/// Skipped / Errors, the mailbox connector's wording) and the callback URL the owner registers in the Meta app. <c>webhook_url</c>
/// is null when the server has no public address configured (App:PublicUrl).</summary>
public record MetaConnectionDetailDto(
    string Status, string? ConnectedAdminName, DateTime? LastSyncedAt,
    int SyncedCount, int LoggedCount, int SkippedCount, int ErrorCount, string? LastError,
    List<MetaPageDto> Pages, string? WebhookUrl);

/// <summary>PUT /integrations/meta/pages - the Pages leads should come from. Newly selected Pages are subscribed to the leadgen
/// webhook and backfilled (last 90 days); deselected ones are unsubscribed.</summary>
public record MetaSelectPagesInput(List<string> PageIds);

/// <summary>What a backfill run did: <c>processed</c> = leads looked at, <c>created</c> = new leads, <c>skipped</c> = matched an
/// existing lead (no lead, no note) or already imported, <c>errors</c>. <c>truncated</c> is true when the per-run cap was reached
/// - run it again to continue.</summary>
public record MetaBackfillResultDto(int Processed, int Created, int Skipped, int Errors, bool Truncated);

/// <summary>PUT /integrations/meta/pages's answer.</summary>
public record MetaSelectPagesResultDto(List<MetaPageDto> Pages, MetaBackfillResultDto? Backfill);

/// <summary>POST /integrations/meta/backfill - optional <c>page_id</c> narrows it to one Page (default: every selected Page).</summary>
public record MetaBackfillInput(string? PageId);

public record MetaFormQuestionDto(string Key, string Label, string Type);

/// <summary>One lead form as the admin list shows it: Meta's own form (name, status, questions) joined with the saved mapping.
/// <c>needs_mapping</c> is true until an admin saves a mapping; such a form still creates leads (default lead form, standard
/// name/email/phone/company mapping).</summary>
public record MetaFormDto(
    string FormId, string Name, string? PageId, string? PageName, string? Status,
    List<MetaFormQuestionDto> Questions, bool NeedsMapping,
    Guid? LeadFormId, string? LeadFormName, Dictionary<string, string> Mapping);

/// <summary>GET /integrations/meta/forms. <c>available</c> is false when the connection is not active or Meta rate-limits the list
/// call - the screen then shows the saved mappings only (never a 500).</summary>
public record MetaFormsResultDto(bool Available, string? Reason, List<MetaFormDto> Forms);

public record MetaFormMappingDto(
    Guid Id, string MetaFormId, string? PageId, string? FormName, Guid? LeadFormId,
    Dictionary<string, string> Mapping, bool NeedsMapping, DateTime UpdatedAt);

/// <summary>PUT /integrations/meta/mapping. <c>lead_form_id</c> must be an existing, non-archived lead form (null = default
/// resolution). <c>mapping</c> is {meta question key: "name" | "company" | "email" | "phone" | "custom.&lt;key&gt;"}.</summary>
public record MetaFormMappingInput(string MetaFormId, string? PageId, string? FormName, Guid? LeadFormId, Dictionary<string, string> Mapping);

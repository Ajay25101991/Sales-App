namespace SalesApi.Dtos;

/// <summary>
/// The rules that describe what a loyalty CONTRACT may contain — shared by every
/// layer, because they live in the one project all of them reference.
///
/// WHY HERE. Step 7 of the API-led migration puts validation at every layer, and
/// the obvious way to do that is to write the check three times. That produces
/// three rules that agree right up until someone edits one, and then produces a
/// value the endpoint refuses and the store accepts — or worse, the reverse.
/// Defence in depth means three ENFORCEMENTS of one rule, not three rules.
///
/// It lives in Contracts rather than in the System layer for a reason that only
/// shows up at the boundary: the Experience project cannot see System at all
/// (DisableTransitiveProjectReferences), so a bound defined there would be
/// unreachable from the layer closest to the user — exactly where a bad value
/// should be caught first.
/// </summary>
public static class LoyaltyRules
{
    /// <summary>
    /// Zero IS legal: it is how an org switches one customer, or one source,
    /// off while everything else keeps earning. The ceiling is arbitrary and
    /// finite — it exists so a typo cannot mint a balance nobody can explain.
    /// A NEGATIVE value is refused because a negative earn is a deduction
    /// wearing an earn's name, and deductions are not a mechanic this module
    /// has.
    /// </summary>
    public const int MinPointsPerEvent = 0;
    public const int MaxPointsPerEvent = 10_000;

    /// <summary>Null means "no opinion — follow the rule above me", which is
    /// always legal. That is why this takes a nullable and answers true for
    /// null rather than making every caller special-case it.</summary>
    public static bool IsValidPoints(int? points) =>
        points is not int p || (p >= MinPointsPerEvent && p <= MaxPointsPerEvent);

    public static string PointsRangeMessage =>
        $"points must be between {MinPointsPerEvent} and {MaxPointsPerEvent}";

    // E20.1 - the window the balance counts over. `lifetime` (the default, the behaviour before this setting existed) counts every
    // event ever; `rolling` counts only events newer than N months, so points leave the balance as they age.
    public const string WindowLifetime = "lifetime";
    public const string WindowRolling = "rolling";
    public const int MinWindowMonths = 1;
    public const int MaxWindowMonths = 120;

    public static bool IsValidWindow(string? window) => window is WindowLifetime or WindowRolling;
    public static bool IsValidWindowMonths(int months) => months is >= MinWindowMonths and <= MaxWindowMonths;

    // E20.2 - how often an allowance resets: calendar units in the org's reporting calendar (its time zone). A null allowance is unlimited.
    public const string PeriodMonth = "month";
    public const string PeriodQuarter = "quarter";
    public const string PeriodYear = "year";
    public static bool IsValidPeriod(string? period) => period is PeriodMonth or PeriodQuarter or PeriodYear;
    public const int MaxAllowance = 1_000_000;
    public const int MaxQuantityPerUse = 100_000;
}

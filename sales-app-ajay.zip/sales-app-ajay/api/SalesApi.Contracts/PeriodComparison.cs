// The reader-chosen comparison basis, and the pure date math that applies it.
//
// WHY IT LIVES IN CONTRACTS. It was written in `SystemApi/Services` because
// that is where the first caller happened to be, not because it belongs near
// the database — there is no EF and no HTTP in this file, only an enum and
// arithmetic over two DateTimes. It is the FOURTH value object found sitting in
// System by accident of authorship (after RecordAccessContext, TeamScope and
// CalendarDto), and it was found by the sweep the migration plan called for
// rather than by being blocked, which is the cheaper of the two ways.
//
// It had to move before `/reports/comparison` migrates: the basis is something
// the CALLER chooses, so it lands on a Process method's public surface, and
// LayerBoundaryTests rightly refuses a Process signature that names a System
// type. Moving it now costs a `git mv`; discovering it mid-migration costs a
// rewrite of whatever signature had already been built around it.
//
// The namespace stays `SalesApi.Services` for the same reason every other move
// here kept its namespace: it makes the move cost zero `using` edits.

namespace SalesApi.Services;

// Owner decision §34: "prior equivalent period" is a READER-CHOSEN control,
// not a hidden assumption — trailing window vs same period last year. Default
// is TrailingWindow, because it is the only reading well-defined for an
// arbitrary range: "the N days before these N days" always has an answer,
// whereas "the same period last year" is only meaningful once the period is a
// calendar-aligned one. The label travels with every figure this produces so
// a reader can always see which comparison produced a delta — see
// PeriodComparisonDto.BasisLabel.
public enum PeriodComparisonBasis
{
    TrailingWindow,
    SamePeriodLastYear,
}

public static class PeriodComparison
{
    public static PeriodComparisonBasis Parse(string? raw) => (raw ?? "").ToLowerInvariant() switch
    {
        "same_period_last_year" or "last_year" => PeriodComparisonBasis.SamePeriodLastYear,
        _ => PeriodComparisonBasis.TrailingWindow, // the well-defined-for-anything default
    };

    public static string Label(PeriodComparisonBasis basis) => basis switch
    {
        PeriodComparisonBasis.SamePeriodLastYear => "Same period last year",
        _ => "Trailing window",
    };

    /// <summary>
    /// The PRIOR period a figure over [<paramref name="start"/>, <paramref name="end"/>)
    /// is compared against, under <paramref name="basis"/>. Half-open, matching
    /// every other window in this codebase (MeasureScope's own convention).
    /// </summary>
    public static (DateTime Start, DateTime End) PriorPeriod(DateTime start, DateTime end, PeriodComparisonBasis basis)
    {
        if (basis == PeriodComparisonBasis.SamePeriodLastYear)
            return (start.AddYears(-1), end.AddYears(-1));

        // TrailingWindow: the period of the SAME LENGTH immediately preceding
        // this one — "the 30 days before these 30 days" for a 30-day range.
        var length = end - start;
        return (start - length, start);
    }
}

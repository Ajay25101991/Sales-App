// The AI gateway contracts (E4.1) — to-do/e4-ai-platform-design.md §2.
//
// Lives in SalesApi.Contracts (no project references — root CLAUDE.md's
// architecture table) so a ProcessApi skill class can depend on IAiPlatform
// without ever seeing AppDbContext or a ClaimsPrincipal, the same rule
// LayerBoundaryTests already enforces for every other Process-facing contract.
// SalesApi.SystemApi holds every concrete implementation (AiProviderResolver,
// StubAiPlatform, …) next to EmailProviderResolver, since those need
// AppDbContext and IEmailSecretProtector directly (design §2.4).

// Namespace stays SalesApi.Services (not the design doc's illustrative
// `SalesApi.Contracts`) — this project's actual convention for a plain-interface
// contract like IEmailSender (SalesApi.SystemApi/Services/EmailSending.cs) is to
// keep it in `SalesApi.Services` regardless of which assembly the file lives in,
// exactly as SwipeActions.cs/Settings.cs's DTOs stay `SalesApi.Dtos`. Moving a
// record between assemblies costs callers nothing; renaming its namespace costs
// every one of them a `using` (see SwipeActions.cs's own note).
namespace SalesApi.Services;

/// <summary>
/// What actually changes provider behaviour — a classify call can route to a
/// cheaper model than a free-form complete call — which is why this is a
/// gateway-level axis and not a per-skill choice (design §2.1). Extract/Classify
/// are Complete calls with a constrained output contract, not separate wire
/// shapes.
/// </summary>
public enum AiTaskClass { Complete, Extract, Classify, Embed }

/// <summary>One turn in a conversation sent to the model. <paramref name="Role"/>
/// is "system" | "user" | "assistant" | "tool".</summary>
public sealed record AiMessage(string Role, string Content, IReadOnlyList<AiToolCall>? ToolCalls = null);

/// <summary>A tool invocation — proposed by the model (in an <see cref="AiResponse"/>)
/// or replayed back to it as conversation history. Never auto-executed by the
/// gateway itself; see the E4.7 tool registry design (§7.2) for the
/// propose/execute split this type exists to support. Not built in this slice —
/// carried here only so <see cref="AiRequest"/>/<see cref="AiResponse"/> compile
/// to their designed shape ahead of the tool registry (E4 slices 9-10).</summary>
public sealed record AiToolCall(string Id, string Name, string ArgsJson);

/// <summary>
/// One thing a call's answer drew on — a citation, never the content itself
/// (E4.2 design §3.2: "never logs prompt or completion text... records what
/// was cited, not the field values themselves"). <paramref name="Kind"/> is
/// e.g. "timeline_item" | "lead_field" | "quote" | "knowledge_chunk";
/// <paramref name="Id"/> is that record's id (null when the citation is a
/// field name rather than a row, e.g. a masked custom field);
/// <paramref name="Field"/> names the field for a field-shaped citation. A
/// masked field is recorded exactly like any other citation — kind + id/field
/// — never its value, so "masked fields stay masked in the trace" holds by
/// construction (design §3.4).
/// </summary>
public sealed record AiContextSource(string Kind, Guid? Id, string? Field);

/// <summary>A minimal wrapper around a JSON Schema document — kept as opaque JSON
/// text rather than a typed object graph, the same posture <c>AiSkillVersion.OutputSchemaJson</c>
/// and <c>leads.custom</c> already take for schema-shaped data in this codebase:
/// one storage/transport representation, parsed only where a caller actually
/// needs to walk it.</summary>
public sealed record JsonSchema(string Json);

/// <summary>Who may call a proposed tool, and how carefully — the E4.7 tool
/// registry (§7.1). Not built in this slice; carried here only because
/// <see cref="AiRequest.Tools"/> needs the type to compile to the design's
/// signature ahead of that work (E4 slices 9-10).</summary>
public enum AiToolRiskClass { Read, Recommend, Write, Send, Destructive }

/// <summary>A tool's declared shape — see <see cref="AiToolRiskClass"/>'s note.</summary>
public sealed record AiToolSpec(
    string Name, string Description, JsonSchema ArgsSchema, AiToolRiskClass RiskClass, bool Idempotent);

/// <summary>
/// One call into the gateway. <paramref name="OrgId"/> is always populated by
/// the caller, never inferred inside the gateway — the same "facts about the
/// caller travel down as data" discipline root CLAUDE.md states for
/// controllers, applied one layer earlier here because <see cref="IAiPlatform"/>
/// itself must never read a <c>ClaimsPrincipal</c> (design §2.4).
///
/// <paramref name="UserId"/> and <paramref name="Feature"/> (E4.2, design §3.1)
/// are the caller facts <see cref="Services.LoggingAiPlatform"/> needs to write
/// one execution-log row per call — added here, not read off a principal below
/// the controller, for the same reason <paramref name="OrgId"/> already isn't.
/// <paramref name="Feature"/> is the product surface making the call
/// ("deal-brief", "hygiene", "ask-crm", …), independent of which skill answers
/// it — the same axis <c>AiCostPolicy.FeaturesJson</c> (E4.3) toggles.
/// <paramref name="Sources"/> is optional context-source citations the caller
/// already resolved (E4.5's context engine assembles these; a plain skill call
/// with no context engine behind it yet may leave this null/empty) — see
/// <see cref="AiContextSource"/>.
///
/// <paramref name="RequestId"/> (E5.1): optional, assigned CLIENT-SIDE by the
/// caller before the call — the same "assigned client-side" convention
/// <c>AiToolResult</c>'s own <c>invocationId</c> parameter and
/// <c>WebhookDelivery.Id</c> already use. When set,
/// <see cref="Services.LoggingAiPlatform"/> writes the resulting
/// <c>AiExecutionLogEntry</c> under THIS id instead of minting its own —
/// on every outcome (ok, error, or refused before reaching the provider) —
/// so a caller that needs to reference "the log row this call wrote" (E5.1's
/// brief cache, which stores the entry id) can know it without a second,
/// racy lookup query. Null (every caller before E5.1) behaves exactly as
/// before: the decorator mints a fresh id itself.
/// </summary>
public sealed record AiRequest(
    Guid? OrgId,
    Guid UserId,
    string Feature,
    string Skill,
    int SkillVersion,
    AiTaskClass TaskClass,
    IReadOnlyList<AiMessage> Messages,
    IReadOnlyList<AiToolSpec>? Tools,
    int? MaxOutputTokens,
    double? Temperature,
    bool Stream,
    IReadOnlyList<AiContextSource>? Sources = null,
    Guid? RequestId = null);

/// <summary>
/// One embedding call (E4.6, design §6, slice 12's "close the embed gap"
/// requirement). Carries the same caller facts <see cref="AiRequest"/> does
/// (<paramref name="OrgId"/>/<paramref name="UserId"/>/<paramref name="Feature"/>)
/// so <see cref="Services.LoggingAiPlatform"/> can log and budget-check an
/// embed call exactly like a Complete/Extract/Classify call — before this
/// record existed, <c>IAiPlatform.EmbedAsync(string, ct)</c> carried none of
/// that and the decorator's embed path was an undocumented unlogged,
/// ungated pass-through (see that class's history). <paramref name="Text"/>
/// is the one chunk (or query) to embed.
/// </summary>
public sealed record AiEmbedRequest(Guid? OrgId, Guid UserId, string Feature, string Text);

/// <summary>Token accounting for one call. <paramref name="EstimatedCostUsd"/> is
/// null when the adapter can't price a call (e.g. the stub provider), which the
/// execution log (E4.2, not built here) records as a zero-cost row rather than
/// guessing a number.</summary>
public sealed record AiUsage(int InputTokens, int OutputTokens, decimal? EstimatedCostUsd);

/// <summary>What a completion call returns. <paramref name="ToolCalls"/> are
/// PROPOSED, never yet executed — see <see cref="AiToolCall"/>'s note.
/// <paramref name="ModelId"/> is the concrete model the adapter actually used
/// for this task class, which can differ per org per <c>AiProviderSetting</c>'s
/// per-task-class model fields (design §2.3).</summary>
public sealed record AiResponse(
    string? Text,
    IReadOnlyList<AiToolCall> ToolCalls,
    AiUsage Usage,
    string ModelId,
    string? StopReason);

/// <summary>One chunk of a streamed response. Either a token delta
/// (<paramref name="TextDelta"/> set, <paramref name="FinalResponse"/> null) or
/// the terminal chunk (<paramref name="FinalResponse"/> set), which carries the
/// same <see cref="AiResponse"/>/<see cref="AiUsage"/> shape a non-streaming call
/// returns — design §2.1's "the execution log always has one record shape
/// whether or not the caller streamed."</summary>
public sealed record AiStreamChunk(string? TextDelta, AiResponse? FinalResponse);

/// <summary>
/// The model gateway (E4.1). The single egress point for model traffic — no
/// skill or tool talks to a vendor SDK directly (design §12, "data leaving the
/// tenant"). A plain interface, no <c>AppDbContext</c>, no <c>ClaimsPrincipal</c>
/// — <see cref="SalesApi.LayerBoundaryTests"/>-shaped by construction.
/// </summary>
public interface IAiPlatform
{
    Task<AiResponse> CompleteAsync(AiRequest request, CancellationToken ct = default);
    Task<AiResponse> ExtractAsync(AiRequest request, JsonSchema outputSchema, CancellationToken ct = default);
    Task<AiResponse> ClassifyAsync(AiRequest request, IReadOnlyList<string> labels, CancellationToken ct = default);
    Task<float[]> EmbedAsync(AiEmbedRequest request, CancellationToken ct = default);
    IAsyncEnumerable<AiStreamChunk> StreamAsync(AiRequest request, CancellationToken ct = default);
}

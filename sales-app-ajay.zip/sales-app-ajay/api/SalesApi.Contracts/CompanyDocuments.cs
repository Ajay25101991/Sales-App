// Company documents library: files the org keeps once and any rep can attach to an email. Wire shapes are snake_case (the host's JSON policy).

namespace SalesApi.Dtos;

/// <summary>GET /company-documents (settings.manage): one document with its newest version. <c>Version</c> is the number a send would attach now.
/// <c>ArchivedAt</c> is set on an archived one (listed only with <c>?include_archived=true</c>).</summary>
public record CompanyDocumentDto(
    Guid Id, string Name, string? Category, int Version, string FileName, string ContentType, long SizeBytes, DateTime UpdatedAt, DateTime? ArchivedAt);

/// <summary>GET /company-documents/options (anyone who can send email): the live documents a send may attach - name, category, latest version, size.</summary>
public record CompanyDocumentOptionDto(Guid Id, string Name, string? Category, int Version, string FileName, long SizeBytes);

/// <summary>GET /company-documents/{id}/versions (settings.manage), newest first.</summary>
public record CompanyDocumentVersionDto(int Version, string FileName, string ContentType, long SizeBytes, DateTime UploadedAt, Guid? UploadedById);

/// <summary>PATCH /company-documents/{id}. Every field optional. <c>Category</c> blank clears it. <c>Archived</c> true archives, false restores.</summary>
public record UpdateCompanyDocumentInput(string? Name = null, string? Category = null, bool? Archived = null);

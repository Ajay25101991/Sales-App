namespace SalesApi.Dtos;

// E3.9 — the global search palette (desktop ⌘K). One row of any of the five
// groups below: a record the caller may open, never a record they merely
// matched on a hidden field — see SearchProcess's own remarks for exactly
// what that means for contact email/phone. `Href` is the client route to
// push on Enter/click; the client never has to know which entity shape
// produced a row to navigate to it.
public record SearchHit(string Type, Guid Id, string Title, string? Subtitle, string Href);

// GET /search — grouped, not a single ranked list: each group is capped and
// ranked on its own (SearchProcess.PerTypeLimit), so one huge group (say,
// leads) can never crowd the others out of the response the way a single
// merged top-N would.
public record SearchResultsDto(
    List<SearchHit> Leads,
    List<SearchHit> Accounts,
    List<SearchHit> Contacts,
    List<SearchHit> Quotes,
    List<SearchHit> Invoices);

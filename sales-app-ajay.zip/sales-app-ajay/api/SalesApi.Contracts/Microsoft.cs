// Microsoft 365 umbrella contracts (design doc to-do/microsoft-365-sharepoint-design.md §3):
// the org's ONE Entra app registration and the features that sit under it.
// JSON is snake_case (the host's global naming policy), so Features -> "features",
// NeedSignInAgain -> "need_sign_in_again", and so on.

namespace SalesApi.Dtos;

/// <summary><paramref name="Granted"/> is null until an access check has run, and
/// stays null for delegated permissions — those cannot be proven without a
/// person signing in.</summary>
public record MicrosoftPermissionDto(string Name, string Type, bool? Granted);

/// <summary>
/// <paramref name="Status"/> is one of <c>off | ready | needs_permission |
/// needs_credentials | unavailable | coming_soon</c>. <paramref name="Enabled"/> is
/// READ from where each feature's switch already lives; this screen never owns a
/// second flag. <paramref name="Detail"/> is one plain sentence (why unavailable,
/// what to do next), null when there is nothing to add.
/// </summary>
public record MicrosoftFeatureDto(
    string Key, string Label, bool Enabled, string Status, string? Detail,
    List<MicrosoftPermissionDto> Permissions);

public record MicrosoftCheckDto(DateTime At, bool Ok, List<string> Problems);

/// <summary><paramref name="Connected"/> counts people (not connector rows) with a live
/// Microsoft sign-in; <paramref name="NeedSignInAgain"/> those among them whose stored
/// grant lacks a permission a switched-on feature needs.</summary>
public record MicrosoftPeopleDto(int Connected, int NeedSignInAgain);

/// <summary>The whole screen. The client secret is write-only: only
/// <paramref name="HasSecret"/> ever says one is stored.</summary>
public record MicrosoftConnectionDto(
    bool Configured, string? TenantId, string? ClientId, bool HasSecret, DateTime? UpdatedAt,
    List<MicrosoftFeatureDto> Features, MicrosoftCheckDto? LastCheck, MicrosoftPeopleDto People,
    [property: System.Text.Json.Serialization.JsonPropertyName("sharepoint")] SharePointSettingsDto SharePoint);

/// <summary>PUT /microsoft/credentials. <paramref name="ClientSecret"/> omitted or
/// empty keeps the stored secret; the first save requires one.</summary>
public record MicrosoftCredentialsInput(string? TenantId, string? ClientId, string? ClientSecret);

// --- SharePoint file storage (design doc to-do/microsoft-365-sharepoint-design.md §5) ---

/// <summary>One kind of file the admin can tick. <paramref name="Key"/> is documents | signed_proposals |
/// voice_notes | business_cards | whatsapp_media | knowledge.</summary>
public record SharePointKindOptionDto(string Key, string Label, string Description);

/// <summary>A folder rename / move / create that SharePoint did not accept after every automatic retry.
/// <paramref name="Action"/> is rename | move | create. Retry resets it for the dispatcher to try again.</summary>
public record SharePointSyncProblemDto(
    Guid Id, string RecordType, string RecordLabel, string Action, string Message, int Attempts, DateTime? LastTriedAt);

/// <summary><paramref name="Available"/> is the deployment switch (Microsoft:SharePointEnabled).
/// <paramref name="DeleteMode"/> is recycle | keep.</summary>
public record SharePointSettingsDto(
    bool Available, bool Enabled, string? SiteUrl, string? SiteName, string? LibraryName,
    List<string> Kinds, List<SharePointKindOptionDto> KindOptions, string DeleteMode,
    List<SharePointSyncProblemDto> SyncProblems, bool BrowseEnabled = false, SharePointMoveDto? Move = null);

// --- Move existing files to SharePoint (design doc §5, decision 5) ---

/// <summary>One file the move job could not move. <paramref name="AttachmentId"/> is the file's row id (a knowledge-base
/// document's id for a knowledge document); <paramref name="RecordType"/> is lead | account | quote | invoice | amc |
/// knowledge_collection; <paramref name="RecordLabel"/> is the record as people know it. The file is untouched.</summary>
public record SharePointMoveFailureDto(Guid AttachmentId, string Filename, string RecordType, string RecordLabel, string Message);

/// <summary>
/// The move job as the settings screen reads it (<c>sharepoint.move</c>). <paramref name="Eligible"/> is the files of the
/// ticked kinds still in the CRM's own storage (excluding links, files of deleted records, and files in SharePoint already).
/// <paramref name="State"/> is idle | running | stopping | stopped | finished. <paramref name="Failed"/> counts eligible files
/// the job could not move; <paramref name="Remaining"/> is eligible minus failed. <paramref name="Failures"/> is the first 50.
/// <paramref name="Message"/> is a plain reason when the job stopped by itself (switched off, credentials gone, site
/// unreachable), otherwise null.
/// </summary>
public record SharePointMoveDto(
    int Eligible, string State, int Moved, int Failed, int Remaining,
    DateTime? StartedAt, DateTime? FinishedAt, string? StartedBy,
    List<SharePointMoveFailureDto> Failures, int FailuresTotal, string? Message = null);

/// <summary>PUT settings/microsoft-365 { sharepoint }. A key left out is left unchanged; an empty
/// <paramref name="SiteUrl"/> clears the site.</summary>
public record SharePointSettingsInput(bool? Enabled, string? SiteUrl, List<string>? Kinds, string? DeleteMode, bool? BrowseEnabled = null);

public record MicrosoftSettingsInput([property: System.Text.Json.Serialization.JsonPropertyName("sharepoint")] SharePointSettingsInput? SharePoint);

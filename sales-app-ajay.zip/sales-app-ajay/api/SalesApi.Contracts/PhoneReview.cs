namespace SalesApi.Contracts;

// Admin → "Phone numbers to review" (owner 2026-09-30, to-do/epics-ai-native-crm.md
// "Phone storage" row + to-do/phone-matching-audit.md). A row here is a lead or
// contact whose phone was captured with no country and no leading '+'/'00', so it
// stays digits-only (Lead.NormalizePhone's step 3) and can't match its
// international twin. See PhoneReviewProcess for the exact qualifying predicate.

public record PhoneReviewRowDto(
    string Kind, Guid Id, string Name, string Phone,
    string? SuggestedCountry, string? SuggestedE164, string? OwnerName);

public record PhoneReviewListDto(List<PhoneReviewRowDto> Rows, string? NextCursor, int Total, int UnrecoverableCount);

/// <summary>Backs the Admin hub card — hidden entirely when both are 0.</summary>
public record PhoneReviewCountDto(int Leads, int Contacts);

public record PhoneReviewApplyItem(string Kind, Guid Id, string Country);
public record PhoneReviewApplyInput(List<PhoneReviewApplyItem> Items);

public record PhoneReviewApplyResultDto(string Kind, Guid Id, string E164);

/// <summary>A row that no longer qualifies by the time apply runs (already
/// fixed by someone else, deleted, or turned out to be a different org) — never
/// an error, just left out of Results and reported here instead.</summary>
public record PhoneReviewApplySkippedDto(string Kind, Guid Id, string Reason);

public record PhoneReviewApplyResponseDto(int Applied, List<PhoneReviewApplyResultDto> Results, List<PhoneReviewApplySkippedDto> Skipped);

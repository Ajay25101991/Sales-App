// The Partner API contracts (EP-25 integration, 2026-09-20) — the wire shapes
// for API-key callers reached through Controllers/PartnerApiController.cs.
// Read-only shapes carry only what an external delivery-tracking system needs
// to correlate its own records (accounts/contacts for incremental sync, a
// lead by id); the update shape is a deliberately narrow allow-list — no
// ownership, stage, or commercial (value/currency) field is writable here.

namespace SalesApi.Dtos;

public record PartnerAccountDto(
    Guid Id, string Name, string? Industry, string? Website, string? Phone,
    string? Address, string? City, string? State, string? PostalCode, string? Country, string? CountryCode,
    DateTime CreatedAt, DateTime UpdatedAt,
    // E12.3 - see LeadDto.FieldAccess: the fields not at full for this key (the External partner row), e.g. phone -> masked_partial.
    Dictionary<string, string>? FieldAccess = null);

public record PartnerContactDto(
    Guid Id, Guid AccountId, string Name, string? Title, string? Email, string? Phone,
    DateTime CreatedAt, DateTime UpdatedAt,
    Dictionary<string, string>? FieldAccess = null);

public record PartnerLeadDto(
    Guid Id, string Name, string? Company, string? Email, string? Phone,
    string Status, string? Source,
    Guid? AccountId, string? AccountName, Guid? ContactId, string? ContactName,
    decimal? EstimatedValue, string Currency,
    DateTime? ExpectedCloseDate, DateTime? WonAt, DateTime? LostAt,
    string? DeliveryStatus, string? DeliveryNextMilestone, decimal? DeliveredHours, string? DeliveryNote, DateTime? DeliveryUpdatedAt,
    DateTime CreatedAt, DateTime UpdatedAt,
    Dictionary<string, string>? FieldAccess = null);

/// <summary>
/// The ENTIRE allow-list for a `leads:update` PATCH. Every field is optional
/// (a partner sends only what changed); anything not on this record — status,
/// owner, account, value — cannot be sent because there is no property here
/// to bind it to, not because of a runtime check that could be missed.
/// </summary>
public record PartnerLeadDeliveryInput(
    string? DeliveryStatus, string? DeliveryNextMilestone, decimal? DeliveredHours, string? DeliveryNote);

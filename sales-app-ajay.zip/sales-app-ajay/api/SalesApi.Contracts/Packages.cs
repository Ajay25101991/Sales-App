using System.Text.Json;

namespace SalesApi.Dtos;

// --- E7.1 packages: manifest format ---------------------------------------
// Design doc to-do/e7-config-platform-design.md §2 (format), §6 (security).
// This slice covers FLAT, non-versioned items only (custom fields, picklists,
// and the safe subset of OrgSettings keys, which includes terminology — see
// PackageExportProcess.SafeOrgSettingKeys for the allow-list and why
// terminology is folded into "org_setting" rather than a fifth kind:
// mechanically it is exactly one more Settings row, keyed the same way as
// the rest). Versioned items (playbooks/automations/lead forms/AI skills),
// rollback, templates, sandbox and studio are later slices, per the story
// brief.

/// <summary>
/// The hard allow-list §2.2/§6 requires: the exporter only ever walks item
/// KINDS it knows about, and the importer refuses anything outside this list
/// outright rather than guessing at an unrecognised kind's shape. A future
/// item type is invisible here until someone deliberately adds it — the safer
/// failure direction for "never export/import a secret by accident."
/// </summary>
public static class PackageItemKinds
{
    public const string CustomField = "custom_field";
    public const string Picklist = "picklist";
    public const string OrgSetting = "org_setting";
    /// <summary>Slice 5 — versioned (draft/live/archived) kinds. Export
    /// carries the LIVE version's content only (§2, "export the live
    /// version's content"); import always creates a new DRAFT on the matched
    /// (or newly-created) item, never auto-published (§2.4).</summary>
    public const string Playbook = "playbook";
    public const string LeadForm = "lead_form";
    public const string Automation = "automation";

    public static readonly string[] All = { CustomField, Picklist, OrgSetting, Playbook, LeadForm, Automation };

    /// <summary>The versioned subset — draft/live/archived, identified by an
    /// admin-set <c>Key</c> (§10 owner answer 5), never a slug re-derived
    /// from the item's own free-text name.</summary>
    public static readonly string[] Versioned = { Playbook, LeadForm, Automation };
}

/// <summary>One item inside a package. <see cref="StableKey"/> is never a
/// database id (§2.1) — identity across orgs is by this key alone, scoped
/// within <see cref="Kind"/>. <see cref="ContentHash"/> hashes only
/// <see cref="Body"/>'s normalized JSON (not the key or the dependency
/// list) — see PackageBodyFactory.Hash.</summary>
public record PackageItemDto(
    string Kind,
    string StableKey,
    string ContentHash,
    List<string> DependsOn,
    JsonElement Body,
    /// <summary>Set only on an exported package, only for an item the
    /// exporter added on its own (§2.2 point 3) because something the admin
    /// DID pick needs it — null for an item the admin picked directly.</summary>
    string? AutoAddedReason = null);

public record PackageManifestDto(
    int SchemaVersion,
    Guid PackageId,
    string Name,
    Guid? SourceOrgId,
    DateTime CreatedAt,
    List<PackageItemDto> Items);

/// <summary>A dependency edge the exporter could not resolve to an item in
/// scope — §2.2 point 4 ("will not transfer" rather than silently exported
/// or silently dropped).</summary>
public record PackageUnresolvedReferenceDto(string FromStableKey, string TargetKind, string TargetStableKey, string Reason);

/// <summary>A picked item that produced nothing to export — today the only
/// case is a versioned item with no LIVE version (a draft-only playbook/
/// automation/lead form has nothing published to snapshot), stated rather
/// than silently omitted (§2's "say what happens when there is none").</summary>
public record PackageSkippedExportItemDto(string Kind, string StableKey, string Reason);

public record PackageExportResultDto(
    PackageManifestDto Manifest,
    List<PackageUnresolvedReferenceDto> UnresolvedReferences,
    List<PackageSkippedExportItemDto>? SkippedItems = null);

public record PackageExportSelectionDto(string Kind, string StableKey);
public record PackageExportRequestDto(string? Name, List<PackageExportSelectionDto> Items);

// --- Import preview / diff (§2.3) -----------------------------------------

public static class PackageDiffStates
{
    /// <summary>Key absent in the target org.</summary>
    public const string New = "new";
    /// <summary>Same content hash as the target's current row.</summary>
    public const string Unchanged = "unchanged";
    /// <summary>Different hash, no structural risk — needs a resolution
    /// choice but is not itself a flagged conflict.</summary>
    public const string Changed = "changed";
    /// <summary>A real decision, not just a diff — §2.3's table (for this
    /// slice: a custom field's Type changing on an already-existing field).</summary>
    public const string Conflict = "conflict";
    /// <summary>E7.3 — sandbox-diff only (never produced by an ordinary
    /// import preview, which is additive and never reports something the
    /// PACKAGE doesn't mention): present in a fresh export of production,
    /// absent from a fresh export of the sandbox — i.e. removed/archived
    /// inside the sandbox since it was cloned. Promoting it requires an
    /// explicit acknowledgement per item (§4.4/§0.1's mock).</summary>
    public const string Removed = "removed";
}

public record PackageFieldDiffDto(string Field, string? Before, string? After);

public record PackageDiffItemDto(
    string Kind,
    string StableKey,
    string State,
    string? ConflictReason,
    List<PackageFieldDiffDto> FieldDiffs,
    /// <summary>Set when this item's own depends_on names a key that exists
    /// in neither the package nor the target org — the "unresolved
    /// reference" case (§2.3), never silently dropped.</summary>
    string? DependsOnMissingKey = null,
    /// <summary>Things the import will change from what the package says, stated rather than done silently (E13: a handover item that names a
    /// person who is not in this org is given to the deal's owner instead). Null when there are none.</summary>
    List<string>? Warnings = null);

public record PackageImportPreviewRequestDto(PackageManifestDto Package);

/// <summary><see cref="PackageHash"/> is a hash of the whole manifest as
/// previewed — Apply re-sends it as <see cref="PackageApplyRequestDto.ExpectedPackageHash"/>
/// so a package that changed since preview is refused (§2.3's binding
/// rule), not silently applied against a stale diff.</summary>
public record PackageImportPreviewDto(string PackageHash, List<PackageDiffItemDto> Items);

// --- Import apply (§2.3 resolution choices, §2.5 atomic apply + audit) ----

public static class PackageResolutionChoices
{
    public const string KeepTarget = "keep_target";
    public const string TakePackage = "take_package";
    /// <summary>Only valid for a flat blob with independent fields
    /// (org_setting/terminology in this slice) — never offered for
    /// custom_field/picklist, whose fields are not independently mergeable
    /// the same way (§2.3's table).</summary>
    public const string Merge = "merge";
    public const string Skip = "skip";

    public static readonly string[] All = { KeepTarget, TakePackage, Merge, Skip };
}

public record PackageItemResolutionDto(string Kind, string StableKey, string Choice);

public record PackageApplyRequestDto(
    PackageManifestDto Package,
    string ExpectedPackageHash,
    List<PackageItemResolutionDto> Resolutions);

public record PackageApplyItemResultDto(string Kind, string StableKey, string Action, List<string>? Warnings = null); // created | updated | skipped | unchanged | archived

/// <summary>E7.3: an already-ACKNOWLEDGED removal to carry out inside the
/// SAME apply as any creates/updates in the same call — see
/// <c>PackageImportProcess.ApplyAsync</c>'s <c>removals</c> parameter. Never
/// constructed from raw client input without going through
/// <c>SandboxProcess.PromoteAsync</c>'s own acknowledgement check first.</summary>
public record PackageRemovalSelectionDto(string Kind, string StableKey);

public record PackageApplyResultDto(
    Guid ApplyRecordId,
    DateTime AppliedAt,
    string PackageHash,
    int Created, int Updated, int Skipped, int Unchanged,
    List<PackageApplyItemResultDto> Items,
    /// <summary>E7.3 — items archived by an explicit, acknowledged promote
    /// removal (§4.4). Zero for every ordinary import/clone/template apply,
    /// which never removes anything on its own.</summary>
    int Removed = 0);

/// <summary>Why Apply refused. <see cref="StalePackage"/> is §2.3's hash
/// check; <see cref="UnresolvedStableKeys"/> lists every changed/conflicting
/// item with no resolution choice yet, or whose dependency reference is
/// still unresolved.</summary>
public record PackageApplyRefusalDto(string Reason, List<string>? UnresolvedStableKeys = null, bool StalePackage = false);

// --- Slice 6: apply history + rollback (§2.5, §2.6) -------------------------

/// <summary>One row of GET /admin/packages/applies — "who, when, counts,
/// rolled back?" (design doc §2's own words for this list).</summary>
public record PackageApplyRecordDto(
    Guid Id,
    string PackageName,
    string PackageHash,
    Guid? SourceOrgId,
    Guid? AppliedByProfileId,
    DateTime AppliedAt,
    int Created, int Updated, int Skipped, int Unchanged,
    List<PackageApplyItemResultDto> Items,
    bool IsRollback,
    /// <summary>Set once a LATER apply has rolled this one back — the "rolled
    /// back?" column the design's apply-history list calls for.</summary>
    DateTime? RolledBackAt,
    Guid? RolledBackByApplyRecordId);

/// <summary>Rollback is refused when a later apply already touched one of
/// this apply's own items, unless the caller passes <c>force</c> — the same
/// "a real decision, not just a diff" posture §2.3 gives ordinary import
/// conflicts. Named rather than silently allowed, because a forced rollback
/// can overwrite work a later, unrelated apply already did to the same
/// item.</summary>
public record PackageRollbackRequestDto(bool Force = false);

public record PackageRollbackResultDto(
    Guid RollbackApplyRecordId,
    DateTime AppliedAt,
    int Restored,
    List<PackageApplyItemResultDto> Items);

public record PackageRollbackRefusalDto(string Reason, List<string>? SupersededByLaterApplies = null);

// --- E7.2: templates + clone-from-org (design doc §3, §8 slice 8) ---------
// Templates are packages, shipped with the app rather than exported from a
// live org (§3: "templates are not a special case of the import pipeline,
// they are its first caller"). GET /templates lists them for the new-org
// wizard's "start from template" step; applying one runs through the SAME
// PackageImportProcess every other import uses.

/// <summary>One row of GET /templates — name, description, and how many
/// items it carries, without shipping the whole manifest to a screen that
/// only needs to list them (the manifest itself is only ever built at apply
/// time).</summary>
public record TemplateSummaryDto(string Id, string Name, string Description, int ItemCount);

/// <summary>Body of POST /admin/organizations/{targetOrgId}/clone-from/{sourceOrgId}
/// — everything else about the clone (source, target) is already in the
/// route.</summary>
public record CloneOrgConfigInput(string? Name);

using System.Text.Json;
using System.Text.Json.Serialization;

// The Reports contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Pipeline movement report (GET /reports/movement) ---
public record MovementLineDto(
    Guid LeadId, string LeadName, string? Company, decimal? Value,
    string Kind, // entered | advanced | slipped_back | quiet
    string? FromStatus, string? FromLabel, string? ToStatus, string? ToLabel,
    DateTime At, int DaysInPriorState, bool IsBackfilled);
// One rep's movement lines plus the header totals the collapsed accordion shows.
// The totals come from the pre-aggregated tables, never from a scan of `leads`:
//   OpenValue/OpenCount/LeadCount — PipelineStats (a *snapshot* of the rep's
//     current pipeline, so it describes now, not the report window).
//   WonValue/WonCount            — DailyDealStats summed over [From, To], so it
//     is windowed exactly like the lines are.
//
// WonValue is deliberately WON only, not won + lost. Sitting beside OpenValue it
// reads as money closed, and lost value is money forgone, not earned — summing
// them inflates the figure and makes a rep with large losses look productive.
// If a "deals decided" figure is ever wanted, add it as its own field rather
// than folding two opposite outcomes into one number.
//
// Values are null (counts still populated) for callers without ViewLeadValues.
//
// LineCount is the rep's TRUE total, independent of how many rows `Lines`
// actually carries. GET /reports/movement caps `Lines` to
// ReportsController.MovementLinesPageSize and still reports the real
// LineCount, so the client's "Show N more" disclosure can name the whole
// hidden count on the first response, even for rows past the page it can't
// show yet (see GET /reports/movement/lines). GET /reports/movement/export
// builds its DTO from BuildMovementReportAsync directly, never through the
// paginating action, so LineCount == Lines.Count there always.
public record MovementRepGroupDto(
    Guid OwnerId, string? OwnerName, List<MovementLineDto> Lines,
    decimal? OpenValue, int OpenCount,
    decimal? WonValue, int WonCount,
    int LeadCount, int LineCount);
public record MovementReportDto(DateTime From, DateTime To, List<MovementRepGroupDto> Reps);
// GET /reports/movement/lines — one rep's next page of lines, past whatever
// GET /reports/movement already embedded. HasMore tells the client whether a
// further "load more" click has anything left to do.
public record MovementLinesPageDto(List<MovementLineDto> Lines, bool HasMore);

// Leads added per salesperson within an optional date window, from
// Lead.CreatedAt + Lead.CreatedById.
//
// The key is the CREATOR, not the owner. It used to be the owner, which made
// this report answer a question nobody asked — "leads created in this window
// that this person currently owns" — and moved a closed period's credit whenever
// a lead was handed over. Renamed from OwnerId/OwnerName rather than left
// alone: a field called `owner_id` holding a creator is precisely the kind of
// almost-right label this audit exists to remove.
//
// IsUnattributed marks the single row standing for leads with NO recorded
// creator: everything created before the column existed, plus every lead the
// public web form will ever capture. It is not a person — no id, no rep report,
// no picker — and clients must not link it anywhere. CreatorId is null on it.
public record LeadsAddedRowDto(Guid? CreatorId, string? CreatorName, int Count, bool IsUnattributed = false);
public record LeadsAddedReportDto(DateTime From, DateTime To, List<LeadsAddedRowDto> Rows);

// --- Quote conversion report (GET /reports/quotes) ---
// Sent = Proposal.SentAt != null. AcceptRate = accepted / sent. Decision-time
// (days from SentAt to the decision) is computed ONLY over proposals whose
// decision date is actually known: accepted (AcceptedAt is always set on
// accept) or declined AFTER DeclinedAt existed. PendingCount (still awaiting
// a decision) and DeclinedUnknownDateCount (declined before DeclinedAt was
// added, so the date was never captured) are both reported explicitly so a
// median never silently drops the slow/undated cases and reads as complete.
// SentValue is null — never 0 — for a caller without lead_values.view. Masking
// it to 0 made every rep's quote pipeline read "$0 sent" and put the whole rep
// list in an arbitrary order (see ComputeQuoteConversionAsync, which now ranks
// by sent COUNT when the values are withheld).
public record QuoteRepRow(
    Guid OwnerId, string? OwnerName,
    int SentCount, decimal? SentValue, int AcceptedCount, int DeclinedCount,
    double AcceptRate, int DecidedCount, double? MedianDecisionDays);

public record QuoteConversionDto(
    int SentCount, decimal? SentValue, int AcceptedCount, int DeclinedCount, int PendingCount,
    double AcceptRate, int DecidedCount, int DeclinedUnknownDateCount, double? MedianDecisionDays,
    List<QuoteRepRow> Reps);

// --- Pipeline close-date coverage (GET /reports/pipeline-coverage) ---
// Of OPEN pipeline only: what share of count and of value carries a
// rep-entered Lead.ExpectedCloseDate. This is the gate for whether a
// commit/forecast board built on that field would reflect real pipeline or
// mostly nulls — see crm-scope-decisions.md. It is not itself a forecast.
// The value half — OpenValue/DatedValue and the ValueCoverage RATIO derived
// from them — is null for a caller without lead_values.view. It used to mask
// the values to 0 at the projection and then divide, which printed a confident
// "0% of pipeline value has a close date" beside a count coverage of 70% on the
// same card. Count coverage leaks nothing and always stands.
public record PipelineCoverageRepRow(
    Guid OwnerId, string? OwnerName,
    int OpenCount, int DatedCount, double CountCoverage,
    decimal? OpenValue, decimal? DatedValue, double? ValueCoverage);

// The org totals here span the caller's owned pipeline PLUS the routing queue;
// the Reps rail spans owned pipeline only. Deliberate: an unowned lead is real
// uncovered pipeline (nobody has entered a close date on it) but it is nobody's
// coverage to improve, so it is counted once at the top and given no rail row.
// The rail therefore need not sum to the header — see ReportsController.PipelineCoverage.
public record PipelineCoverageDto(
    int OpenCount, int DatedCount, double CountCoverage,
    decimal? OpenValue, decimal? DatedValue, double? ValueCoverage,
    List<PipelineCoverageRepRow> Reps);

// --- MD monthly pack (GET /reports/md-pack) ---
// One shareable, period-bounded summary composed entirely from figures other
// screens already compute (see ReportsController.MdPack for exactly which
// method backs each field) — never a second, independently-computed number.
// Dso and PeriodInvoiced are the one genuinely new pair introduced for this
// endpoint (no existing endpoint exposes invoiced value for an arbitrary past
// month); Dso is null when PeriodInvoiced is 0 rather than guessed. Similarly
// the two Amc* figures have no other backend endpoint today (the AMC screen
// computes its renewal book client-side) — see the controller comment.
public record MdPackBookingRow(Guid UserId, string? FullName, decimal Target, decimal Bookings, double Attainment);

// ArOutstanding/ArOverdue/PeriodInvoiced/CashCollected masked (null) without
// ViewAccountFinancials (invoice-money-masking, owner decision 2026-09-28) —
// same convention as CollectionsDto, which ArOutstanding/ArOverdue/ArAging are
// sourced from directly. Dso is a ratio (days), not money, and stays visible.
public record MdPackDto(
    string Period, DateTime PeriodStart, DateTime PeriodEnd, string Currency,
    decimal TotalTarget, decimal TotalBookings, double TotalAttainment, List<MdPackBookingRow> Bookings,
    int QuotesSentCount, decimal QuotesSentValue, int QuotesAcceptedCount, double QuotesAcceptRate,
    decimal? ArOutstanding, decimal? ArOverdue, List<AgingBucket> ArAging,
    double? Dso, decimal? PeriodInvoiced,
    decimal? CashCollected,
    decimal AmcActiveBookValue, int AmcActiveCount,
    decimal AmcDueWithin90Value, int AmcDueWithin90Count);

// --- Rep self-scorecard (GET /reports/scorecard) ---
// Private, rep-facing monthly view: target/closed/gap, this rep's activity
// against the TEAM MEDIAN, win rate this period vs last, untouched ("idle")
// pipeline, and this rep's own overdue reminders. See
// ReportsController.Scorecard for the authorization + median computation —
// TeamMedianActivity is the ONLY team-wide figure here, reduced to a single
// number server-side; this DTO never carries another rep's raw count, even
// when a manager requests someone else's scorecard via ?user_id=.
// Value is null without lead_values.view — the idle lead still needs chasing,
// which is the whole point of the list; only its amount is withheld.
// Accounts rework (L1): idle is measured from LastContactAt (null = never contacted, measured from creation); UpdatedAt is
// still the lead's last edit, kept for existing readers.
public record ScorecardIdleLeadRow(Guid Id, string Name, string? Company, decimal? Value, DateTime UpdatedAt, DateTime? LastContactAt = null);
public record ScorecardOverdueReminderRow(Guid Id, Guid? LeadId, string Title, DateTime RemindAt);

// Item 10: closed value per week, weeks starting on the org calendar's
// configured day (OrgCalendarService.WeekStartFor) — a straight partition of
// the same closed-won leads Closed sums, so these rows always sum to Closed.
public record ScorecardWeekDto(DateTime WeekStart, decimal ClosedValue);

public record ScorecardDto(
    string Period, DateTime PeriodStart, DateTime PeriodEnd, string Currency,
    ProfileLite User,
    // Null, not 0, without lead_values.view. Masking these to 0 made Gap fall
    // out as 0 and Attainment as 0 — a screen reading "on target, nothing
    // owing" to someone who is simply not allowed to see the numbers.
    decimal? Target, decimal? Closed, decimal? Gap, double? Attainment,
    int ActivityCount, double? TeamMedianActivity,
    double? WinRateThisPeriod, double? WinRateLastPeriod,
    // The two counts the win rate is a ratio OF, and the open value still
    // behind the target. All three fall out of collections Scorecard already
    // materialises (ownLeads, filtered by the same phase service), so they
    // cost no extra query — see ReportsController.Scorecard. WonCount/LostCount
    // are this period only, matching WinRateThisPeriod; OpenPipelineValue is a
    // snapshot of open leads right now, and is NULL (not 0) without the
    // lead-values permission, like every other money figure here.
    int WonCount, int LostCount, decimal? OpenPipelineValue,
    int IdleDays, int IdleLeadCount, decimal? IdleLeadValue, List<ScorecardIdleLeadRow> IdleLeads,
    int OverdueReminderCount, List<ScorecardOverdueReminderRow> OverdueReminders,
    List<ScorecardWeekDto> WeeklyClosedValue);

// --- "Needs you today" (GET /reports/needs-you-today) ---
// A prioritised, per-user action list — NOT a report and not the dashboard's
// stat tiles (those stay untouched; this is its own destination). Five
// sections, each independently empty-able; ReportsController.NeedsYouToday
// documents exactly what each reuses vs computes fresh, and why sections 1
// and 3 are commonly/always empty today. Every row below carries the ids a
// client needs to deep-link straight to the real thing — never to a generic
// filtered list.

// Section 1 — deals that slipped (regressed a stage) or gone quiet (no stage
// movement within the team's idle window), sourced from LeadStageEvents.
// Regressed and Stalled are independent booleans; a row can be both.
// OwnerId travels alongside OwnerName because consumers that group these rows
// by rep must key on the id: names are not unique, so a name match silently
// merges two people who happen to share one (see risk-leaderboard.tsx).
// OwnerId is NULL for a lead still in the routing queue (OwnerName reads
// "Unassigned"). Those rows are included only for a caller who can route them —
// see ReportsController.NeedsYouToday. A consumer grouping by rep must SKIP a
// null id rather than coerce it: the queue is not a person to nudge, which is
// the same rule RiskLeaderboard already applies to the leaderboard's
// Unassigned row.
public record NeedsYouTodayDealRow(
    Guid LeadId, string LeadName, string? Company, Guid? OwnerId, string? OwnerName,
    string? FromStatus, string ToStatus, DateTime ChangedAt, bool IsBackfilled,
    bool Regressed, bool Stalled, int DaysInStage);

// Section 2 — pending reminders past their remind_at. LeadId/InvoiceId/AmcId
// (at most one meaningfully set, mirroring Reminder) tell the client which
// detail screen to deep-link to.
public record NeedsYouTodayReminderRow(
    Guid Id, Guid? LeadId, string? LeadName, Guid? InvoiceId, Guid? AmcId,
    Guid OwnerId, string? OwnerName, string Title, DateTime RemindAt);

// Section 3 — invoice collection promises broken (PromisedDate has passed and
// the invoice is still unpaid). Structurally empty today — see the empty_reason
// on the parent DTO.
// PromisedAmount and OutstandingBalance are null for a caller without
// financials.view. The same user is refused outright by GET /invoices
// (InvoicesController's class-level gate), so this list must not hand them the
// receivable figure through the side door. The ROW stays: a broken promise
// still needs chasing, and the work is not the money.
public record NeedsYouTodayPromiseRow(
    Guid ActivityId, Guid InvoiceId, string InvoiceNumber, Guid? LeadId, string? LeadName,
    DateTime PromisedDate, decimal? PromisedAmount, decimal? OutstandingBalance, Guid OwnerId, string? OwnerName);

// Section 4 — active AMCs renewing within 60 days whose lead has had no
// activity within the team's idle window.
// ContractValue is null without financials.view — same rule as the promise row
// above (AmcsController is itself gated on financials.view, so the contract
// figure must not leak out of this list either).
public record NeedsYouTodayAmcRow(
    Guid Id, Guid LeadId, string? LeadName, string? Company, string? Title,
    decimal? ContractValue, DateTime RenewalDate, int DaysToRenewal, Guid OwnerId, string? OwnerName);

// Section 5 — approval requests waiting on THIS user's decision. Empty (with a
// reason) for anyone who cannot decide approvals — nothing is "waiting on" a
// rep whose requests are pending someone else's call.
public record NeedsYouTodayApprovalRow(
    Guid Id, string Type, Guid? LeadId, string? LeadName, decimal? Amount, string? Reason,
    Guid RequesterId, string? RequesterName, DateTime CreatedAt);

// Every list here is CAPPED (the cap protects the render — see
// ReportsController.NeedsYouToday), so each one is paired with a `*Total`: the
// real number of matching items, counted before the cap.
//
// Audit H10. Without the totals the clients rendered each array's `.length` as
// the section count and summed those into the headline badge, so an org with 63
// at-risk renewals read "50" forever and the badge could never move — a
// truncation limit wearing the label of a count. The badge now shows the total,
// the list still shows the cap, and each section says which it is showing.
// Deliberately NO single "cap" field: the sections do not share one cap (overdue
// follow-ups keep a larger one), so one number would be wrong for at least one
// section. Truncation is `rows.length < total`, which cannot lie.
// Audit H16 — "who needs attention" ranking. Used to be recomputed client-side
// (packages/ui/src/charts/risk-leaderboard.tsx) from the CAPPED SlippedDeals /
// OverdueFollowUps arrays above, with a hardcoded `overdue + stalled +
// regressed * 1.5` formula that desktop explicitly refused to port (no endpoint
// blessed the 1.5). Both defects are fixed the same way: RepRisk is computed
// here, server-side, from the FULL pre-cap lists (see ReportsController.NeedsYouToday),
// using org-configurable weights (OrgSettings.GetRiskWeightsAsync).
// Already sorted descending by Score with zero-score reps dropped — a client
// renders this list as-is, it does not re-rank it.
public record RepRiskRow(Guid UserId, string? FullName, int Overdue, int Stalled, int Regressed, double Score);

// E2.1 — tasks due today or already overdue, for the caller only ("mine" —
// Needs-you-today has never shown a manager their team's items in any other
// section either; TaskDto already carries everything the row needs).
public record NeedsYouTodayTaskRow(
    Guid Id, string Title, DateTime? DueAt, string Priority,
    string? LinkedRecordType, Guid? LinkedRecordId, string? LinkedRecordName, bool Overdue);

public record NeedsYouTodayDto(
    int IdleDays,
    List<NeedsYouTodayDealRow> SlippedDeals, int SlippedDealsTotal, int OpenDealsWithStageHistory, int OpenDealsTotal,
    List<NeedsYouTodayReminderRow> OverdueFollowUps, int OverdueFollowUpsTotal,
    List<NeedsYouTodayPromiseRow> BrokenPromises, int BrokenPromisesTotal, string BrokenPromisesEmptyReason,
    List<NeedsYouTodayAmcRow> AmcRenewalsAtRisk, int AmcRenewalsAtRiskTotal,
    List<NeedsYouTodayApprovalRow> PendingApprovals, int PendingApprovalsTotal, bool CanDecideApprovals,
    List<RepRiskRow> RepRisk,
    List<NeedsYouTodayTaskRow> Tasks, int TasksTotal);

// One scheduled installment; Paid/Overdue are derived from allocating payments.
// Amount masked (null) without ViewAccountFinancials (invoice-money-masking).
public record InstallmentDto(Guid Id, int Seq, decimal? Amount, DateTime DueDate, bool Paid, bool Overdue);

// Create/replace a plan: split the balance into Count equal installments every
// IntervalDays starting at StartDate.
public record PlanInput(int? Count, int? IntervalDays, DateTime? StartDate);

// Invoice detail bundles its payments + collection timeline + any plan + its
// itemised lines (C2/C3 — the non-editable document is rendered from these).
// PaymentsCount is a server-side COUNT over the same InvoiceId — the screen's
// "Payments (N)" heading reads it instead of Payments.Count, so the heading
// stays correct even if Payments is ever paginated instead of loaded whole.
public record InvoiceDetailDto(
    InvoiceDto Invoice,
    List<PaymentDto> Payments,
    int PaymentsCount,
    List<InvoiceActivityDto> Activities,
    List<InstallmentDto> Installments,
    List<InvoiceLineItemDto> LineItems);

// The raise-invoice pick list (D1 union): a won lead with no invoice yet
// (Kind "lead", AmcTermId null), or an AMC term with no invoice yet (Kind
// "amc_renewal", AmcTermId set). `Id` is unique across both — the lead id for
// a lead row, the term id for an AMC row — so the client can key a list on
// it directly. `LeadId` is always the underlying deal, needed by
// InvoicesController.Create for either kind.
public record BillableLeadDto(
    Guid Id, string Name, string? Company, decimal EstimatedValue, DateTime? WonAt,
    string Kind, Guid LeadId, Guid? AmcTermId);

// Team-wide auto payment-reminder schedule. Offsets are days relative to an
// invoice's due date (negative = before due, 0 = on due, positive = overdue).
public record CollectionReminderConfigDto(bool Enabled, List<int> Offsets, int Hour, List<string> Channels, int EscalateDays);
public record CollectionReminderConfigInput(bool? Enabled, List<int>? Offsets, int? Hour, List<string>? Channels, int? EscalateDays)
{
    /// <summary>Null fields keep the current value. The one merge: PUT /collections/reminder-config and E13's per-workflow override.</summary>
    public CollectionReminderConfigDto ApplyTo(CollectionReminderConfigDto current) => new(
        Enabled ?? current.Enabled, Offsets ?? current.Offsets, Hour ?? current.Hour,
        Channels ?? current.Channels, EscalateDays ?? current.EscalateDays);
}

// --- Reports ---
// Leaderboard rows are snake_case (handled by the global policy).
// OpenValue/WonValue are NULL — not 0 — for a caller without lead_values.view.
// They used to be masked to 0m, which every client then drew as a real "$0":
// a rep saw the whole team sitting at $0 and read it as "nobody closed
// anything". Null is the only value a currency formatter cannot turn into a
// plausible figure, so the columns disappear instead. Ranking is unaffected —
// ReportsController.Rank already switches to WonCount/WinRate when values are
// masked, so medals never encode a hidden figure.
public record LeaderboardRowDto(
    Guid UserId,
    string? FullName,
    int OpenLeads,
    decimal? OpenValue,
    int WonCount,
    decimal? WonValue,
    int LostCount,
    double WinRate,
    int? AvgCycleDays,
    // True on the single "Unassigned" row: leads sitting in the routing queue
    // with no owner (C6). It is NOT a person — UserId is the all-zero sentinel
    // (Services/AggregateOwner.cs), there is no profile behind it, and it is
    // appended AFTER ranking so it can never take a medal. Clients must not
    // link it to a rep report and must not offer it in a per-rep picker.
    // Defaulted so every existing construction site stays a real person's row.
    bool IsUnassigned = false);

// Rep report is camelCase at the top level; sub-objects are snake_case.
public record ProfileLite(Guid Id, string? FullName, string? Email, string Role);
// Value is null for a masked caller on GET /reports/trends. GET /reports/rep/{id}
// still sends 0 here: that screen renders the literal word "Hidden" from its own
// permission check, so it never formats this field, and aligning the two was
// deliberately NOT done — a vanishing figure and a labelled one are different
// affordances (see to-do/numbers-audit-decisions.md, H1).
public record SourceBucket(string Source, int Count, decimal? Value);
public record RecentWon(Guid Id, string Name, string? Company, decimal EstimatedValue, DateTime UpdatedAt);

// Trends: time-series + source ROI + pipeline funnel (rep = own, manager = team).
// Count is always real. Value is null when the caller may not see the money
// behind the series — lead values for won/new-lead buckets, financials for the
// invoiced/collected pair. Every chart that plots Value must hide itself rather
// than draw a flat axis of zeros; the count series stands on its own.
public record MonthBucket(string Period, string Label, int Count, decimal? Value);
public record FunnelStage(string Status, string Label, int Count, decimal? Value);
// Cohort stage-conversion funnel (crm-delivery-plan.md B4) — see
// FunnelConversionService for what "reached" means and why. CohortSize is every
// lead CREATED in [CohortFrom, CohortTo), which is the funnel's true top of
// funnel — NOT the same number as Stages[0].Reached, since a lead can be created
// directly into a later bucket (bulk import, CSV, an inbound webhook) or never
// reach any funnel bucket at all (e.g. it goes straight to Lost). DataStartsAt is
// the earliest LeadStageEvent this caller can see; InsufficientData is true when
// the window can't be honestly measured yet (no events at all, or the whole
// window predates the first one) — Stages is empty in that case, not zeroed.
public record FunnelConversionDto(
    DateTime CohortFrom, DateTime CohortTo, int CohortSize,
    DateTime? DataStartsAt, bool InsufficientData,
    List<FunnelConversionStage> Stages);
// Reached is cumulative ("at least this far", see FunnelConversionService).
// ConversionRate is Reached / previous bucket's Reached; null on the first bucket
// and whenever the previous bucket's Reached is 0 (no rate is measurable, not 0%).
public record FunnelConversionStage(string Status, string Label, int Reached, double? ConversionRate);
// Per-stage flow on the org's OWN stage list, for the pipeline-stages admin screen —
// see StagePerformanceService for why this is a separate aggregate from the cohort
// funnel above and not a merge of it. InsufficientData/DataStartsAt carry exactly the
// same meaning they do on FunnelConversionDto, and Rows is empty (not zeroed) when set.
public record StagePerformanceDto(
    DateTime From, DateTime To,
    DateTime? DataStartsAt, bool InsufficientData,
    List<StagePerformanceRow> Rows);
// Entered/MovedOn are distinct lead counts, so AdvancedRate (MovedOn / Entered) can
// never exceed 1; it is null when nothing entered, which is not the same as 0%.
// AvgDaysHere is the mean over CLOSED spells only, excluding any spell bounded by a
// backfilled event whose timestamp isn't trustworthy — DurationSamples is how many
// spells actually went into that mean, which is why it is carried rather than implied
// by Entered. Null AvgDaysHere means nothing measurable, not "no time at all".
public record StagePerformanceRow(
    string Status, string Label, string Color,
    int Entered, int MovedOn, double? AdvancedRate, double? AvgDaysHere, int DurationSamples);
// Per-source volume + conversion: total leads, won count, and won value.
// Lost is carried alongside Won so the client can show a decided-only rate.
// Without it the only computable remainder is Leads - Won, which lumps lost
// deals together with everything still open — a live pipeline and a dead one
// then render identically.
public record SourcePerf(string Source, int Leads, int Won, int Lost, decimal? WonValue);
// Per-product volume + conversion, mirroring SourcePerf, from Lead.Products
// (a text[] of catalogue KEYS - Product is the item's NAME, ProductKey its key; a lead can carry more than one, so
// counts across products don't sum to total leads). EstimatedWonValue is
// summed from Lead.EstimatedValue on won leads carrying that product — this
// is estimated pipeline value, NOT billed revenue (Invoice has no
// per-product breakdown) — must be labeled as an estimate everywhere it's shown.
public record ProductPerf(string Product, int Leads, int Won, int Lost, decimal? EstimatedWonValue, string? ProductKey = null);
// Speed-to-lead distribution: number of leads whose first touch fell in a bucket.
public record ResponseBucket(string Bucket, int Count);

public class TrendsDto
{
    [JsonPropertyName("wonByMonth")] public List<MonthBucket> WonByMonth { get; set; } = new();
    [JsonPropertyName("leadsByMonth")] public List<MonthBucket> LeadsByMonth { get; set; } = new();
    // Invoiced (Invoice.Amount/IssuedAt) vs collected (Payment.Amount/PaidAt),
    // same buckets as won/leads-by-month. Zero-valued (not omitted) when the
    // caller lacks ViewFinancials — see ReportsController.Trends.
    [JsonPropertyName("invoicedByMonth")] public List<MonthBucket> InvoicedByMonth { get; set; } = new();
    [JsonPropertyName("collectedByMonth")] public List<MonthBucket> CollectedByMonth { get; set; } = new();
    [JsonPropertyName("bySource")] public List<SourceBucket> BySource { get; set; } = new();
    [JsonPropertyName("sourcePerf")] public List<SourcePerf> SourcePerf { get; set; } = new();
    [JsonPropertyName("productPerf")] public List<ProductPerf> ProductPerf { get; set; } = new();
    [JsonPropertyName("funnel")] public List<FunnelStage> Funnel { get; set; } = new();
    // The real, event-backed conversion funnel — see FunnelConversionDto. `Funnel`
    // above is kept as-is (current-position snapshot, unread by any UI) rather than
    // repurposed; this is the field trends.tsx renders.
    [JsonPropertyName("funnelConversion")] public FunnelConversionDto FunnelConversion { get; set; } = null!;
    [JsonPropertyName("responseBuckets")] public List<ResponseBucket> ResponseBuckets { get; set; } = new();
    [JsonPropertyName("responseMedianHours")] public double? ResponseMedianHours { get; set; }
    [JsonPropertyName("responseMeasured")] public int ResponseMeasured { get; set; }
    // C2 — the ONE win-rate definition (MeasureRegistry.Keys.WinRate: won /
    // (won + lost) over DECIDED deals), computed over the same cohort window
    // FunnelConversion already uses, so the KPI tile and the funnel panel below
    // it agree. Null, not 0, when nothing closed in that window — see
    // MeasureRegistry's own null-vs-zero rule.
    [JsonPropertyName("winRate")] public decimal? WinRate { get; set; }
}

public class RepReportDto
{
    [JsonPropertyName("user")] public ProfileLite User { get; set; } = null!;
    [JsonPropertyName("totalLeads")] public int TotalLeads { get; set; }
    [JsonPropertyName("openLeads")] public int OpenLeads { get; set; }
    [JsonPropertyName("openValue")] public decimal OpenValue { get; set; }
    [JsonPropertyName("wonLeads")] public int WonLeads { get; set; }
    [JsonPropertyName("wonValue")] public decimal WonValue { get; set; }
    [JsonPropertyName("lostLeads")] public int LostLeads { get; set; }
    [JsonPropertyName("winRate")] public double WinRate { get; set; }
    [JsonPropertyName("avgCycleDays")] public int? AvgCycleDays { get; set; }
    [JsonPropertyName("byStatus")] public List<StatusBucket> ByStatus { get; set; } = new();
    [JsonPropertyName("bySource")] public List<SourceBucket> BySource { get; set; } = new();
    [JsonPropertyName("recentWon")] public List<RecentWon> RecentWon { get; set; } = new();
}

// --- Estimated vs closed (GET /reports/estimated-vs-closed) ---
//
// One row per won/sold lead whose reported CLOSED value (ClosedValue, or
// EstimatedValue when it was never overridden — see Lead.WonValue) no longer
// matches what the pipeline ESTIMATED. Gated outright on lead_values.view
// (403, not masking — see ReportsController): unlike every other report in
// this file, there is no reading of this screen with the money hidden, so
// there is no masked shape to fall back to.
public record EstimatedVsClosedRowDto(
    Guid LeadId, string LeadName, string? AccountName, Guid? OwnerId, string? OwnerName,
    DateTime WonAt, decimal EstimatedValue, decimal ClosedValue, decimal Difference, decimal? PotentialValue = null,
    // Deal values per stage (owner 2026-11-12, decision 6): this deal's captured Proposal / Negotiation / Closed sets (null = none captured); the columns they fill are the report's StageValueFields.
    StageValueSetsDto? StageValues = null);

// Totals over the WHOLE filtered set (date range, team, owner, access scope) —
// never just the current page, and computed from the SAME filters regardless
// of `only_different`, so a reader who flips that toggle sees the identical
// headline numbers while only the row list below them changes. Raw figures
// only; no percentages or scores (owner rule: never invent what a number
// means on this caller's behalf).
public record EstimatedVsClosedTotalsDto(
    int WonCount, int DifferentCount, decimal TotalEstimated, decimal TotalClosed, decimal TotalDifference,
    decimal TotalPotential = 0m, int PotentialCount = 0);

// StageValueFields: the per-field breakdown columns (the stage value fields of the workflows of the deals on this page, labelled from the live custom field definitions).
public record EstimatedVsClosedReportDto(
    List<EstimatedVsClosedRowDto> Items, string? NextCursor, EstimatedVsClosedTotalsDto Totals, List<StageValueFieldDto>? StageValueFields = null);

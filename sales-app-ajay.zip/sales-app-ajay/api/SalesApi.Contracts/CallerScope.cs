namespace SalesApi.Services;

// WHO IS ASKING, and how far they can see — the caller's scope, expressed as a
// contract.
//
// MOVED HERE 2026-08-28, and the reason is the point of the whole migration.
// These two value objects were in the System layer, so every Process method that
// took one leaked a System type in its signature — which the Experience boundary
// caught the moment it tried to wrap CollectionProcess. A Process surface that
// names a System type is not layered; it just had not met a strict enough
// consumer yet.
//
// They belong in Contracts on the merits, not as a convenience: neither has any
// EF or HTTP in it. They are plain values describing the caller, which is
// exactly the sort of thing every layer legitimately shares. What does NOT come
// with them is how a caller is IDENTIFIED — the factories that read a
// ClaimsPrincipal and the database stay in System (RecordAccessContexts), where
// their dependencies live.
//
// Contrast with `Proposal`: an EF ENTITY must never become a contract, because
// then a schema change is a breaking client change. That is the coupling the
// layering exists to remove, so the quote path is fixed the other way round —
// Process maps the entity to a DTO rather than handing it out.
//
// The namespace stays `SalesApi.Services` so the move costs zero `using` edits.

public readonly record struct TeamScope(Guid[]? TeamIds, bool AllTeams)
{
    /// <summary>No team at all. The fail-closed value, and what an unhydrated principal reads as.</summary>
    public static readonly TeamScope None = new([], false);

    /// <summary>Every team in the org — the org admin and the platform admin.</summary>
    public static readonly TeamScope Everything = new([], true);

    public static TeamScope For(IEnumerable<Guid> teamIds, bool allTeams) =>
        allTeams ? Everything : new([.. teamIds.Distinct()], false);

    /// <summary>
    /// A record with no team is covered by NOBODY here — it reaches only its owner
    /// (checked separately in <see cref="RecordAccess"/>) and org admins (who hold
    /// <see cref="Everything"/>). This is fail-CLOSED, and it is a deliberate
    /// reversal of the previous default.
    ///
    /// It used to fail OPEN, on a stated premise: "after the backfill there are no
    /// NULLs, and failing closed would hide live records from the people who own
    /// them during a rollback window" (docs/teams-plan.md §2.5). **That premise has
    /// since expired.** Archiving the org default teams (2026-08-22) removed the
    /// last fallback in TeamService.ResolveLeadTeamAsync, so new records CAN once
    /// again land with no team — measured 2026-08-24: 2 leads of 3,135 and 2
    /// accounts of 120. A permanent hole is a different thing from a rollback
    /// window, and this one contradicted the guarantee the rest of the model makes,
    /// that a manager in one team cannot see another team's records.
    ///
    /// The owner clause in RecordAccess is why failing closed is safe: whoever owns
    /// a team-less record still sees it. Only OTHER non-admins lose sight of it,
    /// which is the point.
    /// </summary>
    public bool Covers(Guid? teamId) =>
        AllTeams || (teamId is { } id && TeamIds is { } ids && Array.IndexOf(ids, id) >= 0);
}

public readonly record struct RecordAccessContext(
    Guid UserId,
    bool IsOrgAdmin,
    bool HasManagerAccess,
    TeamScope Scope,
    string Visibility,
    // E12.2 - what this caller may see of each sensitive-data category. Null = not resolved (a legacy construction):
    // readers treat it as the access the old booleans describe. Travels here because this is the value every
    // Process method already receives, so no signature has to grow.
    SensitiveAccess? Sensitive = null,
    // Owner 2026-11-16: the caller holds invoices.manage AND financials.view. Resolved once where the context is built (RecordAccessContexts.For) and read ONLY by
    // RecordAccess.CanManageInvoice; it opens no lead or account write. Default false keeps every other construction unchanged.
    bool ManageInvoices = false,
    // Owner 2026-11-16: the caller holds tasks.assign. Resolved once where the context is built (RecordAccessContexts.For) and read ONLY by RecordAccess.CanAssignTasks.
    bool AssignTasks = false)
{
}

/// <summary>
/// The org's reporting calendar: which timezone "today" means, which day a week
/// starts on, and which days never send.
///
/// MOVED HERE 2026-08-28, for the same reason `RecordAccessContext` and
/// `TeamScope` are here, and found the same way — the Experience layer could
/// not name it, which meant every Process method taking one was leaking a
/// System type. It has no EF and no HTTP in it; it is a plain description of
/// how an org counts time, which every layer legitimately shares.
///
/// What did NOT come with it is `OrgCalendarService`, which RESOLVES one from
/// the database. Reading a row is System work; the shape of the answer is a
/// contract.
/// </summary>
public record CalendarDto(string TimeZoneId, int WeekStartDay, List<int> NonSendingDays);

using System.Text.Json;

// E10.3 — pricing-model contracts. A service (a CatalogItem of kind "service") can carry ONE pricing
// model: admin-defined INPUTS and RESULTS written as safe formulas (see PricingExpression in
// SalesApi.SystemApi/Services). The model is edited as a draft and published as immutable numbered
// versions, so a proposal keeps the maths it was made with. Wire contract: to-do/pricing-models-api.md.
//
// The namespace stays `SalesApi.Dtos` like every other contract file.

namespace SalesApi.Dtos;

/// <summary>
/// One thing the rep fills in. Type is "number", "money", "yes_no" (an optional add-on, 1 or 0), "choice" or "number_list".
/// An Optional input (not yes/no) may be left blank, e.g. a minimum commitment; formulas must then read it through coalesce().
/// Default is what a new proposal starts with and may be overridden per proposal.
///
/// The rest is additive and optional (every earlier model and published version reads unchanged):
/// Group - a section heading for the editor and the proposal form; no maths effect.
/// Choice (Type "choice") - Options, Multiple (pick several), DefaultValue (the price of a pick that has no Value of its own, and
/// the only price an ad-hoc pick not on the list can have), DefaultPick (the starting option key, or keys when Multiple: a string or
/// an array of strings) and FromDealField (a deal custom-field key whose list the proposal COPIES into this input when a version is
/// made, e.g. "erp_systems"). FromAccountField (E14.6) is its twin for the deal's ACCOUNT: on a choice input it names an account custom-field key
/// whose list is copied the same way; on a "number" or "money" input it names a numeric account field (a custom number, or the built-in
/// "child_count") whose value is copied, e.g. a per-entity price multiplied by the account's child accounts. As for FromDealField the
/// rep's own value for the input wins, and a blank source copies nothing. A choice reads as a NUMBER: single = the picked option's price; multiple = the sum of the picked options'
/// prices. Derived names read the rest: key_recurring (sum of the yearly figures), key_percent (sum of the percents), key_count.
/// List (Type "number_list") - one number per row. RowsKey is the key of the number input the row count must equal (pricing is blocked
/// when it does not); derived names key_sum and key_count. A list is read only through those two names or a banded block with Each.
/// </summary>
public record PricingInputDto(
    string Key, string Label, string Type, decimal? Default = null, bool Optional = false,
    string? Group = null, bool Multiple = false, List<PricingOptionDto>? Options = null, decimal? DefaultValue = null,
    JsonElement? DefaultPick = null, string? FromDealField = null, string? RowsKey = null, string? FromAccountField = null);

/// <summary>
/// One option of a choice input. Key is what is stored on a proposal (for an ERP, the ERP's name as the deal lists it; matching ignores
/// case). Value is its price (or the 0/1 of a mode switch); null falls back to the input's DefaultValue. Recurring is its yearly figure
/// (null = 0, which R7 allows). Percent is a percent-of-something figure (a support tier priced as a share of the platform fee); an option
/// with a Percent and no Value is priced 0 flat. Text is wording a document can print (an SLA).
/// </summary>
public record PricingOptionDto(string Key, string Label, decimal? Value = null, decimal? Recurring = null, string? Text = null, decimal? Percent = null);

/// <summary>
/// One calculated figure. Expr is an EXPRESSION TREE (JSON blocks: const, ref, op, group, higher_of,
/// lower_of, round_to, percent_of, if, coalesce — see PricingExpression in SalesApi.SystemApi/Services); admins build it
/// by picking names and operators, they never type a formula. Format is "money" (rounded to the cent,
/// half away from zero) or "number".
/// </summary>
public record PricingResultDto(string Key, string Label, JsonElement Expr, string Format = "money");

/// <summary>The editable body of a model — a draft, or a frozen version.</summary>
public record PricingModelContentDto(
    List<PricingInputDto> Inputs, List<PricingResultDto> Results, string? DealValueKey = null, string? Year1Key = null, string? Year2Key = null);

/// <summary>
/// Something wrong with the model. Code is stable (clients may switch on it); Message is prose.
/// Where points at the field ("inputs[1].key", "deal_value_key") or, for a problem inside a result's
/// expression, at the offending BLOCK: "results[2].expr" is the root block, "results[2].expr.left.args[1]" a
/// nested one (path segments: .left .right .expr .value .cond .then .else .args[n]).
/// </summary>
public record PricingIssueDto(string Code, string Message, string? Where = null);

public record PricingValidationDto(bool Valid, List<PricingIssueDto> Issues);

public record PricingResultValueDto(string Key, string Label, string Format, decimal Value);

/// <summary>
/// The outcome of running a model. Issues is empty on success. On the first error the run stops:
/// Results holds what was computed before it, and DealValue is null.
/// </summary>
public record PricingEvaluationDto(
    List<PricingResultValueDto> Results, decimal? DealValue, string? DealValueKey, List<PricingIssueDto> Issues,
    decimal? Year1 = null, decimal? Year2 = null, string? Year1Key = null, string? Year2Key = null)
{
    public bool Ok => Issues.Count == 0;
}

/// <summary>GET /catalog-items/{id}/pricing-model — the draft plus a pointer at what is published.</summary>
public record PricingModelDto(
    Guid? Id, Guid CatalogItemId, PricingModelContentDto Draft, DateTime? DraftUpdatedAt, Guid? DraftUpdatedById,
    int? PublishedVersion, DateTime? PublishedAt,
    // True when the draft differs from the latest published version (or nothing is published yet and the draft has content).
    bool HasUnpublishedChanges);

public record PricingModelVersionSummaryDto(
    int Version, DateTime PublishedAt, Guid? PublishedById, int InputCount, int ResultCount, string DealValueKey);

public record PricingModelVersionDto(
    Guid Id, Guid CatalogItemId, int Version, DateTime PublishedAt, Guid? PublishedById, PricingModelContentDto Content);

/// <summary>
/// Body of PUT .../pricing-model (a draft save) and POST .../validate. Saving never refuses for formula
/// errors — a half-finished model is a normal thing to save — it returns them alongside.
/// </summary>
public record PricingModelDraftInput(
    List<PricingInputDto>? Inputs, List<PricingResultDto>? Results, string? DealValueKey = null, string? Year1Key = null, string? Year2Key = null);

/// <summary>Draft save response: the stored draft and what is currently wrong with it.</summary>
public record PricingModelSavedDto(PricingModelDto Model, PricingValidationDto Validation);

/// <summary>
/// POST .../preview. Evaluates Content when given, else the stored version Version when given, else the
/// stored draft. Inputs are the values to try: a number, a numeric string, or true/false for yes/no.
/// </summary>
/// <remarks>
/// Deal and account fields a model reads come from DealId (the caller must be able to see that deal) and/or the
/// explicit DealValues/AccountValues maps (key to number or null), which win over the deal. A key with no value
/// is blank.
/// </remarks>
public record PricingPreviewInput(
    PricingModelDraftInput? Content, int? Version, Dictionary<string, JsonElement>? Inputs,
    Guid? DealId = null, Dictionary<string, JsonElement>? DealValues = null, Dictionary<string, JsonElement>? AccountValues = null);

/// <summary>POST .../versions/{n}/evaluate. Same field rules as the preview.</summary>
public record PricingEvaluateInput(
    Dictionary<string, JsonElement>? Inputs, Guid? DealId = null,
    Dictionary<string, JsonElement>? DealValues = null, Dictionary<string, JsonElement>? AccountValues = null);

/// <summary>
/// One name the builder can pick. Scope is "input", "result", "deal" or "account"; Type is "number", "money"
/// or "yes_no"; Optional means it can be blank (so it must sit inside a coalesce block).
/// </summary>
public record PricingFieldDto(string Scope, string Key, string Label, string Type, bool Optional);

/// <summary>GET .../fields — everything a result's expression may refer to.</summary>
public record PricingFieldsDto(
    List<PricingFieldDto> Inputs, List<PricingFieldDto> Results, List<PricingFieldDto> Deal, List<PricingFieldDto> Account);

/// <summary>
/// GET /settings/payment-workflow/basis-keys - one pricing result key a payment milestone can take its share of: the key and label as
/// the LIVE (newest published) version of an active service's pricing model names it. A key several services share appears once
/// (their results add up on the quote); Services names the services that carry it.
/// </summary>
public record PricingResultKeyDto(string Key, string Label, string Format, List<string> Services);

/// <summary>POST .../versions/{n}/restore. Without ReplaceDraft the restore refuses to overwrite unsaved draft work.</summary>
public record PricingRestoreInput(bool? ReplaceDraft);

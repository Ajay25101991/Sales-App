// The Approvals contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Approval requests (reassignment / discount / reopen sign-off) ---
public record ApprovalDto(
    Guid Id, Guid RequesterId, string? RequesterName, string Type, Guid LeadId, string? LeadName,
    decimal? Amount, string? Reason, string Status, Guid? DecidedById, string? DecidedByName,
    DateTime? DecidedAt, string? DecisionNote, DateTime CreatedAt,
    // What the approver needs in order to DECIDE, rather than having to open the
    // lead to find it: what the deal is worth, and where it has got to. A
    // discount of $4,870 means nothing without the value it comes off.
    decimal? LeadValue = null,
    string? LeadStatus = null,
    string? LeadCompany = null,
    // H6 — only set on Type == "reopen": the OPEN stage the rep wants the lead
    // moved back to. Decide() re-checks this is still a real, open destination at
    // decision time rather than trusting whatever was true when the request was
    // raised — the pipeline can be reshaped in between.
    string? TargetStatus = null,
    // D5 — the lead's own playbook, alongside LeadStatus, so a client can
    // resolve this request's phase/label against the lead's OWN stage list
    // instead of the org's (an approver otherwise reads a playbook-only status
    // like "proposal_sent" as an unrecognised raw key). Wire key: lead_playbook_id.
    Guid? LeadPlaybookId = null,
    // Q13 - only on a discount request tied to a quote (ApprovalRequest.RecordType = "quote").
    Guid? QuoteId = null,
    // Channel partners: a request that names a record other than a lead or quote (type partner_payout -> record_type "partner_payout", record_id = the payout).
    string? RecordType = null,
    Guid? RecordId = null,
    // Parked item 7: on a pending gate_exception to a Won stage that asks for deal values - the REQUIRED values still missing (Kind "win_value"), which the approver enters on decide (win_values).
    List<StageRequirementDto>? MissingWinValues = null);
// QuoteId (Q13): the quote a discount request is for, so an approval is tied to ONE quote.
public record ApprovalInput(string? Type, Guid? LeadId, decimal? Amount, string? Reason, string? TargetStatus = null, Guid? QuoteId = null);
public record ApprovalDecisionInput(bool? Approve, string? Note, WinValuesInput? WinValues = null);

// H6 — the org-level half of the reopen policy: what happens to won_at/lost_at
// when a deal is reopened and later re-closed. Both options retain the ORIGINAL
// close date in Lead.WonAtOriginal/LostAtOriginal regardless, so the choice
// stays reversible — see StageService.SyncCloseDates. Named ReopenCloseDatePolicy
// rather than the shorter CloseDatePolicy so it can never collide with the DTO
// property of that name right below it.
public static class ReopenCloseDatePolicy
{
    /// <summary>Re-closing restores the date the deal first closed on.</summary>
    public const string KeepOriginal = "keep_original";
    /// <summary>Re-closing stamps the moment it re-closed.</summary>
    public const string Restamp = "restamp";
    public static readonly string[] All = [KeepOriginal, Restamp];
    public static bool IsValid(string? v) => v is not null && All.Contains(v);
}
public record ReopenSettingsDto(string CloseDatePolicy = ReopenCloseDatePolicy.KeepOriginal);
public record ReopenSettingsInput(string? CloseDatePolicy);

/// <summary>
/// Bug 2 (owner 2026-10-26) - which deal custom fields an accepted GENERATED proposal's Year 1 / Year 2 totals are written to
/// (GET/PUT /settings/proposal-fee-fields). Each is a lead custom-field key of a number or currency field; null = unmapped (nothing is written).
/// </summary>
public record ProposalFeeFieldsDto(string? Year1Key = null, string? Year2Key = null);
public record ProposalFeeFieldsInput(string? Year1Key, string? Year2Key);

// Bulk action over selected leads: action = "assign" | "stage" | "delete".
// Accounts rework: leads also take "tag_add" | "tag_remove" (TagId); skips come back with their reasons (additive tail).
// Exactly ONE of Ids (ticked rows) or Match ("select all N matching") is sent; both or neither is a 400.
public record BulkInput(List<Guid>? Ids, string? Action, Guid? OwnerId, string? Status, Guid? TagId = null, LeadMatchInput? Match = null);

/// <summary>"Select all N matching" on POST /leads/bulk: the list endpoint's own params, same shape and the SAME wire names as GET /leads
/// (camelCase where the query string is: quietSince, tagIds, ...). Resolved server-side to ids through the filtered query the list and
/// GET /leads/count run, inside what the caller may see. <c>Filters</c> is the JSON string the <c>filters</c> query parameter carries.
/// Paging and sorting are not part of a match.</summary>
public record LeadMatchInput(
    string? Status = null,
    string? Search = null,
    string? Owner = null,
    string? Source = null,
    string? Product = null,
    bool? Overdue = null,
    bool? Idle = null,
    bool? Mine = null,
    double? Similarity = null,
    string? Custom = null,
    [property: System.Text.Json.Serialization.JsonPropertyName("quietSince")] DateTime? QuietSince = null,
    [property: System.Text.Json.Serialization.JsonPropertyName("quietWindowDays")] int? QuietWindowDays = null,
    [property: System.Text.Json.Serialization.JsonPropertyName("tagIds")] string? TagIds = null,
    [property: System.Text.Json.Serialization.JsonPropertyName("teamId")] Guid? TeamId = null,
    [property: System.Text.Json.Serialization.JsonPropertyName("dealType")] string? DealType = null,
    string? Filters = null);
public record BulkResult(int Updated, int Skipped, List<BulkSkipDto>? Skips = null);

// --- Approval chains (E2.6 slice 9, to-do/e2-automation-design.md §8) ---
// Layered ABOVE the ApprovalDto/ApprovalInput/ApprovalDecisionInput family
// above, not replacing it: a chain routes a request's decide flow through
// its own ordered steps instead of the blanket DecideApprovals/ViewFinancials
// gate. See ApprovalChainProcess (SalesApi.ProcessApi) for the resolution and
// per-step decision rules.

// ApproverUserIds/ApproverUserNames — design §17 item 12's any_of_users kind:
// the named group for this step, set only when ApproverKind is "any_of_users".
// Empty (never null) for the other two kinds, same "additive, no guard needed"
// convention as ApprovalChainInstanceDto's own CurrentApproverIds.
public record ApprovalChainStepDto(
    Guid Id, int Order, string ApproverKind, Guid? ApproverUserId, string? ApproverUserName,
    List<Guid> ApproverUserIds, List<string> ApproverUserNames);

public record ApprovalChainDto(
    Guid Id, string Name, int Priority, bool Enabled,
    System.Text.Json.JsonElement Condition, List<string> RequestTypes,
    List<ApprovalChainStepDto> Steps, DateTime CreatedAt);

public record ApprovalChainStepInput(string? ApproverKind, Guid? ApproverUserId, List<Guid>? ApproverUserIds = null);

public record ApprovalChainInput(
    string? Name, System.Text.Json.JsonElement? Condition, List<string>? RequestTypes,
    List<ApprovalChainStepInput>? Steps, bool? Enabled);

public record ApprovalChainReorderInput(List<Guid>? Ids);

public record ApprovalChainStepDecisionDto(
    int Step, Guid DecidedById, string? DecidedByName,
    Guid? DelegatedFromId, string? DelegatedFromName,
    string Decision, string? Note, DateTime DecidedAt);

// Compat/slice-17 follow-up — the resolved current-step approver(s), so a
// client can say "Waiting on Sara Ahmed" instead of a generic fallback.
// Additive: empty once the instance is no longer pending (nobody is
// currently waited on), or if the step resolves to nobody (an owner-less
// lead's manager_of_owner step) — never null, so a client can iterate
// without a guard.
public record ApprovalChainInstanceDto(
    Guid Id, Guid ChainId, string ChainName, Guid ApprovalRequestId,
    int CurrentStep, int TotalSteps, string Status,
    DateTime CreatedAt, DateTime? CompletedAt,
    List<ApprovalChainStepDecisionDto> Decisions,
    List<Guid>? CurrentApproverIds = null,
    List<string>? CurrentApproverNames = null);

// bool? Approve mirrors ApprovalDecisionInput's own shape. DelegatedFromId is
// E2.0 decision 14's delegation attribution (design §8) — see
// ApprovalChainProcess.DecideStepAsync's own comment for exactly how a
// delegated decision is authorized in this slice.
public record ApprovalChainStepDecisionInput(bool? Approve, string? Note, Guid? DelegatedFromId);

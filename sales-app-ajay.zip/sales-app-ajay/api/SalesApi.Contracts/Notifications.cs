// The Notifications contracts: one person's own settings screen, plus their
// in-app inbox. Moved out of Controllers/NotificationsController.cs for the
// API-led migration (step 8, notifications domain) — none of these name a
// System type, so they belong here like every other domain's plain wire
// records.

namespace SalesApi.Dtos;

public record NotificationSettingsDto(
    bool PushEnabled, bool InAppEnabled, bool EmailEnabled,
    string Preset, string? QuietFrom, string? QuietTo, int UtcOffsetMinutes,
    // The org/team calendar's own timezone + current UTC offset, resolved via
    // OrgCalendarService — what the quiet-hours window actually runs against,
    // surfaced so "your local time" stops being ambiguous (item 3). Folded
    // into the calendar rather than left as a fifth, independently-edited
    // notion of local time: UtcOffsetMinutes above is legacy/manual and still
    // stored, but the screen should show and default from THIS.
    string CalendarTimeZoneId, int CalendarUtcOffsetMinutes,
    List<NotificationPreferenceDto> Events,
    List<TeamNotificationPreferenceDto> Teams);

public record NotificationPreferenceDto(
    string EventType, string Label, string Class, bool EmailDefault,
    bool? Push, bool? InApp, bool? Email);

public record TeamNotificationPreferenceDto(Guid TeamId, string TeamName, string Scope);

// Every field optional: the screen PATCHes the one switch that moved rather than
// posting the whole object back, so an omitted field means "leave it alone".
public record NotificationSettingsInput(
    bool? PushEnabled, bool? InAppEnabled, bool? EmailEnabled,
    string? Preset, string? QuietFrom, string? QuietTo, int? UtcOffsetMinutes);

public record NotificationPreferenceInput(string? EventType, bool? Push, bool? InApp, bool? Email);

public record TeamNotificationPreferenceInput(Guid? TeamId, string? Scope);

/// <summary>One row of the in-app inbox. Was an anonymous object on the
/// controller; typed here with the SAME property names so the serialized
/// wire shape (JsonNamingPolicy.SnakeCaseLower) is unchanged — see
/// NotificationsWireShapeTests.</summary>
public record AppNotificationDto(
    Guid Id, string EventType, string Title, string Body,
    Guid? LeadId, Guid? InvoiceId, DateTime CreatedAt, DateTime? ReadAt, string? Link = null);

// The Organizations contracts (API-led migration, step 8).
//
// OrganizationDto / OrganizationInput / OrganizationOffboardInput already
// live in Auth.cs (used by both AdminController and OrganizationsController)
// and are not repeated here. These two are new: plain mappings of the two
// System-layer records the offboarding flow already returned
// (OffboardingBackupArtifact, OrganizationOffboardingResult in
// SystemApi/Services/OrganizationOffboardingService.cs) — both were already
// all-plain-data (paths, hashes, counts), so the move is a rename with the
// exact same fields, done so Process's public surface never names a System
// type (LayerBoundaryTests).

namespace SalesApi.Dtos;

public record OffboardingBackupArtifactDto(string Path, string Filename, string Sha256, string Receipt);

public record OrganizationOffboardResultDto(
    Guid OrganizationId,
    string OrganizationName,
    string BackupSha256,
    IReadOnlyDictionary<string, int> Deleted,
    int StorageObjectsDeleted,
    IReadOnlyList<string> StorageCleanupErrors);

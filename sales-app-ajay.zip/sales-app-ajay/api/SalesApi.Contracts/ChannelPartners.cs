using System.Text.Json;

// Channel-partner management, Phase 1 (design: to-do/partner-management-design.md, section 7 owner decisions 2026-10-19).
//
// NAMING. "Partner API" in this codebase (PartnerApiController, ApiKeyScopes) means an INTEGRATION KEY. This module is the
// channel programme - referrers, resellers, integrators - and is called "channel partners" everywhere it could be confused.
//
// CONFIDENTIAL. Everything commercial in here (plan rates, ledger amounts, statements, payouts, payout bank details) sits behind
// the sensitive-data category `partner_commercials` (payout bank details behind `id_bank`). None of it is read by the document field
// reader, so a partner's margin can never print on a client document.
//
// The namespace stays `SalesApi.Dtos` like every other contract file.

namespace SalesApi.Dtos;

/// <summary>The fixed vocabularies. Plain strings on the wire; one place so a writer and a validator cannot disagree.</summary>
public static class ChannelPartnerVocab
{
    // ---- partner profile ----
    public static class Status
    {
        public const string Prospect = "prospect";
        public const string Active = "active";
        public const string Suspended = "suspended";
        public const string Terminated = "terminated";
        public static readonly string[] All = [Prospect, Active, Suspended, Terminated];
        /// <summary>Only these may be NEWLY attributed to a deal.</summary>
        public static bool CanAttribute(string? status) => status is Prospect or Active;
    }

    /// <summary>Org-setting defaults (design section 1.2 keys). The org's own list replaces these - a partner's Type is validated against the setting.</summary>
    public static readonly string[] DefaultTypes =
    [
        "referral_flat", "referral_percent", "revenue_share", "reseller", "reseller_bulk", "system_integrator",
        "fsp", "tri_party_mou", "white_label", "distributor", "alliance", "affiliate",
    ];

    /// <summary>The partner types that RESELL to their own clients (buy from us, resell): the lead form offers the reseller role only for these.</summary>
    public static bool IsResellerType(string? type) => type is "reseller" or "reseller_bulk";

    public static readonly string[] DefaultTiers = ["standard", "silver", "gold"];

    /// <summary>Bulk upload (owner 2026-10-20): the type a partner gets from the partners file until someone sets it. A SYSTEM value - always in the types list, labelled "To be set".</summary>
    public const string ToBeSetType = "to_be_set";

    /// <summary>Phase 3: levels in a distributor chain (a distributor and its sub-resellers = 2). An org setting; this is only its default.</summary>
    public const int DefaultMaxChannelDepth = 2;
    public const int MaxChannelDepthLimit = 5;
    /// <summary>The AccountRelationship type that links a distributor (From) to a sub-reseller (To). One of the org's defaults already.</summary>
    public const string DistributorRelationship = "distributor_for";

    // ---- deal attribution ----
    public static class Role
    {
        public const string Referrer = "referrer";
        public const string TriParty = "tri_party";
        public const string Reseller = "reseller";
        public const string Fsp = "fsp";
        public const string Integrator = "integrator";
        public const string Affiliate = "affiliate";
        public const string CoSell = "co_sell";
        /// <summary>Phase 3: the override earner above a sub-reseller (an AccountRelationship distributor_for edge). Attached by the Process layer, never typed by a rep.</summary>
        public const string Distributor = "distributor";
        public static readonly string[] All = [Referrer, TriParty, Reseller, Fsp, Integrator, Affiliate, CoSell, Distributor];
        public static bool IsValid(string? v) => v is not null && Array.IndexOf(All, v) >= 0;
    }

    public static class Origin
    {
        public const string Sourced = "sourced";
        public const string Assigned = "assigned";
        public static readonly string[] All = [Sourced, Assigned];
    }

    /// <summary>Where a deal partner's effective rule came from: the published plan, the partner's own override, or a per-deal override.</summary>
    public static class RuleScope
    {
        public const string Plan = "plan";
        public const string Partner = "partner_override";
        public const string Deal = "deal_override";
        public static readonly string[] All = [Plan, Partner, Deal];
    }

    // ---- plans ----
    public static class RateKind
    {
        /// <summary>The "legacy, no terms" plan: attribution without an entitlement.</summary>
        public const string None = "none";
        public const string Flat = "flat";
        public const string Percent = "percent";
        /// <summary>A formula over the same PricingExpression engine as pricing models (tiers, bands, caps).</summary>
        public const string Expression = "expression";
        public static readonly string[] All = [None, Flat, Percent, Expression];
    }

    public static class Trigger
    {
        /// <summary>Earned as money is collected: a percent plan accrues on every collected payment (cumulative, to the cent).</summary>
        public const string EachCollected = "each_collected";
        /// <summary>Earned from the first collected payment: a flat plan pays once collected money exists; a percent plan counts the FIRST invoice only.</summary>
        public const string FirstCollected = "first_collected";
        /// <summary>
        /// Phase 3 (distributor, model T2): earned as the sub-reseller's wins DRAW stock from the distributor's lots - the base is the wholesale value drawn
        /// (cumulative, falls on a return), not collected money. Same cumulative method, same ledger, same clawback window.
        /// </summary>
        public const string Drawdown = "drawdown";
        public static readonly string[] All = [EachCollected, FirstCollected, Drawdown];
    }

    public static class AppliesTo
    {
        /// <summary>The deal's own invoices (DealBilling.LiveInvoicesOf: not void, not an AMC renewal).</summary>
        public const string Deal = "deal";
        /// <summary>Every non-void invoice of the deal, renewals included.</summary>
        public const string All = "all";
        public static readonly string[] Values = [Deal, All];
    }

    /// <summary>F3 (owner 2026-10-19): what a "first only" percent plan counts.</summary>
    public static class FirstOnlyBasis
    {
        /// <summary>Money collected on the deal's first invoice.</summary>
        public const string FirstInvoice = "first_invoice";
        /// <summary>The first payment received on the deal.</summary>
        public const string FirstPayment = "first_payment";
        /// <summary>Everything collected in the first 12 months from the client's onboarding (the deal's win date).</summary>
        public const string First12Months = "first_12_months";
        public static readonly string[] All = [FirstInvoice, FirstPayment, First12Months];
    }

    /// <summary>F6 (owner 2026-10-19): how recent earnings are held.</summary>
    public static class Settlement
    {
        public const string CarryNegative = "carry_negative";
        public const string HoldDays = "hold_days";
        public static readonly string[] All = [CarryNegative, HoldDays];
    }

    public static class StockExpiryPolicy
    {
        /// <summary>No refund and no credit: the unused units lapse and our revenue stands.</summary>
        public const string Forfeit = "forfeit";
        /// <summary>The unused value becomes a stock credit the partner can spend on a later purchase (recorded, not paid).</summary>
        public const string Credit = "credit";
        /// <summary>The unused value is due back to the partner: a manager task is raised; the CRM pays nobody.</summary>
        public const string Refund = "refund";
        public static readonly string[] All = [Forfeit, Credit, Refund];
    }

    /// <summary>Phase 3: when a bulk pack starts its expiry clock (a plan setting).</summary>
    public static class StockActivatesOn
    {
        public const string Signed = "signed";
        public const string Invoiced = "invoiced";
        public const string Paid = "paid";
        public static readonly string[] All = [Signed, Invoiced, Paid];
    }

    /// <summary>
    /// Phase 3: the kinds of a stock movement. Append-only; the balance of a lot is SUM(Delta). Value is signed ex-VAT money where the kind carries one
    /// (drawdown +, return -, expiry +, credit_issued +, credit_applied -).
    /// </summary>
    public static class StockKind
    {
        public const string Drawdown = "drawdown";
        public const string Return = "return";
        public const string Expiry = "expiry";
        public const string Adjustment = "adjustment";
        public const string Override = "override";
        public const string CreditIssued = "credit_issued";
        public const string CreditApplied = "credit_applied";
        public static readonly string[] All = [Drawdown, Return, Expiry, Adjustment, Override, CreditIssued, CreditApplied];
        /// <summary>The kinds that make up what a lot has SUPPLIED to end-client deals (drawn net of returns).</summary>
        public static bool IsDraw(string kind) => kind is Drawdown or Return;
    }

    /// <summary>What a revenue figure rests on (PartnerRevenueView).</summary>
    public static class RevenueKind
    {
        /// <summary>No partner sold this deal: our revenue is the deal's own value.</summary>
        public const string Own = "own";
        /// <summary>Resold from the partner's bulk stock: our revenue is the wholesale value drawn (an ALLOCATION of the pack purchase, not new revenue).</summary>
        public const string Drawn = "drawn";
        /// <summary>The partner buys per deal and bills its client: our revenue is the wholesale amount recorded on the deal partner.</summary>
        public const string Expected = "expected";
        /// <summary>Phase 2: a financial-service partner bills the end client. The END-CLIENT deal counts as any deal at its end-client price; the FSP's share is back-calculated beside it.</summary>
        public const string BilledByPartner = "billed_by_partner";
        /// <summary>Phase 2: the deal on the FSP's account our platform-fee invoice is raised on. Excluded from revenue totals (never counted twice); kept for collections.</summary>
        public const string BillingDeal = "billing_deal";
    }

    // ---- ledger ----
    public static class Direction
    {
        public const string Payable = "payable";
        public const string Receivable = "receivable";
        public const string Cost = "cost";
        public static readonly string[] All = [Payable, Receivable, Cost];
        public static bool IsValid(string? v) => v is not null && Array.IndexOf(All, v) >= 0;
        /// <summary>The directions a payout can settle: we pay the partner a share (payable) or we pay an SI's invoice (cost). A receivable is the partner paying US and never joins a payout.</summary>
        public static bool IsPayable(string? v) => v is Payable or Cost;
    }

    // ---- Phase 2 (owner decisions 2026-10-19, section 10 of the design) ----

    /// <summary>
    /// Registration is a RECORD (owner: "none - just record"): a date, who recorded it, a status and notes. No timer ever moves it, nothing is blocked by it, no money
    /// reads it. A person sets every status.
    /// </summary>
    public static class Registration
    {
        public const string None = "none";
        public const string Registered = "registered";
        public const string Accepted = "accepted";
        public const string Declined = "declined";
        public static readonly string[] All = [None, Registered, Accepted, Declined];
        public static readonly string[] Settable = [Registered, Accepted, Declined];
        /// <summary>A registration that protects the prospect from other partners' claims (what a rep without partner commercials is told: "protected by a partner registration").</summary>
        public static bool Protects(string? status) => status is Registered or Accepted;
    }

    /// <summary>A referral for a client already in the pipeline is FLAGGED on its deal partner row and decided there by the deal owner or partners.manage.</summary>
    public static class PipelineDecision
    {
        public const string Pending = "pending";
        public const string Accepted = "accepted";
        public const string Declined = "declined";
    }

    /// <summary>Two partners claiming one client: ALWAYS a manager decision (owner 2.4). The decision is a record, not a state machine: the manager sets each registration status separately.</summary>
    public static class ConflictStatus
    {
        public const string Open = "open";
        public const string Decided = "decided";
        public static readonly string[] All = [Open, Decided];
    }

    public static class ConflictDecision
    {
        public const string NewClaim = "new_claim";
        public const string ExistingClaim = "existing_claim";
        public const string Both = "both";
        public static readonly string[] All = [NewClaim, ExistingClaim, Both];
    }

    /// <summary>How the matcher found the other claim.</summary>
    public static class MatchedBy
    {
        public const string SameAccount = "same_account";
        public const string CompanyName = "company_name";
        public const string EmailDomain = "email_domain";
    }

    /// <summary>Owner 2.5: SI billing is per plan. we_bill_pay_si = we bill the client and pay the SI (accepting a milestone is a cost payable to the SI); si_bills_client = milestones are recorded and no money is.</summary>
    public static class SiBilling
    {
        public const string WeBillPaySi = "we_bill_pay_si";
        public const string SiBillsClient = "si_bills_client";
        public static readonly string[] All = [WeBillPaySi, SiBillsClient];
    }

    public static class MilestoneStatus
    {
        public const string Planned = "planned";
        public const string Accepted = "accepted";
        public const string Rejected = "rejected";
        public static readonly string[] All = [Planned, Accepted, Rejected];
    }

    /// <summary>Derived on read from the linked invoice and the dates - never stored, so nothing needs a sweep to turn "overdue" on.</summary>
    public static class RemittanceStatus
    {
        public const string Expected = "expected";
        public const string Invoiced = "invoiced";
        public const string Remitted = "remitted";
        public const string Overdue = "overdue";
        public const string Waived = "waived";
    }

    public static class EntryKind
    {
        public const string Accrual = "accrual";
        public const string Clawback = "clawback";
        public const string Adjustment = "adjustment";
        public const string Payout = "payout";
        public static readonly string[] All = [Accrual, Clawback, Adjustment, Payout];
        /// <summary>The kinds that make up what the partner has EARNED (everything but the settling payout).</summary>
        public static bool IsEarning(string kind) => kind is Accrual or Clawback or Adjustment;
    }

    public static class DecisionStatus
    {
        public const string Pending = "pending";
        public const string Approved = "approved";
        public const string Waived = "waived";
        public const string Cancelled = "cancelled";
    }

    // ---- statements and payouts ----
    public static class StatementStatus
    {
        /// <summary>Computed now and not stored (no id, no number).</summary>
        public const string Preview = "preview";
        public const string Issued = "issued";
    }

    public static class PayoutStatus
    {
        public const string Draft = "draft";
        public const string Submitted = "submitted";
        public const string Approved = "approved";
        public const string Rejected = "rejected";
        public const string Paid = "paid";
        public const string Cancelled = "cancelled";
        /// <summary>Statuses whose items still hold their ledger entries (the entries cannot join another payout).</summary>
        public static bool HoldsEntries(string status) => status is Draft or Submitted or Approved or Paid;
    }

    // ---- org settings (Q17 default, Q18) ----
    public static class RepCredit
    {
        /// <summary>The rep keeps full target / leaderboard credit for a partner-sourced deal; the partner is informational.</summary>
        public const string Full = "full";
        /// <summary>A partner-sourced deal does not count toward the rep's target.</summary>
        public const string None = "none";
        public static readonly string[] All = [Full, None];
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Plans. The wire shape is PartnerPlanContentDto; the draft lives on the plan and every published version is a frozen row,
// exactly like a pricing model (PricingModel / PricingModelVersion).
// ---------------------------------------------------------------------------------------------------------------------

/// <summary>
/// The rule of one plan (draft or version). Percent is a PERCENT (10 = 10%). A cap is on the CUMULATIVE entitlement per deal partner.
/// For RateKind "expression" the formula is a PricingModelContentDto whose inputs may only be collected_to_date, deal_base and
/// term_number and which must define a result keyed "target" (the cumulative entitlement); it runs on the existing PricingExpression engine.
/// </summary>
public record PartnerPlanContentDto(
    string RateKind,
    decimal? Percent = null,
    decimal? FlatAmount = null,
    string Trigger = ChannelPartnerVocab.Trigger.EachCollected,
    string AppliesTo = ChannelPartnerVocab.AppliesTo.Deal,
    decimal? Cap = null,
    int ClawbackWindowDays = 90,
    int PaymentTermsDays = 90,
    string? StockExpiryPolicy = null,
    PricingModelContentDto? Expression = null,
    // F3: for a percent plan on trigger first_collected - what "first only" means (first_invoice | first_payment | first_12_months).
    string FirstOnlyBasis = ChannelPartnerVocab.FirstOnlyBasis.FirstInvoice,
    // F6: carry_negative = payable at once, later clawbacks net into the next payout; hold_days = payable only HoldDays after earned.
    string Settlement = ChannelPartnerVocab.Settlement.CarryNegative,
    int HoldDays = 0,
    // ---- Phase 2 (all additive; the default of each is today's behaviour, so every published version keeps evaluating identically) ----
    // payable = a share of client money we owe the partner (Phase 1). cost = an SI's fee for work we accept (milestones). receivable = an FSP that bills the end client and
    // owes US a platform fee. A cost or receivable plan has no RateKind (Clean pins it to "none"): nothing is accrued from the end client's payments.
    string Direction = ChannelPartnerVocab.Direction.Payable,
    // Cost plans (owner 2.5, per plan).
    string? SiBilling = null,
    List<PartnerPlanMilestoneDto>? Milestones = null,
    // Receivable plans (FSP): the partner bills the end client (our expected invoices on that deal are suppressed), remits our fee N days after it collects, and the
    // agreement names late interest at prime + a margin (displayed, NEVER charged).
    bool PartnerBillsEndClient = false,
    int RemitDaysAfterCollection = 30,
    decimal? OverdueInterestMarginPct = null,
    // ---- Phase 3 (stock). Every property is optional with a default equal to today's behaviour, so an old published version evaluates identically. ----
    // Months a bulk pack lasts, counted from StockActivatesOn (null = it never expires). StockExpiryPolicy (above) says what happens to the unused rest.
    int? StockExpiryMonths = null,
    string StockActivatesOn = ChannelPartnerVocab.StockActivatesOn.Signed,
    // The proposal input (e.g. "entities") a reseller deal's drawdown units are read from; null = units are typed on the deal partner.
    string? DrawdownUnitsInput = null,
    // Owner 3.3: each renewal term draws the units again (default yes); false = only the first term draws.
    bool RenewalDrawsStock = true,
    // Distributor model T2: a sub-reseller on this plan draws from its parent distributor's lots when it has none of its own.
    bool SubResellersDrawFromParent = false);

/// <summary>A milestone template on an SI plan: copied onto a deal partner when the SI is attached (the amount is then frozen there, the PricingModelVersion rule).</summary>
public record PartnerPlanMilestoneDto(string Label, decimal Amount);

public record PartnerPlanDto(
    Guid Id, string Key, string Name, string? PartnerType, bool IsSystem, DateTime? ArchivedAt,
    PartnerPlanContentDto Draft, DateTime? DraftUpdatedAt, int? LatestVersion, DateTime? LatestPublishedAt, bool HasUnpublishedChanges);

public record PartnerPlanVersionDto(Guid Id, Guid PlanId, int Version, DateTime PublishedAt, Guid? PublishedById, PartnerPlanContentDto Content);

public record PartnerPlanSavedDto(PartnerPlanDto Plan, PricingValidationDto Validation);

public record PartnerPlanCreateInput(string? Name, string? PartnerType, PartnerPlanContentDto? Content);

public record PartnerPlanDraftInput(string? Name, string? PartnerType, PartnerPlanContentDto? Content);

/// <summary>A per-partner override of a plan: any field left null follows the plan. A Reason is mandatory (the LoyaltyAccountRule rule).</summary>
public record PartnerPlanAssignmentInput(
    Guid? PlanId, decimal? Percent, decimal? FlatAmount, decimal? Cap, int? ClawbackWindowDays, int? PaymentTermsDays,
    DateTime? EffectiveFrom, string? Reason);

public record PartnerPlanAssignmentDto(
    Guid Id, Guid PartnerAccountId, Guid PlanId, string? PlanName, decimal? Percent, decimal? FlatAmount, decimal? Cap,
    int? ClawbackWindowDays, int? PaymentTermsDays, DateTime EffectiveFrom, DateTime? EffectiveTo, string Reason, Guid? CreatedById, DateTime CreatedAt);

// ---------------------------------------------------------------------------------------------------------------------
// Partner profile (one per partner account)
// ---------------------------------------------------------------------------------------------------------------------

/// <summary>
/// The profile of a channel partner. Commercial terms are NOT here (they are versioned plans). PayoutDetails is null unless the caller reads
/// the ID &amp; bank category raw. <c>PayoutsNeedSignedAgreement</c> is the Q17 choice made at setup; <c>RepCredit</c> is the Q18 per-partner
/// override (null = follow the org setting).
/// </summary>
public record PartnerProfileDto(
    Guid Id, Guid AccountId, string AccountName, string Type, string Status, string? Tier,
    Guid? DefaultPlanId, string? DefaultPlanName,
    Guid? AgreementEngagementLetterId, Guid? AgreementAttachmentId, bool SignedAgreementOnFile,
    bool PayoutsNeedSignedAgreement, string? RepCredit, string EffectiveRepCredit,
    bool VatRegistered, string? Trn, string? Territory, string? ExclusivityNote,
    DateTime? OnboardedAt, DateTime? TerminatedAt,
    PartnerPayoutDetailsDto? PayoutDetails, bool PayoutDetailsHidden,
    DateTime CreatedAt, DateTime UpdatedAt,
    // Phase 4 white-label (DOCUMENTS ONLY): the partner's name, logo and template variant on the proposals / agreements of its deals. Not money, so not behind a commercial category.
    bool WhiteLabelEnabled = false, string? WhiteLabelName = null, string? WhiteLabelVariant = null, Guid? LogoAttachmentId = null, string? LogoFilename = null,
    // Bulk upload (owner 2026-10-20): "our contact for this partner" - CRM users (profile ids) with their names. Empty when none.
    List<PartnerInternalContactDto>? InternalContacts = null,
    // Partner terms (owner 2026-11-10). Partner commercials: all null when the caller's level withholds them (TermsHidden true). At most one of WholesaleAmount / WholesalePercent.
    decimal? ResalePrice = null, decimal? WholesaleAmount = null, decimal? WholesalePercent = null, decimal? ExtraEntityFee = null, decimal? ExtraEntitySharePercent = null,
    int? PaymentTermsDays = null, decimal? MinimumCommitmentQuantity = null, string? MinimumCommitmentUnit = null, bool TermsHidden = false,
    // The requirement field keys (PartnerRequirementCatalogue) this partner still lacks under its type's rules, plus "type_to_be_set". The ONE completeness rule.
    List<string>? Missing = null,
    // Owner 2026-11-12: the signed MoU net-margin terms (Partner commercials: null when the caller's level withholds them, or none are set). See PartnerMou.cs.
    PartnerMouTermsDto? MouTerms = null);

/// <summary>A CRM user who is "our contact" for a partner.</summary>
public record PartnerInternalContactDto(Guid UserId, string? Name);

public record PartnerPayoutDetailsDto(string? AccountHolder, string? BankName, string? Iban);

/// <summary>Create / change a profile. On create, <c>PayoutsNeedSignedAgreement</c> must be stated (Q17: asked during partner setup); on update null = leave.</summary>
public record PartnerProfileInput(
    string? Type, string? Status, string? Tier, Guid? DefaultPlanId, bool ClearDefaultPlan,
    Guid? AgreementEngagementLetterId, Guid? AgreementAttachmentId, bool ClearAgreement,
    bool? PayoutsNeedSignedAgreement, string? RepCredit, bool ClearRepCredit,
    bool? VatRegistered, string? Trn, string? Territory, string? ExclusivityNote,
    DateTime? OnboardedAt, DateTime? TerminatedAt,
    string? PayoutAccountHolder, string? PayoutBankName, string? PayoutIban,
    // Phase 4 white-label. Null = leave. WhiteLabelName / WhiteLabelVariant: blank text clears. LogoAttachmentId must be a PNG or JPEG already on the partner ACCOUNT's files (at most 2 MB).
    bool? WhiteLabelEnabled = null, string? WhiteLabelName = null, string? WhiteLabelVariant = null, Guid? LogoAttachmentId = null, bool ClearLogo = false,
    // Bulk upload. Null = leave; a list REPLACES "our contacts for this partner" (each must be an active CRM user of this organization; an empty list clears it).
    List<Guid>? InternalContactIds = null,
    // Partner terms (needs a Full Partner commercials write). Null = leave; a Clear* flag clears (the profile save's precedent: ClearDefaultPlan, ClearRepCredit, ClearLogo).
    // Setting wholesale_amount clears wholesale_percent and vice versa; sending both is refused (wholesale_one_way).
    decimal? ResalePrice = null, decimal? WholesaleAmount = null, decimal? WholesalePercent = null, decimal? ExtraEntityFee = null, decimal? ExtraEntitySharePercent = null,
    int? PaymentTermsDays = null, decimal? MinimumCommitmentQuantity = null, string? MinimumCommitmentUnit = null,
    bool ClearResalePrice = false, bool ClearWholesaleAmount = false, bool ClearWholesalePercent = false, bool ClearExtraEntityFee = false, bool ClearExtraEntitySharePercent = false,
    bool ClearPaymentTermsDays = false, bool ClearMinimumCommitmentQuantity = false, bool ClearMinimumCommitmentUnit = false,
    // MoU net-margin terms (needs a Full Partner commercials write). A given object REPLACES the stored terms (validated in plain words); ClearMouTerms removes them.
    PartnerMouTermsDto? MouTerms = null, bool ClearMouTerms = false);

public record PartnerListItemDto(
    Guid AccountId, string AccountName, string Type, string Status, string? Tier, bool SignedAgreementOnFile,
    decimal? Accrued, decimal? Owed, decimal? Paid);

/// <param name="AdjustmentApprovalLimit">F9: a manual ledger adjustment whose absolute amount is above this goes through the approval chains; null = no limit set (managers adjust with a reason).</param>
/// <param name="MaxChannelDepth">Phase 3: levels in a distributor chain (a distributor and its sub-resellers = 2).</param>
public record ChannelPartnerSettingsDto(
    List<string> Types, List<string> Tiers, string RepCredit, bool PayoutsNeedSignedAgreementDefault, decimal? AdjustmentApprovalLimit = null,
    int MaxChannelDepth = ChannelPartnerVocab.DefaultMaxChannelDepth,
    decimal? PrimeRatePercent = null,
    // Owner 2026-11-10 (D4/D6): which profile fields each partner type requires, and the default values a new partner of that type is filled with. Keyed by type. The reply always
    // carries the EFFECTIVE map (the org's own, else the shipped one) and the field catalogues the settings screen lists.
    Dictionary<string, PartnerTypeRequirementDto>? TypeRequirements = null,
    List<RequirementFieldDto>? RequirementFields = null, List<RequirementFieldDto>? DefaultFields = null);

/// <summary>One type's rules. <c>Required</c>: requirement field keys. <c>Defaults</c>: default-field key to value (a plan id, a number, a boolean).</summary>
public record PartnerTypeRequirementDto(List<string>? Required = null, Dictionary<string, JsonElement>? Defaults = null);

/// <param name="CanDefault">The requirement can carry a default value in a type's defaults.</param>
public record RequirementFieldDto(string Key, string Label, bool CanDefault);

/// <summary>The ONE catalogue of requirement fields and default fields, and the shipped per-type rules (used when an org has saved none).</summary>
public static class PartnerRequirementCatalogue
{
    public const string Agreement = "agreement", DefaultPlan = "default_plan", VatTrn = "vat_trn", BankDetails = "bank_details", Territory = "territory",
        OnboardedOn = "onboarded_on", ResalePrice = "resale_price", Wholesale = "wholesale", PaymentTermsDays = "payment_terms_days",
        MinimumCommitment = "minimum_commitment", ExtraEntityFee = "extra_entity_fee", MouTerms = "mou_terms";

    public static readonly IReadOnlyList<RequirementFieldDto> Fields =
    [
        new(Agreement, "Signed agreement", false), new(DefaultPlan, "Default plan", true), new(VatTrn, "VAT / TRN", false), new(BankDetails, "Bank details", false),
        new(Territory, "Territory", false), new(OnboardedOn, "Onboarded on", false), new(ResalePrice, "Resale price", false), new(Wholesale, "Wholesale (amount or percent)", true),
        new(PaymentTermsDays, "Payment terms (days)", true), new(MinimumCommitment, "Minimum commitment", false), new(ExtraEntityFee, "Extra-entity fee", false),
        new(MouTerms, "MoU terms (net margin)", false),
    ];

    public const string DefaultWholesalePercent = "wholesale_percent", DefaultExtraEntitySharePercent = "extra_entity_share_percent", DefaultPayoutsNeedSignedAgreement = "payouts_need_signed_agreement",
        DefaultFpSharePct = "fp_share_pct", DefaultSpSharePct = "sp_share_pct", DefaultBillingFrequency = "billing_frequency", DefaultBilledBy = "billed_by", DefaultTierBasis = "tier_basis";

    /// <summary>Keys a type's Defaults may carry: default_plan (plan id), payment_terms_days, wholesale_percent, extra_entity_share_percent, payouts_need_signed_agreement.</summary>
    public static readonly IReadOnlyList<RequirementFieldDto> DefaultFields =
    [
        new(DefaultPlan, "Default plan", true), new(PaymentTermsDays, "Payment terms (days)", true), new(DefaultWholesalePercent, "Wholesale percent of resale", true),
        new(DefaultExtraEntitySharePercent, "Extra-entity share percent", true), new(DefaultPayoutsNeedSignedAgreement, "Payouts need a signed agreement", true),
        new(DefaultFpSharePct, "MoU: FP share percent", true), new(DefaultSpSharePct, "MoU: SP share percent", true), new(DefaultBillingFrequency, "MoU: billing frequency", true),
        new(DefaultBilledBy, "MoU: who bills the end client", true), new(DefaultTierBasis, "MoU: volume tier basis", true),
    ];

    public static bool IsField(string key) => Fields.Any(f => f.Key == key);
    public static bool IsDefaultField(string key) => DefaultFields.Any(f => f.Key == key);

    private static PartnerTypeRequirementDto Rule(string[] required, Dictionary<string, JsonElement>? defaults = null) => new([.. required], defaults ?? []);
    private static JsonElement N(decimal v) => JsonSerializer.SerializeToElement(v);

    /// <summary>Owner 2026-11-10. Used for an org that has saved no requirements of its own.</summary>
    public static Dictionary<string, PartnerTypeRequirementDto> Shipped()
    {
        PartnerTypeRequirementDto Reseller() => Rule([Agreement, ResalePrice, Wholesale, PaymentTermsDays],
            new() { [DefaultWholesalePercent] = N(50), [PaymentTermsDays] = N(30) });
        string[] payable = [Agreement, DefaultPlan, BankDetails];
        return new()
        {
            ["reseller"] = Reseller(), ["reseller_bulk"] = Reseller(), ["white_label"] = Reseller(),
            ["referral_flat"] = Rule(payable), ["referral_percent"] = Rule(payable), ["revenue_share"] = Rule(payable), ["affiliate"] = Rule(payable), ["distributor"] = Rule([.. payable, MouTerms], new() { [DefaultFpSharePct] = N(50), [DefaultSpSharePct] = N(50), [DefaultBillingFrequency] = JsonSerializer.SerializeToElement("monthly"), [PaymentTermsDays] = N(30) }),
            ["fsp"] = Rule([Agreement, DefaultPlan]),
            ["system_integrator"] = Rule([Agreement, DefaultPlan, BankDetails]),
            ["tri_party_mou"] = Rule([Agreement]), ["alliance"] = Rule([Agreement]),
        };
    }
}

/// <summary>Terms-change prompt (D3): how many in-progress reseller deals of this partner a terms change would reach.</summary>
public record PartnerTermsOpenDealsDto(int Count);

public record PartnerTermsAppliedDto(int Updated);

public record ChannelPartnerSettingsInput(
    List<string>? Types, List<string>? Tiers, string? RepCredit, bool? PayoutsNeedSignedAgreementDefault,
    decimal? AdjustmentApprovalLimit = null, bool ClearAdjustmentApprovalLimit = false, int? MaxChannelDepth = null,
    decimal? PrimeRatePercent = null, bool ClearPrimeRate = false,
    // Replaces the whole per-type map when sent (every key a type of the org; required keys from the catalogue; defaults keys from the default catalogue). Null = leave.
    Dictionary<string, PartnerTypeRequirementDto>? TypeRequirements = null);

// ---------------------------------------------------------------------------------------------------------------------
// Deal partners
// ---------------------------------------------------------------------------------------------------------------------

/// <summary>
/// One partner on a deal. Rate fields (<c>Rule</c>) are null when the caller's partner_commercials level withholds them; the partner, its role and
/// whether terms exist are always visible to anyone who sees the deal.
/// </summary>
public record DealPartnerDto(
    Guid Id, Guid LeadId, string? LeadName, Guid PartnerAccountId, string PartnerName, string Role, string Origin,
    Guid? PlanVersionId, string? PlanName, int? PlanVersion, bool Legacy, bool HasTerms, string RuleScope, string? OverrideReason,
    PartnerRuleSummaryDto? Rule, DateTime StartedAt, DateTime? EndedAt, string? EndReason,
    decimal? Accrued, decimal? CollectedBase, decimal? Paid = null, decimal? Owed = null,
    // ---- Phase 2 (additive) ----
    string PlanDirection = ChannelPartnerVocab.Direction.Payable, DealPartnerRegistrationDto? Registration = null, bool ProtectedByRegistration = false,
    DealPartnerPipelineFlagDto? PipelineFlag = null, int OpenConflictCount = 0, bool BillsEndClient = false, Guid? BillingLeadId = null, string? BillingLeadName = null,
    string? SiBilling = null, decimal? PartnerCost = null, decimal? PartnerCostPaid = null,
    // FSP revenue (owner): on a deal billed by this FSP - the end-client price, what the FSP is invoiced to remit to us, and the back-calculated FSP SHARE (price - remit). Null until
    // our invoice to the FSP is raised; withheld below a raw Partner commercials read.
    decimal? FspEndClientPrice = null, decimal? FspBilledToUs = null, decimal? FspShare = null,
    // Reseller figures (owner 2026-11-10): the partner's resale price, the wholesale amount stored on the attribution, OUR revenue on the deal (the attribution's wholesale, else what
    // PartnerRevenueView resolves) and the deal's win date. Resale/wholesale/our revenue are withheld below a raw Partner commercials read; WonAt is the deal's own fact.
    decimal? ResalePrice = null, decimal? WholesaleAmount = null, decimal? OurRevenue = null, DateTime? WonAt = null);

/// <summary>The effective rule after overrides - what the next accrual will use.</summary>
public record PartnerRuleSummaryDto(
    string RateKind, decimal? Percent, decimal? FlatAmount, string Trigger, string AppliesTo, decimal? Cap, int ClawbackWindowDays, int PaymentTermsDays);

/// <summary>One option of the lead form's "Partner" picker: a partner account the form could accept. Names only - no status, tier, balance or count.</summary>
public record PartnerPickDto(Guid AccountId, string Name, string? Type = null);

/// <summary>Attribute a partner to a deal. PlanId null = the partner's current assignment, else its default plan, else "legacy, no terms". Overrides need a Reason.</summary>
public record DealPartnerInput(
    Guid? PartnerAccountId, string? Role, string? Origin, Guid? PlanId,
    decimal? OverridePercent, decimal? OverrideFlatAmount, decimal? OverrideCap, int? OverrideClawbackWindowDays, int? OverridePaymentTermsDays,
    string? OverrideReason);

/// <summary>Ending an attribution that has earned money needs <c>ReverseEarned</c>: the reversing adjustment is written in the same save.</summary>
public record DealPartnerEndInput(string? Reason, bool ReverseEarned = false);

/// <summary>Re-point a deal partner at a plan version. Changing terms after money accrued needs a Reason and is a manager action.</summary>
public record DealPartnerRepointInput(Guid? PlanId, string? Reason);

// ---------------------------------------------------------------------------------------------------------------------
// Ledger, clawbacks, statements, payouts
// ---------------------------------------------------------------------------------------------------------------------

public record PartnerLedgerEntryDto(
    Guid Id, Guid PartnerAccountId, Guid? LeadId, string? LeadName, Guid? DealPartnerId, string Direction, string Kind, decimal Amount, string Currency,
    Guid? PaymentId, Guid? InvoiceId, Guid? ReverseOfEntryId, Guid? PayoutId, Guid? PlanVersionId, string? RuleKey, string RuleScope,
    decimal BaseAmount, decimal BaseDelta, decimal? Rate, DateTime EarnedAt, DateTime PayableOn, DateTime? ReversibleUntil, int PaymentTermsDays,
    string? Reason, Guid? CreatedById, DateTime CreatedAt, bool Settled, Guid? MilestoneId = null, Guid? RemittanceId = null);

public record PartnerLedgerPageDto(List<PartnerLedgerEntryDto> Entries, decimal Accrued, decimal Clawed, decimal Paid, decimal Owed, int Total);

/// <summary>A clawback that fell OUTSIDE the plan's window: a manager decides (Q14). Approving writes the negative adjustment; waiving lets the partner keep it.</summary>
public record PartnerClawbackDecisionDto(
    Guid Id, Guid PartnerAccountId, string? PartnerName, Guid? LeadId, Guid DealPartnerId, decimal Amount, string Status, string Reason,
    Guid? InvoiceId, Guid? TaskId, Guid? DecidedById, DateTime? DecidedAt, string? DecisionNote, DateTime CreatedAt);

public record PartnerClawbackDecideInput(bool Approve, string? Note);

/// <summary>A manual correction: a NEW signed entry (never an edit), with a reason. Managers only; the original is left as it was.</summary>
public record PartnerLedgerAdjustInput(Guid? DealPartnerId, decimal Amount, string? Reason, Guid? ReverseOfEntryId);

/// <summary>
/// F9: the answer to a manual adjustment. At or below the org's limit the entry is written at once (<c>Entry</c> set). Above it, nothing is written: an approval request
/// (type partner_adjustment) is opened on the approval chains and <c>PendingApproval</c> is true; approving it writes the entry.
/// </summary>
public record PartnerAdjustmentResultDto(
    PartnerLedgerEntryDto? Entry, bool PendingApproval, Guid? AdjustmentRequestId, Guid? ApprovalRequestId, Guid? ApprovalChainInstanceId);

public record PartnerStatementLineDto(
    Guid EntryId, Guid? LeadId, string? LeadName, string Kind, decimal Amount, DateTime EarnedAt, decimal BaseDelta, decimal? Rate);

public record PartnerStatementDto(
    Guid? Id, string? Number, Guid PartnerAccountId, string PartnerName, DateOnly PeriodStart, DateOnly PeriodEnd, string Status,
    decimal OpeningBalance, decimal Accruals, decimal Clawbacks, decimal Payouts, decimal ClosingBalance,
    List<PartnerStatementLineDto> Lines, DateTime? IssuedAt, Guid? IssuedById, string Direction = ChannelPartnerVocab.Direction.Payable);

/// <summary>Direction null = payable (Phase 1). A receivable statement is what the partner owes us; a cost statement is what we owe an SI. Never mixed.</summary>
public record PartnerStatementInput(DateOnly? PeriodStart, DateOnly? PeriodEnd, string? Direction = null);

public record PartnerPayoutDto(
    Guid Id, string Number, Guid PartnerAccountId, string PartnerName, string Status,
    decimal NetAmount, decimal VatRate, decimal VatAmount, decimal GrossAmount, string Currency,
    string? PartnerInvoiceNumber, DateOnly? PartnerInvoiceDate, Guid? PartnerInvoiceAttachmentId, DateOnly? DueDate,
    Guid PreparedById, string? PreparedByName, DateTime PreparedAt, DateTime? SubmittedAt, Guid? ApprovalRequestId, Guid? ApprovalChainInstanceId,
    Guid? ApprovedById, DateTime? ApprovedAt, string? DecisionNote,
    DateTime? PaidAt, Guid? PaidById, string? Method, string? Reference, Guid? ProofAttachmentId, DateTime? ExportedAt,
    int EntryCount, List<Guid> EntryIds, string? BlockedReason,
    string? PartnerInvoiceFilename = null, string? PartnerInvoiceUrl = null, string Direction = ChannelPartnerVocab.Direction.Payable);

/// <summary>Prepare a payout from payable ledger entries. Null EntryIds = every unsettled earning entry of the partner. The partner's tax invoice details may be added now or on update.</summary>
public record PartnerPayoutPrepareInput(
    Guid? PartnerAccountId, List<Guid>? EntryIds, string? PartnerInvoiceNumber, DateOnly? PartnerInvoiceDate, Guid? PartnerInvoiceAttachmentId,
    decimal? VatRate, decimal? VatAmount, string? Direction = null);

/// <summary>Edit a DRAFT payout's partner-invoice details. VatAmount null with a VatRate = computed (net x rate, 2dp half away from zero); recorded as the partner's invoice states it.</summary>
public record PartnerPayoutUpdateInput(
    string? PartnerInvoiceNumber, DateOnly? PartnerInvoiceDate, Guid? PartnerInvoiceAttachmentId, decimal? VatRate, decimal? VatAmount, string? Note);

public record PartnerPayoutMarkPaidInput(DateTime? PaidAt, string? Method, string? Reference, Guid? ProofAttachmentId);

public record PartnerPayoutCancelInput(string? Reason);

// ---------------------------------------------------------------------------------------------------------------------
// Aggregate (PartnerStats)
// ---------------------------------------------------------------------------------------------------------------------

public record PartnerStatsRowDto(
    Guid PartnerAccountId, string? PartnerName, DateOnly Month, int SourcedCount, decimal SourcedValue, int WonCount, decimal WonValue,
    decimal CollectedBase, decimal Accrued, decimal Clawed, decimal Paid,
    // Phase 2: separate columns, never mixed with the payable ones above. Cost = what we owe an SI; receivable = what an FSP owes us.
    decimal CostAccrued = 0m, decimal CostPaid = 0m, decimal ReceivableBilled = 0m, decimal ReceivableRemitted = 0m,
    // Phase 3. WonValue above is the END-CLIENT PRICE; WholesaleValue is the second named total, "our revenue (wholesale)", over the same won reseller deals.
    PartnerStockStatsDto? Stock = null,
    // FSP revenue (owner): the FSP's share of the deals it bills, back-calculated (end-client price - what it is invoiced to remit to us), by the month won.
    decimal FspShare = 0m);

public record PartnerStatsDto(
    List<PartnerStatsRowDto> Rows, int SourcedCount, decimal SourcedValue, int WonCount, decimal WonValue,
    decimal CollectedBase, decimal Accrued, decimal Clawed, decimal Paid, decimal Owed,
    decimal CostAccrued = 0m, decimal CostPaid = 0m, decimal CostOwed = 0m, decimal ReceivableBilled = 0m, decimal ReceivableRemitted = 0m, decimal ReceivableOwed = 0m,
    PartnerStockStatsDto? Stock = null, decimal FspShare = 0m);

/// <summary>One-call partner tab payload: profile + balances + deals + open decisions.</summary>
public record PartnerOverviewDto(
    PartnerProfileDto Profile, decimal? Accrued, decimal? Clawed, decimal? Paid, decimal? Owed, decimal? Payable,
    int PendingDecisions, int OpenDeals, PartnerPlanAssignmentDto? Assignment, bool CommercialsHidden,
    decimal? CostAccrued = null, decimal? CostPaid = null, decimal? CostOwed = null, decimal? ReceivableBilled = null, decimal? ReceivableRemitted = null, decimal? ReceivableOwed = null,
    // Reseller only (null otherwise): three separate figures, never netted. ReceivableOwed above carries the unpaid invoice balance for a reseller.
    decimal? WholesaleWon = null, decimal? InvoicedToPartner = null);

public static class ChannelPartnerJson
{
    public static readonly JsonSerializerOptions Options = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
        PropertyNameCaseInsensitive = true,
    };
}

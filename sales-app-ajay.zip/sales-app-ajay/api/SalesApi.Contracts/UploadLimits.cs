namespace SalesApi.Services;

/// <summary>The per-file size ceilings for uploads, in ONE place (owner decision 2026-11-12). Staff uploads (attachments,
/// gate files, signed copies, IRL workbook, document register, knowledge, screening evidence) take up to 25 MB, because
/// signed client agreements of 11-18 MB arrive. Anything a CLIENT or the public sends (customer portal, public document
/// request, public IRL) stays at 10 MB. WhatsApp media has its own platform limit (<c>WhatsAppMedia.MaxBytes</c>) and is
/// deliberately NOT tied to these. The client mirror is <c>STAFF_UPLOAD_MAX_BYTES</c> in packages/core/src/lib/uploadLimits.ts.</summary>
public static class UploadLimits
{
    public const long StaffFileBytes = 25L * 1024 * 1024;
    public const long PublicFileBytes = 10L * 1024 * 1024;

    /// <summary>Multipart framing (boundaries, the other form fields) on top of the file itself.</summary>
    private const long FormOverheadBytes = 1024 * 1024;

    /// <summary>[RequestSizeLimit] for one staff file in a multipart form.</summary>
    public const long StaffRequestBytes = StaffFileBytes + FormOverheadBytes;
    /// <summary>[RequestSizeLimit] for one public file in a multipart form.</summary>
    public const long PublicRequestBytes = PublicFileBytes + FormOverheadBytes;
    /// <summary>[RequestSizeLimit] for the lead-with-files form: several gate files at once.</summary>
    public const long StaffMultiFileRequestBytes = 3 * StaffFileBytes + FormOverheadBytes;

    /// <summary>"25 MB" - for refusal messages, so they follow the constant.</summary>
    public static string Describe(long bytes) => $"{bytes / (1024 * 1024)} MB";
}

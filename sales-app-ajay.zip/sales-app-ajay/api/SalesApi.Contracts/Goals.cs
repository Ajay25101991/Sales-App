// The Goals contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Sales targets ---
// Per-rep monthly revenue target + attainment for a period ("yyyy-MM").
// Role rides along so the targets table can show it as a subtitle under the
// name without a second lookup — see TargetsController.ComputeManyAsync.
public record TargetProgressDto(Guid UserId, string? FullName, string? Role, string Period, decimal Target, decimal WonValue, double Attainment);

// One month of GET /targets/history — the same rows GET /targets returns for
// that period. Per-rep rather than a team total, because the caller needs both
// the summed attainment (the chart) and each rep's own previous month (the
// "last month" column), and one shape serves both.
public record TargetHistoryPeriodDto(string Period, List<TargetProgressDto> Rows);
public record TargetInput(Guid? UserId, string? Period, decimal? Amount);

// --- Org/team goals (item 4) + targets audit log (item 5) ---

public record GoalInput(string? Period, decimal? Amount);
public record TeamGoalInput(Guid? TeamId, string? Period, decimal? Amount);

// PeopleSum is the sum of that team's members' individual Targets for the
// period — served alongside Amount (the team's own goal, independently set)
// so the client can warn on a mismatch without deriving either from the other.
// IsUnassigned marks the single virtual row for people with no PrimaryTeamId —
// TeamId is Services/AggregateOwner.Unassigned (the all-zero sentinel), Amount
// is always null (nobody can set a goal for a team that doesn't exist), and
// PeopleSum is the sum of their individual targets. Mirrors
// LeaderboardRowDto.IsUnassigned: not a real team, appended after the real
// rows, never offered in a team picker.
public record TeamGoalRowDto(Guid TeamId, string TeamName, decimal? Amount, decimal PeopleSum, bool IsUnassigned = false);
public record OrgGoalsResponseDto(string Period, decimal? OrgGoal, decimal TeamGoalsSum, List<TeamGoalRowDto> Teams);

public record TargetAuditEntryDto(
    string EntityType, string EntityKey, string Period, Guid ChangedBy,
    decimal? OldValue, decimal NewValue, DateTime CreatedAt);

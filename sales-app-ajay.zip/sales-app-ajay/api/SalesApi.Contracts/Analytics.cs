// The Analytics contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Analytics / Explore (owner decision §28) ---------------------------

// The catalogue GET /reports/explore/catalogue returns — every measure and
// dimension the Explore builder may offer MUST come from here, never a
// hand-written list on the client (the binding rule: an entry offered in the
// UI that the backend cannot resolve is the same defect as an unenforced
// permission scope).
public record ExploreMeasureDto(string Key, string Label, string Unit);
public record ExploreDimensionDto(string Key, string Label);
public record ExploreCatalogueDto(List<ExploreMeasureDto> Measures, List<ExploreDimensionDto> Dimensions);

// One group's worth of results — Key is the raw (possibly composite, "::"-
// joined) grouping key for stable React keys / drill-through filters; Label
// is what the chart/table shows. Measures is keyed by the SAME measure keys
// the request asked for.
public record ExploreGroupDto(string Key, string Label, Dictionary<string, decimal?> Measures, int WonCount, int LostCount);

public record ExploreResultDto(
    List<ExploreGroupDto> Rows,
    string GroupedBy,
    string? SplitBy,
    // Echoes the composition back so a "Save view" / "Open as a list" caller
    // never has to reconstruct it from the query string.
    List<string> Measures);

// --- Activity effort (Analytics tab 4, "Sources and effort") ------------
//
// GET /reports/activity-effort. Two figures, both honestly scoped:
// TotalActivities/WonCount/ActivitiesPerWonDeal come from the SAME sources
// every other figure on this controller does — DailyActivityStats(Org) (the
// governed activity fact) and MeasureRegistry's won_count — never a second
// count of either. Points is different: "touches before close, against value
// won" is a PER-LEAD pairing no fact table carries (DailyActivityStats has no
// lead id; DailyDealStats has no touch count), so it is answered by a live,
// explicitly-scoped join of LeadActivities against won Leads — see
// ReportsController.ActivityEffort for why that is the honest choice here and
// not a violation of "hit a fact, not leads" (ExploreService's own rule):
// there is no fact to hit for this shape, and the join is bounded by the won
// leads in the window (small in every measured environment).
public record ActivityEffortPointDto(Guid LeadId, string LeadName, int Touches, decimal? Value);
public record ActivityEffortDto(
    DateTime Start,
    DateTime End,
    int TotalActivities,
    int WonCount,
    // TotalActivities / WonCount. Null (not a divide-by-zero 0) when WonCount
    // is 0 — no deals closed in this window, so "activities per won deal" has
    // no measurable answer.
    decimal? ActivitiesPerWonDeal,
    double? MedianTouches,
    List<ActivityEffortPointDto> Points,
    // True when Points was capped below the full won-lead count in this
    // window — see ActivityEffortGuardrails.MaxPoints.
    bool Truncated);

// --- Cohorts (Analytics tab 5, "Cohorts and team") -----------------------
//
// GET /reports/cohorts. Grouped by the CREATION month of each lead, not the
// close day DailyDealStats keys on — see ReportsController.Cohorts for why
// that means this reads `leads` directly, live, rather than a fact table
// (numbers-audit-decisions.md §35's own gap: every existing fact is keyed by
// owner+time-of-CLOSE, and a creation-month cohort needs time-of-CREATION).
public record CohortAgeCellDto(
    int AgeMonths,
    // False when this age has not fully elapsed yet for this cohort (e.g. a
    // cohort created 6 weeks ago has no honest "age 3 months" answer) —
    // WonCount/WonPct are null in that case, not zeroed.
    bool Measurable,
    int? WonCount,
    double? WonPct);
public record CohortRowDto(string CohortMonth, string CohortLabel, int CohortSize, List<CohortAgeCellDto> Ages);
public record CohortsDto(List<CohortRowDto> Cohorts, int MaxAgeMonths, DateTime GeneratedAt);

// Guardrail for GET /reports/activity-effort's per-lead scatter — named in ONE
// place like Services/ExploreService.ExploreGuardrails, whose "refuse/truncate
// with a stated reason, never silently" discipline this mirrors.
//
// Moved here from ReportsController when the report itself moved into the
// Process layer: a bound the computation enforces cannot live in the host
// project, which nothing below the HTTP surface can see. It is a pure constant,
// so Contracts is where both the computation and the DTO documenting it can
// read the same number.
public static class ActivityEffortGuardrails
{
    /// <summary>The scatter is one dot per won lead; past this many the chart
    /// stops being readable and the response says Truncated=true rather than
    /// silently dropping rows.</summary>
    public const int MaxPoints = 500;
}

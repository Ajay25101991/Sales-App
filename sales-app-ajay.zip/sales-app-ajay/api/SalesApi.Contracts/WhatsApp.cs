// E6.4 WhatsApp contracts (design doc to-do/e6-connectors-design.md §3/§4/§11).

namespace SalesApi.Dtos;

/// <summary>Same shape as MailboxSyncSettingsDto/Input — see that file.
/// E6.4 finish, slice 8 (design §3.7) — <c>ConnectionStatus</c>/<c>ConnectionErrorReason</c>
/// surface the same four-state shape the design gives every connector's card
/// (not_configured/active/token_expired/error), resolved from
/// <c>WhatsAppConnectionHealth</c> plus whether a <c>ConnectorConnection</c> row
/// even exists.</summary>
public record WhatsAppSettingsDto(
    string UnknownSenderPolicy, bool StoreMedia, string ConnectionStatus, string? ConnectionErrorReason, string? WebhookUrl = null);

/// <summary>Partial-update input — nulls mean "leave as-is".</summary>
public record WhatsAppSettingsInput(string? UnknownSenderPolicy, bool? StoreMedia);

/// <summary>POST /leads/{id}/whatsapp body — EITHER a free-text session
/// message (<c>Body</c>, only accepted while the 24h window is open) OR a
/// template send (<c>TemplateName</c>/<c>TemplateLanguage</c>/<c>TemplateParams</c>,
/// design §3.3/§3.4, E6.4 finish slice 5) — never both.</summary>
public record WhatsAppSendInput(string? Body, string? TemplateName = null, string? TemplateLanguage = null, List<string>? TemplateParams = null);

/// <summary>GET /whatsapp/templates row — E6.4 finish, slice 5 (design §3.4).
/// Only APPROVED templates are ever returned (the composer's own "only offer
/// what Meta will actually accept" rule). <c>Body</c> (coordinator follow-up)
/// is the template's BODY component text, placeholders and all (e.g. "Your
/// order {{1}} has shipped") — the desktop composer's preview source; null
/// when the template has no BODY component.</summary>
public record WhatsAppTemplateDto(string Name, string Language, int PlaceholderCount, string? Body);

public record WhatsAppTemplateSyncResultDto(bool Ok, int Synced, string? Reason);

public record WhatsAppSendResultDto(bool Ok, DateTime? SentAt);

/// <summary>What the composer needs before it lets a rep type: whether the
/// lead has a matched WhatsApp number at all, and whether the 24h window is
/// currently open (design §3.2/§7.2).</summary>
public record WhatsAppWindowDto(bool HasPhone, bool WindowOpen, DateTime? WindowOpenUntil, bool OptedOut);

/// <summary>POST /settings/whatsapp/test result — mirrors the email/AI
/// "test connection" shape (SettingsStore.SendTestEmailAsync /
/// TestAiProviderConnectionAsync): a plain outcome and, on failure, a
/// message naming the problem rather than echoing Meta's raw error.</summary>
public record WhatsAppTestConnectionResultDto(bool Ok, string? Reason, string? PhoneNumber);

/// <summary>One row on the "Unmatched WhatsApp" triage screen (design §4.6).</summary>
public record WhatsAppUnmatchedMessageDto(
    Guid Id, string PhoneNormalized, string Body, DateTime ReceivedAt, string Status, Guid? LinkedLeadId);

public record WhatsAppLinkUnmatchedInput(Guid LeadId);

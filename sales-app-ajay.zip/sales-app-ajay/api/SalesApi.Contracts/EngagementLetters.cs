// E10.9 - engagement letters: made from an accepted generated proposal, sent from the rep's own Microsoft 365 mailbox, accepted
// on a secure link. Wire contract: to-do/proposal-generator-api.md ("E10.9 - engagement letters"). Namespace stays SalesApi.Dtos.

namespace SalesApi.Dtos;

/// <summary>
/// One engagement letter. Status: draft | sent | accepted | superseded. PdfState: ready | pending. Files are the Word file and the
/// PDF (WebUrl only filled on generate). ProposalNumber / ProposalRevision say which proposal version it was made from.
/// AcceptToken is the secure link's token (null until first sent); the link is /engagement-letters/accept/{token}.
/// </summary>
public record EngagementLetterDto(
    Guid Id, Guid LeadId, Guid ProposalId, string? ProposalNumber, int ProposalRevision, int Version,
    string Status, string PdfState, List<RenderedFileDto> Files, List<TemplateVersionUsedDto> TemplatesUsed,
    DateTime CreatedAt, Guid CreatedById, string? CreatedByName,
    DateTime? SentAt, string? SentTo, string? SentSubject, bool? SentAsReply, string? AcceptToken,
    DateTime? AcceptedAt, string? AcceptedBy,
    int ViewCount, DateTime? FirstViewedAt, DateTime? LastViewedAt,
    Guid? SignedAttachmentId, DateTime? SignedAt,
    // The agreement this letter is (the letter template's variant name) when several were generated together; null = the unnamed letter.
    string? Variant = null);

/// <summary>The generate response: the letter and anything the renderer left as written, plus why a PDF is missing. With several
/// agreements, Letter is the first and Letters lists all of them (null for a single unnamed letter, as before); LeftVisible is merged and
/// PdfError is the first one.</summary>
public record EngagementLetterGeneratedDto(
    EngagementLetterDto Letter, List<string> LeftVisible, string? PdfError, List<EngagementLetterDto>? Letters = null);

/// <summary>
/// POST .../engagement-letter (optional body). Variants = the names of the agreements to generate, each one its own letter of the same
/// version (see GET /document-templates for the names). Omitted or empty = the single unnamed engagement letter, as before.
/// </summary>
public record GenerateEngagementLettersInput(List<string>? Variants = null);

/// <summary>
/// POST .../engagement-letter/send. ReplyToMessageId is the id of a message from the threads list (default: the most recent
/// message of this deal that is in the rep's own mailbox). NewEmail = true sends a new email even when a thread exists. ToEmail
/// overrides the recipient (default: the deal's contact). Subject / Body are the rep's edit of the prefilled email (default: the template as prefilled).
/// LetterIds = the letters to send TOGETHER in one email, each as an attachment (default: every live letter of the newest generation).
/// More than one letter, or any named agreement, goes WITHOUT the accept link (the customer signs and returns a copy); a single unnamed
/// letter keeps the link as before.
/// </summary>
public record SendEngagementLetterInput(
    Guid? ReplyToMessageId = null, bool? NewEmail = null, string? ToEmail = null, string? Subject = null, string? Body = null,
    List<Guid>? LetterIds = null, List<string>? Cc = null, List<string>? Bcc = null, List<Guid>? CompanyDocumentIds = null,
    string? ToRecipientRef = null, List<string>? CcRecipientRefs = null, List<string>? BccRecipientRefs = null);

/// <summary>GET .../engagement-letter/email: the message the send would use, from the org's "Engagement letter email" template, prefilled for this letter.
/// Body still holds {link}, replaced by the secure link at send (and appended if the rep removes it). Subject is only used for a NEW email: a reply keeps its thread's subject.</summary>
public record EngagementLetterEmailDto(string Subject, string Body, string? ToEmail, string? ToName, string? ToRecipientRef = null);

/// <summary>An email of this deal that is in the rep's own mailbox and can be replied to. MessageId is what ReplyToMessageId takes.</summary>
public record EngagementLetterThreadDto(Guid MessageId, string? Subject, string? FromName, string? FromAddress, DateTime? ReceivedAt);

/// <summary>What the customer's accept page needs. No internal facts: no owner, no deal value breakdown beyond the totals.</summary>
public record CustomerEngagementLetterDto(
    string? QuoteNumber, int Version, string Title, string Status, DateTime? AcceptedAt, string? AcceptedBy,
    List<string> Services, decimal? Total, string? Currency, bool HasPdf);

using System.Text.Json;

namespace SalesApi.Dtos;

// Owner 2026-11-17 - enrichment suggestions: an AI tool's proposed value for one field of a deal, account or contact, accepted or rejected by a person. Wire shapes are snake_case
// like the rest of the API. See FieldSuggestionProcess.

/// <summary>
/// One suggestion. <c>field</c> is a column name ("email") or <c>custom.&lt;key&gt;</c>. <c>suggested_value</c> and <c>current_value</c> are JSON values; both are null with
/// <c>masked</c> true when the caller's role or sensitive-data level hides the field (a suggestion is still listed so the person knows one exists). <c>source_kind</c> is
/// mcp | provider | api_key; <c>status</c> is open | accepted | rejected | superseded.
/// </summary>
public record FieldSuggestionDto(
    Guid Id, string RecordType, Guid RecordId, string? RecordLabel, string Field, JsonElement? SuggestedValue, JsonElement? CurrentValue, bool Masked,
    string? SourceNote, string? SourceUrl, string SourceKind, Guid SuggestedById, string Status, Guid? DecidedById, DateTime? DecidedAt, DateTime CreatedAt);

// E12.7 - the data access log contracts (decision 17), and E12.6's device-launch input.
// Own file for the usual reason: the Experience layer cannot see the System layer, so what it returns lives here.
// Wire: to-do/sensitive-data-api.md section 7.

namespace SalesApi.Dtos;

/// <summary>The fixed vocabulary of what a log entry records. Append-only: a stored row names its action by this key.</summary>
public static class DataAccessActions
{
    public const string CallLaunched = "call_launched";
    public const string SmsLaunched = "sms_launched";
    public const string EmailSent = "email_sent";
    public const string WhatsAppSent = "whatsapp_sent";
    public const string WhatsAppOpened = "whatsapp_opened";
    public const string Export = "export";
    public const string RevealRequested = "reveal_requested";
    public const string RevealApproved = "reveal_approved";
    public const string RevealRefused = "reveal_refused";
    public const string ValueRevealed = "value_revealed";

    public static readonly string[] All =
        [CallLaunched, SmsLaunched, EmailSent, WhatsAppSent, WhatsAppOpened, Export, RevealRequested, RevealApproved, RevealRefused, ValueRevealed];

    public static bool IsValid(string? key) => key is not null && Array.IndexOf(All, key) >= 0;
}

/// <summary>What kind of record an entry points at. <c>report</c> and <c>team</c> are exports that span rows (no record id).</summary>
public static class DataAccessRecordTypes
{
    public const string Lead = "lead";
    public const string Account = "account";
    public const string Contact = "contact";
    public const string Invoice = "invoice";
    public const string Amc = "amc";
    public const string Report = "report";
    public const string Team = "team";

    public static readonly string[] All = [Lead, Account, Contact, Invoice, Amc, Report, Team];

    public static bool IsValid(string? key) => key is not null && Array.IndexOf(All, key) >= 0;
}

/// <summary>The channels a device launch can name.</summary>
public static class DataAccessChannels
{
    public const string Call = "call";
    public const string Sms = "sms";
    public const string WhatsApp = "whatsapp";
}

/// <summary>
/// One row of the log. NEVER carries a value: <paramref name="Field"/> and <paramref name="Category"/> name WHAT was touched,
/// <paramref name="Detail"/> is a short non-sensitive tag (an export's format, a launch's channel).
/// </summary>
public record DataAccessLogEntryDto(
    Guid Id, DateTime OccurredAt, Guid UserId, string? UserName, string Action, string RecordType, Guid? RecordId,
    string? Field, string? Category, int? RowCount, string? Detail);

/// <summary>POST /data-access/launch body. The client names only the record and the channel; the server resolves everything else.</summary>
public record DataAccessLaunchInput(string? RecordType, Guid? RecordId, string? Channel);

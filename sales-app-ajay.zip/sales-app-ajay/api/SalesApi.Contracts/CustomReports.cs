namespace SalesApi.Dtos;

// Custom reports — slice 1 (to-do/report-builder-design.md): the breakdown
// engine over one source (leads, for now) grouped by one field, plus CSV
// export and the field catalogue that drives both the group-by and filter
// pickers. Saved/shared reports are slice 3 — not here.

/// <summary>One group-by choice: a built-in lead field, or a dropdown/
/// picklist/multi-select custom field by its def key.</summary>
public record CustomReportGroupByInput(string Kind, string Key);

/// <summary>
/// `Custom` mirrors the lead-list filter's own shape (key -> selected values,
/// OR within a key) — see <c>LeadListProcess</c>'s own custom-filter comment.
/// `From`/`To` are calendar dates (time-of-day ignored), resolved to org-local
/// day boundaries via <c>ReportingCalendar</c>, never raw UTC midnight.
/// </summary>
/// <remarks>
/// ONE-TABLE ADDITION (owner decision 2026-10-08): a table-mode report's headings edit the report, so the definition's
/// <c>filters</c> may ALSO arrive as the one-table array <c>[{ field, conditions: [...] }]</c> (see
/// <see cref="CustomReportRequestDto.ColumnFilters"/>, the canonical key <c>column_filters</c>); that array form lands in
/// <see cref="ColumnFilters"/> here and carries no date range / team / owner / source / stage / custom, which
/// only the object form has.
/// </remarks>
[System.Text.Json.Serialization.JsonConverter(typeof(CustomReportFiltersInputConverter))]
public record CustomReportFiltersInput(
    DateTime? From, DateTime? To, Guid? TeamId, Guid? OwnerId,
    string? Source, string? Stage, Dictionary<string, List<string>>? Custom,
    List<TableFilterDto>? ColumnFilters = null);

/// <summary>Reads <c>filters</c> as either today's object or the one-table array (see <see cref="CustomReportFiltersInput"/>).</summary>
public sealed class CustomReportFiltersInputConverter : System.Text.Json.Serialization.JsonConverter<CustomReportFiltersInput>
{
    // The object form, read by the serializer's own record binding (so its naming policy applies).
    private sealed record Plain(
        DateTime? From, DateTime? To, Guid? TeamId, Guid? OwnerId,
        string? Source, string? Stage, Dictionary<string, List<string>>? Custom);

    public override CustomReportFiltersInput? Read(
        ref System.Text.Json.Utf8JsonReader reader, Type typeToConvert, System.Text.Json.JsonSerializerOptions options)
    {
        if (reader.TokenType == System.Text.Json.JsonTokenType.Null) return null;
        if (reader.TokenType == System.Text.Json.JsonTokenType.StartArray)
            return new CustomReportFiltersInput(
                null, null, null, null, null, null, null,
                System.Text.Json.JsonSerializer.Deserialize<List<TableFilterDto>>(ref reader, options));
        var p = System.Text.Json.JsonSerializer.Deserialize<Plain>(ref reader, options);
        return p is null ? null : new CustomReportFiltersInput(p.From, p.To, p.TeamId, p.OwnerId, p.Source, p.Stage, p.Custom);
    }

    public override void Write(
        System.Text.Json.Utf8JsonWriter writer, CustomReportFiltersInput value, System.Text.Json.JsonSerializerOptions options)
    {
        if (value.ColumnFilters is { } cf && value.From is null && value.To is null && value.TeamId is null && value.OwnerId is null
            && value.Source is null && value.Stage is null && value.Custom is null)
        {
            System.Text.Json.JsonSerializer.Serialize(writer, cf, options);
            return;
        }
        System.Text.Json.JsonSerializer.Serialize(
            writer, new Plain(value.From, value.To, value.TeamId, value.OwnerId, value.Source, value.Stage, value.Custom), options);
    }
}

/// <summary>One table-mode column choice: a built-in lead field, or a
/// visible custom field by its def key — same Kind/Key shape as
/// <see cref="CustomReportGroupByInput"/>.</summary>
public record CustomReportColumnInput(string Kind, string Key);

/// <summary><paramref name="Dir"/> is "asc" or "desc".</summary>
public record CustomReportSortInput(string Key, string Dir);

/// <summary>
/// Slice 3 additions are all OPTIONAL and ignored by breakdown mode: a
/// breakdown request never sends them, and a table request never sends
/// <see cref="GroupBy"/>. <see cref="Columns"/>/<see cref="Sort"/> are
/// required for <c>mode: "table"</c>; <see cref="Cursor"/>/<see cref="Limit"/>
/// are optional keyset-paging controls (first page omits Cursor).
/// </summary>
public record CustomReportRequestDto(
    string Source, string Mode, CustomReportGroupByInput? GroupBy, CustomReportFiltersInput? Filters,
    List<CustomReportColumnInput>? Columns = null, CustomReportSortInput? Sort = null,
    string? Cursor = null, int? Limit = null,
    List<TableFilterDto>? ColumnFilters = null, List<TableSortDto>? Sorts = null,
    // E18.2: the number or money field a non-lead breakdown sums (wire sum_field). Ignored for leads and for table mode.
    string? SumField = null);

/// <summary>One breakdown row (and, reused, the totals row — see
/// <see cref="CustomReportResultDto.Totals"/>). Money fields are null, never
/// zero, when the caller lacks lead_values.view — the same rule every other
/// report in this codebase follows (see ReportsProcess's own remarks).</summary>
public record CustomReportRow(
    string Key, string Label, int Leads,
    int OpenCount, decimal? OpenValue,
    int WonCount, decimal? WonValue,
    int LostCount, decimal? LostValue,
    double? WinRate);

/// <summary>
/// <paramref name="MultiValue"/> is true only for a multi-select group-by: a
/// lead with N selected values is counted in N rows, so <paramref name="Rows"/>
/// does not sum to <paramref name="Totals"/> — Totals is computed over
/// DISTINCT leads, exactly once each, per the design doc's own rule.
/// </summary>
public record CustomReportResultDto(
    string GroupByLabel, List<CustomReportRow> Rows, CustomReportRow Totals,
    bool ValuesVisible, bool MultiValue);

public record CustomReportFieldOptionDto(string Value, string Label);

/// <summary><paramref name="Kind"/> is "builtin" or "custom_field", matching
/// <see cref="CustomReportGroupByInput.Kind"/> exactly so a client can echo a
/// row straight back as a group-by choice. <paramref name="Options"/> is the
/// known value vocabulary for built-ins with one (stage, source, deal type) and
/// every dropdown/picklist/multi-select custom field; empty for owner/team,
/// whose options are the org's existing people/teams pickers.</summary>
public record CustomReportFieldDto(
    string Kind, string Key, string Label, string? Type, List<CustomReportFieldOptionDto> Options);

public record CustomReportFieldsDto(List<CustomReportFieldDto> Fields);

// --- Table mode (slice 3) ---------------------------------------------------

/// <summary><paramref name="Kind"/> matches <see cref="CustomReportColumnInput.Kind"/>
/// ("builtin" or "custom_field") so a client can echo a catalogue entry
/// straight back as a column choice. <paramref name="Type"/> is the value
/// shape the client should render ("string", "money", "date", "bool",
/// "multi_select", or a custom field's own Type for everything else).</summary>
public record CustomReportColumnOptionDto(string Kind, string Key, string Label, string Type);

public record CustomReportColumnsDto(List<CustomReportColumnOptionDto> Columns);

public record CustomReportTableColumnDto(string Key, string Label, string Type);

/// <summary><paramref name="Values"/> is keyed by the column's own
/// <see cref="CustomReportColumnInput.Key"/> — a money value is null when
/// <c>values_visible</c> is false (never zero, never omitted), matching the
/// breakdown engine's own masking rule.</summary>
public record CustomReportTableRowDto(Guid LeadId, Dictionary<string, object?> Values);

/// <summary><paramref name="DroppedColumns"/> lists any requested column key
/// that no longer resolves (an archived or newly-hidden custom field) —
/// non-empty only when this ran from a SAVED report, which opens anyway
/// rather than refusing (design doc "Validation" rule). A fresh, ad-hoc
/// request refuses instead of ever populating this list — see
/// CustomReportProcess.BuildTableAsync's <c>lenient</c> parameter.</summary>
public record CustomReportTableResultDto(
    List<CustomReportTableColumnDto> Columns, List<CustomReportTableRowDto> Rows,
    string? NextCursor, int TotalCount, bool ValuesVisible, List<string> DroppedColumns);

// --- Saved reports (slice 3) ------------------------------------------------

/// <summary><paramref name="Definition"/> is the exact body <c>/reports/custom/run</c>
/// and <c>/export</c> take (<see cref="CustomReportRequestDto"/>), stored and
/// replayed as-is — see <c>Models.SavedReport</c>'s own remarks on why a saved
/// report never widens what its VIEWER sees. <paramref name="Visibility"/> is
/// "private"/"team"/"org" (<c>Models.SavedReport.Visibilities</c>), same
/// vocabulary as a saved view; <paramref name="TeamId"/> only applies when
/// Visibility is "team".</summary>
public record SavedReportInput(
    string? Name, System.Text.Json.JsonElement? Definition, string? Visibility, Guid? TeamId);

public record SavedReportDto(
    Guid Id, string Name, System.Text.Json.JsonElement Definition, string Visibility, Guid? TeamId,
    Guid CreatedBy, string? CreatedByName, bool Archived, DateTime CreatedAt, DateTime? UpdatedAt, bool CanEdit);

// Channel partners, Phase 3 (to-do/partner-management-design.md 9.2; owner decisions section 10): reseller bulk packs (stock), the two named figures, distributor tiers.
//
// CONFIDENTIAL like the rest of the programme: units, prices, resale price, wholesale and credit sit behind the sensitive category `partner_commercials`.
// A caller below a raw read gets only `availability` ("available" / "low" / "out") and the shortfall wording, never a count or a price - every number below is
// therefore nullable. None of it is read by the document field reader.

namespace SalesApi.Dtos;

/// <summary>"available" / "low" / "out" - all a rep below a raw Partner commercials read ever learns about a partner's stock.</summary>
public static class StockAvailability
{
    public const string Available = "available";
    public const string Low = "low";
    public const string Out = "out";
}

/// <summary>One pack. Balance = bought + movements, derived (never stored); it may be negative (owner 3.5: a win is never blocked by stock).</summary>
public record PartnerStockLotDto(
    Guid Id, Guid PartnerAccountId, string? PartnerName, Guid PurchaseLeadId, string? PurchaseLeadName, Guid? PurchaseInvoiceId, Guid? CatalogItemId,
    string UnitLabel, decimal? QuantityBought, decimal? UnitWholesalePrice, decimal? Balance, decimal? Drawn, decimal? Expired, decimal? ValueBought,
    DateTime PurchasedAt, DateTime? ActivatesOn, DateTime? ExpiresAt, string ExpiryPolicy, Guid? PlanVersionId, decimal? LowStockThreshold,
    bool IsExpired, bool Overdrawn, string Availability, string? Note, DateTime CreatedAt);

/// <summary>One stock movement (the ledger of a lot). Delta negative = units consumed.</summary>
public record PartnerStockMovementDto(
    Guid Id, Guid LotId, string Kind, decimal? Delta, decimal? Value, Guid? LeadId, string? LeadName, Guid? DealPartnerId, string? Reason, bool Overdrawn,
    DateTime At, Guid? ById);

public record PartnerStockMovementPageDto(List<PartnerStockMovementDto> Movements, int Total);

/// <summary>A partner's stock tab: its lots, the totals over them, and the stock credit it holds.</summary>
public record PartnerStockSummaryDto(
    Guid PartnerAccountId, string? PartnerName, List<PartnerStockLotDto> Lots,
    decimal? UnitsBought, decimal? UnitsDrawn, decimal? UnitsExpired, decimal? Balance, decimal? ValueBought, decimal? ValueDrawn, decimal? ValueForfeited, decimal? Credit,
    string Availability, bool CommercialsHidden);

/// <summary>Record a pack: the purchase is an ordinary deal on the partner's account (<c>PurchaseLeadId</c>); this only adds the stock. Null expiry / policy follow the partner's plan.</summary>
public record PartnerStockLotInput(
    Guid? PurchaseLeadId, Guid? PurchaseInvoiceId, Guid? CatalogItemId, string? UnitLabel, decimal? Quantity, decimal? UnitWholesalePrice,
    DateTime? PurchasedAt, DateTime? ExpiresAt, string? ExpiryPolicy, decimal? LowStockThreshold, string? Note);

/// <summary>A manager changes ONE lot's expiry date and/or its policy, with a reason. Written as a zero-delta `override` movement carrying old and new.</summary>
public record PartnerStockOverrideInput(DateTime? ExpiresAt, bool ClearExpiry, string? ExpiryPolicy, string? Reason);

/// <summary>A manager corrects the units on a lot (positive adds, negative removes), with a reason. A transfer between partners is a pair of these.</summary>
public record PartnerStockAdjustInput(decimal? Delta, string? Reason);

/// <summary>Spend (part of) a partner's stock credit against a new purchase lot. The new invoice itself is external; this records that the credit was used.</summary>
public record PartnerStockCreditApplyInput(Guid? PartnerAccountId, Guid? LotId, decimal? Amount, string? Reason);

/// <summary>The cross-partner stock page: one row per partner holding stock.</summary>
public record PartnerStockOverviewRowDto(
    Guid PartnerAccountId, string? PartnerName, string? Tier, decimal? Balance, decimal? ValueBought, decimal? ValueDrawn, decimal? Credit,
    int LotCount, int ExpiringSoon, int LowLots, int OverdrawnLots, DateTime? NextExpiry, string Availability);

public record PartnerStockOverviewDto(List<PartnerStockOverviewRowDto> Rows, int ExpiringWithinDays, bool CommercialsHidden);

/// <summary>
/// The stock facts of ONE deal partner on a deal. <c>StockUnits</c> is typed (editable until the deal is won); <c>SuggestedUnits</c> is what the accepted proposal's named
/// input says (the prefill); <c>DrawnUnits</c> is what the stock has actually supplied. Prices are masked below a raw Partner commercials read.
/// </summary>
public record DealPartnerStockDto(
    Guid DealPartnerId, Guid LeadId, Guid PartnerAccountId, string Role, string? UnitsInput,
    decimal? StockUnits, decimal? SuggestedUnits, decimal? DrawnUnits, decimal? ResalePrice, decimal? WholesaleAmount,
    decimal? Available, string Availability, bool Editable, bool RenewalDraws, int RenewalTerms);

/// <summary>Set the stock facts on a deal partner. Null = leave; the Clear flags remove a value. Units are refused once the deal is won.</summary>
public record DealPartnerStockInput(
    decimal? StockUnits, bool ClearStockUnits, decimal? ResalePrice, bool ClearResalePrice, decimal? WholesaleAmount, bool ClearWholesaleAmount);

/// <summary>
/// THE TWO NAMED FIGURES of a deal (owner 3.1). <c>EndClientPrice</c> is what the deal stores - the partner's price to its client. <c>OurRevenue</c> is the wholesale amount
/// that is ours (null = not known yet, or masked). <c>Kind</c> says what it rests on (own / drawn / expected). <c>IsAllocation</c> is true when OurRevenue is an allocation of a
/// pack purchase already counted on the purchase deal, so org-wide revenue sums leave it out (<c>TotalledOurRevenue</c> is what the stored DealStats adds).
/// </summary>
public record DealRevenueDto(
    Guid LeadId, decimal EndClientPrice, string EndClientPriceLabel, decimal? OurRevenue, string OurRevenueLabel, string Kind, bool IsAllocation,
    decimal? TotalledOurRevenue, decimal? ResalePrice, bool CommercialsHidden);

/// <summary>Add a sub-reseller under a distributor: the AccountRelationship (distributor_for) is added, bounded by the org's MaxChannelDepth.</summary>
public record SubResellerInput(Guid? SubResellerAccountId);

public record DistributorNodeDto(
    Guid AccountId, string Name, int Depth, Guid? ParentAccountId, string? Status, string? Tier,
    decimal? UnitsBought, decimal? UnitsDrawn, decimal? ValueDrawn, decimal? OverrideEarned, int DealsOnStock, List<DistributorNodeDto> Children);

public record DistributorTreeDto(DistributorNodeDto Root, int MaxDepth, bool CommercialsHidden);

/// <summary>The stock columns of the stored partner aggregate (PartnerStats), summed over the rows asked for. Ex VAT; units are the lot's unit label.</summary>
public record PartnerStockStatsDto(
    decimal WholesaleValue, decimal UnitsBought, decimal UnitsUsed, decimal UnitsExpired, decimal ValueBought, decimal ValueDrawn, decimal ValueForfeited);

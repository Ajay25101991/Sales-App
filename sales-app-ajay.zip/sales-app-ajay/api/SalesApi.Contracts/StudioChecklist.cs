namespace SalesApi.Dtos;

// --- E7.4 Studio — onboarding checklist / go-live readiness (design doc
// to-do/e7-config-platform-design.md §5.2, slice 14). Access control (who
// may view an org's checklist) is Part A's `StudioAssignment` question — see
// StudioController's own remark for the seam this slice gates on instead.

/// <summary>The three chip states a checklist row can render as (mock:
/// "Blocking / To do / Done"). See <see cref="StudioAutoCheckDto.Status"/>
/// for how an auto-check picks one.</summary>
public static class StudioChecklistStatuses
{
    public const string Done = "done";
    public const string ToDo = "to_do";
    public const string Blocking = "blocking";
}

/// <summary>One row of an AUTO-COMPUTED check — the RAW fact, never a score
/// (§0.3/§5.2's binding rule: "each check shows its own raw fact... never an
/// invented readiness score"). <see cref="Kind"/> identifies which check
/// produced the row ("email_provider", "ai_budget", "permission_coverage",
/// "unresolved_reference"); <see cref="Detail"/> names the concrete thing
/// failing (a permission name, a stable key, a resolver's own reason string)
/// so the UI never renders a generic "incomplete" (design doc slice 15's own
/// test: "renders as failing with the actual permission name").
///
/// <see cref="Status"/> — owner answer 2026-09-29: a failing auto-check is
/// <see cref="StudioChecklistStatuses.Blocking"/> BY DEFAULT, except
/// <c>permission_coverage</c> ("no one holds permission X"), which is only
/// <see cref="StudioChecklistStatuses.ToDo"/> unless something in the org
/// actually depends on that permission right now (a discount approval chain
/// exists but nobody can decide it; WhatsApp is connected but nobody can send
/// a message) — see <c>StudioChecklistProcess.PermissionCoverageChecksAsync</c>
/// for the dependency list. <see cref="Passing"/> stays the plain pass/fail
/// fact; <see cref="Status"/> is the chip the UI renders.</summary>
public record StudioAutoCheckDto(string Kind, bool Passing, string Label, string? Detail, string Status);

public record StudioChecklistItemDto(
    Guid Id, string Title, string? Owner, DateTime? DueDate, bool Checked, DateTime? CheckedAt, DateTime CreatedAt);

public record StudioChecklistItemInputDto(string Title, string? Owner, DateTime? DueDate);

/// <summary>Counts only (§5.2: "never a single invented readiness score").
/// <see cref="Blocking"/> = an auto-check whose <see cref="StudioAutoCheckDto.Status"/>
/// is <see cref="StudioChecklistStatuses.Blocking"/>; <see cref="ToDo"/> = an
/// unchecked manual item PLUS an auto-check whose status is
/// <see cref="StudioChecklistStatuses.ToDo"/>; <see cref="Done"/> = a passing
/// auto-check or a checked manual item.</summary>
public record StudioReadinessDto(int Blocking, int ToDo, int Done);

public record StudioChecklistResponseDto(
    List<StudioAutoCheckDto> AutoChecks, List<StudioChecklistItemDto> ManualItems, StudioReadinessDto Readiness);

namespace SalesApi.Dtos;

// E3.3 — deal stakeholders. Split into its own file, same reasoning as
// Leads.cs/Accounts.cs's own header comment: one file per domain so the
// Experience layer (reference-free from System) can still see the shape, and
// so two agents adding domains at once don't collide on one shared file.

// One stakeholder on a lead's buying committee: the contact plus the
// lead-specific facts about their role in THIS deal. Embeds the same
// ContactDto every other contact-bearing DTO uses (AccountDetailDto,
// ContactDetailDto) so the client never needs a second GET per row.
// Contact-detail masking (contact_details.view) and custom-field masking
// apply to the embedded ContactDto exactly as they do on GET /contacts/{id}.
public record StakeholderDto(
    Guid Id,
    Guid LeadId,
    ContactDto Contact,
    string? Role,
    string Influence,
    string Sentiment,
    DateTime? LastTouchedAt,
    bool IsPrimary,
    DateTime CreatedAt,
    DateTime UpdatedAt,
    // Contact roles with a per-deal override. Roles = the EFFECTIVE roles (the contact's while RoleSource is "contact", else this
    // deal's own); RoleSource = "contact" (inherited, live) | "deal" (a rep's override) | "frozen" (snapshot taken when the deal
    // closed); ContactRoles = what the contact holds now (so the client can offer "Use contact's roles" and show the difference).
    // Role (above) stays for ONE release as the first effective role.
    List<string>? Roles = null,
    string? RoleSource = null,
    List<string>? ContactRoles = null);

// POST/PATCH /leads/{id}/stakeholders — ContactId is required on add (which
// contact to attach), omitted on update (a stakeholder row's contact is
// fixed once created — swapping the person is remove-then-add, the same
// "no partial identity change" rule Lead.ContactId's own promotion-only
// write path follows). IsPrimary=true on either verb makes this row the
// lead's primary contact (and syncs Lead.ContactId); it never unsets itself
// to false — clearing primary status happens by another row becoming primary.
// Roles: a list of buying-role keys (the org picklist). Sending it (even empty) makes this deal's roles an OVERRIDE
// (role_source "deal"); omitting it leaves them as they are (a new row inherits the contact's). UseContactRoles=true drops
// the override and inherits the contact's roles again (role_source "contact"); sending both is refused.
public record StakeholderInput(
    Guid? ContactId,
    List<string>? Roles,
    string? Influence,
    string? Sentiment,
    DateTime? LastTouchedAt,
    bool? IsPrimary,
    bool? UseContactRoles = null);

// GET /leads/{id}/stakeholders — the committee list plus which of the org's
// required roles (OrgSettings.GetRequiredStakeholderRolesAsync, default
// ["economic_buyer"]) nobody on this lead currently holds.
public record StakeholderListDto(List<StakeholderDto> Stakeholders, List<string> MissingRequiredRoles);

// GET/PUT /settings/buying-roles — mirrors DealTypesInput exactly
// (OrgSettings.GetBuyingRolesAsync).
public record BuyingRolesInput(List<string>? Roles);

// GET/PUT /settings/required-stakeholder-roles — mirrors BuyingRolesInput;
// validated to be a subset of the currently configured buying roles (see
// SettingsProcess.SetRequiredStakeholderRolesAsync).
public record RequiredStakeholderRolesInput(List<string>? Roles);

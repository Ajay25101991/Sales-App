// E5.1 — Deal and account brief (to-do/epics-ai-native-crm.md E5.1 row;
// design doc to-do/e4-ai-platform-design.md §5/§10/§17-18) plus the E5-wide
// AI-feedback frame (design §3's "UserFeedback... E5's accept/edit/reject
// frame", E5.0 design review decision 2's reject-reason policy). Lives in
// SalesApi.Contracts — same reasoning every other AI-platform DTO file here
// gives (Ai.cs, AiExecutionLog.cs, AiContext.cs): the Experience layer needs
// these shapes and cannot see System types.

namespace SalesApi.Dtos;

/// <summary>One citation a brief's reason line points at — the SAME
/// (kind, id) shape <c>AiContextSource</c> already carries (Ai.cs), reduced to
/// what a client needs to render a link: a timeline-sourced citation carries
/// the timeline item's own id to link to; a non-timeline citation (a lead
/// field, a knowledge chunk) carries <see cref="Id"/> null.</summary>
public record LeadBriefEvidenceSourceDto(string Kind, Guid? Id);

/// <summary>One evidence line — the model's stated reason, plus the sources
/// it cited that actually resolved to a real context item. A citation marker
/// the model returned that does not map to any assembled context item is
/// silently dropped from this list, never invented back (build item 2:
/// "drop citations that don't resolve, never invent").</summary>
public record LeadBriefReasonDto(string Text, IReadOnlyList<LeadBriefEvidenceSourceDto> Citations);

/// <summary><see cref="Kind"/> is one of "create_task" | "prepare_outreach" |
/// "none" (the deal-brief v2 output schema's own enum).</summary>
public record LeadBriefRecommendedActionDto(string Kind, string Text);

/// <summary>
/// The one response shape both <c>GET /leads/{id}/brief</c> and
/// <c>POST /leads/{id}/brief/refresh</c> return.
///
/// <see cref="Available"/> false means AI is off for this org — every other
/// field is null and the caller shows nothing at all (owner decision, E5
/// build decisions 2026-09-28: "AI-off hides E5 entirely").
///
/// When <see cref="Available"/> is true, <see cref="Status"/> is one of:
/// "ok" (the brief fields below are populated), "not_enough_history" (too
/// little timeline to brief — no model call was made), or "refused" (the
/// gateway refused before reaching the provider — <see cref="RefusalCode"/>/
/// <see cref="RefusalMessage"/> are set, the server's own message, never a 500).
/// </summary>
public record LeadBriefDto(
    bool Available,
    string? Status,
    string? Momentum,
    string? Summary,
    IReadOnlyList<LeadBriefReasonDto>? Reasons,
    LeadBriefRecommendedActionDto? RecommendedAction,
    string? Confidence,
    DateTime? GeneratedAt,
    Guid? LogEntryId,
    string? RefusalCode,
    string? RefusalMessage)
{
    /// <summary>The single shared "AI is off for this org" answer — every
    /// caller returns this exact instance rather than re-building the
    /// all-null shape, so "available: false" is structurally the only
    /// populated field however many call sites eventually construct it.</summary>
    public static readonly LeadBriefDto Unavailable =
        new(false, null, null, null, null, null, null, null, null, null, null);
}

// --- E5's shared AI-feedback frame (design §3's "UserFeedback"; E5.0 design
// review decision 2's reject-reason policy) — one endpoint, used by every
// E5 AI-output surface, not just the brief. -------------------------------

/// <param name="Verdict">One of <c>Models.AiFeedbackVerdicts.All</c>:
/// "accepted" | "edited" | "rejected".</param>
/// <param name="Reason">Free-text reject reason. Only meaningful (and only
/// ever enforced) when <paramref name="Verdict"/> is "rejected".</param>
/// <param name="ReasonChip">One of the org's configured quick chips, an
/// alternative to (or alongside) <paramref name="Reason"/>.</param>
public record AiFeedbackInput(Guid LogEntryId, string Verdict, string? Reason, string? ReasonChip);

public record AiFeedbackResultDto(Guid LogEntryId, string Verdict, string? Reason, string? ReasonChip);

/// <param name="ReasonPolicy">One of <c>Models.AiFeedbackReasonPolicies.All</c>:
/// "required" | "optional" | "not_asked".</param>
/// <param name="ReasonChips">The quick-chip list shown when rejecting.</param>
public record AiFeedbackSettingsDto(string ReasonPolicy, IReadOnlyList<string> ReasonChips);

public record AiFeedbackSettingsInput(string? ReasonPolicy, IReadOnlyList<string>? ReasonChips);

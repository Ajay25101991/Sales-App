// E22.1 - personal-data export and erasure contracts (UAE PDPL / GDPR data-subject requests for ONE person).
// Own file for the usual reason: the Experience layer cannot see the System layer, so what it returns lives here.
// Wire is snake_case (the host's JSON policy). Nothing in here carries personal data: results name a subject by id only.

namespace SalesApi.Dtos;

/// <summary>Who a request is about. A contact is the normal subject; a lead is a person who was never promoted to a contact.</summary>
public static class PrivacySubjectKinds
{
    public const string Contact = "contact";
    public const string Lead = "lead";
    public static readonly string[] All = [Contact, Lead];
    public static bool IsValid(string? kind) => kind is not null && Array.IndexOf(All, kind) >= 0;
}

/// <summary>The word the erase body must carry. Same idea as the offboarding phrase: an irreversible admin action is never one tap.</summary>
public static class PrivacyConfirmation
{
    public const string Phrase = "ERASE";
}

public record PrivacyEraseInput(string? Confirm);

/// <summary>The temp file a finished export was written to; the controller streams it and deletes it afterwards.</summary>
public record PrivacyExportFileDto(string Path, string Filename, int RowCount, int FileCount);

/// <summary>Rows an erasure kept because an org retention hold has not ended yet, and when they will be erased.</summary>
public record PrivacyHeldItemDto(string Table, string? DocumentType, int Rows, DateTime HeldUntil);

public record PrivacyErasureResultDto(
    string SubjectKind,
    Guid SubjectId,
    int SubjectNumber,
    bool AlreadyErased,
    bool Completed,
    DateTime? NextDueAt,
    int RowsAnonymised,
    int RowsDeleted,
    int FilesDeleted,
    IReadOnlyList<PrivacyHeldItemDto> Held);

/// <summary>One line of the erasure log: who erased which subject, when. The subject is an id and a number - never a name.</summary>
public record PrivacyErasureLogDto(
    Guid Id,
    string SubjectKind,
    Guid SubjectId,
    int SubjectNumber,
    Guid RequestedById,
    DateTime RequestedAt,
    DateTime? CompletedAt,
    DateTime? NextDueAt);

/// <summary>One hold: keep a document type (kind = document_type) or a record kind (kind = record) for this many days after the relationship ends.</summary>
public record PrivacyHoldDto(string Kind, string Key, int Days);

public record PrivacyHoldsDto(IReadOnlyList<PrivacyHoldDto> Holds);

public static class PrivacyHoldKinds
{
    public const string DocumentType = "document_type";
    public const string Record = "record";
}

/// <summary>One table of the personal-data map, as the request screen shows it.</summary>
public record PrivacyMapTableDto(
    string Key,
    string SubjectScope,
    string Link,
    string Treatment,
    IReadOnlyList<string> Columns,
    string? HoldKey);

public record PrivacyMapDto(IReadOnlyList<PrivacyMapTableDto> Tables, IReadOnlyList<string> HoldableRecordKinds, IReadOnlyList<string> NotCovered);

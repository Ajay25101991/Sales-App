// The lead-form SCHEMA MODEL: the shape the designer edits, the API stores, and
// the renderer draws from.
//
// WHY IT LIVES IN CONTRACTS. These four classes are pure data — explicit
// [JsonPropertyName] on every member, no EF, no DbContext — and they are the
// contract three separate things agree on. They sat in
// SystemApi/Services/LeadFormService.cs only because that is where the code
// that reads them lives.
//
// SystemBoundContracts.cs named this exact move as the fix if the lead form
// ever needed an Experience layer: LeadFormDraftDto carries a schema, Experience
// cannot see the System project, so either the model moves down or the boundary
// bends. It moved. The same move unblocks LeadFormsController, which the
// migration plan had listed as BLOCKED for this one reason.
//
// The namespace stays `SalesApi.Services`, so no caller needed a `using` change.
//
// Mirrors packages/core/src/constants/lead-form-fields.ts (the built-in registry
// + resolve) and lib/lead-form-rules.ts (validation). The client uses its copy
// to render; this one decides what the API accepts. Neither trusts the other: a
// schema is re-resolved on every read, and a submitted lead is re-validated
// server-side even though the form already validated it.

using System.Text.Json;
using System.Text.Json.Serialization;

namespace SalesApi.Services;

// Explicit [JsonPropertyName] on every member: these names are a wire contract
// shared with the TS types, not something to leave to a global naming policy.
public class LeadFormConditions
{
    [JsonPropertyName("visible")] public JsonElement? Visible { get; set; }
}

public class LeadFormFieldModel
{
    [JsonPropertyName("key")] public string Key { get; set; } = "";
    [JsonPropertyName("type")] public string Type { get; set; } = "text";
    [JsonPropertyName("label")] public string? Label { get; set; }
    [JsonPropertyName("placeholder")] public string? Placeholder { get; set; }
    [JsonPropertyName("help")] public string? Help { get; set; }
    [JsonPropertyName("visible")] public bool Visible { get; set; } = true;
    [JsonPropertyName("required")] public bool Required { get; set; }
    [JsonPropertyName("required_message")] public string? RequiredMessage { get; set; }
    [JsonPropertyName("options")] public List<string>? Options { get; set; }
    // Width on the rep form's 4-column grid: quarter / half / three_quarter / full (LeadFormWidths).
    // Null in a schema stored before widths existed; Resolve fills the per-type default.
    [JsonPropertyName("width")] public string? Width { get; set; }
    [JsonPropertyName("conditions")] public LeadFormConditions? Conditions { get; set; }
}

public class LeadFormSectionModel
{
    [JsonPropertyName("id")] public string Id { get; set; } = "";
    [JsonPropertyName("title")] public string Title { get; set; } = "";
    [JsonPropertyName("layout")] public List<string> Layout { get; set; } = new();

    // Sections carry the same two visibility controls fields do, and they compose by
    // AND: a field is on the form only if its section is shown and it is shown. That
    // is the only composition that makes hiding a section mean anything — the
    // alternative, where a section is a purely visual grouping, would let an admin
    // "hide" a section while every field in it stayed required and writable.
    [JsonPropertyName("visible")] public bool Visible { get; set; } = true;
    [JsonPropertyName("conditions")] public LeadFormConditions? Conditions { get; set; }
}

public class LeadFormSchemaModel
{
    [JsonPropertyName("version")] public int Version { get; set; } = 1;
    [JsonPropertyName("sections")] public List<LeadFormSectionModel> Sections { get; set; } = new();
    [JsonPropertyName("fields")] public Dictionary<string, LeadFormFieldModel> Fields { get; set; } = new();
}

/// <summary>
/// The four widths a field may take on the rep form's 4-column grid (owner decision 8, 2026-10-16).
/// Phones ignore it and show every field full width.
/// </summary>
public static class LeadFormWidths
{
    public const string Quarter = "quarter";
    public const string Half = "half";
    public const string ThreeQuarter = "three_quarter";
    public const string Full = "full";

    public static readonly string[] All = { Quarter, Half, ThreeQuarter, Full };

    public static bool IsValid(string? width) => width is not null && All.Contains(width);
}

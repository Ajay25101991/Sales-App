namespace SalesApi.Dtos;

/// <summary>
/// The value permission (<c>lead_values.view</c>) applied to the generator's reads, at the DTO edge. A caller without it sees every
/// money figure as NULL - never 0, which would read as a real amount - in the same way the lead's own EstimatedValue is withheld
/// (<c>LeadMapping.ToDto</c>). Pure DTO code so the Experience layer, which cannot see the System layer, can apply it.
///
/// What counts as money here: the version's totals and deal value, the stored one-line change summary (it quotes figures), the frozen
/// snapshot echo (prices, results, totals), and in a diff every total, every service's deal value, every result of format "money"
/// and every input of type "money" or "choice" (a choice's number is a price; what was picked, as words, is not money). Quantities (TINs, add-on on/off), service names and template versions are not money.
///
/// The whole of a deal-scoped quote read (<see cref="ProposalDto"/>) follows the same rule (owner 2026-10-15): Total, Subtotal, DiscountAmount,
/// TaxAmount, the unit prices in line items and modules, the document text (it prints the figures), and the generator's snapshot and change
/// summary are null. The VAT RATE is a percentage, not money, and stays. The customer's own accept page uses its own DTO and is not masked.
/// </summary>
public static class ProposalMasking
{
    public static ProposalDto Mask(ProposalDto p, bool canSeeValues) =>
        canSeeValues ? p : p with
        {
            Content = null, Total = null, Subtotal = null, DiscountAmount = null, TaxAmount = null,
            Modules = NullPrices(p.Modules), LineItems = NullPrices(p.LineItems),
            Snapshot = null, ChangeSummary = null,
        };

    private static readonly string[] PriceKeys = ["price", "unit_price", "amount"];

    /// <summary>The array with every price property set to null (quantity, description and names stay). Anything that is not an array of objects passes through.</summary>
    private static System.Text.Json.JsonElement NullPrices(System.Text.Json.JsonElement e)
    {
        if (e.ValueKind != System.Text.Json.JsonValueKind.Array) return e;
        var node = System.Text.Json.Nodes.JsonNode.Parse(e.GetRawText());
        if (node is not System.Text.Json.Nodes.JsonArray array) return e;
        foreach (var item in array.OfType<System.Text.Json.Nodes.JsonObject>())
            foreach (var key in PriceKeys)
                if (item.ContainsKey(key)) item[key] = null;
        return System.Text.Json.JsonSerializer.SerializeToElement(array);
    }

    public static List<ProposalDto> Mask(List<ProposalDto> list, bool canSeeValues) =>
        canSeeValues ? list : [.. list.Select(p => Mask(p, false))];

    public static ProposalVersionDto Mask(ProposalVersionDto v, bool canSeeValues) =>
        canSeeValues ? v : v with { ChangeSummary = null, Total = null, DealValue = null, Year1 = null, Year2 = null };

    public static List<ProposalVersionDto> Mask(List<ProposalVersionDto> list, bool canSeeValues) =>
        canSeeValues ? list : [.. list.Select(v => Mask(v, false))];

    public static ProposalGeneratedDto Mask(ProposalGeneratedDto g, bool canSeeValues) =>
        canSeeValues ? g : g with { Proposal = Mask(g.Proposal, false), Version = Mask(g.Version, false) };

    public static ProposalDiffDto Mask(ProposalDiffDto d, bool canSeeValues)
    {
        if (canSeeValues) return d;
        var masked = d with
        {
            ServicesAdded = [.. d.ServicesAdded.Select(s => s with { DealValue = null })],
            ServicesRemoved = [.. d.ServicesRemoved.Select(s => s with { DealValue = null })],
            InputChanges = [.. d.InputChanges.Select(i => i.Type is "money" or "choice" ? i with { From = null, To = null } : i)],
            ResultChanges = [.. d.ResultChanges.Select(r => r.Format == "money" ? r with { From = null, To = null } : r)],
            Totals = [.. d.Totals.Select(t => t with { From = null, To = null })],
        };
        return masked with { Summary = ProposalSnapshotDiff.Summarise(masked, includeMoney: false) };
    }
}

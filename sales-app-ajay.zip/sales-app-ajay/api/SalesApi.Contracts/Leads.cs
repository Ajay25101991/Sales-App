using System.Text.Json;
using System.Text.Json.Serialization;

// The Leads contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// E3.11 — one entry in the 409 `open_deal_exists` refusal's `open_deals` list
// (LeadWriteProcess) and in the `deals` array a lead can no longer create over
// silently. StageLabel is the matched lead's OWN playbook's label for its
// current status, never the org-wide one — see DuplicateMatchService.
public record OpenDealDto(Guid Id, string Name, string StageLabel, string? OwnerName, string? Company = null);

// E6.4 (design doc to-do/e6-connectors-design.md, owner answer 2026-09-29) —
// the CLOSED lead an unattended-intake submission (LinkedIn today) matched,
// carried far enough for the caller to build a repeat-business "new
// opportunity" the same way the interactive client's own "New deal like
// this" does: link the same account/contact, hint the deal type, and
// reference the earlier deal by name on the new lead's timeline. See
// DuplicateMatchService.FindMostRecentClosedMatchAsync.
public record ClosedMatchDto(Guid LeadId, string LeadName, Guid? AccountId, Guid? ContactId, bool IsWon);

// GET /contacts/{id}/deals — E3.11's contact timeline: every deal for this
// person, open and closed, newest first. Value is null (never 0) for a caller
// without lead_values.view, same masking convention every other money figure
// in this API follows.
//
// E3.11e — Role/IsPrimary added (additive, appended at the end): every deal
// this contact is linked to via `lead_contacts` (StakeholderProcess's own
// table, not just the lead's primary Lead.ContactId shortcut), so a
// non-primary stakeholder's deals show up here too. Role null means "primary
// contact with no role recorded" (StakeholderStore/StakeholderProcess's own
// reading of a null Role) or, for a lead created before roles existed, simply
// "no role set" — the client cannot tell those apart and does not need to.
public record ContactDealDto(
    Guid Id, string Name, string StageLabel, string? DealType, decimal? Value, DateTime CreatedAt,
    DateTime? WonAt, DateTime? LostAt, string? Role, bool IsPrimary, string? Company = null,
    // Every EFFECTIVE role the contact holds on that deal (contact roles with a per-deal override); Role above = the first, kept one release.
    List<string>? Roles = null);

// --- Leads ---
public record LeadDto(
    Guid Id,
    Guid? OwnerId,
    string Name,
    string? Company,
    string? Email,
    string? Phone,
    string Status,
    string Priority,
    string? Source,
    decimal? EstimatedValue,
    string? Notes,
    DateTime? NextFollowUpAt,
    DateTime CreatedAt,
    DateTime UpdatedAt,
    string? OwnerName,
    JsonElement Custom,
    Guid? AccountId,
    string? AccountName,
    string? CloseReason,
    List<string> Products,
    string? Address,
    string? City,
    string? State,
    string? PostalCode,
    string? Country,
    string? Nationality,
    DateTime? ExpectedCloseDate,
    // Set once when the lead first becomes "won", and its counterpart LostAt
    // when it first becomes "lost". WonAt was MISSING here while LostAt was
    // present, so `won_at` was never serialised on any lead read and the Lead
    // dates screen's Won column rendered "—" for every won lead in the org. The
    // column was not broken and the data was not missing — CSV export has always
    // carried it — the field simply never left the API.
    DateTime? WonAt,
    DateTime? LostAt,
    // Time-in-stage (B2/Part 2) — days since the latest recorded LeadStageEvent
    // for this lead. Null (not 0) when the lead has no stage-event history at
    // all — either it predates stage-event capture and was never backfilled, or
    // the backfill hasn't run — so the client must render "not enough data"
    // rather than a misleading "0 days". Only populated on GET /leads/{id}
    // (LeadsController.Get) — list/create/update responses leave it null.
    int? DaysInStage = null,
    // Payment workflow (PaymentWorkflowService) — the chosen term and its
    // derived due date. Not amounts, so returned unconditionally regardless of
    // ViewLeadValues (unlike EstimatedValue above).
    string? PaymentTermKey = null,
    DateTime? PaymentDueDate = null,
    // Empty (never null) when a caller doesn't ask for tags to be loaded — see
    // LeadsController.ToDto's `tags` parameter.
    List<TagRefDto>? Tags = null,
    // Set only by POST /leads/{id}/promote-contact (ContactPromotionService) —
    // never by this DTO's own input twin, LeadInput, which has no ContactId.
    Guid? ContactId = null,
    // D10a — which playbook this lead is on, and whether that came from
    // matching or a person (Lead.PlaybookSource/PlaybookId, verbatim). Null
    // PlaybookId is the normal D4 "no rule matched, nothing picked" state.
    Guid? PlaybookId = null,
    string? PlaybookSource = null,
    // Set ONLY by Create/Update, and only when this request carried an
    // explicit pick that Setting 1 (rules_win) refused to apply because a
    // rule had already matched or the lead already carried a playbook — the
    // UI-must-say requirement D10a leads with. Never populated on a plain
    // read (GET), where there is no pick in flight to report on.
    string? PlaybookPickNote = null,
    // Country/nationality picker (alpha-2). Same ViewContactDetails gating and
    // same "free text stays" rule as Country/Nationality above — see
    // Lead.CountryCode's comment. NationalityCodes is plural: dual nationality
    // is real in the data.
    string? CountryCode = null,
    List<string>? NationalityCodes = null,
    // ISO 3166-1 alpha-2 for Phone above — see Lead.PhoneCountryCode. Same
    // ViewContactDetails gating as Phone/Email/Country/CountryCode. Null means
    // either "no country recorded" or "captured before this field existed";
    // the two are indistinguishable and both mean Phone is whatever was typed
    // (no dial prefix assumed either way).
    string? PhoneCountryCode = null,
    // Which team this lead belongs to. Set once at creation
    // (TeamService.ResolveLeadTeamAsync) and changed only by an explicit move -
    // it deliberately does not follow the owner. Null is a REAL state, not a
    // loading one: a lead created by someone in no team, or in two teams when
    // the org has no default team, lands there and is then invisible to every
    // team-scoped view. Surfaced so that is legible instead of inferred.
    Guid? TeamId = null,
    // Null when the caller did not load the Team navigation - the list query
    // deliberately does not, since it draws no team column. TeamId above is a
    // scalar and is ALWAYS accurate; a null name never means "no team".
    string? TeamName = null,
    // S5 correction — whether this lead has EVER had a logged activity or a
    // recorded stage change (LeadWorkStatusService, the same predicate every
    // server idle count/filter already excludes a never-worked lead with).
    // Null, not false, when not computed for this response — see
    // LeadListProcess.ToDto's own comment for which endpoints populate it
    // (GET /leads list/paged and GET /leads/{id}; never create/update,
    // mirroring DaysInStage's own null-means-not-computed convention above).
    // The client's `isIdle` MUST treat null the same as false (never idle) —
    // never assume "worked" from an absent fact.
    bool? HasBeenWorked = null,
    // E3.11 — new | renewal | upsell | cross_sell, from the org's configurable
    // deal_types picklist (OrgSettings.GetDealTypesAsync). Null reads as "new"
    // (Lead.DealType's own doc comment) so every lead created before this
    // shipped is unaffected.
    string? DealType = null,
    // E5.6 deal risk — low|medium|high, or null. ALWAYS null while AI is not
    // configured for the org (owner decision, "E5 build decisions" item 2:
    // "every E5 feature is hidden entirely" until AI is set up) and for any
    // lead with no LeadRisk row (closed leads never get one; an open lead
    // whose first sweep/on-change compute hasn't run yet). Additive: list
    // filtering/sorting by risk is explicitly NOT in this slice (story brief
    // item 7). Populated on GET /leads list/paged and GET /leads/{id} only —
    // same "not on create/update" convention DaysInStage/HasBeenWorked above
    // already follow.
    string? RiskLevel = null,
    // Built-in Closed value (owner decision 2026-10-02) — see LeadInput.
    // ClosedValue and Lead.ClosedValue's own doc comments. Masked by the same
    // ViewLeadValues permission as EstimatedValue (never contact_details.view
    // — it is a money figure, not contact information), and null for every
    // lead that has never been sold, exactly like EstimatedValue reads null
    // when masked rather than 0 — a masked money figure must not be
    // renderable as a real amount.
    decimal? ClosedValue = null,
    // Accounts rework (L1/L3): the ONE shared last-contact rule (LastContactService) and the soonest next step
    // (NextStepService). Populated on GET /leads list/paged and GET /leads/{id}; null elsewhere. Last contact is null when
    // the deal has never been in contact (the client shows created-at-based "never").
    DateTime? LastContactAt = null,
    NextStepDto? NextStep = null,
    // Accounts rework (lead page): for a LOST deal, the stage it was lost FROM - the target of "Reopen" (latest stage event into the
    // current stage, its from-status; null when not lost or not recoverable). Populated on GET /leads/{id} only.
    string? LostFromStage = null,
    // E10.7 Potential value: the first proposal version's deal value, stored once. Masked by lead_values.view like
    // EstimatedValue (null when masked, and null for a deal that never had a generated proposal).
    decimal? PotentialValue = null,
    // E12.2 - field key -> level for every field the caller does not hold at full (see to-do/sensitive-data-api.md section 3).
    Dictionary<string, string>? FieldAccess = null,
    // E12.5 - category -> the instant an approved reveal stops applying to THIS record for this caller (absent = no active reveal).
    Dictionary<string, DateTime>? RevealExpiresAt = null,
    // The deal's PARTNER account (the third party of a tri-party agreement): its id and name, like AccountId / AccountName.
    // Null when the deal has none. Not masked - an account link is not contact information.
    Guid? PartnerAccountId = null,
    string? PartnerAccountName = null,
    // The "Partner" lead-form field (source_partner), read side - what the form pre-fills on edit. The picked partner (the deal's active
    // referrer, else its document partner), its name and the role that partner holds on this deal (LeadSourcePartnerRoles). All null when
    // the deal has neither. Populated on GET /leads/{id} and on create/update responses; null on list rows.
    Guid? SourcePartnerId = null,
    string? SourcePartnerName = null,
    string? SourcePartnerRole = null,
    // Bug 2 (owner 2026-10-26): the proposal accepted on this deal (the latest accepted one), for the "Proposal accepted" badge. Populated on
    // GET /leads/{id} only; null when no proposal on the deal is accepted.
    AcceptedProposalDto? AcceptedProposal = null,
    // Who added the lead (Lead.CreatedById): the typist, the importer of a CSV upload, null for a web-form lead or one that
    // predates the column. Drives the "Created by" column; the name comes from that column's own people options.
    Guid? CreatedById = null);

/// <summary>The role a rep picks for the partner on the "Partner" lead-form field (wire values of source_partner_role / LeadDto.SourcePartnerRole).</summary>
public static class LeadSourcePartnerRoles
{
    /// <summary>Added to the deal's partners as its referrer (origin sourced), on the partner's own plan else the no-terms plan.</summary>
    public const string Referrer = "referrer";
    /// <summary>The above AND the deal's document partner (Lead.PartnerAccountId).</summary>
    public const string ReferrerAndDocument = "referrer_and_document";
    /// <summary>Only the deal's document partner (Lead.PartnerAccountId).</summary>
    public const string Document = "document";
    /// <summary>Added to the deal's partners as its reseller (origin sourced; a reseller-type partner only), on the partner's own plan when it fits the role else the no-terms plan.</summary>
    public const string Reseller = "reseller";
    public static readonly string[] All = [Referrer, ReferrerAndDocument, Document, Reseller];
    public static bool IsValid(string? role) => role is not null && Array.IndexOf(All, role) >= 0;
}

/// <summary>
/// What POST /leads/backfill-team did, or would do with preview=true.
///
/// Every count is reported rather than folded into one number, because the
/// skips are the interesting part: an ambiguous lead is one a person still has
/// to decide about, and an owner-in-no-team lead says the roster is the problem,
/// not the leads.
/// </summary>
public record LeadTeamBackfillDto(
    bool Preview,
    int Updated,
    int SkippedNoOwner,
    int SkippedOwnerInNoTeam,
    int SkippedOwnerInSeveralTeams,
    /// <summary>
    /// Stale leads still needing repair AFTER this call — the loop condition for
    /// a batched run (`limit`), and the reason it is honest to call again.
    ///
    /// Never reaches 0 while any lead is unresolvable: a skipped lead stays
    /// stale by definition, and no number of further calls will change that.
    /// Drive the loop on <see cref="Updated"/> + <see cref="ClearedFromArchivedTeam"/>
    /// being 0 — no progress — and read this to see what a person still has to
    /// decide about.
    /// </summary>
    int RemainingTeamless,
    /// <summary>
    /// Leads that were sitting in an ARCHIVED team and could not be resolved to a
    /// live one, so they were cleared to no team. Not a repair — a rescue: an
    /// archived team is filtered out of every visibility read
    /// (TeamService.LoadScopeAsync), so a lead left pointing at one would vanish
    /// for everyone but its owner. "No team" is at least findable, via the Leads
    /// screen's own filter.
    ///
    /// Coupled to that filter, deliberately: if it is ever removed again, this
    /// rescue becomes a HARM — clearing narrows a lead to its owner and org
    /// admins, whereas leaving it in the archived team keeps it visible to that
    /// team. Both moved together once already.
    /// </summary>
    int ClearedFromArchivedTeam = 0);

// One entry in a lead's stage-transition history (GET /leads/{id}/stage-history),
// oldest first. FromStatus is null for a lead's earliest recorded transition —
// either it had no prior stage or the backfill couldn't recover one; the client
// must not render that as "started in no stage", just as the first known state.
// IsBackfilled marks rows reconstructed from historical LeadActivity text
// (DbInitializer.BackfillStageEventsAsync) rather than recorded live — their
// ChangedAt is best-effort, not exact.
public record LeadStageEventDto(
    Guid Id, string? FromStatus, string ToStatus, DateTime ChangedAt,
    string? ChangedByName, bool IsBackfilled);

// Partial input for create/update. Null = field not provided.
/// <summary>
/// POST /leads/playbook-preview — the playbook a lead with these values WOULD
/// land on if created now, so the new-lead form can offer that playbook's own
/// stages. Null <c>PlaybookId</c> means the org-wide stage list applies.
/// <c>Note</c> carries what the create would say about it: a pick a rule
/// overrode, or a pick the server would refuse.
/// </summary>
public record LeadPlaybookPreviewDto(Guid? PlaybookId, string? PlaybookName, string? Note);

/// <summary>
/// POST /leads/form-preview — the resolver inputs a client CAN know ahead of a
/// submit: which account the lead would land on (mirrors LeadInput.AccountId,
/// same field LeadFormRoutingService.ResolveForCreateAsync takes), and, only
/// consulted under LeadFormSourcePolicy.RepChoice, an explicit pick. The owner
/// is never a parameter here — LeadWriteProcess.CreateAsync always captures
/// the CALLER as owner, never a reassigned one, so the resolver's `ownerId`
/// is always the caller too (see LeadFormRoutingService.ResolveForCreateAsync's
/// own remarks on this point).
/// </summary>
public record LeadFormForCreateInput(Guid? AccountId, Guid? LeadFormId, Guid? TeamId = null);

/// <summary>One form a rep_choice caller may pick instead, for the picker
/// LeadFormResolutionDto.Choices offers under that policy.</summary>
public record LeadFormChoiceDto(Guid Id, string Name);

/// <summary>
/// E3.12 — "the form shown is the form checked". What GET/POST /leads/form-preview
/// and GET /leads/{id}/form return: the SAME form LeadWriteProcess.CreateAsync/
/// UpdateAsync itself would validate against right now, already masked for the
/// caller's role (LeadFormService.FilterForCaller — the same filter GET
/// /settings/lead-form already applies), plus which form it is and, under
/// LeadFormSourcePolicy.RepChoice, what else the caller could pick instead.
///
/// <c>Blocked</c> mirrors LeadFormRoutingService.CreateFormResolution: true
/// means creation is refused right now (lead_form_no_playbook = block) and
/// <c>FormId</c>/<c>FormName</c>/<c>Schema</c> are all null. The edit variant
/// (GET /leads/{id}/form) never sets it — ResolveForLeadAsync always falls
/// back to the Default form rather than refuse, since the lead already exists.
/// </summary>
public record LeadFormResolutionDto(
    Guid? FormId,
    string? FormName,
    Services.LeadFormSchemaModel? Schema,
    bool Blocked,
    string? BlockReason,
    List<LeadFormChoiceDto>? Choices = null);

public record LeadInput(
    string? Name,
    string? Company,
    string? Email,
    string? Phone,
    string? Status,
    string? Priority,
    string? Source,
    decimal? EstimatedValue,
    string? Notes,
    DateTime? NextFollowUpAt,
    string? Reason,
    JsonElement? Custom,
    Guid? AccountId,
    string? CloseReason,
    List<string>? Products,
    string? Address,
    string? City,
    string? State,
    string? PostalCode,
    string? Country,
    string? Nationality,
    DateTime? ExpectedCloseDate,
    // Payment workflow: capture the chosen term at close time. DueDate is
    // normally left for the server to derive (PaymentWorkflowService.
    // ComputeDueDate); an explicit override is accepted but rarely needed.
    string? PaymentTermKey = null,
    DateTime? PaymentDueDate = null,
    // The caller's answer to an account-link question the server previously refused
    // this same edit over (LeadsController.Update → AccountLinkService).
    //
    // Required rather than inferred, because the two things it disambiguates are
    // indistinguishable from the payload alone: "Acme Ltd" arriving on a lead linked
    // to "Acme Holdings" could mean link them, or could mean these are two companies
    // that happen to normalise alike. The payload cannot say which; only the person
    // editing can, so the server refuses until they have.
    //
    // Choice is one of AccountLinkService.Choices; AccountId is required by
    // "link_existing" and must name one of the candidates the refusal offered.
    // Which of the OWNER'S OWN teams this lead belongs to. Honoured only when
    // the owner is actually a member of it (TeamService.ResolveLeadTeamAsync's
    // first rung checks exactly that), so this is not a second source of truth
    // competing with the owner - it narrows within what the owner already has.
    //
    // Absent means "decide for me": their single team, or their primary when
    // they are in several. Only someone in more than one team is ever asked.
    Guid? TeamId = null,
    AccountLinkDecisionInput? AccountLinkDecision = null,
    // Tags: same replace/leave-unchanged semantics as AccountLinkDecision's
    // neighbours. Present (either array non-null, even empty) means "replace the
    // lead's tags with exactly this set"; both null/absent means "don't touch
    // tags". Sending only TagNames must still read as present — see
    // LeadsController.Update, which checks `TagIds is not null || TagNames is
    // not null`, never either array alone.
    Guid[]? TagIds = null,
    string[]? TagNames = null,
    // D10a — an explicit playbook pick from the create/edit form or the
    // unassigned-lead flow. Absent means "no pick"; the server never
    // distinguishes "explicitly cleared" from "not sent" here because there
    // is no clearing gesture in D10a — a lead's playbook only ever gets SET.
    // Whether this wins over a rule match is Setting 1
    // (PlaybookPolicyService); whether the caller may send it at all is
    // Setting 2, both enforced server-side, never trusted from the client.
    Guid? PlaybookId = null,
    // D2 — the rep's explicit form pick, consulted only under
    // LeadFormSourcePolicy.RepChoice (LeadFormRoutingService.ResolveForCreateAsync).
    // Ignored under every other lead_form_source value, and ignored on Update
    // (a lead's form is resolved by lead_form_pinning there, not chosen per
    // request).
    Guid? LeadFormId = null,
    // Country/nationality picker (alpha-2) — see LeadDto's twin fields. Null
    // means "not provided" (leaves the stored code alone), matching every
    // other optional field on this record; there is no separate clearing
    // gesture, same as PlaybookId above.
    string? CountryCode = null,
    List<string>? NationalityCodes = null,
    // ISO 3166-1 alpha-2 for Phone — see LeadDto's twin field and
    // Lead.PhoneCountryCode. Null means "not provided" (leaves the stored
    // code alone), same as every other optional field here. For a NEW record
    // the client sends Phone without the dial prefix once this is set.
    string? PhoneCountryCode = null,
    // E3.11 — "new deal from a contact/account": create pre-fills and LINKS
    // directly, no promotion round-trip. Validated server-side (LeadWriteProcess)
    // to belong to AccountId (when both are sent) and to be visible to the
    // caller; name/email/phone/company default from the contact+account when
    // the caller did not supply their own. Update never accepts this — Lead.ContactId
    // is otherwise set only by ContactPromotionService — so a contact link, once
    // made, only moves via promotion or the account-link machinery, never a
    // plain PATCH.
    Guid? ContactId = null,
    // E3.11 — new | renewal | upsell | cross_sell (org-configurable picklist,
    // OrgSettings.GetDealTypesAsync). Null on create defaults to "new"; on
    // Update, null means "leave unchanged" like every other optional field here.
    string? DealType = null,
    // E3.11 — the caller has already seen the `open_deal_exists` refusal (or
    // its equivalent list on Update) and chose "Create anyway". Ignored unless
    // an open match actually exists; a stray true on an ordinary create/edit
    // does nothing.
    bool ConfirmDuplicate = false,
    // E3.11 — pre-select "renewal" when this create was started from a won
    // deal or an AMC (LeadWriteProcess.ResolveDealTypeAsync). Neither is a
    // foreign key enforced here; both are pure UI hints the server uses only
    // to CHOOSE a default deal type when the caller sent none.
    Guid? SourceLeadId = null,
    Guid? SourceAmcId = null,
    // E3.12 — "the form shown is the form checked". The form id the caller's
    // screen actually rendered and validated against, from a prior GET
    // /leads/form-preview (or /leads/{id}/form on Update). Absent for every
    // caller that never previewed a form at all — CSV import, the inbound
    // webhook, auto-routing, merge, and any client build that predates this
    // field — so its absence changes nothing for them.
    //
    // When present, LeadWriteProcess re-resolves the form itself (the same
    // resolver the preview endpoint called) and REFUSES with `form_changed`
    // if the answer no longer matches this value, rather than silently
    // validating the payload against a different form than the one the rep
    // saw. This is what keeps the two paths from drifting even though each
    // resolves independently: team assignment, the routing policy, or (under
    // rep_choice) the chosen form's own archival can all change in the gap
    // between the preview and the submit.
    Guid? ExpectedLeadFormId = null,
    // Built-in Closed value (owner decision 2026-10-02) — what this deal
    // actually closed at, distinct from EstimatedValue (the running estimate).
    // Null/absent means "not provided" like every other optional field here:
    // on a request that moves the lead into a sold phase, LeadWriteProcess
    // (via Apply() then StageService.SyncCloseDates) applies this if sent, and
    // otherwise defaults Lead.ClosedValue to EstimatedValue — see Lead.
    // ClosedValue's own doc comment. On a request that does NOT close the
    // lead, this behaves exactly like EstimatedValue: an ordinary field write,
    // audited the same way (FieldAudit.TrackedFields).
    decimal? ClosedValue = null,
    // Lead page: an explicit "clear the follow-up date" (null NextFollowUpAt means "not sent" on this record). Mirrors the
    // ClearPlaybook / ClearUnassignedTeam flags. A NextFollowUpAt sent in the same request wins. Deliberately not audited
    // (owner decision 2026-10-15: the follow-up date is not a FieldAudit field).
    bool ClearNextFollowUp = false,
    // The deal's partner account: a plain pick (no company-name matching, unlike AccountId). Null = not sent, leave as is;
    // ClearPartnerAccount removes it (a PartnerAccountId sent in the same request wins). It must be an account of this
    // organisation (it MAY be the deal's own client account).
    Guid? PartnerAccountId = null,
    bool ClearPartnerAccount = false,
    // The "Partner" lead-form field (source_partner): the picked partner account and its role on THIS deal (LeadSourcePartnerRoles).
    // Sent together or not at all (absent = leave as is). The role is applied through the channel-partner attribution path (referrer)
    // and the PartnerAccountId path (document partner) - see LeadWriteProcess.SourcePartnerAsync.
    Guid? SourcePartnerId = null,
    string? SourcePartnerRole = null,
    // Item 6 (owner 2026-10-26) - on a stage move: who gets each "rep picks" stage task, { task definition id: user id }. Each user must be a
    // member of a team the MOVER belongs to (GET /leads/{id}/stage-tasks lists them). Missing = the deal owner. Ignored when the stage does not change.
    Dictionary<string, Guid>? StageTaskAssignees = null,
    // Parked item 7 (owner 2026-10-27) - on a move to the Won stage whose workflow asks for values (GET /leads/{id}/win-ask): the answers. Folded into
    // closed_value / custom / payment_term_key before the gate check, so they are judged and written exactly like those fields. Ignored when the ask does not apply.
    WinValuesInput? WinValues = null);

public record AccountLinkDecisionInput(string? Choice, Guid? AccountId);

// Team-defined win/loss reason taxonomy + a breakdown report.
public record CloseReasonsDto(List<string> Won, List<string> Lost);
public record CloseReasonsInput(List<string>? Won, List<string>? Lost);
public record LeadSourcesInput(List<string>? Sources);
// E3.11 — mirrors LeadSourcesInput exactly for OrgSettings.GetDealTypesAsync.
public record DealTypesInput(List<string>? Types);

// §44 — whether `source` is required on the two paths with no human to ask
// (the public inbound endpoint and CSV import). `Mode` is "off" | "required" |
// "defaulted"; `Default` is populated only for "defaulted", and is always one
// of the org's currently configured lead_sources (see
// SettingsController.SetLeadSourcePolicy) — a default can never be a value the
// dropdown would reject. Manual capture (the lead form, the card scanner) is
// governed by the existing per-field `required` flag on the lead form schema
// instead — a human is present there to ask, which is the exact mechanism that
// flag already exists for; this policy is deliberately scoped to the paths
// that flag does NOT reach (LeadFormService.MissingRequired is only enforced
// in LeadsController.Create).
public record LeadSourcePolicyDto(string Mode, string? Default);
public record LeadSourcePolicyInput(string? Mode, string? Default);

// What reads a lead source / custom field, and what stops working without it —
// see LeadTaxonomyUsageService, which derives all of this. `Removability` is a
// token ("safe" | "in_use" | "gate"); the client turns it into a label and a
// theme colour, but the judgement itself is the server's.
public record LeadSourceUsageDto(
    string Name, int LeadCount, List<string> ReadBy, string RemovalImpact, string Removability);
public record CustomFieldUsageDto(
    Guid Id, string Key, string Label, string Type, int LeadCount,
    List<string> ReadBy, List<string> StageGates, string RemovalImpact, string Removability);
public record LeadTaxonomyUsageDto(List<LeadSourceUsageDto> Sources, List<CustomFieldUsageDto> Fields);
// Value is null (never 0) for a caller without lead_values.view — see
// LeaderboardRowDto for why a masked money figure must not be renderable.
public record ReasonBucket(string Reason, int Count, decimal? Value);
public record WinLossDto(int WonCount, decimal? WonValue, int LostCount, decimal? LostValue, List<ReasonBucket> LostReasons, List<ReasonBucket> WonReasons);

// --- Merge preview (read-only, computed before any write) ---
public record MergeFieldPreview(
    string Field, string Label, string? PrimaryValue, string? DuplicateValue, string? SurvivorValue, bool DuplicateValueDiscarded);
public record MergeCounts(int Activities, int Attachments, int Reminders, int Approvals, int Invoices, int Proposals, int Amcs);
public record MergePreviewDto(LeadDto Primary, LeadDto Duplicate, List<MergeFieldPreview> Fields, MergeCounts Counts);

// Result of a merge write: the merged lead plus enough to offer + perform an
// undo (see LeadsController.UndoMerge). ExpiresAt is MergedAt + the undo window.
public record MergeResultDto(LeadDto Lead, Guid MergeId, DateTime MergedAt, DateTime ExpiresAt);

// Pre-merge snapshot of the primary's mergeable fields — restored verbatim by undo.
public record MergeSnapshotDto(
    string? Company, string? Email, string? Phone, string? Source, string? Notes, decimal EstimatedValue, Guid? AccountId,
    // Built-in Closed value (owner decision 2026-10-02) — appended at the end,
    // defaulted, so an existing serialized snapshot (log row written before
    // this field existed) still deserializes: UndoMerge then restores null,
    // which is correct for a merge that happened before ClosedValue existed.
    decimal? ClosedValue = null);

// --- Activities ---
// AuthorId is null for a website-intake note appended to an open deal (E3.11
// unattended-paths follow-up, 2026-09-26) — see LeadActivity.AuthorId. This
// raw per-lead list carries no author NAME (the lead detail screens that read
// it render only body/timestamp, never an author), so a null id needs no
// client-side change; the unified timeline (TimelineItemDto) is what renders
// "Website form".
// Accounts rework: LeadId is null for an ACCOUNT-level activity (one logged on the company itself); AccountId is the account
// the activity belongs to (set for those, and stamped on a lead activity when its lead has an account). Both additive.
public record ActivityDto(Guid Id, Guid? LeadId, Guid? AuthorId, string Type, string? Body, DateTime CreatedAt, Guid? AccountId = null);
// NextFollowUpAt (L6): sets the lead's next follow-up in the same step as logging.
public record ActivityInput(string? Type, string? Body, DateTime? NextFollowUpAt = null);

// Unified team activity feed row (lead + invoice activity). Kind = lead|invoice.
// ActorId is null only for a Kind="lead" row sourced from a website-intake
// note (E3.11 unattended-paths follow-up, 2026-09-26 — see
// LeadActivity.AuthorId); Actor already carries the literal "Website form" for
// that row, so an existing client's `actor ?? 'Someone'` fallback never fires
// for it.
public record FeedItemDto(string Kind, Guid? ActorId, string? Actor, string Type, string? Body, string? Subject, Guid EntityId, DateTime CreatedAt);

/// <summary>
/// How a caller renders a lead: the permission facts the lead mapper needs,
/// resolved ONCE per request and carried as data.
///
/// WHY IT LIVES IN CONTRACTS. It started as two booleans — no EF, no HTTP,
/// nothing that knows how a lead is stored — and it appears on Process
/// signatures, which may not name a System type. It first shipped inside the
/// Process layer with a convenience `ToDto(Lead)` hanging off it;
/// `LayerBoundaryTests` refused that immediately and was right to, because a
/// Process surface naming the entity is exactly how an entity becomes the
/// contract. The mapping stayed with the mapper in the System layer; only the
/// facts travel.
///
/// <see cref="CallerRole"/> (E3.1b) is the third fact: which of a lead's
/// custom-field values <c>LeadMapping.ToDto</c>/<c>CustomFieldMasking</c> may
/// show this caller. A plain string, same reasoning as the two booleans above
/// — a role name is not a System type either. Defaults to "" (fail-closed:
/// see <c>CustomFieldMasking.IsVisibleTo</c>'s own default) so the two
/// existing 2-arg call sites in <c>SalesApi.Tests</c> keep compiling.
/// </summary>
public readonly record struct LeadView(bool CanSeeContactDetails, bool CanSeeValues, string CallerRole = "", SalesApi.Services.SensitiveAccess? Sensitive = null);

// --- GET /leads/facets ---
//
// How many leads each filter option would match, so the filter sheet can show
// "Qualified (12)" and grey out the options that would return nothing instead of
// making the user tap to find out.
//
// Named records rather than the anonymous objects these were, because the
// Experience layer has to return them. The wire shape is unchanged —
// JsonNamingPolicy.SnakeCaseLower renders these as the same keys.
//
// PRODUCT is deliberately absent: Lead.Products is a text[], so counting per
// product needs an unnest/lateral EF Core cannot express, and one COUNT per
// catalogue entry would be a query per product.
public record FacetCountDto(string Key, int Count);

public record LeadFacetsDto(
    IReadOnlyList<FacetCountDto> Status,
    IReadOnlyList<FacetCountDto> Owner,
    IReadOnlyList<FacetCountDto> Source);

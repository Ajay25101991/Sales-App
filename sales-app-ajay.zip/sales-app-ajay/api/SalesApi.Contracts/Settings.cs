using System.Text.Json;
using System.Text.Json.Serialization;

// The Settings contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Settings (team-wide) ---
// LeadVisibility controls how much of other reps' leads a salesperson can see:
// "own" (default) | "view" (see all, edit only own) | "manage" (full access).
public record SettingsDto(string LeadVisibility);
public record SettingsInput(string? LeadVisibility);
public record SlaInput(int? IdleDays);
/// <summary>One of OrgSettings.ContactPromotionModes.</summary>
public record ContactPromotionInput(string? Mode);

/// <summary>E16.1 - GET/PUT /settings/message-kinds: the purposes an org still sends as service mail to an opted-out contact
/// (wire key service_purposes).</summary>
public record MessageKindSettingsDto(List<string> ServicePurposes);
public record MessageKindSettingsInput(List<string>? ServicePurposes);
/// <summary>E14.3: whether automations may move a deal to an earlier open stage (a rep may not; on by default).</summary>
public record AutomationStageMovesDto(bool MayMoveBackward);
public record AutomationStageMovesInput(bool? MayMoveBackward);

/// <summary>One header tile an admin may show on a record page (wire keys key, label).</summary>
public record HeaderTileOption(string Key, string Label);
/// <summary>Every tile an admin may choose from, per record type.</summary>
public record HeaderTileCatalogueDto(List<HeaderTileOption> Lead, List<HeaderTileOption> Account);
/// <summary>GET/PUT /settings/header-tiles: the ordered visible tile keys per record type, plus the full catalogue (wire key catalogue).</summary>
public record HeaderTilesDto(List<string> Lead, List<string> Account, HeaderTileCatalogueDto Catalogue);
/// <summary>PUT /settings/header-tiles. A list left out is left alone.</summary>
public record HeaderTilesInput(List<string>? Lead = null, List<string>? Account = null);

/// <summary>
/// THE vocabulary of the summary-strip tiles on the lead/deal page and the account page - the one place the keys, their labels and the
/// out-of-the-box order live. The default order is what the pages showed before this was a setting, so an org that never saves sees no change.
///
/// The setting only CHOOSES and ORDERS. It never grants: a tile the caller may not see (values without lead_values.view, financials, AI risk when
/// AI is off) is still dropped by the client exactly as before, whatever the saved list says.
/// </summary>
public static class HeaderTiles
{
    public static readonly IReadOnlyList<HeaderTileOption> Lead =
    [
        new("value", "Value"), new("potential_value", "Proposal value"), new("closed_value", "Closed value"), new("weighted", "Weighted"),
        new("time_in_stage", "Time in stage"), new("last_contact", "Last contact"), new("next_step", "Next step"), new("risk", "Risk"),
    ];

    public static readonly IReadOnlyList<HeaderTileOption> Account =
    [
        new("owner", "Owner"), new("open", "Open"), new("billed", "Billed"), new("owed", "Owed"),
        new("last_contact", "Last contact"), new("next_step", "Next step"), new("next_renewal", "Next renewal"),
    ];

    public static List<string> LeadDefaults() => Lead.Select(t => t.Key).ToList();
    public static List<string> AccountDefaults() => Account.Select(t => t.Key).ToList();
    public static HeaderTileCatalogueDto CatalogueDto() => new(Lead.ToList(), Account.ToList());

    /// <summary>Null when the list is acceptable; otherwise why not. Known keys only, no duplicates, at least one tile.</summary>
    public static string? Validate(string recordType, IReadOnlyList<HeaderTileOption> catalogue, IEnumerable<string?> keys)
    {
        var list = keys.Select(k => (k ?? "").Trim()).ToList();
        if (list.Count == 0) return $"{recordType}: choose at least one tile.";
        foreach (var k in list)
            if (!catalogue.Any(t => t.Key == k)) return $"{recordType}: \"{k}\" is not a tile. Choose from: {string.Join(", ", catalogue.Select(t => t.Key))}.";
        if (list.Distinct().Count() != list.Count) return $"{recordType}: each tile can appear once.";
        return null;
    }
}
/// <summary>E12: PUT /settings/sensitive-data. One of SensitiveAccess.Scopes (own | own_team).</summary>
public record SensitiveDataSettingsInput(string? AssignedScope, bool? RevealEnabled = null, int? RevealMinutes = null);
public record InviteSettingsInput(int? TokenDays);
/// <summary>
/// E14: GET/PUT /settings/account-hierarchy. <c>InheritedFields</c> = the account fields a child takes from its parent (empty = none, the
/// default; keys from AccountInheritance: industry, address, city, state, postal_code, country, custom.&lt;key&gt;).
/// <c>ChildCountStatuses</c> = the account_statuses keys whose children count toward an account's child_count (empty = every child counts).
/// On PUT an omitted list is left alone.
/// </summary>
/// <c>AggregateAccountDimension</c> (E18.1) = the ONE account field the pipeline snapshot and the stage-entry counts split by: "" (off, the default),
/// "industry" or "status". On PUT, null leaves it alone; "" turns it off; changing it re-derives both aggregates for the org.
public record AccountHierarchySettingsDto(List<string> InheritedFields, List<string> ChildCountStatuses, string AggregateAccountDimension = "");
public record AccountHierarchySettingsInput(List<string>? InheritedFields = null, List<string>? ChildCountStatuses = null, string? AggregateAccountDimension = null);

// --- Org setup (design doc D6a/D8) ---
// `UnmatchedLeadPolicy` is genuinely nullable, not merely "unsaved" — see
// OrgSetupService's doc comment for why that distinction matters here and
// nowhere else in this file. `Completed` is DERIVED (unmatched_lead_policy !=
// null), not a second stored flag: there is exactly one question today, so
// "answered" and "complete" are the same fact. A second question would need
// its own field here and Completed would become "every question answered".
//
// `CatchAllPlaybookId` is the playbook `catch_all_default` falls into — see
// OrgSetupService.CatchAllPlaybookIdKey. Always null when UnmatchedLeadPolicy
// isn't `catch_all_default`; OrgSetupService enforces that on both read and
// write so a caller never has to cross-check the two fields itself.
// OrgSetupDto lives in SalesApi.SystemApi/Dtos/SystemBoundContracts.cs — its
// Completed rule names Models.UnmatchedLeadPolicy, which this project cannot see.
public record OrgSetupInput(string? UnmatchedLeadPolicy, Guid? CatchAllPlaybookId = null);

// D9a #2 / D12 — who may approve a gate-exception request: "managers" (any
// DecideApprovals holder, default — matches reassign/reopen today) or
// "admins" (org admins only). See GateEscalationSettingsService.
//
// SelfDecision (E0.1) rides along on the same DTO rather than a new endpoint:
// both fields answer "who may decide an approval request", and the desktop's
// "Approvals" settings group edits them side by side. "blocked" (default) — a
// decider may not decide their own request; "allowed" — today's behaviour.
public record GateEscalationSettingsDto(string ApproverPolicy, string SelfDecision);
public record GateEscalationSettingsInput(string? ApproverPolicy, string? SelfDecision);

// D10a — the two settings governing the playbook picker on the lead
// create/edit forms and the unassigned-lead flow. See PlaybookPolicyService.
public record PlaybookPolicyDto(string HumanChoicePolicy, string PickerAccessPolicy);
public record PlaybookPolicyInput(string? HumanChoicePolicy, string? PickerAccessPolicy);

// D11/D11a — the lead board's DEFAULT view (single/union/grouped). The board
// itself is a user-facing toggle a viewer switches freely (D11a); this only
// picks which of the three a session starts on. See BoardRenderingPolicyService.
public record BoardRenderingPolicyDto(string Policy);
public record BoardRenderingPolicyInput(string? Policy);

// D2 (2026-08-25) — the three org settings governing which lead form captures
// a lead at create, what happens when no playbook resolves for it, and
// whether an existing lead keeps that form or follows its playbook's current
// one. See LeadFormPolicyService.
public record LeadFormPolicyDto(string Source, string NoPlaybookPolicy, string PinningPolicy);
public record LeadFormPolicyInput(string? Source, string? NoPlaybookPolicy, string? PinningPolicy);

// Tax / invoicing profile (org config): the VAT rate and TRN/legal identity
// that every server-rendered quote and invoice document reads from — never a
// hard-coded constant in a template. VatRate is a percentage (e.g. 5).
// TaxLabel (item 7): the org's own name for this tax — "VAT", "GST", "Sales
// tax" — so the label + default rate are configurable while TaxRate/TaxAmount
// stay PER-INVOICE (Invoice.TaxRate/TaxAmount), snapshotted at raise time so an
// individual invoice can still differ from the org default and a later label/
// rate change never rewrites an issued document.
// M12 — QuoteOverDiscountPolicy governs a discount larger than the lines it is
// taken off. It lives here, on the org's document-money profile, because that is
// already where a quote reads its tax rate and tax label from
// (LeadsController.CreateQuote) — the same config surface, not a new one. A
// positional-record default, so an org whose stored invoice_profile blob
// predates the key deserializes to "allow" with no backfill.
public record InvoiceProfileDto(
    decimal VatRate, string Trn, string LegalName, string LegalAddress, string TaxLabel,
    string QuoteOverDiscountPolicy = QuoteDiscountPolicies.OverDiscountAllow,
    // Q13: role key to the percent of a quote a role may discount without approval. Null/empty = no limit (today).
    Dictionary<string, decimal>? QuoteDiscountLimits = null);
public record InvoiceProfileInput(
    decimal? VatRate, string? Trn, string? LegalName, string? LegalAddress, string? TaxLabel,
    string? QuoteOverDiscountPolicy = null,
    Dictionary<string, decimal>? QuoteDiscountLimits = null);

// Audit H16 — the weights behind the "needs attention" risk score
// (RepRiskRow.Score = Overdue*OverdueWeight + Stalled*StalledWeight +
// Regressed*RegressedWeight), org-configurable rather than the hardcoded
// `overdue + stalled + regressed * 1.5` that used to live in
// packages/ui/src/charts/risk-leaderboard.tsx. Positional-record default so a
// stored blob that predates a new field deserializes to the shipped weight.
public record RiskWeightsDto(double OverdueWeight = 1, double StalledWeight = 1, double RegressedWeight = 1.5);
public record RiskWeightsInput(double? OverdueWeight, double? StalledWeight, double? RegressedWeight);

// E3.5 — per-org label overrides for the record words the desktop shows
// (Lead, Account, Contact, Deal, Quote, Invoice, Playbook, Stage, Rep). Wire
// names, API routes and enum values NEVER change — this is display text only,
// read through `useTerm()` on the client. Keyed by the lowercase term key
// (`OrgSettings.TerminologyKeys`); a key missing from the stored map (or the
// whole setting) falls back to `OrgSettings.DefaultTerminology`, never a blank
// or the raw key — see `SettingsProcess.GetTerminologyAsync`.
public record TermDto(string Singular, string Plural);
public record TerminologyInput(Dictionary<string, TermDto>? Terms);

// Manager-defined open pipeline stages (won/lost are fixed terminal statuses).
//
// Kind: "field" | "custom" | "attachment" | "rule" (workflow-engine-design.md
// §3.4/§4.3). The first three read a single value's presence (StageGateService
// .HasFieldValue/HasCustomValue/attachment tag); "rule" instead carries a
// RuleEvaluator-format condition in Rule and is satisfied when that condition
// evaluates true. Rule is null for every other Kind. Q6: a "rule" gate whose
// Rule references a field outside the live registry (built-ins ∪ active custom
// fields) is UNEVALUABLE — PlaybookService rejects publishing it, but at
// runtime an unevaluable rule still resolves via RuleEvaluator's own fail-open
// contract (unreadable => true => the gate does not block). Runtime and
// publish-time deliberately disagree on purpose; see PlaybookService.PublishAsync.
public record StageRequirementDto(string Key, string Label, string Kind, JsonElement? Rule = null);
// Semantic roles let features refer to a stage by MEANING rather than by name.
// Before these existed, the client hardcoded literals ('new' for a new lead's
// stage, 'qualified' for "convert to deal", 'proposal' for the quote prompt) —
// so an org that renamed or removed those stages silently lost the feature, and
// creating a lead failed outright because the posted status wasn't a configured
// stage. At most one stage may hold each role; see StageService.SaveAsync.
// Null means "not set", which the client resolves with a documented fallback —
// it is NOT the same as false.
public record StageDefDto(
    string Key,
    string Label,
    string Color,
    int Order,
    List<StageRequirementDto>? Requirements = null,
    double? X = null,
    double? Y = null,
    /// <summary>The stage a newly created lead enters.</summary>
    bool? IsDefault = null,
    /// <summary>The stage a lead reaches when it becomes a real deal ("Convert to deal").</summary>
    bool? IsDeal = null,
    /// <summary>The stage that offers to generate a proposal/quote document on entry.</summary>
    bool? IsProposal = null,
    /// <summary>
    /// What this stage MEANS: open | won | lost | post_close (see StagePhase).
    /// Null on config saved before this field existed, which resolves to the literal
    /// the codebase always hard-coded — "won"/"lost" keep their meaning, everything
    /// else is open — so an org that never opens the Stages screen is unaffected.
    /// </summary>
    string? Phase = null,
    /// <summary>
    /// Which bucket on the org's canonical stage axis this stage rolls up to (see
    /// CanonicalStage). Null on config saved before this field existed, which reads
    /// as a DERIVED default rather than as "unmapped" — see
    /// CanonicalStageService.ResolveMapping. This is what StageService.Ranks ranks
    /// on, so it decides which moves read as backward.
    /// </summary>
    string? Canonical = null,
    /// <summary>
    /// Manager-entered win probability (0..1) for this OPEN stage, used to weight
    /// the pipeline forecast. Formerly its own settings row (see ForecastService);
    /// merged onto the stage itself so /settings/stages is the single place stage
    /// configuration — including this — is edited and persisted. Null means "no
    /// value on record", which ForecastService resolves with the same
    /// rank-interpolated fallback it always has; it is NOT the same as 0.
    /// </summary>
    double? WinProbability = null,
    /// <summary>
    /// H6 — the EXIT gate mirroring <see cref="Requirements"/>'s entry gate.
    /// What it takes to move a lead BACKWARD out of this stage: null/"not_allowed"
    /// | "reason" | "manager_approval" (see StageService.StageReopenPolicy). Most
    /// relevant on a closed stage (won/lost/post_close) — that is what "reopening a
    /// deal" means — but the field is not phase-restricted, for the same reason
    /// Requirements isn't: a stage that is open today can become a terminal
    /// tomorrow without losing whatever an admin already set on it.
    ///
    /// Null resolves to StageReopenPolicy.Default (System layer)
    /// ("manager_approval"), which is deliberately what today's hardcoded rule
    /// already enforces (manager + a reason) — see "Reopen policy default (H6)" in
    /// the audit decisions doc. An org upgrades to the configurable version with its
    /// existing behaviour unchanged, and tightens (or loosens) it stage by stage.
    /// </summary>
    string? ReopenPolicy = null,
    /// <summary>
    /// S7 — whether a NEW lead may be created directly on this stage. Never
    /// consulted for an existing lead's own stage, or for a stage MOVE — only
    /// at creation (LeadWriteProcess.CreateAsync).
    ///
    /// UNLIKE IsDefault/IsDeal/IsProposal above, null/missing means TRUE, not
    /// false — the opposite of the usual "absent flag reads as off" rule this
    /// record otherwise follows. This is deliberate: this field did not exist
    /// before S7, and every stage on every existing org's saved config has it
    /// absent. If absent read as false the same way the other role flags do,
    /// every org would silently lose every starting stage the moment this
    /// shipped — "default = today's behaviour, all stages allowed" is the
    /// explicit requirement, so the default has to be permissive here even
    /// though it is restrictive everywhere else on this record.
    /// </summary>
    bool? IsStartable = null,
    /// <summary>
    /// E13 (proposal on stage entry, owner decision D3) - a PLAYBOOK stage option, saved/published with the stage snapshot like
    /// <see cref="Requirements"/>: when a deal is moved into this stage the client asks "upload or generate the proposal?" first.
    /// Null/false = no prompt. Never set on the org-wide list (the org stages screen does not write it).
    /// </summary>
    bool? AskProposalOnEntry = null,
    /// <summary>
    /// LEGACY - handover items were merged into <see cref="TasksOnEnter"/> (owner 2026-11-10). Read only so HandoverToStageTasksBackfill
    /// (and an old package) can convert a stored item; a save ignores it, and it is null once the backfill has run.
    /// </summary>
    List<HandoverItemDto>? Handover = null,
    /// <summary>
    /// E-invoicing IRL (owner decision 2, 2026-10-22) - a PLAYBOOK stage option exactly like <see cref="AskProposalOnEntry"/>: when a deal
    /// is moved into this stage the client asks "send the IRL link or upload a completed IRL?". Not a gate. Open stages only; null/false = no prompt.
    /// </summary>
    bool? AskIrlOnEntry = null,
    /// <summary>Item 6 (owner 2026-10-26) - tasks created when a deal ENTERS this stage (stage_snapshot tasksOnEnter). PLAYBOOK stages only; every phase.</summary>
    List<StageTaskDto>? TasksOnEnter = null,
    /// <summary>Tasks created when a deal LEAVES this stage (stage_snapshot tasksOnLeave).</summary>
    List<StageTaskDto>? TasksOnLeave = null,
    /// <summary>Bug 2 (owner 2026-10-26) - on an OPEN stage: when a proposal on a deal sitting here is accepted, move the deal to this stage key (null = off). The move is the normal gated move.</summary>
    string? MoveOnProposalAccepted = null,
    /// <summary>Parked item 7 (owner 2026-10-27) - on the WON stage only: the values the win step asks for when the deal has no accepted CRM-generated proposal (stage_snapshot askOnWin).</summary>
    AskOnWinDto? AskOnWin = null,
    /// <summary>Owner 2026-11-11 - optional recommended next steps for a lead sitting in this stage (stage_snapshot recommended). PLAYBOOK stages only; every phase; at most 10; never a gate.</summary>
    List<StageRecommendationDto>? Recommended = null,
    /// <summary>Owner 2026-11-12 (deal values per stage) - which stage-value set this OPEN stage captures when a deal LEAVES it: "proposal" | "negotiation" | null (stage_snapshot valueRole). PLAYBOOK stages only; at most one stage per role.</summary>
    string? ValueRole = null,
    /// <summary>Owner 2026-11-12 (delivery project from a workflow stage) - a PLAYBOOK stage option exactly like <see cref="AskProposalOnEntry"/>: when a deal is moved into this stage
    /// the client asks the rep which Suntech Delivery services to start, then answers with POST /leads/{id}/delivery-project. Not a gate. Open and Won stages and the stages after the win; never Lost. Null/false = no prompt.</summary>
    bool? CreateDeliveryProjectOnEntry = null);

// --- Canonical stage axis (see Models/CanonicalStage) ---
// Position is the list index on the wire, not a field: the PUT body is an ordered
// array and the server reindexes it, so a client cannot submit two buckets both
// claiming position 3.
public record CanonicalStageDto(
    string Key, string Label, int Position,
    // Item 8 (2026-09-26) — which LIVE playbook stages pin this bucket, each
    // already formatted "Stage label (Playbook name playbook)" — the exact
    // wording `CanonicalStageService`'s own save-time refusal uses, so the
    // canonical-stages screen can block a removal with the server's own words
    // instead of a generic "can't remove this" and finding out why only at
    // save. Only populated by `GET /settings/canonical-stages`
    // (`CanonicalStageService.GetWithPlaybookPinsAsync`) — every other reader
    // of this DTO (the save path's own usage check, the stage-editor picker)
    // gets an empty list rather than paying for a query it doesn't need.
    List<string>? PlaybookPins = null);
public record CanonicalStageInput(string? Key, string? Label);
// ConfirmReorder is the API half of Q9b's "reordering must warn": a body that
// changes the relative order of existing buckets is REFUSED unless the caller has
// acknowledged that it changes what counts as a backward move. Making the server
// refuse — rather than trusting each client to show a dialog — is what stops the
// warning from being skippable by whichever client is written next.
public record CanonicalStagesInput(List<CanonicalStageInput>? Stages, bool? ConfirmReorder);
public record QuotaInput(int? Quota);

// Weekly activity quota report: calls+meetings logged per rep this week vs target.
public record ActivityRepRow(Guid UserId, string? FullName, int Count);
public record ActivityReportDto(int Quota, List<ActivityRepRow> Rows);

// --- Inbound (website contact form) integration ---
// (The single plaintext ApiKey field is gone: website-form keys are named, hashed rows under /api-keys.)
public record InboundConfigDto(Guid? OwnerId, string? OwnerName);
// Inbound lead routing: mode = fixed | round_robin | load; pool = rep ids.
// SourceRules: per-source override, keyed by the org's own lead-source string
// (OrgSettings.GetLeadSourcesAsync), matched case-insensitively. See
// LeadRoutingService.PickOwnerAsync for exactly how OwnerId/TeamId combine.
// UnassignedTeamId: the org's default triage team for a lead that ends up with
// no owner and no rule-named team — null leaves it teamless (the org-wide
// queue every view/manage role already sees via Lead.TeamId == null).
// SourcePlaybooks is a SEPARATE map from SourceRules, deliberately — SourceRules'
// null-owner-and-team shape already means "route unassigned" (see SourceRuleDto's
// own comment), and overloading that record with a playbook id would collide with
// a meaning it already carries. Keyed the same way (the org's own lead-source
// string, matched case-insensitively) and validated the same way at save time: a
// source not in the org's configured list, or a playbook id that doesn't exist in
// this org, is dropped rather than persisted. Whether the MAPPED playbook is
// actually live right now is deliberately NOT checked here — that is re-verified
// at resolve time (PlaybookMatchService.ResolveMappedSourceAsync), the same way an
// explicit human pick is re-checked at use time rather than at save time, so a
// playbook drafted-over-and-republished later is judged by what it is when a lead
// actually arrives.
public record LeadRoutingDto(string Mode, List<Guid> Pool, Dictionary<string, SourceRuleDto>? SourceRules, Guid? UnassignedTeamId, Dictionary<string, Guid>? SourcePlaybooks = null);
public record LeadRoutingInput(string? Mode, List<Guid>? Pool, Dictionary<string, SourceRuleDto>? SourceRules, Guid? UnassignedTeamId, bool ClearUnassignedTeam = false, Dictionary<string, Guid>? SourcePlaybooks = null);

// OwnerId set -> route straight to that rep (team resolves the normal
// owner-based way). OwnerId null & TeamId set -> leave the owner TBD and file
// under that team, overriding the org's default triage team for this source.
// Both null -> leave the owner TBD and fall back to the org's default triage
// team (LeadRoutingDto.UnassignedTeamId), or the org-wide queue if that's unset.
public record SourceRuleDto(Guid? OwnerId, Guid? TeamId);
// Routing audit: what the rule actually did. Reason is a RoutingReasons key —
// the client owns the label, so a wording change never needs a deploy here.
public record RoutingAuditRowDto(
    Guid Id, Guid LeadId, string? LeadName, string? Company,
    Guid OwnerId, string? OwnerName, string Reason, DateTime RoutedAt);
public record RoutingAuditCountDto(Guid OwnerId, string? OwnerName, int Count);
public record RoutingAuditDto(int Days, List<RoutingAuditRowDto> Recent, List<RoutingAuditCountDto> Counts);
public record InboundOwnerInput(Guid? OwnerId);
// PhoneCountryCode (phone storage decision, 2026-09-30; to-do/phone-matching-audit.md
// §2.3) — the website form's captured country (ISO 3166-1 alpha-2), optional
// and trailing so every existing caller (a form that never sends it) keeps
// today's digits-only normalization for a '+'-less phone unchanged.
// Validated in PublicIntakeProcess before use; an invalid code is a BadRequest,
// not silently ignored, so a broken embed shows up instead of quietly losing
// the fix this field exists for.
public record PublicLeadInput(string? Name, string? Email, string? Phone, string? Company, string? Message, string? Source, string? PhoneCountryCode = null);

public record AssignInput(Guid? OwnerId);
// FieldChoices: optional per-field override, keyed by the field names used in
// MergeFieldPreview.Field ("company","email","phone","source","notes",
// "estimated_value","account_id"). A value of "duplicate" keeps the
// duplicate's value for that field instead of the default (primary wins
// unless primary's value is blank/zero). Omitted fields use the default.
public record MergeInput(Guid? PrimaryId, Guid? DuplicateId, Dictionary<string, string>? FieldChoices);

// --- Org setup (design doc D6a/D8) ---
//
// Moved here from SystemApi/Dtos/SystemBoundContracts.cs on 2026-08-28, once
// the vocabulary its Completed rule depends on (Models.UnmatchedLeadPolicy)
// moved into this project. See OrgSetupPolicy.cs for why that was the fix
// rather than an exception to the boundary.
public record OrgSetupDto(string? UnmatchedLeadPolicy, Guid? CatchAllPlaybookId = null)
{
    public bool Completed => SalesApi.Models.UnmatchedLeadPolicy.IsValid(UnmatchedLeadPolicy);
}

// --- Email provider (org-level) ---
//
// SECRETS ARE WRITE-ONLY, and these two records are where that is enforced on
// the way out: there is a `*_set` boolean and no field that could carry the
// value. A masked secret invites someone to paste it back, and an echoed one
// leaks its length and shape.
//
// Named records rather than the anonymous object this used to be, because the
// Experience layer has to return it. The wire shape is unchanged —
// `JsonNamingPolicy.SnakeCaseLower` renders these names as the same snake_case
// keys the anonymous object spelled by hand.
public record EmailDeliveryLogRowDto(
    string? ToAddress, string? EventType, string Outcome, string? Reason, DateTime CreatedAt);

/// <param name="Status">What the NEXT real send would do, taken from the same
/// resolver that send uses rather than re-derived here. Two copies of that rule
/// would eventually disagree, and the disagreement an admin sees is a page
/// saying "Ready" over a pipeline dropping every message — or the reverse, which
/// is worse, because it invites someone to "fix" a working configuration.</param>
/// <param name="InfraEnabled">The deployment-wide kill switch, surfaced
/// read-only. Without it, an operator switching email off looks identical to a
/// broken org configuration.</param>
public record EmailProviderConfigDto(
    string Status,
    string? StatusReason,
    bool InfraEnabled,
    bool Enabled,
    string Provider,
    IReadOnlyList<string> Available,
    string? FromAddress,
    string? FromName,
    string? SmtpHost,
    int SmtpPort,
    bool SmtpUseTls,
    string? SmtpUsername,
    bool SmtpPasswordSet,
    string? GraphTenantId,
    string? GraphClientId,
    bool GraphClientSecretSet,
    IReadOnlyList<EmailDeliveryLogRowDto> RecentDeliveries);

// --- Lead form designer ---
//
// The last resident of SystemApi/Dtos/SystemBoundContracts.cs, a file that
// existed to hold the contracts that could not live here because they named
// System types. Both of its residents have now moved down — OrgSetupDto with
// its policy vocabulary, and this one with the schema model — so the file is
// gone rather than kept as an empty placeholder for a problem that was solved.
//
// Form builder rework (2026-10-16): the trailing members let the builder diff draft against live and show
// "last saved / last published" without a second call. Schema/Version/IsPublished keep their old meaning:
// the WORKING copy (the draft when one exists, otherwise the live version).
// Live* is the published version, null when the form has never been published (the old v1 seed draft).
public record LeadFormDraftDto(
    global::SalesApi.Services.LeadFormSchemaModel Schema, int Version, bool IsPublished,
    bool HasDraft = false,
    DateTime? DraftUpdatedAt = null, string? DraftUpdatedBy = null,
    global::SalesApi.Services.LeadFormSchemaModel? LiveSchema = null, int? LiveVersion = null,
    DateTime? LivePublishedAt = null, string? LivePublishedBy = null);

// The Picklists contracts (E3.6 — managed picklists).
//
// Same split-per-domain convention as the other files here (see the header on
// CustomFields.cs): this project has no references at all, so anything the
// Experience layer must be able to return has to live here.

namespace SalesApi.Dtos;

/// <summary>One selectable entry. <c>UsageCount</c> is always populated on a
/// read (never on a write echo) — it is what the E0.6-style delete
/// confirmation and the settings screen's row both show, computed the same
/// way for both so they can never disagree.</summary>
public record OrgPicklistValueDto(
    Guid Id, string Value, string Label, int SortOrder, DateTime? ArchivedAt, int UsageCount);

public record OrgPicklistDto(
    Guid Id, string Key, string Label, DateTime CreatedAt, DateTime? UpdatedAt,
    List<OrgPicklistValueDto> Values);

/// <summary>Create a NEW org picklist (beyond the two seeded ones) — for a
/// custom field of type "picklist" that wants its own list. Key is derived
/// from Label, same as CustomFieldProcess.ToKey.</summary>
public record PicklistInput(string? Label);

/// <summary>Add a value, or rename one's label (Value/key never changes after
/// creation — see OrgPicklistValue's class remarks).</summary>
public record PicklistValueInput(string? Label);

public record PicklistValueReorderInput(List<Guid>? Ids);

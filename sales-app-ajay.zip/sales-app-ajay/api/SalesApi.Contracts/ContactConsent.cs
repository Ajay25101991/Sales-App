namespace SalesApi.Dtos;

// E16.1 - contact opt-out per channel. Wire keys are snake_case (JsonNamingPolicy.SnakeCaseLower).

/// <summary>POST /contacts/{id}/opt-out and /opt-in. <c>Channel</c> is "email" | "sms" | "whatsapp"; <c>Reason</c> is free text kept on the consent log.</summary>
public record ContactOptOutInput(string? Channel, string? Reason = null);

/// <summary>The contact's CURRENT opt-out state after a change: channel -> when they opted out (a channel that is not opted out is absent).</summary>
public record ContactOptOutStateDto(Dictionary<string, DateTime> OptedOut);

/// <summary>One line of GET /contacts/{id}/consent-history (newest first). <c>Action</c> is "opted_out" | "opted_in"; <c>Source</c> is "staff" |
/// "unsubscribe_link" | "stop_reply"; <c>ActorId</c> is the staff member (null for a link or a STOP reply).</summary>
public record ContactConsentEntryDto(
    Guid Id, string Channel, string Action, string Source, string? Reason, string? Address, Guid? ActorId, DateTime OccurredAt);

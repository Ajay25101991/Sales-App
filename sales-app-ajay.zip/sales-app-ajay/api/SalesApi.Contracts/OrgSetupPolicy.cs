// WHY THIS SITS IN CONTRACTS. It is a small closed vocabulary of wire values —
// no EF, no HTTP, nothing that knows how anything is stored — and
// SystemBoundContracts.cs named it as one of the two things that had to move
// DOWN here before org-setup could have an Experience layer at all. That is
// exactly what happened: the settings migration needed OrgSetupDto on an
// Experience surface, Experience cannot see the System project, and the fix the
// note prescribed was to move this rather than weaken the boundary.
//
// The namespace stays `SalesApi.Models` so the move costs no caller a `using`.

namespace SalesApi.Models;

/// <summary>
/// Wire values for the org-setup flow's one question so far (design doc
/// D6/D6a/D8): when a lead matches no playbook, does it fall to the seeded
/// catch-all playbook, or stay unmatched for an org admin?
///
/// Deliberately its OWN file rather than living beside <c>Playbook</c>:
/// this is org-setup config, not a playbook concept, AND Playbook.cs is active
/// ground for concurrent playbook-matching-UI work (see
/// to-do/workflow-engine-design.md's D-block) — sharing a file would be a
/// needless collision surface between two changes that do not otherwise touch.
///
/// Persisted as a plain <c>AppSetting</c> value (see
/// <c>Services.OrgSetupService</c>), the same key/value table
/// ~20 other org settings already share, rather than a new column on
/// <c>Organization</c> — adding a column would mean a migration AND a
/// new offboarding purge/backup declaration; a new AppSetting key needs
/// neither (OrganizationOffboardingService already purges/backs up the whole
/// `settings` table generically).
/// </summary>
public static class UnmatchedLeadPolicy
{
    /// <summary>An unmatched lead keeps a null PlaybookId and is left for an
    /// org admin to find and assign by hand. Today's behaviour, unchanged.</summary>
    public const string AdminQueue = "admin_queue";

    /// <summary>An unmatched lead falls into the org's DESIGNATED catch-all
    /// playbook, so it always has gates and a stage list.
    ///
    /// CONSUMED by <c>Services.PlaybookMatchService.MatchAsync</c> —
    /// note it is a *designated existing playbook*, not a seeded "Default"
    /// one: Q13 specified seeding a Default playbook per org, but that was
    /// never built (no seeding code exists anywhere, verified 2026-08-25),
    /// so there was nothing for this setting to fall back TO. Rather than
    /// build the unbuilt Q13 concept, an org instead POINTS this policy at
    /// one of its own live playbooks — see
    /// <c>Services.OrgSetupService.CatchAllPlaybookIdKey</c>. This
    /// still needs an org to have at least one live, condition-matching-
    /// anything-or-not playbook to point at; an org with none configured has
    /// no effective catch-all even with this policy selected, exactly as it
    /// had none before this setting was consumed.</summary>
    public const string CatchAllDefault = "catch_all_default";

    public static readonly string[] All = [AdminQueue, CatchAllDefault];
    public static bool IsValid(string? v) => v is not null && All.Contains(v);
}

// E-invoicing IRL (Information Request List) - to-do/einvoicing-irl-design.md. Wire keys are snake_case (the app's JSON policy).
// Answers and definitions travel as JsonElement so the canonical ids ("Q-ABOUT-NAME", "ENTITIES-COL-2") are NEVER rewritten by the
// naming policy: a JSON object keyed by canonical id comes out exactly as it went in.

using System.Text.Json;

namespace SalesApi.Dtos;

// ---- the question definition, derived from the blank workbook's hidden _map + Lists sheets -----------------------------------

/// <summary>
/// One question. Type: "text", "number" (a non-negative number), "enum" (one of Options) or "document" (a Section D item: Options are its
/// attach statuses; DocType is the client-document type a file uploaded against it is tagged with, null = a plain tagged attachment).
/// Address is the workbook cell the answer is read from / written to; Order the sheet row, so questions and tables of a section can be interleaved.
/// </summary>
public record IrlQuestionDto(
    string Id, string Label, string? Hint, string Type, List<string> Options, string? Code, string? Who, string Address, int Order, string? DocType = null, string? NotesAddress = null);

/// <summary>One column of a table. Key is what each row object is keyed by (the column's canonical id; a range of several columns, such as
/// VATGROUPS-TABLE B34:C37, gets "&lt;id&gt;.B" and "&lt;id&gt;.C"). Defaults are the values the blank workbook already holds in that column.</summary>
public record IrlColumnDto(string Key, string Label, string? Hint, string Type, List<string> Options, string Address, List<string> Defaults);

/// <summary>A table of rows (entities, VAT groups, systems). MaxRows is the number of rows the workbook has room for.</summary>
public record IrlTableDto(string Id, string Title, string? Hint, int MaxRows, List<IrlColumnDto> Columns, int Order);

/// <summary>Section Key is the letter on the sheet ("A".."D"); Why is the sheet's "Why we ask" line.</summary>
public record IrlSectionDto(string Key, string Title, string? Why, List<IrlQuestionDto> Questions, List<IrlTableDto> Tables);

/// <summary>Everything a screen needs to draw the form. TemplateVersion and DocId come from the _map sheet's first row; Sheet is the workbook
/// sheet every address refers to.</summary>
public record IrlDefinitionDto(string DocId, string TemplateVersion, string? Released, string Sheet, List<IrlSectionDto> Sections);

/// <summary>What the admin sees after uploading the blank workbook (on DocumentTemplateVersionDto.Irl).</summary>
public record IrlTemplateInfoDto(string DocId, string TemplateVersion, string? Released, int Questions, int Tables, int Documents);

// ---- the rep's side: GET/POST /leads/{id}/irl... ------------------------------------------------------------------------------

/// <summary>A file the client uploaded against a Section D item (the file itself is an ordinary attachment of the deal).</summary>
public record IrlFileDto(string ItemId, Guid AttachmentId, string FileName, long SizeBytes, DateTime UploadedAt);

/// <summary>One kept submission. Source: "online" (the client pressed Submit) or "upload" (the rep uploaded a completed workbook, AttachmentId).
/// Warnings are plain-words notes about an upload (cells read but not one of the usual options).</summary>
public record IrlSubmissionDto(
    Guid Id, int Number, string Source, DateTime SubmittedAt, string By, Guid? ByUserId, Guid? AttachmentId, string? FileName, List<string> Warnings);

/// <summary>
/// The request as the rep sees it. Status: draft, sent, in_progress, submitted, locked (submitted, then a proposal was sent), expired,
/// revoked. Link is the client's secure address (null when never sent or when the server has no public address configured). Locked says the
/// client can no longer change anything until the rep reopens. AnsweredCount / QuestionCount count top-level questions and tables with at
/// least one filled cell.
/// </summary>
public record IrlRequestDto(
    Guid Id, Guid LeadId, string Status, bool Locked, string TemplateVersion, string DocId, Guid? CatalogItemId, string? ServiceName,
    string? Link, DateTime CreatedAt, Guid CreatedById, string? CreatedByName,
    DateTime? SentAt, string? SentTo, string? SentSubject, DateTime? ExpiresAt, DateTime? RevokedAt, string? RevokeReason,
    DateTime? SubmittedAt, DateTime? LastClientSaveAt, int SubmissionCount, bool EditedSinceSubmit,
    int ViewCount, DateTime? FirstViewedAt, DateTime? LastViewedAt, int AnsweredCount, int QuestionCount,
    List<IrlFileDto> Files, List<IrlSubmissionDto> Submissions);

/// <summary>A blank IRL workbook an admin has uploaded that this deal could be sent: one per service. Send takes CatalogItemId when more than one fits.</summary>
public record IrlTemplateChoiceDto(Guid? CatalogItemId, string ServiceName, string TemplateVersion, string FileName);

/// <summary>GET /leads/{id}/irl. Request is null until one is sent or uploaded. Definition and Answers are those of the request (null with it).</summary>
public record IrlDetailDto(IrlRequestDto? Request, JsonElement? Definition, JsonElement? Answers, List<IrlTemplateChoiceDto> Templates);

/// <summary>POST /leads/{id}/irl/send. CatalogItemId picks the service's blank workbook when the deal has more than one candidate. The rest is the
/// engagement letter's send body (thread to reply on, recipient, subject/body overrides).</summary>
public record SendIrlInput(
    Guid? CatalogItemId = null, Guid? ReplyToMessageId = null, bool? NewEmail = null, string? ToEmail = null, string? Subject = null, string? Body = null,
    List<string>? Cc = null, List<string>? Bcc = null, List<Guid>? CompanyDocumentIds = null,
    string? ToRecipientRef = null, List<string>? CcRecipientRefs = null, List<string>? BccRecipientRefs = null);

/// <summary>GET /leads/{id}/irl/submissions/{submissionId}: one kept snapshot with its answers.</summary>
public record IrlSubmissionDetailDto(IrlSubmissionDto Submission, JsonElement Answers);

/// <summary>POST /leads/{id}/irl/upload (multipart) result: the request after the workbook was read, plus how many cells were read.</summary>
public record IrlUploadResultDto(IrlRequestDto Request, int CellsRead, List<string> Warnings);

// ---- the client's side: /irl/{token} ------------------------------------------------------------------------------------------

/// <summary>
/// GET /irl/{token}. CanEdit is false when the request is locked (a proposal has been sent) or otherwise closed; LockedReason says why in plain
/// words. PreparedFor is the client's company or deal name. Files are those already uploaded against Section D items.
/// </summary>
public record IrlPublicViewDto(
    string Status, bool CanEdit, string? LockedReason, DateTime? ExpiresAt, string? PreparedFor, string TemplateVersion, DateTime? SubmittedAt,
    JsonElement Definition, JsonElement Answers, List<IrlFileDto> Files);

/// <summary>PUT /irl/{token} body: only the keys sent change; a table key replaces the whole table; null or "" clears a question.</summary>
public record SaveIrlAnswersInput(JsonElement Answers);

/// <summary>POST /irl/{token}/submit body (optional): answers to save first, atomically with the submit.</summary>
public record SubmitIrlInput(JsonElement? Answers = null);

/// <summary>PUT result. Saved = the instant the save was recorded.</summary>
public record IrlSaveResultDto(string Status, DateTime SavedAt);

/// <summary>POST submit result.</summary>
public record IrlSubmitResultDto(string Status, DateTime SubmittedAt, int SubmissionNumber);

/// <summary>One answer that was refused. Id is the canonical id (a table cell is "TABLE[row].COLUMN-KEY", row from 1).</summary>
public record IrlFieldErrorDto(string Id, string Message);

/// <summary>POST /irl/{token}/documents/{itemId} result: the file now on the deal, and the item's status it moved to.</summary>
public record IrlDocumentUploadedDto(string ItemId, Guid AttachmentId, string FileName, long SizeBytes, string ItemStatus);

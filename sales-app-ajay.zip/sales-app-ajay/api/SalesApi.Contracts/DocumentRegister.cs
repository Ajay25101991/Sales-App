namespace SalesApi.Dtos;

// E15.1 document register: one row per KYC / company document (type, number, issue and expiry date, verification, the file it points
// to), with a version chain on replacement. Company documents belong to an account; personal ID documents belong to a contact (the
// owner or signatory) and are shown read-only on the account's children. JSON is snake_case like the rest of the API.

/// <summary>
/// One document in the register. <c>Number</c> is null when the caller may not see it (<c>NumberMasked</c> says so) - the same masking the
/// account's own field of that number gets. <c>Expired</c> is the expiry date having passed today (not stored). <c>Inherited</c> is true
/// for a person's document held on an ancestor account and shown read-only here (<c>InheritedFromAccountId</c> says where).
/// </summary>
public record DocumentRegisterEntryDto(
    Guid Id, Guid AccountId, Guid? ContactId, string? ContactName, string DocumentType,
    string? Number, bool NumberMasked, DateOnly? IssueDate, DateOnly? ExpiryDate, bool Expired,
    string Status, Guid? VerifiedById, DateTime? VerifiedAt,
    Guid? AttachmentId, string? FileName, string? FileUrl,
    int Version, bool IsCurrent, Guid? SupersedesId, DateTime? SupersededAt,
    Guid? CreatedById, DateTime CreatedAt, bool Inherited, Guid? InheritedFromAccountId, bool CanOpen = true);

/// <summary>POST /document-register (multipart form). Give <c>account_id</c> (a company document) or <c>contact_id</c> (a personal ID document;
/// the account is the contact's). <c>replaces_id</c> makes the new row the next version of that row.</summary>
public record DocumentRegisterAddInput(
    Guid? AccountId, Guid? ContactId, string? DocumentType, string? Number, DateOnly? IssueDate, DateOnly? ExpiryDate, Guid? ReplacesId,
    Guid? DocumentRequestId = null);

/// <summary>PUT /document-register/{id}: the number and dates as they should now be (null clears). Editing a verified document puts it back to pending.</summary>
public record DocumentRegisterEditInput(string? Number, DateOnly? IssueDate, DateOnly? ExpiryDate);

namespace SalesApi.Dtos;

// E15.5 sanctions screening: an append-only record of each check of a company (an account) or a person at it (a contact - an owner or partner), what
// a reviewer decided about it, and the evidence files. JSON is snake_case like the rest of the API. The words used for the feature are "screening"
// and "sanctions screening"; nothing here describes itself as anything broader.

/// <summary>One possible match a check turned up. <c>Score</c> is the provider's own figure, if it gives one.</summary>
public record ScreeningMatchDto(string Name, string? Source, decimal? Score, string? Notes);

/// <summary>One reviewer decision (<c>clear</c>, <c>true_match</c> or <c>escalate</c>) with the reason given. The newest decision of a screening is the one in force.</summary>
public record ScreeningDecisionDto(Guid Id, string Decision, string Reason, Guid DecidedById, string? DecidedByName, DateTime DecidedAt);

/// <summary>An evidence file: an attachment on the account tagged <c>screening:{id}</c>. <c>Url</c> downloads it.</summary>
public record ScreeningEvidenceDto(Guid AttachmentId, string FileName, string Url, DateTime CreatedAt)
{
    /// <summary>Owner 2026-11-16: false when the caller's ID &amp; bank level cannot open the file (the download answers 403). The row, name and date stay visible.</summary>
    public bool CanOpen { get; init; } = true;
}

/// <summary>
/// One screening. <c>Status</c> is what it currently amounts to: <c>clear</c> (no match, or a reviewer cleared it), <c>open</c> (a possible or true
/// match nobody has decided), <c>escalated</c> or <c>true_match</c> (a reviewer's decision). <c>Blocks</c> is true for every status but clear: it is what
/// a <c>screening_clear</c> stage gate counts. <c>Decision</c> is the one in force, <c>Decisions</c> the whole history, newest first. <c>IsLatest</c> is
/// true when no newer screening of the same subject exists - only that one counts.
/// </summary>
public record ScreeningDto(
    Guid Id, Guid AccountId, string? AccountName, Guid? ContactId, string? ContactName, string Provider, DateTime ScreenedAt, string Result,
    IReadOnlyList<ScreeningMatchDto> Matches, string? ProviderReference, string? Notes, Guid? CreatedById, string? CreatedByName, DateTime CreatedAt,
    string Status, bool Blocks, bool IsLatest, ScreeningDecisionDto? Decision, IReadOnlyList<ScreeningDecisionDto> Decisions,
    IReadOnlyList<ScreeningEvidenceDto> Evidence);

/// <summary>POST /screenings. Give <c>account_id</c> (the company) or <c>contact_id</c> (a person; the account is theirs). <c>provider</c> defaults to
/// "manual" (staff screened on the provider's own website): <c>result</c> is then required. <c>screened_at</c> defaults to now.</summary>
public record ScreeningRecordInput(
    Guid? AccountId, Guid? ContactId, string? Provider, DateTime? ScreenedAt, string? Result,
    List<ScreeningMatchDto>? Matches, string? ProviderReference, string? Notes);

/// <summary>POST /screenings/{id}/decision. <c>decision</c> is clear, true_match or escalate; <c>reason</c> is required.</summary>
public record ScreeningDecisionInput(string? Decision, string? Reason);

/// <summary>
/// Where one subject stands for the stage gate: the account, or an in-scope contact. <c>ScreeningId</c> is null when the subject has never been screened
/// (which blocks). <c>Status</c> is null in that case too.
/// </summary>
public record ScreeningSubjectDto(Guid AccountId, Guid? ContactId, string Name, Guid? ScreeningId, string? Status, bool Blocks);

/// <summary>GET /screenings/subjects?account_id=: every subject the org's scope names for the account, and whether all of them are clear.</summary>
public record ScreeningSubjectsDto(Guid AccountId, bool Clear, IReadOnlyList<ScreeningSubjectDto> Subjects);

/// <summary>
/// The org's screening policy (GET / PUT /screenings/settings). Off unless configured: with <c>RescreenDays</c> null no reminder is raised, and a stage only
/// asks for screening when it carries the <c>screening_clear</c> gate.
/// <c>IncludeAccount</c> - the company itself is screened (default true).
/// <c>ContactScope</c> - which contacts are screened as well: <c>none</c> (default), <c>all</c> (every contact on the account), or <c>field</c> (contacts whose
/// contact custom field <c>ContactFieldKey</c> holds one of <c>ContactFieldValues</c>, e.g. a "role" field with "owner" and "partner").
/// <c>RescreenDays</c> - screen again this many days after the last screening (null = never).
/// <c>ReminderLeadDays</c> - raise the staff reminder this many days before the screening is due (default 7).
/// </summary>
public record ScreeningSettingsDto(
    bool IncludeAccount, string ContactScope, string? ContactFieldKey, List<string> ContactFieldValues, int? RescreenDays, int ReminderLeadDays);

/// <summary>PUT /screenings/settings. Anything left out keeps its current value; <c>rescreen_days</c> of 0 turns the repeat off.</summary>
public record ScreeningSettingsInput(
    bool? IncludeAccount, string? ContactScope, string? ContactFieldKey, List<string>? ContactFieldValues, int? RescreenDays, int? ReminderLeadDays);

public static class ScreeningContactScopes
{
    public const string None = "none";
    public const string All = "all";
    public const string Field = "field";
    public static readonly string[] Every = [None, All, Field];
}

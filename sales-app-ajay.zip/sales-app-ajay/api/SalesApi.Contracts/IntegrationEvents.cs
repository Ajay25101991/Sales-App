// Integrations audit (to-do/integrations-audit.md, owner decisions 4 and 6): the incoming log, the common "test connection" answer,
// and the admin "needs attention" items. Wire keys are snake_case by the API's JSON naming policy.

namespace SalesApi.Dtos;

/// <summary>How one inbound webhook delivery ended. A fixed vocabulary - the log screen filters on it.</summary>
public static class InboundEventOutcomes
{
    /// <summary>Signature checked and handled (including a genuine delivery with nothing for us to do).</summary>
    public const string Accepted = "accepted";
    /// <summary>The POST signature was missing or wrong; nothing was parsed.</summary>
    public const string RejectedSignature = "rejected_signature";
    /// <summary>The one-time GET handshake carried the wrong verify token.</summary>
    public const string RejectedVerify = "rejected_verify";
    /// <summary>Signed and genuine, but handling it failed (the sender may retry).</summary>
    public const string FailedProcessing = "failed_processing";
    /// <summary>Signed and genuine, but the organization's plan does not include this connector.</summary>
    public const string IgnoredPlan = "ignored_plan";

    public static readonly string[] All = [Accepted, RejectedSignature, RejectedVerify, FailedProcessing, IgnoredPlan];

    /// <summary>The outcomes that mean something went wrong (what "last error" and the rejected counter read).</summary>
    public static readonly string[] Problems = [RejectedSignature, RejectedVerify, FailedProcessing];
}

/// <summary>One row of the incoming log. <paramref name="Detail"/> is a short plain sentence (never a payload body or a secret);
/// <paramref name="ExternalId"/> is only the sender's own id for the thing (a Meta leadgen id, a WhatsApp message id).</summary>
public record InboundEventDto(
    Guid Id, string Connector, string ConnectorLabel, DateTime ReceivedAt, string Outcome, string? Detail, string? ExternalId);

public record InboundEventPageDto(List<InboundEventDto> Items, int Page, int PageSize, int Total);

/// <summary>The answer of POST /integrations/{key}/test - the WhatsApp test's shape (<c>ok</c> + a plain sentence).</summary>
public record ConnectionTestResultDto(bool Ok, string Message);

/// <summary>One thing an admin should look at. <paramref name="Kind"/> is webhook_paused | api_key_expiring | api_key_expired |
/// connector_token_expired | connector_error; <paramref name="RefId"/> is the webhook / key id or the connector key.</summary>
public record IntegrationAttentionItemDto(string Kind, string RefId, string Label, DateTime? Since);

public record IntegrationAttentionDto(List<IntegrationAttentionItemDto> Items);

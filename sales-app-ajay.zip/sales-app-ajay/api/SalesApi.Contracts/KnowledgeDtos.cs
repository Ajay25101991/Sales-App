// The E4.6 knowledge-collections admin contracts (design doc
// to-do/e4-ai-platform-design.md §6, §15 slice 12). Own file for the same
// reason every other AI admin contract has one — see AiExecutionLog.cs's header.

namespace SalesApi.Dtos;

public record KnowledgeCollectionDto(
    Guid Id,
    string Name,
    IReadOnlyList<string> ScopedTeamIds,
    IReadOnlyList<string> ScopedSkillKeys,
    int DocumentCount,
    DateTime CreatedAt);

/// <summary>Both scope lists default to empty (unrestricted) when omitted —
/// same "explicit, whole-map replace" posture <c>AiCostPolicyInput</c> takes
/// for its own maps, simpler than a partial-merge contract nobody asked for.</summary>
public record KnowledgeCollectionInput(
    string Name,
    IReadOnlyList<string>? ScopedTeamIds,
    IReadOnlyList<string>? ScopedSkillKeys);

/// <summary>One scope-filtered candidate chunk handed to
/// <c>IAiContextEngine</c>'s knowledge fan-out (design §5.2 step 5, §6.3) —
/// already restricted to Ready documents and to collections the caller's
/// team/the skill's purpose may draw on; similarity ranking happens ABOVE
/// this, in the context engine, never as a substitute for the scope filter
/// that produced this list.</summary>
public record KnowledgeChunkCandidate(Guid ChunkId, string Text, float[] Embedding);

public record KnowledgeDocumentDto(
    Guid Id,
    Guid CollectionId,
    string FileName,
    string? ContentType,
    long SizeBytes,
    string Status,
    string? FailureReason,
    Guid UploadedById,
    DateTime CreatedAt,
    DateTime UpdatedAt);

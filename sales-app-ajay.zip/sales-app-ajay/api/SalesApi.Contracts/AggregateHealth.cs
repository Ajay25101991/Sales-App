// The aggregate-health contracts: what the nightly drift check FOUND, and the
// per-org envelope the admin console reads it in.
//
// WHY THEY LIVE HERE. These two records were written inside
// `SystemApi/Services/AggregateDrift.cs`, next to the code that produces them,
// and there is nothing System-layer about either: no EF, no entity, no
// DbContext — a timestamp, a count, and a list of four-field findings. They are
// the FIFTH value object found sitting in System by accident of authorship
// (after RecordAccessContext, TeamScope, CalendarDto and PeriodComparisonBasis),
// and like PeriodComparisonBasis they were found by the sweep rather than by
// being blocked.
//
// Admin is what forced the issue: `GET /admin/aggregate-health` returns the
// report, so it lands on a Process AND an Experience surface — and Experience
// cannot see the System assembly at all (`DisableTransitiveProjectReferences`),
// so leaving them in System does not merely trip LayerBoundaryTests, it makes
// the Experience class impossible to compile.
//
// `AggregateDrift` itself — the comparison, which reads the aggregate tables —
// stays in System where it belongs. Only the SHAPE of its answer moved.
//
// The namespace stays `SalesApi.Services`, so the move costs zero `using` edits.

namespace SalesApi.Services;

/// <summary>One aggregate that disagrees with the live data behind it.</summary>
/// <param name="Metric">Stable machine key, e.g. <c>daily_org.won_value</c>.</param>
/// <param name="Detail">What window or bucket it covers, in words.</param>
/// <param name="Expected">What the live query says.</param>
/// <param name="Actual">What the aggregate table says.</param>
public record AggregateDriftFinding(string Metric, string Detail, decimal Expected, decimal Actual)
{
    public decimal Difference => Actual - Expected;
}

/// <param name="QueueDepth">
/// Buckets sitting in the durable retry queue at the time of the check. A
/// non-zero depth EXPLAINS drift rather than adding to it — those recomputes are
/// known-owed and will be retried; see <see cref="AggregateQueue"/>.
/// </param>
public record AggregateDriftReport(
    DateTime CheckedAt, Guid? OrgId, int QueueDepth, List<AggregateDriftFinding> Findings)
{
    public bool HasDrift => Findings.Count > 0;
}

/// <summary>
/// One org's row in <c>GET /admin/aggregate-health</c>.
///
/// <paramref name="Report"/> is NULLABLE and the null is load-bearing: it means
/// the scheduled check has never run for this org, which is NOT the same as "no
/// drift found" and must not be rendered as a clean bill of health. Replacing it
/// with an empty report would erase exactly that distinction.
///
/// This was an anonymous object inside the controller. It is a named record now
/// because Experience has to return it, and the wire shape is unchanged —
/// `JsonNamingPolicy.SnakeCaseLower` renders these three properties as
/// `org_id`, `queue_depth` and `report`, the same keys the anonymous object had
/// spelled by hand.
/// </summary>
public record AggregateHealthDto(Guid? OrgId, int QueueDepth, AggregateDriftReport? Report);

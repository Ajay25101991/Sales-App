namespace SalesApi.Dtos;

/// <summary>
/// The vocabulary of facts the event backbone (E1,
/// to-do/e1-event-backbone-design.md §4) can raise — the registered-vocabulary
/// discipline <c>WebhookEvents</c>/<c>NotificationEvents.Keys</c> already use,
/// moved to the Contracts project (not <c>SalesApi.Services</c>, where those
/// two live) because both ProcessApi (raises) and ExperienceApi (reads, for
/// E1.4/E1.6 shaping) need to see the type name without either depending on
/// SystemApi.
///
/// Step 4 (to-do/e1-event-backbone-design.md §8) wired a real call site (see
/// each <see cref="Definition.RaisedBy"/>) for every type except the two
/// scheduled-scan producers (AMC expiry, collection escalation) design §8
/// deferred to step 9. Step 9 wired those two (<c>AmcService.GenerateAsync</c>,
/// <c>CollectionEscalationService.RunAsync</c>) and added the scans' own
/// <c>lead.idle</c>/<c>collection.escalated</c> output events, so
/// <see cref="DeferredToStep9"/> is now empty and <c>DomainEventTypeCatalogTests</c>
/// asserts every declared type has a raising site, the same "every declared
/// event names its emission site" discipline <c>WebhookEventCatalogTests</c>
/// already applies.
///
/// Growing the catalogue is still a code change: a declaration here, plus
/// the one-line <c>DomainEvents.Raise</c> call at the real trigger.
/// </summary>
public static class DomainEventTypes
{
    /// <summary><paramref name="RaisedBy"/> names the file:method that calls
    /// <c>DomainEvents.Raise</c> for this type — same self-documenting discipline
    /// as <c>WebhookEvents.Definition.RaisedBy</c>. Null is no longer valid for
    /// any declared type as of step 9 — <see cref="DeferredToStep9"/> is empty
    /// and <c>DomainEventTypeCatalogTests</c> enforces this for every entry.</summary>
    public sealed record Definition(string Key, string AggregateType, string? RaisedBy = null);

    /// <summary>"lead" | "account" | "contact" | "invoice" | "quote" | "amc" |
    /// "approval" | "reminder" | "import" — the <see cref="Models.DomainEvent.AggregateType"/>
    /// values named in design §2, in one place so a typo in a raise call site
    /// is a compile error rather than a silently-wrong string.</summary>
    public static class AggregateTypes
    {
        public const string Lead = "lead";
        public const string Account = "account";
        public const string Contact = "contact";
        public const string Invoice = "invoice";
        public const string Quote = "quote";
        public const string Amc = "amc";
        public const string Approval = "approval";
        public const string Reminder = "reminder";
        public const string Import = "import";
        public const string Task = "task";
        /// <summary>E19.5: a self sign-up application (the aggregate of <c>sign_up.submitted</c> / <c>sign_up.flagged</c>).</summary>
        public const string SignUpApplication = "sign_up_application";
        /// <summary>An API key (the aggregate of the <c>api_key.*</c> audit events). Never carries key material.</summary>
        public const string ApiKey = "api_key";
        /// <summary>A person's MCP access override (the aggregate id is the person; the aggregate of <c>mcp_access.changed</c>).</summary>
        public const string McpAccess = "mcp_access";
    }

    public static class Keys
    {
        public const string LeadCreated = "lead.created";
        public const string LeadAssigned = "lead.assigned";
        public const string LeadStageChanged = "lead.stage_changed";
        public const string LeadValueChanged = "lead.value_changed";
        public const string LeadClosedWon = "lead.closed_won";
        public const string LeadClosedLost = "lead.closed_lost";
        public const string LeadReopened = "lead.reopened";
        public const string ContactCreated = "contact.created";
        public const string ContactUpdated = "contact.updated";
        public const string AccountCreated = "account.created";
        public const string AccountUpdated = "account.updated";
        /// <summary>Accounts rework (decision 5): an account's owner changed. AggregateType is Account;
        /// NotificationDomainEventHandler reacts like it does to <see cref="LeadAssigned"/>.</summary>
        public const string AccountAssigned = "account.assigned";
        public const string LeadUpdated = "lead.updated";
        /// <summary>E-invoicing IRL: the client pressed Submit on the IRL link (a re-submit after more edits raises it again).</summary>
        public const string IrlSubmitted = "irl.submitted";
        /// <summary>E-invoicing IRL: the client changed their answers after submitting; raised once per edit session (the first save after a submit).</summary>
        public const string IrlEdited = "irl.edited";
        /// <summary>E15 document request: the client pressed Submit on the document-request link. AggregateType is Account; NotificationDomainEventHandler tells the rep who sent it and the account owner.</summary>
        public const string DocumentRequestCompleted = "document_request.completed";
        /// <summary>E19.2: a portal user submitted (or re-submitted) a proposed edit to an account or contact. AggregateType is Account (the account itself, or the contact's account);
        /// NotificationDomainEventHandler tells the account's owner.</summary>
        public const string RecordChangeSubmitted = "record_change.submitted";
        /// <summary>E19.2: staff approved or rejected a portal user's proposed edit. AggregateType is Account; NotificationDomainEventHandler tells the requester.</summary>
        public const string RecordChangeDecided = "record_change.decided";
        /// <summary>E19.5: an applicant pressed Submit on their sign-up application. AggregateType is SignUpApplication; NotificationDomainEventHandler tells every holder of Manage partners.</summary>
        public const string SignUpSubmitted = "sign_up.submitted";
        /// <summary>E19.5: a verified sign-up looked like an existing account and was held for staff. AggregateType is SignUpApplication; NotificationDomainEventHandler tells every holder of Manage partners.</summary>
        public const string SignUpFlagged = "sign_up.flagged";
        public const string QuoteUpdated = "quote.updated";
        public const string InvoiceUpdated = "invoice.updated";
        public const string AmcUpdated = "amc.updated";
        public const string AccountParentChanged = "account.parent_changed";
        public const string AccountRelationshipAdded = "account.relationship_added";
        public const string AccountRelationshipRemoved = "account.relationship_removed";
        public const string ActivityLogged = "activity.logged";
        public const string ReminderDue = "reminder.due";
        public const string ReminderCompleted = "reminder.completed";
        public const string ApprovalRequested = "approval.requested";
        public const string ApprovalDecided = "approval.decided";
        public const string QuoteSent = "quote.sent";
        public const string QuoteAccepted = "quote.accepted";
        public const string QuoteDeclined = "quote.declined";
        /// <summary>E10.9 - the customer typed their name on the engagement letter's secure link. AggregateType is Quote (the accepted
        /// proposal), so automation conditions and set_field act on that quote's deal exactly as for quote.accepted.</summary>
        public const string EngagementLetterAccepted = "engagement_letter.accepted";
        /// <summary>E6.3 — the public quote-accept page was rendered for a
        /// COUNTED view (a known bot, or a repeat open within the 30-minute
        /// collapse window, never raises this). One per counted view, not one
        /// per calendar day — the per-day collapse is a TIMELINE rendering rule
        /// (TimelineService), not a raise-time one, so an automation watching
        /// this trigger still sees every real open.</summary>
        public const string QuoteViewed = "quote.viewed";
        public const string InvoiceRaised = "invoice.raised";
        public const string InvoicePaid = "invoice.paid";
        public const string InvoiceOverdue = "invoice.overdue";
        public const string PaymentReceived = "payment.received";
        public const string AmcRenewed = "amc.renewed";
        public const string AmcExpiring = "amc.expiring";
        public const string ImportCompleted = "import.completed";

        /// <summary>Step 9 (design §5, "idle nudges … both, during transition"):
        /// <c>IdleLeadService</c>'s scheduled scan raises this alongside the
        /// reminder it already creates for a lead that crossed the idle SLA.</summary>
        public const string TaskCreated = "task.created";
        public const string TaskCompleted = "task.completed";
        public const string TaskReassigned = "task.reassigned";

        public const string LeadIdle = "lead.idle";

        /// <summary>E3.3 — a lead's buying-committee stakeholders changed.
        /// AggregateType is Lead (not Contact): these are facts about THIS
        /// deal's committee, same reasoning ActivityLogged uses Lead rather
        /// than the activity's own identity.</summary>
        public const string StakeholderAdded = "stakeholder.added";
        public const string StakeholderRemoved = "stakeholder.removed";
        public const string StakeholderChanged = "stakeholder.changed";

        /// <summary>Step 9 (design §5, "collection escalation … same shape as
        /// idle nudges"): <c>CollectionEscalationService</c>'s scheduled scan
        /// raises this when a collection task's priority actually moves up a
        /// rank — never on a re-examined-but-unchanged pass.</summary>
        public const string CollectionEscalated = "collection.escalated";

        /// <summary>E3.7 — a lead's methodology checklist item was marked or
        /// unmarked done. AggregateType is Lead, same reasoning as the
        /// stakeholder events above (a fact about THIS deal's qualification,
        /// not about any org-wide definition).</summary>
        public const string QualificationItemCompleted = "qualification_item.completed";
        public const string QualificationItemUncompleted = "qualification_item.uncompleted";

        /// <summary>E6.1/E6.2 (design doc to-do/e6-capture-design.md §5.1) —
        /// ambient capture: an inbound/outbound email, or a calendar meeting
        /// scheduled/completed, matched to a lead (§4.1). AggregateType is
        /// Lead, same reasoning as the stakeholder/qualification events above
        /// (a fact about THIS deal's relationship, not a globally-addressable
        /// mail/calendar object). Declared in this story (slice 1); the sync
        /// worker that raises them (design §9 slices 4/10) is a later story —
        /// see RaisedBy below, which names where that raise call will live.</summary>
        public const string EmailReceived = "email.received";
        public const string EmailSent = "email.sent";
        public const string MeetingScheduled = "meeting.scheduled";
        public const string MeetingCompleted = "meeting.completed";

        /// <summary>E6.4 (design doc to-do/e6-connectors-design.md §5.1) — a
        /// WhatsApp message sent to, or received from, a lead's matched
        /// WhatsApp number. AggregateType is Lead, same reasoning as
        /// EmailReceived/EmailSent above (a fact about THIS deal's
        /// relationship). Unlike email, the message BODY does ride in the
        /// payload (§4.4: "a WhatsApp message has no equivalent 'open the
        /// real app' affordance a rep can click"), so TimelineService reads
        /// it straight off the generic domain-event stream with no dedicated
        /// mutable table — see WhatsAppSendProcess/WhatsAppInboundProcess.</summary>
        public const string WhatsAppReceived = "whatsapp.received";
        public const string WhatsAppSent = "whatsapp.sent";
        /// <summary>
        /// LinkedIn Lead Gen Form submission synced in as a lead (or folded
        /// into an existing open deal's timeline as a note, per the org's
        /// duplicate-mode setting — see <c>LinkedInLeadSyncProcess</c>). Raised
        /// once per newly CREATED lead only, never for the append-note branch
        /// (that fact is already the note's own timeline entry, no separate
        /// event needed — same "closed never blocks, open appends" shape
        /// E3.11's other unattended paths already follow).</summary>
        public const string LinkedInLeadCreated = "linkedin_lead.created";
        /// <summary>A Facebook / Instagram Lead Ad submission synced in as a lead (the Meta Lead Ads connector, sibling of
        /// <see cref="LinkedInLeadCreated"/>). Raised once per newly CREATED lead only - a skipped backfill match or an
        /// appended note raises nothing, same rule as LinkedIn.</summary>
        public const string MetaLeadCreated = "meta_lead.created";
        /// <summary>A lead made by an unattended intake (website form, WhatsApp inbound, a person turning a WhatsApp or
        /// email review row into a lead) so its owner can be told. NOTIFICATION ONLY: see <see cref="NotificationOnly"/> -
        /// no webhook, no automation trigger, no timeline row.</summary>
        public const string LeadRoutedIn = "lead.routed_in";
        /// <summary>A proposal / quote was generated, regenerated or revised for a lead (owner 2026-11-11, so a "proposal" recommended action can tick
        /// itself - RecommendationDomainEventHandler). INTERNAL: see <see cref="NotificationOnly"/> - no webhook, no automation trigger, no timeline
        /// row (the note activity written beside it is the timeline entry).</summary>
        public const string ProposalGenerated = "proposal.generated";
        /// <summary>Integrations audit (owner decision, API keys): an API key was created, edited, revoked or rotated. AUDIT ONLY: see
        /// <see cref="NotificationOnly"/> - recorded in <c>domain_events</c> (who, when, which key id and name, never the key), not a
        /// webhook, automation trigger or timeline row.</summary>
        public const string ApiKeyCreated = "api_key.created";
        public const string ApiKeyUpdated = "api_key.updated";
        public const string ApiKeyRevoked = "api_key.revoked";
        public const string ApiKeyRotated = "api_key.rotated";
        /// <summary>An admin set, changed or cleared one person's "Connect AI tools" override (allow / block / follows role). AUDIT ONLY: see <see cref="NotificationOnly"/>.</summary>
        public const string McpAccessChanged = "mcp_access.changed";

        public static readonly string[] Registered =
        [
            LeadCreated, LeadAssigned, LeadStageChanged, LeadValueChanged, LeadClosedWon, LeadClosedLost,
            LeadReopened, ContactCreated, ContactUpdated, AccountCreated, AccountUpdated, AccountAssigned, ActivityLogged,
            ReminderDue, ReminderCompleted, ApprovalRequested, ApprovalDecided, QuoteSent, QuoteAccepted,
            QuoteDeclined, EngagementLetterAccepted, QuoteViewed, InvoiceRaised, InvoicePaid, InvoiceOverdue, PaymentReceived, AmcRenewed,
            AmcExpiring, ImportCompleted, LeadIdle, CollectionEscalated,
            TaskCreated, TaskCompleted, TaskReassigned,
            AccountParentChanged, AccountRelationshipAdded, AccountRelationshipRemoved,
            StakeholderAdded, StakeholderRemoved, StakeholderChanged,
            QualificationItemCompleted, QualificationItemUncompleted,
            EmailReceived, EmailSent, MeetingScheduled, MeetingCompleted,
            WhatsAppReceived, WhatsAppSent,
            LinkedInLeadCreated, MetaLeadCreated, LeadRoutedIn, ProposalGenerated,
            LeadUpdated, QuoteUpdated, InvoiceUpdated, AmcUpdated,
            IrlSubmitted, IrlEdited, DocumentRequestCompleted, RecordChangeSubmitted, RecordChangeDecided,
            SignUpSubmitted, SignUpFlagged,
            ApiKeyCreated, ApiKeyUpdated, ApiKeyRevoked, ApiKeyRotated, McpAccessChanged,
        ];
    }

    // design §4's table, minus the dropped `QuoteExpired` (owner decision
    // 2026-09-26 — no expiry sweep exists to raise it from; becomes an E2.2
    // trigger instead), plus `LeadIdle`/`CollectionEscalated` (design §5 —
    // added beyond §4's starting list so the scans' own output is a real
    // event, not just a reminder/notification). Every entry has a RaisedBy as
    // of step 9.
    public static readonly Definition[] All =
    [
        new(Keys.LeadCreated, AggregateTypes.Lead, "LeadWriteProcess.CreateAsync; LeadImportProcess.ImportAsync (one per imported row)"),
        new(Keys.LeadAssigned, AggregateTypes.Lead, "LeadAssignProcess.AssignAsync; LeadWriteProcess.BulkAsync (assign action)"),
        new(Keys.LeadStageChanged, AggregateTypes.Lead, "StageService.AddStageEvent (every call site: LeadWriteProcess.UpdateAsync/BulkAsync, ApprovalProcess.DecideAsync, WorkflowStore.PublishAsync)"),
        new(Keys.LeadValueChanged, AggregateTypes.Lead, "LeadWriteProcess.UpdateAsync"),
        new(Keys.LeadClosedWon, AggregateTypes.Lead, "LeadWriteProcess.UpdateAsync; ApprovalProcess.DecideAsync (gate-exception won branch)"),
        new(Keys.LeadClosedLost, AggregateTypes.Lead, "LeadWriteProcess.UpdateAsync"),
        new(Keys.LeadReopened, AggregateTypes.Lead, "LeadWriteProcess.UpdateAsync (reopening branch); ApprovalProcess.DecideAsync (reopen branch)"),
        new(Keys.ContactCreated, AggregateTypes.Contact, "AccountProcess.AddContactAsync; ContactPromotionService.PromoteAsync"),
        new(Keys.ContactUpdated, AggregateTypes.Contact, "ContactProcess.UpdateAsync"),
        new(Keys.AccountCreated, AggregateTypes.Account, "AccountProcess.CreateAsync; LeadWriteProcess.CreateAsync/ApplyAccountLink; AccountLinkService.FindOrCreateAccountAsync; LeadImportProcess.ImportAsync"),
        new(Keys.AccountUpdated, AggregateTypes.Account, "AccountProcess.UpdateAsync"),
        new(Keys.AccountAssigned, AggregateTypes.Account, "AccountProcess.AssignAsync; AccountProcess.BulkAsync (assign action)"),
        new(Keys.ActivityLogged, AggregateTypes.Lead, "LeadReadProcess.AddActivityAsync; AccountProcess.AddActivityAsync (lead-filed: Lead aggregate; no deal: Account aggregate)"),
        new(Keys.ReminderDue, AggregateTypes.Reminder, "ReminderSweeper.SweepAsync"),
        new(Keys.ReminderCompleted, AggregateTypes.Reminder, "ReminderProcess.UpdateAsync (status -> done)"),
        new(Keys.ApprovalRequested, AggregateTypes.Approval, "ApprovalProcess.CreateAsync"),
        new(Keys.ApprovalDecided, AggregateTypes.Approval, "ApprovalProcess.DecideAsync"),
        new(Keys.QuoteSent, AggregateTypes.Quote, "LeadQuoteProcess.UpdateAsync (status -> sent)"),
        new(Keys.QuoteAccepted, AggregateTypes.Quote, "QuoteProcess.AcceptAsync; LeadQuoteProcess.UpdateAsync (status -> accepted)"),
        new(Keys.QuoteDeclined, AggregateTypes.Quote, "LeadQuoteProcess.UpdateAsync (status -> declined)"),
        new(Keys.EngagementLetterAccepted, AggregateTypes.Quote, "EngagementLetterAcceptProcess.AcceptAsync (the public engagement-letter accept link)"),
        new(Keys.QuoteViewed, AggregateTypes.Quote, "QuoteProcess.ViewAsync (once per counted view of the public accept page)"),
        new(Keys.InvoiceRaised, AggregateTypes.Invoice, "PaymentWorkflowService.OnInvoiceRaisedAsync (shared by InvoiceProcess.CreateAsync and RaiseAsync)"),
        new(Keys.InvoicePaid, AggregateTypes.Invoice, "InvoiceProcess.RecordPaymentAsync"),
        new(Keys.InvoiceOverdue, AggregateTypes.Invoice, "CollectionEscalationService.RunAsync (first transition of a task's priority off \"normal\")"),
        new(Keys.PaymentReceived, AggregateTypes.Invoice, "InvoiceProcess.RecordPaymentAsync"),
        new(Keys.AmcRenewed, AggregateTypes.Amc, "AmcProcess.RenewAsync"),
        new(Keys.AmcExpiring, AggregateTypes.Amc, "AmcService.GenerateAsync (once per created pre-renewal reminder, piggybacking on its own per-offset/day dedupe)"),
        new(Keys.ImportCompleted, AggregateTypes.Import, "LeadImportProcess.ImportAsync (once per import run)"),
        new(Keys.LeadIdle, AggregateTypes.Lead, "IdleLeadService.GenerateAsync (once per idle nudge actually created, none on dedupe)"),
        new(Keys.CollectionEscalated, AggregateTypes.Invoice, "CollectionEscalationService.RunAsync (once per task priority transition)"),
        new(Keys.TaskCreated, AggregateTypes.Task, "TaskProcess.CreateAsync"),
        new(Keys.TaskCompleted, AggregateTypes.Task, "TaskProcess.CompleteAsync (also UpdateAsync's status -> done branch)"),
        new(Keys.TaskReassigned, AggregateTypes.Task, "TaskProcess.BulkReassignAsync (also UpdateAsync's assignee-change branch)"),
        new(Keys.AccountParentChanged, AggregateTypes.Account, "AccountProcess.SetParentAsync"),
        new(Keys.AccountRelationshipAdded, AggregateTypes.Account, "AccountProcess.AddRelationshipAsync"),
        new(Keys.AccountRelationshipRemoved, AggregateTypes.Account, "AccountProcess.RemoveRelationshipAsync"),
        new(Keys.StakeholderAdded, AggregateTypes.Lead, "StakeholderProcess.AddAsync"),
        new(Keys.StakeholderRemoved, AggregateTypes.Lead, "StakeholderProcess.RemoveAsync"),
        new(Keys.StakeholderChanged, AggregateTypes.Lead, "StakeholderProcess.UpdateAsync"),
        new(Keys.QualificationItemCompleted, AggregateTypes.Lead, "LeadQualificationProcess.CompleteAsync"),
        new(Keys.QualificationItemUncompleted, AggregateTypes.Lead, "LeadQualificationProcess.UncompleteAsync"),
        // E6.1/E6.2 (design doc to-do/e6-capture-design.md §5.1) — the sync
        // worker that raises these is a later story (design §9 slices 4/10),
        // so RaisedBy names the future call site the design already commits
        // to, not one that exists yet. Declared now (this story's slice 1)
        // so automations (E2) and the raising code, when it lands, both find
        // the vocabulary already registered — the same "declared, wired
        // later" step the E1 backbone itself went through.
        new(Keys.EmailReceived, AggregateTypes.Lead, "MailboxSyncProcess.SyncOneAsync (mail branch, inbound — not built by this story, see to-do/e6-capture-design.md §9 slice 4)"),
        new(Keys.EmailSent, AggregateTypes.Lead, "MailboxSyncProcess.SyncOneAsync (mail branch, outbound Sent Items delta — not built by this story, see to-do/e6-capture-design.md §9 slice 4)"),
        // E6.2 story slice 10 — built. MeetingScheduled fires once, on FIRST
        // log (design §5.1); a later Graph delta update to the same iCalUId
        // mutates MailboxLoggedMeeting in place (TimelineService.MeetingsAsync
        // reads the current row) and raises nothing further.
        new(Keys.MeetingScheduled, AggregateTypes.Lead, "MailboxSyncProcess.ProcessCalendarEventAsync (calendar branch, first log of a new iCalUId)"),
        new(Keys.MeetingCompleted, AggregateTypes.Lead, "MailboxSyncProcess.RunCompletedScanAsync (calendar branch's completed-meeting scan, design §6.3)"),
        // E6.4 story slices 3/4 (design §3.3/§3.6) — built.
        new(Keys.WhatsAppSent, AggregateTypes.Lead, "WhatsAppSendProcess.SendAsync (session-message send, on success)"),
        new(Keys.WhatsAppReceived, AggregateTypes.Lead, "WhatsAppInboundProcess.HandleMessageAsync (known-sender inbound text message)"),
        // E6.4 (design doc to-do/e6-connectors-design.md §5.1/§9 slice 11).
        new(Keys.LinkedInLeadCreated, AggregateTypes.Lead, "LinkedInLeadSyncProcess.SyncOneAsync (once per newly created lead, never on the append-note branch)"),
        new(Keys.MetaLeadCreated, AggregateTypes.Lead, "CapturedLeadWriter.ApplyAsync via MetaLeadSyncProcess (once per newly created lead, never on the append-note or backfill-skip branch)"),
        new(Keys.LeadRoutedIn, AggregateTypes.Lead, "PublicIntakeStore.CreateLeadAsync (website form, WhatsApp inbound, WhatsApp and email review-row Create lead; not LinkedIn or the team mailbox, which raise their own creation event)"),
        new(Keys.ProposalGenerated, AggregateTypes.Lead, "LeadQuoteProcess.GenerateAsync / GenerateDocumentAsync / ReviseAsync (quote builder paths); ProposalGenerateProcess.GenerateAsync (proposal generator: new version, or unsent draft replaced) - one per call, in the same save as the note"),
        new(Keys.LeadUpdated, AggregateTypes.Lead, "LeadWriteProcess.UpdateAsync; PaymentWorkflowService.OnDealWonAsync (account link); LeadMergeProcess (merge and undo); AccountProcess.BulkLinkLeadsAsync (account link); LeadImportProcess (update-existing rows) - name, company or account link changed"),
        new(Keys.QuoteUpdated, AggregateTypes.Quote, "LeadQuoteProcess.UpdateAsync (title edited); LeadQuoteProcess send path (number minted)"),
        new(Keys.InvoiceUpdated, AggregateTypes.Invoice, "InvoiceProcess.UpdateAsync (number edited); InvoiceProcess.RaiseAsync (number minted)"),
        new(Keys.AmcUpdated, AggregateTypes.Amc, "AmcProcess.UpdateAsync (title edited)"),
        new(Keys.IrlSubmitted, AggregateTypes.Lead, "IrlPublicProcess.SubmitAsync (the client's Submit on the public IRL link)"),
        new(Keys.IrlEdited, AggregateTypes.Lead, "IrlPublicProcess.SaveAsync (the first client save after a submit)"),
        new(Keys.DocumentRequestCompleted, AggregateTypes.Account, "DocumentRequestPublicProcess.SubmitAsync (the client's Submit on the public document-request link)"),
        new(Keys.RecordChangeSubmitted, AggregateTypes.Account, "RecordChangeRequestProcess.SubmitAsync (a portal user's proposed edit, first submit and re-submit)"),
        new(Keys.RecordChangeDecided, AggregateTypes.Account, "RecordChangeRequestProcess.ApproveAsync / RejectAsync (staff decision on a proposed edit)"),
        new(Keys.SignUpSubmitted, AggregateTypes.SignUpApplication, "SignUpProcess.SubmitAsync (the applicant's Submit)"),
        new(Keys.SignUpFlagged, AggregateTypes.SignUpApplication, "SignUpProcess.VerifyAsync (a verified sign-up that matched an existing account, held for staff)"),
        new(Keys.ApiKeyCreated, AggregateTypes.ApiKey, "ApiKeyProcess.CreateAsync"),
        new(Keys.ApiKeyUpdated, AggregateTypes.ApiKey, "ApiKeyProcess.UpdateAsync (name or scopes changed)"),
        new(Keys.ApiKeyRevoked, AggregateTypes.ApiKey, "ApiKeyProcess.RevokeAsync (the first revoke only)"),
        new(Keys.ApiKeyRotated, AggregateTypes.ApiKey, "ApiKeyProcess.RotateAsync (aggregate = the old key; payload names the new one)"),
        new(Keys.McpAccessChanged, AggregateTypes.McpAccess, "McpConnectionsProcess.SetAccessAsync via McpCallStore.SaveAccessAsync (one per person whose override actually changed)"),
    ];

    /// <summary>Step 9 (design §8) migrated both remaining scheduled-scan
    /// producers, so this is now empty — <see cref="DomainEventTypeCatalogTests"/>
    /// requires every declared type to name a real raising call site. Kept as a
    /// declared (empty) array rather than deleted so a FUTURE deferred type has
    /// an obvious place to go, and so the test that reads it doesn't need a
    /// null check.</summary>
    public static readonly string[] DeferredToStep9 = [];

    /// <summary>Internal types: only an internal handler reacts (notification handler for lead.routed_in, recommendation handler for proposal.generated). They stay out of the webhook and automation handlers, the
    /// webhook catalogue (which is also the automation builder's trigger list) and the lead timeline, so a new intake
    /// notification cannot become a trigger, a subscribable event or a timeline row by accident.</summary>
    public static readonly string[] NotificationOnly =
        [Keys.LeadRoutedIn, Keys.ProposalGenerated, Keys.ApiKeyCreated, Keys.ApiKeyUpdated, Keys.ApiKeyRevoked, Keys.ApiKeyRotated, Keys.McpAccessChanged];

    private static readonly Dictionary<string, Definition> ByKey =
        All.ToDictionary(d => d.Key, StringComparer.Ordinal);

    public static Definition? Find(string? key) => key is not null && ByKey.TryGetValue(key, out var d) ? d : null;

    public static bool IsKnown(string? key) => Find(key) is not null;
}

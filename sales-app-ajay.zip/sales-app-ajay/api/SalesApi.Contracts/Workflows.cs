// The Workflows contracts.
//
// Split out of WorkflowsController.cs on 2026-08-28 (API-led migration, step
// 8): Experience cannot see System, so a contract it must return has to live
// in this reference-free project. None of these named a System type before
// the move either — OrganizationWorkflow (the stored entity) never appeared
// on the wire, so nothing had to be mapped, only relocated.
//
// The namespace is `SalesApi.Dtos`, matching every other split-out contract
// file (see Goals.cs, Settings.cs) — moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// POST/PUT body for a workflow draft. Stages carry the full designer shape
// (StageDefDto, defined in Settings.cs) since a workflow owns its whole
// pipeline design.
public record WorkflowInput(string? Name, string? Description, List<StageDefDto>? Stages);

// API response shape for a workflow — adds StagesInSync (computed in
// WorkflowProcess.ToDto) on top of the stored OrganizationWorkflow model.
public record WorkflowResponseDto(
    Guid Id, string Name, string? Description, List<StageDefDto> Stages, bool IsActive,
    bool StagesInSync, Guid CreatedBy, DateTime CreatedAt, DateTime UpdatedAt, DateTime? PublishedAt);

// Count + total estimated value of leads sitting on one stage key that a
// publish would remove (or, with zero/zero, a key it would add).
//
// LeadCount is always present — it is the guard on a destructive operation.
// TotalValue is null for a caller without lead_values.aggregate; see
// WorkflowProcess.ComputeImpactAsync.
public record StagePublishImpactDto(string Key, string Label, int LeadCount, decimal? TotalValue);
public record WorkflowPublishPreviewDto(List<StagePublishImpactDto> Removed, List<StagePublishImpactDto> Added);

// Manager-supplied remap for the publish: removed stage key -> destination
// stage key (one of the new workflow's stage keys, or "won"/"lost") for every
// removed stage that currently holds leads.
public record PublishInput(Dictionary<string, string>? Remap);

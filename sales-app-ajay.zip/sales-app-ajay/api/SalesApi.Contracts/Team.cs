// The Team contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Team / user management ---
// OrgId lets a suntech-admin create the user in another organization; ignored for
// regular managers (who always create in their own org).
// TeamId carries THREE states, and a plain Guid? cannot: System.Text.Json binds
// both an omitted property and an explicit null to null, so "leave them
// unassigned" would be indistinguishable from "an older app build didn't send
// the field" — and the default would silently win over the manager's choice.
// Hence a string:
//   omitted / null  -> the org's default team (unchanged behaviour, and what
//                      every existing client and the registration path get)
//   "none"          -> no team; the person is created unassigned
//   a guid          -> that team
public record CreateUserInput(
    string? Email, string? FullName, string? Role, string? Password, Guid? OrgId,
    string? TeamId = null);
// TempPassword is returned only when the server generated one (share it once) —
// still populated even when an invite email was also sent, so an admin whose
// mail server is flaky is never left with literally nothing to hand the new
// hire. InviteEmailSent/InviteEmailError are ONLY present when an invite email
// was attempted at all (self-serve create, i.e. Password omitted): true+null
// means the invitee has a working set-your-own-password link; false+a reason
// means they do not, and the admin must be told loudly rather than assume the
// "invite sent" toast means the email went anywhere — see TeamController.Create.
public record CreateUserResult(ProfileDto User, string? TempPassword, bool? InviteEmailSent = null, string? InviteEmailError = null);
public record UpdateTeamMemberInput(string? Role, bool? IsActive);

/// <summary>
/// Which of a person's teams their work counts toward. Null CLEARS it, which is
/// a real answer rather than an omission — someone on a single team needs no
/// primary, because resolution answers them from that one membership.
///
/// Its own endpoint rather than a field on UpdateTeamMemberInput: a nullable
/// Guid there cannot distinguish "clear it" from "not supplied", and clearing
/// has to be expressible.
/// </summary>
public record PrimaryTeamInput(Guid? TeamId);

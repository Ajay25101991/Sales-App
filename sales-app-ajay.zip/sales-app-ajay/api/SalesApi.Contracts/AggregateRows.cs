// E18.1 - the RAW stored aggregate rows behind the account-field dimension and the stage-entry counts. No labels, no tiles, no derived rates: what each
// figure means and where it shows is the owner's call (asked per figure before the screens story). Keys are ids / stage keys; a client resolves names.
//
// The namespace stays `SalesApi.Dtos` for the same reason as every other contract file (see Reports.cs).

namespace SalesApi.Dtos;

/// <summary>
/// GET /dashboard/pipeline-by-account-field. One row per stored (owner, team, playbook, stage, account-field value) bucket of the pipeline snapshot in
/// the caller's scope. <c>Dimension</c> is the org setting in force ("" = off: every row then has <c>AccountDim</c> "" and the rows are just the
/// ordinary snapshot). <c>ValuesVisible</c> false means <c>LeadValue</c> was zeroed at this edge (counts stay real).
/// </summary>
public record PipelineByAccountFieldDto(string Dimension, bool ValuesVisible, List<PipelineByAccountFieldRowDto> Rows);
public record PipelineByAccountFieldRowDto(Guid UserId, Guid TeamId, Guid PlaybookId, string Status, string AccountDim, int LeadCount, decimal LeadValue);

/// <summary>
/// GET /dashboard/stage-entries?from=yyyy-MM-dd&amp;to=yyyy-MM-dd. One row per stored (org-local month, stage, owner, playbook, team, account-field value)
/// with the number of times deals ENTERED that stage in that month. <c>From</c>/<c>To</c> echo the first and last month returned
/// ("yyyy-MM"; the request's dates are widened to whole months).
/// </summary>
public record StageEntriesDto(string Dimension, string From, string To, List<StageEntryRowDto> Rows);
public record StageEntryRowDto(int Year, int Month, Guid UserId, Guid TeamId, Guid PlaybookId, string Status, string AccountDim, int EntryCount);

/// <summary>
/// GET /dashboard/amc-renewals?from=yyyy-MM-dd&amp;to=yyyy-MM-dd. One row per stored (month, contract owner, playbook, team) with the AMC terms DUE in that
/// month (by the literal month of the term's end date) and how many of them were RENEWED (the contract has a later term, whenever it was created) - counts
/// and values; the renewal rate is divided by the client. <c>Partial</c> is true for a month after the current org-local month: its renewals have not had
/// time to happen, so a low rate there is not a result. <c>ValuesVisible</c> false means both values were zeroed at this edge (counts stay real).
/// </summary>
public record AmcRenewalsDto(string From, string To, bool ValuesVisible, List<AmcRenewalRowDto> Rows);
public record AmcRenewalRowDto(
    int Year, int Month, Guid UserId, Guid TeamId, Guid PlaybookId, int DueCount, int RenewedCount, decimal DueValue, decimal RenewedValue, bool Partial);

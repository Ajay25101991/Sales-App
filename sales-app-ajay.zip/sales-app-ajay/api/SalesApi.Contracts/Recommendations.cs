namespace SalesApi.Dtos;

// ---- Recommended actions per workflow stage (owner 2026-11-11, to-do/workflow-recommended-actions-design.md) ------------------------------

/// <summary>The fixed list of app actions a recommendation can open. Anything else is refused on draft save and publish.</summary>
public static class RecommendedActionKinds
{
    public const string EmailTemplate = "email_template";
    public const string Meeting = "meeting";
    public const string Call = "call";
    public const string Proposal = "proposal";
    public const string Agreement = "agreement";
    public const string Irl = "irl";
    public const string DocumentRequest = "document_request";
    public const string Task = "task";
    /// <summary>Open the delivery-services ask (POST /leads/{id}/delivery-project). Done is DERIVED on read: the deal has a delivery project row (one per deal).</summary>
    public const string DeliveryProject = "delivery_project";
    public static readonly string[] All = [EmailTemplate, Meeting, Call, Proposal, Agreement, Irl, DocumentRequest, Task, DeliveryProject];
}

/// <summary>The one app action a recommendation opens. <c>template_id</c> is required for <c>email_template</c> (a live email template of the org) and absent otherwise.
/// <c>assignee_role</c> (owner 2026-11-16) only means something for <c>task</c>: the role key whose shared queue the New task dialog presets; dropped for every other kind.
/// <c>assignee_user_id</c> (owner 2026-11-24) is the other preset for <c>task</c>: a named person instead of a role queue. At most one of the two is set (the person wins when a draft carries both).
/// </summary>
public record RecommendedActionDto(string Kind, Guid? TemplateId = null, string? AssigneeRole = null, Guid? AssigneeUserId = null);

/// <summary>
/// One recommended next step on a workflow stage (stage_snapshot <c>recommended</c>, beside <c>tasks_on_enter</c>). Id is a stable definition id, unique
/// within the stage (per-lead done/dismissed state hangs on it). Label is the guidance text (required, at most 120 characters). Action is optional:
/// a guidance-only item has none. At most 10 per stage. Never blocks a stage move.
/// </summary>
public record StageRecommendationDto(string Id, string Label, RecommendedActionDto? Action = null);

public static class RecommendationStatuses
{
    public const string Open = "open";
    public const string Done = "done";
    public const string Dismissed = "dismissed";
}

/// <summary>
/// One recommendation as a lead sees it: the definition plus its state for THIS entry into the stage. Status is open | done | dismissed;
/// <c>auto</c> is true when the linked action ticked it (not a person); <c>at</c> / <c>by_user_id</c> are null while open.
/// </summary>
public record LeadRecommendationDto(
    string Id, string Label, RecommendedActionDto? Action, string Status, bool Auto = false, DateTime? At = null, Guid? ByUserId = null);

/// <summary>
/// GET /leads/{id}/recommendations - the lead's CURRENT stage (resolved against the lead's own workflow) and its recommendations with their state.
/// <c>entered_at</c> is the instant the lead entered the stage this time; state from an earlier entry is ignored. Items is empty when the stage has none.
/// POST /leads/{id}/recommendations/{recommendation_id}/done | dismiss | undo answers with the same body.
/// </summary>
public record LeadRecommendationsDto(string StageKey, string StageLabel, DateTime EnteredAt, List<LeadRecommendationDto> Items);

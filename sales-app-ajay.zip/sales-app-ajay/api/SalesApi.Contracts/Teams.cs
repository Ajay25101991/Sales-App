// The Teams contracts — API-led migration, step 8 (to-do/api-led-migration-plan.md).
//
// TeamSummaryDto, TeamDetailDto, TeamInput and TeamMembersInput already lived in
// SalesApi.Contracts/Auth.cs (moved there when Dtos.cs was split, since ProfileDto
// embeds TeamSummaryDto), and CalendarSettingsDto/Input already lived in Calendar.cs
// (shared with SettingsController's org-level calendar). Nothing new was needed for
// those. This file holds only what the /teams vertical itself introduces.
//
// Namespace stays `SalesApi.Dtos` — see the other Contracts files for why.

namespace SalesApi.Dtos;

/// <summary>
/// The three distinct outcomes of <c>DELETE /teams/{id}</c>, kept as a value rather
/// than folded into <c>TeamProcess.Refusal</c> — archiving an already-archived team is
/// not a refusal (the request still succeeds, 200), it is a different SUCCESS shape:
/// the endpoint omits <c>detached</c> entirely rather than sending <c>detached: 0</c>,
/// so a client cannot tell "nothing was attributed to this team" from "this call did
/// not run the detach step at all". Collapsing the two into one boolean plus a count
/// would have silently changed that response shape.
/// </summary>
public enum TeamArchiveOutcome
{
    NotFound,
    AlreadyArchived,
    Archived,
    /// <summary>The team to move the members to is missing, archived, or the team being archived.</summary>
    InvalidDestination,
}

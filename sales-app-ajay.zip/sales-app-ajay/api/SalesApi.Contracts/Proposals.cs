// The Proposals contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Proposals ---
// The old ProposalModule price-list contracts are gone (E10.1): the catalogue
// (CatalogItemDto, CatalogItems.cs) carries the price now.

/// <summary>
/// A quote as the customer-facing page needs it — the ELEVEN fields that page
/// actually renders, and nothing else.
///
/// Added 2026-08-28 to stop `QuoteProcess` handing out the `Proposal` ENTITY.
/// That leak was invisible until the Experience boundary refused to name the
/// type, and it is the one coupling this architecture exists to prevent: while
/// an entity is the contract, a column rename is a breaking change for every
/// consumer, and "the customer page shows the quote" quietly means "the customer
/// page shows the table".
///
/// Deliberately NOT a mirror of the entity. `LineItems` stays a raw JSON string
/// because that is exactly what the renderer parses today; widening it into a
/// typed list here would be a second parsing rule to keep in step with the first.
/// </summary>
public record CustomerQuoteDto(
    string? Number,
    string? Title,
    decimal Subtotal,
    decimal DiscountAmount,
    decimal TaxRate,
    decimal TaxAmount,
    decimal Total,
    DateTime? ValidUntil,
    string? AcceptedBy,
    DateTime? AcceptedAt,
    string? LineItems);

/// <summary>GET /quotes/{id}/views (E6.3) — counted views only. Same
/// permission as reading the quote (QuoteProcess.ViewsAsync), never the public
/// accept flow above.</summary>
public record QuoteViewSummaryDto(int ViewCount, DateTime? FirstViewedAt, DateTime? LastViewedAt);

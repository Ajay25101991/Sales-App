
// The CustomFields contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Custom fields ---
// E3.1/E3.2 fields are trailing optional params (never break a positional
// caller): ObjectType defaults to "lead" so an older client that never sends
// it keeps behaving exactly as before; the flag fields default to their
// "off"/least-surprising value.
public record CustomFieldDefDto(
    Guid Id, string Key, string Label, string Type, List<string> Options, int SortOrder,
    DateTime CreatedAt, bool Required, DateTime? ArchivedAt = null,
    string ObjectType = "lead", string? Description = null, bool Sensitive = false,
    bool Searchable = false, bool Reportable = false, bool AiVisible = false,
    bool AuditChanges = true, List<string>? VisibleToRoles = null,
    // E3.6 — set only when Type == "picklist": which OrgPicklist.Key this
    // field's values come from.
    string? PicklistKey = null,
    // Form builder rework: set only on the create response, the lead forms the new field was added to as a
    // draft change (CustomFieldInput.FormIds). Null everywhere else.
    List<Guid>? AddedToFormIds = null,
    // E12.1 - sensitive-data category tag (contact_details, deal_values, id_bank, company_financials, identity_checks,
    // deal_insights) or null = untagged. See to-do/sensitive-data-api.md section 2.
    string? Category = null);
// Key is settable on update: renaming it migrates every lead's stored value
// (see CustomFieldsController.Update), so the label and the storage key can be
// changed independently rather than the key being frozen at creation.
// ObjectType is set on CREATE only — CustomFieldProcess.UpdateAsync ignores it
// on an edit, the same way an entity's own object-type is never something an
// edit can change.
public record CustomFieldInput(
    string? Label, string? Type, List<string>? Options, int? SortOrder, bool? Required, string? Key = null,
    string? ObjectType = null, string? Description = null, bool? Sensitive = null,
    bool? Searchable = null, bool? Reportable = null, bool? AiVisible = null,
    bool? AuditChanges = null, List<string>? VisibleToRoles = null, string? PicklistKey = null,
    // Form builder rework (owner decision 2): CREATE only, lead fields only. The lead forms the new field is
    // added to, as a DRAFT change on each (it goes live when that form is published). Forms not listed are
    // untouched. For a lead field, `Required` is no longer stored on the definition (decision 3): it is the
    // initial Required of the field on those forms.
    List<Guid>? FormIds = null,
    // E12.1 - a category key to tag the field with; "" clears the tag; null leaves it as is.
    string? Category = null);
public record CustomFieldReorderInput(List<Guid>? Ids);

// --- Lead form designer ---
// LeadFormDraftDto lives in SalesApi.SystemApi/Dtos/SystemBoundContracts.cs —
// it names Services.LeadFormSchemaModel, which this project cannot see.
// IsPublished = this row is the LIVE version now. IsDraft = it is the form's one working draft (the newest row,
// unpublished). PublishedAt/By are set on a row that is or was ever live (rows superseded before 2026-10-16
// carry none and read as plain history). UpdatedAt/By = last time a draft was saved over this row.
public record LeadFormVersionDto(
    int Version, bool IsPublished, DateTime CreatedAt, string? CreatedBy,
    bool IsDraft = false, DateTime? PublishedAt = null, string? PublishedBy = null,
    DateTime? UpdatedAt = null, string? UpdatedBy = null);

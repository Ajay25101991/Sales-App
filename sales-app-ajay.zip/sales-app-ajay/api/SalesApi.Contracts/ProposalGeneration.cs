using System.Text.Json;

// E10.5 - E10.7 - the proposal generator's contracts: the generate request, the structured snapshot every generated version
// freezes, the version list with its upgrade notice, and the "what changed" diff. Wire contract:
// to-do/proposal-generator-api.md ("E10.5 - E10.7" section). The namespace stays `SalesApi.Dtos` like every other contract file.

namespace SalesApi.Dtos;

// ---- request --------------------------------------------------------------------------------------------------------

/// <summary>
/// One service of the proposal being generated. Inputs are the values for the service's pricing model, keyed by input key
/// (a number, a numeric string, true/false for an add-on; null = blank for an optional input). Absent entirely = the same
/// inputs the superseded version used (or the model's defaults on a first version); keys sent here are laid over those.
/// </summary>
public record GenerateServiceInput(Guid CatalogItemId, Dictionary<string, JsonElement>? Inputs = null);

/// <summary>
/// POST /leads/{id}/proposals/generate. Services is the full list the proposal covers (the screen starts from the deal's
/// services and lets the rep add more). SupersedesId makes this a new version of an existing quote. Upgrade (default false)
/// moves every service and the wrapper to the newest published pricing model and template; without it a new version keeps
/// the versions the previous one started with.
/// </summary>
public record GenerateProposalVersionInput(
    List<GenerateServiceInput>? Services, Guid? SupersedesId = null, bool? Upgrade = null,
    // A negotiated discount on the version, in the org currency, under the same rules as a plain quote document (the org's
    // over-discount policy). Absent = the superseded version's discount (a new version starts as a copy), else none. Send 0 to clear.
    decimal? DiscountAmount = null);

// ---- the snapshot (Proposal.GenerationSnapshot) -----------------------------------------------------------------------

/// <summary>
/// An input as it was entered. Value is null for a blank optional input; an add-on (Type "yes_no") is 1 or 0.
/// A "choice" input freezes WHAT WAS PICKED in Picks (key, label, the price it had, yearly figure, wording) so the proposal keeps its
/// maths and a document can print it later; Value is the number the formulas read (single: the pick's price; multiple: the sum; null
/// when an optional single choice was left empty). A "number_list" freezes its Rows; Value is their sum (null when blank). Both extra
/// fields are null for every other type and for snapshots made before they existed.
/// </summary>
public record SnapshotInputDto(string Key, string Label, string Type, decimal? Value, List<SnapshotPickDto>? Picks = null, List<decimal>? Rows = null);

/// <summary>One picked option of a choice input, with the figures it had in the run (Value after the input's default price was applied).</summary>
public record SnapshotPickDto(string Key, string Label, decimal Value, decimal Recurring = 0m, string? Text = null, decimal Percent = 0m);

/// <summary>A result of the service's pricing model as computed. Format is "money" or "number".</summary>
public record SnapshotResultDto(string Key, string Label, string Format, decimal Value);

/// <summary>
/// One service of a generated version. PricingModelVersion and DeckVersion are the versions this version is pinned to.
/// DealValue is the model's marked deal-value result; Year1 / Year2 are the marked year results (null when the model marks none).
/// </summary>
public record SnapshotServiceDto(
    Guid CatalogItemId, string Key, string Name, int PricingModelVersion, int? DeckVersion,
    List<SnapshotInputDto> Inputs, List<SnapshotResultDto> Results, decimal DealValue, decimal? Year1, decimal? Year2);

/// <summary>Deal value = the sum of each service's deal value; Year 1 / Year 2 sum the services that have one (null when none does).</summary>
/// <remarks>
/// DealValue is AFTER discount and BEFORE VAT (owner 2026-10-15); it is what the deal's estimate takes. Gross is the plain sum of
/// the services' deal values, Discount the printed discount, Vat at TaxRate (percent) on DealValue, Total = DealValue + Vat.
/// Year1 / Year2 are plain sums of the marked results (the discount is not spread over them).
/// </remarks>
public record SnapshotTotalsDto(
    decimal DealValue, decimal? Year1, decimal? Year2,
    decimal Gross = 0m, decimal Discount = 0m, decimal TaxRate = 0m, decimal Vat = 0m, decimal Total = 0m);

/// <summary>Everything a generated version froze. Schema is 1.</summary>
public record ProposalSnapshotDto(
    int Schema, string Currency, int? WrapperVersion, List<SnapshotServiceDto> Services, SnapshotTotalsDto Totals);

// ---- versions -------------------------------------------------------------------------------------------------------

/// <summary>
/// A pricing model, deck or wrapper version: Kind is "pricing_model", "deck" or "wrapper" (a service's deck, or the org wrapper
/// deck, whose CatalogItemId is null). In the upgrade notice From is the pinned version and To the newest published; in a diff
/// they are the two versions compared (null on one side = not present there).
/// </summary>
public record ProposalVersionChangeDto(string Kind, Guid? CatalogItemId, string? ServiceName, int? From, int? To);

/// <summary>Newer published templates or pricing models than the ones a version is pinned to. Available is Items.Count &gt; 0.</summary>
public record ProposalUpgradesDto(bool Available, List<ProposalVersionChangeDto> Items);

/// <summary>
/// One entry of a quote's version list. Generated is false for a quote the generator did not make (it then has no snapshot,
/// figures, files or PDF state). Files are the PowerPoint and PDF saved for this version (WebUrl is where each opens in SharePoint, null for a file
/// in the CRM's own storage). Upgrades is null for a version that is not the newest of its chain.
/// </summary>
public record ProposalVersionDto(
    Guid Id, Guid? SupersedesId, string? Number, int Revision, string Status, bool Generated,
    Guid AuthorId, string? AuthorName, DateTime CreatedAt, DateTime? SentAt, DateTime? AcceptedAt,
    string? ChangeSummary, decimal? Total, decimal? DealValue, decimal? Year1, decimal? Year2,
    string? PdfState, List<RenderedFileDto> Files, ProposalUpgradesDto? Upgrades);

/// <summary>The generate response: the stored quote, its version entry, and anything the renderer could not fill or finish.</summary>
public record ProposalGeneratedDto(
    ProposalDto Proposal, ProposalVersionDto Version, List<string> LeftVisible, string? PdfError);

// ---- what changed ---------------------------------------------------------------------------------------------------

/// <summary>A service added to, or removed from, the proposal.</summary>
public record DiffServiceDto(Guid CatalogItemId, string Name, decimal? DealValue);

/// <summary>
/// An input (or an add-on, Type "yes_no", From/To 0 or 1) that changed on a service present in both versions. For a "choice" or
/// "number_list" input FromText / ToText say what it was and is in words (the picked labels, or the rows, comma-separated; "none" when
/// empty); From / To stay the number the formulas read (and, for a choice, are withheld like money). Null for every other type.
/// </summary>
public record DiffInputDto(
    Guid CatalogItemId, string ServiceName, string Key, string Label, string Type, decimal? From, decimal? To,
    string? FromText = null, string? ToText = null);

/// <summary>A calculated result that changed on a service present in both versions.</summary>
public record DiffResultDto(Guid CatalogItemId, string ServiceName, string Key, string Label, string Format, decimal? From, decimal? To);

/// <summary>A total that changed: Name is "deal_value", "year1" or "year2".</summary>
public record DiffFigureDto(string Name, decimal? From, decimal? To);

/// <summary>
/// GET /leads/{id}/proposals/{pid}/diff?against=. Compares version ProposalId (the newer, "to") with AgainstId (the older,
/// "from"; default the version it supersedes). Changed is false when nothing differs. Summary is the one-line version.
/// </summary>
public record ProposalDiffDto(
    Guid ProposalId, string? Number, Guid AgainstId, string? AgainstNumber, bool Changed, string Summary,
    List<DiffServiceDto> ServicesAdded, List<DiffServiceDto> ServicesRemoved,
    List<DiffInputDto> InputChanges, List<DiffInputDto> AddOnChanges, List<DiffResultDto> ResultChanges,
    List<ProposalVersionChangeDto> VersionChanges, List<DiffFigureDto> Totals);

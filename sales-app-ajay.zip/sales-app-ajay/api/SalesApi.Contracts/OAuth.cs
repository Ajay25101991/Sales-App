// The OAuth contracts (MCP phase 2, to-do/mcp-server-design.md): the CRM as a small authorization server so a person connects Claude / ChatGPT /
// Cursor by signing in with their OWN account. JSON is snake_case on the wire (the host's naming policy), which is also what RFC 7591 / 8414 /
// 9728 / 6749 name their members, so these records need no per-property attributes.

namespace SalesApi.Dtos;

/// <summary>RFC 9728 protected resource metadata for /mcp.</summary>
public record OAuthProtectedResourceMetadata(
    string Resource, string[] AuthorizationServers, string[] BearerMethodsSupported, string[] ScopesSupported, string ResourceName);

/// <summary>RFC 8414 authorization server metadata. Public clients only (PKCE, no client secret).</summary>
public record OAuthServerMetadata(
    string Issuer, string AuthorizationEndpoint, string TokenEndpoint, string RegistrationEndpoint,
    string[] ResponseTypesSupported, string[] GrantTypesSupported, string[] CodeChallengeMethodsSupported,
    string[] TokenEndpointAuthMethodsSupported, string[] ScopesSupported);

/// <summary>RFC 7591 registration request. Everything but the two named members is ignored.</summary>
public record OAuthRegisterRequest(string? ClientName, string[]? RedirectUris);

public record OAuthRegisterResponse(
    string ClientId, string ClientName, string[] RedirectUris, string[] GrantTypes, string[] ResponseTypes, string TokenEndpointAuthMethod,
    long ClientIdIssuedAt);

/// <summary>The query of GET /oauth/authorize, already read off the request.</summary>
public record OAuthAuthorizeQuery(
    string? ClientId, string? RedirectUri, string? ResponseType, string? CodeChallenge, string? CodeChallengeMethod, string? State, string? Resource);

/// <summary>Either a consent request id (go to the consent page), or an RFC 6749 error. <see cref="RedirectUrl"/> is set when the error must go back to
/// the client's redirect_uri; otherwise the host answers a plain 400.</summary>
public record OAuthAuthorizeOutcome(string? ConsentRequestId, string? RedirectUrl, string? Error, string? ErrorDescription);

/// <summary>What the consent page shows: who is asking, and whether this person may connect at all (the same gate /mcp runs).</summary>
public record OAuthConsentRequest(string ClientName, string RedirectHost, bool CanConnect, string? Reason);

public record OAuthRedirect(string RedirectUrl);

/// <summary>The token endpoint's success body (RFC 6749 5.1).</summary>
public record OAuthTokenResponse(string AccessToken, string TokenType, int ExpiresIn, string RefreshToken, string Scope);

public record OAuthTokenError(string Error, string ErrorDescription);

/// <summary>One connected AI tool: a refresh family issued to an OAuth client. <see cref="UserId"/>/<see cref="UserName"/> are set only on the admin view.</summary>
public record AiConnectionDto(Guid Id, string ClientName, DateTime ConnectedAt, DateTime? LastUsedAt, Guid? UserId = null, string? UserName = null);

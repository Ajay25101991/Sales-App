namespace SalesApi.Dtos;

// Channel partners Phase 4 - client usage (to-do/partner-management-design.md 9.3.4; owner decisions 4.4 / 4.5 / 4.6, 2026-10-19).
//
// What a client actually consumed (invoices issued and received, API calls) per month, imported by staff from a CSV (preview, then commit) or pushed by the platform itself with a
// scoped API key (usage:write). Shown as COUNTS against the contract's allowance and an ESTIMATED charge: the deal's FROZEN pricing (the quote's pinned model version and inputs)
// re-evaluated on the engine with the actual counts substituted - no new formula. The CRM never creates an invoice from it.

public static class UsageVocab
{
    public static class Metric
    {
        public const string InvoicesIssued = "invoices_issued";
        public const string InvoicesReceived = "invoices_received";
        public const string ApiCalls = "api_calls";
        public static readonly string[] All = [InvoicesIssued, InvoicesReceived, ApiCalls];
        public static bool IsValid(string? v) => v is not null && Array.IndexOf(All, v) >= 0;
    }

    public static class BatchStatus
    {
        public const string Preview = "preview";
        public const string Committed = "committed";
        public const string Rejected = "rejected";
    }

    public static class Source
    {
        public const string Csv = "csv";
        public const string Api = "api";
    }

    /// <summary>
    /// The pricing-model keys the estimate reads and substitutes (the e-invoicing model of the pricing proposal, section 9). A model with none of the INPUT keys has no usage to
    /// substitute and answers "not estimable"; a result key a model does not define is simply not listed. They are DATA about the model, not a formula: the arithmetic stays in the model.
    /// </summary>
    public static class ModelKeys
    {
        public const string Entities = "entities";
        public const string AllowanceMode = "allowance_mode";       // choice: 0 = pooled, 1 = per entity
        public const string VolumePool = "volume_pool";             // number: expected invoices per year, all entities
        public const string VolumeEach = "volume_each";             // number_list: expected invoices per year, one row per entity
        public const string ApiCalls = "api_calls";                 // number
        public const string InvoicesIncluded = "invoices_included"; // number: allowance per entity per year
        public const string ApiAllowance = "api_allowance";         // number: allowance per entity per year
        public static readonly string[] ResultKeys = ["extra_invoices_fee", "api_fee_estimate", "usage_estimate", "spend_top_up_estimate"];
    }

    public const int MaxRows = 20_000;
    public const int MaxErrorsListed = 200;
}

/// <summary>POST usage/imports: the CSV text (header: client, entity, period, metric, count, partner, deal) and the file's name for the batch record.</summary>
public record UsageCsvInput(string? Csv, string? FileName);

/// <summary>One count. <c>Client</c> is an account id or its exact name; <c>Period</c> is YYYY-MM; <c>Metric</c> one of invoices_issued | invoices_received | api_calls; <c>Entity</c>, <c>Partner</c> (an account id or name) and <c>Deal</c> (a deal id) are optional.</summary>
public record UsageRowInput(string? Client, string? Entity, string? Period, string? Metric, long? Count, string? Partner = null, string? Deal = null);

/// <summary>POST partner/v1/usage (scope usage:write): all-or-nothing - one bad row refuses the whole push and nothing is written.</summary>
public record UsagePushInput(List<UsageRowInput>? Rows);

public record UsageRowErrorDto(int Row, string Reason);

/// <summary>A validated row as the preview shows it (names, not ids).</summary>
public record UsageRowDto(int Row, Guid ClientAccountId, string ClientName, string Entity, DateOnly Month, string Metric, long Count, Guid? PartnerAccountId, string? PartnerName, Guid? DealId);

/// <summary>
/// An import, as the screen needs it. <c>Replaces</c> = how many numbers already stored for the same client / entity / month / metric this batch will SUPERSEDE on commit (they are kept
/// for the audit trail, in no total). <c>Sample</c> is the first rows of a preview.
/// </summary>
public record UsageBatchDto(
    Guid Id, string Source, string Status, string? FileName, int RowCount, int ValidCount, int ErrorCount, List<UsageRowErrorDto> Errors,
    DateOnly? PeriodFrom, DateOnly? PeriodTo, int Replaces, List<UsageRowDto> Sample,
    DateTime CreatedAt, Guid? UploadedById, string? UploadedByName, DateTime? CommittedAt, DateTime? RejectedAt);

/// <summary>One client-month from the stored aggregate (UsageStats).</summary>
public record UsageMonthDto(DateOnly Month, long InvoicesIssued, long InvoicesReceived, long ApiCalls);

public record UsageAccountDto(Guid AccountId, string AccountName, List<UsageMonthDto> Months, long InvoicesIssued, long InvoicesReceived, long ApiCalls);

/// <summary>One result of the frozen model re-run on the actual counts (the key is the model's own).</summary>
public record UsageEstimateResultDto(string Key, string Label, string Format, decimal Value);

/// <summary>
/// A deal's usage in one contract year against what the frozen quote allows, per priced service. <c>Estimable</c> false says why in <c>Reason</c> (no frozen quote, the model has
/// no usage inputs, per-entity counts that do not line up with the entities). <c>Results</c> is null below a raw read of Deal values - the estimate is a price.
/// </summary>
public record UsageServiceDto(
    Guid CatalogItemId, string ServiceName, int PricingModelVersion, bool Estimable, string? Reason,
    long? InvoicesAllowance, long InvoicesUsed, long? ApiAllowance, long ApiUsed, string? AllowanceMode, int? Entities,
    List<UsageEstimateResultDto>? Results);

public record UsageDealDto(
    Guid LeadId, Guid? AccountId, string? AccountName, int ContractYear, DateOnly WindowStart, DateOnly WindowEnd, bool WonDeal,
    Guid? QuoteId, string? QuoteNumber, string? Currency, List<UsageMonthDto> Months, List<UsageEntityDto> Entities, List<UsageServiceDto> Services, bool EstimateHidden);

/// <summary>Per-entity totals in the window (a blank entity is the client as a whole).</summary>
public record UsageEntityDto(string Entity, long InvoicesIssued, long InvoicesReceived, long ApiCalls);

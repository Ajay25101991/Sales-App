namespace SalesApi.Dtos;

// The Tasks contracts (E2.1, to-do/epics-ai-native-crm.md). Split into its own
// file per the API-led migration's one-file-per-domain convention (see the
// header on Reminders.cs).

/// <summary>One checklist row on the wire — mirrors <see cref="Models.TaskChecklistItem"/>
/// (System cannot be named from Contracts, so this is a plain duplicate of that
/// shape, not a reference to it).</summary>
public record TaskChecklistItemDto(string Text, bool Done);

public record TaskDto(
    Guid Id,
    string Title,
    string? Description,
    /// <summary>Null while the task sits in a role's shared queue (E13 handover): see <paramref name="AssigneeRoleKey"/>.</summary>
    Guid? AssigneeId,
    string? AssigneeName,
    DateTime? DueAt,
    string Priority,
    string Status,
    string? LinkedRecordType,
    Guid? LinkedRecordId,
    string? LinkedRecordName,
    Guid? TeamId,
    string? TeamName,
    string Source,
    Guid? SourceRef,
    List<TaskChecklistItemDto> Checklist,
    DateTime? SnoozedUntil,
    DateTime? CompletedAt,
    Guid? CompletedById,
    string? CompletedByName,
    Guid CreatedById,
    DateTime CreatedAt,
    DateTime UpdatedAt,
    bool Overdue,
    /// <summary>E13 - set only on a task created from a workflow stage's handover list: the stage and the item's stable key, so the
    /// deal page can show the handover checklist (a task of the deal whose HandoverKey is set). Null on every other task.</summary>
    string? HandoverStage = null,
    string? HandoverKey = null,
    /// <summary>E13 - set (and AssigneeId null) while the task is an unclaimed role-queue task: holders of this role see it under
    /// "For my role" and the first to POST /tasks/{id}/claim takes it. Null on every ordinary task.</summary>
    string? AssigneeRoleKey = null,
    string? AssigneeRoleLabel = null);

public record TaskInput(
    string? Title,
    string? Description,
    Guid? AssigneeId,
    DateTime? DueAt,
    string? Priority,
    string? LinkedRecordType,
    Guid? LinkedRecordId,
    Guid? TeamId,
    List<TaskChecklistItemDto>? Checklist,
    /// <summary>Owner 2026-11-16: POST /tasks only - send the task to this ROLE's shared queue (no named assignee; any holder claims it). Anyone who may create a task may do this. Mutually exclusive with assignee_id.</summary>
    string? AssigneeRoleKey = null,
    /// <summary>POST /tasks only - files already on the task's deal or account to link to the new task (task files design). Needs a linked record.</summary>
    List<Guid>? AttachmentIds = null);

/// <summary>POST /tasks/{id}/files/links - files of the task's record to link to it.</summary>
public record TaskFileLinksInput(List<Guid>? AttachmentIds);

public record TaskSnoozeInput(DateTime? Until, int? QuickDays);

public record TaskBulkCompleteInput(List<Guid>? Ids);
public record TaskBulkReassignInput(List<Guid>? Ids, Guid? AssigneeId);

/// <summary>One item this bulk action could not carry out, and why — so a
/// partial success (E2.0 decision 2: cross-team reassignment refused item by
/// item) reads as "12 reassigned, 2 refused: X" rather than an opaque 400.</summary>
public record TaskBulkFailureDto(Guid Id, string Reason);
public record TaskBulkResultDto(List<Guid> Succeeded, List<TaskBulkFailureDto> Failed);

/// <summary>Org-configurable quick-snooze durations (E2.0 decision 5), in whole
/// days. Default [1, 3, 7] ("1 day", "3 days", "1 week").</summary>
public record TaskSnoozeOptionsDto(List<int> QuickDays);
public record TaskSnoozeOptionsInput(List<int>? QuickDays);

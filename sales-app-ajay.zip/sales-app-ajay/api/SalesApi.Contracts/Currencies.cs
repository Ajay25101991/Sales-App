// The ISO-4217 currencies an organization may be denominated in.
//
// WHY IT MOVED HERE. It was `internal static readonly` on
// `OrganizationsController`, and `AdminController.CreateOrganization` reached
// across to read it. When organizations migrated, the list was deliberately left
// in the controller with a comment explaining that it could not move: Admin was
// outside that batch and Process cannot reference the host project, so moving it
// would either break Admin or fork the list in two.
//
// Migrating Admin is what expires that reason. The list is a pure value — no EF,
// no HTTP, just membership — so it lands in Contracts, where BOTH controllers and
// any layer beneath them can read the one copy. This is the same shape as
// `QuoteLineItems`: a cross-controller static that the layering made impossible
// to keep hiding, fixed by putting it where it always belonged rather than by
// duplicating it with a note asking humans to keep two lists in sync.
//
// Keep in sync with the client picker.

namespace SalesApi.Services;

public static class OrgCurrencies
{
    public static readonly HashSet<string> Supported = new()
    {
        "USD", "AED", "SAR", "QAR", "KWD", "BHD", "OMR", "EUR", "GBP",
        "INR", "PKR", "AUD", "CAD", "SGD", "JPY", "CNY", "ZAR", "NGN", "KES",
    };
}

namespace SalesApi.Dtos;

// E15.3 KYC checklist: which documents an account must hold (org-configured rules), and which of them the register has. JSON is snake_case.

/// <summary>Who holds a required document: the account itself, or a contact on the billed entity (the account, or its parent when the org bills children through the parent).</summary>
public static class KycHolders
{
    public const string Account = "account";
    public const string OwnerContact = "owner_contact";
    public static readonly IReadOnlyList<string> All = [Account, OwnerContact];
}

/// <summary>One condition of a rule: the account field (a built-in column - industry, status, country, country_code, city, state, postal_code - or
/// <c>custom.&lt;key&gt;</c> of an account custom field) must equal ONE of <c>Values</c> (case-insensitive). A rule's conditions all have to hold.</summary>
public record KycConditionDto(string Field, List<string> Values);

/// <summary>A document type (a "document_types" picklist key) the rule asks for. <c>Mandatory</c> false = asked for but not required.</summary>
public record KycRequirementDto(string DocumentType, bool Mandatory = true, string Holder = KycHolders.Account);

/// <summary>A rule: when every condition holds for an account, its requirements apply. No conditions = every account.</summary>
public record KycRuleDto(string? Name, List<KycConditionDto> Conditions, List<KycRequirementDto> Requirements);

/// <summary>GET/PUT /settings/kyc-checklist. <c>ChildrenBilledThroughParent</c>: an account with a parent is billed through it, so a requirement held
/// by an <c>owner_contact</c> is looked for on the parent. Off (and no rules) by default: the feature does nothing until an org configures it.
/// <c>CompanyDocumentTypes</c> (owner 2026-11-16): the "document_types" keys that carry no ID or bank data; every OTHER type is locked for roles whose ID &amp; bank level cannot read raw
/// (<see cref="IdBankDocuments"/>). Always a list on the wire (the four built-ins until an admin saves their own; an empty list locks every type).
/// On PUT an omitted field is left alone.</summary>
public record KycChecklistSettingsDto(List<KycRuleDto> Rules, bool ChildrenBilledThroughParent, List<string>? CompanyDocumentTypes = null);
public record KycChecklistSettingsInput(List<KycRuleDto>? Rules = null, bool? ChildrenBilledThroughParent = null, List<string>? CompanyDocumentTypes = null);

/// <summary>One required document and where it stands. State: <c>present</c> (a current register row that has not expired - pending or verified),
/// <c>expired</c> (a current row whose expiry date has passed; counts as missing) or <c>missing</c> (no current row).</summary>
public record KycChecklistItemDto(
    string DocumentType, string Label, bool Mandatory, string Holder, string State,
    Guid? EntryId, DateOnly? ExpiryDate, string? RegisterStatus, Guid? HeldOnAccountId, Guid? ContactId, string? ContactName);

/// <summary>An account's checklist. <c>Complete</c> = no MANDATORY item is missing or expired. <c>BilledAccountId</c> is the entity owner-contact
/// documents are looked for on.</summary>
public record KycChecklistDto(
    Guid AccountId, Guid BilledAccountId, bool Complete, int MissingCount, int MissingMandatoryCount, List<KycChecklistItemDto> Items);

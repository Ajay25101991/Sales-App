// E3.4 — account relationships (parent/subsidiary, related companies, external
// ids) and the account-360 rollup they feed. Split from Accounts.cs for the
// same reason that file itself was split out of Dtos.cs (see its own header):
// one file per sub-feature keeps a growing domain from becoming a merge
// conflict every agent hits at once.

namespace SalesApi.Dtos;

// --- Related companies (partner_of / distributor_for / competitor_of, org-configurable) ---

/// <summary>
/// One relationship edge as seen FROM either side. <see cref="Direction"/> is
/// "outgoing" when the account this DTO is attached to is the FROM side of
/// the underlying edge ("Acme is a distributor_for Globex"), "incoming" when
/// it is the TO side ("Globex has Acme as a distributor_for") — the same
/// directed edge read from the other account's page. The client renders both
/// the same way a stakeholder or tag list reads either direction of a graph.
/// </summary>
public record AccountRelationshipDto(
    Guid Id, string Direction, Guid CounterpartyAccountId, string CounterpartyAccountName,
    string Type, DateTime CreatedAt);

public record AccountRelationshipInput(Guid? ToAccountId, string? Type);

public record AccountRelationshipTypesInput(List<string>? Types);

// --- External ids (ERP/Zoho matching) ---

public record AccountExternalIdDto(Guid Id, string System, string Value, DateTime CreatedAt);

public record AccountExternalIdInput(string? System, string? Value);

// --- Parent/subsidiary tree ---

public record AccountParentInput(Guid? ParentAccountId);

/// <summary>
/// GET /accounts/{id}/tree — this account's own subtree, bounded to
/// <c>AccountProcess.MaxHierarchyDepth</c> levels down. <see cref="Truncated"/>
/// is true on a node whose real children exist beyond the bound (so the
/// client can say "N more levels not shown" instead of silently looking like
/// a leaf). Hidden descendants (RecordAccess.CanView false) are OMITTED —
/// never shown as a placeholder — same as AccountDto.OpenValue's own rollup
/// never counting a lead the caller cannot see.
/// </summary>
public record AccountChildNodeDto(
    Guid Id, string Name, List<AccountChildNodeDto> Children, bool Truncated = false);

/// <summary>The lite summary AccountDetailDto carries for its DIRECT children
/// only — the full recursive tree is its own endpoint (GET /accounts/{id}/tree)
/// so a plain account-detail read never pays for walking the whole hierarchy.</summary>
/// Status and the account's OWN tags ride along so a list of children needs no per-child detail read.
public record AccountChildSummaryDto(Guid Id, string Name, int DirectChildCount, string Status = "", List<TagRefDto>? Tags = null);

// --- Rollups (parent + every descendant the caller can see) ---

/// <summary>
/// Computed over this account and every DESCENDANT the caller may view
/// (RecordAccess.CanView) — a hidden subsidiary's pipeline never leaks
/// through its visible parent's rollup, the same "hidden means omitted, not
/// zeroed or summed anyway" rule AccountProcess.ToDto's own single-account
/// figures already follow for invoice visibility (WhereViewable).
///
/// Money fields ARE masked to null for missing ViewLeadValues/
/// ViewAccountFinancials, as of account-money-masking (owner decision
/// 2026-09-27) — this doc previously said otherwise (AccountDto's OpenValue/
/// WonValue/Outstanding/Overdue were unmasked at the time), which was the bug:
/// only WHICH invoices/leads counted was scoped (WhereViewable/
/// canSeeFullFinancials), never the number itself, so a rollup could show a
/// caller a figure the single-account/lead views already hid from them. This
/// generalises AccountDto's now-corrected masking rule (see its own doc):
/// OpenPipelineValue follows ViewLeadValues, WonValue/InvoiceOutstanding
/// follow ViewAccountFinancials. OpenDealsCount/DescendantAccountCount are
/// COUNTS, not values, and stay unmasked.
///
/// WonValue carries no period: AccountDto.WonValue (the single-account figure
/// this rollup generalises) has none either — all-time gross non-void,
/// non-draft invoice amount. Do not read a month/quarter into it without an
/// owner decision; none exists today.
/// </summary>
public record AccountRollupDto(
    int OpenDealsCount, decimal? OpenPipelineValue, decimal? WonValue, decimal? InvoiceOutstanding,
    int DescendantAccountCount);

// The E4.8 action-risk-policy contracts. Own file, same reason as
// MessageTemplates.cs's own header: the Experience layer cannot see the
// System layer, so a contract it must return has to live in this
// reference-free project.

namespace SalesApi.Dtos;

// --- AI action risk policy ---
public record AiActionPolicyDto(string ActionType, string Autonomy, DateTime UpdatedAt, Guid? UpdatedById);
public record AiActionPolicyInput(string? Autonomy);

using System.Text.Json;

namespace SalesApi.Dtos;

// The playbooks vertical's wire shapes. Field names are unchanged from the
// anonymous objects PlaybooksController used to build by hand — this is a
// straight extraction, not a redesign, so every existing test and client
// still sees the same JSON (PropertyNamingPolicy.SnakeCaseLower does the
// PascalCase -> snake_case conversion, same as every other Dtos file).

/// <summary>A library row — everything <c>List</c> renders, and no more (the
/// stage list is deliberately NOT here; see <see cref="PlaybookDetailDto"/>).</summary>
public record PlaybookSummaryDto(
    Guid Id,
    string Name,
    string? Description,
    int? LiveVersion,
    int? DraftVersion,
    int GateCount,
    DateTime? PublishedAt,
    int Priority,
    JsonElement? MatchCondition,
    bool OutOfSync,
    string? OutOfSyncReason,
    /// <summary>
    /// E0.3 — null unless this LIVE playbook can provably never receive a
    /// lead under the current org configuration (an earlier, unconditional
    /// playbook always wins first — see
    /// <c>PlaybookProcess.UnreachableReason</c>). Absent/null for a draft-only
    /// playbook: unreachability is only meaningful once something is live to
    /// evaluate.
    /// </summary>
    string? UnreachableReason = null,
    // E-batch (2026-09-26) — set only when this playbook is archived. A plain
    // List call never returns an archived row at all; this is populated only
    // when the caller asks for them too (List's includeArchived=true, the
    // Workflows screen's "show archived" filter).
    DateTime? ArchivedAt = null,
    /// <summary>E7.1 stable identity (design doc §10 owner answer 5).</summary>
    string Key = "");

/// <summary>One playbook WITH its editable stage list — what the builder loads.</summary>
public record PlaybookDetailDto(
    Guid Id,
    string Name,
    string? Description,
    int? LiveVersion,
    int? DraftVersion,
    int GateCount,
    DateTime? PublishedAt,
    List<StageDefDto> Stages,
    int Priority,
    JsonElement? MatchCondition,
    bool OutOfSync,
    string? OutOfSyncReason,
    /// <summary>See <see cref="PlaybookSummaryDto.UnreachableReason"/>.</summary>
    string? UnreachableReason = null,
    /// <summary>E13 - the editing version's (draft, else live) after-the-win overrides; null = every field uses the org setting.</summary>
    PlaybookPostWinDto? PostWin = null,
    /// <summary>Owner 2026-11-12 - the editing version's stage-value fields (custom field keys); null = never configured (legacy: stages keyed proposal / negotiating act as the role stages).</summary>
    List<string>? StageValueFields = null);

/// <summary>The picker's row (D10a) — id/name only, nothing a picker doesn't need.</summary>
public record PlaybookLiteDto(Guid Id, string Name);

/// <summary>Result of PUT .../matching.</summary>
public record PlaybookMatchingResultDto(int Priority, JsonElement? MatchCondition);

/// <summary>Result of PUT .../draft.</summary>
public record PlaybookDraftResultDto(int Version, string Status);

/// <summary>Result of POST .../publish.</summary>
public record PlaybookPublishResultDto(int Version, string Status, DateTime? PublishedAt);

/// <summary>The whole assignment set for a playbook (GET/PUT .../assignments).</summary>
public record PlaybookAssignmentsDto(List<Guid> TeamIds);

/// <summary>One lead matching genuinely ran on and found nothing for.</summary>
public record UnmatchedLeadDto(
    Guid Id, string Name, string? Company, string? Source, string? OwnerName, DateTime CreatedAt);

public record UnmatchedLeadsResultDto(int Total, List<UnmatchedLeadDto> Leads);

/// <summary>One stage that publishing would remove, and what sits on it.
///
/// MOVED HERE from SalesApi.SystemApi/Services/PlaybookService.cs (2026-08-28,
/// the playbooks vertical migration) — it is a plain value (no EF, no HTTP), so
/// it belongs in Contracts on the same reasoning as `TeamScope`/`RecordAccessContext`:
/// PlaybookProcess.PublishPreviewAsync returns it, and a Process surface may not
/// name a System type (LayerBoundaryTests).</summary>
public record PlaybookStageImpact(string Key, string Label, int LeadCount, decimal LeadValue);

/// <summary>What publishing a draft would do to the leads already on this
/// playbook, plus whether it even CAN publish (Q6) — see the same move note as
/// <see cref="PlaybookStageImpact"/>.</summary>
public record PlaybookPublishPreview(List<PlaybookStageImpact> Removed, List<string> Added, string? GateError = null);

/// <summary>
/// One gate as it appeared in a version's frozen StageSnapshot — just enough
/// identity (key, label, kind) for A12's "Compare with live" to say WHICH
/// requirement was added/removed/changed on a stage, never the full
/// <see cref="StageRequirementDto"/> (its `Rule` payload is the entry-gate's
/// own business, not a fact this history view needs to expose).
/// </summary>
public record PlaybookVersionRequirementDto(string Key, string Label, string Kind);

/// <summary>
/// One stage as it appeared in a version's frozen StageSnapshot — a version-
/// history row does not need the WHOLE StageDefDto (no color/order/x/y/role
/// flags), just enough to show what the pipeline looked like and how gated
/// it was. `Requirements` rides alongside the pre-existing `RequirementCount`
/// (kept for callers that only ever wanted the number) so A12's diff can tell
/// a requirement being swapped for a different one apart from the count
/// merely staying the same by coincidence.
/// </summary>
public record PlaybookVersionStageDto(
    string Key, string Label, string Phase, int RequirementCount,
    List<PlaybookVersionRequirementDto> Requirements,
    string? ReopenPolicy = null,
    /// <summary>E13 - the stage options frozen with this version, so the history diff can show them.</summary>
    bool? AskProposalOnEntry = null,
    List<HandoverItemDto>? Handover = null,
    /// <summary>E-invoicing IRL - the stage option frozen with this version (mirrors <see cref="AskProposalOnEntry"/>).</summary>
    bool? AskIrlOnEntry = null,
    List<StageTaskDto>? TasksOnEnter = null,
    List<StageTaskDto>? TasksOnLeave = null,
    string? MoveOnProposalAccepted = null,
    AskOnWinDto? AskOnWin = null,
    List<StageRecommendationDto>? Recommended = null,
    /// <summary>Delivery project from a workflow stage - the stage option frozen with this version (mirrors <see cref="AskProposalOnEntry"/>).</summary>
    bool? CreateDeliveryProjectOnEntry = null);

/// <summary>
/// One row of a playbook's version history (GET .../versions). Every version
/// ever created, oldest never deleted (design doc, Playbook's own class
/// comment) — draft/live/archived per <see cref="PlaybookStatus"/>.
///
/// Priority and match condition are deliberately absent: they live on
/// <see cref="Playbook"/>, not on any version, and history must not imply
/// otherwise. <c>GateCount</c> is frozen at publish for a live/archived row
/// (design doc C5) but computed fresh from the snapshot for a draft, since a
/// draft's requirements can still change before it is ever published.
///
/// Additive (2026-09-27, follow-up story): <see cref="QualificationItems"/>
/// carries this version's frozen checklist items, from
/// <c>PlaybookVersion.QualificationSnapshot</c>, so "Compare with live" (A12)
/// can diff checklist items the same way it already diffs <see cref="Stages"/>.
/// <see cref="QualificationItemDto.Key"/> is the item's stable identity across
/// versions (same reasoning as <see cref="PlaybookVersionRequirementDto.Key"/>).
/// Phones don't call this endpoint, so this is a pure desktop concern.
/// </summary>
public record PlaybookVersionDto(
    int Version,
    string Status,
    DateTime CreatedAt,
    Guid? CreatedById,
    string? CreatedByName,
    DateTime? PublishedAt,
    Guid? PublishedById,
    string? PublishedByName,
    int GateCount,
    int StageCount,
    List<PlaybookVersionStageDto> Stages,
    List<QualificationItemDto> QualificationItems,
    /// <summary>E13 - this version's after-the-win overrides (null = none), and the override fields (by name, e.g.
    /// "payment.terms") that differ from the next-older version, so the history can say what a publish changed.</summary>
    PlaybookPostWinDto? PostWin = null,
    List<string>? PostWinChangedFields = null);

/// <summary>Result of POST .../versions/{version}/restore — the DRAFT the
/// restore produced (never the live version; see PlaybooksController).</summary>
public record PlaybookRestoreResultDto(int Version, string Status);

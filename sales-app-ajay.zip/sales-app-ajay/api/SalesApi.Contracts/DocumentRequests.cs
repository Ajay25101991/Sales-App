namespace SalesApi.Dtos;

// E15 document requests: an account-level ask for missing KYC documents, answered by the client on a secure link. JSON is snake_case.
// Staff side: POST/GET /accounts/{id}/document-requests, POST /document-requests/{id}/resend|revoke. Client side: /public/document-requests/{token}.

/// <summary>
/// POST /accounts/{id}/document-requests body. <c>DocumentTypes</c> omitted = every missing or expired item of the account's KYC checklist.
/// <c>ContactId</c> is the recipient; an <c>owner_contact</c> item is requestable only when it is given (the files for it are owned by that contact).
/// <c>To</c> overrides the contact's email (one of the two is needed). <c>Message</c> is a personal note put at the top of the standard email.
/// </summary>
public record CreateDocumentRequestInput(List<string>? DocumentTypes = null, Guid? ContactId = null, string? To = null, string? Message = null);

/// <summary>A file that came in through the request: the register entry it became and when.</summary>
public record DocumentRequestUploadDto(Guid EntryId, string? FileName, DateTime UploadedAt);

/// <summary>One document asked for. <c>Holder</c> is "account" or "owner_contact" (<see cref="KycHolders"/>).</summary>
public record DocumentRequestItemDto(string DocumentType, string Label, string Holder, List<DocumentRequestUploadDto> Uploaded);

/// <summary>
/// One request, as staff see it. <c>Status</c> is open / completed / expired / revoked (expired is worked out from the link's expiry). <c>SentTo</c> is
/// null for a caller who may not read the account's contact details. <c>NotRequestable</c> lists missing types the request could not ask for.
/// </summary>
public record DocumentRequestDto(
    Guid Id, Guid AccountId, Guid? ContactId, string? ContactName, string? SentTo, string Status,
    List<string> DocumentTypes, List<DocumentRequestItemDto> Items, List<string> NotRequestable,
    DateTime? LinkExpiresAt, DateTime? SentAt, string? SentByName, DateTime? CompletedAt, DateTime? RevokedAt);

// ---- the client's side: /public/document-requests/{token} ----------------------------------------------------------------------------

public record DocumentRequestPublicUploadDto(string FileName, DateTime UploadedAt);

public record DocumentRequestPublicItemDto(string DocumentType, string Label, List<DocumentRequestPublicUploadDto> Uploaded);

/// <summary>GET /public/document-requests/{token}: what the client's page shows. No internal ids.</summary>
public record DocumentRequestPublicViewDto(
    string Company, string? RequestedBy, DateTime? ExpiresAt, string Status, string Language, List<DocumentRequestPublicItemDto> Items);

/// <summary>POST /public/document-requests/{token}/files result (201).</summary>
public record DocumentRequestFileUploadedDto(string DocumentType, string FileName, DateTime UploadedAt);

/// <summary>POST /public/document-requests/{token}/submit result.</summary>
public record DocumentRequestSubmitResultDto(string Status);

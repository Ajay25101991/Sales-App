namespace SalesApi.Dtos;

// E19.1 - portal users, general. A PORTAL user is a Profile with a portal kind ("partner" | "customer") and a portal account; the one default-deny guard (PortalGuard) lets it reach only
// the endpoints marked for its kind. The partner portal's own DTOs are in PartnerPortal.cs; this file holds what is true of EVERY portal kind.

/// <summary>
/// The caller's portal identity, as DATA handed down from the controller (the layer rule: a Process class never reads a principal). <see cref="IncludeChildren"/> only means something for
/// the customer kind. Every portal query for a customer is filtered by <c>PortalProcess.AccountIdsAsync(scope)</c>.
/// </summary>
public sealed record PortalScope(string Kind, Guid AccountId, bool IncludeChildren, Guid UserId);

/// <summary><c>GET /portal/me</c> - the same shape for every kind. A partner's richer profile (tier, status, currency) stays at <c>GET /partner-portal/me</c>.
/// <c>PreferredLanguage</c>: the language code of the contact on the portal account whose email is the user's (null when no contact matches); the portal's i18n provider reads it.</summary>
public record PortalMeDto(string Kind, Guid AccountId, string AccountName, bool IncludeChildren, string? Name, string Email, string? PreferredLanguage = null);

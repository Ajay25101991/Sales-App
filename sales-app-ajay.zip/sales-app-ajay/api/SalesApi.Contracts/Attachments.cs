// The Attachments contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Attachments ---
// A file belongs to ONE record: (RecordType, RecordId). LeadId is the parent lead and is set for lead, quote,
// invoice and AMC files (null for an account file); it is what lead merge reparents by.
// PaymentProof marks a row that is listed on an invoice only because a payment / InvoiceAttachment link points at
// it (the file itself belongs to the lead) - the client labels it and does not offer delete there.
public record AttachmentDto(
    Guid Id, Guid? LeadId, Guid UploaderId, string Filename, string? MimeType, long SizeBytes, DateTime CreatedAt, string? Tag,
    string RecordType, Guid RecordId, bool PaymentProof = false, string? Provider = null, string? RecordLabel = null,
    string Kind = "file", string? WebUrl = null, IReadOnlyList<AttachmentGateLinkDto>? GateLinks = null,
    // Client-document reading (tag "doctype:{key}" only; null on every other file): queued | reading | read | failed | not_applicable,
    // and the plain reason when a read produced nothing.
    string? ReadState = null, string? ReadMessage = null)
{
    /// <summary>The stage file gates this file has been linked to (never null on the wire: an empty list when none).</summary>
    public IReadOnlyList<AttachmentGateLinkDto>? GateLinks { get; init; } = GateLinks ?? [];

    /// <summary>Owner 2026-11-16 (roles audit decision 5): false on an identity or bank document the caller's ID &amp; bank level does not let them open. The row is still listed (type, name, dates);
    /// the bytes and any SharePoint address are withheld and the file download answers 403. True everywhere else.</summary>
    public bool CanOpen { get; init; } = true;

    /// <summary>Task files design: set (from_task_id / from_task_title) when the file was UPLOADED from a task; the record's Files list shows "From task: title". Null on every other file.</summary>
    public Guid? FromTaskId { get; init; }
    public string? FromTaskTitle { get; init; }
}

/// <summary>
/// Owner 2026-11-16 (roles audit decision 5): OPENING the bytes of an identity or bank document (and the values read from it) needs a raw read (full or view only) of the ID &amp; bank
/// category on top of kyc.access. Listing, requesting and metadata stay on kyc.access. ONE classification, read by the file download, the three lists and the OCR values.
///
/// The company documents are named by the ORG (setting <c>company_document_types</c>; default the four built-ins below); they carry nothing personal or bankable: every OTHER client-document type is treated as identity or bank, including a type the org adds to the
/// "document_types" picklist (signatory_id, passport, emirates_id, bank_letter, iban_certificate, ...). Failing closed is deliberate: an unrecognised type is locked, never opened.
/// The keys are literals because Contracts references nothing; a unit test pins them to <c>ClientDocumentFields</c>.
/// </summary>
public static class IdBankDocuments
{
    /// <summary>The DEFAULT company-document list, used when the org has not saved its own (org setting <c>company_document_types</c>, edited with the KYC checklist settings).</summary>
    public static readonly string[] CompanyDocumentTypes = ["trade_licence", "vat_certificate", "moa_aoa", "signatory_authority"];

    public const string RefusalMessage = "Your role can't open ID or bank documents.";

    /// <summary><paramref name="companyTypes"/> is the org's company-document list (null = the built-in default).</summary>
    public static bool IsIdentityOrBank(string? documentType, IReadOnlyCollection<string>? companyTypes = null) =>
        !string.IsNullOrEmpty(documentType) && !(companyTypes ?? CompanyDocumentTypes).Contains(documentType);

    /// <summary>A "doctype:{key}" file whose type is identity or bank, or (owner 2026-11-16) a "screening:{id}" evidence file: a passport copy or bank statement is typical evidence, so it is held to the same level.</summary>
    public static bool IsIdentityOrBankFile(string? tag, IReadOnlyCollection<string>? companyTypes = null) =>
        AttachmentTags.IsScreening(tag) || (AttachmentTags.IsClientDocument(tag) && IsIdentityOrBank(AttachmentTags.ClientDocumentType(tag), companyTypes));

    /// <summary>May this caller open the FILE with this tag? The tag-based form of <see cref="MayOpen"/> that also covers screening evidence (its tag carries no document type).</summary>
    public static bool MayOpenFile(string? tag, SalesApi.Services.SensitiveAccess? sensitive, IReadOnlyCollection<string>? companyTypes = null) =>
        !IsIdentityOrBankFile(tag, companyTypes)
        || SalesApi.Services.SensitiveLevels.CanReadRaw((sensitive ?? SalesApi.Services.SensitiveAccess.Unrestricted).RoleLevel(SalesApi.Services.SensitiveCategories.IdBank));

    /// <summary>May this caller open a document of <paramref name="documentType"/>? Company documents: always (kyc.access is checked elsewhere). Identity / bank: ID &amp; bank at full or view only.
    /// masked_partial and masked_full cannot open the file (a scan shows every digit) and see a masked value instead. No SensitiveAccess (a job, a test) is unrestricted.</summary>
    public static bool MayOpen(string? documentType, SalesApi.Services.SensitiveAccess? sensitive, IReadOnlyCollection<string>? companyTypes = null) =>
        !IsIdentityOrBank(documentType, companyTypes)
        || SalesApi.Services.SensitiveLevels.CanReadRaw((sensitive ?? SalesApi.Services.SensitiveAccess.Unrestricted).RoleLevel(SalesApi.Services.SensitiveCategories.IdBank));
}

/// <summary>One stage file gate a file meets by link (POST /attachments/{id}/gate-links). The file keeps its own tag.</summary>
public record AttachmentGateLinkDto(string Stage, string RequirementKey);

/// <summary>POST /attachments/{id}/gate-links body.</summary>
public record AttachmentGateLinkInput(string? Stage, string? RequirementKey);

/// <summary>POST /attachments/links (SharePoint program, Phase 4): link files that already live in SharePoint. Nothing is copied.</summary>
public record AttachmentLinkItemInput(string? DriveId, string? ItemId);
public record AttachmentLinkInput(string? RecordType, Guid? RecordId, List<AttachmentLinkItemInput>? Items);

/// <summary>Plain sentences shared by the places that refuse a link row.</summary>
public static class AttachmentRules
{
    public const string LinkHasNoFile = "This file lives in SharePoint. Open it from its link.";
    public const string LinkIsNotProof = "A SharePoint link cannot be a payment proof: attach the proof as a file instead.";
}

/// <summary>The kinds of record a file can hang on, and the plain rules about them.</summary>
/// <summary>The "doctype:{key}" tag namespace: a client's own document (trade licence, VAT certificate...). The key is one of the
/// org's "document_types" picklist values. Allowed on a deal's or an account's files only.</summary>
public static class AttachmentTags
{
    public const string ClientDocumentPrefix = "doctype:";

    /// <summary>Channel partners: the partner's tax invoice for a payout. Reserved: it lives on the PARTNER ACCOUNT only, and reading or adding it needs the Partner commercials category.</summary>
    public const string PartnerInvoice = "partner_invoice";

    /// <summary>E15.5: a sanctions-screening evidence file, tagged "screening:{screening id}". It sits on the SUBJECT'S ACCOUNT and, like a KYC document, is invisible without kyc.access.</summary>
    public const string ScreeningPrefix = "screening:";

    public static string ScreeningTag(Guid screeningId) => ScreeningPrefix + screeningId.ToString("D");

    public static bool IsScreening(string? tag) => tag is not null && tag.StartsWith(ScreeningPrefix, StringComparison.Ordinal);

    /// <summary>The screening id a "screening:{id}" tag names, else null.</summary>
    public static Guid? ScreeningId(string? tag) => IsScreening(tag) && Guid.TryParse(tag![ScreeningPrefix.Length..], out var id) ? id : null;

    /// <summary>A well-formed screening tag (a real id after the prefix).</summary>
    public static bool IsValidScreening(string tag) => ScreeningId(tag) is not null;

    /// <summary>Files that need kyc.access to be seen, listed, downloaded, added or deleted: client documents and screening evidence.</summary>
    public static bool IsKycFile(string? tag) => IsClientDocument(tag) || IsScreening(tag);

    public static bool IsClientDocument(string? tag) =>
        tag is not null && tag.StartsWith(ClientDocumentPrefix, StringComparison.Ordinal);

    /// <summary>The document type key of a "doctype:{key}" tag, else null.</summary>
    public static string? ClientDocumentType(string? tag) => IsClientDocument(tag) ? tag![ClientDocumentPrefix.Length..] : null;

    /// <summary>A well-formed client-document tag: a lower-case key of letters, digits and underscores (a picklist value's shape).</summary>
    public static bool IsValidClientDocument(string tag)
    {
        var key = ClientDocumentType(tag);
        return key is { Length: > 0 and <= 60 } && key.All(c => c is (>= 'a' and <= 'z') or (>= '0' and <= '9') or '_');
    }
}

public static class AttachmentRecordType
{
    public const string Lead = "lead";
    public const string Account = "account";
    public const string Quote = "quote";
    public const string Invoice = "invoice";
    public const string Amc = "amc";

    public static readonly IReadOnlyList<string> All = new[] { Lead, Account, Quote, Invoice, Amc };

    public static bool IsKnown(string? type) => type is not null && All.Contains(type);

    /// <summary>The word the not-found / not-allowed messages use.</summary>
    public static string Label(string type) => type == Amc ? "AMC" : char.ToUpperInvariant(type[0]) + type.Substring(1);
}

/// <summary>Facts about the caller the HTTP layer resolves (authorization stays at the controller; facts about the
/// caller travel down as data). Each record type's own endpoints sit behind one of these permissions.</summary>
/// <param name="ViewKyc">E15.1: the caller holds kyc.access. A "doctype:{key}" file (a KYC / company document) is invisible - not listed, not downloadable, not addable, not deletable - without it. Trailing and defaulting to true so callers that never deal in client documents keep compiling.</param>
public record AttachmentPermissions(bool ViewFinancials, bool ViewContactDetails, bool ViewKyc = true);

// GET/PUT /attachments/deleted-record-retention - what happens to a record's files once the record is deleted.
// Same shape as CardScanRetentionDto.
public record DeletedRecordRetentionDto(string Mode, int RetentionDays);
public record DeletedRecordRetentionInput(string? Mode, int? RetentionDays);

/// <summary>What an attachment row is: bytes we hold ("file"), or a reference to a file that lives in SharePoint
/// ("sharepoint_link": no bytes, no storage provider, opens at its web address).</summary>
public static class AttachmentKind
{
    public const string File = "file";
    public const string SharePointLink = "sharepoint_link";
}

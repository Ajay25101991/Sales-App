// The API-keys contracts.
//
// Moved out of ApiKeysController (API-led migration, step 8, 2026-08-28):
// these were nested public records on the controller itself, which worked
// only while the controller was also where every scope/hash/generation
// decision lived. Once that logic moves to Process/System, the wire shapes
// have to live somewhere both layers — and Experience, which cannot see
// System at all — can name them. They are plain values (strings, guids,
// dates, a List<string>), so Contracts is where they belong on the merits,
// not as a convenience.
//
// PlaintextKey is the one field on this whole domain that matters most:
// ApiKeyCreatedDto carries it, and it is returned to the client exactly once,
// on creation, by SalesApi.ProcessApi/ApiKeys/ApiKeyProcess.cs. Nothing else
// in the system — no Store method, no other DTO — ever reproduces it, because
// only the SHA-256 hash is persisted (see ApiKeyHasher's own docs).

namespace SalesApi.Dtos;

public record ScopeDefDto(string Key, string Label);

public record ApiKeyDto(
    Guid Id, string Name, string DisplayPrefix, List<string> Scopes,
    DateTime CreatedAt, DateTime? ExpiresAt, DateTime? LastUsedAt, DateTime? RevokedAt);

public record ApiKeyCreatedDto(ApiKeyDto Key, string PlaintextKey);

// ExpiresInDays: 30 | 90 | 365 | 0 (= never expires). OMITTED/null = the org's default (ApiKeySettingsDto.DefaultExpiryDays).
// ExpiresAt (an exact instant, must be in the future) is the older way and still accepted; give one of the two, not both.
public record CreateApiKeyInput(string? Name, List<string>? Scopes, DateTime? ExpiresAt, int? ExpiresInDays = null);

// PATCH /api-keys/{id}: rename and/or change scopes. Whichever is null is left as it is.
public record UpdateApiKeyInput(string? Name, List<string>? Scopes);

// GET/PUT /api-keys/settings. DefaultExpiryDays null = new keys never expire. RateLimitPerMinute is per key.
public record ApiKeySettingsDto(
    int? DefaultExpiryDays, int RateLimitPerMinute, List<int> ExpiryChoices, int MinRateLimitPerMinute, int MaxRateLimitPerMinute);

// PUT: DefaultExpiryDays is ALWAYS applied (null = never); RateLimitPerMinute null = leave unchanged.
public record ApiKeySettingsInput(int? DefaultExpiryDays, int? RateLimitPerMinute);

// Field-change audit read contract — design doc
// to-do/e1-event-backbone-design.md §6/§8 ("read endpoint for later"). Feeds
// GET /leads/{id}/history and GET /accounts/{id}/history.

namespace SalesApi.Dtos;

/// <summary>
/// One row of <c>FieldChangeAuditEntry</c>, permission-masked per the
/// caller — <see cref="OldValue"/>/<see cref="NewValue"/> are null when the
/// caller lacks the permission that field is gated on (mirrors how
/// <c>LeadMapping.ToDto</c> masks <c>EstimatedValue</c>/contact fields), not
/// omitted from the page: the fact "this field changed" is still worth
/// showing even when the value is not.
/// </summary>
public record FieldChangeAuditEntryDto(
    Guid Id,
    string EntityType,
    Guid EntityId,
    string Field,
    string? OldValue,
    string? NewValue,
    Guid? ChangedBy,
    DateTime ChangedAt);

// The unified record timeline read contract — design doc
// to-do/e1-event-backbone-design.md §7/§8 ("timeline endpoints"). Feeds
// GET /leads/{id}/timeline and GET /accounts/{id}/timeline.

namespace SalesApi.Dtos;

/// <summary>
/// One normalised fact from any contributing source (LeadStageEvent,
/// LeadActivity, Reminder, DomainEvent, ApprovalRequest, Proposal, Invoice,
/// Payment, LeadRoutingEvent, FieldChangeAuditEntry) — see
/// <c>SalesApi.Services.TimelineService</c> for the union query that builds
/// these.
///
/// <see cref="Kind"/> is either one of <c>TimelineKinds</c>'s dedicated-source
/// keys (e.g. "lead_stage_changed", "activity_logged", "reminder_created",
/// "field_changed") or, for an item sourced from <c>domain_events</c>, the
/// RAW <c>DomainEvent.Type</c> string (e.g. "lead.closed_won") — the client
/// renders an unrecognised kind with a generic icon and <see cref="Summary"/>
/// rather than needing a switch statement kept in sync with the server's
/// vocabulary (design's "render generically by type" requirement).
///
/// <see cref="Detail"/>/<see cref="Summary"/> already reflect permission
/// masking (design §7): a masked amount reads "Hidden" in the rendered text
/// rather than being a separate boolean the client must apply itself — the
/// same "hide the number, keep the fact" rule <c>FieldChangeAuditEntryDto</c>
/// applies via null old/new values, done here as text because a timeline
/// entry's summary is prose, not a structured field.
///
/// <see cref="LeadId"/>/<see cref="LeadName"/> are set on every item in an
/// account-rollup timeline (design §7/§9: "each tagged with its lead id and
/// name") and null for an account's own-row items and for every item in a
/// lead timeline (the lead is already the page's subject there).
/// </summary>
public record TimelineItemDto(
    DateTime OccurredAt,
    string Kind,
    string Summary,
    string? Detail,
    Guid? ActorId,
    string? ActorName,
    Guid SourceId,
    Guid? LeadId,
    string? LeadName,
    // E6.1/E6.2 (design §5.2) — a generic "open the source elsewhere" link,
    // set for email.received/email.sent and meeting.scheduled/meeting.completed
    // (the Graph webLink, "Open in Outlook") and null for every other kind.
    // Generic and optional on purpose: a future source sets the same field
    // rather than growing a source-specific one.
    string? LinkUrl = null,
    // E6.2 story slice 10 (design §6) — "a cancellation marks it cancelled
    // on the timeline". EXACT FIELD: "cancelled" (snake_case on the wire,
    // this app's JsonNamingPolicy.SnakeCaseLower), a nullable bool — true
    // only on a meeting.scheduled item whose logged meeting was cancelled;
    // null (omitted-in-spirit, though System.Text.Json still serializes a
    // null property) for every other item, including meeting.completed
    // (a completed meeting was, by definition, never cancelled — see
    // TimelineService.MailboxLoggedMeeting's completed-scan guard). Generic
    // on the DTO, not a meeting-specific property name, the same "one field,
    // set by whichever source needs it" shape LinkUrl above already uses —
    // a future cancellable source (if one arrives) sets the same field.
    bool? Cancelled = null,
    // Coordinator follow-up (E6.4 finish) — set ONLY on a whatsapp.sent item,
    // joined by Meta's own message id against WhatsAppOutboundMessage
    // (TimelineService.WhatsAppDeliveryStatusesAsync): "sent"/"delivered"/
    // "read"/"failed" (wire: delivery_status), same vocabulary
    // WhatsAppOutboundMessage.Statuses already uses server-side. Null for
    // every other kind, and for a whatsapp.sent item whose outbound row
    // cannot be found (e.g. a pre-existing event raised before this field
    // existed, carrying no meta_message_id).
    string? DeliveryStatus = null,
    // The plain-text reason a "failed" DeliveryStatus carries (wire:
    // delivery_error), already mapped from Meta's error code via
    // WhatsAppStatusReasons — never Meta's raw code. Null unless
    // DeliveryStatus is "failed".
    string? DeliveryError = null);

/// <summary>Kind constants for items sourced from a dedicated table rather
/// than a raw <c>DomainEvent</c> — see <see cref="TimelineItemDto.Kind"/>.</summary>
public static class TimelineKinds
{
    public const string LeadStageChanged = "lead_stage_changed";
    public const string ActivityLogged = "activity_logged";
    public const string ReminderCreated = "reminder_created";
    public const string ApprovalRequested = "approval_requested";
    public const string ApprovalDecided = "approval_decided";
    public const string ProposalSent = "proposal_sent";
    public const string ProposalAccepted = "proposal_accepted";
    public const string ProposalDeclined = "proposal_declined";
    public const string InvoiceRaised = "invoice_raised";
    public const string PaymentReceived = "payment_received";
    public const string LeadRouted = "lead_routed";
    public const string FieldChanged = "field_changed";
}

/// <summary>The four client-facing groupings the "kinds" filter and the
/// desktop timeline's category chips both key off — design §7's "kind
/// filter" (All / Activities / Stage & status / Money / Changes). A source
/// query and every domain-event type map to exactly one category
/// (<c>TimelineService.CategoryOf</c>), so filtering can skip whole source
/// queries rather than filtering rows after the fact.</summary>
public static class TimelineCategories
{
    public const string Activity = "activity";
    public const string Stage = "stage";
    public const string Money = "money";
    public const string Change = "change";

    public static readonly string[] All = [Activity, Stage, Money, Change];
}

// The E4.4 prompt/skill registry wire shapes (design doc
// to-do/e4-ai-platform-design.md §4, §15 slice 6). Field names follow the
// same PascalCase-to-snake_case convention every other Dtos file uses
// (JsonNamingPolicy.SnakeCaseLower).

namespace SalesApi.Dtos;

/// <summary>A library row — everything the "Admin, AI skills" list (design
/// §4.3) renders for one platform skill and the caller's org.</summary>
public record AiSkillSummaryDto(
    Guid Id,
    string Key,
    string Name,
    bool IsBuiltIn,
    int PlatformLiveVersion,
    int? OrgLiveVersion,
    int? OrgDraftVersion,
    bool HasOrgOverride);

/// <summary>One version row (GET .../versions) — either the org's own or one
/// of the platform's published ones, per <c>AiSkillStore.VersionsVisibleToOrgAsync</c>.</summary>
public record AiSkillVersionDto(
    Guid Id,
    int Version,
    string Status,
    bool IsPlatform,
    string TaskClass,
    string SystemPromptTemplate,
    string? OutputSchemaJson,
    DateTime CreatedAt,
    Guid? CreatedById,
    DateTime? PublishedAt,
    Guid? PublishedById);

public record AiSkillDraftInput(string? SystemPromptTemplate, string? OutputSchemaJson, string? TaskClass);

public record AiSkillDraftResultDto(Guid VersionId, int Version, string Status);

/// <summary>One golden-set case's outcome for the version that was just
/// published — design §4.3 ("eval results per version") and §10's own
/// "surface the per-case results in the publish response DTO so the admin
/// screen can show them" (story slice 11). Empty when the skill ships no
/// golden set.</summary>
public record AiSkillEvalCaseResultDto(string CaseName, bool Passed, string? Reason);

public record AiSkillPublishResultDto(
    Guid VersionId, int Version, string Status, DateTime? PublishedAt,
    IReadOnlyList<AiSkillEvalCaseResultDto>? EvalResults = null);

/// <summary>Result of "the effective prompt for skill X in org Y" (design
/// §4's resolver) — what a future skill-invoking caller (E5, not built in
/// this slice) would actually send to the gateway.</summary>
public record AiSkillEffectivePromptDto(
    string Key,
    int Version,
    bool IsOrgOverride,
    string TaskClass,
    string SystemPromptTemplate,
    string? OutputSchemaJson);

// The Webhooks contracts (API-led migration, step 8).
//
// Moved out of WebhooksController's nested records so Experience — which
// cannot see SalesApi.SystemApi at all — can still return them. Shapes and
// property names are unchanged, so the JSON a customer's delivery endpoint
// already binds to (JsonNamingPolicy.SnakeCaseLower) does not move.

namespace SalesApi.Dtos;

public record WebhookEventDefDto(string Key, string Label);

public record WebhookSubscriptionDto(
    Guid Id, string Event, string EndpointUrl, DateTime CreatedAt,
    DateTime? PausedAt, DateTime? RevokedAt,
    int? LastStatusCode, DateTime? LastDeliveryAt, bool LastDeliverySuccess);

public record WebhookSubscriptionCreatedDto(WebhookSubscriptionDto Subscription, string SigningSecret);

public record CreateWebhookSubscriptionInput(string? Event, string? EndpointUrl);

// PATCH /webhooks/{id}: either field may be given; whichever is null/blank is left as it is.
public record UpdateWebhookSubscriptionInput(string? Event, string? EndpointUrl);

public record WebhookDeliveryDto(
    Guid Id, string Event, int Attempts, DateTime CreatedAt,
    DateTime? DeliveredAt, int? LastStatusCode, string? LastError, bool GaveUp, DateTime? NextAttemptAt);

// E1 step 8 (to-do/e1-event-backbone-design.md section 8 step 8): the full
// grouped catalogue behind GET /webhooks/catalog - every subscribable key
// (the 3 frozen legacy ones plus every domain-event type), its group for the
// desktop picker's sections, a one-line description, its documented payload
// field names, and whether it is one of the 3 frozen legacy (flat, not
// enveloped) shapes.
public record WebhookCatalogEntryDto(
    string Key, string Label, string Group, string Description, string[] Fields, bool Legacy,
    // Terminology key (OrgSettings.TerminologyKeys) whose word the label contains, so the client can show the org's
    // own term (e.g. "Proposal sent" for "Quote sent"). Null = label is shown as is.
    string? TermKey = null);

// SharePoint program, Phase 4: attach files that already live in SharePoint (design doc
// to-do/microsoft-365-sharepoint-design.md section 6). JSON is snake_case (the host's global naming policy).

namespace SalesApi.Dtos;

/// <summary>GET /sharepoint/browse/status. <paramref name="State"/> is ready | not_connected | sign_in_again | off | unavailable
/// (off = the org switch is off; unavailable = the deployment switch is off).</summary>
public record SharePointBrowseStatusDto(string State, string? Message);

/// <summary>One thing in a browse list. <paramref name="Kind"/> is file | folder | library | site. A site has an empty
/// <paramref name="DriveId"/> and its id in <paramref name="ItemId"/> and <paramref name="SiteId"/>; a library has its drive id
/// and an empty <paramref name="ItemId"/> (its root).</summary>
public record SharePointBrowseItemDto(
    string DriveId, string ItemId, string Name, string Kind, string? SiteId, long? SizeBytes, string? MimeType,
    DateTime? ModifiedAt, string? ModifiedBy, string? WebUrl, string? Location);

/// <summary><paramref name="Next"/> is an opaque cursor, passed back as <c>?cursor=</c>.</summary>
public record SharePointBrowsePageDto(List<SharePointBrowseItemDto> Items, string? Next);

/// <summary>The body of a 409 from a browse route: the caller cannot browse right now.</summary>
public record SharePointBrowseRefusedDto(string Error, string State);

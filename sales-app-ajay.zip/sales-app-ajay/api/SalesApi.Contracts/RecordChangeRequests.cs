using System.Text.Json;

namespace SalesApi.Dtos;

// E19.2 - record change requests: a portal user's proposed edit to an Account or a Contact, approved by staff (old against new against current) before it is saved.
// NOT the E7.4 Studio change request (ChangeRequests.cs). Wire shapes are snake_case like the rest of the API.

/// <summary>The caller, as DATA handed down from the controller (the layer rule: a Process class never reads a principal): the portal user's profile and the account they
/// belong to. A request may target that account or any account below it.</summary>
public sealed record RecordChangePortalScope(Guid UserId, Guid PortalAccountId, bool IncludeChildren = false);

/// <summary>
/// POST /portal/change-requests. <c>target_type</c> is "account" or "contact". <c>values</c> is an object of the proposed values: scalar fields by their snake_case name
/// (account: name, industry, website, phone, address, city, state, postal_code, country, country_code; contact: name, title, email, phone, phone_country_code,
/// preferred_language) and custom fields nested under "custom" (<c>{"custom": {"licence_no": "123"}}</c>). Scalars are text; an empty string clears the value.
/// A second submit for the same record replaces the caller's pending request.
/// </summary>
public record RecordChangeSubmitInput(string? TargetType, Guid TargetId, JsonElement? Values);

/// <summary>POST /record-change-requests/{id}/reject. The reason is required and is shown to the requester.</summary>
public record RecordChangeRejectInput(string? Reason);

/// <summary>What the requester sees of their own request. No stored values of the record travel back: only what they proposed.</summary>
public record RecordChangePortalDto(
    Guid Id, string TargetType, Guid TargetId, string Status, JsonElement Values,
    DateTime CreatedAt, DateTime UpdatedAt, DateTime? DecidedAt, string? DecisionReason);

public record RecordChangeRequesterDto(Guid Id, string? Name, string Email);

/// <summary>
/// One proposed field. <c>field</c> is a column name, or <c>custom.&lt;key&gt;</c> for a custom field. <c>old</c> is the stored value when the request was made (or
/// last re-submitted), <c>new</c> the proposed value, <c>current</c> the stored value NOW; <c>changed_since</c> is true when current differs from old (the record moved
/// on after the request, so staff should look twice). <c>masked</c> is true when the caller's sensitive-data level hides or partly hides the value: old, new and
/// current are then masked text or null, exactly as the account / contact reads show them.
/// </summary>
public record RecordChangeFieldDto(string Field, JsonElement? Old, JsonElement? New, JsonElement? Current, bool ChangedSince, bool Masked);

public record RecordChangeRequestDto(
    Guid Id, string TargetType, Guid TargetId, Guid AccountId, string? AccountName, string? ContactName, string Status,
    RecordChangeRequesterDto Requester, List<RecordChangeFieldDto> Fields,
    DateTime CreatedAt, DateTime UpdatedAt, DateTime? DecidedAt, Guid? DecidedById, string? DecisionReason);

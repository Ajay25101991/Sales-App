namespace SalesApi.Dtos;

// ---- Deal values per stage (owner 2026-11-12, to-do/deal-values-per-stage-design.md) -----------------------------------------------------------

/// <summary>The three fixed sets of a deal's stage values. The same for every workflow (owner decision 3).</summary>
public static class StageValueKinds
{
    public const string Proposal = "proposal";
    public const string Negotiation = "negotiation";
    public const string Closed = "closed";
    public static readonly string[] All = [Proposal, Negotiation, Closed];
    public static bool IsValid(string? kind) => kind is not null && Array.IndexOf(All, kind) >= 0;
}

/// <summary>The role a workflow stage can carry: the stage whose LEAVING captures the Proposal / Negotiation set (<c>value_role</c> on the stage).</summary>
public static class StageValueRoles
{
    public const string Proposal = StageValueKinds.Proposal;
    public const string Negotiation = StageValueKinds.Negotiation;
    public static readonly string[] All = [Proposal, Negotiation];
    public static bool IsValid(string? role) => role is not null && Array.IndexOf(All, role) >= 0;
}

/// <summary>One column of the stage-value table: a ticked deal custom field (key, label and type come from its live definition).</summary>
public record StageValueFieldDto(string Key, string Label, string Type);

/// <summary>
/// One captured set. <c>values</c> maps a field key to its figure (a field with no figure is absent); every number here, and <c>deal_value</c>, is null
/// for a caller who cannot read deal values (see <see cref="LeadStageValuesDto.Masked"/>). <c>edited_by</c> is the display name of whoever last corrected it.
/// </summary>
public record StageValueSetDto(
    Dictionary<string, decimal?> Values, decimal? DealValue, DateTime CapturedAt, DateTime? EditedAt, string? EditedBy);

/// <summary>The three sets of a deal; a set that was never captured is null.</summary>
public record StageValueSetsDto(StageValueSetDto? Proposal, StageValueSetDto? Negotiation, StageValueSetDto? Closed);

/// <summary>GET /leads/{id}/stage-values. <c>fields</c> = the lead's OWN workflow's stage_value_fields; <c>masked</c> = the caller cannot read deal values.</summary>
public record LeadStageValuesDto(List<StageValueFieldDto> Fields, StageValueSetsDto Sets, bool Masked = false);

/// <summary>
/// PUT /leads/{id}/stage-values/{kind}. <c>values</c> changes only the keys it names (a key sent as null clears that figure); <c>deal_value</c> changes the
/// set's deal value when sent, <c>clear_deal_value</c> clears it. A key must be one of the workflow's stage value fields or already in the set.
/// </summary>
public record StageValueSetInput(Dictionary<string, decimal?>? Values, decimal? DealValue = null, bool ClearDealValue = false);

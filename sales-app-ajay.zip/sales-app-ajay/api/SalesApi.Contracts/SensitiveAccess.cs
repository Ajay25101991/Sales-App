namespace SalesApi.Services;

// E12.1 / E12.2 — the caller's SENSITIVE-DATA access, expressed as plain values.
//
// Lives in Contracts for the same reason RecordAccessContext and TeamScope do (CallerScope.cs): it describes the
// caller, carries no EF and no HTTP, and every layer legitimately shares it. How a caller is IDENTIFIED (the
// roles store, the principal) stays in the System layer; what travels DOWN is this value, so a Process class
// never reads a ClaimsPrincipal to decide what to show.
//
// Design: to-do/sensitive-data-design.md. Wire: to-do/sensitive-data-api.md.

/// <summary>The fixed data categories a role is given a level for (six built in E12, plus partner_commercials).</summary>
public static class SensitiveCategories
{
    public const string ContactDetails = "contact_details";
    public const string DealValues = "deal_values";
    public const string IdBank = "id_bank";
    public const string CompanyFinancials = "company_financials";
    public const string IdentityChecks = "identity_checks";
    public const string DealInsights = "deal_insights";

    /// <summary>Channel-partner commercial terms: plan rates, ledger amounts, statements, payouts (owner decision Q9, 2026-10-19). Appended, so a stored override still names its category by the same key.</summary>
    public const string PartnerCommercials = "partner_commercials";

    /// <summary>Display order. Append-only: a stored override names its category by this key.</summary>
    public static readonly string[] All =
        [ContactDetails, DealValues, IdBank, CompanyFinancials, IdentityChecks, DealInsights, PartnerCommercials];

    public static bool IsValid(string? key) => key is not null && Array.IndexOf(All, key) >= 0;

    /// <summary>The label the roles screen and a refusal message show.</summary>
    public static string Label(string category) => category switch
    {
        ContactDetails => "Contact details",
        DealValues => "Deal values",
        IdBank => "ID & bank",
        CompanyFinancials => "Company financials",
        IdentityChecks => "Identity checks",
        DealInsights => "Deal insights",
        PartnerCommercials => "Partner commercials",
        _ => category,
    };
}

/// <summary>The five levels a role holds for a category. Strongest first.</summary>
public static class SensitiveLevels
{
    public const string Full = "full";
    public const string ViewOnly = "view_only";
    public const string MaskedPartial = "masked_partial";
    public const string MaskedFull = "masked_full";
    public const string Hidden = "hidden";

    public static readonly string[] All = [Full, ViewOnly, MaskedPartial, MaskedFull, Hidden];

    public static bool IsValid(string? level) => level is not null && Array.IndexOf(All, level) >= 0;

    /// <summary>Higher = more access. An unknown level ranks as hidden (fail closed).</summary>
    public static int Rank(string? level) => level switch
    {
        Full => 4,
        ViewOnly => 3,
        MaskedPartial => 2,
        MaskedFull => 1,
        _ => 0,
    };

    /// <summary>The caller may be handed the real value (full or view only).</summary>
    public static bool CanReadRaw(string? level) => level is Full or ViewOnly;

    /// <summary>The caller may change the value.</summary>
    public static bool CanWrite(string? level) => level == Full;

    public static bool IsMasked(string? level) => level is MaskedPartial or MaskedFull;

    /// <summary>The caller may see SOMETHING (real or masked text). Hidden and unknown: no.</summary>
    public static bool CanReach(string? level) => level is Full or ViewOnly or MaskedPartial or MaskedFull;

    /// <summary>
    /// The level the legacy boolean permissions (contact_details.view, lead_values.view) mean: on = full, off = hidden.
    /// This IS the migration rule, so it lives in one place both the store and the tests read.
    /// </summary>
    public static string FromLegacyBit(bool granted) => granted ? Full : Hidden;
}

/// <summary>
/// E12.5 - one approved reveal that is still inside its time limit: this caller may read <see cref="Category"/> on ONE record.
/// Carried on <see cref="SensitiveAccess"/>; applied by <see cref="SensitiveAccess.ForRecord"/>. <see cref="Used"/> is set the first time a
/// mapper actually lifts a level for it in this request, which is what the once-per-grant value_revealed log entry keys on.
/// </summary>
public sealed class RevealGrant
{
    public RevealGrant(Guid requestId, string recordType, Guid recordId, string category, DateTime expiresAt)
    {
        RequestId = requestId;
        RecordType = recordType;
        RecordId = recordId;
        Category = category;
        ExpiresAt = expiresAt;
    }

    public Guid RequestId { get; }
    public string RecordType { get; }
    public Guid RecordId { get; }
    public string Category { get; }
    public DateTime ExpiresAt { get; }

    /// <summary>Set by <see cref="SensitiveAccess.ForRecord"/> when a mapper used this grant. Per request (the grants are loaded per request).</summary>
    public volatile bool Used;
}

/// <summary>
/// What THIS caller may see of each category, resolved once per request at the HTTP layer and passed down as data.
/// </summary>
public sealed class SensitiveAccess
{
    /// <summary>
    /// The level an approved reveal lifts a masked category to, for the one record it covers. view_only: the real value is readable
    /// and still not editable (a reveal is not an edit grant). The ONE place to change if the owner wants it to be full.
    /// </summary>
    public const string RevealLevel = SensitiveLevels.ViewOnly;

    public const string ScopeOwn = "own";
    public const string ScopeOwnTeam = "own_team";
    public static readonly string[] Scopes = [ScopeOwn, ScopeOwnTeam];

    private readonly IReadOnlyDictionary<string, string> _levels;

    private readonly IReadOnlyDictionary<string, DateTime>? _revealed;

    public SensitiveAccess(
        IReadOnlyDictionary<string, string> levels, string assignedScope, Guid userId, TeamScope teams,
        IReadOnlyList<RevealGrant>? grants = null)
        : this(levels, assignedScope, userId, teams, grants, null) { }

    private SensitiveAccess(
        IReadOnlyDictionary<string, string> levels, string assignedScope, Guid userId, TeamScope teams,
        IReadOnlyList<RevealGrant>? grants, IReadOnlyDictionary<string, DateTime>? revealed)
    {
        Grants = grants ?? Array.Empty<RevealGrant>();
        _revealed = revealed;
        _levels = levels;
        AssignedScope = assignedScope == ScopeOwn ? ScopeOwn : ScopeOwnTeam;
        UserId = userId;
        Teams = teams;
    }

    /// <summary>E12.5 - the caller's approved, unexpired reveals (loaded per request). Empty for nearly everyone.</summary>
    public IReadOnlyList<RevealGrant> Grants { get; }

    /// <summary>
    /// E12.5 - THE one place a reveal grant takes effect. Returns the access to use for ONE record: the same access with every category
    /// the caller holds an active grant for on (<paramref name="recordType"/>, <paramref name="recordId"/>) raised to
    /// <see cref="RevealLevel"/> (never lowered; the assigned scope no longer narrows a granted category). A mapper that has the record
    /// calls this once at the top and reads levels from the result, so DTOs, history and timeline agree. Purely time-based: a grant past
    /// its instant is ignored here, no worker needed. Returns <c>this</c> when nothing applies.
    /// </summary>
    public SensitiveAccess ForRecord(string recordType, Guid recordId)
    {
        if (Grants.Count == 0) return this;
        var now = DateTime.UtcNow;
        Dictionary<string, DateTime>? active = null;
        foreach (var g in Grants)
        {
            if (g.RecordId != recordId || g.RecordType != recordType || g.ExpiresAt <= now) continue;
            g.Used = true;
            active ??= new Dictionary<string, DateTime>(StringComparer.Ordinal);
            if (!active.TryGetValue(g.Category, out var existing) || existing < g.ExpiresAt) active[g.Category] = g.ExpiresAt;
        }
        return active is null ? this : new SensitiveAccess(_levels, AssignedScope, UserId, Teams, Grants, active);
    }

    /// <summary>E12.5 - category -> expiry of the reveals <see cref="ForRecord"/> applied; null when none. For the DTO's reveal_expires_at.</summary>
    public Dictionary<string, DateTime>? RevealExpiries =>
        _revealed is null || _revealed.Count == 0 ? null : new Dictionary<string, DateTime>(_revealed, StringComparer.Ordinal);

    /// <summary>E12.5 - the same access with no grants (exports and other surfaces that must keep showing masked text).</summary>
    public SensitiveAccess WithoutGrants() =>
        Grants.Count == 0 && _revealed is null ? this : new SensitiveAccess(_levels, AssignedScope, UserId, Teams, null, null);

    private string Raise(string category, string level) =>
        _revealed is not null && _revealed.ContainsKey(category) && SensitiveLevels.Rank(level) < SensitiveLevels.Rank(RevealLevel)
            ? RevealLevel : level;

    public string AssignedScope { get; }
    public Guid UserId { get; }
    public TeamScope Teams { get; }

    /// <summary>Every category at full. Background jobs and tests that render as nobody in particular.</summary>
    public static SensitiveAccess Unrestricted { get; } = new(
        SensitiveCategories.All.ToDictionary(c => c, _ => SensitiveLevels.Full),
        ScopeOwnTeam, Guid.Empty, TeamScope.Everything);

    /// <summary>
    /// The access the two legacy booleans describe: contact details and deal values on (full) or off (hidden), the
    /// other four categories full (no built-in field was ever gated by them). Lets every pre-E12 call site that
    /// still passes two booleans keep its exact behaviour.
    /// </summary>
    public static SensitiveAccess FromLegacyFlags(bool canSeeContactDetails, bool canSeeValues)
    {
        var levels = SensitiveCategories.All.ToDictionary(c => c, _ => SensitiveLevels.Full);
        levels[SensitiveCategories.ContactDetails] = SensitiveLevels.FromLegacyBit(canSeeContactDetails);
        levels[SensitiveCategories.DealValues] = SensitiveLevels.FromLegacyBit(canSeeValues);
        // Everywhere: the assigned-scope narrowing is moot (Unrestricted team scope), so a flag-built access never masks by record.
        return new SensitiveAccess(levels, ScopeOwnTeam, Guid.Empty, TeamScope.Everything);
    }

    /// <summary>The ROLE's level for a category, ignoring which record is being read.</summary>
    public string RoleLevel(string category) =>
        Raise(category, _levels.TryGetValue(category, out var level) && SensitiveLevels.IsValid(level) ? level : SensitiveLevels.Hidden);

    /// <summary>
    /// The level that applies to one RECORD. Only contact details narrow by record: a role at full or view only
    /// sees real values on a record assigned to the caller (per <see cref="AssignedScope"/>) and masked_partial
    /// elsewhere. A role already at a masked level or hidden stays there on its own records — the role's level
    /// always wins; the scope only narrows where full applies.
    /// </summary>
    public string LevelFor(string category, Guid? ownerId, Guid? teamId)
    {
        var level = RoleLevel(category);
        if (category != SensitiveCategories.ContactDetails || !SensitiveLevels.CanReadRaw(level)) return level;
        if (_revealed is not null && _revealed.ContainsKey(category))
            // An approved reveal beats the scope narrowing (outside the scope it lifts the record to a read) and never LOWERS the role:
            // level is full or view_only here, so on a record already in scope it is left exactly as it is.
            return InAssignedScope(ownerId, teamId) ? level : RevealLevel;
        return InAssignedScope(ownerId, teamId) ? level : SensitiveLevels.MaskedPartial;
    }

    /// <summary>Owner is the caller; or, under own_team, the record sits in one of the caller's teams.</summary>
    public bool InAssignedScope(Guid? ownerId, Guid? teamId)
    {
        if (ownerId is { } owner && owner == UserId && UserId != Guid.Empty) return true;
        if (AssignedScope == ScopeOwn) return false;
        return Teams.Covers(teamId);
    }

    /// <summary>
    /// May contact details be used as a SEARCH / FILTER / SORT key across the caller's records? Only when the role reads
    /// them raw AND the assigned scope is the whole visible set (own_team: a non-admin's visible records are their own
    /// plus their teams'; an org admin's Everything covers all). Under `own` some visible records are masked, and a
    /// predicate cannot be applied per record without becoming an oracle for the masked ones, so contact fields are
    /// simply not searchable there. A masked or hidden role is never searchable.
    /// </summary>
    public bool ContactDetailsSearchable =>
        SensitiveLevels.CanReadRaw(RoleLevel(SensitiveCategories.ContactDetails)) && AssignedScope == ScopeOwnTeam;

    /// <summary>All six role levels, for echoing back.</summary>
    public IReadOnlyDictionary<string, string> RoleLevels =>
        SensitiveCategories.All.ToDictionary(c => c, RoleLevel);
}

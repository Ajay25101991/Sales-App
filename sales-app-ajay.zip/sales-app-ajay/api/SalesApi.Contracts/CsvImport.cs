// The CsvImport contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- CSV import ---
// Mapping is an optional lead-field -> CSV-header map so a differently-shaped CSV
// can be imported without renaming its columns first. SourceMap optionally
// remaps raw source values in the file onto the org's defined lead sources
// (rawValue -> orgSource), so imports land on the configured list.
// AccountMode is the review step's account decision ("none" | "link" |
// "link_and_create" — LeadImportProcess.ImportAccountMode's wire names),
// carried in the body now rather than only the `account_mode` query
// parameter: a documented request shape should not omit a choice the review
// step actually makes. The query parameter is still read (LeadsController)
// as a fallback for any older caller that has not moved to the body yet —
// the body wins when both are present.
//
// ConfirmDuplicateRows (E3.11 unattended-paths follow-up, 2026-09-26) is the
// review step's PER-ROW duplicate decision, mirroring LeadInput.ConfirmDuplicate
// at the single-lead level: the 1-based row numbers (header is row 1, so the
// first data row is row 2 — the same numbering CsvImportError.Row already
// uses) the caller has chosen "create anyway" for, after seeing them on the
// preview as CsvImportResult.DuplicateRows. A row flagged as matching an open
// deal that is NOT in this list is skipped — the same behaviour every caller
// got before this field existed, so an old client that never sends it keeps
// today's "has an open deal: <name>" skip unchanged.
//
// PhoneCountryCode (phone storage decision, 2026-09-30) is ONE country for the
// WHOLE FILE, not a per-row CSV column — the file format has no such column to
// read one from. Optional: absent means today's digits-only behaviour, exactly
// as before this field existed. Applied only to rows whose phone has no '+'
// (see Lead.NormalizePhone's own doc comment — a '+' number already names its
// own country and ignores this). Sent on both the preview call and the real
// import (PREVIEW AND IMPORT ARE THE SAME CODE PATH, per LeadImportProcess's
// own doc comment), so the review step's duplicate detection already reflects
// the chosen country before the caller commits.
public record CsvImportInput(
    string? Csv, Dictionary<string, string>? Mapping, Dictionary<string, string>? SourceMap,
    string? AccountMode = null, List<int>? ConfirmDuplicateRows = null, string? PhoneCountryCode = null);
public record CsvImportError(int Row, string Reason);

// E3.11 unattended-paths follow-up — one row the dry run (or a real import
// that didn't get a confirmation for it) skipped because the person already
// has an open deal, carrying the SAME OpenDealDto shape the single-lead
// `open_deal_exists` refusal uses (id, name, stage label, owner) so the
// review step can offer "Open it" / "Create anyway" per row without a second
// round trip. A key can match more than one open lead (rare — same email and
// phone on two separate open deals), hence a list rather than one deal.
public record CsvImportDuplicateRowDto(int Row, IReadOnlyList<OpenDealDto> OpenDeals);
// SkippedDetails and UnreadableDates exist for the PREVIEW (dry-run) call — the
// All/Skipped toggle needs to know WHICH rows are skipped, not just the count,
// and the unreadable-date warning needs a count of rows whose follow-up date
// column didn't parse. Capped at 25 like ErrorDetails, for the same reason: a
// row-by-row list of a 10,000-row file is not what either screen renders.
// Both are populated on a real (non-dry-run) import too, at no extra cost —
// the same loop already knows both — so nothing about this shape is
// preview-only; it is simply unused there today.
//
// LinkedAccounts and InvalidPhones follow the same shape as
// CreatedAccounts/UnreadableDates above — a plain count, no per-row list,
// because neither one is a reason a row didn't import (the row still lands):
// LinkedAccounts is how many LEADS (not distinct companies — see
// CreatedAccounts) were linked to an account that already existed, and
// InvalidPhones is how many rows carried a phone number too malformed to
// ever match another for duplicate purposes (see ContactFieldFormat.LooksInvalidPhone).
// DuplicateRows follows SkippedDetails' own cap (25) for the same reason: a
// row-by-row list beyond a screenful is not what the review step renders. A
// row confirmed via ConfirmDuplicateRows never appears here (it was created,
// not skipped) even on a repeat preview call.
public record CsvImportResult(
    int Created, int Skipped, int Errors, List<CsvImportError> ErrorDetails, int CreatedAccounts = 0,
    List<CsvImportError>? SkippedDetails = null, int UnreadableDates = 0,
    int LinkedAccounts = 0, int InvalidPhones = 0, List<CsvImportDuplicateRowDto>? DuplicateRows = null);

// --- CSV import: dry-run preview, saved mappings, defaults ---

/// <summary>
/// GET /leads/import/mapping?headers=... — a previously saved column mapping for
/// this exact set of CSV headers, so a repeat import from the same source (the
/// same export tool, run again next month) can skip the mapping step entirely.
/// Matched on the header SET (order-independent, case-insensitive), not the file
/// name or any other signal the server doesn't have.
/// </summary>
public record SavedImportMappingDto(
    Dictionary<string, string> Mapping, Dictionary<string, string>? SourceMap, DateTime UpdatedAt);

public record SaveImportMappingInput(
    List<string>? Headers, Dictionary<string, string>? Mapping, Dictionary<string, string>? SourceMap);

/// <summary>
/// GET /leads/import/defaults — what an unmapped field becomes, in the caller's
/// own org, right now. The wizard's mapping step names the stage default already
/// (computed client-side from the pipeline the caller can already see); this is
/// everything else it CANNOT compute itself: the literal default priority, and
/// that an owner column with nothing recognized in it falls back to the person
/// running the import.
/// </summary>
public record CsvImportDefaultsDto(string Status, string Priority, Guid OwnerId, string? OwnerName);

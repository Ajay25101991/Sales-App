// The Tags contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Tags ---

// UsageCount is leads currently carrying this tag (soft-deleted leads excluded —
// see TagsController.UsageCountsAsync). CreatedAt only; no UpdatedAt in the DTO
// today, nothing renders it. Returned only by TagsController (GET/POST/PATCH
// /tags) — everywhere else a tag is EMBEDDED on another record (a lead, an
// account), it is a TagRefDto instead. UsageCount is an org-wide count computed
// with its own query; faking one on every lead/account payload (0, or the lead's
// own tag count) would be a number this API never actually computed.
public record TagDto(Guid Id, string Name, string NormalizedName, string? Color, int UsageCount, DateTime CreatedAt);

// A tag as carried by another record (a lead's Tags, an account's derived
// roll-up) — identity + display only, no usage count. See TagDto's comment for
// why the count is deliberately not here.
public record TagRefDto(Guid Id, string Name, string NormalizedName, string? Color);

public record CreateTagInput(string? Name, string? Color);

// Color is a three-state field, same convention as EmailProviderInput.SmtpPassword:
// omitted (null) leaves the stored colour alone, the literal "clear" removes it
// (back to client-derived), anything else must be a hex value and replaces it.
public record UpdateTagInput(string? Name, string? Color);

public record MergeTagInput(Guid? IntoTagId);

// One org-wide forecast snapshot (owner decision §22) plus, once the period
// has closed, what actually happened — MonthlyDealStatsOrg's own WonValue for
// the same (year, month), the SAME stored figure every other monthly report
// reads, not a second computation of "actual". Actual/AccuracyPct are null
// until the period has fully closed; Predicted is null-masked (not the whole
// row omitted) when the caller lacks ViewLeadValues, matching every other
// money figure in this controller.
public record ForecastSnapshotDto(
    int Year,
    int Month,
    DateTime SnapshotAt,
    decimal? Predicted,
    decimal? Actual,
    // Actual / Predicted, when both are known and Predicted is nonzero. Null,
    // not a divide-by-zero 0 or a misleading 100 — a forecast of $0 has no
    // meaningful "how accurate was it" answer.
    double? AccuracyRatio);

// A governed measure (MeasureRegistry) computed over a period AND its prior
// equivalent period (owner decision §34 — the reader chooses the comparison
// basis; Basis/BasisLabel travel WITH the figure so a reader can always see
// which comparison produced Delta/DeltaPct, rather than a hidden assumption).
public record PeriodComparisonDto(
    string Measure,
    decimal? Current,
    decimal? Prior,
    decimal? Delta,
    // (Current - Prior) / Prior. Null when Prior is null, zero, or Current is
    // null — a "% change" from nothing or to nothing is not a number.
    double? DeltaPct,
    string Basis,
    string BasisLabel);

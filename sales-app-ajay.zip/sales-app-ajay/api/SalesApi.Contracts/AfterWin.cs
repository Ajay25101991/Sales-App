// E13 "After the win" (to-do/e13-after-the-win-design.md): GET /leads/{id}/after-win.
//
// Money follows the account rollup's masking (AccountProcess.RollupAsync): the invoice-derived figures are null for a caller who
// cannot see invoice money (CanViewMoney false), and ClosedValue follows the lead's own deal-value masking. A null is "you may not
// see this", never zero.

namespace SalesApi.Dtos;

/// <summary>A draft invoice on the deal. Listed, never totalled (owner answer 2).</summary>
public record AfterWinDraftDto(Guid Id, string Number, decimal Amount);

public record AfterWinTermDto(string Key, string Label);

public record AfterWinStageDto(string Key, string Label);

/// <summary>One recurring contract (an AMC) of the deal. ContractValue is null when the caller cannot see invoice money.</summary>
public record AfterWinContractDto(Guid Id, string? Title, string Label, decimal? ContractValue, DateTime RenewalDate, string Status);

/// <summary>The deal's engagement letter: State is draft | sent | accepted | signed (signed = a signed copy is on file).</summary>
public record AfterWinLetterDto(string State);

/// <summary>
/// A handover task of the deal (created when the deal enters a stage with handover items): a task of the deal that carries a handover key.
/// Done is the task's completion time. An unclaimed role-queue task has no AssigneeId/AssigneeName and names its role instead.
/// </summary>
public record AfterWinHandoverTaskDto(
    Guid Id, string Title, string Status, DateTime? DueAt, Guid? AssigneeId, string? AssigneeName,
    string? AssigneeRoleKey, string? AssigneeRoleLabel, DateTime? CompletedAt);

/// <summary>
/// The contract a workflow set to "offer" proposes on a win, for the client to confirm through the existing POST /amcs
/// (title is the client's, label/value/start/renewal are these). Also what "auto" would have opened.
/// </summary>
public record RecurringOfferDto(string Label, decimal ContractValue, DateTime Start, DateTime Renewal);

public record AfterWinDto(
    decimal? ClosedValue,
    decimal? Invoiced,
    decimal? Paid,
    decimal? DiscountsTaken,
    decimal? Outstanding,
    decimal? Overdue,
    decimal? NotYetInvoiced,
    List<AfterWinDraftDto>? Drafts,
    string Currency,
    AfterWinTermDto? PaymentTerm,
    List<AfterWinContractDto> RecurringContracts,
    AfterWinLetterDto? EngagementLetter,
    List<AfterWinHandoverTaskDto> HandoverTasks,
    AfterWinStageDto? NextPostCloseStage,
    RecurringOfferDto? RecurringOffer,
    bool CanViewMoney,
    bool CanChangeSettings,
    /// <summary>The deal's workflow requires a signed engagement letter before its first invoice is issued, and there is none yet: the auto draft
    /// is still made, but it cannot be issued until the letter is signed (the card says so).</summary>
    bool WaitingOnEngagementLetter = false,
    /// <summary>VAT on the issued invoices (their tax amounts): the difference between Invoiced (before VAT) and what the customer is billed. Null when money is hidden.</summary>
    decimal? Vat = null);

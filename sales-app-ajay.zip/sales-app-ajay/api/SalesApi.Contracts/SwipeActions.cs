// The SwipeActions contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Per-team swipe actions (the phone's lead-card swipe menu) ---

// One team's row on the admin screen. `Configured` distinguishes "this team was
// deliberately given this set" from "this team has no override and is showing
// you the org default" — without it the screen could not offer a Reset, and an
// admin could not tell inherited values from chosen ones.
public record TeamSwipeActionsDto(
    Guid TeamId,
    string TeamName,
    bool IsDefaultTeam,
    bool Configured,
    List<string> Left,
    List<string> Right);

public record SwipeActionsConfigDto(
    List<string> DefaultLeft,
    List<string> DefaultRight,
    List<TeamSwipeActionsDto> Teams);

// TeamId null means "the org default", which is why it is nullable rather than
// a separate endpoint: the screen edits one list of slots and the default is
// simply the slot every team falls back to.
public record SwipeActionsInput(Guid? TeamId, List<string>? Left, List<string>? Right);

// What one person's phone renders, already resolved server-side.
public record ResolvedSwipeActionsDto(List<string> Left, List<string> Right);

// Email provider configuration. SmtpPassword is a three-state field: omitted leaves
// the stored secret, the literal "clear" deletes it, anything else replaces it —
// see SettingsController.SetEmailProvider for why a plain null cannot express that.
public record EmailProviderInput(
    bool? Enabled, string? Provider, string? FromAddress, string? FromName,
    string? SmtpHost, int? SmtpPort, bool? SmtpUseTls, string? SmtpUsername,
    string? SmtpPassword,
    string? GraphTenantId, string? GraphClientId,
    // Same three-state contract as SmtpPassword: omitted -> leave alone,
    // "clear" -> delete it, any other value -> replace it.
    string? GraphClientSecret);

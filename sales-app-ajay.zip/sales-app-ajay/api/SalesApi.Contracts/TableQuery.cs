// One-table contract (to-do/one-table-inline-filters-design.md, sections 7 and 8).
// These are the wire shapes for GET /leads/columns and for the `filters` / `sorts`
// query parameters (and saved-view fields) that every paged list will share.
// JSON is snake_case on the wire (JsonNamingPolicy.SnakeCaseLower).

using System.Text.Json;

namespace SalesApi.Dtos;

/// <summary>One selectable value of a pick-type column. <c>Group</c> is only set
/// for the status column, where it is the playbook name (the org's default list
/// is grouped as "No playbook").</summary>
public record TableColumnOptionDto(string Value, string Label, string? Group = null);

/// <summary>One column of a list, as the table needs to draw its heading, sort and
/// filter controls. A column the caller may not see is never in the catalogue.</summary>
public record TableColumnDto(
    string Key, string Label, string Type, bool Sortable, bool Filterable,
    List<string> Ops, List<TableColumnOptionDto>? Options, bool DefaultVisible, bool? Pinned);

public record TableColumnsDto(List<TableColumnDto> Columns, int MaxSorts);

/// <summary>
/// One condition on a column. <c>Join</c> ("and" | "or") links it to the PREVIOUS
/// condition of the same column (the first condition's join is ignored).
/// <c>Value</c>/<c>Value2</c> are JSON scalars (string, number or boolean);
/// <c>Values</c> is the list for pick / multi-pick operators.
/// </summary>
public record TableConditionDto(
    string? Join, string Op, JsonElement? Value = null, JsonElement? Value2 = null, List<string>? Values = null);

/// <summary>A column's filter: an ordered list of conditions (AND binds before OR).
/// Different columns' filters AND with each other.</summary>
public record TableFilterDto(string Field, List<TableConditionDto> Conditions);

public record TableSortDto(string Field, string Dir);

/// <summary>The most columns a list may sort by at once.</summary>
public static class TableQueryLimits
{
    public const int MaxSorts = 5;
}

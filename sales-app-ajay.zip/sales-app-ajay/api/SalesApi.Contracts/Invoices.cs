// The Invoices contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Invoices & payments (collection) ---
//
// Money masking (invoice-money-masking, owner decision 2026-09-28): every
// money-shaped figure below is null — not 0 or a real number — for a caller
// without `account_financials.view` (OrganizationPermissions.ViewAccountFinancials),
// mirroring AccountDto's own convention EXACTLY (account-money-masking,
// 2026-09-27). Invoice ACCESS itself is unchanged — still ownership/team
// scoped via RecordAccessContext, gated at the HTTP layer by
// `financials.view` (ViewFinancials) on InvoicesController. This is
// field-level masking layered on top of that, the same relationship
// ViewAccountFinancials already has with AccountsController's own
// `financials.view`-gated access. TaxRate/LatePenaltyKind/DiscountCutoffDate/
// PromisedDate/Overdue/BrokenPromise are NOT masked — they are rates, labels,
// dates or booleans, not money, the same distinction AccountDto draws keeping
// OpenLeads (a count) and NextPromisedDate unmasked... except NextPromisedDate
// actually IS masked there; the difference here is Overdue is a computed FACT
// about the invoice (like AccountDto.ContactCount), not a currency figure, so
// it stays visible while every decimal beside it does not.
public record InvoiceDto(
    Guid Id,
    Guid LeadId,
    Guid? AccountId,
    Guid OwnerId,
    string Number,
    decimal? Amount,
    decimal? AmountPaid,
    decimal? Balance,
    string Status,
    bool Overdue,
    DateTime IssuedAt,
    DateTime DueDate,
    string? Notes,
    DateTime CreatedAt,
    DateTime UpdatedAt,
    // Convenience fields joined from the deal/rep for list + detail rendering.
    string? LeadName,
    string? Company,
    string? OwnerName,
    string? CustomerEmail,
    // Compliance fields (C2) — Subtotal + TaxAmount == Amount by construction.
    // TaxRate is the org's own VAT/tax rate (a policy percentage, the same for
    // every invoice), not a fact about THIS invoice's money — left unmasked.
    decimal? Subtotal,
    decimal TaxRate,
    decimal? TaxAmount,
    // Broken promise-to-pay (E3): the earliest promise on this invoice whose
    // date has passed while the invoice is still open/partial. Null unless the
    // caller is List() with broken_promise filtering context — see InvoicesController.
    bool BrokenPromise = false,
    DateTime? PromisedDate = null,
    decimal? PromisedAmount = null,
    // Null while still a draft; set once by POST /invoices/{id}/raise (or
    // immediately, for an invoice created already-open via POST /invoices).
    DateTime? RaisedAt = null,
    // Payment-term snapshot (see PaymentTermDto) — all null unless the
    // resolved term at creation time carried a discount/penalty. DiscountPercent/
    // LatePenaltyValue are masked (money-shaped figures the owner named
    // explicitly — "discount/penalty figures"); LatePenaltyKind/DiscountCutoffDate
    // are a label and a date, not money, and stay visible.
    decimal? DiscountPercent = null,
    DateTime? DiscountCutoffDate = null,
    string? LatePenaltyKind = null,
    decimal? LatePenaltyValue = null,
    // Set when this invoice was auto-generated from an accepted proposal
    // (ProposalBillingService), null otherwise.
    Guid? ProposalId = null,
    // M9 — the part of Amount that closed without cash because the customer
    // earned the early-payment discount. Balance above is Amount − AmountPaid −
    // this (see Invoice.BalanceOf), so a discounted invoice reads zero rather
    // than a 2% residual. Null (not 0) without ViewAccountFinancials — same
    // masking rule as every other figure here; 0 stays the real "no discount
    // taken" answer for a caller who CAN see it.
    decimal? DiscountTaken = 0m,
    // Set ONLY on the response to POST /invoices/{id}/payments and
    // POST /collection-tasks/{id}/collect, and null everywhere else — they
    // describe what just happened to a payment, not a property of the invoice.
    // They ride on this DTO because both endpoints already answer with it and a
    // second envelope would break every existing caller; the alternative was
    // leaving the one policy that deliberately drops money (cap_and_warn) with
    // nowhere to put its warning. M1.
    decimal? PaymentCredited = null,
    decimal? PaymentNotRecorded = null,
    // Finance fix (2026-10-17). Invoicing is done in an external system: this row RECORDS the external invoice.
    string? ExternalNumber = null,
    // Milestone this expected invoice stands for (null on an invoice that was not built from a term's schedule).
    string? MilestoneLabel = null,
    int? MilestoneSeq = null,
    decimal? MilestoneSharePercent = null,
    // The pricing-result key the milestone was taken of (null = the deal value, or what is left of it after the named bases).
    string? MilestoneBasis = null,
    string? MilestoneBasisLabel = null,
    // Set while the milestone waits for the deal to reach this stage: the invoice is "not yet due" and DueDate is only a
    // placeholder. Null once reached (or for any other invoice).
    string? AwaitingStageKey = null,
    string? VoidReason = null,
    string? WriteOffReason = null,
    decimal? WrittenOffAmount = null,
    // Q5: the late penalty under the invoice's own term, computed on read for an overdue invoice. "Due, not charged": it is
    // never part of Balance. Null when the invoice carries no penalty term or is not overdue.
    decimal? PenaltyDue = null,
    int? DaysOverdue = null);

// One priced line on a compliant invoice (C2). No LineTotal on the wire since
// #83 — the total is quantity × unit price, derived by the client the same way
// the server derives it (packages/core `lineTotal()` mirrors
// QuoteNumbering.LineTotal). Sending it too would just re-create, across the
// network boundary, the second source of truth the column was dropped to remove.
// UnitPrice is masked (null) without ViewAccountFinancials (invoice-money-masking) —
// Quantity/Description/SortOrder describe WHAT was billed, not how much.
public record InvoiceLineItemDto(Guid Id, string Description, decimal Quantity, decimal? UnitPrice, int SortOrder);
public record InvoiceLineItemInput(string? Description, decimal? Quantity, decimal? UnitPrice);

// Manager-defined email template for customer payment reminders. Supports the
// placeholders {customer} {company} {number} {amount} {balance} {due_date}.
public record InvoiceEmailTemplateDto(string Subject, string Body);
public record InvoiceEmailTemplateInput(string? Subject, string? Body);

public record InvoiceInput(
    Guid? LeadId,
    string? Number,
    // Set when raising an invoice for an AMC renewal term (D1) rather than a
    // fresh won deal — see InvoicesController.Create.
    Guid? AmcTermId,
    decimal? Amount,
    DateTime? IssuedAt,
    DateTime? DueDate,
    string? Notes,
    string? Status,
    // Optional itemised lines (C2). When omitted, Create() falls back to a
    // single "Professional services" line derived from Amount (back-compat
    // for the existing raise-invoice screen, which doesn't yet have a
    // line-item editor) — see InvoicesController.BuildLineItemsAsync.
    List<InvoiceLineItemInput>? LineItems,
    // Finance fix (2026-10-17). The external system's invoice number (unique per org when set).
    string? ExternalNumber = null,
    // Required on a manager's edit / void / write-off of an ISSUED invoice; stored and shown in the invoice's history.
    string? Reason = null,
    // Write-off amount (defaults to the whole balance); stored with the reason.
    decimal? WriteOffAmount = null,
    // Manager override of the "invoices may not exceed the deal's closed value (+VAT)" guard; Reason is then required.
    bool? ExceedDealValue = null);

/// <summary>POST /invoices/{id}/record-external - finance completes an expected (draft) invoice with the external invoice's
/// own figures; they replace the expected values and the invoice becomes a real (open) one.</summary>
public record RecordExternalInvoiceInput(
    string? ExternalNumber,
    decimal? Subtotal,
    decimal? VatAmount,
    DateTime? IssueDate,
    DateTime? DueDate,
    // Manager override of the deal-value guard (the external invoice may differ from what was expected); needs a reason.
    bool? ExceedDealValue = null,
    string? Reason = null);

// Amount masked (null) without ViewAccountFinancials — invoice-money-masking.
public record PaymentDto(
    Guid Id,
    Guid InvoiceId,
    Guid RecordedById,
    decimal? Amount,
    string Method,
    string? Reference,
    DateTime PaidAt,
    string? Note,
    Guid? ProofAttachmentId,
    string? ProofFilename,
    string? ProofMimeType,
    DateTime CreatedAt);

/// Task 10: the deal-level billing flag finance reads (GET /invoices/billing-flag?lead_id=). Null BillingFlag = nothing to flag.
public record DealBillingFlagDto(Guid LeadId, string? BillingFlag, Guid? QuoteId, string? QuoteNumber, string? Message);

public record PaymentInput(
    decimal? Amount,
    string? Method,
    string? Reference,
    DateTime? PaidAt,
    string? Note,
    Guid? ProofAttachmentId);

public record InvoiceActivityDto(Guid Id, Guid InvoiceId, Guid AuthorId, string Type, string? Body, DateTime? PromisedDate, decimal? PromisedAmount, DateTime CreatedAt);
public record InvoiceActivityInput(string? Type, string? Body, DateTime? PromisedDate, decimal? PromisedAmount);

// Channel-partner management, PHASE 2 contracts (design: to-do/partner-management-design.md sections 9.1 and 10, owner decisions 2026-10-19).
//
// WHAT PHASE 2 IS, after the owner's decisions overrode section 9:
//   - Registration is a RECORD on the deal partner (a date, who recorded it, a status, notes). No timers, no blocks, no money reads it.
//   - A referral for a client already in the pipeline is FLAGGED on the deal partner row (with the matched open deals) and decided ON THE DEAL.
//   - Two partners claiming one client is ALWAYS a manager decision (PartnerRegistrationConflict).
//   - An SI is a COST: milestones the deal owner (or partners.manage) accepts; accepting writes a cost entry through the existing payout pipeline when the plan says so.
//   - An FSP is a RECEIVABLE: the partner bills the end client, we invoice the partner for our fee, and the partner remits it. We record, we never net, we never charge interest.
//
// CONFIDENTIAL like the rest of the module: amounts and notes sit behind the sensitive-data category `partner_commercials`.

namespace SalesApi.Dtos;

// ---------------------------------------------------------------------------------------------------------------------
// Registration (a record) and the pipeline flag
// ---------------------------------------------------------------------------------------------------------------------

/// <summary>What a person recorded about a partner's registration of a client. Notes and who/when are withheld below a raw Partner commercials read (status stays).</summary>
public record DealPartnerRegistrationDto(
    string Status, DateOnly? RegisteredOn, Guid? RegisteredById, string? RegisteredByName, string? Notes, DateTime? DecidedAt, Guid? DecidedById);

/// <summary>Set or change the record. Every field is optional on update; Status must be registered | accepted | declined (a person sets it, nothing else ever does).</summary>
public record DealPartnerRegistrationInput(string? Status, DateOnly? RegisteredOn, string? Notes);

/// <summary>
/// A referral for a client that already has an open deal: the matched deals (those the caller may see, plus whether more exist that they may not) and the decision once made.
/// Not commercial data - a deal owner must see it to decide it.
/// </summary>
public record DealPartnerPipelineFlagDto(
    string Status, List<OpenDealDto> Matches, bool HiddenMatches, string? DecisionReason, DateTime? DecidedAt, Guid? DecidedById);

/// <summary>Accept or decline the referral. A reason is required to decline.</summary>
public record PipelineDecisionInput(bool Accept, string? Reason);

// ---------------------------------------------------------------------------------------------------------------------
// Two partners, one client
// ---------------------------------------------------------------------------------------------------------------------

public record PartnerRegistrationConflictDto(
    Guid Id, Guid LeadId, string? LeadName, Guid DealPartnerId, Guid PartnerAccountId, string? PartnerName,
    Guid AgainstDealPartnerId, Guid AgainstLeadId, string? AgainstLeadName, Guid AgainstPartnerAccountId, string? AgainstPartnerName,
    Guid? ClientAccountId, string? ClientName, string MatchedBy, string Status, string? Decision, string? DecisionReason,
    Guid? TaskId, Guid? DecidedById, DateTime? DecidedAt, DateTime CreatedAt);

/// <summary>Decision is new_claim | existing_claim | both; a reason is mandatory. It is recorded, and nothing changes automatically: the manager then sets each registration status.</summary>
public record PartnerConflictDecideInput(string? Decision, string? Reason);

// ---------------------------------------------------------------------------------------------------------------------
// SI milestones (cost)
// ---------------------------------------------------------------------------------------------------------------------

/// <param name="Amount">Ex VAT. Null when the caller's Partner commercials level withholds amounts.</param>
public record DealPartnerMilestoneDto(
    Guid Id, Guid DealPartnerId, Guid LeadId, int Seq, string Label, decimal? Amount, DateOnly? Due, string Status,
    DateTime? AcceptedAt, Guid? AcceptedById, string? AcceptedByName, string? Note, Guid? LedgerEntryId, bool CostRecorded, bool Settled);

/// <summary>Add (or, while planned, change) a milestone on an SI's deal partner row. Amount is ex VAT and above zero.</summary>
public record DealPartnerMilestoneInput(string? Label, decimal? Amount, DateOnly? Due);

/// <summary>Accept / reject / reopen. A reason is required to reject.</summary>
public record MilestoneDecisionInput(string? Note);

// ---------------------------------------------------------------------------------------------------------------------
// FSP remittance (receivable)
// ---------------------------------------------------------------------------------------------------------------------

/// <summary>
/// The FSP's obligation to us on ONE end-client deal: our invoice to the FSP (on the billing deal on the FSP's account), the end user's due date, when the FSP says it
/// collected, and the date remittance falls due (collection + the plan's days). <c>Status</c> is derived: expected (no invoice linked) | invoiced | remitted | overdue | waived.
/// <c>LateInterestWording</c> is what the agreement says late remittance costs - shown, never charged.
/// </summary>
public record PartnerRemittanceDto(
    Guid Id, Guid DealPartnerId, Guid PartnerAccountId, string? PartnerName, Guid EndClientLeadId, string? EndClientLeadName, Guid BillingLeadId, string? BillingLeadName,
    Guid? InvoiceId, string? InvoiceNumber, decimal? Billed, decimal? Remitted, decimal? Owed, string Status,
    DateOnly? EndUserDueOn, DateOnly? PartnerCollectedOn, DateOnly? RemitDueOn, int DaysOverdue,
    string? LateInterestWording, decimal? LateInterestEstimate, string? WaiveReason, DateTime? WaivedAt, DateTime CreatedAt);

/// <summary>Start the remittance record for an FSP deal partner. The billing deal must already be linked.</summary>
public record PartnerRemittanceCreateInput(Guid? DealPartnerId, DateOnly? EndUserDueOn, DateOnly? PartnerCollectedOn);

/// <summary>The dates, as staff read them from the partner's statement. Null = leave. The remittance due is recomputed from the collection date.</summary>
public record PartnerRemittanceUpdateInput(DateOnly? EndUserDueOn, DateOnly? PartnerCollectedOn, bool ClearPartnerCollectedOn = false);

/// <summary>Our invoice to the FSP, which must be on the billing deal.</summary>
public record PartnerRemittanceLinkInvoiceInput(Guid? InvoiceId);

public record PartnerRemittanceWaiveInput(string? Reason);

/// <summary>Link the deal on the FSP's account that our platform-fee invoices are raised on (ONE per end-client deal).</summary>
public record DealPartnerBillingDealInput(Guid? LeadId);

/// <summary>What a partner owes us, and what we owe an SI, side by side and never netted: the balances of one partner by direction.</summary>
public record PartnerBalancesDto(
    Guid PartnerAccountId, decimal Payable, decimal CostOwed, decimal ReceivableOwed,
    List<PartnerRemittanceDto> Remittances);

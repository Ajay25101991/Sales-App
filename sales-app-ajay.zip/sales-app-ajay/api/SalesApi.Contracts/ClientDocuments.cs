namespace SalesApi.Dtos;

// Client-document reading (to-do/proposal-deck-port-scope.md, owner decisions 6, 10, 11). A client's own documents (trade licence,
// VAT certificate, signatory ID / authority, MoA/AoA) are attached to a deal or an account with the tag "doctype:{key}"; the server
// reads them with open-source OCR; every read value waits here for a person to confirm it; only confirmed values reach the account's
// custom fields (where the document tokens pick them up). JSON is snake_case like the rest of the API.

/// <summary>One value read from (or entered about) a client document. <c>Value</c> is null when the caller may not see it
/// (<c>Masked</c> says so); a masked value cannot be confirmed from a screen that cannot show it.</summary>
public record ClientDocumentValueDto(
    Guid Id, Guid? AccountId, Guid? LeadId, string FieldKey, string FieldLabel, string DocumentType, string? Value, bool Masked,
    string Status, string Origin, string? Confidence, string? Evidence,
    Guid? SourceAttachmentId, string? SourceFileName, string? SourceFileUrl,
    DateTime ReadAt, Guid? ConfirmedById, DateTime? ConfirmedAt, string? ReadValue);

/// <summary>A client-document file and where its reading is (queued | reading | read | failed | not_applicable).</summary>
public record ClientDocumentFileDto(
    Guid AttachmentId, string FileName, string DocumentType, string RecordType, Guid RecordId, string? ReadState, string? ReadMessage,
    DateTime? ReadAt, DateTime UploadedAt, string FileUrl, bool CanOpen = true);

/// <summary>GET /client-documents?account_id= | lead_id= : the files, and the values read (pending first) or confirmed.</summary>
public record ClientDocumentsDto(
    IReadOnlyList<ClientDocumentFileDto> Files, IReadOnlyList<ClientDocumentValueDto> Values, Guid? AccountId, bool NeedsAccount);

/// <summary>One account field a document can fill.</summary>
public record ClientDocumentFieldDto(string Key, string Label, string Type, bool Sensitive, string Description);

/// <summary>A document type and the fields reading it can fill (GET /client-documents/fields). The type's label comes from the
/// org picklist "document_types"; this carries the built-in label for a type the picklist no longer has.</summary>
public record ClientDocumentTypeDto(string Key, string Label, IReadOnlyList<ClientDocumentFieldDto> Fields);

/// <summary>POST /client-documents/values/{id}/confirm-edited : confirm with a changed value. The reason is required and is
/// written as a note on the account.</summary>
public record ClientDocumentEditInput(string? Value, string? Reason);

/// <summary>POST /client-documents/values : a value typed in with no file. The reason is required (written as a note on the account).</summary>
public record ClientDocumentManualInput(Guid? AccountId, string? FieldKey, string? Value, string? Reason, string? DocumentType = null);

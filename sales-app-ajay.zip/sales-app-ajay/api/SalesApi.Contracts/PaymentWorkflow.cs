using System.Text.Json;
using System.Text.Json.Serialization;

// The PaymentWorkflow contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Payment workflow (won-deal -> draft invoice -> send reminder -> collection
// task), see PaymentWorkflowService. Config key payment_workflow_v1 — a NEW,
// standalone settings key. NOT the stage/workflow system: StageService.SaveAsync
// deletes any stage keyed won/lost, and WorkflowService.SaveAsync republishes
// the whole stage list on every publish, so neither can safely hold config that
// must survive both.
// A payment term has four independent parts (only the first is required):
//  1. Due-date logic — DueKind selects how DueDate is computed. "net_days"
//     (the default, existing behaviour) or "day_of_month" (a fixed calendar
//     day, e.g. "due on the 15th"). Milestone-triggered due dates are a valid
//     future DueKind — that's why this is a string discriminator + a per-kind
//     field, not a bare NetDays int.
//  2. Early-payment discount — classic "2/10 net 30": DiscountPercent off if
//     paid within DiscountDays of the close date. Both null together = no
//     discount offered; the pair is all-or-nothing (see SaveConfigAsync).
//  3. Late penalty — PenaltyKind discriminates "flat_fee_percent" (applied
//     once, the moment the invoice goes overdue) from "daily_rate" (accrues
//     per day overdue). PenaltyValue is the percentage for either kind. Both
//     null together = no penalty. Never inferred from PenaltyValue alone.
//  4. E-invoicing/XML tag mapping is deliberately NOT modelled — this product
//     has no e-invoicing network integration, so that vocabulary would be dead
//     config with nothing to consume it.
public record PaymentTermDto(
    string Key,
    string Label,
    int NetDays,
    decimal AdvancePercent,
    string DueKind = "net_days",       // net_days | day_of_month
    int? DueDayOfMonth = null,          // 1-28, used only when DueKind == day_of_month
    decimal? DiscountPercent = null,
    int? DiscountDays = null,
    string? PenaltyKind = null,         // flat_fee_percent | daily_rate | null
    decimal? PenaltyValue = null,
    // Finance fix (owner 2026-10-17): the term's invoice schedule. Each milestone is ONE expected invoice. Null/empty = the
    // term's legacy single-invoice behaviour (see PaymentMilestones.Effective, the one place that reads it).
    List<PaymentMilestoneDto>? Milestones = null);

/// <summary>
/// One milestone of a payment term: a share of the deal's value, billed as ONE expected (draft) invoice. Trigger is either
/// "days_after_win" (due = win + Days + NetDays) or "stage_reached" (waits, not yet due, until the deal reaches StageKey;
/// then due = reached + NetDays). Shares across a term's milestones sum to 100.
/// </summary>
public record PaymentMilestoneDto(
    string Label,
    decimal SharePercent,
    string Trigger = "days_after_win",
    int Days = 0,
    string? StageKey = null,
    int NetDays = 0,
    // E-invoicing pricing (owner 2026-10-19, option Y): the key of a pricing RESULT on the deal's quote (e.g. "setup", "platform_annual")
    // this milestone's share is taken of. Null = the deal value, exactly as before. Shares sum to 100 per basis.
    string? Basis = null);
public record PaymentWorkflowConfigDto(
    bool Enabled,
    List<PaymentTermDto> Terms,
    string DefaultTermKey,
    bool RequireTerms,
    bool CreateDraftInvoice,
    bool CreateSendReminder,
    int SendReminderDays,
    int SendReminderHour,
    List<string> SendReminderChannels,
    bool CreateCollectionTask,
    string CollectionTaskMethod,
    // Collection-task priority escalation (CollectionEscalationService): a
    // task's linked invoice this many days past due bumps it to "high", and
    // this many days past due bumps it to "critical". Same config surface as
    // everything else here — no hardcoded thresholds in the job itself.
    int EscalateHighDays = 15,
    int EscalateCriticalDays = 30,
    // M1 — what happens when a payment exceeds the invoice's remaining balance.
    // credit (default) | refuse | cap_and_warn; see PaymentSettlement for what
    // each does and why credit ships as the default. A default parameter, not a
    // backfill: an org whose stored payment_workflow_v1 blob predates this key
    // deserializes to "credit" on the next read, the same mechanism
    // EscalateHighDays/EscalateCriticalDays above arrived by.
    string OverpaymentPolicy = OverpaymentPolicies.Credit,
    // Owner decision #15 — what settling a HISTORICAL discount residual
    // writes. discount_taken (default) | write_off; see PaymentSettlement.
    // Same backfill mechanism as OverpaymentPolicy: a stored blob that
    // predates this key deserializes to the default on next read.
    string ResidualSettlementPolicy = ResidualSettlementPolicies.DiscountTaken,
    // Owner decision #16 — what happens to a residual that ISN'T settled.
    // dismissible (default) | age_filter | list_only; see PaymentSettlement.
    string ResidualTriagePolicy = ResidualTriagePolicies.Dismissible);
public record PaymentWorkflowConfigInput(
    bool? Enabled,
    List<PaymentTermDto>? Terms,
    string? DefaultTermKey,
    bool? RequireTerms,
    bool? CreateDraftInvoice,
    bool? CreateSendReminder,
    int? SendReminderDays,
    int? SendReminderHour,
    List<string>? SendReminderChannels,
    bool? CreateCollectionTask,
    string? CollectionTaskMethod,
    int? EscalateHighDays = null,
    int? EscalateCriticalDays = null,
    string? OverpaymentPolicy = null,
    string? ResidualSettlementPolicy = null,
    string? ResidualTriagePolicy = null)
{
    /// <summary>
    /// The field-by-field merge of this partial over <paramref name="current"/>: a null field keeps the current value.
    /// The ONE definition of that merge - PUT /settings/payment-workflow merges onto the org's stored config with it, and
    /// E13's per-workflow override merges onto the org's config with it (null = "use the org setting").
    /// </summary>
    public PaymentWorkflowConfigDto ApplyTo(PaymentWorkflowConfigDto current) => new(
        Enabled ?? current.Enabled,
        Terms ?? current.Terms,
        DefaultTermKey ?? current.DefaultTermKey,
        RequireTerms ?? current.RequireTerms,
        CreateDraftInvoice ?? current.CreateDraftInvoice,
        CreateSendReminder ?? current.CreateSendReminder,
        SendReminderDays ?? current.SendReminderDays,
        SendReminderHour ?? current.SendReminderHour,
        SendReminderChannels ?? current.SendReminderChannels,
        CreateCollectionTask ?? current.CreateCollectionTask,
        CollectionTaskMethod ?? current.CollectionTaskMethod,
        EscalateHighDays ?? current.EscalateHighDays,
        EscalateCriticalDays ?? current.EscalateCriticalDays,
        OverpaymentPolicy ?? current.OverpaymentPolicy,
        ResidualSettlementPolicy ?? current.ResidualSettlementPolicy,
        ResidualTriagePolicy ?? current.ResidualTriagePolicy);
}

/// One credit held to a customer, minted by an over-payment (M1) and now a visible register (Q11, owner 2026-10-17): what was received
/// (<see cref="Amount"/>), how much has been applied to invoices or refunded outside the CRM, and what is still held
/// (<see cref="Remaining"/>). Money figures mask to null without ViewAccountFinancials, like the invoice's own. See Models/AccountCredit.
public record AccountCreditDto(
    Guid Id,
    Guid? AccountId,
    string? AccountName,
    Guid LeadId,
    string? LeadName,
    Guid InvoiceId,
    string InvoiceNumber,
    Guid PaymentId,
    decimal? Amount,
    decimal? AppliedAmount,
    decimal? RefundedAmount,
    decimal? Remaining,
    string? Note,
    DateTime CreatedAt,
    DateTime? RefundedAt,
    string? RefundReason);

/// The customer-credit register for an account (or a deal): every credit, and the total still held.
public record AccountCreditListDto(List<AccountCreditDto> Credits, decimal? Balance);

/// Apply held credit to one of the customer's open invoices. Amount defaults to the smaller of what the credit still holds and what the invoice still owes.
public record ApplyCreditInput(Guid? InvoiceId, decimal? Amount);

/// Mark held credit as refunded OUTSIDE the CRM (the CRM does not move money). A reason is required; Amount defaults to everything still held.
public record RefundCreditInput(decimal? Amount, string? Reason);

/// An invoice whose residual balance matches the early-payment discount it was
/// raised under — Q5 of to-do/numbers-audit-verification.sql, surfaced for a
/// human. NOT settled automatically: a matching residual is indistinguishable
/// from a genuine short payment, so this is a review list, not a rule.
// Every money figure below is masked (null) without ViewAccountFinancials
// (invoice-money-masking, owner decision 2026-09-28) — same convention as
// InvoiceDto. DiscountPercent/ContractedDiscount are named "discount figures"
// by the owner decision explicitly, so they mask too, even though the former
// is a percentage rather than a currency amount.
public record DiscountResidualDto(
    Guid Id,
    string Number,
    Guid LeadId,
    string? LeadName,
    string? Company,
    decimal? Amount,
    decimal? AmountPaid,
    decimal? Balance,
    decimal? DiscountPercent,
    decimal? ContractedDiscount,
    DateTime IssuedAt,
    DateTime DueDate,
    DateTime? DiscountCutoffDate,
    // Owner decision #16. Only ever set under the `dismissible` triage policy;
    // present regardless of policy so a client that flips policies doesn't
    // need a second endpoint shape.
    DateTime? DismissedAt,
    // E13 (owner 2026-10-17): this row's own rules when its deal's workflow overrides the org's; null = the org's (the header's).
    string? TriagePolicy = null,
    string? SettlementPolicy = null);

public record DiscountResidualListDto(
    int Count,
    // Masked (null) without ViewAccountFinancials — it is a sum of the masked
    // Balance figures above.
    decimal? ArOverstatedBy,
    // What settling a row on this list will write, and what triaging offers —
    // named here rather than making the client re-derive them, since the UI
    // must say what "Settle" does before the person clicks it.
    string SettlementPolicy,
    string TriagePolicy,
    List<DiscountResidualDto> Invoices,
    // E13: the workflows (playbook ids) on this list whose triage or settlement rule differs from the org's — the header's
    // "some workflows differ" note. Empty when every row follows the org.
    List<Guid>? OverridingPlaybookIds = null);

// Per-rep receivables (collections leaderboard). Managers see the team; reps see self.
// Outstanding/Overdue/CollectedThisMonth masked (null) without
// ViewAccountFinancials (invoice-money-masking) — OpenCount/OverdueCount are
// counts, not values, and stay unmasked (same rule AccountDto's OpenLeads
// follows beside a masked OpenValue).
public record CollectionsLeaderboardRowDto(
    Guid UserId,
    string? FullName,
    decimal? Outstanding,
    decimal? Overdue,
    decimal? CollectedThisMonth,
    int OpenCount,
    int OverdueCount,
    int? AvgDaysOverdue);

// Collections dashboard: outstanding vs overdue + an aging breakdown. Amount
// masked (null) without ViewAccountFinancials; Count stays visible.
public record AgingBucket(string Bucket, string Label, int Count, decimal? Amount);

// Collections grouped by customer (E2) — "you collect from customers, not
// invoices." One row per account with open/overdue invoices. OldestBucket
// mirrors the CollectionsDto aging buckets (current/1_30/31_60/60_plus) so the
// client can reuse the same badge coloring. NextPromisedDate is the soonest
// upcoming (not-yet-passed) promise date logged against any of the account's
// open invoices; null when nothing has been promised.
// Outstanding/Overdue/NextPromisedDate masked (null) without
// ViewAccountFinancials — NextPromisedDate follows AccountDto's own precedent
// of masking the receivables-position date alongside the money, not just the
// money itself. OpenInvoiceCount/OverdueInvoiceCount are counts and stay
// unmasked.
public record CollectionsByCustomerRowDto(
    Guid AccountId,
    string AccountName,
    Guid? OwnerId,
    string? OwnerName,
    decimal? Outstanding,
    decimal? Overdue,
    string OldestBucket,
    string OldestBucketLabel,
    int? OldestDaysOverdue,
    DateTime? NextPromisedDate,
    int OpenInvoiceCount,
    int OverdueInvoiceCount);

// Outstanding/Overdue/CollectedThisMonth/aging Amount masked (null) without
// ViewAccountFinancials (invoice-money-masking); the counts stay visible.
public class CollectionsDto
{
    [JsonPropertyName("outstanding")] public decimal? Outstanding { get; set; }
    [JsonPropertyName("overdue")] public decimal? Overdue { get; set; }
    [JsonPropertyName("openCount")] public int OpenCount { get; set; }
    [JsonPropertyName("overdueCount")] public int OverdueCount { get; set; }
    // Q7: ALL money received in the window (incl. the part of an over-payment held as credit).
    [JsonPropertyName("collectedThisMonth")] public decimal? CollectedThisMonth { get; set; }
    // Q7/Q11: customer credit held and not yet applied to an invoice or refunded - a separate figure, never part of outstanding.
    [JsonPropertyName("unappliedCredit")] public decimal? UnappliedCredit { get; set; }
    [JsonPropertyName("aging")] public List<AgingBucket> Aging { get; set; } = new();
}

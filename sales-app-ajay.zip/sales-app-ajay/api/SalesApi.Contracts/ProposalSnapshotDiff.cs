using System.Globalization;

namespace SalesApi.Dtos;

/// <summary>
/// "What changed" between two generated proposal versions (E10.6, owner decision 9): a plain structured diff of the two frozen
/// snapshots, pure and database-free. There is no server-side precedent to reuse - <c>playbook-version-diff.ts</c> is the
/// client's diff of two playbook versions and works on a different shape - so this follows its idea (one entry per thing
/// that moved, "from" and "to", unchanged things silent) over this snapshot.
///
/// Services are matched by catalogue item. For a service in both versions: inputs that moved (add-ons - yes/no inputs - are
/// listed apart), results that moved, and the pricing-model / deck versions it is pinned to. A service in one version only is
/// "added" or "removed". The wrapper version and the three totals are compared last.
/// </summary>
public static class ProposalSnapshotDiff
{
    private const int SummaryParts = 3;

    /// <summary>The diff of <paramref name="from"/> (older) to <paramref name="to"/> (newer).</summary>
    public static ProposalDiffDto Compare(
        Guid proposalId, string? number, ProposalSnapshotDto to, Guid againstId, string? againstNumber, ProposalSnapshotDto from)
    {
        var fromBy = from.Services.ToDictionary(s => s.CatalogItemId);
        var toBy = to.Services.ToDictionary(s => s.CatalogItemId);

        var added = to.Services.Where(s => !fromBy.ContainsKey(s.CatalogItemId))
            .Select(s => new DiffServiceDto(s.CatalogItemId, s.Name, s.DealValue)).ToList();
        var removed = from.Services.Where(s => !toBy.ContainsKey(s.CatalogItemId))
            .Select(s => new DiffServiceDto(s.CatalogItemId, s.Name, s.DealValue)).ToList();

        var inputs = new List<DiffInputDto>();
        var addOns = new List<DiffInputDto>();
        var results = new List<DiffResultDto>();
        var versions = new List<ProposalVersionChangeDto>();

        if (from.WrapperVersion != to.WrapperVersion)
            versions.Add(new("wrapper", null, null, from.WrapperVersion, to.WrapperVersion));

        foreach (var now in to.Services)
        {
            if (!fromBy.TryGetValue(now.CatalogItemId, out var before)) continue;

            var fromInputs = before.Inputs.ToDictionary(i => i.Key);
            var toInputs = now.Inputs.ToDictionary(i => i.Key);
            foreach (var key in now.Inputs.Select(i => i.Key).Concat(before.Inputs.Select(i => i.Key)).Distinct())
            {
                fromInputs.TryGetValue(key, out var a);
                toInputs.TryGetValue(key, out var b);
                if (a is not null && b is not null && SameInput(a, b)) continue;
                var side = b ?? a!;
                var row = new DiffInputDto(now.CatalogItemId, now.Name, key, side.Label, side.Type, a?.Value, b?.Value, Words(a), Words(b));
                (side.Type == "yes_no" ? addOns : inputs).Add(row);
            }

            var fromResults = before.Results.ToDictionary(r => r.Key);
            var toResults = now.Results.ToDictionary(r => r.Key);
            foreach (var key in now.Results.Select(r => r.Key).Concat(before.Results.Select(r => r.Key)).Distinct())
            {
                fromResults.TryGetValue(key, out var a);
                toResults.TryGetValue(key, out var b);
                if (a is not null && b is not null && a.Value == b.Value) continue;
                var side = b ?? a!;
                results.Add(new DiffResultDto(now.CatalogItemId, now.Name, key, side.Label, side.Format, a?.Value, b?.Value));
            }

            if (before.PricingModelVersion != now.PricingModelVersion)
                versions.Add(new("pricing_model", now.CatalogItemId, now.Name, before.PricingModelVersion, now.PricingModelVersion));
            if (before.DeckVersion != now.DeckVersion)
                versions.Add(new("deck", now.CatalogItemId, now.Name, before.DeckVersion, now.DeckVersion));
        }

        var totals = new List<DiffFigureDto>();
        if (from.Totals.DealValue != to.Totals.DealValue) totals.Add(new("deal_value", from.Totals.DealValue, to.Totals.DealValue));
        if (from.Totals.Year1 != to.Totals.Year1) totals.Add(new("year1", from.Totals.Year1, to.Totals.Year1));
        if (from.Totals.Year2 != to.Totals.Year2) totals.Add(new("year2", from.Totals.Year2, to.Totals.Year2));

        var changed = added.Count + removed.Count + inputs.Count + addOns.Count + results.Count + versions.Count + totals.Count > 0;
        var diff = new ProposalDiffDto(proposalId, number, againstId, againstNumber, changed, "", added, removed, inputs, addOns, results, versions, totals);
        return diff with { Summary = Summarise(diff) };
    }

    /// <summary>Same value, same picks (by key, in order), same rows: an input that did not move.</summary>
    private static bool SameInput(SnapshotInputDto a, SnapshotInputDto b) =>
        a.Value == b.Value
        && (a.Picks ?? []).Select(p => p.Key).SequenceEqual((b.Picks ?? []).Select(p => p.Key), StringComparer.OrdinalIgnoreCase)
        && (a.Rows ?? []).SequenceEqual(b.Rows ?? []);

    /// <summary>A choice or a list in words ("Focus RT, Pact"; "none" when empty); null for any other type or when the input is absent.</summary>
    private static string? Words(SnapshotInputDto? i) => i switch
    {
        null => null,
        { Type: "choice" } => i.Picks is { Count: > 0 } picks ? string.Join(", ", picks.Select(p => p.Label)) : "none",
        { Type: "number_list" } => i.Rows is { Count: > 0 } rows
            ? string.Join(", ", rows.Select(r => r.ToString("0.##########", CultureInfo.InvariantCulture))) : "none",
        _ => null,
    };

    /// <summary>The one-line summary stored on the version when it is generated. Null-safe: a first version has nothing to compare.</summary>
    public static string ChangeSummary(ProposalSnapshotDto from, ProposalSnapshotDto to) =>
        Compare(Guid.Empty, null, to, Guid.Empty, null, from).Summary;

    /// <summary>"Added VAT; Entities 6 to 8; Deal value 11,000 to 13,500 and 2 more" - at most three parts, in the order a rep thinks.</summary>
    public static string Summarise(ProposalDiffDto d, bool includeMoney = true)
    {
        if (!d.Changed) return "No changes";
        var parts = new List<string>();
        if (d.ServicesAdded.Count > 0) parts.Add("Added " + string.Join(", ", d.ServicesAdded.Select(s => s.Name)));
        if (d.ServicesRemoved.Count > 0) parts.Add("Removed " + string.Join(", ", d.ServicesRemoved.Select(s => s.Name)));
        foreach (var i in d.InputChanges.Where(i => includeMoney || i.Type != "money"))
        {
            if (i.FromText is not null || i.ToText is not null)
            {
                // A pick that did not move but whose price did (a newer pricing model) is a number change a masked reader cannot see.
                if (i.FromText == i.ToText && !includeMoney) continue;
                parts.Add(i.FromText == i.ToText ? $"{i.Label} {Fmt(i.From)} to {Fmt(i.To)}" : $"{i.Label} {i.FromText ?? "none"} to {i.ToText ?? "none"}");
            }
            else parts.Add($"{i.Label} {Fmt(i.From)} to {Fmt(i.To)}");
        }
        foreach (var a in d.AddOnChanges) parts.Add($"{a.Label} {(a.To is > 0 ? "added" : "removed")}");
        foreach (var f in includeMoney ? d.Totals : []) parts.Add($"{FigureLabel(f.Name)} {Fmt(f.From)} to {Fmt(f.To)}");
        foreach (var v in d.VersionChanges)
            parts.Add(v.Kind == "pricing_model" ? $"{v.ServiceName} pricing updated" : v.Kind == "deck" ? $"{v.ServiceName} template updated" : "Wrapper updated");
        if (parts.Count == 0) parts.Add("Results recalculated");
        return parts.Count <= SummaryParts
            ? string.Join("; ", parts)
            : string.Join("; ", parts.Take(SummaryParts)) + $" and {parts.Count - SummaryParts} more";
    }

    private static string FigureLabel(string name) => name switch { "deal_value" => "Deal value", "year1" => "Year 1", _ => "Year 2" };

    private static string Fmt(decimal? v) => v is not { } x ? "blank"
        : x % 1 == 0 ? x.ToString("N0", CultureInfo.InvariantCulture) : x.ToString("N2", CultureInfo.InvariantCulture);
}

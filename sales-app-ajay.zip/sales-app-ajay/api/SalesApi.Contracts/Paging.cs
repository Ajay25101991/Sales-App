// The Paging contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Paging ---
// The envelope for keyset-paginated list endpoints (see Services/Paging).
// NextCursor is opaque to every caller — null means "no more rows". Only
// endpoints called with `paged=true` return this shape; every other GET
// (including the SAME endpoints called without `paged`) still returns a bare
// array, so existing full-set callers (lead-board, merge, amcs, …) are
// unaffected by this ever having been added.
public record PagedResult<T>(List<T> Items, string? NextCursor);

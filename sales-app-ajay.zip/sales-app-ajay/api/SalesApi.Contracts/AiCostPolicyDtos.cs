// The E4.3 cost-policy admin contracts (design doc
// to-do/e4-ai-platform-design.md §13, §15 slice 5). Own file for the same
// reason every other AI admin contract has one — see AiExecutionLog.cs's header.

namespace SalesApi.Dtos;

public record AiModelPriceDto(decimal InputPerMillionUsd, decimal OutputPerMillionUsd);

/// <param name="MonthToDateSpendUsd">Estimated — the running total of
/// <c>AiExecutionLogEntry.EstimatedCostUsd</c> for the org's current calendar
/// month in ITS OWN time zone, labelled clearly on the screen as an estimate
/// (story brief: "label it clearly as month-to-date estimated spend").</param>
public record AiCostPolicyDto(
    decimal? MonthlyBudgetUsd,
    decimal? PerUserMonthlyCapUsd,
    IReadOnlyDictionary<string, bool> Features,
    IReadOnlyDictionary<string, AiModelPriceDto> ModelPrices,
    decimal MonthToDateSpendUsd);

/// <summary>Every field optional so a partial save doesn't force resending the
/// rest — same <c>?? existing</c> merge rule <c>AiProviderInput</c> already
/// takes. <see cref="Features"/>/<see cref="ModelPrices"/>, when present,
/// REPLACE the whole map rather than merging key-by-key (simpler contract; the
/// admin screen always posts its full, edited map).</summary>
public record AiCostPolicyInput(
    decimal? MonthlyBudgetUsd,
    decimal? PerUserMonthlyCapUsd,
    IReadOnlyDictionary<string, bool>? Features,
    IReadOnlyDictionary<string, AiModelPriceDto>? ModelPrices);

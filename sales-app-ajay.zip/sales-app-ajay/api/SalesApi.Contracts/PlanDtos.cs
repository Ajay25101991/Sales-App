// E7.6 plan/entitlement admin contracts. Own file, same reason every other
// admin contract set has one — see AiExecutionLog.cs's header.

namespace SalesApi.Dtos;

public record PlanLimitDto(string MeterKey, decimal Amount, string Mode);

public record PlanDto(
    Guid Id,
    string Name,
    string Key,
    IReadOnlyList<string> Features,
    IReadOnlyList<PlanLimitDto> Limits,
    bool Archived,
    DateTime CreatedAt,
    DateTime? UpdatedAt);

/// <summary>Every field optional so a partial save (e.g. just archiving) does
/// not force resending the rest, same <c>?? existing</c> merge rule
/// <c>AiCostPolicyInput</c> already takes. <see cref="Features"/>/
/// <see cref="Limits"/>, when present, REPLACE the whole list rather than
/// merging entry-by-entry — the admin screen always posts its full edited
/// list.</summary>
public record EntitlementPlanInput(
    string? Name,
    string? Key,
    IReadOnlyList<string>? Features,
    IReadOnlyList<PlanLimitDto>? Limits,
    bool? Archived);

public record SetOrgPlanInput(Guid PlanId);

/// <summary>The platform-admin "set an org's plan" endpoint's response — a
/// mapped shape, never the Organization entity itself (LayerBoundaryTests:
/// a Process public surface may not name a System type).</summary>
public record OrgPlanAssignmentDto(Guid OrgId, string OrgName, Guid PlanId, string PlanName);

public record OrgPlanFeatureStatusDto(string Key, string Label, bool Enabled);

/// <param name="Usage">The raw current count for this org's current period —
/// never a pre-computed percentage (root CLAUDE.md: "never decide what a
/// displayed number means"); the client computes 80%/100% states from
/// Usage/Limit itself.</param>
/// <param name="Limit">Null when this meter carries no limit on the org's plan
/// (unmetered).</param>
/// <param name="Mode">"warn" | "stop" | null (null when <see cref="Limit"/>
/// is null).</param>
/// <param name="ResetsAt">The exclusive end of the current reporting period,
/// in the org's own calendar — same boundary <c>ReportingCalendar.EndOfMonthUtc</c>
/// computes elsewhere.</param>
public record OrgPlanMeterStatusDto(
    string MeterKey,
    string Label,
    decimal Usage,
    decimal? Limit,
    string? Mode,
    DateTime ResetsAt);

public record OrgPlanStatusDto(
    Guid PlanId,
    string PlanName,
    IReadOnlyList<OrgPlanFeatureStatusDto> Features,
    IReadOnlyList<OrgPlanMeterStatusDto> Meters);

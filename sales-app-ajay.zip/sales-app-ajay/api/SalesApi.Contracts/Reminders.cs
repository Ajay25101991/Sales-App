// The Reminders contracts.
//
// Split out of the single 1,981-line Dtos.cs on 2026-08-28, one file per domain
// (API-led migration, step 8). Two reasons, and the second is the operational
// one: the Experience layer cannot see the System layer at all, so a contract
// it must return has to live in this reference-free project — and with 31
// domains left to migrate, one shared contract file is a merge conflict every
// agent would hit at once.
//
// The namespace stays `SalesApi.Dtos`: moving a record between assemblies costs
// callers nothing, renaming its namespace costs every one of them a `using`.

namespace SalesApi.Dtos;

// --- Reminders ---
public record ReminderDto(
    Guid Id,
    Guid? LeadId,
    Guid? InvoiceId,
    Guid UserId,
    string Title,
    string? Notes,
    DateTime RemindAt,
    List<string> Channels,
    string Status,
    DateTime CreatedAt,
    // Team follow-up view (E1/Part 1) — populated only when the caller is a
    // manager listing the team (RemindersController.List); null for a rep's own
    // list, where every row is obviously theirs.
    string? OwnerName = null,
    // "invoice_send" when auto-created by PaymentWorkflowService.OnDealWonAsync;
    // null for a plain user reminder.
    string? Kind = null,
    // Who the reminder is ABOUT. A reminder carries only a LeadId, so a list of
    // them reads as a wall of titles with no way to tell which deal each one
    // belongs to. Resolved in RemindersController.List by the same batched
    // dictionary lookup the owner names use — one extra query for the page, not
    // one per row. Null when the reminder isn't attached to a lead.
    string? LeadName = null,
    string? LeadCompany = null);

public record ReminderInput(
    Guid? LeadId,
    string? Title,
    string? Notes,
    DateTime? RemindAt,
    List<string>? Channels,
    string? Status,
    // Reassign (E1/Part 1) — manager-only; PATCHing this moves the reminder to
    // another user_id. Ignored (and rejected — see RemindersController.Update)
    // for anyone who isn't a manager.
    Guid? OwnerId = null,
    // E2.5 (design doc §12 slice 7): the built-in "AMC renewal reminder"
    // automation's create_reminder action needs to stamp Reminder.AmcId the
    // same way AmcService.GenerateAsync's own (now-removed) inline
    // `db.Reminders.Add` did — that column is what the scan's own dedupe
    // (`db.Reminders.AnyAsync(r => r.AmcId == amc.Id && ...)`) matches
    // against, so an automation-created AMC reminder that left it null would
    // never be found by the next scan tick and would duplicate every
    // interval. Null for every other caller (unchanged).
    Guid? AmcId = null,
    // E2.5: the built-in idle-nudge/AMC-renewal automations stamp
    // Reminder.EventType exactly as the scans' own (now-removed) inline
    // writes did (NotificationEvents.Keys.LeadIdle / .AmcExpiring) — read by
    // the reminders list/detail screens to badge "why was I reminded of
    // this". Null for every other caller (unchanged, an ordinary reminder).
    string? EventType = null);

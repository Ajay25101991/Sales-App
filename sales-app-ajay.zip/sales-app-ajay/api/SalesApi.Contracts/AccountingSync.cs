// E17.3 — accounting sync log as the finance screens see it. Wire keys are snake_case.

namespace SalesApi.Dtos;

/// <summary>
/// One CRM record's push to an accounting system. <see cref="Status"/> is
/// pending|succeeded|failed. <see cref="WillRetry"/> is true while an automatic
/// retry is still scheduled; a failed row with it false has exhausted its attempts
/// and needs the retry action.
/// </summary>
public record AccountingSyncDto(
    Guid Id, string System, string EntityType, Guid EntityId, string Status, int Attempts,
    string? LastError, DateTime? LastAttemptAt, DateTime? NextAttemptAt, bool WillRetry,
    string? ExternalId, DateTime? SucceededAt, DateTime CreatedAt);

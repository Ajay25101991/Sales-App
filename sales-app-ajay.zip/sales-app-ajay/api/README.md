# Sales API (.NET 8 + EF Core)

The backend for the sales mobile app: ASP.NET Core Web API over Postgres, using
EF Core (code-first) with Npgsql. Exposes the REST contract the Expo app expects
(JWT auth, snake_case JSON). Replaces the earlier Node/Express backend.

## Run it

Requires Docker (for Postgres) and the .NET 8 SDK.

```bash
cd api
docker compose up -d          # Postgres in Docker on host port 5433
dotnet run                    # API on http://localhost:5100
```

On startup the app applies EF migrations and seeds 5 salespeople + sample
pipeline into the `sales_dotnet` database (idempotent-ish: it seeds only when the
`profiles` table is empty).

Seeded logins (password `Password123!`): `maya@salesco.test` (manager),
`liam@`, `sofia@`, `noah@`, `ava@salesco.test` (reps).

## Configuration

`appsettings.json`:

- `Urls` — `http://localhost:5100` (the app the client points at).
- `ConnectionStrings:Default` — local Postgres (`Host=localhost;Port=5433;Database=sales_dotnet`).
- `Jwt:Secret` — HS256 signing key (**must be ≥32 bytes**); override in production.
- `Jwt:AccessTokenMinutes` — 30. Access-token lifetime for a client that can
  refresh. This is the window in which a stolen token, a deactivated account or a
  just-changed password still works, so it is short by design.
- `Jwt:RefreshTokenDays` — 30. How long an idle device can come back without
  re-typing a password.
- `Jwt:ExpiresDays` — 30. The **legacy** access-token lifetime, still minted for
  clients that do not send `supports_refresh` (app builds shipped before refresh
  existed). Removable once those are out of the field.
- `Seed:Password` — password used for the seeded accounts.

### Sessions and refresh tokens

Sign-in with `supports_refresh: true` returns a short access token **and** an
opaque `refresh_token`; `POST /auth/refresh` exchanges it for a new pair.

- Refresh tokens are random 256-bit values, **not JWTs**, and only their SHA-256
  hash is stored (`refresh_tokens.token_hash`) — same discipline as
  `password_hash`. The raw value is never logged.
- **Rotated on every use.** The presented row is revoked in the same save that
  issues its successor.
- **Reuse is treated as theft.** Presenting an already-rotated token revokes the
  whole `family_id` lineage, not just that row, because the live branch of the
  chain may be the attacker's.
- Revoked on sign-out (`POST /auth/signout`, that session) and on
  `POST /auth/change-password` (every session — which then hands the caller back
  a replacement so the change does not surface as a delayed mystery logout).
- Expiry fails closed but does **not** burn the family: an idle device is not an
  attack.

Deploying this does not invalidate anything already in the field. Token
validation still checks signature and expiry only, so an access token minted
before the change stays valid until its own `exp`, and a client that does not ask
for refresh keeps getting the 30-day token it gets today.

Hosted deploys: set `DATABASE_URL` (a `postgres://…` URL — auto-converted to an
Npgsql connection string), `DATABASE_SSL=true`, and `Jwt__Secret`. `PORT`, if
present, is used as the listen port. See `render.yaml` for a one-click Render
blueprint (Docker web service + managed Postgres).

## Layout

```
api/
  Program.cs          # host setup: EF, JWT, CORS, rate limiting, middleware, seed
  Controllers/        # REST endpoints (authorization enforced here)
  Data/               # AppDbContext + DbInitializer (migrate + seed)
  Models/             # EF entities
  Dtos/               # request/response shapes (JSON casing pinned to the contract)
  Services/           # JwtService, reminder sweeper, proposal template, CSV, middleware
  Migrations/         # EF Core migrations
```

## Migrations

```bash
# The DbContext, the models and the migrations all live in SalesApi.SystemApi
# now (the System layer). EF needs the project that HOLDS the context, and the
# startup project that can build a host for it — and migrations must stay in the
# context's own assembly, because that is where EF looks for them at runtime.
dotnet ef migrations add <Name>   --project SalesApi.SystemApi/SalesApi.SystemApi.csproj --startup-project SalesApi.csproj
dotnet ef database update   --project SalesApi.SystemApi/SalesApi.SystemApi.csproj --startup-project SalesApi.csproj
# (applied automatically on startup too)
```

## Endpoints

`/auth`, `/profile`, `/leads` (+ `/leads/export`, `/leads/import`,
`/leads/{id}/activities|proposal|proposals|assign`), `/reminders` (+ `/sweep`),
`/dashboard`, `/team`, `/reports` (+ `/reports/rep/{id}`), `/attachments`,
`/custom-fields`, `/catalog-items`, `/health`. Swagger UI is served at `/` in
Development.
